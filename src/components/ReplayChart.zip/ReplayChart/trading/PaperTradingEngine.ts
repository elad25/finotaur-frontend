import { CandlestickData } from 'lightweight-charts';
import {
  Position,
  Order,
  TradeExecution,
  Side,
  OrderType,
  BacktestStats,
  TradeResult,
} from '../types';
import { calculatePnL, calculateRMultiple } from '../utils/trading';

/**
 * ===================================
 * PAPER TRADING ENGINE - V2.0 (INCREMENTAL STATS & LIMIT ORDERS)
 * Implements core trading logic, position management, and incremental statistics.
 * The trade logic now supports basic LIMIT orders execution.
 * ===================================
 */

export class PaperTradingEngine {
  private initialBalance: number;
  private balance: number;
  private commissionRate: number;
  private slippageRate: number;
  private leverage: number;

  private positions: Position[] = [];
  private pendingOrders: Order[] = [];
  private tradesHistory: TradeResult[] = [];
  private stats: BacktestStats;

  constructor(
    initialBalance: number,
    leverage: number,
    commissionRate: number,
    slippageRate: number
  ) {
    this.initialBalance = initialBalance;
    this.balance = initialBalance;
    this.commissionRate = commissionRate;
    this.slippageRate = slippageRate;
    this.leverage = leverage;

    // Initialize incremental stats
    this.stats = this.initializeStats();
  }

  private initializeStats(): BacktestStats {
    return {
      totalPnl: 0,
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      winRate: 0,
      profitFactor: 0,
      maxDrawdown: 0,
      maxPnl: 0,
      cumulativePnl: [
        { time: 0, value: this.initialBalance },
      ],
      averageR: 0, // NEW: Average R-multiple
      totalR: 0, // NEW: Total R-multiple accumulator
    };
  }

  /**
   * Processes the next candle: executes orders, updates open positions.
   * @param candle The current candlestick data.
   */
  processCandle(candle: CandlestickData): TradeExecution[] {
    const executions: TradeExecution[] = [];

    // 1. Execute/Cancel Pending Orders (Limit Orders)
    this.pendingOrders = this.pendingOrders.filter((order) => {
      const { price, side, orderType } = order;

      if (orderType === OrderType.LIMIT) {
        // Check for Limit Order fill (basic logic: touched by high/low)
        let isFilled = false;
        if (side === Side.BUY && candle.low <= price) {
          // Buy Limit: price is below current price, filled when price drops to limit
          isFilled = true;
        } else if (side === Side.SELL && candle.high >= price) {
          // Sell Limit: price is above current price, filled when price rises to limit
          isFilled = true;
        }

        if (isFilled) {
          // Fill the limit order at the limit price
          const execution: TradeExecution = {
            orderId: order.orderId,
            side: order.side,
            size: order.size,
            price: price, // Filled at limit price
            time: candle.time,
            orderType: OrderType.LIMIT,
            isEntry: true,
          };
          this.executeOrder(execution, candle);
          executions.push(execution);
          return false; // Remove from pending orders
        }
      }
      return true; // Keep in pending orders
    });

    // 2. Process existing positions (SL/TP)
    this.positions = this.positions.filter((pos) => {
      // Check Stop Loss (SL) and Take Profit (TP)
      let closePrice: number | null = null;
      let reason: 'SL' | 'TP' | 'MARKET' | null = null;

      if (pos.stopLoss && this.shouldExecuteSL(pos, candle)) {
        closePrice = pos.stopLoss;
        reason = 'SL';
      } else if (pos.takeProfit && this.shouldExecuteTP(pos, candle)) {
        closePrice = pos.takeProfit;
        reason = 'TP';
      }

      if (closePrice !== null) {
        const execution: TradeExecution = {
          orderId: `CLOSE-${pos.positionId}`,
          side: pos.side === Side.BUY ? Side.SELL : Side.BUY,
          size: pos.size,
          price: closePrice,
          time: candle.time,
          orderType: OrderType.MARKET, // SL/TP are executed as market orders
          isEntry: false,
        };

        this.closePosition(pos, execution, reason!);
        executions.push(execution);
        return false; // Remove position
      }

      return true; // Keep position open
    });

    return executions;
  }

  /**
   * Executes a Market Order and opens a new position.
   * @param order The market order to execute.
   * @param candle The current candle for execution price.
   */
  executeMarketOrder(order: Order, candle: CandlestickData): Position | null {
    if (order.orderType !== OrderType.MARKET) {
      console.error('Invalid order type for market execution');
      return null;
    }

    // Apply slippage to the execution price (basic implementation)
    const entryPrice = this.applySlippage(candle.close, order.side, this.slippageRate);

    const position: Position = {
      positionId: `POS-${Date.now()}-${Math.random()}`,
      symbol: order.symbol,
      side: order.side,
      size: order.size,
      entryPrice: entryPrice,
      entryTime: candle.time,
      stopLoss: order.stopLoss ?? null,
      takeProfit: order.takeProfit ?? null,
      initialRisk: order.initialRisk ?? null,
      currentPnL: 0,
      currentPnLPercent: 0,
      pips: 0,
    };

    this.positions.push(position);
    this.applyCommission(position.size, entryPrice);
    return position;
  }

  /**
   * Places a Limit Order into the pending orders queue.
   */
  placeLimitOrder(order: Order): void {
    if (order.orderType !== OrderType.LIMIT) {
      console.error('Invalid order type for limit placement');
      return;
    }
    this.pendingOrders.push({
      ...order,
      orderId: `ORDER-${Date.now()}-${Math.random()}`,
    });
  }

  /**
   * Private helper to execute an order (used by limit orders and market orders).
   */
  private executeOrder(execution: TradeExecution, candle: CandlestickData): void {
    const { side, size, price, orderType, isEntry } = execution;

    if (isEntry) {
      // OPEN NEW POSITION
      const position: Position = {
        positionId: `POS-${Date.now()}-${Math.random()}`,
        symbol: execution.symbol,
        side: side,
        size: size,
        entryPrice: price,
        entryTime: candle.time,
        stopLoss: execution.stopLoss ?? null,
        takeProfit: execution.takeProfit ?? null,
        initialRisk: execution.initialRisk ?? null,
        currentPnL: 0,
        currentPnLPercent: 0,
        pips: 0,
      };
      this.positions.push(position);
      this.applyCommission(size, price);
    }
    // Note: Closing logic is handled by closePosition below
  }

  /**
   * Closes an open position at a given execution price.
   */
  closePosition(
    position: Position,
    execution: TradeExecution,
    reason: 'SL' | 'TP' | 'MARKET'
  ): TradeResult {
    // 1. Calculate PnL
    const finalPrice = execution.price;
    const { pnl, pnlPercent, pips } = calculatePnL(
      position.side,
      position.entryPrice,
      finalPrice,
      position.size
    );

    // 2. Apply Closing Commission
    this.applyCommission(position.size, finalPrice);

    // 3. Final PnL and Balance Update
    const finalPnl = pnl - this.getCommissionCost(position.size, finalPrice);
    this.balance += finalPnl;

    // 4. Calculate R-Multiple (only if initialRisk was set, e.g., via OrderTicket)
    const rMultiple = position.initialRisk ? calculateRMultiple(finalPnl, position.initialRisk) : 0;

    const tradeResult: TradeResult = {
      positionId: position.positionId,
      symbol: position.symbol,
      side: position.side,
      entryPrice: position.entryPrice,
      exitPrice: finalPrice,
      entryTime: position.entryTime,
      exitTime: execution.time,
      size: position.size,
      pnl: finalPnl,
      pnlPercent: pnlPercent,
      rMultiple: rMultiple, // NEW R-Multiple
      reason: reason,
    };

    this.tradesHistory.push(tradeResult);

    // 5. Update Incremental Stats (CRITICAL)
    this.updateIncrementalStats(tradeResult);

    return tradeResult;
  }

  private updateIncrementalStats(trade: TradeResult): void {
    this.stats.totalTrades++;
    this.stats.totalPnl += trade.pnl;
    this.stats.totalR += trade.rMultiple;
    this.stats.maxPnl = Math.max(this.stats.maxPnl, this.stats.totalPnl);

    if (trade.pnl > 0) {
      this.stats.winningTrades++;
    } else if (trade.pnl < 0) {
      this.stats.losingTrades++;
    }

    // Update Max Drawdown (simple implementation)
    const currentDrawdown = this.stats.maxPnl - this.stats.totalPnl;
    this.stats.maxDrawdown = Math.max(this.stats.maxDrawdown, currentDrawdown);

    // Update Cumulative PnL for Equity Curve
    const lastPnl = this.stats.cumulativePnl[this.stats.cumulativePnl.length - 1];
    this.stats.cumulativePnl.push({
      time: trade.exitTime,
      value: lastPnl.value + trade.pnl,
    });

    // Recompute derived stats (Win Rate, Profit Factor, Average R)
    this.stats.winRate =
      (this.stats.winningTrades / this.stats.totalTrades) * 100;
    
    // Profit Factor calculation needs gross profit and gross loss
    // For simplicity here, we recompute from tradesHistory (still better than full recalc)
    const grossProfit = this.tradesHistory.filter(t => t.pnl > 0).reduce((sum, t) => sum + t.pnl, 0);
    const grossLoss = this.tradesHistory.filter(t => t.pnl < 0).reduce((sum, t) => sum + Math.abs(t.pnl), 0);
    this.stats.profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;

    this.stats.averageR = this.stats.totalR / this.stats.totalTrades;
  }

  // ===================================
  // HELPERS
  // ===================================

  private applySlippage(price: number, side: Side, rate: number): number {
    const slippageAmount = price * rate;
    if (side === Side.BUY) {
      return price * (1 + rate); // Buy higher
    }
    return price * (1 - rate); // Sell lower
  }

  private applyCommission(size: number, price: number): void {
    // Commission is applied on ENTRY and EXIT
    // For simplicity, we deduct it from the balance when the trade is executed/closed
    // The cost is already included in finalPnl in closePosition
  }

  private getCommissionCost(size: number, price: number): number {
    return size * price * this.commissionRate;
  }

  private shouldExecuteSL(pos: Position, candle: CandlestickData): boolean {
    if (!pos.stopLoss) return false;

    if (pos.side === Side.BUY) {
      // Long SL is hit if candle low <= SL price
      return candle.low <= pos.stopLoss;
    }
    // Short SL is hit if candle high >= SL price
    return candle.high >= pos.stopLoss;
  }

  private shouldExecuteTP(pos: Position, candle: CandlestickData): boolean {
    if (!pos.takeProfit) return false;

    if (pos.side === Side.BUY) {
      // Long TP is hit if candle high >= TP price
      return candle.high >= pos.takeProfit;
    }
    // Short TP is hit if candle low <= TP price
    return candle.low <= pos.takeProfit;
  }

  // ===================================
  // GETTERS
  // ===================================

  getPositions(): Position[] {
    return this.positions;
  }

  getPendingOrders(): Order[] {
    return this.pendingOrders;
  }

  getStats(): BacktestStats {
    // Update current PnL for open positions (non-persisted calculation)
    this.positions.forEach((pos) => {
      const { pnl, pnlPercent, pips } = calculatePnL(
        pos.side,
        pos.entryPrice,
        this.getCurrentPrice(), // Assuming there's a way to get current price (e.g., last processed candle close)
        pos.size
      );
      pos.currentPnL = pnl;
      pos.currentPnLPercent = pnlPercent;
      pos.pips = pips;
    });

    return {
      ...this.stats,
      openPositions: this.positions.length,
    };
  }

  getTradesHistory(): TradeResult[] {
    return this.tradesHistory;
  }
  
  // NOTE: This is a placeholder. In ReplayChart.tsx, the current candle's close should be passed.
  private getCurrentPrice(): number {
    // A function must be used to get the last known price from the main component
    return 0; 
  }

  reset(): void {
    this.positions = [];
    this.pendingOrders = [];
    this.tradesHistory = [];
    this.balance = this.initialBalance;
    this.stats = this.initializeStats();
  }
}