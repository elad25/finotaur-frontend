// trading/index.ts
export { PaperTradingEngine } from './PaperTradingEngine';
export { OrderTicket } from './OrderTicket';
export type { OrderTicketProps } from './OrderTicket';
export { BacktestPanel } from './BacktestPanel';
export type { BacktestPanelProps } from './BacktestPanel';

// ✅ PositionsPanel is in ui/, not here!
// Import it from ui when needed: import { PositionsPanel } from '../ui';