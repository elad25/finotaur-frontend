// types/index.ts - COMPLETE & FINAL VERSION
// ============================================================================
// UNIFIED TYPE DEFINITIONS FOR FINOTAUR REPLAY CHART & BACKTEST ENGINE
// ============================================================================

import { 
  Time, 
  UTCTimestamp,
  CandlestickData as LWCandlestickData,
  IChartApi,
  ISeriesApi,
  MouseEventParams,
} from 'lightweight-charts';

// ============================================================================
// ✅ EXTENDED CANDLESTICK DATA (FIX FOR VOLUME)
// ============================================================================

/**
 * Extended CandlestickData with volume support
 * Fixes TypeScript error: Property 'volume' does not exist
 */
export interface CandlestickData extends LWCandlestickData<Time> {
  volume?: number;
}

/**
 * Standard candle format (alias for backward compatibility)
 */
export interface Candle {
  time: number | UTCTimestamp;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

// ============================================================================
// CHART DATA TYPES
// ============================================================================

/**
 * Timeframe value - string representation
 */
export type Timeframe = 
  | '1m' | '3m' | '5m' | '15m' | '30m' 
  | '1h' | '2h' | '4h' 
  | '1d' | '1w' | '1M';

/**
 * Timeframe configuration object - UNIFIED VERSION
 * ✅ This is the SINGLE SOURCE OF TRUTH for timeframe objects
 */
export interface TimeframeConfig {
  value: Timeframe;
  label: string;
  seconds: number;
  minutes: number;
  limit: number;
  binanceInterval?: string;
}

/**
 * Optimized candle buffer for high-performance scenarios
 */
export interface CandleBuffer {
  symbol: string;
  timeframe: Timeframe;
  data: Float64Array; // [time, open, high, low, close, volume] repeated
  count: number;
  lastUpdate: number;
}

// ============================================================================
// SYMBOL TYPES
// ============================================================================

export type SymbolCategory = 'Crypto' | 'Stocks' | 'Forex' | 'Futures';

export interface Symbol {
  symbol: string;
  name: string;
  category: SymbolCategory;
  baseAsset?: string;
  quoteAsset?: string;
  exchange?: string;
  logo?: string;
}

export interface SymbolMeta {
  symbol: string;
  displayName: string;
  name: string;
  category: SymbolCategory;
  exchange: string;
  precision?: number;
  minPrice?: number;
  maxPrice?: number;
  tickSize?: number;
  minQty?: number;
  maxQty?: number;
  lotSize?: number;
}

// ============================================================================
// THEME & CHART TYPES
// ============================================================================

export type Theme = 'light' | 'dark';
export type CandleStyle = 'candles' | 'hollow' | 'bars' | 'line' | 'area' | 'heikin-ashi';

export interface ChartOptions {
  theme: Theme;
  width?: number;
  height?: number;
  autoSize?: boolean;
}

export interface ChartSettings {
  theme: Theme;
  showGrid: boolean;
  showCrosshair: boolean;
  showVolume: boolean;
  showWatermark: boolean;
  candleStyle: CandleStyle;
  showSessionBreaks: boolean;
  showCountdown: boolean;
  timezone: string;
  locale: string;
}

export interface ChartConfig {
  symbol: string;
  interval: Timeframe;
  container: string;
  theme: Theme;
  locale: string;
  timezone: string;
  autosize: boolean;
  disabled_features?: string[];
  enabled_features?: string[];
  overrides?: Record<string, any>;
  studies_overrides?: Record<string, any>;
  custom_css_url?: string;
}

// ============================================================================
// REPLAY TYPES
// ============================================================================

export type ReplayMode = 'live' | 'replay';
export type ReplaySpeed = 0.25 | 0.5 | 1 | 2 | 4 | 8 | 10;
export type PlaybackSpeed = ReplaySpeed; // Alias

export interface ReplayState {
  mode: ReplayMode;
  startIndex: number;
  endIndex: number;
  currentIndex: number | null;
  isPlaying: boolean;
  speed: ReplaySpeed;
  autoScroll: boolean;
}

// ============================================================================
// TRADING TYPES
// ============================================================================

export type TradeDirection = 'long' | 'short';
export type PositionSide = TradeDirection;
export type TradeStatus = 'open' | 'closed' | 'cancelled';
export type OrderType = 'market' | 'limit' | 'stop' | 'stop-limit';
export type OrderStatus = 'pending' | 'filled' | 'cancelled' | 'rejected';
export type ExitReason = 'manual' | 'stop_loss' | 'take_profit' | 'liquidation' | 'timeout';

/**
 * Complete position structure
 */
export interface Position {
  // Identification
  id: string;
  symbol: string;
  
  // Direction & Entry
  side: TradeDirection;
  type: TradeDirection; // Alias for backward compatibility
  entryPrice: number;
  entryTime: number | UTCTimestamp;
  size: number;
  
  // Exit
  exitPrice?: number;
  exitTime?: number | UTCTimestamp;
  exitReason?: ExitReason;
  
  // Risk Management
  stopLoss?: number;
  takeProfit?: number;
  trailingStop?: number;
  
  // Status
  status: TradeStatus;
  isClosed: boolean;
  
  // P&L
  realizedPnL?: number;
  realizedPnl?: number; // Alias
  unrealizedPnL?: number;
  unrealizedPnl?: number; // Alias
  realizedPnlPercent?: number;
  unrealizedPnlPercent?: number;
  
  // Risk metrics
  riskAmount?: number;
  rewardAmount?: number;
  riskRewardRatio?: number;
  rMultiple?: number;
  
  // Costs
  commission?: number;
  slippage?: number;
  fees?: number;
  
  // Metadata
  notes?: string;
  tags?: string[];
  strategyId?: string;
  strategyName?: string;
  sessionId?: string;
  screenshotUrl?: string;
  chartSnapshotUrl?: string;
  
  // Timestamps
  createdAt?: number;
  updatedAt?: number;
}

/**
 * Order structure
 */
export interface Order {
  id: string;
  positionId?: string;
  symbol: string;
  side: TradeDirection;
  type: OrderType;
  status: OrderStatus;
  
  // Pricing
  size: number;
  price?: number;
  stopPrice?: number;
  limitPrice?: number;
  
  // Execution
  filled: boolean;
  filledPrice?: number;
  filledSize?: number;
  filledTime?: number | UTCTimestamp;
  
  // Timestamps
  createdAt: number | UTCTimestamp;
  timestamp: number | UTCTimestamp;
  expiresAt?: number;
  
  // Metadata
  clientOrderId?: string;
  notes?: string;
}

/**
 * Order draft for UI
 */
export interface PositionDraft {
  side: TradeDirection;
  size: number;
  orderType: OrderType;
  limitPrice?: number;
  stopPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  trailingStop?: number;
  notes?: string;
  tags?: string[];
}

// ============================================================================
// BACKTEST STATE TYPES
// ============================================================================

export interface BacktestState {
  // Configuration
  symbol: string;
  timeframe: Timeframe;
  startDate: number;
  endDate: number;
  initialBalance: number;
  
  // Playback
  isPlaying: boolean;
  speed: PlaybackSpeed;
  currentIndex: number;
  totalCandles: number;
  mode: ReplayMode;
  
  // Data
  candles: Candle[];
  visibleCandles: Candle[];
  
  // Positions & Orders
  activePosition?: Position;
  openPositions: Position[];
  closedPositions: Position[];
  orders: Order[];
  
  // Account
  balance: number;
  equity: number;
  margin: number;
  marginLevel: number;
  availableBalance: number;
  
  // Statistics
  statistics: BacktestStatistics;
  
  // UI State
  showBacktestPanel: boolean;
  showStatistics: boolean;
  autoScroll: boolean;
}

// ============================================================================
// STATISTICS TYPES
// ============================================================================

export interface BacktestStatistics {
  // Basic metrics
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  breakEvenTrades: number;
  
  // Win rate
  winRate: number;
  lossRate: number;
  
  // P&L
  totalPnl: number;
  totalPnlPercent: number;
  grossProfit: number;
  grossLoss: number;
  netProfit: number;
  netProfitPercent: number;
  
  // Average metrics
  avgWin: number;
  avgWinPercent: number;
  avgLoss: number;
  avgLossPercent: number;
  avgRR: number;
  avgTradeDuration: number;
  avgBarsInTrade: number;
  
  // Advanced metrics
  profitFactor: number;
  expectancy: number;
  expectancyPercent: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  
  // Drawdown
  maxDrawdown: number;
  maxDrawdownPercent: number;
  maxDrawdownDuration: number;
  currentDrawdown: number;
  currentDrawdownPercent: number;
  recoveryFactor: number;
  
  // Consecutive
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  currentStreak: number;
  currentStreakType: 'win' | 'loss' | 'none';
  
  // Risk metrics
  largestWin: number;
  largestWinPercent: number;
  largestLoss: number;
  largestLossPercent: number;
  avgRiskAmount: number;
  totalRiskTaken: number;
  
  // Time-based
  tradingDays: number;
  avgTradesPerDay: number;
  firstTradeDate?: number;
  lastTradeDate?: number;
  totalTradingTime: number;
  
  // Equity curve
  equityCurve: EquityPoint[];
  drawdownCurve: DrawdownPoint[];
  
  // R-Multiple Distribution
  rMultipleDistribution?: {
    '< -2R': number;
    '-2R to -1R': number;
    '-1R to 0R': number;
    '0R to 1R': number;
    '1R to 2R': number;
    '2R to 3R': number;
    '> 3R': number;
  };
}

export interface EquityPoint {
  time: number;
  balance: number;
  equity: number;
  drawdown: number;
  drawdownPercent: number;
}

export interface DrawdownPoint {
  time: number;
  drawdown: number;
  drawdownPercent: number;
  inDrawdown: boolean;
  peakBalance: number;
}

// ============================================================================
// ✅ DRAWING TYPES (COMPLETE WITH ALL TOOLS)
// ============================================================================

export type DrawingTool = 
  | 'cursor' 
  | 'cross' 
  | 'trendline' 
  | 'horizontal' 
  | 'vertical'
  | 'ray' 
  | 'extended'
  | 'rectangle' 
  | 'circle' 
  | 'ellipse'
  | 'triangle'
  | 'text' 
  | 'note'
  | 'brush'
  | 'measure'
  | 'fibonacci'
  | 'fibonacci-extension'
  | 'pitchfork'
  | 'gann-fan'
  | 'arrow';

export type DrawingType = DrawingTool; // Alias

export interface Point {
  time: Time;
  price: number;
}

export interface DrawingPoint {
  time: number;
  price: number;
}

export interface DrawingStyle {
  color: string;
  lineWidth: number;
  lineStyle: 'solid' | 'dashed' | 'dotted';
  fillColor?: string;
  fillOpacity?: number;
  text?: string;
  fontSize?: number;
  backgroundColor?: string;
  borderColor?: string;
}

export interface Drawing {
  id: string;
  type: DrawingType;
  points: DrawingPoint[];
  style: DrawingStyle;
  visible: boolean;
  locked: boolean;
  selected?: boolean;
  
  // Text properties
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: 'normal' | 'bold';
  textAlign?: 'left' | 'center' | 'right';
  
  // Layer & ordering
  layer?: number;
  zIndex?: number;
  
  // Metadata
  createdAt: number;
  updatedAt: number;
  author?: string;
  symbol?: string;
  
  // Fibonacci specific
  levels?: number[];
  showLabels?: boolean;
  extendLeft?: boolean;
  extendRight?: boolean;
}

// ============================================================================
// INDICATOR TYPES
// ============================================================================

export interface IndicatorSettings {
  // Moving Averages
  sma?: { length: number; color: string; lineWidth?: number };
  ema?: { length: number; color: string; lineWidth?: number };
  wma?: { length: number; color: string };
  vwma?: { length: number; color: string };
  
  // Momentum
  rsi?: { length: number; overbought: number; oversold: number; color?: string };
  macd?: { fast: number; slow: number; signal: number };
  stochastic?: { kPeriod: number; dPeriod: number; smooth: number };
  
  // Volatility
  bollinger?: { length: number; stdDev: number; color?: string };
  atr?: { length: number; color?: string };
  keltner?: { length: number; multiplier: number };
  
  // Volume
  volume?: { color: string; upColor?: string; downColor?: string };
  obv?: { color: string };
  
  // Trend
  supertrend?: { atrPeriod: number; multiplier: number };
  ichimoku?: { 
    conversionPeriod: number; 
    basePeriod: number; 
    spanBPeriod: number; 
    displacement: number;
  };
  
  // Support/Resistance
  pivotPoints?: { type: 'standard' | 'fibonacci' | 'camarilla' };
}

export interface IndicatorValue {
  time: Time;
  value: number;
  color?: string;
}

export interface IndicatorData {
  id: string;
  name: string;
  type: string;
  values: IndicatorValue[];
  settings: any;
}

// ============================================================================
// UI TYPES
// ============================================================================

export interface OHLC {
  open: number;
  high: number;
  low: number;
  close: number;
  change?: number;
  changePercent?: number;
  time?: number;
  volume?: number;
}

export interface CrosshairData {
  time: Time | null;
  price: number | null;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
}

export interface ChartMarker {
  id: string;
  time: number | UTCTimestamp;
  position: 'aboveBar' | 'belowBar' | 'inBar';
  color: string;
  shape: 'circle' | 'square' | 'arrowUp' | 'arrowDown' | 'flag' | 'text';
  text?: string;
  size?: 'auto' | 'tiny' | 'small' | 'normal' | 'large' | 'huge';
  tooltip?: string;
}

export interface ChartLine {
  id: string;
  price: number;
  color: string;
  width: number;
  style: 'solid' | 'dashed' | 'dotted';
  title?: string;
  axisLabelVisible?: boolean;
  editable?: boolean;
  showLabel?: boolean;
}

export interface ChartShape {
  id: string;
  time: number;
  price: number;
  type: 'arrow' | 'circle' | 'rectangle' | 'text' | 'icon';
  text?: string;
  color?: string;
  size?: number;
  icon?: string;
}

// ============================================================================
// EVENT TYPES
// ============================================================================

export interface ChartClickEvent {
  time: number;
  price: number;
  x: number;
  y: number;
  seriesData?: any;
}

export interface CrosshairMoveEvent {
  time: number | null;
  price: number | null;
  seriesData: any;
  point?: { x: number; y: number };
}

export interface TradeEvent {
  type: 'POSITION_OPENED' | 'POSITION_CLOSED' | 'SL_HIT' | 'TP_HIT' | 'ORDER_FILLED' | 'ORDER_CANCELLED';
  timestamp: number;
  position?: Position;
  order?: Order;
  candle?: Candle;
  reason?: string;
}

export interface PlaybackEvent {
  type: 'CANDLE_UPDATE' | 'PLAYBACK_STARTED' | 'PLAYBACK_STOPPED' | 'PLAYBACK_ENDED' | 'PLAYBACK_PAUSED';
  timestamp: number;
  currentIndex: number;
  candle?: Candle;
  speed?: PlaybackSpeed;
}

// ============================================================================
// PERFORMANCE TYPES - ✅ FIXED
// ============================================================================

export interface PerformanceMetrics {
  fps: number;
  renderTime: number;
  memoryUsage: number;
  dataPoints: number;
  warnings?: string[]; // ✅ ADDED
  timestamp?: number;  // ✅ ADDED
}

export interface PerformanceBudget {
  renderMs: number;
  eventMs: number;
  dataProcessingMs: number;
  maxMemoryMB: number;
}

// ============================================================================
// CACHE TYPES
// ============================================================================

export interface CacheEntry<T = any> {
  key: string;
  data: T;
  timestamp: number;
  expiry: number;
  size: number;
  hits?: number;
}

export interface CacheStats {
  totalEntries: number;
  totalMemoryMB: number;
  hitRate: number;
  missRate: number;
  oldestEntry?: number;
  newestEntry?: number;
}

export interface IndexedDBSchema {
  candles: {
    key: string;
    value: Candle;
    indexes: {
      symbol: string;
      timeframe: string;
      timestamp: number;
    };
  };
  candleBuffers: {
    key: string;
    value: CandleBuffer;
    indexes: {
      symbol: string;
      timeframe: string;
      lastUpdate: number;
    };
  };
  positions: {
    key: string;
    value: Position;
    indexes: {
      symbol: string;
      status: TradeStatus;
      sessionId: string;
      entryTime: number;
    };
  };
  drawings: {
    key: string;
    value: Drawing;
    indexes: {
      symbol: string;
      type: DrawingType;
      createdAt: number;
    };
  };
  metadata: {
    key: string;
    value: any;
  };
}

// ============================================================================
// WORKER MESSAGE TYPES
// ============================================================================

export type WorkerMessageType =
  | 'INIT'
  | 'START_PLAYBACK'
  | 'STOP_PLAYBACK'
  | 'PAUSE_PLAYBACK'
  | 'SET_SPEED'
  | 'STEP_FORWARD'
  | 'STEP_BACKWARD'
  | 'JUMP_TO'
  | 'UPDATE_POSITION'
  | 'CALCULATE_STATS'
  | 'CALCULATE_INDICATORS'
  | 'PROCESS_CANDLES'
  | 'STATE_UPDATE'
  | 'ERROR';

export interface WorkerMessage {
  type: WorkerMessageType;
  payload?: any;
  id?: string;
  timestamp?: number;
}

export interface WorkerResponse {
  type: WorkerMessageType;
  payload: any;
  id?: string;
  timestamp: number;
  error?: string;
}

// ============================================================================
// API TYPES
// ============================================================================

// Binance
export type BinanceKline = [
  number,  // Open time
  string,  // Open
  string,  // High
  string,  // Low
  string,  // Close
  string,  // Volume
  number,  // Close time
  string,  // Quote asset volume
  number,  // Number of trades
  string,  // Taker buy base asset volume
  string,  // Taker buy quote asset volume
  string   // Ignore
];

export interface BinanceTickerResponse {
  symbol: string;
  priceChange: string;
  priceChangePercent: string;
  lastPrice: string;
  volume: string;
  quoteVolume: string;
  openTime: number;
  closeTime: number;
  firstId: number;
  lastId: number;
  count: number;
}

// Polygon.io
export interface PolygonCandle {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
  vw?: number;
  n?: number;
}

export interface PolygonResponse {
  ticker: string;
  status: string;
  queryCount: number;
  resultsCount: number;
  adjusted: boolean;
  results: PolygonCandle[];
  next_url?: string;
}

// ============================================================================
// CONFIGURATION TYPES
// ============================================================================

export interface BacktestConfig {
  symbol: string;
  timeframe: Timeframe;
  initialBalance: number;
  leverage: number;
  commissionRate: number;
  slippageRate: number;
  compoundProfits: boolean;
  maxPositionSize: number;
  maxDrawdown: number;
  maxDailyLoss?: number;
  maxPositions?: number;
  dateRange: {
    from: number;
    to: number;
  };
  riskManagement?: {
    maxRiskPerTrade: number;
    maxRiskTotal: number;
    useTrailingStop: boolean;
  };
}

export interface DataSourceConfig {
  provider: 'binance' | 'polygon' | 'alphaVantage' | 'custom';
  apiKey?: string;
  apiSecret?: string;
  baseUrl?: string;
  rateLimit?: number;
  cacheDuration?: number;
  timeout?: number;
}

// ============================================================================
// STORE TYPES (Zustand)
// ============================================================================

export interface BacktestStore extends BacktestState {
  // Actions - Playback
  startPlayback: () => void;
  stopPlayback: () => void;
  pausePlayback: () => void;
  setSpeed: (speed: PlaybackSpeed) => void;
  stepForward: () => void;
  stepBackward: () => void;
  jumpToCandle: (index: number) => void;
  toggleMode: () => void;
  
  // Actions - Trading
  openPosition: (params: PositionDraft) => void;
  closePosition: (positionId: string, reason?: Position['exitReason']) => void;
  closeAllPositions: (reason?: Position['exitReason']) => void;
  updateStopLoss: (positionId: string, price: number) => void;
  updateTakeProfit: (positionId: string, price: number) => void;
  updatePosition: (positionId: string, updates: Partial<Position>) => void;
  
  // Actions - Orders
  placeOrder: (order: Omit<Order, 'id' | 'timestamp' | 'filled'>) => void;
  cancelOrder: (orderId: string) => void;
  
  // Actions - Data
  loadCandles: (symbol: string, timeframe: Timeframe, from: number, to: number) => Promise<void>;
  setSymbol: (symbol: string) => void;
  setTimeframe: (timeframe: Timeframe) => void;
  refreshData: () => Promise<void>;
  
  // Actions - Stats
  calculateStatistics: () => void;
  resetBacktest: () => void;
  resetStatistics: () => void;
  
  // Actions - UI
  toggleBacktestPanel: () => void;
  toggleStatistics: () => void;
  setAutoScroll: (enabled: boolean) => void;
  
  // Actions - Journal
  saveToJournal: (position: Position) => Promise<void>;
  exportTrades: (format: 'csv' | 'json') => Promise<string>;
}

// ============================================================================
// ERROR TYPES
// ============================================================================

export class ChartError extends Error {
  constructor(
    message: string,
    public code: string,
    public context?: any
  ) {
    super(message);
    this.name = 'ChartError';
  }
}

export class BacktestError extends Error {
  constructor(
    message: string,
    public code: ErrorCode,
    public details?: any
  ) {
    super(message);
    this.name = 'BacktestError';
  }
}

export type ErrorCode =
  | 'INVALID_POSITION'
  | 'INSUFFICIENT_BALANCE'
  | 'INVALID_PRICE'
  | 'INVALID_SIZE'
  | 'POSITION_NOT_FOUND'
  | 'ORDER_NOT_FOUND'
  | 'DATA_LOAD_FAILED'
  | 'CHART_INIT_FAILED'
  | 'WORKER_ERROR'
  | 'CACHE_ERROR'
  | 'API_ERROR'
  | 'NETWORK_ERROR'
  | 'TIMEOUT_ERROR'
  | 'VALIDATION_ERROR'
  | 'RATE_LIMIT_ERROR';

// ============================================================================
// KEYBOARD SHORTCUTS
// ============================================================================

export interface KeyboardShortcut {
  key: string;
  ctrlKey?: boolean;
  shiftKey?: boolean;
  altKey?: boolean;
  metaKey?: boolean;
  action: string;
  description: string;
}

export type KeyboardShortcutMap = Record<string, KeyboardShortcut>;

// ============================================================================
// UTILITY TYPES
// ============================================================================

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

export type OptionalFields<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type Nullable<T> = T | null;

export type Optional<T> = T | undefined;

// ============================================================================
// EXPORTS FROM LIGHTWEIGHT-CHARTS
// ============================================================================

export type {
  Time,
  UTCTimestamp,
  IChartApi,
  ISeriesApi,
  MouseEventParams,
  LWCandlestickData,
};