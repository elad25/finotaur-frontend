// core/ChartRenderer.ts - WITH DEBUG LOGS
import { IChartApi, ISeriesApi, CandlestickData } from 'lightweight-charts';
import { rafBatchRenderer } from '../utils/performance';

/**
 * ===================================
 * CHART RENDERER - WITH DEBUG
 * Optimized rendering engine with debugging
 * ===================================
 */
export class ChartRenderer {
  private chart: IChartApi;
  private candlestickSeries: ISeriesApi<'Candlestick'>;
  private indicatorSeries: Map<string, ISeriesApi<any>> = new Map();
  private isDestroyed = false;

  constructor(chart: IChartApi, candlestickSeries: ISeriesApi<'Candlestick'>) {
    this.chart = chart;
    this.candlestickSeries = candlestickSeries;
    console.log('🎨 ChartRenderer initialized');
  }

  // ===================================
  // DATA UPDATES
  // ===================================

  /**
   * Update candlestick data (batched) - WITH DEBUG
   */
  setData(data: CandlestickData[]): void {
    if (this.isDestroyed) {
      console.warn('⚠️ ChartRenderer is destroyed, cannot set data');
      return;
    }

    console.log(`🎨 ChartRenderer.setData: ${data.length} candles`);

    if (data.length === 0) {
      console.warn('⚠️ Attempting to set empty data array');
      return;
    }

    // Log first and last candle for debugging
    console.log('📊 First candle:', data[0]);
    console.log('📊 Last candle:', data[data.length - 1]);

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        try {
          this.candlestickSeries.setData(data);
          console.log('✅ Data set successfully');
          
          // Auto-fit content
          this.chart.timeScale().fitContent();
        } catch (error) {
          console.error('❌ Failed to set data:', error);
        }
      }
    });
  }

  /**
   * Update single candle (batched)
   */
  updateCandle(candle: CandlestickData): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.candlestickSeries.update(candle);
      }
    });
  }

  /**
   * Update multiple candles at once
   */
  updateCandles(candles: CandlestickData[]): void {
    if (this.isDestroyed || candles.length === 0) return;

    console.log(`🔄 Updating ${candles.length} candles`);

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        // Set all data at once for better performance
        this.candlestickSeries.setData(candles);
      }
    });
  }

  // ===================================
  // INDICATOR SERIES
  // ===================================

  addIndicatorSeries(
    id: string,
    type: 'Line' | 'Histogram' | 'Area',
    options?: any
  ): ISeriesApi<any> {
    if (this.indicatorSeries.has(id)) {
      return this.indicatorSeries.get(id)!;
    }

    let series: ISeriesApi<any>;

    switch (type) {
      case 'Line':
        series = this.chart.addLineSeries(options);
        break;
      case 'Histogram':
        series = this.chart.addHistogramSeries(options);
        break;
      case 'Area':
        series = this.chart.addAreaSeries(options);
        break;
      default:
        series = this.chart.addLineSeries(options);
    }

    this.indicatorSeries.set(id, series);
    return series;
  }

  removeIndicatorSeries(id: string): void {
    const series = this.indicatorSeries.get(id);
    if (series) {
      this.chart.removeSeries(series);
      this.indicatorSeries.delete(id);
    }
  }

  updateIndicatorData(id: string, data: any[]): void {
    const series = this.indicatorSeries.get(id);
    if (series && !this.isDestroyed) {
      rafBatchRenderer.schedule(() => {
        if (!this.isDestroyed && series) {
          series.setData(data);
        }
      });
    }
  }

  clearIndicators(): void {
    this.indicatorSeries.forEach(series => {
      this.chart.removeSeries(series);
    });
    this.indicatorSeries.clear();
  }

  // ===================================
  // MARKERS
  // ===================================

  setMarkers(markers: any[]): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.candlestickSeries.setMarkers(markers);
      }
    });
  }

  clearMarkers(): void {
    this.setMarkers([]);
  }

  // ===================================
  // PRICE LINES
  // ===================================

  createPriceLine(options: any): any {
    return this.candlestickSeries.createPriceLine(options);
  }

  removePriceLine(line: any): void {
    this.candlestickSeries.removePriceLine(line);
  }

  // ===================================
  // VIEWPORT
  // ===================================

  fitContent(): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.chart.timeScale().fitContent();
        console.log('📐 Fitted content to viewport');
      }
    });
  }

  setVisibleRange(from: number, to: number): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.chart.timeScale().setVisibleLogicalRange({ from, to });
      }
    });
  }

  scrollToPosition(position: number, animated: boolean = true): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.chart.timeScale().scrollToPosition(position, animated);
      }
    });
  }

  scrollToRealtime(): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.chart.timeScale().scrollToRealTime();
      }
    });
  }

  // ===================================
  // SCALE
  // ===================================

  resetPriceScale(): void {
    if (this.isDestroyed) return;

    rafBatchRenderer.schedule(() => {
      if (!this.isDestroyed) {
        this.chart.priceScale('right').applyOptions({
          autoScale: true,
        });
      }
    });
  }

  // ===================================
  // GETTERS
  // ===================================

  getChart(): IChartApi {
    return this.chart;
  }

  getCandlestickSeries(): ISeriesApi<'Candlestick'> {
    return this.candlestickSeries;
  }

  getIndicatorSeries(id: string): ISeriesApi<any> | undefined {
    return this.indicatorSeries.get(id);
  }

  getAllIndicatorSeries(): Map<string, ISeriesApi<any>> {
    return new Map(this.indicatorSeries);
  }

  // ===================================
  // LIFECYCLE
  // ===================================

  destroy(): void {
    console.log('🗑️ Destroying ChartRenderer');
    this.isDestroyed = true;
    this.clearIndicators();
    rafBatchRenderer.clear();
  }
}