// data/index.ts
export { DataFetcher } from './DataFetcher';
export { DataManager, dataManager } from './DataManager';