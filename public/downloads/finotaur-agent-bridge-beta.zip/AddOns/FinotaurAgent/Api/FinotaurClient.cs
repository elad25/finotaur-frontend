// =============================================================================
// Finotaur Agent — Api/FinotaurClient.cs
//
// Thin async HTTP wrapper around the two FINOTAUR automation endpoints.
// All methods are fail-safe: on any network or parse error, they return null
// (or false). The caller MUST treat null as "no-op this cycle."
//
// COMPLIANCE NOTE:
//   This class makes HTTPS calls ONLY to FINOTAUR's Supabase edge functions.
//   It NEVER calls Tradovate, NinjaTrader Cloud, any broker REST/WS API,
//   or any third party. All trade execution happens locally via the NT8 SDK.
//
// SECURITY NOTE:
//   The device_token is an opaque bearer token for this specific agent device.
//   It is NEVER logged, never stored in plaintext (TokenStore uses DPAPI),
//   and never embedded in log lines. If you need to debug auth failures,
//   check the pairing status in the web UI — do not print the token.
// =============================================================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;                           // VERIFY: bundled with NT8
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api
{
    /// <summary>
    /// HTTP client for the FINOTAUR automation Supabase edge functions.
    /// Thread-safe; HttpClient instance is reused (best practice).
    /// </summary>
    public class FinotaurClient : IDisposable
    {
        // -----------------------------------------------------------------------
        // Constants — edit the base URL here if your Supabase project changes.
        // The anon/publishable key is OPTIONAL. The edge function may work without
        // it if the Supabase gateway allows bearer-only auth. If you get 401s,
        // fill in your project's anon key (it is safe to embed — it is the public
        // row-level-security key, not the service-role secret).
        // NEVER embed the service_role/secret key here or anywhere in this addon.
        // -----------------------------------------------------------------------

        public const string DefaultBaseUrl =
            "https://xsgbtptkueabylkxibly.supabase.co/functions/v1";

        /// <summary>
        /// Leave empty if the Supabase gateway allows device-token-only auth.
        /// Replace with your project's anon/publishable key if you receive 401s
        /// on unauthenticated calls to the pairing endpoint.
        /// This value is intentionally a placeholder — it is safe to set it to
        /// the anon key (NOT the service_role key) in production.
        /// </summary>
        private const string AnonKeyPlaceholder = ""; // FILL WITH sb_publishable_* if needed

        // -----------------------------------------------------------------------
        // Internal state
        // -----------------------------------------------------------------------

        private readonly HttpClient  _http;
        private readonly string      _baseUrl;
        private          string      _deviceToken; // kept in memory only, never logged
        private readonly TimeSpan    _timeout;
        private          bool        _disposed;

        // -----------------------------------------------------------------------
        // Constructor
        // -----------------------------------------------------------------------

        /// <param name="baseUrl">Base URL, defaults to DefaultBaseUrl.</param>
        /// <param name="timeoutSeconds">Per-request HTTP timeout. Default 10 s.</param>
        public FinotaurClient(string baseUrl = null, int timeoutSeconds = 10)
        {
            _baseUrl = (baseUrl ?? DefaultBaseUrl).TrimEnd('/');
            _timeout = TimeSpan.FromSeconds(timeoutSeconds);

            _http = new HttpClient
            {
                Timeout = _timeout
            };

            // Common headers applied to every request
            _http.DefaultRequestHeaders.Accept
                .Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        // -----------------------------------------------------------------------
        // Token management (called by FinotaurAgent after TokenStore.Load)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Sets the device token used for authenticated requests.
        /// Call this on startup (from TokenStore.Load) and after a successful pair.
        /// The token is held only in memory; this class never persists it.
        /// </summary>
        public void SetDeviceToken(string token)
        {
            _deviceToken = token; // kept in memory; never logged
        }

        /// <summary>Returns true if a non-empty device token has been set.</summary>
        public bool IsPaired => !string.IsNullOrWhiteSpace(_deviceToken);

        // -----------------------------------------------------------------------
        // 1. PairAsync — POST /automation-pair
        // -----------------------------------------------------------------------

        /// <summary>
        /// Sends the pairing code to the server to register this NT8 installation
        /// as a trusted agent device.
        /// </summary>
        /// <param name="pairingCode">6–8 character code shown in the web UI.</param>
        /// <param name="deviceName">Human-readable name for this machine.</param>
        /// <param name="agentVersion">Semantic version string, e.g. "1.0.0".</param>
        /// <returns>PairingResponse with device_token and device_id, or null on failure.</returns>
        public async Task<PairingResponse> PairAsync(
            string pairingCode,
            string deviceName,
            string agentVersion,
            CancellationToken ct = default)
        {
            var body = new
            {
                pairing_code  = pairingCode,
                device_name   = deviceName,
                agent_version = agentVersion
            };

            try
            {
                var request = BuildRequest(
                    HttpMethod.Post,
                    $"{_baseUrl}/automation-pair",
                    body,
                    authenticated: false);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);
                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    Log($"PairAsync failed HTTP {(int)response.StatusCode}. " +
                        $"Check the pairing code and that your Finotaur account has automation access.");
                    return null;
                }

                var result = JsonConvert.DeserializeObject<PairingResponse>(json);
                if (!string.IsNullOrEmpty(result?.Error))
                {
                    Log($"PairAsync server error: {result.Error}");
                    return null;
                }

                return result;
            }
            catch (TaskCanceledException)
            {
                Log("PairAsync timed out — check network connectivity.");
                return null;
            }
            catch (Exception ex)
            {
                Log($"PairAsync exception: {ex.GetType().Name} — {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // 2. GetConfigAsync — POST /automation-agent {action:'config'}
        //
        // CONFIG VERSIONING (scale requirement #4):
        //   Pass the caller's lastSeenConfigVersion so the server can return a
        //   cheap Shape-A ("unchanged") response when nothing changed, instead of
        //   re-serializing the full config payload every poll cycle.
        //
        //   Shape A: { "unchanged":true, "config_version":"...",
        //              "master_enabled":bool, "kill_switch_engaged":bool, "served_at":"..." }
        //     → Caller MUST apply master_enabled + kill_switch_engaged but must NOT
        //       rebuild its local config (settings/rules/routes are absent).
        //
        //   Shape B: { "unchanged":false, "config_version":"...", "settings":{...}, ... }
        //     → Caller rebuilds its local config in full.
        //
        //   Both shapes are deserialized into the same AutomationConfig class.
        //   The caller distinguishes them via AutomationConfig.Unchanged.
        // -----------------------------------------------------------------------

        /// <summary>
        /// Fetches the current automation config (settings, risk rules, routes,
        /// connections) from the FINOTAUR server.
        ///
        /// Pass <paramref name="lastSeenConfigVersion"/> so the server can return a
        /// cheap "unchanged" response when nothing has changed since last poll.
        /// On the very first poll, pass null — the server always returns a full response.
        /// </summary>
        /// <param name="lastSeenConfigVersion">
        /// The config_version from the last successful config response.
        /// Null or empty on first call. Never log this value (treat as opaque).
        /// </param>
        /// <returns>
        /// AutomationConfig (check .Unchanged to decide whether to rebuild local state),
        /// or null on any failure (caller must no-op this cycle).
        /// </returns>
        public async Task<AutomationConfig> GetConfigAsync(
            string lastSeenConfigVersion = null,
            CancellationToken ct = default)
        {
            if (!IsPaired)
            {
                Log("GetConfigAsync skipped — not paired yet.");
                return null;
            }

            // Send the last-seen version so the server can short-circuit if nothing changed.
            // config_version is null on the first poll — server always returns Shape B then.
            var body = new
            {
                action         = "config",
                config_version = lastSeenConfigVersion  // null on first poll is fine (JSON null)
            };

            try
            {
                var request = BuildRequest(
                    HttpMethod.Post,
                    $"{_baseUrl}/automation-agent",
                    body,
                    authenticated: true);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);
                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    Log($"GetConfigAsync failed HTTP {(int)response.StatusCode}.");
                    return null;
                }

                AutomationConfig result = JsonConvert.DeserializeObject<AutomationConfig>(json);

                // Defensive guard: if the server returned something but config_version
                // is missing, treat it as a full config (safe assumption — rebuild).
                // This makes the versioning opt-in: old server versions without the field
                // behave exactly as before (Unchanged defaults to false).
                if (result != null && result.Unchanged)
                {
                    // Shape A: master_enabled / kill_switch_engaged are populated.
                    // Log for diagnostics; the caller will skip the config rebuild.
                    Log($"GetConfigAsync: config unchanged (version={result.ConfigVersion}). " +
                        "Applying safety flags only.");
                }

                return result;
            }
            catch (TaskCanceledException)
            {
                Log("GetConfigAsync timed out.");
                return null;
            }
            catch (Exception ex)
            {
                Log($"GetConfigAsync exception: {ex.GetType().Name} — {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // 3. HeartbeatAsync — POST /automation-agent {action:'heartbeat'}
        // -----------------------------------------------------------------------

        /// <summary>
        /// Sends a heartbeat so the web dashboard knows the agent is alive.
        /// Called on every poll cycle regardless of master_enabled/kill_switch state.
        /// </summary>
        /// <param name="status">"online" | "offline" | "error"</param>
        /// <param name="agentVersion">Semantic version string.</param>
        /// <param name="bridgePort">
        /// The market-data bridge's currently-bound loopback port, or null if the
        /// bridge is not running. Purely informational for the web dashboard.
        /// </param>
        /// <param name="bridgeClientCount">Number of currently-authenticated bridge WebSocket clients.</param>
        public async Task<bool> HeartbeatAsync(
            string status,
            string agentVersion,
            int? bridgePort = null,
            int bridgeClientCount = 0,
            CancellationToken ct = default)
        {
            if (!IsPaired) return false;

            var body = new
            {
                action         = "heartbeat",
                status         = status,
                agent_version  = agentVersion,
                bridge_port    = bridgePort,
                bridge_clients = bridgeClientCount
            };

            try
            {
                var request = BuildRequest(
                    HttpMethod.Post,
                    $"{_baseUrl}/automation-agent",
                    body,
                    authenticated: true);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    Log($"HeartbeatAsync failed HTTP {(int)response.StatusCode}.");
                    return false;
                }

                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var result = JsonConvert.DeserializeObject<HeartbeatResponse>(json);
                return result?.Ok == true;
            }
            catch (TaskCanceledException)
            {
                // Heartbeat timeout is expected on intermittent network — just return false.
                return false;
            }
            catch (Exception ex)
            {
                Log($"HeartbeatAsync exception: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // 4. ReportCommandResultAsync — POST /automation-agent {action:'command_result'}
        // -----------------------------------------------------------------------

        /// <summary>
        /// Reports the result of an agent command (flatten_all, cancel_orders, etc.)
        /// back to the server so it can mark the command as executed or failed.
        ///
        /// <para>
        /// Fail-safe: returns false on any error (network timeout, HTTP error).
        /// The caller logs and continues — a failed report does not break the loop.
        /// </para>
        /// </summary>
        /// <param name="commandId">UUID of the command being reported.</param>
        /// <param name="status">"executed" or "failed".</param>
        /// <param name="error">Optional error description; null or empty on success.</param>
        public async Task<bool> ReportCommandResultAsync(
            string commandId,
            string status,
            string error,
            CancellationToken ct = default)
        {
            if (!IsPaired) return false;

            var body = new
            {
                action     = "command_result",
                command_id = commandId,
                status     = status,
                error      = error   // null is fine; server treats missing/null as no error
            };

            try
            {
                var request = BuildRequest(
                    HttpMethod.Post,
                    $"{_baseUrl}/automation-agent",
                    body,
                    authenticated: true);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    Log($"ReportCommandResultAsync failed HTTP {(int)response.StatusCode} " +
                        $"for command_id='{commandId}'.");
                    return false;
                }

                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var result = JsonConvert.DeserializeObject<EventResponse>(json);
                return result?.Ok == true;
            }
            catch (TaskCanceledException)
            {
                Log($"ReportCommandResultAsync timed out for command_id='{commandId}'.");
                return false;
            }
            catch (Exception ex)
            {
                Log($"ReportCommandResultAsync exception: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // 5. PostEventAsync — POST /automation-agent {action:'event'}
        // -----------------------------------------------------------------------

        /// <summary>
        /// Posts an automation event (risk enforced, copy executed, etc.) to the
        /// FINOTAUR server so it appears in the web dashboard event log.
        /// Fire-and-forget friendly: caller can await or discard.
        /// </summary>
        public async Task<bool> PostEventAsync(
            AutomationEvent evt,
            CancellationToken ct = default)
        {
            if (!IsPaired) return false;

            // Build the full request body by merging action with the event fields
            var body = new
            {
                action               = "event",
                event_type           = evt.EventType,
                severity             = evt.Severity,
                broker_connection_id = evt.BrokerConnectionId,
                symbol               = evt.Symbol,
                payload              = evt.Payload
            };

            try
            {
                var request = BuildRequest(
                    HttpMethod.Post,
                    $"{_baseUrl}/automation-agent",
                    body,
                    authenticated: true);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    Log($"PostEventAsync failed HTTP {(int)response.StatusCode} " +
                        $"for event_type='{evt.EventType}'.");
                    return false;
                }

                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var result = JsonConvert.DeserializeObject<EventResponse>(json);
                return result?.Ok == true;
            }
            catch (TaskCanceledException)
            {
                Log($"PostEventAsync timed out for event_type='{evt.EventType}'.");
                return false;
            }
            catch (Exception ex)
            {
                Log($"PostEventAsync exception: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // 6. SendAccountSnapshotAsync — POST /automation-agent {action:'account_snapshot'}
        // -----------------------------------------------------------------------

        /// <summary>
        /// Posts a snapshot of all agent-visible NT8 accounts (balance, PnL,
        /// positions) to the FINOTAUR server.  Called every poll cycle alongside
        /// the heartbeat.
        ///
        /// <para>Soft failure: returns false on any network or HTTP error.
        /// The caller logs and continues — a failed snapshot never breaks the loop.</para>
        /// </summary>
        /// <param name="accounts">
        /// Per-account telemetry built by the agent loop from IPlatformAdapter.
        /// </param>
        public async Task<bool> SendAccountSnapshotAsync(
            IEnumerable<AccountSnapshot> accounts,
            CancellationToken ct = default)
        {
            if (!IsPaired) return false;

            var body = new
            {
                action   = "account_snapshot",
                accounts = accounts
            };

            try
            {
                var request = BuildRequest(
                    HttpMethod.Post,
                    $"{_baseUrl}/automation-agent",
                    body,
                    authenticated: true);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    Log($"SendAccountSnapshotAsync failed HTTP {(int)response.StatusCode}.");
                    return false;
                }

                var json   = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var result = JsonConvert.DeserializeObject<AccountSnapshotResponse>(json);
                return result?.Ok == true;
            }
            catch (TaskCanceledException)
            {
                // Snapshot timeout is non-critical — heartbeat already ran.
                return false;
            }
            catch (Exception ex)
            {
                Log($"SendAccountSnapshotAsync exception: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // Private helpers
        // -----------------------------------------------------------------------

        private HttpRequestMessage BuildRequest(
            HttpMethod method,
            string url,
            object body,
            bool authenticated)
        {
            var request = new HttpRequestMessage(method, url);

            // Serialize body
            var json = JsonConvert.SerializeObject(body);
            request.Content = new StringContent(json, Encoding.UTF8, "application/json");

            // Auth header — bearer device token
            if (authenticated && !string.IsNullOrWhiteSpace(_deviceToken))
            {
                // SECURITY: token is injected directly into the header object;
                // it is NOT concatenated into any string that might end up in logs.
                request.Headers.Authorization =
                    new AuthenticationHeaderValue("Bearer", _deviceToken);
            }

            // Optional Supabase anon key as apikey header
            // This is the PUBLIC publishable key — safe to embed.
            // The service_role/secret key must NEVER appear here.
            if (!string.IsNullOrWhiteSpace(AnonKeyPlaceholder))
            {
                request.Headers.TryAddWithoutValidation("apikey", AnonKeyPlaceholder);
            }

            return request;
        }

        /// <summary>
        /// Safe logging helper. Never include the device token or any credential.
        /// Uses NinjaTrader's Print (available in AddOn context).
        /// VERIFY (NT8 API): NinjaTrader.Code.Output.Process() is the NT8 way
        /// to write to the output window from non-Strategy contexts.
        /// </summary>
        private static void Log(string message)
        {
            try
            {
                // VERIFY (NT8 API): Confirm the correct output method for AddOns.
                // Option A (strategies): NinjaTrader.Code.Output.Process(message, PrintTo.OutputTab1);
                // Option B (AddOn/general): Use a static logger or route through the AddOn class.
                // For now we use System.Diagnostics for guaranteed output in all contexts.
                System.Diagnostics.Debug.WriteLine($"[FinotaurClient] {message}");
            }
            catch { /* logging must never throw */ }
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _http?.Dispose();
        }
    }
}
