// =============================================================================
// Finotaur Agent — Platform/NinjaTraderAdapter.cs
//
// IPlatformAdapter implementation against the NinjaTrader 8 Cbi (client-broker
// interface) API. All NT8 API calls are annotated with VERIFY comments where
// the exact method signatures or availability in AddOn context is uncertain.
//
// COMPILE-TIME NOTE:
//   This file references types in NinjaTrader.Cbi and NinjaTrader.Core.
//   These assemblies are available in the NT8 NinjaScript environment.
//   If you see "type not found" errors, check that you are compiling inside
//   the NinjaTrader NinjaScript Editor (not a standalone .NET project).
//
// THREADING:
//   NT8's Account.All collection must be accessed under lock(Account.All).
//   All public methods in this adapter acquire that lock when touching Account.All.
//   Fill callbacks may arrive on NT8's internal threads — the onFill delegate
//   is invoked directly; callers must be thread-safe.
//
// ACCOUNT MATCHING:
//   The server returns BrokerConnection.account_id (a string, e.g. "12345" for
//   Tradovate). We match it to NT8 Account.Name. Tradovate's NT8 account name
//   may be "Demo 12345" or just "12345" depending on NT8 version and connection.
//   The matching strategy: try exact match first, then suffix match.
//   If ambiguous or no match: skip and post agent_status event.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using NinjaTrader.Cbi;                   // Account, Order, Execution, Position, etc.
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;

// Account, Order, OrderAction, OrderType, OrderEntry, TimeInForce, Instrument,
// Execution, ExecutionEventArgs, AccountItem, Currency, CustomOrder are all in NinjaTrader.Cbi.

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform
{
    /// <summary>
    /// NT8-specific IPlatformAdapter. Uses NinjaTrader.Cbi APIs for all
    /// account queries and order submission.
    ///
    /// Every public method is fail-safe: it catches all exceptions, logs them,
    /// and returns a safe default (null / false / 0 / empty). It NEVER throws.
    /// </summary>
    public class NinjaTraderAdapter : IPlatformAdapter
    {
        // -----------------------------------------------------------------------
        // Fill subscription bookkeeping
        // -----------------------------------------------------------------------

        // Handle type for fill subscriptions. Wraps the account name + the
        // delegate so we can unhook from ExecutionUpdate.
        private class FillSubscription
        {
            public string AccountName   { get; set; }
            public Action<FillInfo> OnFill { get; set; }

            // NT8-level handler stored for -= on Unsubscribe.
            // ExecutionUpdate signature: void Handler(object sender, ExecutionEventArgs e)
            // where sender is the Account.
            public EventHandler<ExecutionEventArgs> NtHandler { get; set; }
        }

        // Thread-safe dictionary from subscription ID -> subscription
        private readonly ConcurrentDictionary<Guid, FillSubscription> _subscriptions =
            new ConcurrentDictionary<Guid, FillSubscription>();

        // Track which account objects we have hooked so we only hook once per account.
        private readonly ConcurrentDictionary<string, Account> _hookedAccounts =
            new ConcurrentDictionary<string, Account>();

        // -----------------------------------------------------------------------
        // Working-order subscription bookkeeping (analogous to FillSubscription)
        // -----------------------------------------------------------------------

        // Handle type for working-order subscriptions. Wraps the account name +
        // the delegate so we can unhook from OrderUpdate.
        private class OrderSubscription
        {
            public string AccountName    { get; set; }
            public Action<OrderInfo> OnOrder { get; set; }

            // NT8-level handler stored for -= on Unsubscribe.
            // OrderUpdate signature: void Handler(object sender, OrderEventArgs e)
            // where sender is the Account.
            public EventHandler<OrderEventArgs> NtHandler { get; set; }
        }

        // Thread-safe dictionary from subscription ID -> order subscription.
        // Separate from _subscriptions (fills) so Unsubscribe can check both.
        private readonly ConcurrentDictionary<Guid, OrderSubscription> _orderSubscriptions =
            new ConcurrentDictionary<Guid, OrderSubscription>();

        // Caches to keep the order-submit path fast (avoid per-order lookups).
        // Account objects are stable for the NT session (same object reference
        // throughout; NT8 does not recreate Account instances during a session).
        // Instrument objects returned by Instrument.GetInstrument are also stable
        // for the lifetime of the NT session for a given contract name.
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, Account> _accountCache =
            new System.Collections.Concurrent.ConcurrentDictionary<string, Account>(StringComparer.OrdinalIgnoreCase);
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, Instrument> _instrumentCache =
            new System.Collections.Concurrent.ConcurrentDictionary<string, Instrument>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // Logger (injected to avoid circular dependencies)
        // -----------------------------------------------------------------------

        private readonly Action<string> _log;

        public NinjaTraderAdapter(Action<string> logger = null)
        {
            _log = logger ?? (msg => System.Diagnostics.Debug.WriteLine($"[NtAdapter] {msg}"));
        }

        // -----------------------------------------------------------------------
        // GetAccounts
        // -----------------------------------------------------------------------

        public IEnumerable<AgentAccount> GetAccounts()
        {
            var result = new List<AgentAccount>();
            try
            {
                // Account.All is IList<Account>; must lock before iterating.
                lock (Account.All)
                {
                    foreach (Account acct in Account.All)
                    {
                        result.Add(new AgentAccount
                        {
                            Name           = acct.Name,
                            // Account.Connection.Options.Name is the connection profile name (e.g. "Tradovate").
                            ConnectionName = acct.Connection?.Options?.Name ?? "Unknown",
                            // Simulated/demo accounts are identified by name substring.
                            IsSimulation   = acct.Name.IndexOf("Sim", StringComparison.OrdinalIgnoreCase) >= 0
                                          || acct.Name.IndexOf("Demo", StringComparison.OrdinalIgnoreCase) >= 0
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"GetAccounts error: {ex.Message}");
            }
            return result;
        }

        // -----------------------------------------------------------------------
        // ResolveAccountName
        // -----------------------------------------------------------------------

        public string ResolveAccountName(BrokerConnection connection)
        {
            if (connection == null || string.IsNullOrWhiteSpace(connection.AccountId))
                return null;

            string targetId = connection.AccountId.Trim();

            try
            {
                // Account.All must be accessed under lock(Account.All) per NT8 threading rules.
                lock (Account.All)
                {
                    // Strategy 1: exact match on Account.Name
                    Account exact = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, targetId, StringComparison.OrdinalIgnoreCase));
                    if (exact != null) return exact.Name;

                    // Strategy 2: Account.Name ends with the account_id
                    // (e.g. "Demo 12345" matched by "12345")
                    Account suffix = Account.All.FirstOrDefault(a =>
                        a.Name.EndsWith(targetId, StringComparison.OrdinalIgnoreCase));
                    if (suffix != null)
                    {
                        _log($"ResolveAccountName: matched '{targetId}' to NT account '{suffix.Name}' by suffix.");
                        return suffix.Name;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ResolveAccountName error for connection {connection.Id}: {ex.Message}");
            }

            _log($"ResolveAccountName: NO match for account_id='{targetId}'. " +
                 "Skipping this connection. Check that the Tradovate account is connected in NT8.");
            return null;
        }

        // -----------------------------------------------------------------------
        // ResolveAccountByName
        // -----------------------------------------------------------------------

        /// <summary>
        /// Resolves a broker account name string (e.g. "MFFUEVBLDR161429081",
        /// the value the FINOTAUR server returns as <c>account_name</c>) to the
        /// local NT <c>Account.Name</c> by a case-insensitive exact match.
        ///
        /// <para>
        /// This is the <b>primary</b> account-resolution path for copier routing.
        /// It is simpler than <see cref="ResolveAccountName(BrokerConnection)"/>
        /// because the server now sends the exact NT account name directly, so we
        /// do not need the numeric-ID suffix-match heuristic.
        /// </para>
        ///
        /// Returns <c>null</c> if no local account matches.  The caller MUST treat
        /// null as "this account is not connected in NT8 — skip and log."
        /// </summary>
        public string ResolveAccountByName(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
            {
                _log("ResolveAccountByName: called with null/empty accountName — returning null.");
                return null;
            }

            string target = accountName.Trim();

            try
            {
                // Account.All (IList<Account>) must be accessed under lock(Account.All).
                lock (Account.All)
                {
                    Account match = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, target, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        // Return the canonical NT name (preserves its original casing).
                        return match.Name;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ResolveAccountByName error for '{target}': {ex.Message}");
                return null;
            }

            _log($"ResolveAccountByName: NO local NT account matched '{target}'. " +
                 "The account may not be connected in NT8. " +
                 "Open NinjaTrader Control Center → Accounts and verify the account name. " +
                 "Skipping this route/target.");
            return null;
        }

        // -----------------------------------------------------------------------
        // GetAccountNames
        // -----------------------------------------------------------------------

        public string[] GetAccountNames()
        {
            var names = new List<string>();
            try
            {
                lock (Account.All)
                {
                    foreach (Account acct in Account.All)
                        names.Add(acct.Name);
                }
            }
            catch (Exception ex)
            {
                _log($"GetAccountNames error: {ex.Message}");
            }
            return names.ToArray();
        }

        // -----------------------------------------------------------------------
        // GetCashBalance
        // -----------------------------------------------------------------------

        public double? GetCashBalance(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return null;

                // account.Get(AccountItem.CashValue, Currency.UsDollar) returns the
                // account cash value / equity in USD.
                // VERIFY (NT8 API): AccountItem.CashValue is the closest available item
                // to "cash balance" in the NinjaTrader.Cbi namespace. If CashValue
                // is not present in the NT8 version in use, AccountItem.NetLiquidation
                // is the next best alternative.
                double value = acct.Get(AccountItem.CashValue, Currency.UsDollar);
                return value;
            }
            catch (Exception ex)
            {
                _log($"GetCashBalance error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // GetPositions
        // -----------------------------------------------------------------------

        public AgentPosition[] GetPositions(string accountName)
        {
            var positions = new List<AgentPosition>();
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return positions.ToArray();

                // Account.Positions is IEnumerable<Position> (NinjaTrader.Cbi).
                // Position has: MarketPosition, Quantity, Instrument, UnrealizedProfitLoss.
                lock (Account.All)
                {
                    foreach (Position pos in acct.Positions)
                    {
                        // MarketPosition.Flat means no open position — skip.
                        if (pos.MarketPosition == MarketPosition.Flat) continue;

                        double pointValue = 1.0;
                        try
                        {
                            // Instrument.MasterInstrument.PointValue gives the dollar
                            // value of one point movement per contract.
                            pointValue = pos.Instrument.MasterInstrument.PointValue;
                        }
                        catch { /* best-effort; leave pointValue = 1.0 */ }

                        // pos.AveragePrice is the average entry price.
                        double avgPrice    = pos.AveragePrice;
                        double marketValue = avgPrice * pos.Quantity * pointValue;

                        // WI-4: compute per-position unrealized PnL using the
                        // NT8 Position.GetUnrealizedProfitLoss(PerformanceUnit, double)
                        // method.  We pass the last traded price as the mark-price.
                        // VERIFY (NT8 API): Position.GetUnrealizedProfitLoss is a
                        // public method on NinjaTrader.Cbi.Position taking
                        // (PerformanceUnit unit, double price) and returning double.
                        // Instrument.MarketData?.Last?.Price is the last-trade price
                        // from the NT8 market data subscription (null when no sub).
                        // Fall back to AveragePrice (= 0 unrealized) when no data.
                        double unrealPnl = 0.0;
                        try
                        {
                            double lastPrice = pos.Instrument.MarketData?.Last?.Price
                                              ?? pos.AveragePrice;
                            unrealPnl = pos.GetUnrealizedProfitLoss(
                                PerformanceUnit.Currency, lastPrice);
                        }
                        catch
                        {
                            // Safe degrade: no market data or API not available.
                            unrealPnl = 0.0;
                        }

                        positions.Add(new AgentPosition
                        {
                            InstrumentName  = pos.Instrument.FullName,
                            Quantity        = pos.Quantity,
                            IsLong          = pos.MarketPosition == MarketPosition.Long,
                            AveragePrice    = avgPrice,
                            UnrealizedPnL   = unrealPnl,
                            MarketValueUsd  = marketValue
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"GetPositions error for '{accountName}': {ex.Message}");
            }
            return positions.ToArray();
        }

        // -----------------------------------------------------------------------
        // GetSessionRealizedPnL
        // -----------------------------------------------------------------------

        public double GetSessionRealizedPnL(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return 0.0;

                // account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar) returns
                // the session realized PnL in USD. AccountItem and Currency are in NinjaTrader.Cbi.
                double realized = acct.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
                return realized;
            }
            catch (Exception ex)
            {
                _log($"GetSessionRealizedPnL error for '{accountName}': {ex.Message}");
                return 0.0;
            }
        }

        // -----------------------------------------------------------------------
        // GetOpenPnL
        // -----------------------------------------------------------------------

        public double GetOpenPnL(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return 0.0;

                // account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar) returns
                // the total account-level unrealized PnL in USD. This is the confirmed NT8
                // API; Position has no UnrealizedProfitLoss property.
                return acct.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
            }
            catch (Exception ex)
            {
                _log($"GetOpenPnL error for '{accountName}': {ex.Message}");
                return 0.0;
            }
        }

        // -----------------------------------------------------------------------
        // GetOpenContracts
        // -----------------------------------------------------------------------

        public int GetOpenContracts(string accountName, string symbol = null)
        {
            try
            {
                AgentPosition[] positions = GetPositions(accountName);

                if (string.IsNullOrWhiteSpace(symbol))
                    return positions.Sum(p => p.Quantity);

                return positions
                    .Where(p => p.InstrumentName.IndexOf(symbol, StringComparison.OrdinalIgnoreCase) >= 0)
                    .Sum(p => p.Quantity);
            }
            catch (Exception ex)
            {
                _log($"GetOpenContracts error for '{accountName}': {ex.Message}");
                return 0;
            }
        }

        // -----------------------------------------------------------------------
        // FlattenAll
        // -----------------------------------------------------------------------

        // Helper class used by FlattenAll to carry per-position snapshot data
        // collected under lock before order submission (outside the lock).
        // Uses a private sealed class instead of ValueTuple to avoid any
        // System.ValueTuple dependency in the NinjaScript environment.
        private sealed class OpenPos
        {
            public Instrument Instr  { get; set; }
            public bool       IsLong { get; set; }
            public int        Qty    { get; set; }
        }

        public bool FlattenAll(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"FlattenAll: account '{accountName}' not found — SKIPPING (fail-safe).");
                    return false;
                }

                // NT8 (verified in sim 2026-06-30): Account.Flatten() does NOT reliably
                // close positions on these accounts. Explicit offsetting market orders
                // submitted via acct.CreateOrder + acct.Submit DO fill reliably (same
                // path as PlaceMarketOrder). Collect open positions under the lock, then
                // submit orders outside the lock.
                var openPositions = new List<OpenPos>();
                lock (Account.All)
                {
                    foreach (Position pos in acct.Positions)
                    {
                        if (pos.MarketPosition != MarketPosition.Flat
                            && pos.Instrument != null
                            && pos.Quantity > 0)
                        {
                            openPositions.Add(new OpenPos
                            {
                                Instr  = pos.Instrument,
                                IsLong = pos.MarketPosition == MarketPosition.Long,
                                Qty    = pos.Quantity
                            });
                        }
                    }
                }

                if (openPositions.Count == 0)
                {
                    _log($"FlattenAll: no open positions on '{accountName}' — nothing to flatten.");
                    return true;
                }

                bool allOk = true;
                foreach (OpenPos op in openPositions)
                {
                    // Offsetting side: sell a long, buy a short.
                    OrderAction action = op.IsLong ? OrderAction.Sell : OrderAction.Buy;

                    _log($"FlattenAll: closing {op.Qty} {op.Instr.FullName} on '{accountName}' via market {action}.");

                    try
                    {
                        // Exact same 12-argument CreateOrder signature used by PlaceMarketOrder:
                        //   (Instrument, OrderAction, OrderType, OrderEntry, TimeInForce,
                        //    int qty, double limitPrice, double stopPrice, string oco,
                        //    string name, DateTime gtd, CustomOrder customOrder)
                        Order order = acct.CreateOrder(
                            op.Instr,
                            action,
                            OrderType.Market,
                            OrderEntry.Automated,
                            TimeInForce.Day,
                            op.Qty,
                            0,                                    // limitPrice (not used for market)
                            0,                                    // stopPrice (not used for market)
                            string.Empty,                         // oco id
                            "FinotaurFlatten",                    // name — visible in Executions tab
                            NinjaTrader.Core.Globals.MaxDate,     // gtd
                            null                                  // customOrder
                        );

                        if (order != null)
                        {
                            acct.Submit(new[] { order });
                        }
                        else
                        {
                            _log($"FlattenAll: CreateOrder returned null for {op.Instr.FullName} — skipping this position.");
                            allOk = false;
                        }
                    }
                    catch (Exception posEx)
                    {
                        _log($"FlattenAll: order submission failed for {op.Instr.FullName}: {posEx.Message} — continuing with remaining positions.");
                        allOk = false;
                    }
                }

                return allOk;
            }
            catch (Exception ex)
            {
                _log($"FlattenAll error for '{accountName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // FlattenSymbol
        // -----------------------------------------------------------------------

        public bool FlattenSymbol(string accountName, string symbol)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null || string.IsNullOrWhiteSpace(symbol))
                {
                    _log($"FlattenSymbol: precondition failed for '{accountName}/{symbol}' — SKIPPING.");
                    return false;
                }

                // Instrument.GetInstrument(string) returns null if not found.
                // The name must match NT8's exact format (e.g. "NQ 09-26").
                Instrument instr = Instrument.GetInstrument(symbol);
                if (instr == null)
                {
                    _log($"FlattenSymbol: instrument '{symbol}' not found in NT8 — SKIPPING.");
                    return false;
                }

                _log($"FlattenSymbol: Issuing flatten on '{accountName}' / '{symbol}'.");
                // account.Flatten(ICollection<Instrument>) — pass the target instrument.
                acct.Flatten(new[] { instr });

                return true;
            }
            catch (Exception ex)
            {
                _log($"FlattenSymbol error for '{accountName}/{symbol}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // CancelAllOrders
        // -----------------------------------------------------------------------

        public bool CancelAllOrders(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"CancelAllOrders: account '{accountName}' not found — SKIPPING (fail-safe).");
                    return false;
                }

                // Build a list of orders that are still live (working).
                // VERIFY (NT8 API): Account.Orders is IEnumerable<Order> in NinjaTrader.Cbi.
                // OrderState enum values used here:
                //   OrderState.Working    — accepted by the broker and resting on the book
                //   OrderState.Accepted   — acknowledged by NT/broker but not yet on book
                //   OrderState.Submitted  — sent to broker, awaiting acknowledgement
                // We skip OrderState.Filled, OrderState.Cancelled, OrderState.Rejected,
                // OrderState.PartFilled, OrderState.PendingCancel, OrderState.Unknown.
                // VERIFY (NT8 API): confirm these are the correct OrderState names in
                // the NinjaTrader.Cbi namespace for your NT8 version.
                var workingOrders = new List<Order>();

                lock (Account.All)
                {
                    foreach (Order o in acct.Orders)
                    {
                        if (o.OrderState == OrderState.Working
                            || o.OrderState == OrderState.Accepted
                            || o.OrderState == OrderState.Submitted)
                        {
                            workingOrders.Add(o);
                        }
                    }
                }

                if (workingOrders.Count == 0)
                {
                    _log($"CancelAllOrders: no working orders on '{accountName}' — nothing to cancel.");
                    return true; // success: there is nothing to cancel
                }

                _log($"CancelAllOrders: cancelling {workingOrders.Count} working order(s) " +
                     $"on account '{accountName}'.");

                // VERIFY (NT8 API): Account.Cancel(ICollection<Order>) is the NT8 Cbi method
                // that submits cancel requests for all orders in the list in one call.
                // If this overload does not exist in your NT8 version, replace with a loop:
                //   foreach (var o in workingOrders) acct.Cancel(new[] { o });
                acct.Cancel(workingOrders);

                return true;
            }
            catch (Exception ex)
            {
                _log($"CancelAllOrders error for '{accountName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // GetWorkingOrders
        // -----------------------------------------------------------------------

        /// <summary>
        /// Clones the CancelAllOrders enumeration pattern: lock(Account.All), iterate
        /// acct.Orders. Live states (per IsLiveOrderState) are always included; when
        /// includeTerminal is true, Filled/Cancelled/Rejected orders are included too.
        /// Uses the shared MapOrderType/MapOrderState/MapTif helpers (same mapping as
        /// SubscribeOrders) so results are consistent across both read paths.
        /// </summary>
        public AgentWorkingOrder[] GetWorkingOrders(string accountName, bool includeTerminal = false)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"GetWorkingOrders: account '{accountName}' not found — returning empty array.");
                    return Array.Empty<AgentWorkingOrder>();
                }

                var result = new List<AgentWorkingOrder>();

                lock (Account.All)
                {
                    foreach (Order o in acct.Orders)
                    {
                        bool include = IsLiveOrderState(o.OrderState)
                            || (includeTerminal &&
                                (o.OrderState == OrderState.Filled
                                 || o.OrderState == OrderState.Cancelled
                                 || o.OrderState == OrderState.Rejected));

                        if (!include) continue;

                        bool isBuy = o.OrderAction == OrderAction.Buy ||
                                     o.OrderAction == OrderAction.BuyToCover;

                        result.Add(new AgentWorkingOrder
                        {
                            OrderId        = o.Id.ToString(),
                            Name           = o.Name,
                            InstrumentName = o.Instrument?.FullName,
                            IsBuy          = isBuy,
                            Quantity       = o.Quantity,
                            OrderType      = MapOrderType(o.OrderType),
                            LimitPrice     = o.LimitPrice,
                            StopPrice      = o.StopPrice,
                            Tif            = MapTif(o.TimeInForce),
                            State          = MapOrderState(o.OrderState),
                            // SYNCHARD (v1.10.0): VERIFY (NT8 API): NinjaTrader.Cbi.Order exposes
                            // the OCO group id as string property `Oco` (same property already
                            // read in SubscribeOrders above as o.Oco ?? string.Empty).
                            Oco            = o.Oco ?? string.Empty
                        });
                    }
                }

                return result.ToArray();
            }
            catch (Exception ex)
            {
                _log($"GetWorkingOrders error for '{accountName}': {ex.Message}");
                return Array.Empty<AgentWorkingOrder>();
            }
        }

        // -----------------------------------------------------------------------
        // IsAccountConnected
        // -----------------------------------------------------------------------

        /// <summary>
        /// SYNCHARD (v1.10.0, FIX 3a): reads the SAME acct.Connection object
        /// already dereferenced elsewhere in this adapter (see GetAccounts'
        /// `acct.Connection?.Options?.Name` above) and checks its Status.
        /// VERIFY (NT8 API): NinjaTrader.Cbi.Connection exposes a `Status`
        /// property of type NinjaTrader.Cbi.ConnectionStatus; `Connected` is the
        /// member representing a live, working connection. If the enum member
        /// name differs in this NT8 version, this is the only line to adjust.
        /// FAIL-SAFE: account not found, Connection null, or any exception all
        /// return false — callers must treat false as "not verifiably connected".
        /// </summary>
        public bool IsAccountConnected(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return false;

                Connection conn = acct.Connection;
                if (conn == null) return false;

                return conn.Status == ConnectionStatus.Connected;
            }
            catch (Exception ex)
            {
                _log($"IsAccountConnected error for '{accountName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // PlaceMarketOrder
        // -----------------------------------------------------------------------

        public bool PlaceMarketOrder(string accountName, string instrumentName, bool isBuy, int quantity, string orderName = "FinotaurCopier")
        {
            // Hard guards — never submit a zero or negative qty order.
            if (quantity < 1)
            {
                _log($"PlaceMarketOrder: quantity={quantity} is invalid — SKIPPING.");
                return false;
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"PlaceMarketOrder: account '{accountName}' not found — SKIPPING.");
                    return false;
                }

                // Instrument lookup — cached to avoid calling Instrument.GetInstrument on
                // every copy order. The instrument name is stable for the contract lifetime
                // (e.g. "NQ 09-26" — rolls at expiry, which triggers a new name anyway).
                // On cache miss: call Instrument.GetInstrument as before and cache the result.
                Instrument instr;
                if (!_instrumentCache.TryGetValue(instrumentName, out instr))
                {
                    instr = Instrument.GetInstrument(instrumentName);
                    if (instr != null)
                        _instrumentCache.TryAdd(instrumentName, instr);
                }

                if (instr == null)
                {
                    _log($"PlaceMarketOrder: instrument '{instrumentName}' not found in NT8 — SKIPPING.");
                    return false;
                }

                OrderAction action = isBuy ? OrderAction.Buy : OrderAction.Sell;

                _log($"PlaceMarketOrder: {action} {quantity} {instrumentName} on '{accountName}'.");

                // Official 12-arg CreateOrder signature:
                //   account.CreateOrder(Instrument, OrderAction, OrderType, OrderEntry,
                //                       TimeInForce, int qty, double limitPrice, double stopPrice,
                //                       string oco, string name, DateTime gtd, CustomOrder customOrder)
                // Returns Order; then account.Submit(new[] { order }).
                Order order = acct.CreateOrder(
                    instr,
                    action,
                    OrderType.Market,
                    OrderEntry.Automated,
                    TimeInForce.Day,
                    quantity,
                    0,                                    // limitPrice (not used for market)
                    0,                                    // stopPrice (not used for market)
                    string.Empty,                         // oco id
                    orderName,                            // name — visible in Executions tab; carries copy token for latency correlation
                    NinjaTrader.Core.Globals.MaxDate,     // gtd
                    null                                  // customOrder
                );

                if (order == null)
                {
                    _log($"PlaceMarketOrder: CreateOrder returned null for {instrumentName} — SKIPPING.");
                    return false;
                }

                acct.Submit(new[] { order });

                return true;
            }
            catch (Exception ex)
            {
                _log($"PlaceMarketOrder error for '{accountName}/{instrumentName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // SubscribeFills / Unsubscribe
        // -----------------------------------------------------------------------

        public object SubscribeFills(string accountName, Action<FillInfo> onFill)
        {
            if (onFill == null) return null;

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"SubscribeFills: account '{accountName}' not found — cannot subscribe.");
                    return null;
                }

                var sub = new FillSubscription
                {
                    AccountName = accountName,
                    OnFill      = onFill
                };

                // Build the NT8 ExecutionUpdate handler.
                // ExecutionEventArgs.Execution (type Execution in NinjaTrader.Cbi) exposes:
                //   .ExecutionId (string), .Instrument, .Price, .Quantity,
                //   .MarketPosition, .Order, .Account — all confirmed in NT8 Cbi.
                EventHandler<ExecutionEventArgs> ntHandler = (sender, e) =>
                {
                    try
                    {
                        var exec = e.Execution;
                        if (exec == null) return;
                        if (!string.Equals(exec.Account?.Name, accountName,
                                StringComparison.OrdinalIgnoreCase)) return;

                        bool isBuy = exec.Order?.OrderAction == OrderAction.Buy ||
                                     exec.Order?.OrderAction == OrderAction.BuyToCover;

                        // -------------------------------------------------------
                        // IsOpening + SourceNetAtFill (FIX A):
                        //
                        // Both fields are computed here, inside the NT ExecutionUpdate
                        // callback, by reading Account.Positions in a single lock block.
                        // This is the ONLY safe moment to read the source net for the
                        // copier — doing it off-thread (in the consumer) would race
                        // against NT's async position update.
                        //
                        // Decision logic for IsOpening (sign convention: Long = positive
                        // qty, Short = negative qty, Flat = 0):
                        //
                        //   current position | fill side | result
                        //   ─────────────────────────────────────
                        //   Flat             | Buy       | Opening  (new long)
                        //   Flat             | Sell      | Opening  (new short)
                        //   Long             | Buy       | Opening  (adding to long)
                        //   Long             | Sell      | Closing  (reducing/closing long)
                        //   Short            | Sell      | Opening  (adding to short)
                        //   Short            | Buy       | Closing  (reducing/closing short)
                        //
                        // NOTE: NT8 may have already updated Account.Positions by the
                        // time this callback fires (post-fill state).  We therefore
                        // read the RESULTING (post-fill) position and infer the pre-fill
                        // state from fill direction + quantity.  If the resulting position
                        // is Flat or has switched sides relative to the fill, it was a
                        // closing fill; otherwise it is an opening fill.
                        //
                        // VERIFY (NT8 API): confirm that exec.Account.Positions reflects
                        // the POST-fill state (i.e. the position that exists AFTER NT8
                        // has applied this execution).  If NT8 updates positions
                        // synchronously before firing ExecutionUpdate, this logic is
                        // correct.  If positions update asynchronously after the event,
                        // the position read here is PRE-fill, which would require inverting
                        // the logic below.  In that case swap to: isOpening = (preFill is
                        // Flat || preFill is same direction as fill).
                        //
                        // FIX A: SourceNetAtFill is the signed net computed in this same
                        // lock block, at fill time. CopierEngine uses this value instead of
                        // calling GetPositions(fill.AccountName) off-thread. RESIDUAL: still
                        // assumes NT has updated Account.Positions by the time
                        // ExecutionUpdate fires — an NT8 API timing assumption that MUST
                        // be verified in NT8 sim.
                        // -------------------------------------------------------

                        bool isOpening;
                        int  sourceNetAtFill = 0;
                        try
                        {
                            MarketPosition postFillPos  = MarketPosition.Flat;
                            int            postFillQty  = 0;
                            string         instrFullName = exec.Instrument?.FullName;

                            lock (Account.All)
                            {
                                // Find the position for this specific instrument.
                                // VERIFY (NT8 API): exec.Instrument is NinjaTrader.Cbi.Instrument;
                                // Position.Instrument comparison uses reference equality on
                                // MasterInstrument — FullName string comparison is safer.
                                if (!string.IsNullOrWhiteSpace(instrFullName))
                                {
                                    foreach (Position pos in exec.Account.Positions)
                                    {
                                        if (string.Equals(pos.Instrument?.FullName, instrFullName,
                                                StringComparison.OrdinalIgnoreCase))
                                        {
                                            postFillPos = pos.MarketPosition;
                                            postFillQty = pos.Quantity;
                                            break;
                                        }
                                    }
                                }
                            }

                            // FIX (NT8 timing — verified in sim 2026-06-30):
                            // Account.Positions at ExecutionUpdate time reflects the
                            // PRE-fill net — NT has NOT yet applied this execution. The
                            // earlier code treated the read as post-fill, so a flat→long
                            // BUY read back as Flat → sourceNet=0, is_opening=false →
                            // the copy computed delta=0 and placed no order.
                            // Correct approach: take the read as the PRE-fill signed net,
                            // then ADD this fill's signed quantity to get the true
                            // POST-fill net. This does not depend on NT's async update.
                            int preNet =
                                  postFillPos == MarketPosition.Long  ?  postFillQty
                                : postFillPos == MarketPosition.Short ? -postFillQty
                                : 0;
                            int signedFillQty = isBuy ? exec.Quantity : -exec.Quantity;
                            int postNet       = preNet + signedFillQty;

                            // Signed post-fill net (Long = +, Short = −, Flat = 0).
                            sourceNetAtFill = postNet;

                            // Opening = exposure magnitude increased; closing/flat = decreased.
                            isOpening = Math.Abs(postNet) > Math.Abs(preNet);
                        }
                        catch (Exception posEx)
                        {
                            // VERIFY (NT8 API): if Account.Positions throws in this context,
                            // fall back to the legacy isBuy heuristic (opens most common on buy).
                            // SourceNetAtFill remains 0 (conservative — reconcile will re-seed
                            // from GetPositions on first touch for this key).
                            _log($"SubscribeFills IsOpening/SourceNetAtFill position query failed: {posEx.Message} " +
                                 "— falling back to isBuy heuristic; SourceNetAtFill=0. " +
                                 "VERIFY (NT8 API): check Account.Positions access from ExecutionUpdate.");
                            isOpening = isBuy;
                            sourceNetAtFill = 0;
                        }

                        var fill = new FillInfo
                        {
                            ExecutionId      = exec.ExecutionId,
                            AccountName      = exec.Account?.Name,
                            InstrumentName   = exec.Instrument?.FullName,
                            IsBuy            = isBuy,
                            Quantity         = exec.Quantity,
                            Price            = exec.Price,
                            IsOpening        = isOpening,
                            // FIX A: source net captured at fill time, not off-thread.
                            SourceNetAtFill  = sourceNetAtFill,
                            Timestamp        = exec.Time,
                            // Latency instrumentation: correlate follower fills back to
                            // the copy order that produced them, and record the monotonic
                            // stamp at the moment this callback fires (t0 for leader fills,
                            // t3 for follower fills).
                            OrderName        = exec.Order?.Name,
                            CapturedTicks    = Stopwatch.GetTimestamp(),
                            // Correlates this fill back to a mirrored working order
                            // (e.g. a working order placed via PlaceWorkingOrder).
                            OrderId          = exec.Order?.Id.ToString()
                        };

                        sub.OnFill(fill);
                    }
                    catch (Exception ex)
                    {
                        _log($"SubscribeFills handler error: {ex.Message}");
                    }
                };

                sub.NtHandler = ntHandler;

                // Hook into the account's ExecutionUpdate event.
                // account.ExecutionUpdate is EventHandler<ExecutionEventArgs> on NinjaTrader.Cbi.Account.
                // We track _hookedAccounts for logging, but always attach the handler
                // (each subscription needs its own handler for independent -= on Unsubscribe).
                _hookedAccounts.TryAdd(accountName, acct);
                acct.ExecutionUpdate += ntHandler;

                var id = Guid.NewGuid();
                _subscriptions[id] = sub;

                _log($"SubscribeFills: subscribed to '{accountName}' (sub id: {id}).");
                return id; // opaque handle
            }
            catch (Exception ex)
            {
                _log($"SubscribeFills error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        public void Unsubscribe(object subscriptionHandle)
        {
            if (subscriptionHandle == null) return;
            if (!(subscriptionHandle is Guid id)) return;

            try
            {
                // Check the fill-subscription dictionary first.
                if (_subscriptions.TryRemove(id, out FillSubscription sub))
                {
                    Account acct = FindAccount(sub.AccountName);
                    if (acct != null && sub.NtHandler != null)
                    {
                        acct.ExecutionUpdate -= sub.NtHandler;
                    }

                    _log($"Unsubscribe: removed fill subscription {id} for '{sub.AccountName}'.");
                    return;
                }

                // Not a fill subscription — check the order-subscription dictionary.
                if (_orderSubscriptions.TryRemove(id, out OrderSubscription orderSub))
                {
                    Account acct = FindAccount(orderSub.AccountName);
                    if (acct != null && orderSub.NtHandler != null)
                    {
                        acct.OrderUpdate -= orderSub.NtHandler;
                    }

                    _log($"Unsubscribe: removed order subscription {id} for '{orderSub.AccountName}'.");
                    return;
                }

                // Handle not found in either dictionary — no-op (already unsubscribed).
            }
            catch (Exception ex)
            {
                _log($"Unsubscribe error: {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // SubscribeOrders (working-order lifecycle — analogous to SubscribeFills)
        // -----------------------------------------------------------------------

        public object SubscribeOrders(string accountName, Action<OrderInfo> onOrder,
                                      OrderNameFilter filter = OrderNameFilter.SkipFinotaur)
        {
            if (onOrder == null) return null;

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"SubscribeOrders: account '{accountName}' not found — cannot subscribe.");
                    return null;
                }

                var sub = new OrderSubscription
                {
                    AccountName = accountName,
                    OnOrder     = onOrder
                };

                // Build the NT8 OrderUpdate handler.
                // OrderEventArgs.Order (type Order in NinjaTrader.Cbi) exposes:
                //   .Id, .Account, .Instrument, .OrderAction, .Quantity, .OrderType,
                //   .LimitPrice, .StopPrice, .OrderState, .Name, .Time — all confirmed
                //   in NT8 Cbi (same members used elsewhere in this adapter).
                EventHandler<OrderEventArgs> ntHandler = (sender, e) =>
                {
                    try
                    {
                        Order o = e.Order;
                        if (o == null) return;
                        if (!string.Equals(o.Account?.Name, accountName,
                                StringComparison.OrdinalIgnoreCase)) return;

                        // Apply the requested name filter (v1.9.0).
                        if (filter == OrderNameFilter.SkipFinotaur)
                        {
                            // Skip our own mirrored orders (avoid feedback loops).
                            if (o.Name != null && o.Name.StartsWith("Finotaur",
                                    StringComparison.Ordinal)) return;
                        }
                        else // OnlyFinotaurMirrors
                        {
                            // Deliver ONLY our own mirrored follower orders — drop
                            // everything else (including the user's own manual orders).
                            if (o.Name == null || !o.Name.StartsWith("FinotaurCopier|ord|",
                                    StringComparison.Ordinal)) return;
                        }

                        bool isBuy = o.OrderAction == OrderAction.Buy ||
                                     o.OrderAction == OrderAction.BuyToCover;

                        string orderTypeStr = MapOrderType(o.OrderType);
                        string stateStr     = MapOrderState(o.OrderState);

                        var orderInfo = new OrderInfo
                        {
                            OrderId        = o.Id.ToString(),
                            AccountName    = o.Account?.Name,
                            InstrumentName = o.Instrument?.FullName,
                            IsBuy          = isBuy,
                            Quantity       = o.Quantity,
                            OrderType      = orderTypeStr,
                            LimitPrice     = o.LimitPrice,
                            StopPrice      = o.StopPrice,
                            State          = stateStr,
                            OrderName      = o.Name,
                            Tif            = MapTif(o.TimeInForce),
                            // VERIFY (NT8 API): NinjaTrader.Cbi.Order exposes the OCO group id as string property `Oco`.
                            OcoId          = o.Oco ?? string.Empty,
                            // VERIFY (NT8 API): Order.Time is expected to reflect the
                            // timestamp of this state change. Fall back to DateTime.Now
                            // if unavailable (e.g. default/unset).
                            Timestamp      = o.Time != default(DateTime) ? o.Time : DateTime.Now
                        };

                        sub.OnOrder(orderInfo);
                    }
                    catch (Exception ex)
                    {
                        _log($"SubscribeOrders handler error: {ex.Message}");
                    }
                };

                sub.NtHandler = ntHandler;

                acct.OrderUpdate += ntHandler;

                var id = Guid.NewGuid();
                _orderSubscriptions[id] = sub;

                _log($"SubscribeOrders: subscribed to '{accountName}' (sub id: {id}).");
                return id; // opaque handle
            }
            catch (Exception ex)
            {
                _log($"SubscribeOrders error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // PlaceWorkingOrder / ModifyWorkingOrder / CancelWorkingOrder
        // -----------------------------------------------------------------------

        public string PlaceWorkingOrder(string accountName, string instrumentName, bool isBuy, int quantity,
                                         string orderType, double limitPrice, double stopPrice,
                                         string orderName = "FinotaurCopier", string tif = "day", string oco = "")
        {
            // Hard guards — never submit a zero or negative qty order.
            if (quantity < 1)
            {
                _log($"PlaceWorkingOrder: quantity={quantity} is invalid — SKIPPING.");
                return null;
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"PlaceWorkingOrder: account '{accountName}' not found — SKIPPING.");
                    return null;
                }

                // Instrument lookup — same cache path as PlaceMarketOrder.
                Instrument instr;
                if (!_instrumentCache.TryGetValue(instrumentName, out instr))
                {
                    instr = Instrument.GetInstrument(instrumentName);
                    if (instr != null)
                        _instrumentCache.TryAdd(instrumentName, instr);
                }

                if (instr == null)
                {
                    _log($"PlaceWorkingOrder: instrument '{instrumentName}' not found in NT8 — SKIPPING.");
                    return null;
                }

                // Map orderType string -> NT8 OrderType + resolve which price fields apply.
                OrderType ntOrderType;
                double effectiveLimitPrice = 0;
                double effectiveStopPrice  = 0;

                string normalizedType = orderType?.Trim().ToLowerInvariant();
                if (normalizedType == "limit")
                {
                    ntOrderType = OrderType.Limit;
                    effectiveLimitPrice = limitPrice;
                }
                else if (normalizedType == "stop")
                {
                    ntOrderType = OrderType.StopMarket;
                    effectiveStopPrice = stopPrice;
                }
                else if (normalizedType == "stoplimit")
                {
                    ntOrderType = OrderType.StopLimit;
                    effectiveLimitPrice = limitPrice;
                    effectiveStopPrice  = stopPrice;
                }
                else if (normalizedType == "mit")
                {
                    // MIT (Market-If-Touched) — trigger price rides the stop-price
                    // field, same NT8 convention as a plain stop; no limit price.
                    ntOrderType = OrderType.MIT;
                    effectiveStopPrice = stopPrice;
                }
                else
                {
                    _log($"PlaceWorkingOrder: unknown orderType '{orderType}' — SKIPPING.");
                    return null;
                }

                OrderAction action = isBuy ? OrderAction.Buy : OrderAction.Sell;

                // Leader TIF mirroring (v1): "gtc" → TimeInForce.Gtc, anything else
                // (including null/unrecognized) normalizes to TimeInForce.Day. The
                // gtd arg below stays Globals.MaxDate regardless — that is correct
                // for both Day and Gtc orders in NT8's CreateOrder signature.
                TimeInForce effectiveTif = (tif != null && tif.Trim().ToLowerInvariant() == "gtc")
                    ? TimeInForce.Gtc
                    : TimeInForce.Day;

                _log($"PlaceWorkingOrder: {action} {quantity} {instrumentName} ({normalizedType}) " +
                     $"on '{accountName}' (limit={effectiveLimitPrice}, stop={effectiveStopPrice}, tif={effectiveTif}).");

                // Same 12-arg CreateOrder signature used by PlaceMarketOrder/FlattenAll.
                Order order = acct.CreateOrder(
                    instr,
                    action,
                    ntOrderType,
                    OrderEntry.Automated,
                    effectiveTif,
                    quantity,
                    effectiveLimitPrice,
                    effectiveStopPrice,
                    oco ?? string.Empty,                  // oco id — follower OCO group (mirrors leader's grouping)
                    orderName,                            // name — visible in Executions tab
                    NinjaTrader.Core.Globals.MaxDate,     // gtd
                    null                                  // customOrder
                );

                if (order == null)
                {
                    _log($"PlaceWorkingOrder: CreateOrder returned null for {instrumentName} — SKIPPING.");
                    return null;
                }

                acct.Submit(new[] { order });

                return order.Id.ToString();
            }
            catch (Exception ex)
            {
                _log($"PlaceWorkingOrder error for '{accountName}/{instrumentName}': {ex.Message}");
                return null;
            }
        }

        public bool ModifyWorkingOrder(string accountName, string orderId, int newQuantity, double newLimitPrice, double newStopPrice)
        {
            if (string.IsNullOrWhiteSpace(orderId))
            {
                _log("ModifyWorkingOrder: orderId is null/empty — SKIPPING.");
                return false;
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"ModifyWorkingOrder: account '{accountName}' not found — SKIPPING.");
                    return false;
                }

                // Find the live order under lock, same pattern as CancelAllOrders.
                Order order = null;
                lock (Account.All)
                {
                    foreach (Order o in acct.Orders)
                    {
                        if (string.Equals(o.Id.ToString(), orderId, StringComparison.OrdinalIgnoreCase)
                            && IsLiveOrderState(o.OrderState))
                        {
                            order = o;
                            break;
                        }
                    }
                }

                if (order == null)
                {
                    _log($"ModifyWorkingOrder: no live order '{orderId}' found on '{accountName}' — SKIPPING.");
                    return false;
                }

                // NT8 change semantics: Account.Change() reads the *Changed properties,
                // NOT Quantity/LimitPrice/StopPrice. Setting the plain properties submits
                // a no-op change (old values) — the broker keeps the original prices while
                // Change() "succeeds". Verified live 2026-07-02: follower stayed at its
                // placement price through 3 reported-ok modifies until this fix.
                order.QuantityChanged   = newQuantity   > 0 ? newQuantity   : order.Quantity;
                order.LimitPriceChanged = newLimitPrice > 0 ? newLimitPrice : order.LimitPrice;
                order.StopPriceChanged  = newStopPrice  > 0 ? newStopPrice  : order.StopPrice;

                _log($"ModifyWorkingOrder: submitting change for order '{orderId}' on '{accountName}' " +
                     $"(qty={newQuantity}, limit={newLimitPrice}, stop={newStopPrice}).");

                // Submit the change outside the lock, same pattern as CancelAllOrders/FlattenAll.
                acct.Change(new[] { order });

                return true;
            }
            catch (Exception ex)
            {
                _log($"ModifyWorkingOrder error for '{accountName}/{orderId}': {ex.Message}");
                return false;
            }
        }

        public bool CancelWorkingOrder(string accountName, string orderId)
        {
            if (string.IsNullOrWhiteSpace(orderId))
            {
                _log("CancelWorkingOrder: orderId is null/empty — SKIPPING.");
                return false;
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"CancelWorkingOrder: account '{accountName}' not found — SKIPPING.");
                    return false;
                }

                // Scan WITHOUT the IsLiveOrderState filter so an order that has already
                // reached a terminal state (Cancelled/Filled/Rejected — e.g. an OCO
                // sibling auto-cancelled by the broker before our cancel arrived) is
                // still found and can be treated as an already-satisfied cancel instead
                // of a false "no live order" failure.
                Order order = null;
                lock (Account.All)
                {
                    foreach (Order o in acct.Orders)
                    {
                        if (string.Equals(o.Id.ToString(), orderId, StringComparison.OrdinalIgnoreCase))
                        {
                            order = o;
                            break;
                        }
                    }
                }

                if (order == null)
                {
                    _log($"CancelWorkingOrder: no order '{orderId}' found on '{accountName}' — SKIPPING.");
                    return false;
                }

                if (!IsLiveOrderState(order.OrderState))
                {
                    if (order.OrderState == OrderState.Cancelled
                        || order.OrderState == OrderState.Filled
                        || order.OrderState == OrderState.Rejected)
                    {
                        _log($"CancelWorkingOrder: order '{orderId}' on '{accountName}' is " +
                             $"already terminal ({order.OrderState}) — treating as success.");
                        return true;
                    }

                    _log($"CancelWorkingOrder: no live order '{orderId}' found on '{accountName}' — SKIPPING.");
                    return false;
                }

                _log($"CancelWorkingOrder: cancelling order '{orderId}' on '{accountName}'.");

                acct.Cancel(new[] { order });

                return true;
            }
            catch (Exception ex)
            {
                _log($"CancelWorkingOrder error for '{accountName}/{orderId}': {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// SYNCHARD (v1.10.0): finds the order using the SAME unfiltered scan
        /// CancelWorkingOrder uses (so a terminal order is still found rather than
        /// silently treated as "gone"), then returns true only if it is found AND
        /// still in a live state. Never throws — any error returns false.
        /// </summary>
        public bool IsOrderLive(string accountName, string orderId)
        {
            if (string.IsNullOrWhiteSpace(orderId)) return false;

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return false;

                Order order = null;
                lock (Account.All)
                {
                    foreach (Order o in acct.Orders)
                    {
                        if (string.Equals(o.Id.ToString(), orderId, StringComparison.OrdinalIgnoreCase))
                        {
                            order = o;
                            break;
                        }
                    }
                }

                if (order == null) return false;

                return IsLiveOrderState(order.OrderState);
            }
            catch (Exception ex)
            {
                _log($"IsOrderLive error for '{accountName}/{orderId}': {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Polls the order until it leaves live states or timeoutMs elapses. Returns
        /// "cancelled"|"filled"|"rejected"|"gone"|"timeout". Never throws.
        /// Background threads only — never the NT thread (this method blocks via
        /// Thread.Sleep, which would freeze the NT8 UI thread if called there).
        /// </summary>
        public string AwaitOrderTerminal(string accountName, string orderId, int timeoutMs)
        {
            if (string.IsNullOrWhiteSpace(orderId))
            {
                _log("AwaitOrderTerminal: orderId is null/empty — returning 'gone'.");
                return "gone";
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"AwaitOrderTerminal: account '{accountName}' not found — returning 'gone'.");
                    return "gone";
                }

                DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);

                while (true)
                {
                    Order order = null;
                    lock (Account.All)
                    {
                        foreach (Order o in acct.Orders)
                        {
                            if (string.Equals(o.Id.ToString(), orderId, StringComparison.OrdinalIgnoreCase))
                            {
                                order = o;
                                break;
                            }
                        }
                    }

                    if (order == null)
                        return "gone";

                    if (order.OrderState == OrderState.Cancelled) return "cancelled";
                    if (order.OrderState == OrderState.Filled)    return "filled";
                    if (order.OrderState == OrderState.Rejected)  return "rejected";

                    if (!IsLiveOrderState(order.OrderState))
                        return "gone";

                    if (DateTime.UtcNow >= deadline)
                        return "timeout";

                    Thread.Sleep(50);
                }
            }
            catch (Exception ex)
            {
                _log($"AwaitOrderTerminal error for '{accountName}/{orderId}': {ex.Message}");
                return "timeout";
            }
        }

        /// <summary>
        /// True if the given OrderState is still "live" (working/resting/in-flight
        /// and therefore eligible for modify/cancel). Mirrors the state set used by
        /// CancelAllOrders plus ChangeSubmitted/PartFilled (an order can be modified
        /// or cancelled while a prior change is in flight or partially filled).
        /// </summary>
        private static bool IsLiveOrderState(OrderState state)
        {
            return state == OrderState.Working
                || state == OrderState.Accepted
                || state == OrderState.Submitted
                || state == OrderState.ChangeSubmitted
                || state == OrderState.PartFilled;
        }

        /// <summary>
        /// Maps NT8 OrderType -> "limit"|"stop"|"stoplimit"|"mit"|"market"|"other".
        /// Factored out of SubscribeOrders (pure refactor — same mapping, byte-identical
        /// output) so GetWorkingOrders can share it.
        ///
        /// VERIFY (NT8 API): the NinjaTrader.Cbi.OrderType enum member for a
        /// plain stop-market order is used here as OrderType.StopMarket
        /// (matches the enum name used in PlaceWorkingOrder). If this
        /// NT8 version instead names it OrderType.Stop, rename both spots —
        /// they must stay in sync so a working order this adapter places is
        /// correctly reported back through SubscribeOrders.
        /// </summary>
        private static string MapOrderType(OrderType orderType)
        {
            if (orderType == OrderType.Limit) return "limit";
            if (orderType == OrderType.StopMarket) return "stop";
            if (orderType == OrderType.StopLimit) return "stoplimit";
            if (orderType == OrderType.Market) return "market";
            // VERIFY (NT8 API): MIT (Market-If-Touched) is reported here as
            // OrderType.MIT, matching the enum member used in PlaceWorkingOrder.
            // The trigger price for an MIT rides Order.StopPrice (NT8
            // convention, same field a plain stop uses) — see the "mit" branch
            // in CopierEngine.ProcessOrderPlacement for the price mapping.
            if (orderType == OrderType.MIT) return "mit";
            return "other";
        }

        /// <summary>
        /// Maps NT8 OrderState -> "working"|"accepted"|"submitted"|"changesubmitted"|
        /// "partfilled"|"filled"|"cancelled"|"rejected"|"other". Factored out of
        /// SubscribeOrders (pure refactor — same mapping, byte-identical output) so
        /// GetWorkingOrders can share it.
        /// </summary>
        private static string MapOrderState(OrderState orderState)
        {
            if (orderState == OrderState.Working) return "working";
            if (orderState == OrderState.Accepted) return "accepted";
            if (orderState == OrderState.Submitted) return "submitted";
            if (orderState == OrderState.ChangeSubmitted) return "changesubmitted";
            if (orderState == OrderState.PartFilled) return "partfilled";
            if (orderState == OrderState.Filled) return "filled";
            if (orderState == OrderState.Cancelled) return "cancelled";
            if (orderState == OrderState.Rejected) return "rejected";
            return "other";
        }

        /// <summary>
        /// Maps NT8 TimeInForce -> "day"|"gtc". Factored out of SubscribeOrders (pure
        /// refactor — same mapping, byte-identical output) so GetWorkingOrders can
        /// share it.
        ///
        /// VERIFY (NT8 API): Order.TimeInForce.Gtc is the enum member for
        /// Good-Till-Cancelled; anything else (Day and any other NT8 TIF we don't
        /// explicitly mirror in v1) normalizes to "day".
        /// </summary>
        private static string MapTif(TimeInForce tif)
        {
            return (tif == TimeInForce.Gtc) ? "gtc" : "day";
        }

        // -----------------------------------------------------------------------
        // Private helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Finds an NT8 Account by name. Returns null if not found (never throws).
        /// Caller is responsible for null-checking.
        ///
        /// Cache path: checks _accountCache first to avoid acquiring lock(Account.All)
        /// on every call. On cache miss the locked linear scan runs as before, and the
        /// result is stored so subsequent calls for the same name are O(1).
        /// Account objects are stable for the NT session — the cache never goes stale.
        /// </summary>
        private Account FindAccount(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return null;

            // Fast path: return cached Account without acquiring the NT8 lock.
            if (_accountCache.TryGetValue(accountName, out Account cached))
                return cached;

            try
            {
                Account found;
                lock (Account.All)
                {
                    found = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, accountName, StringComparison.OrdinalIgnoreCase));
                }

                if (found != null)
                {
                    // Cache under the REQUESTED name (may differ in casing from found.Name).
                    // Use TryAdd so two concurrent callers racing on the same name are safe.
                    _accountCache.TryAdd(accountName, found);
                }

                return found;
            }
            catch (Exception ex)
            {
                _log($"FindAccount error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // StartLockGuard / StopLockGuard (WI-3)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Bookkeeping record for one active lock guard on an account.
        /// Holds the Account reference and both event handlers so they can be
        /// individually unhooked on StopLockGuard.
        /// </summary>
        private sealed class GuardReg
        {
            public Account                           Acct           { get; set; }
            public EventHandler<OrderEventArgs>      OnOrderHandler { get; set; }
            public EventHandler<PositionEventArgs>   OnPosHandler   { get; set; }
            public System.Func<bool>                 StillLocked    { get; set; }
        }

        // Thread-safe dictionary: accountName (lower) → active GuardReg.
        // VERIFY (NT8 API): OrderEventArgs and PositionEventArgs are in
        // NinjaTrader.Cbi (same namespace as Account, Order, Position).
        // Account.OrderUpdate is EventHandler<OrderEventArgs>.
        // Account.PositionUpdate is EventHandler<PositionEventArgs>.
        private readonly ConcurrentDictionary<string, GuardReg> _lockGuards =
            new ConcurrentDictionary<string, GuardReg>(StringComparer.OrdinalIgnoreCase);

        public void StartLockGuard(string accountName, System.Func<bool> stillLocked)
        {
            if (string.IsNullOrWhiteSpace(accountName) || stillLocked == null) return;

            try
            {
                // If already guarding, just update the delegate and return.
                if (_lockGuards.TryGetValue(accountName, out GuardReg existing))
                {
                    existing.StillLocked = stillLocked;
                    _log($"StartLockGuard: updated stillLocked delegate for '{accountName}'.");
                    return;
                }

                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"StartLockGuard: account '{accountName}' not found — cannot install guard.");
                    return;
                }

                // Immediate protective action before events can race: cancel then flatten.
                // ORDER MATTERS: cancel orders first so our own flatten orders (submitted
                // below) are not immediately cancelled by CancelAllOrders.
                CancelAllOrders(accountName);
                FlattenAll(accountName);

                // Build the registration object first so handlers can close over it.
                var reg = new GuardReg { Acct = acct, StillLocked = stillLocked };

                // Order guard: cancel any non-Finotaur live order while lock is active.
                // VERIFY (NT8 API): OrderEventArgs.Order is NinjaTrader.Cbi.Order.
                // OrderState enum values used:
                //   OrderState.Submitted      — sent to broker, awaiting acknowledgement
                //   OrderState.Accepted       — broker acknowledged, not yet on book
                //   OrderState.Working        — resting on the order book
                //   OrderState.ChangeSubmitted— a modify was submitted for this order
                //   OrderState.TriggerPending — OCO/OSO trigger is pending
                //   OrderState.PartFilled     — partially filled (still live remainder)
                // VERIFY (NT8 API): confirm TriggerPending and ChangeSubmitted exist
                // in the NinjaTrader.Cbi.OrderState enum for this NT8 version.
                // If they do not compile, remove them — the remaining states are sufficient.
                EventHandler<OrderEventArgs> onOrder = (sender, e) =>
                {
                    try
                    {
                        if (!reg.StillLocked()) { StopLockGuard(accountName); return; }
                        Order o = e.Order;
                        if (o == null) return;

                        bool isLive =
                            o.OrderState == OrderState.Submitted      ||
                            o.OrderState == OrderState.Accepted       ||
                            o.OrderState == OrderState.Working        ||
                            o.OrderState == OrderState.ChangeSubmitted||
                            o.OrderState == OrderState.TriggerPending ||
                            o.OrderState == OrderState.PartFilled;

                        if (!isLive) return;

                        // Skip our own flatten/exit orders (name starts with "Finotaur").
                        if (o.Name != null && o.Name.StartsWith("Finotaur",
                                StringComparison.Ordinal)) return;

                        _log($"LockGuard '{accountName}': cancelling non-Finotaur order " +
                             $"'{o.Name}' (state={o.OrderState}).");
                        try { acct.Cancel(new[] { o }); }
                        catch (Exception cancelEx)
                        {
                            _log($"LockGuard '{accountName}': cancel failed — {cancelEx.Message}.");
                        }
                    }
                    catch (Exception ex)
                    {
                        _log($"LockGuard onOrder error for '{accountName}': {ex.Message}");
                    }
                };

                // Position guard: submit an offsetting market order whenever a
                // non-Flat position appears while the lock is active.
                // VERIFY (NT8 API): PositionEventArgs.Position is NinjaTrader.Cbi.Position.
                // Position.MarketPosition (enum MarketPosition) values: Flat, Long, Short.
                // We reuse the same CreateOrder+Submit path as FlattenAll — order name
                // "FinotaurLockFlatten" so the order guard above skips it (starts "Finotaur").
                EventHandler<PositionEventArgs> onPos = (sender, e) =>
                {
                    try
                    {
                        if (!reg.StillLocked()) { StopLockGuard(accountName); return; }
                        Position p = e.Position;
                        if (p == null) return;
                        if (p.MarketPosition == MarketPosition.Flat) return;
                        if (p.Instrument == null || p.Quantity <= 0) return;

                        OrderAction action = p.MarketPosition == MarketPosition.Long
                            ? OrderAction.Sell
                            : OrderAction.Buy;

                        _log($"LockGuard '{accountName}': non-Flat position detected " +
                             $"({p.MarketPosition} {p.Quantity} {p.Instrument.FullName}) " +
                             "— submitting FinotaurLockFlatten.");
                        try
                        {
                            Order flatOrder = acct.CreateOrder(
                                p.Instrument,
                                action,
                                OrderType.Market,
                                OrderEntry.Automated,
                                TimeInForce.Day,
                                p.Quantity,
                                0,
                                0,
                                string.Empty,
                                "FinotaurLockFlatten",
                                NinjaTrader.Core.Globals.MaxDate,
                                null);

                            if (flatOrder != null)
                                acct.Submit(new[] { flatOrder });
                        }
                        catch (Exception flatEx)
                        {
                            _log($"LockGuard '{accountName}': flatten submit failed — {flatEx.Message}.");
                        }
                    }
                    catch (Exception ex)
                    {
                        _log($"LockGuard onPos error for '{accountName}': {ex.Message}");
                    }
                };

                reg.OnOrderHandler = onOrder;
                reg.OnPosHandler   = onPos;

                // Register guard and subscribe.
                _lockGuards[accountName] = reg;
                acct.OrderUpdate    += onOrder;
                acct.PositionUpdate += onPos;

                _log($"StartLockGuard: guard installed on '{accountName}'.");
            }
            catch (Exception ex)
            {
                _log($"StartLockGuard error for '{accountName}': {ex.Message}");
            }
        }

        public void StopLockGuard(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return;

            try
            {
                if (!_lockGuards.TryRemove(accountName, out GuardReg reg)) return;

                // Unhook both event handlers.
                if (reg.OnOrderHandler != null)
                    reg.Acct.OrderUpdate -= reg.OnOrderHandler;
                if (reg.OnPosHandler != null)
                    reg.Acct.PositionUpdate -= reg.OnPosHandler;

                _log($"StopLockGuard: guard removed from '{accountName}'.");
            }
            catch (Exception ex)
            {
                _log($"StopLockGuard error for '{accountName}': {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        private bool _disposed;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            // Unhook all remaining fill subscriptions.
            foreach (var kvp in _subscriptions)
            {
                try
                {
                    Account acct = FindAccount(kvp.Value.AccountName);
                    if (acct != null && kvp.Value.NtHandler != null)
                        acct.ExecutionUpdate -= kvp.Value.NtHandler;
                }
                catch { /* best-effort cleanup */ }
            }
            _subscriptions.Clear();
            _hookedAccounts.Clear();

            // Unhook all remaining working-order subscriptions.
            foreach (var kvp in _orderSubscriptions)
            {
                try
                {
                    Account acct = FindAccount(kvp.Value.AccountName);
                    if (acct != null && kvp.Value.NtHandler != null)
                        acct.OrderUpdate -= kvp.Value.NtHandler;
                }
                catch { /* best-effort cleanup */ }
            }
            _orderSubscriptions.Clear();

            // Unhook all remaining lock guards (WI-3).
            foreach (var kvp in _lockGuards)
            {
                try
                {
                    if (kvp.Value.OnOrderHandler != null)
                        kvp.Value.Acct.OrderUpdate -= kvp.Value.OnOrderHandler;
                    if (kvp.Value.OnPosHandler != null)
                        kvp.Value.Acct.PositionUpdate -= kvp.Value.OnPosHandler;
                }
                catch { /* best-effort cleanup */ }
            }
            _lockGuards.Clear();
        }
    }
}
