// =============================================================================
// Finotaur Agent — Bridge/MarketHub.cs
//
// ═══════════════════════════════════════════════════════════════════════════
// COMPLIANCE BOUNDARY (DO NOT REMOVE THIS COMMENT)
// ═══════════════════════════════════════════════════════════════════════════
//   • This bridge streams NT8 market data (trades + depth) to LOCALHOST
//     browser tabs only — BridgeServer binds IPAddress.Loopback and rejects
//     any connection whose Origin is not in its allowlist before the WS
//     handshake completes.
//   • It NEVER relays data to any third-party server and NEVER persists
//     market data to disk — everything here is in-memory, per-connection,
//     and discarded on disconnect (see Detach / Reset).
//   • Every stream rides on the SAME NT8 session's SAME live/sim market-data
//     subscription the user already holds with their own data vendor — this
//     bridge creates NO new entitlement, it only re-exposes ticks the NT8
//     instance already receives, to the SAME user's own browser tab.
//   • Access is gated by (a) a bearer token (BridgeAuth, validated by
//     BridgeSession before any subscribe is honored) and (b) the Origin
//     allowlist enforced in BridgeServer.
//   • FAIL-SAFE: every NT8 event handler registered here is wrapped in
//     try/catch. An exception inside a market-data callback is logged and
//     swallowed — it NEVER propagates into NT8's event-dispatch thread,
//     because the agent's prime directive is to never crash the host
//     platform.
//   • Subscribe/unsubscribe of Instrument.MarketData / Instrument.MarketDepth
//     is ALWAYS marshalled via instrument.Dispatcher.InvokeAsync, and every
//     hook (+=) has exactly one matching unhook (-=), ref-counted per
//     instrument across all connected clients — never a bare += without a
//     matching future -=.
// ═══════════════════════════════════════════════════════════════════════════
//
// DESIGN NOTE — depth conflation is PRICE-keyed, not position-index-keyed:
//   NT8 delivers MarketDepthEventArgs as positional ladder edits
//   (Add/Update/Remove at a 0-based Position). This hub applies those edits
//   to an ordered per-side list to reconstruct the live ladder, exactly as
//   NT8 describes it. For the OUTBOUND wire protocol, the ladder is then
//   projected into a price→qty map (top MaxDepthLevels rows per side) and
//   diffed against the last-broadcast map — because the wire contract
//   (depth_snapshot / depth_delta) is price-keyed. Diffing by raw position
//   index would be noisy: removing position 2 shifts every row below it,
//   which would make unrelated lower levels look "changed" even though
//   their price/qty never moved.
//
// VERIFY (NT8 API, flagged — NOT silently assumed):
//   Whether subscribing Instrument.MarketData.Update / .MarketDepth.Update
//   alone is sufficient to START a live data stream for an instrument that
//   has no other active subscriber (chart / Market Analyzer / DOM) open in
//   NT8, or whether NT8 requires an existing "watch" elsewhere first. If
//   trades/depth never arrive in practice for an instrument with no open
//   chart, this is the first thing to check against the NT8 SDK docs.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge
{
    /// <summary>Result of a MarketHub.Attach call.</summary>
    public sealed class MarketHubAttachResult
    {
        public bool   Success      { get; set; }
        public double TickSize     { get; set; }
        public string ErrorCode    { get; set; }
        public string ErrorMessage { get; set; }
    }

    /// <summary>
    /// Ref-counted, per-instrument NT8 market-data hub. Multiple BridgeSessions
    /// can subscribe to the same instrument; NT8 event handlers are hooked once
    /// per instrument (not once per client) and fanned out to all subscribers.
    /// </summary>
    public sealed class MarketHub
    {
        // -----------------------------------------------------------------------
        // Allowed instrument roots + symbol format "ROOT MM-YY"
        // -----------------------------------------------------------------------

        public static readonly string[] AllowedRoots = { "NQ", "ES", "MNQ", "MES" };

        private static readonly Regex SymbolRegex =
            new Regex(@"^(NQ|ES|MNQ|MES)\s\d{2}-\d{2}$", RegexOptions.Compiled);

        public static bool IsSymbolAllowed(string sym) =>
            !string.IsNullOrWhiteSpace(sym) && SymbolRegex.IsMatch(sym.Trim());

        // -----------------------------------------------------------------------
        // Conflation tuning — bridge-side choices, not NT8 API limits
        // -----------------------------------------------------------------------

        private const int TradeFlushMs   = 100;
        private const int DepthFlushMs   = 200;
        private const int MaxDepthLevels = 10; // top-of-book rows kept per side on the wire

        private readonly Action<string> _log;

        private readonly ConcurrentDictionary<string, InstrumentSub> _subs =
            new ConcurrentDictionary<string, InstrumentSub>(StringComparer.OrdinalIgnoreCase);

        private readonly Timer _tradeFlushTimer;
        private readonly Timer _depthFlushTimer;
        private int _flushingTrade; // Interlocked re-entrancy guards
        private int _flushingDepth;

        public MarketHub(Action<string> logger = null)
        {
            _log = logger ?? (m => System.Diagnostics.Debug.WriteLine($"[MarketHub] {m}"));
            _tradeFlushTimer = new Timer(_ => FlushTrades(), null, TradeFlushMs, TradeFlushMs);
            _depthFlushTimer = new Timer(_ => FlushDepth(), null, DepthFlushMs, DepthFlushMs);
        }

        // -----------------------------------------------------------------------
        // Instrument resolution (shared by subscribe + backfill)
        // -----------------------------------------------------------------------

        public Instrument ResolveInstrument(string sym)
        {
            try { return Instrument.GetInstrument(sym); }
            catch (Exception ex)
            {
                _log($"MarketHub.ResolveInstrument('{sym}') error: {ex.GetType().Name} — {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // Primary feed name (best-effort — see VERIFY note)
        // -----------------------------------------------------------------------

        /// <summary>
        /// VERIFY (NT8 API, flagged): NT8 does not expose one obvious "the
        /// market-data feed" object to an AddOn. This reuses the SAME proven
        /// property chain already used by NinjaTraderAdapter.GetAccounts()
        /// (acct.Connection?.Options?.Name) as a pragmatic proxy: the connection
        /// profile name of the first connected account. If NT8 exposes a more
        /// direct market-data-connection concept, prefer that instead.
        /// </summary>
        public string GetPrimaryFeedName()
        {
            try
            {
                lock (Account.All)
                {
                    foreach (Account acct in Account.All)
                    {
                        Connection conn = acct.Connection;
                        if (conn != null && conn.Status == ConnectionStatus.Connected)
                            return conn.Options?.Name ?? "unknown";
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"MarketHub.GetPrimaryFeedName error: {ex.GetType().Name} — {ex.Message}");
            }
            return "unknown";
        }

        // -----------------------------------------------------------------------
        // Attach / Detach
        // -----------------------------------------------------------------------

        public MarketHubAttachResult Attach(BridgeSession client, string sym, bool wantTrades, bool wantDepth)
        {
            try
            {
                string key = sym.Trim().ToUpperInvariant();
                InstrumentSub sub = _subs.GetOrAdd(key, _ => new InstrumentSub { Sym = key });

                lock (sub.Gate)
                {
                    if (sub.Instrument == null)
                    {
                        Instrument instr = ResolveInstrument(sym);
                        if (instr == null)
                        {
                            // Nothing was hooked yet for this brand-new entry — safe to drop it.
                            _subs.TryRemove(key, out _);
                            return new MarketHubAttachResult { Success = false, ErrorCode = "no_instrument" };
                        }

                        sub.Instrument = instr;
                        try { sub.TickSize = instr.MasterInstrument.TickSize; }
                        catch { sub.TickSize = 0.25; /* NQ/ES/MNQ/MES conventional default */ }
                    }

                    if (wantTrades && sub.TradeSubscribers.Add(client) && sub.TradeSubscribers.Count == 1)
                        HookTrades(sub);

                    if (wantDepth && !sub.DepthCaughtUp.ContainsKey(client))
                    {
                        bool wasEmpty = sub.DepthCaughtUp.Count == 0;
                        sub.DepthCaughtUp[client] = false; // gets a full snapshot on the next depth flush
                        if (wasEmpty)
                            HookDepth(sub);
                    }

                    return new MarketHubAttachResult { Success = true, TickSize = sub.TickSize };
                }
            }
            catch (Exception ex)
            {
                _log($"MarketHub.Attach('{sym}') error: {ex.GetType().Name} — {ex.Message}");
                return new MarketHubAttachResult { Success = false, ErrorCode = "internal_error", ErrorMessage = ex.Message };
            }
        }

        public void Detach(BridgeSession client, string sym)
        {
            if (string.IsNullOrWhiteSpace(sym)) return;
            string key = sym.Trim().ToUpperInvariant();

            if (!_subs.TryGetValue(key, out InstrumentSub sub)) return;

            try
            {
                lock (sub.Gate)
                {
                    bool hadTrades = sub.TradeSubscribers.Remove(client);
                    if (hadTrades && sub.TradeSubscribers.Count == 0)
                        UnhookTrades(sub);

                    bool hadDepth = sub.DepthCaughtUp.Remove(client);
                    if (hadDepth && sub.DepthCaughtUp.Count == 0)
                        UnhookDepth(sub);

                    if (sub.TradeSubscribers.Count == 0 && sub.DepthCaughtUp.Count == 0)
                        _subs.TryRemove(key, out _);
                }
            }
            catch (Exception ex)
            {
                _log($"MarketHub.Detach('{sym}') error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        /// <summary>Force-unhooks every remaining subscription. Called when the bridge server stops.</summary>
        public void Reset()
        {
            foreach (var kvp in _subs)
            {
                InstrumentSub sub = kvp.Value;
                try
                {
                    lock (sub.Gate)
                    {
                        if (sub.TradeSubscribers.Count > 0) UnhookTrades(sub);
                        if (sub.DepthCaughtUp.Count > 0) UnhookDepth(sub);
                        sub.TradeSubscribers.Clear();
                        sub.DepthCaughtUp.Clear();
                    }
                }
                catch (Exception ex)
                {
                    _log($"MarketHub.Reset('{kvp.Key}') error: {ex.GetType().Name} — {ex.Message}");
                }
            }
            _subs.Clear();
        }

        // -----------------------------------------------------------------------
        // NT8 event hook/unhook — ALWAYS via instrument.Dispatcher.InvokeAsync,
        // ALWAYS a matched Hook->Unhook pair.
        // -----------------------------------------------------------------------

        private void HookTrades(InstrumentSub sub)
        {
            EventHandler<MarketDataEventArgs> handler = (sender, e) => OnMarketData(sub, e);
            sub.MdHandler = handler;

            try
            {
                sub.Instrument.Dispatcher.InvokeAsync(() =>
                {
                    try { sub.Instrument.MarketData.Update += handler; }
                    catch (Exception ex) { _log($"MarketHub.HookTrades('{sub.Sym}') dispatcher error: {ex.Message}"); }
                });
            }
            catch (Exception ex)
            {
                _log($"MarketHub.HookTrades('{sub.Sym}') error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        private void UnhookTrades(InstrumentSub sub)
        {
            if (sub.MdHandler == null) return;
            EventHandler<MarketDataEventArgs> handler = sub.MdHandler;
            sub.MdHandler = null;

            try
            {
                sub.Instrument.Dispatcher.InvokeAsync(() =>
                {
                    try { sub.Instrument.MarketData.Update -= handler; }
                    catch (Exception ex) { _log($"MarketHub.UnhookTrades('{sub.Sym}') dispatcher error: {ex.Message}"); }
                });
            }
            catch (Exception ex)
            {
                _log($"MarketHub.UnhookTrades('{sub.Sym}') error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        private void HookDepth(InstrumentSub sub)
        {
            EventHandler<MarketDepthEventArgs> handler = (sender, e) => OnMarketDepth(sub, e);
            sub.DepthHandler = handler;

            try
            {
                sub.Instrument.Dispatcher.InvokeAsync(() =>
                {
                    try { sub.Instrument.MarketDepth.Update += handler; }
                    catch (Exception ex) { _log($"MarketHub.HookDepth('{sub.Sym}') dispatcher error: {ex.Message}"); }
                });
            }
            catch (Exception ex)
            {
                _log($"MarketHub.HookDepth('{sub.Sym}') error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        private void UnhookDepth(InstrumentSub sub)
        {
            if (sub.DepthHandler == null) return;
            EventHandler<MarketDepthEventArgs> handler = sub.DepthHandler;
            sub.DepthHandler = null;

            try
            {
                sub.Instrument.Dispatcher.InvokeAsync(() =>
                {
                    try { sub.Instrument.MarketDepth.Update -= handler; }
                    catch (Exception ex) { _log($"MarketHub.UnhookDepth('{sub.Sym}') dispatcher error: {ex.Message}"); }
                });
            }
            catch (Exception ex)
            {
                _log($"MarketHub.UnhookDepth('{sub.Sym}') error: {ex.GetType().Name} — {ex.Message}");
            }

            // Ladder state is stale once unhooked — reset so a future re-subscribe
            // starts clean (a fresh depth_snapshot) instead of replaying an old book.
            sub.Bids.Clear();
            sub.Asks.Clear();
            sub.LastBroadcastBids.Clear();
            sub.LastBroadcastAsks.Clear();
        }

        // -----------------------------------------------------------------------
        // L1 — trades (Last ticks only)
        // -----------------------------------------------------------------------

        private void OnMarketData(InstrumentSub sub, MarketDataEventArgs e)
        {
            try
            {
                if (e.MarketDataType != MarketDataType.Last) return;

                double price  = e.Price;
                double qty    = e.Volume;
                long   timeMs = ToUnixMs(e.Time);

                int side;
                lock (sub.Gate)
                {
                    // Aggressor classification: at/through the prevailing ask = buy,
                    // at/through the prevailing bid = sell, otherwise tick rule vs
                    // the previous trade price (unchanged price carries the previous side).
                    if (e.Ask > 0 && price >= e.Ask) side = 1;
                    else if (e.Bid > 0 && price <= e.Bid) side = -1;
                    else if (sub.LastTradePrice.HasValue)
                    {
                        if (price > sub.LastTradePrice.Value) side = 1;
                        else if (price < sub.LastTradePrice.Value) side = -1;
                        else side = sub.LastTradeSide;
                    }
                    else side = 0;

                    sub.LastTradePrice = price;
                    sub.LastTradeSide  = side;

                    sub.PendingTrades.Add(new object[] { timeMs, price, qty, side });
                }
            }
            catch (Exception ex)
            {
                // FAIL-SAFE: never let an exception escape into NT8's dispatch thread.
                _log($"MarketHub.OnMarketData('{sub.Sym}') error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        private void FlushTrades()
        {
            if (Interlocked.CompareExchange(ref _flushingTrade, 1, 0) != 0) return;
            try
            {
                foreach (var kvp in _subs)
                {
                    InstrumentSub sub = kvp.Value;
                    List<object[]> batch;
                    List<BridgeSession> recipients;

                    lock (sub.Gate)
                    {
                        if (sub.PendingTrades.Count == 0 || sub.TradeSubscribers.Count == 0) continue;
                        batch = sub.PendingTrades;
                        sub.PendingTrades = new List<object[]>();
                        recipients = new List<BridgeSession>(sub.TradeSubscribers);
                    }

                    var payload = new { t = "trades", sym = sub.Sym, d = batch };
                    foreach (BridgeSession client in recipients)
                    {
                        try { client.SendJson(payload); }
                        catch (Exception ex) { _log($"MarketHub.FlushTrades send error: {ex.Message}"); }
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"MarketHub.FlushTrades error: {ex.GetType().Name} — {ex.Message}");
            }
            finally
            {
                Interlocked.Exchange(ref _flushingTrade, 0);
            }
        }

        // -----------------------------------------------------------------------
        // L2 — depth (positional ladder in → price-keyed snapshot/delta out)
        // -----------------------------------------------------------------------

        private void OnMarketDepth(InstrumentSub sub, MarketDepthEventArgs e)
        {
            try
            {
                lock (sub.Gate)
                {
                    List<DepthLevel> levels = e.MarketDataType == MarketDataType.Bid ? sub.Bids : sub.Asks;
                    int pos = e.Position;

                    switch (e.Operation)
                    {
                        case Operation.Add:
                            if (pos >= 0 && pos <= levels.Count)
                                levels.Insert(pos, new DepthLevel { Price = e.Price, Volume = e.Volume });
                            break;

                        case Operation.Update:
                            if (pos >= 0 && pos < levels.Count)
                                levels[pos] = new DepthLevel { Price = e.Price, Volume = e.Volume };
                            break;

                        case Operation.Remove:
                            if (pos >= 0 && pos < levels.Count)
                                levels.RemoveAt(pos);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                // FAIL-SAFE: never let an exception escape into NT8's dispatch thread.
                _log($"MarketHub.OnMarketDepth('{sub.Sym}') error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        private void FlushDepth()
        {
            if (Interlocked.CompareExchange(ref _flushingDepth, 1, 0) != 0) return;
            try
            {
                foreach (var kvp in _subs)
                {
                    InstrumentSub sub = kvp.Value;

                    lock (sub.Gate)
                    {
                        if (sub.DepthCaughtUp.Count == 0) continue;

                        Dictionary<double, double> currentBids = ToTopMap(sub.Bids);
                        Dictionary<double, double> currentAsks = ToTopMap(sub.Asks);

                        var newSubscribers = new List<BridgeSession>();
                        var caughtUpSubscribers = new List<BridgeSession>();
                        foreach (var pair in sub.DepthCaughtUp.ToArray())
                        {
                            if (pair.Value) caughtUpSubscribers.Add(pair.Key);
                            else
                            {
                                newSubscribers.Add(pair.Key);
                                sub.DepthCaughtUp[pair.Key] = true;
                            }
                        }

                        List<object[]> bidDelta = DiffLevels(sub.LastBroadcastBids, currentBids);
                        List<object[]> askDelta = DiffLevels(sub.LastBroadcastAsks, currentAsks);

                        sub.LastBroadcastBids = currentBids;
                        sub.LastBroadcastAsks = currentAsks;

                        if (newSubscribers.Count > 0)
                        {
                            var snapshotPayload = new
                            {
                                t    = "depth_snapshot",
                                sym  = sub.Sym,
                                ts   = ToUnixMs(DateTime.UtcNow),
                                bids = ToPairs(currentBids),
                                asks = ToPairs(currentAsks)
                            };
                            foreach (BridgeSession client in newSubscribers)
                            {
                                try { client.SendJson(snapshotPayload); }
                                catch (Exception ex) { _log($"MarketHub.FlushDepth snapshot send error: {ex.Message}"); }
                            }
                        }

                        if (caughtUpSubscribers.Count > 0 && (bidDelta.Count > 0 || askDelta.Count > 0))
                        {
                            var deltaPayload = new
                            {
                                t    = "depth_delta",
                                sym  = sub.Sym,
                                ts   = ToUnixMs(DateTime.UtcNow),
                                bids = bidDelta,
                                asks = askDelta
                            };
                            foreach (BridgeSession client in caughtUpSubscribers)
                            {
                                try { client.SendJson(deltaPayload); }
                                catch (Exception ex) { _log($"MarketHub.FlushDepth delta send error: {ex.Message}"); }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"MarketHub.FlushDepth error: {ex.GetType().Name} — {ex.Message}");
            }
            finally
            {
                Interlocked.Exchange(ref _flushingDepth, 0);
            }
        }

        private static Dictionary<double, double> ToTopMap(List<DepthLevel> levels)
        {
            var map = new Dictionary<double, double>();
            int count = Math.Min(levels.Count, MaxDepthLevels);
            for (int i = 0; i < count; i++)
                map[levels[i].Price] = levels[i].Volume;
            return map;
        }

        private static List<object[]> ToPairs(Dictionary<double, double> map)
        {
            var list = new List<object[]>(map.Count);
            foreach (var kv in map)
                list.Add(new object[] { kv.Key, kv.Value });
            return list;
        }

        private static List<object[]> DiffLevels(Dictionary<double, double> previous, Dictionary<double, double> current)
        {
            var diff = new List<object[]>();

            foreach (var kv in current)
            {
                double prevQty;
                if (!previous.TryGetValue(kv.Key, out prevQty) || prevQty != kv.Value)
                    diff.Add(new object[] { kv.Key, kv.Value });
            }

            foreach (var kv in previous)
            {
                if (!current.ContainsKey(kv.Key))
                    diff.Add(new object[] { kv.Key, 0.0 }); // qty 0 = removed level
            }

            return diff;
        }

        private static long ToUnixMs(DateTime t)
        {
            DateTime utc = t.Kind == DateTimeKind.Utc ? t : t.ToUniversalTime();
            return (long)(utc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
        }

        // -----------------------------------------------------------------------
        // Internal state
        // -----------------------------------------------------------------------

        private sealed class DepthLevel
        {
            public double Price;
            public double Volume;
        }

        private sealed class InstrumentSub
        {
            public string     Sym;
            public Instrument Instrument;
            public double     TickSize;
            public readonly object Gate = new object();

            // Trades
            public readonly HashSet<BridgeSession> TradeSubscribers = new HashSet<BridgeSession>();
            public EventHandler<MarketDataEventArgs> MdHandler;
            public List<object[]> PendingTrades = new List<object[]>();
            public double? LastTradePrice;
            public int     LastTradeSide;

            // Depth — value = true once that client has received its initial full snapshot.
            public readonly Dictionary<BridgeSession, bool> DepthCaughtUp = new Dictionary<BridgeSession, bool>();
            public EventHandler<MarketDepthEventArgs> DepthHandler;
            public List<DepthLevel> Bids = new List<DepthLevel>();
            public List<DepthLevel> Asks = new List<DepthLevel>();
            public Dictionary<double, double> LastBroadcastBids = new Dictionary<double, double>();
            public Dictionary<double, double> LastBroadcastAsks = new Dictionary<double, double>();
        }
    }
}
