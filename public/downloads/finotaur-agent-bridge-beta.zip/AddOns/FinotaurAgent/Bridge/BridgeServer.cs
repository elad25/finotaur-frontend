// =============================================================================
// Finotaur Agent — Bridge/BridgeServer.cs
//
// Loopback-only TCP/WebSocket listener for the market-data bridge.
// Tries ports 24888..24892 (first free wins). Each connection performs the
// WS upgrade handshake (WsFraming), is Origin-checked BEFORE the handshake
// completes, then hands off to a BridgeSession for protocol-level messages.
//
// THREADING:
//   • AcceptLoopAsync runs on a dedicated background Task.
//   • Each accepted connection is handled on its OWN Task (blocking reads) —
//     this bridge expects at most a handful of concurrent connections
//     (max 2 authed clients), so a thread-per-connection model is simple and
//     sufficient; no need for a fully async I/O pipeline.
//   • Each connection also gets a dedicated writer Task draining a
//     ConcurrentQueue<byte[]> outbox — producers (MarketHub flush timers,
//     BridgeSession replies) never block on socket I/O.
//   • A single HousekeepingLoopAsync Task handles the 15s ping / 45s idle
//     drop / 5s hello-timeout sweep for ALL connections.
//
// COMPLIANCE: see the boundary comment in Bridge/MarketHub.cs — this file is
// the network-facing half (loopback bind + Origin allowlist + auth-slot cap);
// MarketHub is the NT8-data half.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge
{
    // =========================================================================
    // BridgeSettingsStore — persisted on/off toggle for the bridge.
    // Lives in this file (not a separate file) to keep the Bridge/ file list
    // exactly as scoped; it mirrors Storage/TokenStore.cs's directory pattern
    // (same "Finotaur" subfolder under NinjaTrader's per-user data dir), just
    // a different filename so it never collides with agent.dat.
    // =========================================================================

    public static class BridgeSettingsStore
    {
        private const string SubFolder = "Finotaur";
        private const string FileName  = "bridge.dat";

        private static string FilePath
        {
            get
            {
                string ntDataDir;
                try { ntDataDir = NinjaTrader.Core.Globals.UserDataDir; }
                catch
                {
                    ntDataDir = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "NinjaTrader 8");
                }
                return System.IO.Path.Combine(ntDataDir, SubFolder, FileName);
            }
        }

        private class StoredSettings
        {
            [JsonProperty("enabled")]
            public bool Enabled { get; set; } = true;
        }

        /// <summary>Loads the persisted on/off toggle. Defaults to true (ON) if no file exists or on any error.</summary>
        public static bool LoadEnabled()
        {
            try
            {
                if (!System.IO.File.Exists(FilePath)) return true;
                string json = System.IO.File.ReadAllText(FilePath, Encoding.UTF8);
                StoredSettings settings = JsonConvert.DeserializeObject<StoredSettings>(json);
                return settings?.Enabled ?? true;
            }
            catch { return true; }
        }

        public static void SaveEnabled(bool enabled)
        {
            try
            {
                string dir = System.IO.Path.GetDirectoryName(FilePath);
                if (!System.IO.Directory.Exists(dir))
                    System.IO.Directory.CreateDirectory(dir);

                string json = JsonConvert.SerializeObject(new StoredSettings { Enabled = enabled });
                System.IO.File.WriteAllText(FilePath, json, Encoding.UTF8);
            }
            catch { /* best-effort persistence — non-fatal */ }
        }
    }

    // =========================================================================
    // BridgeServer
    // =========================================================================

    public sealed class BridgeServer
    {
        private static readonly int[] PortRange = { 24888, 24889, 24890, 24891, 24892 };
        private const int MaxAuthedClients = 2;
        private static readonly TimeSpan HandshakeReadTimeout = TimeSpan.FromSeconds(10);
        private static readonly TimeSpan IdleDropAfter = TimeSpan.FromSeconds(45);
        private static readonly TimeSpan PingEvery = TimeSpan.FromSeconds(15);

        private static readonly HashSet<string> AllowedOrigins = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "https://www.finotaur.com",
            "https://finotaur.com",
            "http://localhost:5173",
            "http://localhost:5177",
            "http://localhost:8788"
        };

        private sealed class ClientConnection
        {
            public Guid Id;
            public TcpClient TcpClient;
            public NetworkStream Stream;
            public BridgeSession Session;
            public readonly ConcurrentQueue<byte[]> Outbox = new ConcurrentQueue<byte[]>();
            public readonly SemaphoreSlim OutboxSignal = new SemaphoreSlim(0);
            public CancellationTokenSource Cts;
            public long LastActivityTicks;
            public long LastPingSentTicks;
            public volatile bool AuthedCounted;
        }

        private readonly Action<string> _log;
        private readonly string _agentVersion;
        private readonly MarketHub _hub;

        private readonly ConcurrentDictionary<Guid, ClientConnection> _clients =
            new ConcurrentDictionary<Guid, ClientConnection>();

        private TcpListener _listener;
        private CancellationTokenSource _serverCts;
        private Task _acceptTask;
        private Task _housekeepingTask;
        private int _authedCount;
        private volatile bool _isRunning;

        public int BoundPort { get; private set; }
        public bool IsRunning => _isRunning;
        public int AuthedClientCount => Volatile.Read(ref _authedCount);

        public BridgeServer(string agentVersion, Action<string> logger = null)
        {
            _agentVersion = agentVersion ?? "unknown";
            _log = logger ?? (m => System.Diagnostics.Debug.WriteLine($"[BridgeServer] {m}"));
            _hub = new MarketHub(_log);
        }

        // -----------------------------------------------------------------------
        // Start / Stop
        // -----------------------------------------------------------------------

        public bool Start()
        {
            if (_isRunning) return true;

            try
            {
                foreach (int port in PortRange)
                {
                    try
                    {
                        var listener = new TcpListener(IPAddress.Loopback, port);
                        listener.Start();
                        _listener = listener;
                        BoundPort = port;
                        break;
                    }
                    catch (SocketException)
                    {
                        continue; // port in use — try the next one
                    }
                }

                if (_listener == null)
                {
                    _log("BridgeServer: no free port in range 24888-24892 — bridge NOT started.");
                    return false;
                }

                _serverCts = new CancellationTokenSource();
                _acceptTask = Task.Run(() => AcceptLoopAsync(_serverCts.Token));
                _housekeepingTask = Task.Run(() => HousekeepingLoopAsync(_serverCts.Token));
                _isRunning = true;

                _log($"BridgeServer: listening on 127.0.0.1:{BoundPort}.");
                return true;
            }
            catch (Exception ex)
            {
                _log($"BridgeServer.Start error: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        public void Stop()
        {
            if (!_isRunning) return;
            _isRunning = false;

            try { _serverCts?.Cancel(); } catch { /* best-effort */ }
            try { _listener?.Stop(); } catch { /* best-effort */ }

            foreach (var kvp in _clients)
            {
                try { RequestClose(kvp.Value, 1001, "server_shutdown"); } catch { }
                try { kvp.Value.Cts.Cancel(); } catch { }
            }

            try { _acceptTask?.Wait(TimeSpan.FromSeconds(3)); } catch { /* best-effort */ }
            try { _housekeepingTask?.Wait(TimeSpan.FromSeconds(3)); } catch { /* best-effort */ }

            foreach (var kvp in _clients)
                CleanupClient(kvp.Value);

            _hub.Reset();
            _listener = null;
            BoundPort = 0;
            _log("BridgeServer: stopped.");
        }

        // -----------------------------------------------------------------------
        // Accept loop
        // -----------------------------------------------------------------------

        private async Task AcceptLoopAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                TcpClient tcpClient;
                try
                {
                    tcpClient = await _listener.AcceptTcpClientAsync().ConfigureAwait(false);
                }
                catch (ObjectDisposedException) { break; }
                catch (Exception ex)
                {
                    if (ct.IsCancellationRequested) break;
                    _log($"BridgeServer accept error: {ex.GetType().Name} — {ex.Message}");
                    continue;
                }

                var conn = new ClientConnection
                {
                    Id = Guid.NewGuid(),
                    TcpClient = tcpClient,
                    Cts = CancellationTokenSource.CreateLinkedTokenSource(ct)
                };
                TouchActivity(conn);
                _clients.TryAdd(conn.Id, conn);

                // Fire-and-forget per-client handling — failures are contained inside.
                _ = Task.Run(() => HandleClient(conn));
            }
        }

        // -----------------------------------------------------------------------
        // Per-client handling (handshake + reader loop, on a dedicated Task)
        // -----------------------------------------------------------------------

        private void HandleClient(ClientConnection conn)
        {
            Task writerTask = null;
            try
            {
                conn.Stream = conn.TcpClient.GetStream();
                try { conn.TcpClient.NoDelay = true; } catch { /* best-effort */ }
                conn.Stream.ReadTimeout = (int)HandshakeReadTimeout.TotalMilliseconds;

                WsUpgradeRequest req = WsFraming.ParseUpgradeRequest(conn.Stream);
                if (!req.IsValid)
                {
                    // Not a well-formed WS upgrade request — the outer finally block
                    // (CleanupClient) tears the socket down; nothing else to do here.
                    return;
                }

                if (!IsOriginAllowed(req.Origin))
                {
                    try
                    {
                        byte[] reject = WsFraming.BuildRejectResponse(403, "Forbidden");
                        conn.Stream.Write(reject, 0, reject.Length);
                    }
                    catch { /* best-effort */ }

                    _log($"BridgeServer: rejected connection from origin '{req.Origin ?? "(none)"}' — not in allowlist.");
                    return; // outer finally block (CleanupClient) tears the socket down
                }

                byte[] accept = WsFraming.BuildUpgradeResponse(req.SecWebSocketKey);
                conn.Stream.Write(accept, 0, accept.Length);

                // Handshake complete — frame reads block indefinitely; liveness is
                // enforced by the housekeeping loop's idle-drop, not a socket timeout.
                conn.Stream.ReadTimeout = System.Threading.Timeout.Infinite;
                TouchActivity(conn);

                conn.Session = new BridgeSession(
                    hub: _hub,
                    sendText: text => EnqueueOutbound(conn, WsFraming.EncodeText(text)),
                    requestClose: (code, reason) => RequestClose(conn, code, reason),
                    tryRegisterAuthed: () => TryRegisterAuthed(conn),
                    unregisterAuthed: () => UnregisterAuthed(conn),
                    agentVersion: _agentVersion,
                    log: _log);

                writerTask = Task.Run(() => WriterLoop(conn));

                ReaderLoop(conn);

                conn.Cts.Cancel();
                try { conn.OutboxSignal.Release(); } catch { /* may already be disposed-adjacent */ }
                try { writerTask.Wait(TimeSpan.FromSeconds(2)); } catch { /* best-effort */ }
            }
            catch (Exception ex)
            {
                _log($"BridgeServer.HandleClient error: {ex.GetType().Name} — {ex.Message}");
            }
            finally
            {
                CleanupClient(conn);
            }
        }

        private void ReaderLoop(ClientConnection conn)
        {
            try
            {
                while (!conn.Cts.IsCancellationRequested)
                {
                    WsFrame frame;
                    try
                    {
                        frame = WsFraming.ReadFrame(conn.Stream);
                    }
                    catch
                    {
                        // Socket closed, timed out, or protocol violation — end the loop.
                        break;
                    }

                    if (frame == null) break; // clean stream close at a frame boundary

                    TouchActivity(conn);

                    if (!frame.Fin || frame.Opcode == WsOpcode.Binary)
                    {
                        // Politely reject fragmented or binary frames — this bridge only
                        // ever expects single-frame text messages from the browser.
                        RequestClose(conn, 1003, "unsupported_frame");
                        break;
                    }

                    switch (frame.Opcode)
                    {
                        case WsOpcode.Text:
                            string json = Encoding.UTF8.GetString(frame.Payload);
                            try { conn.Session.HandleMessage(json); }
                            catch (Exception ex) { _log($"BridgeSession.HandleMessage error: {ex.GetType().Name} — {ex.Message}"); }
                            break;

                        case WsOpcode.Ping:
                            EnqueueOutbound(conn, WsFraming.EncodePong(frame.Payload));
                            break;

                        case WsOpcode.Pong:
                            // Activity already touched above — nothing else to do.
                            break;

                        case WsOpcode.Close:
                            RequestClose(conn, 1000, "client_close");
                            return; // client-initiated close — loop ends here

                        default:
                            RequestClose(conn, 1003, "unsupported_opcode");
                            return;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"BridgeServer.ReaderLoop error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        private void WriterLoop(ClientConnection conn)
        {
            try
            {
                while (true)
                {
                    try { conn.OutboxSignal.Wait(TimeSpan.FromSeconds(1)); }
                    catch (ObjectDisposedException) { break; }

                    // Drain whatever is queued regardless of why we woke up — this also
                    // guarantees a close frame enqueued right before cancellation still
                    // gets flushed before the loop exits.
                    bool streamDead = false;
                    while (conn.Outbox.TryDequeue(out byte[] frame))
                    {
                        try
                        {
                            conn.Stream.Write(frame, 0, frame.Length);
                        }
                        catch
                        {
                            // Stream is dead — stop attempting further writes for the
                            // remaining queued frames (they are discarded; the connection
                            // is going away regardless) and end the loop below.
                            conn.Cts.Cancel();
                            streamDead = true;
                            break;
                        }
                    }

                    if (streamDead) break;

                    if (conn.Cts.IsCancellationRequested && conn.Outbox.IsEmpty)
                        break;
                }
            }
            catch (Exception ex)
            {
                _log($"BridgeServer.WriterLoop error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Housekeeping — hello timeout, idle drop, app-level ping
        // -----------------------------------------------------------------------

        private async Task HousekeepingLoopAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    DateTime nowUtc = DateTime.UtcNow;

                    foreach (var kvp in _clients)
                    {
                        ClientConnection conn = kvp.Value;
                        if (conn.Session == null) continue; // still mid-handshake

                        if (!conn.Session.IsAuthed && nowUtc > conn.Session.HelloDeadlineUtc)
                        {
                            _log($"BridgeServer: client {conn.Id} did not send hello within 5s — closing.");
                            RequestClose(conn, 1008, "hello_timeout");
                            conn.Cts.Cancel();
                            continue;
                        }

                        DateTime lastActivity = new DateTime(Interlocked.Read(ref conn.LastActivityTicks), DateTimeKind.Utc);
                        if ((nowUtc - lastActivity) > IdleDropAfter)
                        {
                            _log($"BridgeServer: client {conn.Id} idle for 45s+ — dropping.");
                            RequestClose(conn, 1000, "idle_timeout");
                            conn.Cts.Cancel();
                            continue;
                        }

                        DateTime lastPing = new DateTime(Interlocked.Read(ref conn.LastPingSentTicks), DateTimeKind.Utc);
                        if (conn.Session.IsAuthed && (nowUtc - lastPing) >= PingEvery)
                        {
                            Interlocked.Exchange(ref conn.LastPingSentTicks, nowUtc.Ticks);
                            conn.Session.SendPing();
                        }
                    }
                }
                catch (Exception ex)
                {
                    _log($"BridgeServer.HousekeepingLoop error: {ex.GetType().Name} — {ex.Message}");
                }

                try { await Task.Delay(TimeSpan.FromSeconds(2), ct).ConfigureAwait(false); }
                catch (OperationCanceledException) { break; }
            }
        }

        // -----------------------------------------------------------------------
        // Outbound queueing + close
        // -----------------------------------------------------------------------

        private void EnqueueOutbound(ClientConnection conn, byte[] frame)
        {
            if (conn == null || frame == null) return;
            try
            {
                conn.Outbox.Enqueue(frame);
                conn.OutboxSignal.Release();
            }
            catch (ObjectDisposedException) { /* client tearing down concurrently — drop */ }
        }

        private void RequestClose(ClientConnection conn, ushort code, string reason)
        {
            try { EnqueueOutbound(conn, WsFraming.EncodeClose(code, reason)); }
            catch { /* best-effort */ }
        }

        private static void TouchActivity(ClientConnection conn)
        {
            Interlocked.Exchange(ref conn.LastActivityTicks, DateTime.UtcNow.Ticks);
        }

        private static bool IsOriginAllowed(string origin)
        {
            return !string.IsNullOrWhiteSpace(origin) && AllowedOrigins.Contains(origin.TrimEnd('/'));
        }

        // -----------------------------------------------------------------------
        // Authed-slot accounting (max 2 concurrent authed clients)
        // -----------------------------------------------------------------------

        private bool TryRegisterAuthed(ClientConnection conn)
        {
            if (conn.AuthedCounted) return true;
            int newCount = Interlocked.Increment(ref _authedCount);
            if (newCount > MaxAuthedClients)
            {
                Interlocked.Decrement(ref _authedCount);
                return false;
            }
            conn.AuthedCounted = true;
            return true;
        }

        private void UnregisterAuthed(ClientConnection conn)
        {
            if (conn == null || !conn.AuthedCounted) return;
            conn.AuthedCounted = false;
            Interlocked.Decrement(ref _authedCount);
        }

        // -----------------------------------------------------------------------
        // Cleanup
        // -----------------------------------------------------------------------

        private void CleanupClient(ClientConnection conn)
        {
            if (conn == null) return;

            try { conn.Session?.OnDisconnect(); } catch { /* best-effort */ }
            UnregisterAuthed(conn);
            _clients.TryRemove(conn.Id, out _);

            try { conn.Cts?.Cancel(); } catch { /* best-effort */ }
            try { conn.Stream?.Dispose(); } catch { /* best-effort */ }
            try { conn.TcpClient?.Close(); } catch { /* best-effort */ }
            try { conn.Cts?.Dispose(); } catch { /* best-effort */ }
            try { conn.OutboxSignal?.Dispose(); } catch { /* best-effort */ }
        }
    }
}
