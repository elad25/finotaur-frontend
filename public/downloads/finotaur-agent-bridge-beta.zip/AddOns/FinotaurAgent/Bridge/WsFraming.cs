// =============================================================================
// Finotaur Agent — Bridge/WsFraming.cs
//
// Minimal RFC 6455 WebSocket framing for the local market-data bridge:
//   • Server-side HTTP Upgrade handshake (parse request, build 101 response).
//   • Frame encode: server→client text/ping/pong/close, ALWAYS unmasked
//     (RFC 6455 forbids the server from masking).
//   • Frame decode: client→server text/ping/pong/close, ALWAYS masked
//     (RFC 6455 requires the client to mask — unmasked client frames would
//     be a protocol violation, but this bridge does not reject on that
//     basis; it XORs whatever mask key is present).
//
// SCOPE — deliberately minimal, matching the bridge's needs only:
//   • No permessage-deflate extension negotiation.
//   • No fragmentation on the wire — every server-emitted frame has FIN=1.
//   • Client frames that arrive fragmented (FIN=0) or as Binary opcode are
//     decoded here but the CALLER (BridgeServer) is responsible for
//     rejecting them with a clean Close — this file only decodes what is on
//     the wire, it does not enforce policy.
// =============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge
{
    /// <summary>Parsed HTTP upgrade request headers relevant to the WS handshake.</summary>
    public sealed class WsUpgradeRequest
    {
        public string SecWebSocketKey { get; set; }
        public string Origin { get; set; }

        /// <summary>True only if a Sec-WebSocket-Key header was present.</summary>
        public bool IsValid => !string.IsNullOrWhiteSpace(SecWebSocketKey);
    }

    /// <summary>Opcode of a WebSocket frame (subset used by the bridge).</summary>
    public enum WsOpcode
    {
        Text    = 0x1,
        Binary  = 0x2,
        Close   = 0x8,
        Ping    = 0x9,
        Pong    = 0xA,
        Unknown = 0xFF
    }

    /// <summary>A single decoded client→server WebSocket frame.</summary>
    public sealed class WsFrame
    {
        public bool     Fin     { get; set; }
        public WsOpcode Opcode  { get; set; }
        public byte[]   Payload { get; set; }
    }

    public static class WsFraming
    {
        private const string WsMagicGuid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

        // Defensive caps — never buffer unbounded memory for a malformed/hostile
        // client. Both values are generous for this protocol's actual traffic
        // (hello/subscribe/backfill JSON messages are a few hundred bytes).
        private const int MaxHttpHeaderLineLen = 8192;
        private const long MaxFramePayloadLen  = 1_000_000;

        // ---------------------------------------------------------------
        // Handshake
        // ---------------------------------------------------------------

        /// <summary>
        /// Reads and parses the raw HTTP Upgrade request line-by-line from the
        /// stream. Never throws — on any malformed input, returns a request with
        /// IsValid == false and the caller closes the connection.
        /// </summary>
        public static WsUpgradeRequest ParseUpgradeRequest(Stream stream)
        {
            var req = new WsUpgradeRequest();
            try
            {
                string requestLine = ReadHttpLine(stream);
                if (string.IsNullOrEmpty(requestLine)) return req;

                string line;
                while (!string.IsNullOrEmpty(line = ReadHttpLine(stream)))
                {
                    int idx = line.IndexOf(':');
                    if (idx <= 0) continue;

                    string name  = line.Substring(0, idx).Trim();
                    string value = line.Substring(idx + 1).Trim();

                    if (string.Equals(name, "Sec-WebSocket-Key", StringComparison.OrdinalIgnoreCase))
                        req.SecWebSocketKey = value;
                    else if (string.Equals(name, "Origin", StringComparison.OrdinalIgnoreCase))
                        req.Origin = value;
                }
            }
            catch
            {
                // Malformed/truncated request — IsValid stays false (SecWebSocketKey null).
            }
            return req;
        }

        /// <summary>Reads one CRLF-terminated ASCII line from the raw HTTP header stream.</summary>
        private static string ReadHttpLine(Stream stream)
        {
            var sb = new StringBuilder();
            int prev = -1;
            int b;
            while ((b = stream.ReadByte()) != -1)
            {
                if (prev == '\r' && b == '\n')
                {
                    if (sb.Length > 0 && sb[sb.Length - 1] == '\r')
                        sb.Length -= 1;
                    return sb.ToString();
                }
                sb.Append((char)b);
                prev = b;
                if (sb.Length > MaxHttpHeaderLineLen)
                    throw new IOException("HTTP header line too long.");
            }
            return null; // stream closed mid-header
        }

        /// <summary>Builds the raw bytes of the "101 Switching Protocols" handshake response.</summary>
        public static byte[] BuildUpgradeResponse(string secWebSocketKey)
        {
            string accept = ComputeAcceptKey(secWebSocketKey);
            string response =
                "HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                $"Sec-WebSocket-Accept: {accept}\r\n\r\n";
            return Encoding.ASCII.GetBytes(response);
        }

        /// <summary>Builds a raw plain-HTTP rejection response (used pre-handshake, e.g. origin block).</summary>
        public static byte[] BuildRejectResponse(int statusCode, string reason)
        {
            string response =
                $"HTTP/1.1 {statusCode} {reason}\r\n" +
                "Connection: close\r\n\r\n";
            return Encoding.ASCII.GetBytes(response);
        }

        private static string ComputeAcceptKey(string secWebSocketKey)
        {
            string combined = (secWebSocketKey ?? string.Empty) + WsMagicGuid;
            using (var sha1 = SHA1.Create())
            {
                byte[] hash = sha1.ComputeHash(Encoding.ASCII.GetBytes(combined));
                return Convert.ToBase64String(hash);
            }
        }

        // ---------------------------------------------------------------
        // Encoding — server → client (ALWAYS unmasked, per RFC 6455)
        // ---------------------------------------------------------------

        public static byte[] EncodeText(string payload)
        {
            byte[] data = Encoding.UTF8.GetBytes(payload ?? string.Empty);
            return EncodeFrame(WsOpcode.Text, data);
        }

        public static byte[] EncodePing(byte[] payload = null)
        {
            return EncodeFrame(WsOpcode.Ping, payload ?? Array.Empty<byte>());
        }

        public static byte[] EncodePong(byte[] payload)
        {
            return EncodeFrame(WsOpcode.Pong, payload ?? Array.Empty<byte>());
        }

        public static byte[] EncodeClose(ushort code, string reason)
        {
            byte[] reasonBytes = Encoding.UTF8.GetBytes(reason ?? string.Empty);
            byte[] payload = new byte[2 + reasonBytes.Length];
            payload[0] = (byte)(code >> 8);
            payload[1] = (byte)(code & 0xFF);
            Array.Copy(reasonBytes, 0, payload, 2, reasonBytes.Length);
            return EncodeFrame(WsOpcode.Close, payload);
        }

        private static byte[] EncodeFrame(WsOpcode opcode, byte[] payload)
        {
            int payloadLen = payload.Length;
            var header = new List<byte>(10);

            // Byte 0: FIN=1, RSV1-3=0, opcode in the low nibble.
            header.Add((byte)(0x80 | (byte)opcode));

            // Byte 1+: MASK=0 (server never masks) + payload length (125/126/127 variants).
            if (payloadLen < 126)
            {
                header.Add((byte)payloadLen);
            }
            else if (payloadLen <= 0xFFFF)
            {
                header.Add(126);
                header.Add((byte)(payloadLen >> 8));
                header.Add((byte)(payloadLen & 0xFF));
            }
            else
            {
                header.Add(127);
                for (int shift = 56; shift >= 0; shift -= 8)
                    header.Add((byte)(((long)payloadLen >> shift) & 0xFF));
            }

            byte[] frame = new byte[header.Count + payloadLen];
            header.CopyTo(frame);
            Array.Copy(payload, 0, frame, header.Count, payloadLen);
            return frame;
        }

        // ---------------------------------------------------------------
        // Decoding — client → server (ALWAYS masked, per RFC 6455)
        // ---------------------------------------------------------------

        /// <summary>
        /// Reads and decodes one WebSocket frame from the stream (blocking read;
        /// caller runs this on a dedicated per-connection thread/Task).
        /// Returns null if the stream was closed cleanly at a frame boundary.
        /// Throws IOException on protocol violations / oversized frames — the
        /// caller treats this as fatal and closes the connection.
        /// </summary>
        public static WsFrame ReadFrame(Stream stream)
        {
            int b0 = stream.ReadByte();
            if (b0 == -1) return null; // connection closed cleanly

            int b1 = ReadByteStrict(stream);

            bool fin        = (b0 & 0x80) != 0;
            int  opcodeRaw  = b0 & 0x0F;
            bool masked     = (b1 & 0x80) != 0;
            long len        = b1 & 0x7F;

            if (len == 126)
            {
                byte[] ext = ReadExact(stream, 2);
                len = (ext[0] << 8) | ext[1];
            }
            else if (len == 127)
            {
                byte[] ext = ReadExact(stream, 8);
                len = 0;
                for (int i = 0; i < 8; i++)
                    len = (len << 8) | ext[i];
            }

            if (len > MaxFramePayloadLen)
                throw new IOException($"WS frame too large ({len} bytes).");

            byte[] maskKey = null;
            if (masked)
                maskKey = ReadExact(stream, 4);

            byte[] payload = len > 0 ? ReadExact(stream, (int)len) : Array.Empty<byte>();

            if (masked)
            {
                for (int i = 0; i < payload.Length; i++)
                    payload[i] ^= maskKey[i % 4];
            }

            WsOpcode opcode;
            switch (opcodeRaw)
            {
                case 0x1: opcode = WsOpcode.Text;   break;
                case 0x2: opcode = WsOpcode.Binary; break;
                case 0x8: opcode = WsOpcode.Close;  break;
                case 0x9: opcode = WsOpcode.Ping;   break;
                case 0xA: opcode = WsOpcode.Pong;   break;
                default:  opcode = WsOpcode.Unknown; break;
            }

            return new WsFrame { Fin = fin, Opcode = opcode, Payload = payload };
        }

        private static int ReadByteStrict(Stream stream)
        {
            int b = stream.ReadByte();
            if (b == -1) throw new IOException("Unexpected end of stream reading WS frame header.");
            return b;
        }

        private static byte[] ReadExact(Stream stream, int count)
        {
            byte[] buffer = new byte[count];
            int offset = 0;
            while (offset < count)
            {
                int read = stream.Read(buffer, offset, count - offset);
                if (read <= 0) throw new IOException("Unexpected end of stream reading WS frame payload.");
                offset += read;
            }
            return buffer;
        }
    }
}
