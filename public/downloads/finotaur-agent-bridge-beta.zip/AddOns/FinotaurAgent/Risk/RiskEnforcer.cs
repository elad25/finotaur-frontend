// =============================================================================
// Finotaur Agent — Risk/RiskEnforcer.cs
//
// LOCAL risk enforcement engine. Runs on every poll cycle, checking platform
// state against the active risk rules fetched from the FINOTAUR server.
//
// ENFORCEMENT PHILOSOPHY:
//   - Only rules with enforce == true AND is_active == true are enforced.
//   - Advisory (enforce == false) rules are COMPLETELY ignored by this class.
//   - On ANY uncertainty (missing data, unknown account) → do nothing.
//   - Debounce: once an enforcement action fires, it is NOT re-fired every poll
//     until the condition is resolved (e.g. the account is re-opened or the day
//     resets). This prevents spam flattening.
//   - All enforcement actions trigger a PostEventAsync call to the web.
//
// THREAD SAFETY:
//   RunAsync is called from the agent's background loop. CheckAndDebounce on
//   the debounce dictionaries is protected by a simple lock.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk
{
    public class RiskEnforcer
    {
        // -----------------------------------------------------------------------
        // Dependencies
        // -----------------------------------------------------------------------

        private readonly IPlatformAdapter _platform;
        private readonly FinotaurClient   _client;
        private readonly Action<string>   _log;

        // -----------------------------------------------------------------------
        // Debounce state
        // Key = "{ruleId}:{accountName}:{checkType}"
        // Value = DateTime when the last enforcement/alert was fired
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, DateTime> _firedAt =
            new ConcurrentDictionary<string, DateTime>();

        // Tilt state per account-rule:
        //   Key   = "{ruleId}:{accountName}"
        //   Value = consecutive losing trade count
        private readonly ConcurrentDictionary<string, int> _lossStreaks =
            new ConcurrentDictionary<string, int>();

        // Tilt cooldown end times:
        //   Key   = "{ruleId}:{accountName}"
        //   Value = DateTime when tilt cooldown expires
        private readonly ConcurrentDictionary<string, DateTime> _tiltUntil =
            new ConcurrentDictionary<string, DateTime>();

        // Per-day copier open counts:
        //   Key   = "{ruleId}:{accountName}:{utcDate}"
        //   Value = count of copier opens today
        // This is maintained externally by CopierEngine calling IncrementCopierOpens.
        private readonly ConcurrentDictionary<string, int> _dailyCopierOpens =
            new ConcurrentDictionary<string, int>();

        // Accounts locked by "close_lock" breach action.
        //   Key   = accountName (lower-case)
        //   Value = DateTime when lock expires (or DateTime.MaxValue for "until period reset")
        // When locked, ALL copier activity is blocked (not just opens).
        private readonly ConcurrentDictionary<string, DateTime> _lockedUntil =
            new ConcurrentDictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        // Accounts whose copier opens are paused by "pause_copies" or "stop_copies".
        //   Key   = "{ruleId}:{accountName}"
        //   Value = expiry of the pause (DateTime.MaxValue = until period reset)
        private readonly ConcurrentDictionary<string, DateTime> _copierPausedUntil =
            new ConcurrentDictionary<string, DateTime>();

        // Weekly realized PnL baseline per account (rolled over each Sunday).
        //   Key   = "{accountName}:{weekStartDate}"  (weekStartDate = Sunday yyyy-MM-dd local)
        //   Value = the session realized PnL snapshot at week-start
        // Used to compute weekly PnL delta without depending on a broker API for "weekly realized".
        // VERIFY (NT8 API): GetSessionRealizedPnL returns session (daily) realized PnL via
        // account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar).  Weekly tracking is
        // approximated by accumulating daily deltas since last Sunday — see GetWeeklyPnL().
        private readonly ConcurrentDictionary<string, double> _weeklyPnLBaseline =
            new ConcurrentDictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        // Debounce interval — avoid firing the same enforcement more than once
        // per interval. Prevents flatten spam on every poll.
        private static readonly TimeSpan DebounceInterval = TimeSpan.FromSeconds(30);

        // -----------------------------------------------------------------------
        // FIX #7 (risk-state persistence): path for the JSON snapshot file.
        // Mirrors TokenStore's directory convention:
        //   %USERPROFILE%\Documents\NinjaTrader 8\Finotaur\risk-state.json
        // Written on every mutation; loaded on construction to survive restarts.
        // NOTE: untested in this environment — requires NT8 sim verification before live use.
        // -----------------------------------------------------------------------

        private const  string RiskStateFileName = "risk-state.json";
        private readonly string _statePath;

        // -----------------------------------------------------------------------
        // Constructor
        // -----------------------------------------------------------------------

        public RiskEnforcer(
            IPlatformAdapter platform,
            FinotaurClient   client,
            Action<string>   logger = null)
        {
            _platform = platform;
            _client   = client;
            _log      = logger ?? (m => System.Diagnostics.Debug.WriteLine($"[RiskEnforcer] {m}"));

            // FIX #7: resolve the risk-state file path using the same NinjaTrader
            // data directory that TokenStore uses for agent.dat.
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            try
            {
                string ntDataDir;
                try
                {
                    ntDataDir = NinjaTrader.Core.Globals.UserDataDir;
                }
                catch
                {
                    ntDataDir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "NinjaTrader 8");
                }
                _statePath = Path.Combine(ntDataDir, "Finotaur", RiskStateFileName);
            }
            catch (Exception ex)
            {
                _log($"RiskEnforcer: could not resolve state file path ({ex.Message}); " +
                     "risk state will not persist across restarts.");
                _statePath = null;
            }

            // FIX #7: load any previously persisted enforcement state.
            LoadState();
        }

        // -----------------------------------------------------------------------
        // RunAsync — called every poll cycle with the current config
        // -----------------------------------------------------------------------

        /// <summary>
        /// Evaluates all active+enforced risk rules against current platform state.
        /// Safe to call frequently — individual checks are debounced.
        /// Does nothing if rules list is null or empty.
        /// </summary>
        public async Task RunAsync(
            AutomationConfig config,
            CancellationToken ct = default)
        {
            if (config?.RiskRules == null) return;

            foreach (var rule in config.RiskRules)
            {
                if (ct.IsCancellationRequested) break;

                // Skip advisory rules — agent never enforces these
                if (!rule.Enforce || !rule.IsActive) continue;

                // ------------------------------------------------------------------
                // Account binding: resolve the rule to a local NT account.
                //
                // Resolution order (preferred → fallback):
                //   1. rule.AccountName (the broker account name string, e.g.
                //      "MFFUEVBLDR161429081") → ResolveAccountByName()  [PRIMARY]
                //   2. rule.BrokerConnectionId → FindConnection() +
                //      ResolveAccountName()                              [FALLBACK]
                //
                // If neither resolves to a local account → SKIP (fail-safe; do not act).
                // ------------------------------------------------------------------
                string accountName = null;
                BrokerConnection conn = null;

                if (!string.IsNullOrWhiteSpace(rule.AccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    accountName = _platform.ResolveAccountByName(rule.AccountName);
                    if (accountName == null)
                    {
                        _log($"RiskEnforcer: rule '{rule.Label}' — account '{rule.AccountName}' " +
                             "not found in local NT8 — SKIPPING. " +
                             "Verify the account is connected.");
                        continue;
                    }
                    // Attempt to find a matching connection for event payloads (best-effort).
                    conn = FindConnectionByAccountName(config, rule.AccountName);
                }
                else
                {
                    // Fallback: legacy broker_connection_id path.
                    conn = FindConnection(config, rule.BrokerConnectionId);
                    if (conn == null)
                    {
                        _log($"RiskEnforcer: rule '{rule.Label}' references unknown " +
                             $"connection '{rule.BrokerConnectionId}' — SKIPPING.");
                        continue;
                    }
                    accountName = _platform.ResolveAccountName(conn);
                    if (accountName == null)
                    {
                        // No match — already logged by adapter; do not act.
                        continue;
                    }
                }

                await EvaluateRuleAsync(rule, conn, accountName, ct).ConfigureAwait(false);
            }
        }

        // -----------------------------------------------------------------------
        // EvaluateRuleAsync — one rule, one account
        // -----------------------------------------------------------------------

        private async Task EvaluateRuleAsync(
            RiskRule rule,
            BrokerConnection conn,        // may be null on newer account-name-bound rules
            string accountName,
            CancellationToken ct)
        {
            // Shared P&L read — used by multiple checks below.
            double realized = _platform.GetSessionRealizedPnL(accountName);
            double openPnl  = _platform.GetOpenPnL(accountName);
            double totalPnl = realized + openPnl;

            // Positions — used by multiple checks below.
            AgentPosition[] positions = _platform.GetPositions(accountName);

            // Helper: conn?.Id — safe even when conn is null (new-style rules).
            string connId = conn?.Id;

            // ---- (a) Daily loss limit ----------------------------------------
            if (rule.DailyLossLimitUsd.HasValue)
            {
                // Breach condition: totalPnl <= -(daily_loss_limit_usd)
                // E.g. limit = 500 → breach when totalPnl <= -500
                double threshold = -Math.Abs(rule.DailyLossLimitUsd.Value);

                if (totalPnl <= threshold)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:daily_loss";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ENFORCED — daily loss limit hit on '{accountName}'. " +
                             $"Total PnL: {totalPnl:C2} <= threshold {threshold:C2}.");

                        string actionTaken = ApplyBreachAction(rule, accountName);

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "critical",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id          = rule.Id,
                                rule_label       = rule.Label,
                                check            = "daily_loss",
                                realized_pnl     = realized,
                                open_pnl         = openPnl,
                                total_pnl        = totalPnl,
                                threshold        = threshold,
                                action           = actionTaken
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
                else
                {
                    // Condition no longer met — clear debounce so it can fire again
                    // if PnL recovers above threshold and then breaches again.
                    ClearDebounce($"{rule.Id}:{accountName}:daily_loss");
                }
            }

            // ---- (b) Max weekly loss -----------------------------------------
            if (rule.MaxWeeklyLossUsd.HasValue)
            {
                // Weekly PnL = realized + open since Sunday 00:00 local.
                // We approximate by using the same session realized + open PnL and
                // tracking a baseline snapshotted at week-start.
                double weeklyPnl = GetWeeklyPnL(accountName, realized, openPnl);
                double weeklyThreshold = -Math.Abs(rule.MaxWeeklyLossUsd.Value);

                if (weeklyPnl <= weeklyThreshold)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:weekly_loss";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ENFORCED — weekly loss limit hit on '{accountName}'. " +
                             $"Weekly PnL: {weeklyPnl:C2} <= threshold {weeklyThreshold:C2}.");

                        string actionTaken = ApplyBreachAction(rule, accountName);

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "critical",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id        = rule.Id,
                                rule_label     = rule.Label,
                                check          = "weekly_loss",
                                weekly_pnl     = weeklyPnl,
                                threshold      = weeklyThreshold,
                                action         = actionTaken
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
                else
                {
                    ClearDebounce($"{rule.Id}:{accountName}:weekly_loss");
                }
            }

            // ---- (c) Daily profit target ------------------------------------
            if (rule.DailyProfitTargetUsd.HasValue)
            {
                double target = Math.Abs(rule.DailyProfitTargetUsd.Value);

                if (totalPnl >= target)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:daily_profit_target";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ENFORCED — daily profit target reached on '{accountName}'. " +
                             $"Total PnL: {totalPnl:C2} >= target {target:C2}. Locking rest of day.");

                        string actionTaken = ApplyBreachAction(rule, accountName);

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "warning",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id      = rule.Id,
                                rule_label   = rule.Label,
                                check        = "daily_profit_target",
                                total_pnl    = totalPnl,
                                target       = target,
                                action       = actionTaken
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
                else
                {
                    ClearDebounce($"{rule.Id}:{accountName}:daily_profit_target");
                }
            }

            // ---- (d) Weekly profit target ------------------------------------
            if (rule.WeeklyProfitTargetUsd.HasValue)
            {
                double weeklyPnl = GetWeeklyPnL(accountName, realized, openPnl);
                double target    = Math.Abs(rule.WeeklyProfitTargetUsd.Value);

                if (weeklyPnl >= target)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:weekly_profit_target";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ENFORCED — weekly profit target reached on '{accountName}'. " +
                             $"Weekly PnL: {weeklyPnl:C2} >= target {target:C2}. Locking rest of week.");

                        string actionTaken = ApplyBreachAction(rule, accountName);

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "warning",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id      = rule.Id,
                                rule_label   = rule.Label,
                                check        = "weekly_profit_target",
                                weekly_pnl   = weeklyPnl,
                                target       = target,
                                action       = actionTaken
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
                else
                {
                    ClearDebounce($"{rule.Id}:{accountName}:weekly_profit_target");
                }
            }

            // ---- (e) Trade profit target (WI-4: now ENFORCED) -------------------
            //
            // NinjaTraderAdapter.GetPositions() now computes per-position unrealized PnL
            // via Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, lastPrice)
            // using Instrument.MarketData.Last.Price as the mark (falls back to
            // AveragePrice → 0.0 unrealized when no market data subscription exists).
            //
            // Safe degrade: when unrealized is 0.0 the check will simply not fire —
            // it cannot produce a false positive.  The one-time "not enforced" warning
            // that was here before is removed; the rule is now enforced whenever real
            // per-position unrealized PnL data is available.
            //
            // NOTE: enforcement is poll-frequency (every ~5 s), not tick-by-tick.
            if (rule.TradeProfitTargetUsd.HasValue)
            {
                double tradeTarget = Math.Abs(rule.TradeProfitTargetUsd.Value);

                foreach (var pos in positions)
                {
                    // If unrealized is 0.0 (no market data), skip — safe degrade.
                    if (pos.UnrealizedPnL == 0.0) continue;

                    if (pos.UnrealizedPnL >= tradeTarget)
                    {
                        string debounceKey = $"{rule.Id}:{accountName}:trade_profit_target:{pos.InstrumentName}";
                        if (ShouldFire(debounceKey))
                        {
                            _log($"RISK ENFORCED — trade profit target reached on " +
                                 $"'{accountName}' / '{pos.InstrumentName}': " +
                                 $"unrealizedPnL={pos.UnrealizedPnL:C2} >= target {tradeTarget:C2}. " +
                                 "Flattening symbol.");

                            string actionTaken = ApplyBreachAction(rule, accountName);

                            await _client.PostEventAsync(new AutomationEvent
                            {
                                EventType          = "risk_enforced",
                                Severity           = "warning",
                                BrokerConnectionId = connId,
                                Symbol             = pos.InstrumentName,
                                Payload            = new
                                {
                                    rule_id        = rule.Id,
                                    rule_label     = rule.Label,
                                    check          = "trade_profit_target",
                                    unrealized_pnl = pos.UnrealizedPnL,
                                    target         = tradeTarget,
                                    action         = actionTaken
                                }
                            }, ct).ConfigureAwait(false);
                        }
                    }
                    else
                    {
                        ClearDebounce($"{rule.Id}:{accountName}:trade_profit_target:{pos.InstrumentName}");
                    }
                }
            }

            // ---- (f) Max contracts per instrument (per-instrument cap) -------
            if (rule.MaxContracts.HasValue)
            {
                foreach (var pos in positions)
                {
                    if (pos.Quantity > rule.MaxContracts.Value)
                    {
                        string debounceKey = $"{rule.Id}:{accountName}:max_contracts:{pos.InstrumentName}";
                        if (ShouldFire(debounceKey))
                        {
                            _log($"RISK ENFORCED — max_contracts exceeded on '{accountName}' / " +
                                 $"'{pos.InstrumentName}': {pos.Quantity} > {rule.MaxContracts.Value}.");

                            _platform.FlattenSymbol(accountName, pos.InstrumentName);

                            await _client.PostEventAsync(new AutomationEvent
                            {
                                EventType          = "risk_enforced",
                                Severity           = "warning",
                                BrokerConnectionId = connId,
                                Symbol             = pos.InstrumentName,
                                Payload            = new
                                {
                                    rule_id      = rule.Id,
                                    rule_label   = rule.Label,
                                    check        = "max_contracts",
                                    current_qty  = pos.Quantity,
                                    max_allowed  = rule.MaxContracts.Value,
                                    action       = "flatten_symbol"
                                }
                            }, ct).ConfigureAwait(false);
                        }
                    }
                    else
                    {
                        ClearDebounce($"{rule.Id}:{accountName}:max_contracts:{pos.InstrumentName}");
                    }
                }
            }

            // ---- (g) Max position size (total contracts, account-wide) -------
            if (rule.MaxPositionSize.HasValue)
            {
                int totalContracts = 0;
                foreach (var pos in positions) totalContracts += pos.Quantity;

                if (totalContracts > rule.MaxPositionSize.Value)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:max_position_size";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ENFORCED — max_position_size exceeded on '{accountName}': " +
                             $"{totalContracts} total contracts > {rule.MaxPositionSize.Value}.");

                        string actionTaken = ApplyBreachAction(rule, accountName);

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "warning",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id          = rule.Id,
                                rule_label       = rule.Label,
                                check            = "max_position_size",
                                total_contracts  = totalContracts,
                                max_allowed      = rule.MaxPositionSize.Value,
                                action           = actionTaken
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
                else
                {
                    ClearDebounce($"{rule.Id}:{accountName}:max_position_size");
                }
            }

            // ---- (h) Max position USD (ENFORCED — now flattens on breach) ----
            if (rule.MaxPositionUsd.HasValue)
            {
                foreach (var pos in positions)
                {
                    // MarketValueUsd may be 0 if not computable — skip in that case.
                    // VERIFY (NT8 API): computed as AveragePrice * Quantity * PointValue
                    // in NinjaTraderAdapter.GetPositions(). This is entry-price based,
                    // not mark-to-market. Use with awareness that it is approximate.
                    if (pos.MarketValueUsd <= 0) continue;

                    if (pos.MarketValueUsd > rule.MaxPositionUsd.Value)
                    {
                        string debounceKey = $"{rule.Id}:{accountName}:max_pos_usd:{pos.InstrumentName}";
                        if (ShouldFire(debounceKey))
                        {
                            _log($"RISK ENFORCED — max_position_usd exceeded on '{accountName}' / " +
                                 $"'{pos.InstrumentName}': {pos.MarketValueUsd:C2} > " +
                                 $"{rule.MaxPositionUsd.Value:C2}. Flattening symbol.");

                            // Changed from alert-only to ENFORCED (flatten on breach).
                            _platform.FlattenSymbol(accountName, pos.InstrumentName);

                            await _client.PostEventAsync(new AutomationEvent
                            {
                                EventType          = "risk_enforced",
                                Severity           = "warning",
                                BrokerConnectionId = connId,
                                Symbol             = pos.InstrumentName,
                                Payload            = new
                                {
                                    rule_id       = rule.Id,
                                    rule_label    = rule.Label,
                                    check         = "max_position_usd",
                                    position_usd  = pos.MarketValueUsd,
                                    max_allowed   = rule.MaxPositionUsd.Value,
                                    action        = "flatten_symbol"
                                }
                            }, ct).ConfigureAwait(false);
                        }
                    }
                    else
                    {
                        ClearDebounce($"{rule.Id}:{accountName}:max_pos_usd:{pos.InstrumentName}");
                    }
                }
            }

            // ---- (i) Max trades per day (copier opens) -----------------------
            // Count is maintained by IncrementCopierOpens (called by CopierEngine).
            // IsOrderAllowed enforces the gate; this check logs when the limit is crossed.
            if (rule.MaxTradesPerDay.HasValue)
            {
                int todayCount = GetDailyCopierOpens(rule.Id, accountName);
                if (todayCount > rule.MaxTradesPerDay.Value)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:max_trades";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ALERT — max_trades_per_day exceeded on '{accountName}': " +
                             $"{todayCount} copier opens today, limit is {rule.MaxTradesPerDay.Value}. " +
                             "Further copier opens are blocked for this account today.");

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_alert",
                            Severity           = "warning",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id     = rule.Id,
                                rule_label  = rule.Label,
                                check       = "max_trades_per_day",
                                today_opens = todayCount,
                                max_allowed = rule.MaxTradesPerDay.Value,
                                action      = "copier_opens_blocked"
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
            }

            // ---- (j) Tilt cooldown enforcement ------------------------------
            // Tilt state is updated by RecordFillResult (called by CopierEngine).
            // Here we check for expiry and remove stale markers.
            if (rule.TiltLossStreak.HasValue && rule.TiltCooldownMinutes.HasValue)
            {
                string tiltKey = $"{rule.Id}:{accountName}";
                if (_tiltUntil.TryGetValue(tiltKey, out DateTime cooldownEnd))
                {
                    if (DateTime.UtcNow >= cooldownEnd)
                    {
                        // Cooldown expired — remove the tilt marker and reset streak.
                        _tiltUntil.TryRemove(tiltKey, out _);
                        _lossStreaks.TryUpdate(tiltKey, 0, _lossStreaks.GetOrAdd(tiltKey, 0));
                        _log($"Tilt cooldown expired for rule '{rule.Label}' on '{accountName}'.");
                        // FIX #7: persist the cleared tilt state.
                        // NOTE: untested in this environment — requires NT8 sim verification before live use.
                        SaveState();
                    }
                    // Still in cooldown — CopierEngine.IsOrderAllowed blocks opens.
                }
            }
        }

        // -----------------------------------------------------------------------
        // ApplyBreachAction — executes the configured risk_breach_action
        // -----------------------------------------------------------------------

        /// <summary>
        /// Executes the breach action specified in rule.RiskBreachAction and returns
        /// a string describing what was done (used in event payloads).
        ///
        /// "pause_copies"  — block new copier opens for the account until the period
        ///                   resets. Does NOT flatten existing positions.
        /// "stop_copies"   — block new copier opens AND flatten all existing positions.
        /// "close_lock"    — flatten positions + block ALL copier activity until period reset.
        /// null/unknown    — legacy behavior: flatten all positions (same as stop_copies
        ///                   for loss limits, which is what the original code did).
        ///
        /// FAIL-SAFE: never throws. All platform calls are already fail-safe.
        /// </summary>
        private string ApplyBreachAction(RiskRule rule, string accountName)
        {
            string action = (rule.RiskBreachAction ?? string.Empty).Trim().ToLowerInvariant();

            switch (action)
            {
                case "pause_copies":
                    // Block new copier opens only — do not flatten.
                    // WI-1: expire at the next CME session open (17:00 CT) instead of MaxValue.
                    string pauseKey = $"{rule.Id}:{accountName}";
                    _copierPausedUntil[pauseKey] = NextSessionOpenUtc(DateTime.UtcNow);
                    _log($"BreachAction 'pause_copies' applied to '{accountName}' " +
                         $"(rule '{rule.Label}'): copier opens blocked until next session open " +
                         $"({_copierPausedUntil[pauseKey]:u} UTC).");
                    // FIX #7: persist pause so it survives restart.
                    // NOTE: untested in this environment — requires NT8 sim verification before live use.
                    SaveState();
                    return "pause_copies";

                case "stop_copies":
                    // Block opens + flatten existing positions.
                    // WI-1: expire at the next CME session open (17:00 CT) instead of MaxValue.
                    // WI-3: also install the real-time lock guard so any manual order or
                    // position that appears while the lock is active is immediately cancelled/flattened.
                    // We set _lockedUntil in addition to _copierPausedUntil so the guard's
                    // stillLocked predicate (IsAccountLocked) self-deregisters at the correct time.
                    string stopKey = $"{rule.Id}:{accountName}";
                    DateTime stopExpiry = NextSessionOpenUtc(DateTime.UtcNow);
                    _copierPausedUntil[stopKey]  = stopExpiry;
                    _lockedUntil[accountName]    = stopExpiry;
                    _platform.FlattenAll(accountName);
                    _platform.StartLockGuard(accountName, () => IsAccountLocked(accountName));
                    _log($"BreachAction 'stop_copies' applied to '{accountName}' " +
                         $"(rule '{rule.Label}'): copier opens blocked until next session open " +
                         $"({stopExpiry:u} UTC) + positions flattened + lock guard active.");
                    // FIX #7: persist pause so it survives restart.
                    // NOTE: untested in this environment — requires NT8 sim verification before live use.
                    SaveState();
                    return "stop_copies";

                case "close_lock":
                    // Flatten + lock account from ALL copier activity.
                    // WI-1: expire at the next CME session open (17:00 CT) instead of MaxValue.
                    // WI-3: install the real-time lock guard so orders/positions placed after
                    // the breach (copier OR manual) are cancelled/flattened immediately.
                    string lockKey      = $"{rule.Id}:{accountName}";
                    DateTime nextOpen   = NextSessionOpenUtc(DateTime.UtcNow);
                    _copierPausedUntil[lockKey]   = nextOpen;
                    _lockedUntil[accountName]     = nextOpen;
                    _platform.FlattenAll(accountName);
                    _platform.StartLockGuard(accountName, () => IsAccountLocked(accountName));
                    _log($"BreachAction 'close_lock' applied to '{accountName}' " +
                         $"(rule '{rule.Label}'): account locked until next session open " +
                         $"({nextOpen:u} UTC) + positions flattened + lock guard active.");
                    // FIX #7: persist lock so it survives restart — this is the whole point
                    // of close_lock: the lock must not disappear on an NT8 restart.
                    // NOTE: untested in this environment — requires NT8 sim verification before live use.
                    SaveState();
                    return "close_lock";

                default:
                    // Legacy / unknown: flatten all (original behavior for loss limits).
                    _platform.FlattenAll(accountName);
                    _log($"BreachAction '{(string.IsNullOrEmpty(action) ? "default" : action)}' " +
                         $"on '{accountName}' (rule '{rule.Label}'): flattened all positions.");
                    return "flatten_all";
            }
        }

        // -----------------------------------------------------------------------
        // GetWeeklyPnL — approximate weekly P&L since last Sunday 00:00 local
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns an approximate weekly P&L for the account.
        ///
        /// Approach: NT8 exposes only session (daily) realized PnL via
        /// account.Get(AccountItem.RealizedProfitLoss).  A true weekly figure
        /// would require accumulating daily close-of-day snapshots.
        ///
        /// Approximation used here:
        ///   • On the first call for this week, snapshot the current realized PnL
        ///     as the "baseline" (i.e. assume the week starts from that value).
        ///   • On subsequent calls, weekly PnL = (current realized - baseline) + openPnL.
        ///
        /// Limitation: if the agent is restarted mid-week, the baseline resets and
        /// the weekly figure reflects only the post-restart session, not the full week.
        ///
        /// VERIFY (NT8 API): a more accurate implementation would persist daily
        /// realized-PnL snapshots across sessions (e.g. to a local file or registry)
        /// and sum them.  The current approximation is intentionally conservative —
        /// it may under-report weekly loss (only reflects current session) but will
        /// not over-block.
        /// </summary>
        private double GetWeeklyPnL(string accountName, double currentRealized, double openPnl)
        {
            // Compute week-start as most recent Sunday 00:00 in LOCAL time.
            DateTime localNow  = DateTime.Now;
            int      daysSinceSunday = ((int)localNow.DayOfWeek);  // DayOfWeek.Sunday == 0
            DateTime weekStart = localNow.Date.AddDays(-daysSinceSunday);
            string   weekKey   = $"{accountName}:{weekStart:yyyy-MM-dd}";

            // On first call for this week, snapshot current realized as baseline.
            bool isNewEntry = !_weeklyPnLBaseline.ContainsKey(weekKey);
            double baseline = _weeklyPnLBaseline.GetOrAdd(weekKey, _ => currentRealized);

            // FIX #7: persist the baseline immediately on first establishment so
            // a restart mid-week can recover the correct starting point for weekly PnL.
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            if (isNewEntry) SaveState();

            // Clean up stale week entries (prior weeks) to prevent unbounded growth.
            foreach (var key in _weeklyPnLBaseline.Keys)
            {
                if (!key.StartsWith(accountName + ":")) continue;
                if (!key.Equals(weekKey, StringComparison.OrdinalIgnoreCase))
                    _weeklyPnLBaseline.TryRemove(key, out _);
            }

            return (currentRealized - baseline) + openPnl;
        }

        // -----------------------------------------------------------------------
        // CopierEngine integration — pre-trade check
        // -----------------------------------------------------------------------

        /// <summary>
        /// Called by CopierEngine BEFORE placing a mirrored order.
        /// Returns false (block) if any enforced risk rule would be violated.
        /// Returns true (allow) if all checks pass.
        ///
        /// Checks performed (in order):
        ///   1. Account-level lock (close_lock breach action).
        ///   2. Copier-pause (pause_copies / stop_copies breach action).
        ///   3. Tilt cooldown.
        ///   4. max_trades_per_day.
        ///   5. max_contracts (per instrument).
        ///   6. daily_loss_limit_usd.
        ///   7. max_weekly_loss_usd.
        ///   8. daily_profit_target_usd / weekly_profit_target_usd (profit lock).
        ///   9. max_position_size (total contracts).
        ///   10. max_position_usd (projected notional after this order).
        ///   11. trade_profit_target_usd (refuse to add to an already-target-hit position).
        ///
        /// IRON RULE (2026-07-02 incident): an order that REDUCES exposure must
        /// never be blocked by risk rules. Blocking a closing/reducing order is
        /// strictly worse than allowing it — it stalls the follower out of sync
        /// with the leader (e.g. leader flat, follower stuck long), and any
        /// account that is genuinely locked/breached is already flattened by the
        /// separate enforcement loop, not by this gate. Callers that can prove
        /// the order reduces exposure (fill path, placement path) pass
        /// reducesExposure = true to bypass this gate entirely.
        /// </summary>
        public bool IsOrderAllowed(
            string accountName,
            string instrumentName,
            int    quantity,
            List<RiskRule> rules,
            List<BrokerConnection> connections,
            bool   reducesExposure = false)
        {
            if (reducesExposure)
            {
                _log($"IsOrderAllowed: risk gate bypassed — order reduces exposure " +
                     $"({accountName}/{instrumentName} qty {quantity}).");
                return true;
            }

            if (rules == null) return true;

            // ---- Global account lock (close_lock breach action) ---------------
            // This check is NOT rule-specific — it locks the account for all rules.
            // WI-1: locks now carry a real expiry timestamp (NextSessionOpenUtc);
            //       the MaxValue special-case is removed — normal time comparison governs.
            if (_lockedUntil.TryGetValue(accountName, out DateTime lockUntil))
            {
                if (DateTime.UtcNow < lockUntil)
                {
                    _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                         $"account is close_locked until {lockUntil:u} UTC.");
                    return false;
                }
                // Lock expired — clean up.
                _lockedUntil.TryRemove(accountName, out _);
            }

            foreach (var rule in rules)
            {
                if (!rule.Enforce || !rule.IsActive) continue;

                // Resolve account for this rule (AccountName-first, then BrokerConnectionId fallback).
                string mappedName = null;
                if (!string.IsNullOrWhiteSpace(rule.AccountName))
                {
                    mappedName = _platform.ResolveAccountByName(rule.AccountName);
                }
                else
                {
                    BrokerConnection conn = connections?.Find(c => c.Id == rule.BrokerConnectionId);
                    if (conn != null)
                        mappedName = _platform.ResolveAccountName(conn);
                }

                if (mappedName == null || !string.Equals(mappedName, accountName,
                        StringComparison.OrdinalIgnoreCase)) continue;

                // ---- Copier pause (pause_copies / stop_copies) ----------------
                // WI-1: pauses now carry a real expiry timestamp (NextSessionOpenUtc);
                //       the MaxValue special-case is removed — normal time comparison governs.
                string pauseKey = $"{rule.Id}:{accountName}";
                if (_copierPausedUntil.TryGetValue(pauseKey, out DateTime pauseUntil))
                {
                    if (DateTime.UtcNow < pauseUntil)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"copier opens paused by rule '{rule.Label}' until {pauseUntil:u} UTC " +
                             $"(breach action: {rule.RiskBreachAction ?? "legacy"}).");
                        return false;
                    }
                    // Pause expired — clean up.
                    _copierPausedUntil.TryRemove(pauseKey, out _);
                }

                // ---- Tilt cooldown -------------------------------------------
                if (rule.TiltLossStreak.HasValue)
                {
                    if (IsInTiltCooldown(rule.Id, accountName))
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             "tilt cooldown is active.");
                        return false;
                    }
                }

                // ---- Max trades per day --------------------------------------
                if (rule.MaxTradesPerDay.HasValue)
                {
                    int todayCount = GetDailyCopierOpens(rule.Id, accountName);
                    if (todayCount >= rule.MaxTradesPerDay.Value)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"max_trades_per_day ({rule.MaxTradesPerDay.Value}) reached.");
                        return false;
                    }
                }

                // ---- Max contracts per instrument ----------------------------
                if (rule.MaxContracts.HasValue)
                {
                    int currentContracts = _platform.GetOpenContracts(accountName, instrumentName);
                    if (currentContracts + quantity > rule.MaxContracts.Value)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}/{instrumentName}' — " +
                             $"max_contracts would be exceeded ({currentContracts}+{quantity} > " +
                             $"{rule.MaxContracts.Value}).");
                        return false;
                    }
                }

                // ---- Max position size (total contracts, account-wide) -------
                if (rule.MaxPositionSize.HasValue)
                {
                    int totalContracts = _platform.GetOpenContracts(accountName);
                    if (totalContracts + quantity > rule.MaxPositionSize.Value)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"max_position_size would be exceeded ({totalContracts}+{quantity} > " +
                             $"{rule.MaxPositionSize.Value}).");
                        return false;
                    }
                }

                // ---- Max position USD (pre-trade, projected) ------------------
                // Mirrors the monitoring loop's max_position_usd check (see (h) above):
                // AgentPosition.MarketValueUsd is entry-price based (AveragePrice *
                // Quantity * PointValue). If an existing position is found, derive a
                // per-contract USD value from it and project the notional after this
                // order adds `quantity` more contracts. No existing position / no
                // market data (MarketValueUsd <= 0) → skip gracefully, same safe
                // degrade as the monitoring loop — never block on missing data.
                if (rule.MaxPositionUsd.HasValue)
                {
                    AgentPosition[] positionsForGate = _platform.GetPositions(accountName);
                    AgentPosition existingPos = Array.Find(positionsForGate,
                        p => string.Equals(p.InstrumentName, instrumentName, StringComparison.OrdinalIgnoreCase));

                    if (existingPos != null && existingPos.MarketValueUsd > 0 && existingPos.Quantity > 0)
                    {
                        double perContractUsd = existingPos.MarketValueUsd / existingPos.Quantity;
                        double projectedUsd   = (existingPos.Quantity + quantity) * perContractUsd;

                        if (projectedUsd > rule.MaxPositionUsd.Value)
                        {
                            _log($"IsOrderAllowed: BLOCKED on '{accountName}/{instrumentName}' — " +
                                 $"max_position_usd would be exceeded (projected {projectedUsd:C2} > " +
                                 $"{rule.MaxPositionUsd.Value:C2}).");
                            return false;
                        }
                    }
                    // else: no existing position or no market data — skip, safe degrade.
                }

                // ---- Daily loss limit ----------------------------------------
                if (rule.DailyLossLimitUsd.HasValue)
                {
                    double totalPnl  = _platform.GetSessionRealizedPnL(accountName)
                                     + _platform.GetOpenPnL(accountName);
                    double threshold = -Math.Abs(rule.DailyLossLimitUsd.Value);
                    if (totalPnl <= threshold)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"daily loss limit already breached (PnL={totalPnl:C2}).");
                        return false;
                    }
                }

                // ---- Weekly loss limit ---------------------------------------
                if (rule.MaxWeeklyLossUsd.HasValue)
                {
                    double realized     = _platform.GetSessionRealizedPnL(accountName);
                    double open         = _platform.GetOpenPnL(accountName);
                    double weeklyPnl    = GetWeeklyPnL(accountName, realized, open);
                    double weeklyThresh = -Math.Abs(rule.MaxWeeklyLossUsd.Value);
                    if (weeklyPnl <= weeklyThresh)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"weekly loss limit already breached (weeklyPnL={weeklyPnl:C2}).");
                        return false;
                    }
                }

                // ---- Daily profit target (lock new opens when target is met) --
                if (rule.DailyProfitTargetUsd.HasValue)
                {
                    double totalPnl = _platform.GetSessionRealizedPnL(accountName)
                                    + _platform.GetOpenPnL(accountName);
                    double target   = Math.Abs(rule.DailyProfitTargetUsd.Value);
                    if (totalPnl >= target)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"daily profit target already reached (PnL={totalPnl:C2}).");
                        return false;
                    }
                }

                // ---- Weekly profit target ------------------------------------
                if (rule.WeeklyProfitTargetUsd.HasValue)
                {
                    double realized  = _platform.GetSessionRealizedPnL(accountName);
                    double open      = _platform.GetOpenPnL(accountName);
                    double weeklyPnl = GetWeeklyPnL(accountName, realized, open);
                    double target    = Math.Abs(rule.WeeklyProfitTargetUsd.Value);
                    if (weeklyPnl >= target)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"weekly profit target already reached (weeklyPnL={weeklyPnl:C2}).");
                        return false;
                    }
                }

                // ---- Trade profit target (pre-trade, block adding to a winner) -
                // Mirrors the monitoring loop's trade_profit_target_usd check (see (e)
                // above): AgentPosition.UnrealizedPnL is the per-position mark-to-market
                // PnL. If the current position in this instrument has already reached
                // its target, the monitoring loop is about to flatten it — do not let
                // an exposure-INCREASING order add to it first. This check is skipped
                // by the reducesExposure=true bypass at the top of this method, so it
                // only ever blocks orders that add to the position.
                if (rule.TradeProfitTargetUsd.HasValue)
                {
                    AgentPosition[] positionsForGate = _platform.GetPositions(accountName);
                    AgentPosition existingPos = Array.Find(positionsForGate,
                        p => string.Equals(p.InstrumentName, instrumentName, StringComparison.OrdinalIgnoreCase));

                    // If unrealized is 0.0 (no market data) or no position exists, skip — safe degrade.
                    if (existingPos != null && existingPos.UnrealizedPnL != 0.0)
                    {
                        double tradeTarget = Math.Abs(rule.TradeProfitTargetUsd.Value);
                        if (existingPos.UnrealizedPnL >= tradeTarget)
                        {
                            _log($"IsOrderAllowed: BLOCKED on '{accountName}/{instrumentName}' — " +
                                 $"trade_profit_target already reached (unrealizedPnL={existingPos.UnrealizedPnL:C2} " +
                                 $">= target {tradeTarget:C2}); refusing to add to the position.");
                            return false;
                        }
                    }
                }
            }

            return true; // all checks passed
        }

        // -----------------------------------------------------------------------
        // RecordFillResultAsync — called by CopierEngine on every close fill
        // -----------------------------------------------------------------------

        /// <summary>
        /// Records a copier fill outcome for tilt tracking AND per-trade loss limit.
        /// Call this after every source-account CLOSE fill.
        /// </summary>
        /// <param name="ruleId">The risk rule ID governing this account.</param>
        /// <param name="accountName">The source account name.</param>
        /// <param name="wasLoss">true if the closed trade was a loss.</param>
        /// <param name="pnlDelta">
        /// The realized P&amp;L delta for this trade (negative = loss, positive = win).
        /// Used by max_loss_per_trade_usd check.  Pass 0.0 if unavailable (check is skipped).
        /// </param>
        /// <param name="rule">The full rule, to read tilt and per-trade parameters.</param>
        /// <param name="conn">The BrokerConnection for this rule (may be null for new-style rules).</param>
        public async Task RecordFillResultAsync(
            string ruleId,
            string accountName,
            bool wasLoss,
            RiskRule rule,
            BrokerConnection conn,
            CancellationToken ct = default,
            double pnlDelta = 0.0)
        {
            string connId = conn?.Id;

            // ---- Max loss per trade -----------------------------------------
            // Fires on CLOSE fills where the realized loss for that trade exceeds
            // the per-trade limit. Uses the pnlDelta computed by CopierEngine.
            if (rule.MaxLossPerTradeUsd.HasValue && wasLoss && pnlDelta != 0.0)
            {
                double lossAmount = Math.Abs(pnlDelta);
                double limit      = Math.Abs(rule.MaxLossPerTradeUsd.Value);
                if (lossAmount >= limit)
                {
                    _log($"RISK ENFORCED — max_loss_per_trade_usd hit on '{accountName}': " +
                         $"trade loss {lossAmount:C2} >= limit {limit:C2}.");

                    string actionTaken = ApplyBreachAction(rule, accountName);

                    // Best-effort: fire-and-forget (no await to keep this lightweight).
                    // We can't await inside CopierEngine's RecordSourceFillTiltAsync without
                    // restructuring; post to event queue instead via try/catch.
                    try
                    {
                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "warning",
                            BrokerConnectionId = connId,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id        = ruleId,
                                rule_label     = rule.Label,
                                check          = "max_loss_per_trade",
                                trade_loss     = lossAmount,
                                limit          = limit,
                                action         = actionTaken
                            }
                        }, ct).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        _log($"RecordFillResultAsync: PostEventAsync error (non-fatal): {ex.Message}");
                    }
                }
            }

            // ---- Tilt tracking ----------------------------------------------
            if (!rule.TiltLossStreak.HasValue || !rule.TiltCooldownMinutes.HasValue) return;

            string tiltKey = $"{ruleId}:{accountName}";

            if (wasLoss)
            {
                int streak = _lossStreaks.AddOrUpdate(tiltKey, 1, (k, v) => v + 1);
                _log($"Tilt tracker: '{accountName}' loss streak = {streak}.");

                if (streak >= rule.TiltLossStreak.Value && !IsInTiltCooldown(ruleId, accountName))
                {
                    DateTime cooldownEnd = DateTime.UtcNow.AddMinutes(rule.TiltCooldownMinutes.Value);
                    _tiltUntil[tiltKey] = cooldownEnd;

                    _log($"TILT TRIGGERED on '{accountName}': {streak} consecutive losses. " +
                         $"Copier blocked until {cooldownEnd:u}.");

                    // FIX #7: persist tilt state so cooldown survives an NT8 restart.
                    // NOTE: untested in this environment — requires NT8 sim verification before live use.
                    SaveState();

                    await _client.PostEventAsync(new AutomationEvent
                    {
                        EventType          = "risk_alert",
                        Severity           = "warning",
                        BrokerConnectionId = connId,
                        Payload            = new
                        {
                            rule_id           = ruleId,
                            rule_label        = rule.Label,
                            check             = "tilt",
                            loss_streak       = streak,
                            cooldown_minutes  = rule.TiltCooldownMinutes.Value,
                            cooldown_ends_utc = cooldownEnd.ToString("o"),
                            action            = "copier_opens_blocked_tilt"
                        }
                    }, ct).ConfigureAwait(false);
                }
                else
                {
                    // Streak incremented but not yet at threshold (or already in cooldown).
                    // FIX #7: persist updated streak count.
                    // NOTE: untested in this environment — requires NT8 sim verification before live use.
                    SaveState();
                }
            }
            else
            {
                // Winning trade resets the streak.
                _lossStreaks.TryUpdate(tiltKey, 0, _lossStreaks.GetOrAdd(tiltKey, 0));
                // FIX #7: persist streak reset so it survives restart.
                // NOTE: untested in this environment — requires NT8 sim verification before live use.
                SaveState();
            }
        }

        // -----------------------------------------------------------------------
        // Daily copier open counter (called by CopierEngine)
        // -----------------------------------------------------------------------

        public void IncrementCopierOpens(string ruleId, string accountName)
        {
            string key = $"{ruleId}:{accountName}:{DateTime.UtcNow:yyyy-MM-dd}";
            _dailyCopierOpens.AddOrUpdate(key, 1, (k, v) => v + 1);
            // FIX #7: persist after every increment so daily caps survive restart.
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            SaveState();
        }

        private int GetDailyCopierOpens(string ruleId, string accountName)
        {
            string key = $"{ruleId}:{accountName}:{DateTime.UtcNow:yyyy-MM-dd}";
            _dailyCopierOpens.TryGetValue(key, out int count);
            return count;
        }

        // -----------------------------------------------------------------------
        // WI-3: Manual lock/unlock API (called from FinotaurAgent on config diff)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Manually locks <paramref name="account"/> until the next CME session open,
        /// exactly like a "close_lock" breach — flattens positions and installs the
        /// real-time lock guard via IPlatformAdapter.StartLockGuard.
        /// Called when the web config diff shows this account newly in locked_accounts.
        /// </summary>
        public void LockAccountManual(string account)
        {
            if (string.IsNullOrWhiteSpace(account)) return;
            try
            {
                DateTime expiry = NextSessionOpenUtc(DateTime.UtcNow);
                _lockedUntil[account] = expiry;
                _platform.StartLockGuard(account, () => IsAccountLocked(account));
                SaveState();
                _log($"LockAccountManual: '{account}' locked until {expiry:u} UTC " +
                     "(manual lock from web dashboard).");
            }
            catch (Exception ex)
            {
                _log($"LockAccountManual error for '{account}': {ex.Message}");
            }
        }

        /// <summary>
        /// Manually removes the lock on <paramref name="account"/>.
        /// Clears only the manual/close_lock expiry — does NOT clear an independent
        /// breach-action paused-state from a different rule (copier-pause remains).
        /// Stops the real-time lock guard so orders/positions are no longer cancelled.
        /// Called when the web config diff shows this account removed from locked_accounts.
        /// </summary>
        public void UnlockAccountManual(string account)
        {
            if (string.IsNullOrWhiteSpace(account)) return;
            try
            {
                _lockedUntil.TryRemove(account, out _);
                _platform.StopLockGuard(account);
                SaveState();
                _log($"UnlockAccountManual: '{account}' manual lock cleared.");
            }
            catch (Exception ex)
            {
                _log($"UnlockAccountManual error for '{account}': {ex.Message}");
            }
        }

        /// <summary>
        /// Returns true if <paramref name="account"/> is currently locked (close_lock or
        /// manual lock from the web). Cleans up an expired lock entry as a side-effect.
        /// </summary>
        public bool IsAccountLocked(string account)
        {
            if (string.IsNullOrWhiteSpace(account)) return false;
            if (!_lockedUntil.TryGetValue(account, out DateTime until)) return false;
            if (DateTime.UtcNow < until) return true;
            // Lock has expired — clean up.
            _lockedUntil.TryRemove(account, out _);
            return false;
        }

        // -----------------------------------------------------------------------
        // Public query helpers (used by CopierEngine)
        // -----------------------------------------------------------------------

        public bool IsInTiltCooldown(string ruleId, string accountName)
        {
            string tiltKey = $"{ruleId}:{accountName}";
            if (!_tiltUntil.TryGetValue(tiltKey, out DateTime until)) return false;
            return DateTime.UtcNow < until;
        }

        // -----------------------------------------------------------------------
        // Debounce helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns true if enough time has passed since the last fire for this key.
        /// Side-effect: records the current time as the fire time.
        /// </summary>
        private bool ShouldFire(string key)
        {
            DateTime now = DateTime.UtcNow;
            if (_firedAt.TryGetValue(key, out DateTime last))
            {
                if (now - last < DebounceInterval)
                    return false;
            }
            _firedAt[key] = now;
            return true;
        }

        private void ClearDebounce(string key)
        {
            _firedAt.TryRemove(key, out _);
        }

        // -----------------------------------------------------------------------
        // FIX #7 — Risk state persistence (JSON snapshot)
        // -----------------------------------------------------------------------

        // ---- Serialization schema (increment SchemaVersion on breaking changes) ----

        /// <summary>
        /// JSON-serializable snapshot of enforcement state.
        /// Schema version 1 — increment if the shape changes.
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private class RiskStateSnapshot
        {
            [JsonProperty("schema_version")]
            public int SchemaVersion { get; set; } = 1;

            [JsonProperty("saved_at_utc")]
            public string SavedAtUtc { get; set; }

            /// <summary>
            /// Daily copier-opens counts.
            /// Key = "{ruleId}:{accountName}:{utcDate:yyyy-MM-dd}"
            /// </summary>
            [JsonProperty("daily_copier_opens")]
            public Dictionary<string, int> DailyCopierOpens { get; set; }
                = new Dictionary<string, int>();

            /// <summary>
            /// Tilt loss streaks.
            /// Key = "{ruleId}:{accountName}"
            /// </summary>
            [JsonProperty("loss_streaks")]
            public Dictionary<string, int> LossStreaks { get; set; }
                = new Dictionary<string, int>();

            /// <summary>
            /// Tilt cooldown expiry times (ISO-8601 UTC strings).
            /// Key = "{ruleId}:{accountName}"
            /// </summary>
            [JsonProperty("tilt_until_utc")]
            public Dictionary<string, string> TiltUntilUtc { get; set; }
                = new Dictionary<string, string>();

            /// <summary>
            /// Account-level close_lock expiry times (ISO-8601 UTC strings).
            /// Key = accountName (lower-case)
            /// Value = DateTime.MaxValue is stored as the sentinel "MAX"
            /// </summary>
            [JsonProperty("locked_until_utc")]
            public Dictionary<string, string> LockedUntilUtc { get; set; }
                = new Dictionary<string, string>();

            /// <summary>
            /// Copier-pause expiry times (ISO-8601 UTC strings).
            /// Key = "{ruleId}:{accountName}"
            /// Value = DateTime.MaxValue is stored as the sentinel "MAX"
            /// </summary>
            [JsonProperty("copier_paused_until_utc")]
            public Dictionary<string, string> CopierPausedUntilUtc { get; set; }
                = new Dictionary<string, string>();

            /// <summary>
            /// Weekly P&amp;L baselines.
            /// Key = "{accountName}:{weekStartDate:yyyy-MM-dd}"
            /// </summary>
            [JsonProperty("weekly_pnl_baseline")]
            public Dictionary<string, double> WeeklyPnLBaseline { get; set; }
                = new Dictionary<string, double>();
        }

        // Sentinel string for DateTime.MaxValue (persisted as a special value).
        private const string MaxValueSentinel = "MAX";

        /// <summary>
        /// Serializes current enforcement state to disk.
        /// Best-effort: any I/O error is logged and swallowed — must not throw
        /// into the trading path.
        /// FIX #7 (risk-state persistence).
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private void SaveState()
        {
            if (_statePath == null) return;

            try
            {
                var snap = new RiskStateSnapshot
                {
                    SavedAtUtc = DateTime.UtcNow.ToString("o")
                };

                // Daily opens — copy as-is; LoadState will discard stale dates.
                foreach (var kv in _dailyCopierOpens)
                    snap.DailyCopierOpens[kv.Key] = kv.Value;

                // Loss streaks
                foreach (var kv in _lossStreaks)
                    snap.LossStreaks[kv.Key] = kv.Value;

                // Tilt-until times
                foreach (var kv in _tiltUntil)
                    snap.TiltUntilUtc[kv.Key] = kv.Value == DateTime.MaxValue
                        ? MaxValueSentinel
                        : kv.Value.ToString("o");

                // Locked-until (close_lock)
                foreach (var kv in _lockedUntil)
                    snap.LockedUntilUtc[kv.Key] = kv.Value == DateTime.MaxValue
                        ? MaxValueSentinel
                        : kv.Value.ToString("o");

                // Copier-paused-until
                foreach (var kv in _copierPausedUntil)
                    snap.CopierPausedUntilUtc[kv.Key] = kv.Value == DateTime.MaxValue
                        ? MaxValueSentinel
                        : kv.Value.ToString("o");

                // Weekly PnL baseline
                foreach (var kv in _weeklyPnLBaseline)
                    snap.WeeklyPnLBaseline[kv.Key] = kv.Value;

                string json = JsonConvert.SerializeObject(snap, Formatting.Indented);
                string dir  = Path.GetDirectoryName(_statePath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                File.WriteAllText(_statePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                // Non-fatal — log and continue.
                _log($"RiskEnforcer.SaveState: I/O error (non-fatal): " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        /// <summary>
        /// Loads previously persisted enforcement state from disk and rehydrates
        /// the in-memory maps, honoring reset boundaries:
        ///   • daily_copier_opens entries whose embedded UTC date != today are discarded.
        ///   • weekly_pnl_baseline entries whose embedded week start != current week
        ///     are discarded.
        ///   • tilt_until / locked_until / copier_paused_until entries that have
        ///     already expired (and are not MaxValue sentinels) are discarded.
        ///   • close_lock (DateTime.MaxValue sentinel) entries are always restored —
        ///     they must survive restart by design.
        /// Best-effort: any I/O or parse error is logged and swallowed.
        /// FIX #7 (risk-state persistence).
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private void LoadState()
        {
            if (_statePath == null || !File.Exists(_statePath)) return;

            try
            {
                string json = File.ReadAllText(_statePath, Encoding.UTF8);
                var snap    = JsonConvert.DeserializeObject<RiskStateSnapshot>(json);
                if (snap == null) return;

                string todayUtc = DateTime.UtcNow.ToString("yyyy-MM-dd");
                DateTime now    = DateTime.UtcNow;

                // Compute current week start (Sunday, same logic as GetWeeklyPnL).
                DateTime localNow      = DateTime.Now;
                int      daysSunday    = (int)localNow.DayOfWeek; // Sunday == 0
                string   weekStartKey  = localNow.Date.AddDays(-daysSunday).ToString("yyyy-MM-dd");

                // --- daily_copier_opens: keep only entries matching today's UTC date ---
                foreach (var kv in snap.DailyCopierOpens)
                {
                    // Key format: "{ruleId}:{accountName}:{yyyy-MM-dd}"
                    // Discard if the trailing date segment != today.
                    if (!kv.Key.EndsWith(":" + todayUtc, StringComparison.Ordinal)) continue;
                    _dailyCopierOpens[kv.Key] = kv.Value;
                }

                // --- loss_streaks: restore as-is (no date boundary — streak
                //     is reset by wins, not by date) ---
                foreach (var kv in snap.LossStreaks)
                    _lossStreaks[kv.Key] = kv.Value;

                // --- tilt_until: restore only if still in the future or MaxValue ---
                foreach (var kv in snap.TiltUntilUtc)
                {
                    if (kv.Value == MaxValueSentinel)
                    {
                        _tiltUntil[kv.Key] = DateTime.MaxValue;
                    }
                    else if (DateTime.TryParse(kv.Value, null,
                        System.Globalization.DateTimeStyles.RoundtripKind, out DateTime dt))
                    {
                        if (dt > now) _tiltUntil[kv.Key] = dt;
                        // Expired tilt cooldowns are intentionally discarded.
                    }
                }

                // --- locked_until (close_lock) ---
                // WI-1 backward-compat: legacy "MAX" sentinel (written before WI-1) is
                // converted to NextSessionOpenUtc(now) so old saved state resets correctly
                // at the next session boundary rather than locking forever.
                // Real timestamps: restore if still in the future, discard if expired.
                foreach (var kv in snap.LockedUntilUtc)
                {
                    if (kv.Value == MaxValueSentinel)
                    {
                        // Legacy sentinel → treat as "next session open" (WI-1 backward-compat).
                        DateTime legacyExpiry = NextSessionOpenUtc(now);
                        if (legacyExpiry > now) _lockedUntil[kv.Key] = legacyExpiry;
                        // If next-open is somehow in the past (clock skew edge case), discard.
                    }
                    else if (DateTime.TryParse(kv.Value, null,
                        System.Globalization.DateTimeStyles.RoundtripKind, out DateTime dt))
                    {
                        // Restore only if still in the future; expired locks are discarded.
                        if (dt > now) _lockedUntil[kv.Key] = dt;
                    }
                }

                // --- copier_paused_until: same backward-compat logic as locked_until ---
                foreach (var kv in snap.CopierPausedUntilUtc)
                {
                    if (kv.Value == MaxValueSentinel)
                    {
                        // Legacy sentinel → treat as "next session open" (WI-1 backward-compat).
                        DateTime legacyExpiry = NextSessionOpenUtc(now);
                        if (legacyExpiry > now) _copierPausedUntil[kv.Key] = legacyExpiry;
                    }
                    else if (DateTime.TryParse(kv.Value, null,
                        System.Globalization.DateTimeStyles.RoundtripKind, out DateTime dt))
                    {
                        if (dt > now) _copierPausedUntil[kv.Key] = dt;
                    }
                }

                // --- weekly_pnl_baseline: keep only entries matching the current week ---
                foreach (var kv in snap.WeeklyPnLBaseline)
                {
                    // Key format: "{accountName}:{yyyy-MM-dd}" (week-start date)
                    if (!kv.Key.EndsWith(":" + weekStartKey, StringComparison.Ordinal)) continue;
                    _weeklyPnLBaseline[kv.Key] = kv.Value;
                }

                int totalLoaded = _dailyCopierOpens.Count + _lossStreaks.Count
                    + _tiltUntil.Count + _lockedUntil.Count
                    + _copierPausedUntil.Count + _weeklyPnLBaseline.Count;

                _log($"RiskEnforcer.LoadState: restored {totalLoaded} enforcement state entries " +
                     $"from '{_statePath}' (saved at {snap.SavedAtUtc}).");
            }
            catch (Exception ex)
            {
                _log($"RiskEnforcer.LoadState: failed to load state (non-fatal — starting fresh): " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // WI-0: CME Globex session-clock helper
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns the UTC timestamp of the next CME Globex futures trading-day open.
        ///
        /// CME Globex daily reset boundary is 17:00 America/Chicago (Central Time).
        /// The session runs Sunday 17:00 CT → Friday 16:00 CT; there is NO Saturday
        /// session and no Friday-evening re-open. The next open after Friday 16:00 is
        /// Sunday 17:00 CT.
        ///
        /// Algorithm:
        ///   1. Convert nowUtc to Central time.
        ///   2. Compute candidate target = today 17:00 CT.
        ///      If Central-now >= 17:00 CT today, advance target to tomorrow 17:00 CT.
        ///   3. Apply weekend snap:
        ///      - target falls on Saturday → advance to Sunday 17:00 CT.
        ///      - target falls on Sunday but before 17:00 CT → snap to Sunday 17:00 CT
        ///        (already handled by the base algorithm since we always set :17:00).
        ///      Combined: if target.DayOfWeek == Saturday → move +1 day (to Sunday 17:00 CT).
        ///   4. Convert target (unspecified/local) back to UTC via TimeZoneInfo.
        ///   5. Return UTC.
        ///
        /// Pure function — deterministic on nowUtc, no side-effects, easily testable.
        /// Windows TZ id "Central Standard Time" covers both CST and CDT automatically.
        /// </summary>
        public static DateTime NextSessionOpenUtc(DateTime nowUtc)
        {
            // Step 1: get Central timezone (handles CST/CDT automatically on Windows).
            TimeZoneInfo central = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");

            // Step 2: convert to Central and compute target = "today 17:00 CT".
            DateTime centralNow = TimeZoneInfo.ConvertTimeFromUtc(nowUtc, central);
            DateTime target     = centralNow.Date.AddHours(17); // today 17:00 CT

            // If we are AT or PAST today's 17:00 reset, move to tomorrow's 17:00.
            if (centralNow >= target)
                target = target.AddDays(1);

            // Step 3: weekend snap.
            // CME is closed Fri 16:00 CT → Sun 17:00 CT.
            // A 17:00 boundary that lands on Saturday has no session — advance to Sunday.
            // (Friday 16:00 close means the NEXT 17:00 on Friday does not exist; any
            //  target that became Saturday is safe to bump to Sunday 17:00 CT.)
            if (target.DayOfWeek == DayOfWeek.Saturday)
                target = target.AddDays(1); // Saturday 17:00 → Sunday 17:00 CT

            // Sunday before 17:00 is impossible here because we always set target to 17:00
            // (AddHours(17)), so a Sunday target is always Sunday 17:00 CT — correct.

            // Step 4: convert back to UTC.
            // Specify kind = Unspecified so ConvertTimeToUtc treats it as Central local time.
            DateTime targetUtc = TimeZoneInfo.ConvertTimeToUtc(
                DateTime.SpecifyKind(target, DateTimeKind.Unspecified), central);

            return targetUtc;
        }

        // -----------------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------------

        private static BrokerConnection FindConnection(AutomationConfig config, string connectionId)
        {
            if (config?.Connections == null || connectionId == null) return null;
            return config.Connections.Find(c => c.Id == connectionId);
        }

        /// <summary>
        /// Attempts to find a BrokerConnection whose AccountId or account_name
        /// matches the given broker account name string.
        /// Returns null if no match (best-effort — used only for event payload enrichment).
        /// </summary>
        private static BrokerConnection FindConnectionByAccountName(
            AutomationConfig config, string accountName)
        {
            if (config?.Connections == null || string.IsNullOrWhiteSpace(accountName)) return null;
            return config.Connections.Find(c =>
                string.Equals(c.AccountId, accountName, StringComparison.OrdinalIgnoreCase));
        }
    }
}
