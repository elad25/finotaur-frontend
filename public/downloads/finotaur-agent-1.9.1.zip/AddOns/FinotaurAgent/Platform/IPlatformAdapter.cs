// =============================================================================
// Finotaur Agent — Platform/IPlatformAdapter.cs
//
// Abstraction layer between the agent's logic (RiskEnforcer, CopierEngine)
// and the platform-specific trading APIs.
//
// The current concrete implementation is NinjaTraderAdapter (NT8).
// The interface is designed so a future adapter (e.g. for a different platform
// or a mock for unit testing) can be dropped in without changing the engines.
//
// KEY DESIGN DECISIONS (document for future implementors):
//   1. All monetary values are in USD.
//   2. Positions are current open positions (not historical fills).
//   3. "Session realized PnL" means today's closed P&L from the broker
//      (or as close as the platform API allows — document approximations).
//   4. PlaceMarketOrder is fire-and-forget from the caller's perspective;
//      fill confirmation comes via the FillSubscription callback.
//   5. account_id from BrokerConnection is matched to platform accounts by
//      the adapter. If no match is found, the adapter skips that account
//      and must NOT guess.
// =============================================================================

using System;
using System.Collections.Generic;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform
{
    /// <summary>
    /// Controls which orders SubscribeOrders delivers to its callback — see
    /// IPlatformAdapter.SubscribeOrders for the full contract.
    /// </summary>
    public enum OrderNameFilter
    {
        /// <summary>Deliver all orders except our own ("Finotaur*"-named) orders.</summary>
        SkipFinotaur,

        /// <summary>Deliver ONLY our own mirrored follower orders ("FinotaurCopier|ord|*").</summary>
        OnlyFinotaurMirrors
    }

    /// <summary>
    /// Platform-agnostic trading interface used by RiskEnforcer and CopierEngine.
    /// All implementations must be thread-safe (the agent runs a background loop).
    /// </summary>
    public interface IPlatformAdapter : IDisposable
    {
        // -----------------------------------------------------------------------
        // Account discovery
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns all accounts currently visible to the platform.
        /// Includes simulation and live accounts — callers must filter by environment.
        /// NEVER returns null; returns an empty collection if no accounts are found.
        /// </summary>
        IEnumerable<AgentAccount> GetAccounts();

        /// <summary>
        /// Attempts to resolve a BrokerConnection (from the server config) to a
        /// local platform account name. Returns null if no confident match is found.
        /// Callers MUST treat null as "skip this connection — do nothing."
        ///
        /// Used by: risk-rule resolution (which still keys off BrokerConnectionId).
        /// For copier routing, prefer <see cref="ResolveAccountByName"/> which
        /// matches directly on the broker account name string.
        /// </summary>
        string ResolveAccountName(BrokerConnection connection);

        /// <summary>
        /// Resolves a broker account name (e.g. "MFFUEVBLDR161429081" — the value
        /// the FINOTAUR server returns as <c>account_name</c> on an
        /// <c>AutomationAccount</c>, <c>CopierRoute.SourceAccountName</c>, or
        /// <c>CopierTarget.DestinationAccountName</c>) to the local NT
        /// <c>Account.Name</c>.
        ///
        /// <para>
        /// Matching is case-insensitive and trims leading/trailing whitespace.
        /// Returns the NT account's own <c>Account.Name</c> string (canonical form)
        /// on success, or <c>null</c> if no local account matches.
        /// </para>
        ///
        /// <para>
        /// Callers MUST treat null as "this account is not connected in NT8 —
        /// skip the route/target and emit a diagnostic event."  Do NOT guess.
        /// </para>
        /// </summary>
        /// <param name="accountName">
        /// The broker account name from the server config (e.g.
        /// "MFFUEVBLDR161429081").  Must not be null or whitespace.
        /// </param>
        /// <returns>
        /// The NT <c>Account.Name</c> of the matching local account, or
        /// <c>null</c> if no confident match was found.
        /// </returns>
        string ResolveAccountByName(string accountName);

        // -----------------------------------------------------------------------
        // Account name enumeration (used by telemetry snapshot)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns the NT8 Account.Name for every account currently visible to the
        /// platform. Used by the account-snapshot telemetry to enumerate accounts
        /// without filtering by config.
        /// NEVER returns null; returns an empty array if no accounts are found.
        /// </summary>
        string[] GetAccountNames();

        /// <summary>
        /// Returns the cash balance (account equity / cash value) for the named
        /// account in USD.
        /// VERIFY (NT8 API): reads account.Get(AccountItem.CashValue, Currency.UsDollar).
        /// Returns null if the account is not found or the value is unavailable.
        /// </summary>
        double? GetCashBalance(string accountName);

        // -----------------------------------------------------------------------
        // Position and PnL queries
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns all current open positions for the named account.
        /// Returns an empty array if the account has no positions or is not found.
        /// NEVER returns null.
        /// </summary>
        AgentPosition[] GetPositions(string accountName);

        /// <summary>
        /// Returns today's realized PnL (closed trades only) for the named account,
        /// in USD. Returns 0.0 if unavailable (never throws).
        /// VERIFY (NT8 API): NinjaTrader's Account.Get(AccountItem.CashValue) or
        /// similar may be needed. Document the exact API call in NinjaTraderAdapter.
        /// </summary>
        double GetSessionRealizedPnL(string accountName);

        /// <summary>
        /// Returns the total unrealized PnL across all open positions for the
        /// named account, in USD. Returns 0.0 if unavailable.
        /// </summary>
        double GetOpenPnL(string accountName);

        /// <summary>
        /// Returns the total number of open contracts across all instruments for
        /// the named account. If symbol is provided, scopes to that instrument only.
        /// Returns 0 if account is not found.
        /// </summary>
        int GetOpenContracts(string accountName, string symbol = null);

        // -----------------------------------------------------------------------
        // Order actions (all must be locally guarded by the caller)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Flattens ALL open positions on the named account immediately using a
        /// market order. Used by the daily-loss risk enforcer.
        ///
        /// FAIL-SAFE: If the account cannot be found, DO NOTHING and return false.
        /// Never throw. Never guess.
        /// </summary>
        /// <returns>True if the flatten command was issued, false if skipped/errored.</returns>
        bool FlattenAll(string accountName);

        /// <summary>
        /// Flattens open positions in a specific instrument on the named account.
        /// Used for per-symbol risk enforcement.
        /// FAIL-SAFE: same rules as FlattenAll.
        /// </summary>
        bool FlattenSymbol(string accountName, string symbol);

        /// <summary>
        /// Cancels ALL working orders (Working / Accepted / Submitted) on the
        /// named account. Filled and already-cancelled orders are skipped.
        ///
        /// FAIL-SAFE: If the account cannot be found, DO NOTHING and return false.
        /// Never throw. Never guess.
        /// </summary>
        /// <returns>
        /// True if a cancel command was issued (or there were no working orders
        /// to cancel). False if the account was not found or an error occurred.
        /// </returns>
        bool CancelAllOrders(string accountName);

        /// <summary>
        /// Places a market order for the specified quantity.
        /// Used by CopierEngine to mirror source fills.
        ///
        /// FAIL-SAFE: If account, instrument, or quantity cannot be validated,
        /// DO NOTHING and return false. Never throw.
        /// </summary>
        /// <param name="accountName">Target account name (resolved by ResolveAccountName).</param>
        /// <param name="instrumentName">NT8 instrument name, e.g. "NQ 09-26".</param>
        /// <param name="isBuy">true = Buy, false = Sell.</param>
        /// <param name="quantity">Number of contracts. Must be >= 1.</param>
        /// <param name="orderName">NT8 order Name (visible in Executions tab). The copier passes a tokenized name "FinotaurCopier|&lt;token&gt;" so follower fills can be correlated for latency measurement. Defaults to "FinotaurCopier".</param>
        /// <returns>True if order was submitted, false if skipped.</returns>
        bool PlaceMarketOrder(string accountName, string instrumentName, bool isBuy, int quantity, string orderName = "FinotaurCopier");

        // -----------------------------------------------------------------------
        // Fill subscription (used by CopierEngine)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Registers a callback that fires on every new fill on the named account.
        /// The callback receives a normalized FillInfo object.
        ///
        /// Callers must call Unsubscribe with the returned handle to deregister.
        /// Multiple subscriptions on the same account are supported.
        /// </summary>
        /// <param name="accountName">Account to watch.</param>
        /// <param name="onFill">Callback fired on each new fill.</param>
        /// <returns>
        /// An opaque subscription handle passed to Unsubscribe.
        /// Returns null if the account was not found — caller must not proceed.
        /// </returns>
        object SubscribeFills(string accountName, Action<FillInfo> onFill);

        /// <summary>
        /// Deregisters a fill subscription previously returned by SubscribeFills.
        /// Safe to call with a null handle (no-op).
        /// </summary>
        void Unsubscribe(object subscriptionHandle);

        // -----------------------------------------------------------------------
        // Working-order lifecycle + placement (analogous to fill subscription)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Registers a callback that fires on every WORKING-order lifecycle event
        /// (state change) on the named account. The callback receives a normalized
        /// OrderInfo object.
        ///
        /// Callers must call Unsubscribe with the returned handle to deregister —
        /// the same Unsubscribe method used for fill subscriptions handles both.
        /// </summary>
        /// <param name="accountName">Account to watch.</param>
        /// <param name="onOrder">Callback fired on each order state change.</param>
        /// <param name="filter">
        /// Controls which orders are delivered to <paramref name="onOrder"/>:
        ///   • SkipFinotaur (default): deliver everything EXCEPT orders whose
        ///     Name starts with "Finotaur" (the existing own-order feedback-loop
        ///     guard, used when subscribing SOURCE/leader accounts).
        ///   • OnlyFinotaurMirrors: deliver ONLY orders whose Name starts with
        ///     "FinotaurCopier|ord|" (drop everything else, including the
        ///     user's own manual orders). Used when subscribing TARGET/follower
        ///     accounts to observe the lifecycle of our own mirrored orders
        ///     (e.g. late broker rejects, external cancels) without generating
        ///     any traffic for orders we don't own.
        /// </param>
        /// <returns>
        /// An opaque subscription handle passed to Unsubscribe.
        /// Returns null if the account was not found — caller must not proceed.
        /// </returns>
        object SubscribeOrders(string accountName, Action<OrderInfo> onOrder,
                               OrderNameFilter filter = OrderNameFilter.SkipFinotaur);

        /// <summary>
        /// Places a working (non-market) order.
        ///
        /// FAIL-SAFE: If account, instrument, quantity, or orderType cannot be
        /// validated, DO NOTHING and return null. Never throw.
        /// </summary>
        /// <param name="accountName">Target account name (resolved by ResolveAccountName).</param>
        /// <param name="instrumentName">NT8 instrument name, e.g. "NQ 09-26".</param>
        /// <param name="isBuy">true = Buy, false = Sell.</param>
        /// <param name="quantity">Number of contracts. Must be >= 1.</param>
        /// <param name="orderType">"limit" | "stop" | "stoplimit".</param>
        /// <param name="limitPrice">Limit price. Used for "limit" and "stoplimit".</param>
        /// <param name="stopPrice">Stop price. Used for "stop" and "stoplimit".</param>
        /// <param name="orderName">NT8 order Name (visible in Executions tab). Defaults to "FinotaurCopier".</param>
        /// <param name="tif">"day" | "gtc" — mirrors the leader's TimeInForce. Defaults to "day".</param>
        /// <param name="oco">Follower OCO group id (empty = not part of a group). Defaults to "".</param>
        /// <returns>The follower order's NT8 Order.Id (string) on success, or null on failure.</returns>
        string PlaceWorkingOrder(string accountName, string instrumentName, bool isBuy, int quantity,
                                 string orderType, double limitPrice, double stopPrice,
                                 string orderName = "FinotaurCopier", string tif = "day", string oco = "");

        /// <summary>
        /// Modifies an existing working order (found by NT8 Order.Id).
        /// Pass &lt;=0 for a field to leave it unchanged.
        ///
        /// FAIL-SAFE: If the account or order cannot be found (or the order is no
        /// longer live), DO NOTHING and return false. Never throw.
        /// </summary>
        /// <param name="accountName">Account the order lives on.</param>
        /// <param name="orderId">NT8 Order.Id (string) of the order to modify.</param>
        /// <param name="newQuantity">New quantity, or &lt;=0 to leave unchanged.</param>
        /// <param name="newLimitPrice">New limit price, or &lt;=0 to leave unchanged.</param>
        /// <param name="newStopPrice">New stop price, or &lt;=0 to leave unchanged.</param>
        /// <returns>True if the modify was submitted, false if skipped/errored.</returns>
        bool ModifyWorkingOrder(string accountName, string orderId, int newQuantity, double newLimitPrice, double newStopPrice);

        /// <summary>
        /// Cancels a single working order by NT8 Order.Id.
        ///
        /// FAIL-SAFE: If the account or order cannot be found (or the order is no
        /// longer live), DO NOTHING and return false. Never throw.
        /// </summary>
        /// <param name="accountName">Account the order lives on.</param>
        /// <param name="orderId">NT8 Order.Id (string) of the order to cancel.</param>
        /// <returns>True if the cancel was submitted, false if skipped/errored.</returns>
        bool CancelWorkingOrder(string accountName, string orderId);

        /// <summary>
        /// Polls the order until it leaves live states or timeoutMs elapses. Returns
        /// "cancelled"|"filled"|"rejected"|"gone"|"timeout". Never throws.
        /// Background threads only — never the NT thread.
        /// </summary>
        /// <param name="accountName">Account the order lives on.</param>
        /// <param name="orderId">NT8 Order.Id (string) of the order to poll.</param>
        /// <param name="timeoutMs">Max time to poll before giving up and returning "timeout".</param>
        /// <returns>"cancelled" | "filled" | "rejected" | "gone" | "timeout".</returns>
        string AwaitOrderTerminal(string accountName, string orderId, int timeoutMs);

        /// <summary>
        /// Returns all working orders for the named account. By default only live
        /// (working/accepted/submitted/changesubmitted/partfilled) orders are
        /// included; pass includeTerminal=true to also include Filled/Cancelled/
        /// Rejected orders.
        /// NEVER returns null; returns an empty array if the account is not found
        /// or has no matching orders.
        /// </summary>
        /// <param name="accountName">Account to enumerate.</param>
        /// <param name="includeTerminal">
        /// If true, also include orders in Filled/Cancelled/Rejected state.
        /// </param>
        AgentWorkingOrder[] GetWorkingOrders(string accountName, bool includeTerminal = false);

        // -----------------------------------------------------------------------
        // Lock guard (WI-3)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Starts a real-time hard lock guard on the named account.
        /// While <paramref name="stillLocked"/> returns true, the guard:
        ///   • Cancels any newly submitted non-Finotaur orders immediately.
        ///   • Flattens any non-Flat position immediately.
        /// Subscribes to Account.OrderUpdate and Account.PositionUpdate events.
        /// If a guard is already registered for this account, it updates the
        /// delegate and returns without double-subscribing.
        /// Safe to call if the account is not found (no-op + log).
        /// </summary>
        /// <param name="accountName">The NT account name to guard.</param>
        /// <param name="stillLocked">
        /// Delegate queried on every event. When it returns false the guard
        /// self-deregisters — the lock has expired or been cleared.
        /// </param>
        void StartLockGuard(string accountName, System.Func<bool> stillLocked);

        /// <summary>
        /// Stops the hard lock guard on the named account, unsubscribing the
        /// OrderUpdate and PositionUpdate handlers.
        /// Safe to call if no guard is registered (no-op).
        /// </summary>
        void StopLockGuard(string accountName);
    }

    // -------------------------------------------------------------------------
    // Supporting types used by IPlatformAdapter
    // -------------------------------------------------------------------------

    /// <summary>
    /// A single open position on a platform account.
    /// </summary>
    public class AgentPosition
    {
        /// <summary>Platform instrument name (e.g. "NQ 09-26", "ES 09-26").</summary>
        public string InstrumentName { get; set; }

        /// <summary>Number of open contracts (always positive).</summary>
        public int Quantity { get; set; }

        /// <summary>true = Long, false = Short.</summary>
        public bool IsLong { get; set; }

        /// <summary>Average entry price for this position.</summary>
        public double AveragePrice { get; set; }

        /// <summary>Current unrealized PnL for this position in USD.</summary>
        public double UnrealizedPnL { get; set; }

        /// <summary>
        /// Current market value of the position in USD (quantity * price * point value).
        /// VERIFY (NT8 API): may require Instrument.MasterInstrument.PointValue.
        /// Set to 0.0 if not computable — RiskEnforcer will skip max_position_usd check.
        /// </summary>
        public double MarketValueUsd { get; set; }
    }

    /// <summary>
    /// A single working order snapshot returned by GetWorkingOrders. Distinct from
    /// OrderInfo (the SubscribeOrders lifecycle-event payload) — this is a
    /// point-in-time read, not an event.
    /// </summary>
    public class AgentWorkingOrder
    {
        /// <summary>NT8 Order.Id.ToString().</summary>
        public string OrderId { get; set; }

        /// <summary>Order.Name (used to identify our own "Finotaur*" orders).</summary>
        public string Name { get; set; }

        /// <summary>Instrument.FullName e.g. "NQ 09-26".</summary>
        public string InstrumentName { get; set; }

        /// <summary>true = Buy/BuyToCover, false = Sell/SellShort.</summary>
        public bool IsBuy { get; set; }

        public int Quantity { get; set; }

        /// <summary>"limit" | "stop" | "stoplimit" | "mit" | "market" | "other"</summary>
        public string OrderType { get; set; }

        public double LimitPrice { get; set; }

        public double StopPrice { get; set; }

        /// <summary>"day" | "gtc" — anything else normalized to "day".</summary>
        public string Tif { get; set; }

        /// <summary>
        /// "working"|"accepted"|"submitted"|"changesubmitted"|"partfilled"|
        /// "filled"|"cancelled"|"rejected"|"other"
        /// </summary>
        public string State { get; set; }
    }
}
