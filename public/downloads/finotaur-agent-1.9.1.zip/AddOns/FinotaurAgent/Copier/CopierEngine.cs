// =============================================================================
// Finotaur Agent — Copier/CopierEngine.cs
//
// LOCAL trade-copy engine. Mirrors fills from one NT8 account (the "source")
// to one or more NT8 accounts (the "targets") on the SAME user — completely
// locally, with ZERO network calls on the hot path.
//
// ═══════════════════════════════════════════════════════════════════════════
// COMPLIANCE BOUNDARY (DO NOT REMOVE THIS COMMENT)
// ═══════════════════════════════════════════════════════════════════════════
//   • All order placement uses NT8's local NinjaTrader.Cbi APIs only.
//   • This engine NEVER calls Tradovate, NinjaTrader Cloud, or any broker
//     REST/WebSocket API directly. The execution path is 100% local.
//   • Copying is strictly user-to-self: both source and all targets are
//     the same user's accounts (guaranteed by the server config — the server
//     only returns this user's connections).
//   • FAIL-SAFE: when in doubt, DO NOTHING. Every uncertain path returns
//     without placing orders. No order is ever speculative.
// ═══════════════════════════════════════════════════════════════════════════
//
// SCALE DESIGN (Elad requirement: ~60 accounts/user, fast fan-out):
//
//   HOT PATH IS 100% LOCAL, ZERO NETWORK PER FILL.
//     The NT8 ExecutionUpdate callback does the MINIMUM: validate the fill
//     against the locally-cached config, enqueue a CopyJob to the worker
//     queue, then return immediately. The NT thread is never blocked.
//
//   CONCURRENT FAN-OUT, OFF THE NT THREAD.
//     A dedicated background consumer (BlockingCollection<CopyJob>) dequeues
//     copy jobs and fans out to all targets concurrently via Task.WhenAll.
//     With up to ~59 targets per source fill, PlaceMarketOrder calls run in
//     parallel — the NT data thread is never stalled.
//
//   ONE AGGREGATED EVENT PER SOURCE FILL.
//     After the fan-out completes, ONE 'copy_executed' event is posted
//     summarizing: source symbol/qty, target count, per-target {account,
//     qty, ok/fail}. Failures are included in the same event (or a separate
//     'copy_failed' if the aggregated payload becomes too large — see
//     BATCH_MAX_FAILURES below). We NEVER emit one event per target.
//
//   IDEMPOTENCY.
//     Processed source ExecutionIds are tracked in a bounded concurrent set.
//     On reconnect or replay, duplicate fills are silently dropped.
//
//   TELEMETRY BATCHING (event queue).
//     Events are buffered in a ConcurrentQueue and flushed asynchronously
//     by the agent's background loop (not by the copy hot path). The copy
//     path enqueues and returns; it never blocks on network I/O.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Copier
{
    // =========================================================================
    // Internal data structures
    // =========================================================================

    /// <summary>
    /// Represents one pending copy-fan-out job. Placed on the worker queue
    /// by the NT fill callback (hot path) and consumed by the background worker.
    /// </summary>
    internal sealed class CopyJob
    {
        /// <summary>The normalized fill that triggered this copy.</summary>
        public FillInfo SourceFill { get; set; }

        /// <summary>The route that matched this fill.</summary>
        public CopierRoute Route { get; set; }

        /// <summary>Snapshot of config at the moment the job was enqueued.</summary>
        public AutomationConfig Config { get; set; }

        /// <summary>
        /// EXIT-SYNC (v1.8.0): true when this fill came from a leader order that
        /// was previously mirrored as a working order (see WasLeaderOrderMirrored).
        /// Instead of being skipped outright, the job is routed through the normal
        /// net-reconcile fan-out AND, as a pre-step, forces a cancel + resync of
        /// the twin follower order(s) so the follower never double-fills (its own
        /// working order firing independently) and never drifts from the leader's
        /// exit. See ProcessJobAsync's exit-sync pre-step.
        /// </summary>
        public bool IsExitSync { get; set; }

        /// <summary>
        /// The leader OrderId whose mirrored working order produced this fill.
        /// Only set when IsExitSync is true. Used to look up (and remove) the
        /// MirroredOrder mapping under the per-leader-order lock.
        /// </summary>
        public string ExitSyncLeaderOrderId { get; set; }
    }

    /// <summary>
    /// Per-target result after attempting a mirrored order.
    /// Used to build the single aggregated 'copy_executed' event.
    /// </summary>
    internal sealed class TargetResult
    {
        /// <summary>
        /// The destination account name from the server config
        /// (DestinationAccountName when available, DestinationConnectionId as fallback).
        /// Used in the aggregated event payload for diagnostics on the web side.
        /// </summary>
        public string DestinationAccountName { get; set; }

        /// <summary>Resolved local NT account name (null if resolution failed).</summary>
        public string AccountName            { get; set; }
        public int    Quantity               { get; set; }
        public bool   Success                { get; set; }
        public string FailureReason          { get; set; }

        /// <summary>
        /// EXIT-SYNC (v1.8.0): terminal state of the twin follower order that was
        /// awaited before this reconcile ran ("cancelled"|"filled"|"rejected"|
        /// "gone"|"timeout"), or null when this target's placement was not part
        /// of an exit-sync job (no twin to await).
        /// </summary>
        public string TwinState              { get; set; }
    }

    // =========================================================================
    // WORKING-ORDER MIRRORING — internal data structures
    //
    // This is a SEPARATE path, ALONGSIDE the fill-copy path above. It mirrors
    // the LEADER's working (limit/stop/stoplimit) orders onto the followers as
    // their own working orders, so the follower fills independently at the
    // same trigger price instead of receiving a market order when the leader
    // fills. See CopierEngine._orderQueue / ProcessOrderJob for the full flow.
    // =========================================================================

    /// <summary>
    /// One pending order-mirroring job. Placed on <see cref="CopierEngine"/>'s
    /// order worker queue by the NT OrderUpdate callback (hot path) and
    /// consumed by the dedicated order-consumer background task.
    /// </summary>
    internal sealed class OrderCopyJob
    {
        /// <summary>The normalized leader working-order event that triggered this job.</summary>
        public OrderInfo SourceOrder { get; set; }

        /// <summary>The route that matched this order.</summary>
        public CopierRoute Route { get; set; }

        /// <summary>Snapshot of config at the moment the job was enqueued.</summary>
        public AutomationConfig Config { get; set; }

        /// <summary>
        /// RESILIENCE (v1.9.0): true when this job originated from a FOLLOWER
        /// (target-account) order-lifecycle event — i.e. SourceOrder is actually
        /// the follower/mirror order itself (Name "FinotaurCopier|ord|..."), not
        /// a leader order. Routed to HandleFollowerOrderEvent instead of the
        /// normal PLACEMENT/MODIFY/CANCEL switch in ProcessOrderJob.
        /// </summary>
        public bool IsFollowerEvent { get; set; }
    }

    /// <summary>
    /// STEP 5 (copier-state persistence): on-disk snapshot of
    /// CopierEngine._everMirroredOrderIds, so the fill-skip idempotency check
    /// survives an agent restart. Mirrors RiskEnforcer.RiskStateSnapshot's
    /// shape/conventions. Order is oldest→newest (same order as the in-memory
    /// eviction queue), so LoadCopierState can replay TryAdd + enqueue exactly.
    /// </summary>
    internal sealed class CopierStateSnapshot
    {
        public string SavedAtUtc { get; set; }
        public List<string> EverMirroredOrderIds { get; set; } = new List<string>();
    }

    /// <summary>
    /// One follower working order that was placed to mirror a leader working
    /// order on a specific target account.
    /// </summary>
    internal sealed class MirroredTarget
    {
        /// <summary>Resolved local NT account name of the follower.</summary>
        public string TargetAccount { get; set; }

        /// <summary>The follower's NT8 Order.Id, as returned by PlaceWorkingOrder.</summary>
        public string FollowerOrderId { get; set; }

        /// <summary>
        /// Snapshot of CopierTarget.ScaleRatio at placement time, retained so a
        /// later MODIFY can recompute the follower quantity from the leader's
        /// new quantity using the SAME ratio/clamp as the original placement.
        /// </summary>
        public double ScaleRatio { get; set; } = 1.0;

        /// <summary>Snapshot of CopierTarget.MaxContracts at placement time (null = no cap).</summary>
        public int? MaxContracts { get; set; }

        /// <summary>
        /// The translated (TranslateInstrument) instrument name used for this
        /// target at placement time. Used by STEP 3's modify-time risk gate,
        /// which must check the FOLLOWER's instrument (which may differ from
        /// the leader's via CrossToMicro), not the leader's raw symbol.
        /// </summary>
        public string Instrument { get; set; }

        /// <summary>
        /// The follower OCO group id this target's order was placed with (empty =
        /// leader order was not part of an OCO group). Derived via MakeFollowerOco
        /// from (leader's OcoId, TargetAccount) — deterministic so sibling legs
        /// mirrored by separate ProcessOrderPlacement calls join the same group.
        /// </summary>
        public string FollowerOco { get; set; } = string.Empty;
    }

    /// <summary>
    /// Tracks a leader working order that has been mirrored to one or more
    /// follower accounts. Keyed by the leader's OrderId in
    /// <see cref="CopierEngine._mirroredLeaderOrders"/>. Used to route
    /// subsequent modify/cancel/fill events on the same leader order to the
    /// correct follower orders.
    /// </summary>
    internal sealed class MirroredOrder
    {
        public string RouteId { get; set; }
        public string LeaderOrderId { get; set; }

        /// <summary>Last-known leader limit price (0 if not applicable to the order type).</summary>
        public double LastLimit { get; set; }

        /// <summary>Last-known leader stop price (0 if not applicable to the order type).</summary>
        public double LastStop { get; set; }

        /// <summary>Last-known leader quantity.</summary>
        public int LastQty { get; set; }

        /// <summary>
        /// Snapshot of the leader order's TimeInForce at placement time ("day" |
        /// "gtc"). Not re-read on modify — TIF is set once at placement mirroring
        /// and is not expected to change on an existing order.
        /// </summary>
        public string Tif { get; set; } = "day";

        /// <summary>
        /// TRAILING/MODIFY DEBOUNCE (v1.8.0): monotonic Stopwatch.GetTimestamp() of
        /// the last time a modify was actually SUBMITTED for this leader order's
        /// followers (not merely requested — only stamped on a genuine submit).
        /// Used by ProcessOrderJob's modify branches to decide whether a new
        /// modify request should submit immediately or coalesce into
        /// _pendingModifies for a later flush.
        /// </summary>
        public long LastModifySubmitTicks;

        /// <summary>
        /// Snapshot of the leader order's OCO group id (OrderInfo.OcoId) at
        /// placement time ("" when the leader order was not part of an OCO group).
        /// </summary>
        public string LeaderOco { get; set; } = string.Empty;

        public List<MirroredTarget> Targets { get; set; } = new List<MirroredTarget>();
    }

    // =========================================================================
    // CopierEngine
    // =========================================================================

    /// <summary>
    /// Manages fill subscriptions for all active copier routes, fans out mirrored
    /// orders concurrently, and enqueues aggregated telemetry events.
    ///
    /// Lifecycle:
    ///   1. Call ApplyConfig() whenever the agent receives a new AutomationConfig.
    ///   2. The engine subscribes/unsubscribes as routes change.
    ///   3. Call Dispose() when the AddOn shuts down.
    /// </summary>
    public sealed class CopierEngine : IDisposable
    {
        // -----------------------------------------------------------------------
        // Cross-instrument map (full ↔ micro, bidirectional).
        // Key = SOURCE root symbol (upper-case), Value = TARGET root symbol.
        // Used when CopierTarget.CrossToMicro == true.
        // Quantity is NOT adjusted here — scale_ratio handles sizing.
        // -----------------------------------------------------------------------

        private static readonly Dictionary<string, string> CrossMap =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // Equity index futures (CME)
            { "NQ",  "MNQ" }, { "MNQ", "NQ"  },
            { "ES",  "MES" }, { "MES", "ES"  },
            { "RTY", "M2K" }, { "M2K", "RTY" },
            { "YM",  "MYM" }, { "MYM", "YM"  },
            // Metals (CME/COMEX)
            { "GC",  "MGC" }, { "MGC", "GC"  },
            { "SI",  "SIL" }, { "SIL", "SI"  },
            // Energy (CME/NYMEX)
            { "CL",  "MCL" }, { "MCL", "CL"  },
            // FX futures (CME)
            { "6E",  "M6E" }, { "M6E", "6E"  },
            { "6B",  "M6B" }, { "M6B", "6B"  },
            { "6A",  "M6A" }, { "M6A", "6A"  },
            // Crypto futures (CME)
            { "BTC", "MBT" }, { "MBT", "BTC" },
            { "ETH", "MET" }, { "MET", "ETH" },
        };

        /// <summary>
        /// Translates an NT8 full instrument name (e.g. "NQ 09-26") to its
        /// cross-mapped counterpart (e.g. "MNQ 09-26") when CrossToMicro is set.
        ///
        /// The root is the leading token before the first space.  The remainder
        /// (contract month suffix such as " 09-26") is preserved verbatim.
        ///
        /// Returns the original name unchanged if:
        ///   • CrossToMicro is false.
        ///   • The root has no entry in CrossMap.
        ///   • The instrument name is null/empty.
        ///
        /// In all fallback cases a diagnostic message is written via the logger.
        /// The caller MUST NOT drop the order on a fallback — use the original name.
        /// </summary>
        private string TranslateInstrument(string instrumentName, CopierTarget target)
        {
            if (!target.CrossToMicro) return instrumentName;
            if (string.IsNullOrWhiteSpace(instrumentName)) return instrumentName;

            // Split on first space: "NQ 09-26" → root="NQ", suffix=" 09-26"
            int spaceIdx = instrumentName.IndexOf(' ');
            string root   = spaceIdx < 0 ? instrumentName : instrumentName.Substring(0, spaceIdx);
            string suffix = spaceIdx < 0 ? string.Empty   : instrumentName.Substring(spaceIdx);

            if (CrossMap.TryGetValue(root, out string mapped))
            {
                string translated = mapped + suffix;
                _log($"CrossInstrument: '{instrumentName}' → '{translated}' " +
                     $"(CrossToMicro=true, target '{target.DestinationAccountName ?? target.DestinationConnectionId}').");
                return translated;
            }

            // Root not in map — fall back to original, do not drop the copy.
            _log($"CrossInstrument: root '{root}' has no CrossMap entry — " +
                 $"using original instrument '{instrumentName}' (CrossToMicro requested but unsupported root). " +
                 "Add the root pair to CopierEngine.CrossMap if needed.");
            return instrumentName;
        }
        // -----------------------------------------------------------------------
        // Dependencies
        // -----------------------------------------------------------------------

        private readonly IPlatformAdapter   _platform;
        private readonly RiskEnforcer       _risk;
        private readonly Action<string>     _log;

        // -----------------------------------------------------------------------
        // Event queue — telemetry events produced by the copier are placed here.
        // The agent's background loop (FinotaurAgent) drains this queue and
        // flushes to the server via FinotaurClient in batches.
        // The copier NEVER calls FinotaurClient directly — no network on hot path.
        // -----------------------------------------------------------------------

        private readonly ConcurrentQueue<AutomationEvent> _eventQueue;

        // -----------------------------------------------------------------------
        // Worker queue + consumer task
        // The hot path (NT fill callback) enqueues CopyJob objects.
        // A single background consumer Task dequeues and processes them.
        // BlockingCollection provides blocking take + cancellation support.
        // -----------------------------------------------------------------------

        /// <summary>
        /// Maximum pending copy jobs in the queue. If the consumer falls behind
        /// (e.g. NT is very busy), extra fills are silently dropped rather than
        /// blocking the NT thread. In normal operation the queue drains instantly.
        /// </summary>
        private const int WorkerQueueCapacity = 512;

        private readonly BlockingCollection<CopyJob> _workerQueue =
            new BlockingCollection<CopyJob>(WorkerQueueCapacity);

        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private Task _consumerTask;

        // -----------------------------------------------------------------------
        // Active subscriptions — keyed by route.Id
        // Value is the opaque handle returned by IPlatformAdapter.SubscribeFills.
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, object> _subscriptions =
            new ConcurrentDictionary<string, object>();

        // =========================================================================
        // WORKING-ORDER MIRRORING — fields
        //
        // ALONGSIDE (not replacing) the fill-copy path above. Mirrors the leader's
        // working orders (limit/stop/stoplimit) onto followers as their own working
        // orders. Market orders remain handled exclusively by the fill-copy path.
        // =========================================================================

        /// <summary>
        /// Active order subscriptions — keyed by route.Id, parallel to _subscriptions.
        /// Value is the opaque handle returned by IPlatformAdapter.SubscribeOrders.
        /// </summary>
        private readonly ConcurrentDictionary<string, object> _orderSubscriptions =
            new ConcurrentDictionary<string, object>();

        /// <summary>
        /// Leader OrderId → MirroredOrder mapping for working orders currently
        /// being mirrored to one or more followers. Cleared on every config
        /// rebuild (ApplyConfig) — a rebuild loses in-flight modify/cancel
        /// tracking for previously-mirrored orders (logged when it happens).
        /// </summary>
        private readonly ConcurrentDictionary<string, MirroredOrder> _mirroredLeaderOrders =
            new ConcurrentDictionary<string, MirroredOrder>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Bounded FIFO set of leader OrderIds that have EVER been mirrored via
        /// the working-order path, structured exactly like _processedIds /
        /// _idEvictionQueue below. Consulted by the fill-copy hot path to skip
        /// double-copying a fill that came from an order we already mirrored as
        /// a working order (the follower's own working order will fill on its
        /// own). Deliberately NOT cleared on config rebuild — it must survive
        /// reloads so in-flight fills still see the skip.
        /// </summary>
        private const int MaxEverMirroredOrderIds = 100000;
        private readonly ConcurrentDictionary<string, byte> _everMirroredOrderIds =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
        private readonly Queue<string> _everMirroredEvictionQueue = new Queue<string>();
        private readonly object        _everMirroredEvictionLock  = new object();

        /// <summary>
        /// Leader OrderIds whose most recent ProcessOrderPlacement attempt had
        /// EVERY target blocked by the pre-placement risk gate (zero targets
        /// succeeded). No mapping is created for a fully risk-blocked order, so
        /// without this set every subsequent leader OrderUpdate state event
        /// (submitted → accepted → working) would re-run ProcessOrderPlacement,
        /// re-block, and re-emit a duplicate order_copy_failed event. Cleared on
        /// config rebuild (risk rules may change) and on leader terminal states
        /// (filled/cancelled/rejected) so a genuinely re-placed order isn't
        /// wrongly skipped. Scope: risk-blocks only — technical placement
        /// failures (PlaceWorkingOrder returning null, exceptions) are NOT
        /// tracked here and continue to retry on every state event as before.
        /// </summary>
        private readonly ConcurrentDictionary<string, byte> _riskBlockedLeaderOrders =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // STEP 5 (copier-state persistence): path for the JSON snapshot file that
        // persists _everMirroredOrderIds across agent restarts. Mirrors
        // RiskEnforcer's FIX #7 persistence pattern exactly (same directory
        // convention, same best-effort try/catch-swallow semantics).
        // NOTE: untested in this environment — requires NT8 sim verification before live use.
        // -----------------------------------------------------------------------

        private const  string CopierStateFileName = "copier-state.json";
        private readonly string _copierStatePath;

        /// <summary>
        /// Per-leader-order-id locks (like _netLocks below) — serializes
        /// place/modify/cancel handling for one leader order so concurrent
        /// order-state callbacks for the same order cannot race. Cleared on
        /// config rebuild along with _mirroredLeaderOrders.
        /// </summary>
        private readonly ConcurrentDictionary<string, object> _orderLocks =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Maximum pending order-mirroring jobs in the queue. Mirrors
        /// WorkerQueueCapacity — if the order consumer falls behind, extra
        /// order events are dropped rather than blocking the NT thread.
        /// </summary>
        private const int OrderWorkerQueueCapacity = 512;

        private readonly BlockingCollection<OrderCopyJob> _orderQueue =
            new BlockingCollection<OrderCopyJob>(OrderWorkerQueueCapacity);

        private Task _orderConsumerTask;

        // -----------------------------------------------------------------------
        // TRAILING/MODIFY DEBOUNCE (v1.8.0)
        //
        // A trailing-stop leader can emit many rapid-fire modify events for the
        // SAME order (every tick the stop trails). Submitting a broker modify for
        // every single one is wasteful and can hit broker-side rate limits. This
        // coalesces same-order modifies that arrive faster than ModifyDebounceMs
        // apart into a single deferred submit, EXCEPT quantity changes, which
        // always submit immediately (sizing changes are not trailing noise).
        // -----------------------------------------------------------------------

        private const int ModifyDebounceMs = 300;

        /// <summary>
        /// One coalesced-but-not-yet-submitted modify for a leader order. Only the
        /// LATEST OrderInfo/Route/Config for a given leader order is kept — a newer
        /// pending modify simply overwrites the previous one in _pendingModifies.
        /// </summary>
        private sealed class PendingModify
        {
            public OrderInfo         Latest;
            public CopierRoute       Route;
            public AutomationConfig  Config;

            /// <summary>Monotonic Stopwatch.GetTimestamp() when this pending modify becomes due for flush.</summary>
            public long DueTicks;
        }

        /// <summary>
        /// Leader OrderId → coalesced pending modify, keyed identically to
        /// _mirroredLeaderOrders. Drained by FlushDuePendingModifies (called from
        /// OrderConsumerLoop) once DueTicks has elapsed. Cleared on config rebuild
        /// alongside _mirroredLeaderOrders.
        /// </summary>
        private readonly ConcurrentDictionary<string, PendingModify> _pendingModifies =
            new ConcurrentDictionary<string, PendingModify>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // FIX #9/#10 (net-position reconciliation): per-(targetAccount|instrument)
        // tracker for the expected target net position.
        //
        // Key   = "{targetAccountName}|{translatedInstrumentName}"  (pipe-separated,
        //         both components are the locally-resolved NT names)
        // Value = expected net contracts on the target (signed: + long, − short, 0 flat)
        //
        // "Expected" means the net we believe the target SHOULD have based on orders
        // we have successfully submitted — not the raw NT position (which only updates
        // after fill confirmation).  We advance `expected` on successful PlaceMarketOrder
        // so that a rapid next reconcile does not double-send; on failure we do NOT
        // advance, so the next reconcile will retry the outstanding delta.
        //
        // First-touch / restart seeding: when the key is absent, we READ the target
        // account's actual current NT position and seed from that.  This makes
        // pre-existing positions and agent restarts safe.
        //
        // Thread-safety: ConcurrentDictionary handles concurrent reads/updates.
        // The consumer loop serializes jobs one-at-a-time, but per-target fan-out
        // runs concurrently (Task.WhenAll inside ProcessJobAsync).  Two tasks for
        // the SAME (targetAccount, instrument) could race on the same key.
        // We use a per-key lock (see _netLocks below) to make the
        // read-expected → place-order → update-expected sequence atomic per key.
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, int> _expectedTargetNet =
            new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        // Per-key locks: keyed identically to _expectedTargetNet.
        // Created lazily on first touch.  A simple object per key is sufficient
        // because the critical section is very short (no network/IO inside).
        private readonly ConcurrentDictionary<string, object> _netLocks =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // Tilt tracking: last-known session realized PnL per source account.
        // Updated just before processing each close fill so we can compute the
        // PnL delta and infer win/loss.
        //
        // VERIFY (NT8 API): GetSessionRealizedPnL calls Account.Get(AccountItem.*)
        // internally.  NT8 may update the realized-PnL value asynchronously after
        // the ExecutionUpdate callback fires.  If the adapter always returns the
        // same value before and after a close fill, the delta will be 0 and we
        // cannot determine win/loss from this approach alone.  In that case the
        // TODO below applies: swap in a fill-level P&L signal when NT8 exposes it
        // (e.g. Execution.Profit in a future NT release or via a custom position
        // tracker that maintains average-entry price).
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, double> _lastSourceRealizedPnL =
            new ConcurrentDictionary<string, double>();

        // -----------------------------------------------------------------------
        // Latency instrumentation: per-copy timing, keyed by the unique order token.
        // Populated when a target order is submitted; resolved when the matching
        // follower fill arrives on the target account. Bounded + age-purged so a copy
        // whose follower fill never arrives (e.g. rejected order) cannot leak.
        // -----------------------------------------------------------------------

        internal sealed class CopyTiming
        {
            public string   LeaderExecId;
            public DateTime LeaderExecTime;    // wall-clock leader fill time (FillInfo.Timestamp)
            public long     LeaderCapturedTicks; // t0 monotonic
            public long     DequeuedTicks;      // t1 monotonic
            public long     SubmitStartTicks;   // t2 monotonic
            public long     SubmitEndTicks;     // t2b monotonic
            public string   TargetAccount;
            public string   Instrument;
            public int      Delta;             // signed contracts sent
            public string   RouteLabel;
            public long     RegisteredTicks;   // for age purge
        }

        private readonly ConcurrentDictionary<string, CopyTiming> _pendingTimings =
            new ConcurrentDictionary<string, CopyTiming>(StringComparer.OrdinalIgnoreCase);

        private const int MaxPendingTimings = 4096;

        // Tracks target accounts we've subscribed for follower-fill latency, to avoid double-subscribe.
        private readonly ConcurrentDictionary<string, object> _targetFillSubs =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // RESILIENCE (v1.9.0): follower order-lifecycle subscriptions.
        //
        // Tracks target accounts we've subscribed (via SubscribeOrders with
        // OrderNameFilter.OnlyFinotaurMirrors) to observe the lifecycle of our
        // own mirrored follower orders — specifically late broker rejects and
        // external cancels the leader-side tracking cannot see on its own.
        // Managed exactly like _targetFillSubs immediately above: built in
        // ApplyConfig alongside the latency fill-subscribe loop, unsubscribed
        // via the single IPlatformAdapter.Unsubscribe (handles both fill and
        // order subscription handles transparently), and cleared on every
        // config rebuild + on Dispose.
        // -----------------------------------------------------------------------
        private readonly ConcurrentDictionary<string, object> _targetOrderSubs =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // RESILIENCE (v1.9.0): bounded FIFO dedup set for follower-fill opens
        // counted toward max_trades_per_day. Keyed "{fill.OrderId}|{fill.AccountName}".
        // Structured identically to _everMirroredOrderIds (ConcurrentDictionary +
        // Queue + lock, capped at 100000) so a follower fill is counted at most
        // once even if OnTargetFill somehow observes it more than once.
        // -----------------------------------------------------------------------
        private const int MaxCountedFollowerOpens = 100000;
        private readonly ConcurrentDictionary<string, byte> _countedFollowerOpens =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
        private readonly Queue<string> _countedFollowerOpensEvictionQueue = new Queue<string>();
        private readonly object        _countedFollowerOpensEvictionLock  = new object();

        // -----------------------------------------------------------------------
        // Idempotency set — tracks ExecutionIds we have already processed.
        // Bounded to prevent unbounded growth across long NT sessions.
        // -----------------------------------------------------------------------

        private const int MaxProcessedIds = 100000;
        private readonly ConcurrentDictionary<string, byte> _processedIds =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);

        // Keep an ordered queue of IDs so we can evict the oldest when the cap
        // is reached (FIFO eviction — simple ring-buffer approximation via a Queue
        // protected by a lock).
        private readonly Queue<string> _idEvictionQueue = new Queue<string>();
        private readonly object        _idEvictionLock  = new object();

        // -----------------------------------------------------------------------
        // Locally-cached config (set by ApplyConfig, read by hot path)
        // Volatile so the NT callback always sees the latest reference.
        // -----------------------------------------------------------------------

        private volatile AutomationConfig _cachedConfig;

        // -----------------------------------------------------------------------
        // Constructor
        // -----------------------------------------------------------------------

        /// <summary>
        /// Creates a CopierEngine.
        /// </summary>
        /// <param name="platform">Platform adapter for account queries and order placement.</param>
        /// <param name="risk">Risk enforcer used for pre-trade checks.</param>
        /// <param name="eventQueue">
        /// Shared queue that the agent's background loop drains for telemetry.
        /// The copier enqueues aggregated events here — never posts to the network.
        /// </param>
        /// <param name="logger">Optional logger delegate.</param>
        public CopierEngine(
            IPlatformAdapter              platform,
            RiskEnforcer                  risk,
            ConcurrentQueue<AutomationEvent> eventQueue,
            Action<string>                logger = null)
        {
            _platform   = platform   ?? throw new ArgumentNullException(nameof(platform));
            _risk       = risk       ?? throw new ArgumentNullException(nameof(risk));
            _eventQueue = eventQueue ?? throw new ArgumentNullException(nameof(eventQueue));
            _log        = logger     ?? (m => System.Diagnostics.Debug.WriteLine($"[CopierEngine] {m}"));

            // STEP 5: resolve the copier-state file path using the same NinjaTrader
            // data directory convention as RiskEnforcer's FIX #7 (_statePath).
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            try
            {
                string ntDataDir;
                try
                {
                    ntDataDir = NinjaTrader.Core.Globals.UserDataDir;
                }
                catch
                {
                    ntDataDir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "NinjaTrader 8");
                }
                _copierStatePath = Path.Combine(ntDataDir, "Finotaur", CopierStateFileName);
            }
            catch (Exception ex)
            {
                _log($"CopierEngine: could not resolve copier-state file path ({ex.Message}); " +
                     "mirrored-order fill-skip idempotency will not persist across restarts.");
                _copierStatePath = null;
            }

            // STEP 5: load any previously persisted _everMirroredOrderIds.
            LoadCopierState();

            // Start the background consumer task.
            // It runs on a dedicated thread pool task so order placement is always
            // off the NT event thread.
            _consumerTask = Task.Run(ConsumerLoop, _cts.Token);

            // WORKING-ORDER MIRRORING: start the dedicated order consumer task,
            // alongside the fill consumer above. Same cancellation token.
            _orderConsumerTask = Task.Run(OrderConsumerLoop, _cts.Token);
        }

        // -----------------------------------------------------------------------
        // ApplyConfig — called by FinotaurAgent on every successful config pull
        // -----------------------------------------------------------------------

        /// <summary>
        /// Rebuilds fill subscriptions from the new config.
        ///
        /// CALL THIS only when the config actually changed (i.e. AutomationConfig
        /// .Unchanged == false). For Shape-A "unchanged" responses, apply the
        /// master/kill flags but do NOT call ApplyConfig — subscriptions are
        /// stable and rebuilding them would create duplicate events.
        ///
        /// Thread-safe: can be called from the agent background loop.
        /// </summary>
        public void ApplyConfig(AutomationConfig config)
        {
            if (config == null)
            {
                _log("ApplyConfig called with null config — skipping.");
                return;
            }

            // Store the new config atomically. The hot path (fill callback) reads
            // _cachedConfig; publishing a new reference is atomic on 64-bit CLR.
            _cachedConfig = config;

            // ------------------------------------------------------------------
            // Unsubscribe routes that are no longer active or no longer present
            // ------------------------------------------------------------------

            var incomingRouteIds = new HashSet<string>(
                (config.CopierRoutes ?? new List<CopierRoute>())
                    .Where(r => r.IsActive)
                    .Select(r => r.Id));

            foreach (var existingRouteId in _subscriptions.Keys.ToList())
            {
                if (!incomingRouteIds.Contains(existingRouteId))
                {
                    if (_subscriptions.TryRemove(existingRouteId, out object handle))
                    {
                        _platform.Unsubscribe(handle);
                        _log($"Unsubscribed route '{existingRouteId}' (no longer active).");
                    }
                }
            }

            // WORKING-ORDER MIRRORING: unsubscribe order subscriptions for routes
            // that are no longer active, symmetrically with _subscriptions above.
            foreach (var existingRouteId in _orderSubscriptions.Keys.ToList())
            {
                if (!incomingRouteIds.Contains(existingRouteId))
                {
                    if (_orderSubscriptions.TryRemove(existingRouteId, out object orderHandle))
                    {
                        _platform.Unsubscribe(orderHandle);
                        _log($"Unsubscribed order-mirroring for route '{existingRouteId}' (no longer active).");
                    }
                }
            }

            // FIX #9/#10 (net-position reconciliation): clear the net-position tracker
            // on every config rebuild so that re-activated or reconfigured routes
            // re-seed from the actual NT position on their first fill.  Stale expected
            // values from a previous config epoch could cause a spurious delta order.
            // The tracker is small (one int per active (targetAccount, instrument) pair)
            // so clearing on config change is safe.
            _expectedTargetNet.Clear();
            _netLocks.Clear();
            _log("ApplyConfig: cleared net-position tracker (will re-seed on next fill per target).");

            // WORKING-ORDER MIRRORING: clear mirrored-order tracking + per-order
            // locks on every config rebuild, same rationale as the net-position
            // tracker above. Previously-mirrored orders LOSE modify/cancel
            // tracking across this rebuild — a leader modify/cancel on an order
            // mirrored under the old config epoch will not find a mapping and
            // will be treated as a fresh PLACEMENT candidate (which will no-op
            // since IsActive/route lookups use the new config). This is a known,
            // logged trade-off — deliberately NOT clearing _everMirroredOrderIds,
            // since that set must survive reloads so in-flight fills still skip.
            //
            // STEP 2f: if any tracked orders are about to be dropped, log a WARNING
            // (not just info) including how many were GTC — those are the ones most
            // likely to still be resting on the leader across a config rebuild, so
            // losing their modify/cancel tracking is the highest-impact case.
            // RESCAN (v1.8.0): this drop is no longer permanent — RescanMirroredOrders
            // runs at the end of this method and rebuilds tracking for every leader
            // order that is still genuinely working, by reading BOTH sides' live
            // working orders directly from NT8 (not from the dropped in-memory maps).
            if (_mirroredLeaderOrders.Count > 0)
            {
                int gtcCount = _mirroredLeaderOrders.Values.Count(m =>
                    string.Equals(m.Tif, "gtc", StringComparison.OrdinalIgnoreCase));
                _log($"ApplyConfig WARNING: dropping modify/cancel tracking for " +
                     $"{_mirroredLeaderOrders.Count} mirrored leader order(s) across this config " +
                     $"rebuild ({gtcCount} of which were GTC — most likely to still be live). " +
                     "Rescan follows at the end of ApplyConfig to rebuild tracking from live orders.");
            }

            _mirroredLeaderOrders.Clear();
            _orderLocks.Clear();
            _riskBlockedLeaderOrders.Clear();
            _pendingModifies.Clear();
            _log("ApplyConfig: cleared mirrored-order tracking (previously-mirrored orders " +
                 "lose modify/cancel tracking across this config rebuild; fill-skip idempotency " +
                 "via _everMirroredOrderIds is preserved). Also cleared risk-blocked leader-order " +
                 "tracking — new config may change risk rules, so re-evaluate fresh. Also cleared " +
                 "coalesced pending-modify state (v1.8.0 debounce). Rescan follows.");

            // Latency instrumentation: unsubscribe all previous target-fill subscriptions
            // and clear pending timings before rebuilding.  This mirrors the
            // _expectedTargetNet.Clear() pattern — stale subs from an old config epoch
            // should not persist into the new one.
            foreach (var kv in _targetFillSubs)
            {
                try { _platform.Unsubscribe(kv.Value); }
                catch { /* best-effort */ }
            }
            _targetFillSubs.Clear();
            _pendingTimings.Clear();
            _log("ApplyConfig: cleared target fill-latency subscriptions (will re-subscribe below).");

            // RESILIENCE (v1.9.0): mirror the same clear-and-rebuild cycle for the
            // follower order-lifecycle subscriptions (_targetOrderSubs). Same
            // rationale as _targetFillSubs immediately above — stale subs from an
            // old config epoch must not persist into the new one.
            foreach (var kv in _targetOrderSubs)
            {
                try { _platform.Unsubscribe(kv.Value); }
                catch { /* best-effort */ }
            }
            _targetOrderSubs.Clear();
            _log("ApplyConfig: cleared target order-lifecycle subscriptions (will re-subscribe below).");

            // ------------------------------------------------------------------
            // Subscribe new or re-activated routes
            // ------------------------------------------------------------------

            foreach (var route in config.CopierRoutes ?? new List<CopierRoute>())
            {
                if (!route.IsActive)
                {
                    // Ensure any stale subscription is removed
                    if (_subscriptions.TryRemove(route.Id, out object staleHandle))
                    {
                        _platform.Unsubscribe(staleHandle);
                        _log($"Removed subscription for inactive route '{route.Id}'.");
                    }
                    // WORKING-ORDER MIRRORING: ensure any stale order subscription is
                    // removed too, symmetrically.
                    if (_orderSubscriptions.TryRemove(route.Id, out object staleOrderHandle))
                    {
                        _platform.Unsubscribe(staleOrderHandle);
                        _log($"Removed order-mirroring subscription for inactive route '{route.Id}'.");
                    }
                    continue;
                }

                // Already subscribed for this route — no change needed
                if (_subscriptions.ContainsKey(route.Id)) continue;

                // ------------------------------------------------------------------
                // Resolve source account → local NT account name.
                //
                // Resolution order:
                //   1. route.SourceAccountName  → ResolveAccountByName()  (primary)
                //   2. route.SourceConnectionId → FindConnection() +
                //                                 ResolveAccountName()     (fallback)
                //
                // The primary path is the new account-name-based approach.  The
                // fallback supports older server responses that pre-date the
                // accounts array.  Either way: if we cannot resolve to a local NT
                // account, SKIP this route with a diagnostic log — fail-safe.
                // ------------------------------------------------------------------
                string sourceAccount = null;

                if (!string.IsNullOrWhiteSpace(route.SourceAccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    sourceAccount = _platform.ResolveAccountByName(route.SourceAccountName);
                    if (sourceAccount == null)
                    {
                        // Post a status event so the web can surface the gap.
                        _eventQueue.Enqueue(new AutomationEvent
                        {
                            EventType = "agent_status",
                            Severity  = "warning",
                            Payload   = new
                            {
                                message         = $"Copier route '{route.Label}' skipped: " +
                                                  $"source account '{route.SourceAccountName}' " +
                                                  "is not connected in this NT8 instance. " +
                                                  "Open NinjaTrader → Accounts and connect the account.",
                                route_id        = route.Id,
                                source_account  = route.SourceAccountName,
                                source_broker   = route.SourceBroker,
                                source_env      = route.SourceEnvironment
                            }
                        });
                        _log($"ApplyConfig: route '{route.Label}' — source account " +
                             $"'{route.SourceAccountName}' not found locally — SKIPPING. " +
                             "Verify the account is connected in NT8.");
                        continue;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(route.SourceConnectionId))
                {
                    // Fallback: older server response without account_name field.
                    BrokerConnection sourceConn = FindConnection(config, route.SourceConnectionId);
                    if (sourceConn == null)
                    {
                        _log($"ApplyConfig: route '{route.Label}' source connection " +
                             $"'{route.SourceConnectionId}' not found in config — SKIPPING.");
                        continue;
                    }
                    sourceAccount = _platform.ResolveAccountName(sourceConn);
                    if (sourceAccount == null)
                    {
                        _log($"ApplyConfig: route '{route.Label}' — no local NT account for " +
                             $"connection '{route.SourceConnectionId}' (fallback path) — SKIPPING. " +
                             "Ensure the Tradovate account is connected in NT8.");
                        continue;
                    }
                    _log($"ApplyConfig: route '{route.Label}' resolved source via legacy " +
                         $"connection-id fallback → '{sourceAccount}'.");
                }
                else
                {
                    _log($"ApplyConfig: route '{route.Label}' has neither SourceAccountName " +
                         "nor SourceConnectionId — SKIPPING (malformed route).");
                    continue;
                }

                // ------------------------------------------------------------------
                // HOT-PATH FILL CALLBACK
                // Keep this extremely lean: validate + enqueue + return.
                // NO network calls, NO expensive computation here.
                // The NT event thread must not be held.
                // ------------------------------------------------------------------

                // Capture the route ID for the closure to avoid
                // closure-over-loop-variable bugs. The closure reads the full
                // route object from _cachedConfig at fill time (see liveRoute
                // lookup below) rather than capturing the object at subscribe time.
                string capturedRouteId = route.Id;

                object subHandle = _platform.SubscribeFills(sourceAccount, fill =>
                {
                    // -------- HOT PATH START --------
                    // This runs on the NT ExecutionUpdate thread.
                    // Do NOT block, do NOT allocate excessively, do NOT network-call.

                    try
                    {
                        // Load the locally-cached config (atomic volatile read).
                        AutomationConfig cfg = _cachedConfig;
                        if (cfg == null) return;

                        // Hard stop: master disabled or kill engaged.
                        // Always checked first, every fill.
                        if (!cfg.MasterEnabled || cfg.KillSwitchEngaged) return;

                        // EXIT-SYNC (v1.8.0): if this fill's originating order was already
                        // mirrored as a working order (see ProcessOrderJob PLACEMENT below),
                        // the follower's own working order would normally fill independently
                        // — but relying on that alone leaves a window where the follower's
                        // twin order is still resting (stale price, or a sibling OCO leg not
                        // yet cancelled) and can double-fill or drift from the leader's exit.
                        // Instead of skipping, fall through to the normal enqueue and mark the
                        // job for exit-sync reconcile — ProcessJobAsync's pre-step forcibly
                        // cancels the twin (and any OCO siblings) before the net-reconcile math
                        // runs, guaranteeing the follower converges to the leader's true exit.
                        bool isExitSync = fill.OrderId != null && WasLeaderOrderMirrored(fill.OrderId);
                        if (isExitSync)
                        {
                            _log($"Fill '{fill.ExecutionId}' came from mirrored working order '{fill.OrderId}' — routing through exit-sync reconcile.");
                        }

                        // Use the CURRENT route config from the latest cached config (looked up by
                        // Id) — NOT the route object captured at subscribe time. This makes web-UI
                        // edits to an active route (scale_ratio, targets, copy flags, reverse,
                        // cross_to_micro, symbol_filter) take effect on the very next fill, without
                        // requiring a re-subscribe or agent restart.
                        CopierRoute liveRoute = null;
                        var routesNow = cfg.CopierRoutes;
                        if (routesNow != null)
                        {
                            for (int i = 0; i < routesNow.Count; i++)
                            {
                                var rNow = routesNow[i];
                                if (rNow != null && rNow.IsActive
                                    && string.Equals(rNow.Id, capturedRouteId, StringComparison.OrdinalIgnoreCase))
                                {
                                    liveRoute = rNow;
                                    break;
                                }
                            }
                        }
                        if (liveRoute == null) return; // route deactivated/removed since subscribe — nothing to copy

                        // Idempotency: skip fills we have already processed.
                        if (!TryMarkProcessed(fill.ExecutionId)) return;

                        // Symbol filter (empty = copy all)
                        if (liveRoute.SymbolFilter != null
                            && liveRoute.SymbolFilter.Count > 0)
                        {
                            bool symbolMatch = liveRoute.SymbolFilter.Any(s =>
                                string.Equals(s, fill.InstrumentName,
                                    StringComparison.OrdinalIgnoreCase));
                            if (!symbolMatch) return;
                        }

                        // FIX #9/#10 (net-position reconciliation):
                        // The copy_opens / copy_closes gate is NO LONGER applied here
                        // on the hot path using the fill's IsOpening flag.  That
                        // approach was fragile (#10 timing bug) and prevented
                        // correct net reconciliation.  The gate is now derived from
                        // actual net position magnitude change inside
                        // PlaceTargetOrderAsync — see "CopyOpens / CopyCloses gating"
                        // comment block there.  IsOpening is still populated on the
                        // fill (for tilt tracking and telemetry) but MUST NOT be used
                        // to decide whether to enqueue the copy job.

                        // Enqueue the copy job for the background consumer.
                        // If the queue is full (bounded at WorkerQueueCapacity), TryAdd returns
                        // false and we drop this fill — better to drop than to block the NT thread.
                        bool enqueued = _workerQueue.TryAdd(new CopyJob
                        {
                            SourceFill             = fill,
                            Route                  = liveRoute,
                            Config                 = cfg,          // snapshot of config at enqueue time
                            IsExitSync             = isExitSync,
                            ExitSyncLeaderOrderId  = isExitSync ? fill.OrderId : null
                        });

                        if (!enqueued)
                        {
                            // Queue is full — log and drop. This should be rare.
                            _log($"HOT PATH: worker queue full — dropping fill " +
                                 $"'{fill.ExecutionId}' on '{fill.InstrumentName}'. " +
                                 "This indicates the consumer is falling behind; " +
                                 "investigate if this happens frequently.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Fill callbacks must NEVER throw — NT may crash the connection.
                        _log($"HOT PATH exception for fill '{fill?.ExecutionId}': " +
                             $"{ex.GetType().Name} — {ex.Message}");
                    }
                    // -------- HOT PATH END --------
                });

                if (subHandle != null)
                {
                    _subscriptions[route.Id] = subHandle;
                    _log($"Subscribed route '{route.Label}' → source account '{sourceAccount}'.");
                }
                else
                {
                    _log($"Failed to subscribe route '{route.Label}' — " +
                         $"SubscribeFills returned null for '{sourceAccount}'.");
                }

                // ------------------------------------------------------------------
                // WORKING-ORDER MIRRORING — HOT-PATH ORDER CALLBACK
                // Runs on the NT OrderUpdate thread. Keep lean: validate + enqueue +
                // return, exactly like the fill hot path above. NO network calls,
                // NO expensive computation here.
                // ------------------------------------------------------------------

                object orderSubHandle = _platform.SubscribeOrders(sourceAccount, order =>
                {
                    // -------- ORDER HOT PATH START --------
                    try
                    {
                        AutomationConfig cfg = _cachedConfig;
                        if (cfg == null) return;

                        // Hard stop: master disabled or kill engaged.
                        if (!cfg.MasterEnabled || cfg.KillSwitchEngaged) return;

                        // Look up the CURRENT route config, same pattern as the fill
                        // hot path — web-UI edits to an active route take effect on
                        // the very next order event without re-subscribe/restart.
                        CopierRoute liveRoute = null;
                        var routesNow = cfg.CopierRoutes;
                        if (routesNow != null)
                        {
                            for (int i = 0; i < routesNow.Count; i++)
                            {
                                var rNow = routesNow[i];
                                if (rNow != null && rNow.IsActive
                                    && string.Equals(rNow.Id, capturedRouteId, StringComparison.OrdinalIgnoreCase))
                                {
                                    liveRoute = rNow;
                                    break;
                                }
                            }
                        }
                        if (liveRoute == null) return; // route deactivated/removed since subscribe

                        // Only mirror WORKING orders (limit/stop/stoplimit/mit). Market
                        // orders are handled exclusively by the fill-copy path above.
                        string ot = order.OrderType;
                        if (ot != "limit" && ot != "stop" && ot != "stoplimit" && ot != "mit") return;

                        // Symbol filter (empty = copy all) — same as fill path.
                        if (liveRoute.SymbolFilter != null
                            && liveRoute.SymbolFilter.Count > 0)
                        {
                            bool symbolMatch = liveRoute.SymbolFilter.Any(s =>
                                string.Equals(s, order.InstrumentName,
                                    StringComparison.OrdinalIgnoreCase));
                            if (!symbolMatch) return;
                        }

                        // Skip our own mirrored (follower) orders — they carry the
                        // "FinotaurCopier|ord|" name prefix and would otherwise be
                        // picked up again on the target account's own subscription.
                        if (!string.IsNullOrEmpty(order.OrderName)
                            && order.OrderName.StartsWith("Finotaur", StringComparison.Ordinal))
                        {
                            return;
                        }

                        bool enqueued = _orderQueue.TryAdd(new OrderCopyJob
                        {
                            SourceOrder = order,
                            Route       = liveRoute,
                            Config      = cfg
                        });

                        if (!enqueued)
                        {
                            _log($"ORDER HOT PATH: order queue full — dropping order " +
                                 $"'{order.OrderId}' on '{order.InstrumentName}'. " +
                                 "This indicates the order consumer is falling behind; " +
                                 "investigate if this happens frequently.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Order callbacks must NEVER throw — NT may crash the connection.
                        _log($"ORDER HOT PATH exception for order '{order?.OrderId}': " +
                             $"{ex.GetType().Name} — {ex.Message}");
                    }
                    // -------- ORDER HOT PATH END --------
                });

                if (orderSubHandle != null)
                {
                    _orderSubscriptions[route.Id] = orderSubHandle;
                    _log($"Subscribed order-mirroring for route '{route.Label}' → source account '{sourceAccount}'.");
                }
                else
                {
                    _log($"Failed to subscribe order-mirroring for route '{route.Label}' — " +
                         $"SubscribeOrders returned null for '{sourceAccount}'.");
                }

                // ------------------------------------------------------------------
                // Latency instrumentation: subscribe each active target account for
                // follower-fill latency (OnTargetFill = t3).  Uses the SAME resolution
                // logic as PlaceTargetOrderCore STEP 1 to find the NT account name.
                // Only subscribes once per target account (tracked in _targetFillSubs).
                // Fail-safe: any exception here is swallowed — this is additive only.
                // ------------------------------------------------------------------
                foreach (var target in route.Targets ?? new List<CopierTarget>())
                {
                    if (!target.IsActive) continue;

                    try
                    {
                        // Resolve target account name using the same STEP 1 logic.
                        string targetAcct = null;
                        if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
                        {
                            targetAcct = _platform.ResolveAccountByName(target.DestinationAccountName);
                        }
                        else if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
                        {
                            BrokerConnection destConn = FindConnection(config, target.DestinationConnectionId);
                            if (destConn != null)
                                targetAcct = _platform.ResolveAccountName(destConn);
                        }

                        if (targetAcct == null) continue;

                        // Subscribe once per resolved target account name.
                        if (!_targetFillSubs.ContainsKey(targetAcct))
                        {
                            object latencyHandle = _platform.SubscribeFills(targetAcct, OnTargetFill);
                            if (latencyHandle != null)
                            {
                                _targetFillSubs[targetAcct] = latencyHandle;
                                _log($"Latency: subscribed target account '{targetAcct}' for follower-fill timing.");
                            }
                        }

                        // RESILIENCE (v1.9.0): subscribe the target account for its OWN
                        // order lifecycle, filtered to ONLY our mirrored follower orders
                        // ("FinotaurCopier|ord|*"). Independent once-per-account guard
                        // from the fill-latency subscribe above — a target shared by
                        // multiple routes must still get exactly one order subscription.
                        if (!_targetOrderSubs.ContainsKey(targetAcct))
                        {
                            object followerOrderHandle = _platform.SubscribeOrders(
                                targetAcct, OnFollowerOrderEvent, OrderNameFilter.OnlyFinotaurMirrors);
                            if (followerOrderHandle != null)
                            {
                                _targetOrderSubs[targetAcct] = followerOrderHandle;
                                _log($"Resilience: subscribed target account '{targetAcct}' for follower order-lifecycle events.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _log($"Latency/Resilience: target subscribe error (non-fatal): {ex.Message}");
                    }
                }
            }

            // RESCAN (v1.8.0): rebuild _mirroredLeaderOrders / _mirroredTarget tracking
            // from the LIVE NT8 order books, healing the drop performed above. Must run
            // after subscriptions are (re)built. Never allowed to throw out of ApplyConfig.
            try
            {
                RescanMirroredOrders(config);
            }
            catch (Exception ex)
            {
                _log($"ApplyConfig: RescanMirroredOrders error (non-fatal): {ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // RESCAN (v1.8.0) — rebuild mirrored-order tracking after every ApplyConfig
        // -----------------------------------------------------------------------

        /// <summary>
        /// Prefix used on every follower working order's Name by ProcessOrderPlacement
        /// (see "FinotaurCopier|ord|{leaderOrderId}|{targetAccount}"). Used here to
        /// identify our own follower orders when re-scanning target accounts.
        /// </summary>
        private const string FollowerOrderNamePrefix = "FinotaurCopier|ord|";

        /// <summary>
        /// RESCAN (v1.8.0): rebuilds _mirroredLeaderOrders (and its MirroredTarget
        /// entries) by cross-referencing the LIVE leader and follower working-order
        /// books directly from NT8 — fixing the live-confirmed bug where every
        /// config refresh (ApplyConfig) orphans all previously-mirrored brackets by
        /// clearing the in-memory tracking with no way back.
        ///
        /// Called at the end of ApplyConfig, after the clears above and after
        /// subscriptions are rebuilt. Must never throw — the caller wraps this in
        /// try/catch as a belt-and-suspenders measure, but every internal step is
        /// also individually fail-safe (skip-and-log, never abort the whole scan).
        ///
        /// Algorithm (per active route → per active target):
        ///   1. Read the leader's live + terminal working orders (source account).
        ///   2. Read the target's live working orders (follower account), and for
        ///      each one whose Name matches our "FinotaurCopier|ord|<leaderId>|<acct>"
        ///      convention, reconcile against the leader order's current state:
        ///        - leader still working  → rebuild the MirroredOrder/MirroredTarget
        ///          mapping (seeded from the LEADER's current values) + a one-shot
        ///          offline price resync (never touches quantity).
        ///        - leader cancelled/rejected → cancel the orphaned follower order.
        ///        - leader filled → leave the follower alone (certified semantics —
        ///          it may still be resting as a bracket leg) and mark it mirrored
        ///          so a later follower fill routes through exit-sync.
        ///        - leader not found at all → fail-safe: do NOT cancel (ambiguous —
        ///          could be filled-and-purged or cancelled-and-purged); flag for
        ///          manual review instead.
        /// </summary>
        private void RescanMirroredOrders(AutomationConfig cfg)
        {
            if (cfg == null) return;

            int rebuilt      = 0;
            int rebuiltTargets = 0;
            int resyncs      = 0;
            int orphanCancels = 0;
            int ambiguous    = 0;

            foreach (var route in cfg.CopierRoutes ?? new List<CopierRoute>())
            {
                if (!route.IsActive) continue;

                // Resolve source account — same resolution order ApplyConfig uses.
                string sourceAccount = null;
                if (!string.IsNullOrWhiteSpace(route.SourceAccountName))
                {
                    sourceAccount = _platform.ResolveAccountByName(route.SourceAccountName);
                }
                else if (!string.IsNullOrWhiteSpace(route.SourceConnectionId))
                {
                    BrokerConnection sourceConn = FindConnection(cfg, route.SourceConnectionId);
                    if (sourceConn != null)
                        sourceAccount = _platform.ResolveAccountName(sourceConn);
                }

                if (sourceAccount == null)
                {
                    // Unresolvable — ApplyConfig's main loop already logged this route
                    // as skipped; nothing to rescan.
                    continue;
                }

                AgentWorkingOrder[] leaderLiveArr;
                AgentWorkingOrder[] leaderAllArr;
                try
                {
                    leaderLiveArr = _platform.GetWorkingOrders(sourceAccount, includeTerminal: false) ?? new AgentWorkingOrder[0];
                    leaderAllArr  = _platform.GetWorkingOrders(sourceAccount, includeTerminal: true)  ?? new AgentWorkingOrder[0];
                }
                catch (Exception ex)
                {
                    _log($"Rescan: GetWorkingOrders failed for source '{sourceAccount}' (non-fatal): {ex.Message}");
                    continue;
                }

                var leaderLive = new Dictionary<string, AgentWorkingOrder>(StringComparer.OrdinalIgnoreCase);
                foreach (var lo in leaderLiveArr)
                {
                    if (lo?.OrderId != null) leaderLive[lo.OrderId] = lo;
                }

                var leaderTerminal = new Dictionary<string, AgentWorkingOrder>(StringComparer.OrdinalIgnoreCase);
                foreach (var lo in leaderAllArr)
                {
                    if (lo?.OrderId == null) continue;
                    if (leaderLive.ContainsKey(lo.OrderId)) continue; // still live — not terminal
                    leaderTerminal[lo.OrderId] = lo;
                }

                foreach (var target in route.Targets ?? new List<CopierTarget>())
                {
                    if (!target.IsActive) continue;

                    string targetAccount = ResolveTargetAccountForOrder(target, cfg, out _);
                    if (targetAccount == null)
                    {
                        // ApplyConfig's target-fill-latency loop already logs unresolved
                        // targets; nothing to rescan here.
                        continue;
                    }

                    AgentWorkingOrder[] followerOrders;
                    try
                    {
                        followerOrders = _platform.GetWorkingOrders(targetAccount, includeTerminal: false) ?? new AgentWorkingOrder[0];
                    }
                    catch (Exception ex)
                    {
                        _log($"Rescan: GetWorkingOrders failed for target '{targetAccount}' (non-fatal): {ex.Message}");
                        continue;
                    }

                    foreach (var follower in followerOrders)
                    {
                        try
                        {
                            if (follower == null || string.IsNullOrEmpty(follower.Name)) continue;
                            if (!follower.Name.StartsWith(FollowerOrderNamePrefix, StringComparison.Ordinal)) continue;

                            // "FinotaurCopier|ord|<leaderOrderId>|<targetAccount>"
                            string[] parts = follower.Name.Split('|');
                            if (parts.Length != 4) continue; // malformed / not our convention — skip
                            string nameLeaderOrderId = parts[2];
                            string nameTargetAccount = parts[3];

                            if (!string.Equals(nameTargetAccount, targetAccount, StringComparison.OrdinalIgnoreCase))
                                continue; // belongs to a different target account's follower order

                            if (leaderLive.TryGetValue(nameLeaderOrderId, out AgentWorkingOrder leader))
                            {
                                // Leader order is still genuinely working — rebuild tracking.
                                object orderLock = _orderLocks.GetOrAdd(nameLeaderOrderId, _ => new object());
                                lock (orderLock)
                                {
                                    MirroredOrder m = _mirroredLeaderOrders.GetOrAdd(nameLeaderOrderId, _ =>
                                    {
                                        rebuilt++;
                                        return new MirroredOrder
                                        {
                                            RouteId       = route.Id,
                                            LeaderOrderId = nameLeaderOrderId,
                                            LastLimit     = leader.LimitPrice,
                                            LastStop      = leader.StopPrice,
                                            LastQty       = leader.Quantity,
                                            Tif           = leader.Tif,
                                            // TODO (v2, compile-safe follow-up): AgentWorkingOrder does
                                            // not currently expose the leader's OCO group id, so OCO
                                            // recovery is not possible from a rescan alone — leave empty.
                                            // Add an `Oco` field to AgentWorkingOrder (NinjaTraderAdapter
                                            // GetWorkingOrders already has Order.Oco available) to close
                                            // this gap in a future version.
                                            LeaderOco     = string.Empty,
                                        };
                                    });

                                    bool alreadyTracked = m.Targets.Any(mt =>
                                        string.Equals(mt.FollowerOrderId, follower.OrderId, StringComparison.OrdinalIgnoreCase));

                                    if (!alreadyTracked)
                                    {
                                        m.Targets.Add(new MirroredTarget
                                        {
                                            TargetAccount   = targetAccount,
                                            FollowerOrderId = follower.OrderId,
                                            Instrument      = follower.InstrumentName,
                                            // TODO (v2, compile-safe follow-up): same OCO-recovery gap as
                                            // above — AgentWorkingOrder has no Oco field yet.
                                            FollowerOco     = string.Empty,
                                            ScaleRatio      = target.ScaleRatio,
                                            MaxContracts    = target.MaxContracts,
                                        });
                                        rebuiltTargets++;
                                    }

                                    MarkLeaderOrderMirrored(nameLeaderOrderId);

                                    // One-shot offline price resync — PRICES ONLY, never quantity.
                                    // Heals any leader price change (e.g. a trailing stop) that
                                    // happened while the agent was offline/reloading and therefore
                                    // never reached the follower via the normal modify path.
                                    bool limitDiffers = leader.LimitPrice > 0 && follower.LimitPrice != leader.LimitPrice;
                                    bool stopDiffers  = leader.StopPrice  > 0 && follower.StopPrice  != leader.StopPrice;
                                    if (limitDiffers || stopDiffers)
                                    {
                                        // ModifyWorkingOrder treats a <=0 argument as "leave unchanged"
                                        // (verified in NinjaTraderAdapter.ModifyWorkingOrder: newQuantity
                                        // > 0 ? newQuantity : order.Quantity, same pattern for price
                                        // fields) — passing -1 for quantity here is therefore safe and
                                        // leaves the follower's resting quantity untouched.
                                        bool ok = _platform.ModifyWorkingOrder(
                                            targetAccount, follower.OrderId, -1, leader.LimitPrice, leader.StopPrice);
                                        _log($"Rescan: offline price resync ({targetAccount}, follower " +
                                             $"'{follower.OrderId}', leader '{nameLeaderOrderId}'): " +
                                             $"limit {follower.LimitPrice}→{leader.LimitPrice}, " +
                                             $"stop {follower.StopPrice}→{leader.StopPrice} → {(ok ? "OK" : "FAILED")}.");
                                        if (ok)
                                        {
                                            m.LastLimit = leader.LimitPrice;
                                            m.LastStop  = leader.StopPrice;
                                            resyncs++;
                                        }
                                    }
                                }
                            }
                            else if (leaderTerminal.TryGetValue(nameLeaderOrderId, out AgentWorkingOrder terminalLeader)
                                     && (string.Equals(terminalLeader.State, "cancelled", StringComparison.OrdinalIgnoreCase)
                                         || string.Equals(terminalLeader.State, "rejected", StringComparison.OrdinalIgnoreCase)))
                            {
                                // Leader is confirmed cancelled/rejected — this follower is orphaned.
                                bool ok = _platform.CancelWorkingOrder(targetAccount, follower.OrderId);
                                orphanCancels++;
                                _log($"Rescan: leader order '{nameLeaderOrderId}' is '{terminalLeader.State}' — " +
                                     $"cancelling orphaned follower '{follower.OrderId}' on '{targetAccount}' → {(ok ? "OK" : "FAILED")}.");

                                _eventQueue.Enqueue(new AutomationEvent
                                {
                                    EventType = "order_copy_cancelled",
                                    Severity  = "warning",
                                    Payload   = new
                                    {
                                        order_id     = nameLeaderOrderId,
                                        leader_state = terminalLeader.State,
                                        route_id     = route.Id,
                                        reason       = "leader cancelled while agent offline",
                                        per_target   = new[]
                                        {
                                            new { account = targetAccount, order_id = follower.OrderId, ok }
                                        }
                                    }
                                });
                            }
                            else if (leaderTerminal.TryGetValue(nameLeaderOrderId, out AgentWorkingOrder filledLeader)
                                     && string.Equals(filledLeader.State, "filled", StringComparison.OrdinalIgnoreCase))
                            {
                                // Certified semantics: leader filled — leave the follower order in
                                // place (it may be a bracket leg still meant to be live) and ensure
                                // its eventual fill routes through exit-sync rather than a plain
                                // fill-copy.
                                MarkLeaderOrderMirrored(nameLeaderOrderId);
                            }
                            else
                            {
                                // Leader order not found at all (neither live nor terminal) — this
                                // is genuinely ambiguous: it could have filled-and-been-purged from
                                // NT8's order history, or cancelled-and-been-purged. Fail-safe: do
                                // NOT cancel a follower order we cannot confirm is orphaned.
                                ambiguous++;
                                _log($"Rescan: leader order '{nameLeaderOrderId}' not found (neither live " +
                                     $"nor terminal) for follower '{follower.OrderId}' on '{targetAccount}' — " +
                                     "orphaned follower mirror, review manually. NOT cancelling (fail-safe).");

                                _eventQueue.Enqueue(new AutomationEvent
                                {
                                    EventType = "order_copy_failed",
                                    Severity  = "warning",
                                    Payload   = new
                                    {
                                        order_id   = nameLeaderOrderId,
                                        route_id   = route.Id,
                                        reason     = "orphaned follower mirror — leader order not found (filled-or-cancelled ambiguity), review manually",
                                        per_target = new[]
                                        {
                                            new { account = targetAccount, order_id = follower.OrderId, ok = false }
                                        }
                                    }
                                });
                            }
                        }
                        catch (Exception ex)
                        {
                            _log($"Rescan: exception processing follower order on '{targetAccount}' " +
                                 $"(non-fatal, continuing scan): {ex.GetType().Name} — {ex.Message}");
                        }
                    }
                }
            }

            _log($"Rescan: rebuilt {rebuilt} mirrored orders ({rebuiltTargets} targets), " +
                 $"{resyncs} resyncs, {orphanCancels} orphan-cancels, {ambiguous} ambiguous.");
        }

        // -----------------------------------------------------------------------
        // ConsumerLoop — runs on a dedicated Task (NOT the NT thread)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Background consumer: dequeues CopyJob objects and fans out orders
        /// to all target accounts concurrently.
        ///
        /// Runs until the CancellationToken is signalled (on Dispose).
        /// All exceptions are caught; the loop never exits on its own.
        /// </summary>
        private void ConsumerLoop()
        {
            _log("CopierEngine consumer loop started.");

            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    // Blocking take — waits for a job, respecting cancellation.
                    CopyJob job = _workerQueue.Take(_cts.Token);
                    ProcessJobAsync(job).GetAwaiter().GetResult();
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown path
                    break;
                }
                catch (Exception ex)
                {
                    // Should not happen; log and continue the loop.
                    _log($"ConsumerLoop unexpected error: {ex.GetType().Name} — {ex.Message}");
                }
            }

            _log("CopierEngine consumer loop stopped.");
        }

        // -----------------------------------------------------------------------
        // ProcessJobAsync — called by consumer, runs off-NT-thread
        // -----------------------------------------------------------------------

        /// <summary>
        /// Processes one CopyJob: resolves target accounts, checks risk rules,
        /// places orders concurrently to all targets, and enqueues ONE aggregated
        /// telemetry event.
        /// </summary>
        private async Task ProcessJobAsync(CopyJob job)
        {
            // Latency instrumentation: t1 — moment this job was dequeued by the consumer.
            long dequeuedTicks = Stopwatch.GetTimestamp();

            FillInfo       fill   = job.SourceFill;
            CopierRoute    route  = job.Route;
            AutomationConfig cfg  = job.Config;

            _log($"Processing copy job: fill '{fill.ExecutionId}' " +
                 $"{(fill.IsBuy ? "BUY" : "SELL")} {fill.Quantity} {fill.InstrumentName} " +
                 $"on '{fill.AccountName}' via route '{route.Label}'.");

            // ------------------------------------------------------------------
            // EXIT-SYNC (v1.8.0) PRE-STEP: when this job's fill came from a leader
            // order we had mirrored as a follower working order, force the twin
            // follower order(s) (and any OCO siblings) to be cancelled BEFORE the
            // net-reconcile fan-out below runs. This guarantees the follower never
            // double-fills off its own resting twin and always converges to the
            // leader's actual exit via the reconcile math (which then re-seeds from
            // the freshly-read NT position — see PlaceTargetOrderCore forceReseed).
            // ------------------------------------------------------------------
            MirroredOrder exitMapping = null;
            if (job.IsExitSync && !string.IsNullOrWhiteSpace(job.ExitSyncLeaderOrderId))
            {
                string exitLeaderId = job.ExitSyncLeaderOrderId;
                object exitLock = _orderLocks.GetOrAdd(exitLeaderId, _ => new object());

                lock (exitLock)
                {
                    if (_mirroredLeaderOrders.TryRemove(exitLeaderId, out exitMapping))
                    {
                        _pendingModifies.TryRemove(exitLeaderId, out _);

                        foreach (var mt in exitMapping.Targets)
                        {
                            try
                            {
                                bool ok = _platform.CancelWorkingOrder(mt.TargetAccount, mt.FollowerOrderId);
                                _log($"ExitSync: cancelled twin follower '{mt.FollowerOrderId}' " +
                                     $"on '{mt.TargetAccount}' for leader order '{exitLeaderId}' → {(ok ? "OK" : "FAILED")}.");
                            }
                            catch (Exception ex)
                            {
                                _log($"ExitSync: twin cancel exception ({mt.TargetAccount}, " +
                                     $"'{mt.FollowerOrderId}'): {ex.Message}");
                            }
                        }

                        // Proactive OCO-sibling cancel: if the leader order that just filled
                        // was part of an OCO group (e.g. a bracket's stop/target pair), the
                        // sibling leg's follower order(s) must also be cancelled now — NT8
                        // will cancel the sibling on the LEADER side automatically, but the
                        // follower's own OCO wiring is a separate broker-side group and may
                        // not resolve before this reconcile runs.
                        if (!string.IsNullOrEmpty(exitMapping.LeaderOco))
                        {
                            foreach (var siblingId in _mirroredLeaderOrders.Keys.ToList())
                            {
                                if (string.Equals(siblingId, exitLeaderId, StringComparison.OrdinalIgnoreCase))
                                    continue;

                                object siblingLock = _orderLocks.GetOrAdd(siblingId, _ => new object());
                                lock (siblingLock)
                                {
                                    if (_mirroredLeaderOrders.TryGetValue(siblingId, out MirroredOrder siblingMapping)
                                        && string.Equals(siblingMapping.LeaderOco, exitMapping.LeaderOco, StringComparison.OrdinalIgnoreCase))
                                    {
                                        _mirroredLeaderOrders.TryRemove(siblingId, out _);
                                        _pendingModifies.TryRemove(siblingId, out _);

                                        foreach (var mt in siblingMapping.Targets)
                                        {
                                            try
                                            {
                                                bool ok = _platform.CancelWorkingOrder(mt.TargetAccount, mt.FollowerOrderId);
                                                _log($"ExitSync: cancelled OCO-sibling follower '{mt.FollowerOrderId}' " +
                                                     $"on '{mt.TargetAccount}' (sibling leader '{siblingId}', OCO " +
                                                     $"'{exitMapping.LeaderOco}') → {(ok ? "OK" : "FAILED")}.");
                                            }
                                            catch (Exception ex)
                                            {
                                                _log($"ExitSync: OCO-sibling cancel exception ({mt.TargetAccount}, " +
                                                     $"'{mt.FollowerOrderId}'): {ex.Message}");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        _log($"ExitSync: leader order '{exitLeaderId}' fired an exit-sync fill but no " +
                             "mapping was found (already removed/never mapped) — proceeding with plain reconcile.");
                    }
                }
            }

            // ------------------------------------------------------------------
            // Tilt pre-snapshot: for CLOSE fills, record the source account's
            // realized PnL BEFORE the fan-out so we can compute the delta after.
            //
            // VERIFY (NT8 API): GetSessionRealizedPnL must return the up-to-date
            // value at the time this line executes — i.e. AFTER the ExecutionUpdate
            // callback has caused NT8 to close the position and book the P&L.
            // The consumer runs off the NT thread (via Task.Run), so there may be
            // a brief race window where NT8 has not yet updated its internal account
            // state.  If the delta is consistently 0 for close fills, NT8's P&L
            // update is asynchronous with respect to the fill callback and this
            // snapshot approach will NOT work — see the TODO note below.
            // ------------------------------------------------------------------
            double preFillRealizedPnL = 0.0;
            if (!fill.IsOpening)
            {
                preFillRealizedPnL = _lastSourceRealizedPnL.GetOrAdd(
                    fill.AccountName,
                    _ => _platform.GetSessionRealizedPnL(fill.AccountName));
            }

            // Build per-target tasks
            var targetResults = new ConcurrentBag<TargetResult>();

            // Fan-out: prepare a Task for each active target
            var targetTasks = new List<Task>();

            foreach (var target in route.Targets ?? new List<CopierTarget>())
            {
                if (!target.IsActive) continue;

                // Capture for closure
                var capturedTarget = target;

                // Capture dequeuedTicks for the closure (same value for all targets in this job).
                long capturedDequeuedTicks = dequeuedTicks;

                // EXIT-SYNC (v1.8.0): match this target's resolved account against the
                // removed mapping's MirroredTarget list (if any) so PlaceTargetOrderCore
                // can await-terminal the twin follower order and force a fresh reseed.
                // Resolution uses the SAME account-name lookup as ResolveTargetAccountForOrder
                // so the match is consistent with how the twin's TargetAccount was recorded.
                MirroredTarget capturedExitTwin = null;
                if (exitMapping != null)
                {
                    string resolvedTargetAccount = ResolveTargetAccountForOrder(capturedTarget, cfg, out _);
                    if (resolvedTargetAccount != null)
                    {
                        capturedExitTwin = exitMapping.Targets.Find(mt =>
                            string.Equals(mt.TargetAccount, resolvedTargetAccount, StringComparison.OrdinalIgnoreCase));
                    }
                }
                bool capturedForceReseed = exitMapping != null;

                targetTasks.Add(Task.Run(async () =>
                {
                    var result = await PlaceTargetOrderAsync(
                        fill, route, capturedTarget, cfg, capturedDequeuedTicks, _cts.Token,
                        capturedExitTwin, capturedForceReseed)
                        .ConfigureAwait(false);
                    targetResults.Add(result);
                }));
            }

            if (targetTasks.Count == 0)
            {
                _log($"Route '{route.Label}': no active targets — nothing to copy.");
                return;
            }

            // Await ALL target placements concurrently.
            // Task.WhenAll does not throw even if individual tasks fail —
            // exceptions are captured inside PlaceTargetOrderAsync and surfaced
            // via TargetResult.Success = false.
            await Task.WhenAll(targetTasks).ConfigureAwait(false);

            // ------------------------------------------------------------------
            // Emit ONE aggregated event (scale requirement: never 1-event-per-target)
            // ------------------------------------------------------------------

            int successCount = targetResults.Count(r => r.Success);
            // NOTE: failCount removed — replaced by realFailCount below, which excludes
            // no-op "no delta" results (Success=false with a non-failure reason).

            // Aggregate per-target summaries — keep payload small.
            // Use DestinationAccountName (server config name) as the primary label;
            // fall back to the resolved NT account name, then the connection ID.
            //
            // FIX #9/#10 (net-position reconciliation): qty now reports the delta
            // actually sent (not a scaled fill qty).  "reason" is non-null both on
            // failure AND on "no delta needed" (Success=true with reason set) so
            // the web can distinguish true failures from no-op reconciles.
            var perTarget = targetResults.Select(r => new
            {
                account    = r.AccountName ?? r.DestinationAccountName,
                delta      = r.Quantity,        // signed delta sent (renamed from qty for clarity)
                qty        = r.Quantity,        // kept for back-compat with web event display
                ok         = r.Success,
                reason     = r.FailureReason,   // null only when Success and an order was placed
                twin_state = r.TwinState        // EXIT-SYNC (v1.8.0): null when not an exit-sync job
            }).ToList();

            // A result is a "real failure" (not just a no-op no-delta) when it is
            // !Success AND FailureReason is not one of the no-action reasons.
            int realFailCount = targetResults.Count(r =>
                !r.Success &&
                r.FailureReason != "no delta (already reconciled)" &&
                r.FailureReason != "no effective delta after gating");

            string eventType = realFailCount == 0 ? "copy_executed" : "copy_failed";
            string severity  = realFailCount == 0 ? "info"
                             : (successCount == 0 ? "warning" : "info");

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType          = eventType,
                Severity           = severity,
                // Include the source connection ID for back-compat with existing
                // web event displays; also include the account name for new displays.
                BrokerConnectionId = route.SourceConnectionId,
                Symbol             = fill.InstrumentName,
                Payload            = new
                {
                    execution_id         = fill.ExecutionId,
                    // Source account: prefer the config-level name (what the web
                    // configured), then fall back to the NT fill's account name.
                    source_account       = route.SourceAccountName ?? fill.AccountName,
                    source_account_nt    = fill.AccountName,    // NT-resolved name
                    source_broker        = route.SourceBroker,
                    source_environment   = route.SourceEnvironment,
                    symbol               = fill.InstrumentName,
                    side                 = fill.IsBuy ? "buy" : "sell",
                    source_qty           = fill.Quantity,
                    // FIX #9/#10: is_opening now reflects the fill's IsOpening flag
                    // (still populated by the adapter for tilt tracking / telemetry),
                    // but sizing NO LONGER depends on it.
                    is_opening           = fill.IsOpening,
                    reversed             = route.Reverse,
                    route_id             = route.Id,
                    route_label          = route.Label,
                    reconcile_mode       = true,           // signals web this is a net-reconcile event
                    targets_total        = targetResults.Count,
                    targets_ok           = successCount,
                    targets_failed       = realFailCount,
                    per_target           = perTarget,
                    // EXIT-SYNC (v1.8.0): flags this event as originating from a mirrored
                    // working-order's fill rather than a plain leader market fill.
                    is_exit_sync         = job.IsExitSync,
                    leader_order_id      = job.IsExitSync ? job.ExitSyncLeaderOrderId : null
                }
            });

            _log($"NetReconcile job complete — route '{route.Label}': " +
                 $"{successCount}/{targetResults.Count} targets OK, " +
                 $"{realFailCount} real failures.");

            // ------------------------------------------------------------------
            // Tilt tracking: record fill result for CLOSE fills on the SOURCE
            // account so RiskEnforcer can maintain the consecutive-loss streak.
            //
            // Why source account: tilt is about the human trader going on a losing
            // streak.  The source account is where the human trades; the risk rule
            // that governs that account (matched by route.SourceConnectionId) is
            // the one that carries TiltLossStreak / TiltCooldownMinutes.
            //
            // VERIFY (NT8 API): see pre-snapshot comment above.  If the PnL delta
            // is unreliable (always 0), replace this block with a TODO hook and
            // wire it when NT8 exposes Execution.Profit directly on the fill event.
            // ------------------------------------------------------------------
            if (!fill.IsOpening)
            {
                try
                {
                    await RecordSourceFillTiltAsync(fill, cfg, preFillRealizedPnL, _cts.Token)
                        .ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    // Tilt tracking is bookkeeping — a failure here must never
                    // propagate to the caller or disrupt the copy loop.
                    _log($"RecordSourceFillTiltAsync error (non-fatal): " +
                         $"{ex.GetType().Name} — {ex.Message}");
                }
            }
        }

        // -----------------------------------------------------------------------
        // RecordSourceFillTiltAsync — tilt bookkeeping for close fills
        // -----------------------------------------------------------------------

        /// <summary>
        /// Called after every source close fill.  Computes the realized PnL delta
        /// to determine win/loss, then calls RiskEnforcer.RecordFillResultAsync for
        /// every risk rule that governs the source account.
        ///
        /// Fail-safe: all exceptions are caught by the caller.
        /// </summary>
        private async Task RecordSourceFillTiltAsync(
            FillInfo         fill,
            AutomationConfig cfg,
            double           preFillRealizedPnL,
            CancellationToken ct)
        {
            // FIX #6 (account-level risk): resolve the rule's account using the SAME
            // AccountName-first logic that RiskEnforcer.RunAsync uses.
            // The previous code resolved only via BrokerConnectionId, so rules whose
            // server payload carries account_name (null broker_connection_id) never had
            // their tilt recorded — tilt_loss_streak silently never fired.
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            string sourceAccount = fill.AccountName;

            foreach (var rule in cfg.RiskRules ?? new List<RiskRule>())
            {
                if (!rule.Enforce || !rule.IsActive) continue;
                if (!rule.TiltLossStreak.HasValue)   continue;   // tilt not configured

                // FIX #6: AccountName-first resolution, BrokerConnectionId fallback.
                BrokerConnection ruleConn = null;
                string ruleAccount = null;

                if (!string.IsNullOrWhiteSpace(rule.AccountName))
                {
                    // Primary: resolve via broker account name (modern server contract).
                    ruleAccount = _platform.ResolveAccountByName(rule.AccountName);
                    // Best-effort: try to find a matching connection for the RecordFillResultAsync
                    // call (used only for event payloads — null is acceptable).
                    ruleConn = FindConnectionByAccountName(cfg, rule.AccountName);
                }
                else
                {
                    // Fallback: legacy broker_connection_id path.
                    ruleConn = FindConnection(cfg, rule.BrokerConnectionId);
                    if (ruleConn != null)
                        ruleAccount = _platform.ResolveAccountName(ruleConn);
                }

                if (ruleAccount == null || !string.Equals(ruleAccount, sourceAccount,
                        StringComparison.OrdinalIgnoreCase)) continue;

                // We have a tilt-enabled rule for the source account.
                // Compute PnL delta to determine win/loss.
                //
                // VERIFY (NT8 API): GetSessionRealizedPnL must reflect the P&L of
                // THIS fill by the time we call it here.  If NT8 updates its account
                // state synchronously before returning from ExecutionUpdate (i.e.
                // before the fill was enqueued), then postFill == preFill because the
                // pre-snapshot was already taken after the P&L update.  In that case,
                // swap preFillRealizedPnL to be captured in the hot-path callback
                // (before enqueue) and postFillRealizedPnL here (after fan-out), OR
                // use a per-position average-entry-price tracker to compute trade P&L
                // directly from fill.Price.
                //
                // TODO (NT8 API — if delta is always 0): implement a lightweight
                // PositionTracker that records average entry price per account+symbol,
                // then computes realized P&L from (fill.Price - avgEntry) * qty *
                // pointValue when a close fill arrives.  Wire that here instead of
                // the GetSessionRealizedPnL delta.
                double postFillRealizedPnL = _platform.GetSessionRealizedPnL(sourceAccount);
                double pnlDelta            = postFillRealizedPnL - preFillRealizedPnL;

                // Update the stored baseline for the next fill's pre-snapshot.
                _lastSourceRealizedPnL[sourceAccount] = postFillRealizedPnL;

                bool wasLoss;
                if (pnlDelta == 0.0)
                {
                    // Delta is zero — NT8 P&L update may be asynchronous; we cannot
                    // reliably determine win/loss.  Log and skip this fill rather than
                    // recording a wrong result.
                    //
                    // VERIFY (NT8 API): if this log fires consistently, the delta
                    // approach is not viable.  Implement the PositionTracker TODO above.
                    _log($"TiltTracker: PnL delta = 0 for close fill '{fill.ExecutionId}' " +
                         $"on '{sourceAccount}' — cannot determine win/loss. " +
                         "Skipping tilt recording for this fill. " +
                         "VERIFY (NT8 API): GetSessionRealizedPnL may not update synchronously.");
                    continue;
                }
                else
                {
                    wasLoss = pnlDelta < 0.0;
                }

                _log($"TiltTracker: close fill '{fill.ExecutionId}' on '{sourceAccount}': " +
                     $"PnL delta = {pnlDelta:+0.00;-0.00} → {(wasLoss ? "LOSS" : "WIN")}.");

                await _risk.RecordFillResultAsync(
                    rule.Id,
                    sourceAccount,
                    wasLoss,
                    rule,
                    ruleConn,
                    ct,
                    pnlDelta: pnlDelta).ConfigureAwait(false);
            }
        }

        // =========================================================================
        // WORKING-ORDER MIRRORING — order consumer + processing
        //
        // ALONGSIDE the fill-copy consumer above (ConsumerLoop / ProcessJobAsync).
        // Mirrors the leader's working (limit/stop/stoplimit) orders onto the
        // followers as their own working orders, so followers fill independently
        // at the same trigger price instead of receiving a market order when the
        // leader fills. See CopierEngine._orderQueue / OnOrderHotPathCallback above.
        // =========================================================================

        /// <summary>
        /// Background consumer for order-mirroring jobs. Dequeues OrderCopyJob
        /// objects and processes them one at a time (mirrors ConsumerLoop's
        /// shape). Runs until the shared CancellationToken is signalled.
        /// All exceptions are caught; the loop never exits on its own.
        /// </summary>
        private void OrderConsumerLoop()
        {
            _log("CopierEngine order-mirroring consumer loop started.");

            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    // TRAILING/MODIFY DEBOUNCE (v1.8.0): switched from the blocking
                    // Take(token) to a bounded TryTake so the loop also gets a chance
                    // to flush any coalesced pending modifies even when no new order
                    // event has arrived. 100ms poll — well under ModifyDebounceMs
                    // (300ms), so a due pending modify is never delayed by more than
                    // one extra poll tick.
                    if (_orderQueue.TryTake(out OrderCopyJob job, 100, _cts.Token))
                    {
                        ProcessOrderJob(job);
                    }

                    FlushDuePendingModifies();
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown path
                    break;
                }
                catch (Exception ex)
                {
                    // Should not happen; log and continue the loop. Never let a
                    // single bad job or flush error kill the consumer.
                    _log($"OrderConsumerLoop unexpected error: {ex.GetType().Name} — {ex.Message}");
                }
            }

            _log("CopierEngine order-mirroring consumer loop stopped.");
        }

        /// <summary>
        /// TRAILING/MODIFY DEBOUNCE (v1.8.0): drains any _pendingModifies entries
        /// whose DueTicks has elapsed and submits them via ProcessOrderModifyIfChanged,
        /// under the same per-leader-order lock ProcessOrderJob uses. Called every
        /// OrderConsumerLoop iteration (~100ms). Never throws — any per-entry error
        /// is logged and the loop continues to the next entry.
        /// </summary>
        private void FlushDuePendingModifies()
        {
            if (_pendingModifies.IsEmpty) return;

            long nowTicks = Stopwatch.GetTimestamp();

            foreach (var kvp in _pendingModifies.ToList())
            {
                string leaderOrderId = kvp.Key;
                PendingModify pm = kvp.Value;

                if (pm.DueTicks > nowTicks) continue;

                if (!_pendingModifies.TryRemove(leaderOrderId, out PendingModify removed))
                    continue; // another thread already claimed/removed it

                try
                {
                    object orderLock = _orderLocks.GetOrAdd(leaderOrderId, _ => new object());
                    lock (orderLock)
                    {
                        // Re-check the mapping still exists — the order may have been
                        // cancelled/filled/rebuilt (config reload) since this entry was
                        // queued. Skip silently if so; nothing left to modify.
                        if (!_mirroredLeaderOrders.TryGetValue(leaderOrderId, out MirroredOrder mapping))
                        {
                            _log($"FlushDuePendingModifies: leader order '{leaderOrderId}' no longer " +
                                 "mirrored — dropping stale pending modify.");
                            continue;
                        }

                        if (ProcessOrderModifyIfChanged(removed.Latest, mapping, leaderOrderId, removed.Config, removed.Route))
                            mapping.LastModifySubmitTicks = Stopwatch.GetTimestamp();
                    }
                }
                catch (Exception ex)
                {
                    _log($"FlushDuePendingModifies error for leader order '{leaderOrderId}': " +
                         $"{ex.GetType().Name} — {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Resolves a CopierTarget to its local NT account name, using the SAME
        /// resolution order as PlaceTargetOrderCore STEP 1 (DestinationAccountName
        /// primary, DestinationConnectionId fallback). Returns null (with the
        /// failure reason via the out parameter) if resolution fails — the caller
        /// MUST skip this target rather than guess.
        /// </summary>
        private string ResolveTargetAccountForOrder(
            CopierTarget target, AutomationConfig cfg, out string failureReason)
        {
            failureReason = null;

            if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
            {
                string acct = _platform.ResolveAccountByName(target.DestinationAccountName);
                if (acct == null)
                {
                    failureReason =
                        $"destination account '{target.DestinationAccountName}' " +
                        "not found in local NT8 — account may not be connected";
                }
                return acct;
            }

            if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
            {
                BrokerConnection destConn = FindConnection(cfg, target.DestinationConnectionId);
                if (destConn == null)
                {
                    failureReason =
                        $"destination connection '{target.DestinationConnectionId}' not in config";
                    return null;
                }
                string acct = _platform.ResolveAccountName(destConn);
                if (acct == null)
                {
                    failureReason =
                        $"no NT account found for connection '{target.DestinationConnectionId}' (fallback)";
                }
                return acct;
            }

            failureReason =
                "target has neither DestinationAccountName nor DestinationConnectionId " +
                "(malformed target config)";
            return null;
        }

        /// <summary>
        /// Processes one OrderCopyJob: decides PLACEMENT / MODIFY / CANCEL /
        /// FILLED-PARTFILLED action from the leader order's State, serialized
        /// under a per-leader-order-id lock so concurrent order-state callbacks
        /// for the same leader order cannot race each other.
        ///
        /// NEVER throws — all exceptions are caught and logged; this runs on the
        /// dedicated order-consumer Task, off the NT thread, but must still never
        /// bring down the consumer loop.
        /// </summary>
        private void ProcessOrderJob(OrderCopyJob job)
        {
            try
            {
                OrderInfo        order = job.SourceOrder;
                CopierRoute      route = job.Route;
                AutomationConfig cfg   = job.Config;

                if (order == null || string.IsNullOrWhiteSpace(order.OrderId))
                {
                    _log("ProcessOrderJob: order or OrderId missing — skipping.");
                    return;
                }

                // RESILIENCE (v1.9.0): FOLLOWER order-lifecycle events (rejected/
                // cancelled on a target account's own mirrored order) are routed
                // to a dedicated handler, entirely separate from the leader-order
                // PLACEMENT/MODIFY/CANCEL switch below.
                if (job.IsFollowerEvent)
                {
                    HandleFollowerOrderEvent(job);
                    return;
                }

                string leaderOrderId = order.OrderId;
                string state = (order.State ?? string.Empty).ToLowerInvariant();

                object orderLock = _orderLocks.GetOrAdd(leaderOrderId, _ => new object());

                lock (orderLock)
                {
                    bool hasMapping = _mirroredLeaderOrders.TryGetValue(leaderOrderId, out MirroredOrder mapping);

                    switch (state)
                    {
                        case "working":
                        case "accepted":
                        case "submitted":
                            if (!hasMapping)
                            {
                                ProcessOrderPlacement(order, route, cfg, leaderOrderId);
                            }
                            else
                            {
                                // Already mirrored and no material change — treat as a
                                // potential MODIFY candidate too (state transitions like
                                // accepted → working can repeat with the same prices).
                                TrySubmitOrDebounceModify(order, mapping, leaderOrderId, cfg, route);
                            }
                            break;

                        case "changesubmitted":
                            if (hasMapping)
                            {
                                TrySubmitOrDebounceModify(order, mapping, leaderOrderId, cfg, route);
                            }
                            else
                            {
                                _log($"ProcessOrderJob: MODIFY-like state '{state}' for leader order " +
                                     $"'{leaderOrderId}' with no mirrored mapping — nothing to modify.");
                            }
                            break;

                        case "cancelled":
                        case "rejected":
                            // TRAILING/MODIFY DEBOUNCE (v1.8.0): drop any coalesced pending
                            // modify for this leader order — it is now terminal, there is
                            // nothing left to flush.
                            _pendingModifies.TryRemove(leaderOrderId, out _);
                            if (hasMapping)
                            {
                                ProcessOrderCancel(mapping, leaderOrderId, state);
                            }
                            // Leader terminal state — a fully risk-blocked order (no mapping,
                            // so ProcessOrderCancel above did not run) must still clear the
                            // skip-list entry so a genuinely new order reusing this id (or a
                            // resubmitted leader order) is re-evaluated fresh. No-op if absent.
                            _riskBlockedLeaderOrders.TryRemove(leaderOrderId, out _);
                            break;

                        case "filled":
                            // EXIT-SYNC (v1.8.0): mapping removal is now owned by the FILL
                            // consumer's exit-sync pre-step (ProcessJobAsync), which needs the
                            // mapping to still be present when the follower's own fill (or the
                            // leader's fill routed through WasLeaderOrderMirrored) arrives, so
                            // it can force-cancel the twin and reseed the tracker. Do NOT
                            // remove the mapping here — only clear the risk-blocked skip-list
                            // entry so a genuinely re-placed order (reusing this id) is
                            // re-evaluated fresh.
                            _riskBlockedLeaderOrders.TryRemove(leaderOrderId, out _);
                            _log($"ProcessOrderJob: leader order '{leaderOrderId}' FILLED — " +
                                 "mapping left for exit-sync fill path (removed by the fill consumer, not here).");
                            break;

                        case "partfilled":
                            // Keep the mapping — more fills/modifies/cancels may follow.
                            // Nothing to do here; followers fill on their own.
                            break;

                        default:
                            // "other" or unrecognized state — fail-safe: do nothing.
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ProcessOrderJob exception for order '{job?.SourceOrder?.OrderId}': " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        /// <summary>
        /// PLACEMENT: mirrors a newly-seen leader working order to every active
        /// target on the route. Must be called under the per-leader-order lock.
        ///
        /// NOTE (v2 TODO): async broker rejects of follower orders are invisible
        /// here — PlaceWorkingOrder's Submit() call returns a pre-ack Order.Id;
        /// this engine does not subscribe target accounts, so a later broker-side
        /// rejection of the follower order is never observed or reported. v2:
        /// subscribe targets filtered to our own order names ("FinotaurCopier*")
        /// to catch late rejects.
        /// </summary>
        private void ProcessOrderPlacement(
            OrderInfo order, CopierRoute route, AutomationConfig cfg, string leaderOrderId)
        {
            if (_riskBlockedLeaderOrders.ContainsKey(leaderOrderId))
            {
                _log($"OrderMirror PLACEMENT SKIP (leader '{leaderOrderId}'): previously risk-blocked " +
                     "on all targets — skipping re-placement until a terminal state or config rebuild clears it.");
                return;
            }

            var mirrored = new MirroredOrder
            {
                RouteId       = route.Id,
                LeaderOrderId = leaderOrderId,
                LastLimit     = order.LimitPrice,
                LastStop      = order.StopPrice,
                LastQty       = order.Quantity,
                Tif           = order.Tif,
                LeaderOco     = order.OcoId ?? string.Empty,
            };

            var perTarget = new List<object>();
            int targetsOk = 0;
            int targetsTotal = 0;
            bool anyRiskBlocked = false;

            foreach (var target in route.Targets ?? new List<CopierTarget>())
            {
                if (!target.IsActive) continue;
                targetsTotal++;

                string targetDisplayName = !string.IsNullOrWhiteSpace(target.DestinationAccountName)
                    ? target.DestinationAccountName
                    : target.DestinationConnectionId;

                try
                {
                    string targetAccount = ResolveTargetAccountForOrder(target, cfg, out string resolveFailure);
                    if (targetAccount == null)
                    {
                        _log($"OrderMirror PLACEMENT SKIP ({targetDisplayName}): {resolveFailure}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason = resolveFailure });
                        continue;
                    }

                    string instr = TranslateInstrument(order.InstrumentName, target);

                    int qty = (int)Math.Round(order.Quantity * target.ScaleRatio, MidpointRounding.AwayFromZero);
                    if (target.MaxContracts.HasValue && target.MaxContracts.Value > 0 && qty > target.MaxContracts.Value)
                        qty = target.MaxContracts.Value;

                    if (qty <= 0)
                    {
                        string reason = "scaled quantity <= 0 — skipped";
                        _log($"OrderMirror PLACEMENT SKIP ({targetDisplayName}): {reason}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                        continue;
                    }

                    bool isBuy = route.Reverse ? !order.IsBuy : order.IsBuy;

                    // Pre-placement risk gate — same semantics as the fill path (PlaceTargetOrderCore).
                    // NOTE: projects against current POSITION only, not other outstanding working
                    // orders (same approximation as the fill path). Mirrored-order fills do not
                    // count toward max_trades_per_day (v2).
                    //
                    // IRON RULE (2026-07-02 incident): an order that REDUCES exposure (e.g. a
                    // mirrored stop-loss/closing order placed while the follower is already at
                    // its contracts limit) must never be blocked by risk rules. Approximate the
                    // signed order direction from isBuy and compare against the follower's
                    // CURRENT signed net (same GetSignedNetPosition helper the fill path uses
                    // for seeding). This is a placement-time approximation only — the position
                    // can change between placement and fill; the fill-time check in
                    // PlaceTargetOrderCore remains the authoritative gate.
                    int followerSignedNet = GetSignedNetPosition(
                        _platform.GetPositions(targetAccount), instr);
                    int orderSignedQty = isBuy ? qty : -qty;
                    bool reducesExposure = followerSignedNet != 0
                        && Math.Abs(followerSignedNet + orderSignedQty) <= Math.Abs(followerSignedNet);

                    if (!_risk.IsOrderAllowed(targetAccount, instr, qty, cfg.RiskRules, cfg.Connections, reducesExposure))
                    {
                        string reason = "blocked by risk rule";
                        _log($"OrderMirror PLACEMENT BLOCKED ({targetDisplayName} → '{targetAccount}'): {reason}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                        anyRiskBlocked = true;
                        continue;
                    }

                    string ot = order.OrderType; // already validated to be limit/stop/stoplimit/mit by the hot path
                    double limitPrice = 0.0;
                    double stopPrice  = 0.0;
                    if (ot == "limit")
                    {
                        limitPrice = order.LimitPrice;
                    }
                    else if (ot == "stop" || ot == "mit")
                    {
                        // MIT (Market-If-Touched) trigger rides Order.StopPrice, same
                        // field as a plain stop — NT8 convention (see NinjaTraderAdapter
                        // SubscribeOrders/PlaceWorkingOrder for the matching mapping).
                        stopPrice = order.StopPrice;
                    }
                    else // "stoplimit"
                    {
                        limitPrice = order.LimitPrice;
                        stopPrice  = order.StopPrice;
                    }

                    string orderName = $"FinotaurCopier|ord|{leaderOrderId}|{targetAccount}";

                    string followerOco = string.IsNullOrEmpty(order.OcoId)
                        ? string.Empty
                        : MakeFollowerOco(order.OcoId, targetAccount);

                    string followerId = _platform.PlaceWorkingOrder(
                        targetAccount, instr, isBuy, qty, ot, limitPrice, stopPrice, orderName, order.Tif, followerOco);

                    if (followerId != null)
                    {
                        mirrored.Targets.Add(new MirroredTarget
                        {
                            TargetAccount   = targetAccount,
                            FollowerOrderId = followerId,
                            ScaleRatio      = target.ScaleRatio,
                            MaxContracts    = target.MaxContracts,
                            Instrument      = instr,
                            FollowerOco     = followerOco
                        });
                        targetsOk++;
                        _log($"OrderMirror PLACEMENT ({targetDisplayName} → '{targetAccount}'): " +
                             $"placed follower {ot} order '{followerId}' " +
                             $"{(isBuy ? "BUY" : "SELL")} {qty} {instr} " +
                             $"(limit={limitPrice}, stop={stopPrice}, tif={order.Tif}, oco={followerOco}).");
                        perTarget.Add(new { account = targetDisplayName, ok = true, order_id = followerId, qty, oco = followerOco });
                    }
                    else
                    {
                        string reason = "PlaceWorkingOrder returned null (see NT adapter log)";
                        _log($"OrderMirror PLACEMENT FAILED ({targetDisplayName} → '{targetAccount}'): {reason}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                    }
                }
                catch (Exception ex)
                {
                    string reason = $"{ex.GetType().Name}: {ex.Message}";
                    _log($"OrderMirror PLACEMENT exception ({targetDisplayName}): {reason}");
                    perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                }
            }

            if (mirrored.Targets.Count > 0)
            {
                _mirroredLeaderOrders[leaderOrderId] = mirrored;
                MarkLeaderOrderMirrored(leaderOrderId);
            }
            else if (anyRiskBlocked)
            {
                // No target succeeded and at least one was risk-blocked — remember this
                // leader order so the next OrderUpdate state event (e.g. accepted → working)
                // doesn't re-run placement and re-emit a duplicate order_copy_failed event.
                // Partial successes (mirrored.Targets.Count > 0) already create a mapping
                // above and never reach this branch.
                _riskBlockedLeaderOrders.TryAdd(leaderOrderId, 1);
            }

            string eventType = targetsOk > 0 ? "order_copy_executed" : "order_copy_failed";
            // STEP 4a: any per-target failure downgrades severity to "warning" even
            // when the overall eventType stays order_copy_executed (partial success
            // is still worth flagging — some followers did not get the order).
            string severity  = (targetsTotal - targetsOk) > 0
                ? "warning"
                : (targetsOk > 0 ? "info" : "info");

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType          = eventType,
                Severity           = severity,
                BrokerConnectionId = route.SourceConnectionId,
                Symbol             = order.InstrumentName,
                Payload            = new
                {
                    order_id        = leaderOrderId,
                    source_account  = route.SourceAccountName,
                    symbol          = order.InstrumentName,
                    side            = order.IsBuy ? "buy" : "sell",
                    order_type      = order.OrderType,
                    limit_price     = order.LimitPrice,
                    stop_price      = order.StopPrice,
                    source_qty      = order.Quantity,
                    tif             = order.Tif,
                    oco_id          = order.OcoId,
                    reversed        = route.Reverse,
                    route_id        = route.Id,
                    route_label     = route.Label,
                    targets_total   = targetsTotal,
                    targets_ok      = targetsOk,
                    targets_failed  = targetsTotal - targetsOk,
                    per_target      = perTarget
                }
            });

            _log($"OrderMirror PLACEMENT complete — route '{route.Label}': " +
                 $"{targetsOk}/{targetsTotal} targets OK for leader order '{leaderOrderId}'.");
        }

        /// <summary>
        /// MODIFY: if the leader order's price/quantity changed since last seen,
        /// propagate a scaled modify to every mirrored follower order. Must be
        /// called under the per-leader-order lock.
        ///
        /// STEP 3b: quantity INCREASES are gated by the same pre-trade risk check
        /// as placement — a leader adding size to a resting order is economically
        /// equivalent to a new order and must not silently bypass max_contracts /
        /// daily-loss / etc. Quantity DECREASES and price-only changes are NEVER
        /// re-gated — blocking a stop-loss adjustment (or a size reduction) would
        /// strand followers with worse risk than the leader, which is the opposite
        /// of what the gate is for.
        ///
        /// IRON RULE (2026-07-02 incident): even a quantity INCREASE must bypass
        /// the gate if it still reduces the follower's exposure (e.g. enlarging a
        /// stop-loss/closing order to cover a bigger position). `route` is passed
        /// in only to resolve Reverse for the order-side computation — same
        /// isBuy formula ProcessOrderPlacement uses.
        /// </summary>
        /// <summary>
        /// TRAILING/MODIFY DEBOUNCE (v1.8.0). Called from ProcessOrderJob's modify
        /// branches (must already be under the per-leader-order lock). Quantity
        /// changes always submit immediately — sizing is never trailing noise.
        /// Price-only changes submit immediately if at least ModifyDebounceMs has
        /// elapsed since the last actual submit; otherwise they are coalesced into
        /// _pendingModifies (overwriting any previous pending entry for this
        /// leader order) for OrderConsumerLoop's FlushDuePendingModifies to pick
        /// up once due. This bounds broker-modify frequency for fast-trailing
        /// leader stops without dropping any state — only the LATEST snapshot
        /// is ever discarded in favor of a newer one, never silently ignored.
        /// </summary>
        private void TrySubmitOrDebounceModify(
            OrderInfo order, MirroredOrder mapping, string leaderOrderId, AutomationConfig cfg, CopierRoute route)
        {
            bool qtyChanged = order.Quantity != mapping.LastQty;
            long now         = Stopwatch.GetTimestamp();
            long minGap      = Stopwatch.Frequency * ModifyDebounceMs / 1000;

            if (qtyChanged || now - mapping.LastModifySubmitTicks >= minGap)
            {
                // Either a sizing change (never debounced) or enough time has
                // elapsed since the last submit — submit now and drop any
                // stale coalesced entry (this call supersedes it).
                _pendingModifies.TryRemove(leaderOrderId, out _);
                if (ProcessOrderModifyIfChanged(order, mapping, leaderOrderId, cfg, route))
                    mapping.LastModifySubmitTicks = now;
            }
            else
            {
                // Too soon since the last submit and this is a price-only change —
                // coalesce. Overwrites any previous pending entry for this order.
                _pendingModifies[leaderOrderId] = new PendingModify
                {
                    Latest   = order,
                    Route    = route,
                    Config   = cfg,
                    DueTicks = mapping.LastModifySubmitTicks + minGap
                };
            }
        }

        /// <summary>
        /// Returns true only when this call actually SUBMITTED at least one
        /// broker-side modify (i.e. the leader order materially changed since
        /// last seen). Returns false on the "nothing changed" early-out — used by
        /// ProcessOrderJob's debounce logic (v1.8.0) to decide whether to stamp
        /// MirroredOrder.LastModifySubmitTicks.
        /// </summary>
        private bool ProcessOrderModifyIfChanged(
            OrderInfo order, MirroredOrder mapping, string leaderOrderId, AutomationConfig cfg, CopierRoute route)
        {
            bool changed = order.LimitPrice != mapping.LastLimit
                        || order.StopPrice  != mapping.LastStop
                        || order.Quantity   != mapping.LastQty;

            if (!changed) return false;

            string ot = order.OrderType;
            var perTarget = new List<object>();
            int targetsOk = 0;

            foreach (var mt in mapping.Targets)
            {
                try
                {
                    // Recompute the follower quantity using the SAME ratio/clamp as
                    // the original placement (snapshotted on MirroredTarget).
                    int scaledQty = (int)Math.Round(order.Quantity * mt.ScaleRatio, MidpointRounding.AwayFromZero);
                    if (mt.MaxContracts.HasValue && mt.MaxContracts.Value > 0 && scaledQty > mt.MaxContracts.Value)
                        scaledQty = mt.MaxContracts.Value;

                    // <=0 to ModifyWorkingOrder means "leave unchanged"; only pass a
                    // new quantity when the LEADER quantity actually changed and the
                    // recomputed follower quantity is valid (>0).
                    int qtyArg = (order.Quantity != mapping.LastQty && scaledQty > 0)
                        ? scaledQty
                        : -1;

                    // STEP 3b: gate ONLY quantity increases. Recompute what the
                    // follower quantity was under the PREVIOUS leader quantity
                    // (mapping.LastQty), using the same ratio/clamp, so we can
                    // isolate the follower-side delta rather than gating the
                    // full new quantity.
                    string qtyBlockReason = null;
                    if (qtyArg > 0)
                    {
                        int prevScaledQty = (int)Math.Round(mapping.LastQty * mt.ScaleRatio, MidpointRounding.AwayFromZero);
                        if (mt.MaxContracts.HasValue && mt.MaxContracts.Value > 0 && prevScaledQty > mt.MaxContracts.Value)
                            prevScaledQty = mt.MaxContracts.Value;

                        int qtyDelta = scaledQty - prevScaledQty;
                        if (qtyDelta > 0)
                        {
                            string gateInstrument = mt.Instrument ?? order.InstrumentName;

                            // IRON RULE: even though qty is increasing, the order may still
                            // be REDUCING the follower's exposure (e.g. a stop-loss/closing
                            // order enlarged to cover a bigger position). Derive the order's
                            // signed direction the same way ProcessOrderPlacement does, and
                            // compare against the follower's CURRENT signed net.
                            bool modifyIsBuy = route != null && route.Reverse ? !order.IsBuy : order.IsBuy;
                            int followerSignedNet = GetSignedNetPosition(
                                _platform.GetPositions(mt.TargetAccount), gateInstrument);
                            int orderSignedQtyDelta = modifyIsBuy ? qtyDelta : -qtyDelta;
                            bool modifyReducesExposure = followerSignedNet != 0
                                && Math.Abs(followerSignedNet + orderSignedQtyDelta) <= Math.Abs(followerSignedNet);

                            if (!_risk.IsOrderAllowed(mt.TargetAccount, gateInstrument, qtyDelta, cfg.RiskRules, cfg.Connections, modifyReducesExposure))
                            {
                                // Suppress the qty change only — price-only changes are
                                // NEVER re-gated (blocking a stop-loss adjustment would
                                // strand followers). Fall through with qtyArg reset so
                                // ModifyWorkingOrder still applies newLimit/newStop below.
                                qtyBlockReason = "qty increase blocked by risk rule — price-only modify applied";
                                qtyArg = -1;
                            }
                        }
                    }

                    double newLimit = (ot == "limit" || ot == "stoplimit")
                        ? (order.LimitPrice != mapping.LastLimit ? order.LimitPrice : -1)
                        : -1;
                    double newStop = (ot == "stop" || ot == "stoplimit" || ot == "mit")
                        ? (order.StopPrice != mapping.LastStop ? order.StopPrice : -1)
                        : -1;

                    bool ok = _platform.ModifyWorkingOrder(mt.TargetAccount, mt.FollowerOrderId, qtyArg, newLimit, newStop);
                    if (ok) targetsOk++;

                    _log($"OrderMirror MODIFY ({mt.TargetAccount}, follower '{mt.FollowerOrderId}'): " +
                         $"qty={qtyArg} limit={newLimit} stop={newStop} → {(ok ? "OK" : "FAILED")}" +
                         (qtyBlockReason != null ? $" [{qtyBlockReason}]" : string.Empty) + ".");

                    perTarget.Add(new
                    {
                        account  = mt.TargetAccount,
                        order_id = mt.FollowerOrderId,
                        ok,
                        reason   = qtyBlockReason ?? (ok ? null : "ModifyWorkingOrder returned false (see NT adapter log)")
                    });
                }
                catch (Exception ex)
                {
                    _log($"OrderMirror MODIFY exception ({mt.TargetAccount}, follower '{mt.FollowerOrderId}'): {ex.Message}");
                    perTarget.Add(new { account = mt.TargetAccount, order_id = mt.FollowerOrderId, ok = false, reason = ex.Message });
                }
            }

            mapping.LastLimit = order.LimitPrice;
            mapping.LastStop  = order.StopPrice;
            mapping.LastQty   = order.Quantity;

            // STEP 4b: same per-target-failure severity rule as PLACEMENT — any
            // target below full success downgrades to "warning".
            string severity = targetsOk < mapping.Targets.Count ? "warning" : "info";

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType = "order_copy_modified",
                Severity  = severity,
                Symbol    = order.InstrumentName,
                Payload   = new
                {
                    order_id       = leaderOrderId,
                    symbol         = order.InstrumentName,
                    order_type     = order.OrderType,
                    limit_price    = order.LimitPrice,
                    stop_price     = order.StopPrice,
                    source_qty     = order.Quantity,
                    route_id       = mapping.RouteId,
                    targets_total  = mapping.Targets.Count,
                    targets_ok     = targetsOk,
                    targets_failed = mapping.Targets.Count - targetsOk,
                    per_target     = perTarget
                }
            });

            _log($"OrderMirror MODIFY complete — leader order '{leaderOrderId}': " +
                 $"{targetsOk}/{mapping.Targets.Count} targets OK.");

            return true;
        }

        /// <summary>
        /// CANCEL: cancels every mirrored follower order and stops tracking the
        /// leader order. Must be called under the per-leader-order lock. Does
        /// NOT remove the leader order id from _everMirroredOrderIds — that set
        /// must persist so any late fill on this (now-cancelled) leader order
        /// still correctly skips the fill-copy path.
        /// </summary>
        private void ProcessOrderCancel(MirroredOrder mapping, string leaderOrderId, string state)
        {
            var perTarget = new List<object>();
            int targetsOk = 0;

            foreach (var mt in mapping.Targets)
            {
                try
                {
                    bool ok = _platform.CancelWorkingOrder(mt.TargetAccount, mt.FollowerOrderId);
                    if (ok) targetsOk++;

                    _log($"OrderMirror CANCEL ({mt.TargetAccount}, follower '{mt.FollowerOrderId}') " +
                         $"triggered by leader state '{state}': {(ok ? "OK" : "FAILED")}.");

                    perTarget.Add(new
                    {
                        account  = mt.TargetAccount,
                        order_id = mt.FollowerOrderId,
                        ok,
                        reason   = ok ? null : "CancelWorkingOrder returned false (see NT adapter log)"
                    });
                }
                catch (Exception ex)
                {
                    _log($"OrderMirror CANCEL exception ({mt.TargetAccount}, follower '{mt.FollowerOrderId}'): {ex.Message}");
                    perTarget.Add(new { account = mt.TargetAccount, order_id = mt.FollowerOrderId, ok = false, reason = ex.Message });
                }
            }

            _mirroredLeaderOrders.TryRemove(leaderOrderId, out _);

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType = "order_copy_cancelled",
                Severity  = "info",
                Payload   = new
                {
                    order_id       = leaderOrderId,
                    leader_state   = state,
                    route_id       = mapping.RouteId,
                    targets_total  = mapping.Targets.Count,
                    targets_ok     = targetsOk,
                    targets_failed = mapping.Targets.Count - targetsOk,
                    per_target     = perTarget
                }
            });

            _log($"OrderMirror CANCEL complete — leader order '{leaderOrderId}' (state '{state}'): " +
                 $"{targetsOk}/{mapping.Targets.Count} follower cancels OK.");
        }

        // -----------------------------------------------------------------------
        // HandleFollowerOrderEvent (v1.9.0 RESILIENCE) — reacts to terminal
        // lifecycle events on a FOLLOWER's own mirrored order.
        // -----------------------------------------------------------------------

        /// <summary>
        /// Processes a terminal (rejected/cancelled) lifecycle event observed on
        /// a follower's own mirrored order ("FinotaurCopier|ord|{leaderOrderId}|
        /// {targetAccount}"). Called from ProcessOrderJob's early IsFollowerEvent
        /// branch — NOT under the per-leader-order lock yet; this method acquires
        /// that lock itself once the leader order id has been parsed from the
        /// order Name, so it serializes correctly against concurrent leader-side
        /// PLACEMENT/MODIFY/CANCEL handling for the SAME leader order.
        ///
        /// Two terminal states are handled:
        ///   • "rejected" — a broker-side async reject of the follower order that
        ///     the synchronous PlaceWorkingOrder call could not see (it only
        ///     returns a pre-ack Order.Id). Removes JUST this target from the
        ///     mapping (other targets are unaffected) and emits order_copy_failed.
        ///   • "cancelled" — if the mapping still lists this target's
        ///     FollowerOrderId, this is an EXTERNAL cancel (the user, or the
        ///     broker, cancelled the follower order directly — NOT our own
        ///     cancel flow, which removes the mapping/target FIRST via
        ///     ProcessOrderCancel before the broker's cancel-echo can return,
        ///     making our own cancels naturally idempotent here). Removes the
        ///     target and emits order_copy_cancelled with a distinct reason.
        ///     If the target is already gone from the mapping (our own cancel's
        ///     echo), this is a no-op — by design, not by accident.
        ///
        /// Issues ZERO adapter order commands — purely observes and updates
        /// local tracking + telemetry (structurally loop-free, per the design).
        /// </summary>
        private void HandleFollowerOrderEvent(OrderCopyJob job)
        {
            OrderInfo order = job.SourceOrder;
            string state = (order.State ?? string.Empty).ToLowerInvariant();

            if (state != "rejected" && state != "cancelled")
                return; // fail-safe — should already be filtered by OnFollowerOrderEvent

            // Parse the leader OrderId out of the follower's own order Name:
            // "FinotaurCopier|ord|{leaderOrderId}|{targetAccount}" → part index 2.
            string[] parts = (order.OrderName ?? string.Empty).Split('|');
            if (parts.Length < 3 || string.IsNullOrWhiteSpace(parts[2]))
            {
                _log($"HandleFollowerOrderEvent: could not parse leaderOrderId from OrderName " +
                     $"'{order.OrderName}' (follower order '{order.OrderId}') — skipping.");
                return;
            }
            string leaderOrderId = parts[2];

            object orderLock = _orderLocks.GetOrAdd(leaderOrderId, _ => new object());

            lock (orderLock)
            {
                if (!_mirroredLeaderOrders.TryGetValue(leaderOrderId, out MirroredOrder mapping))
                {
                    // No mapping at all — either our own cancel already removed it
                    // (naturally idempotent — see ProcessOrderCancel), or a stale/
                    // already-handled event. No-op either way.
                    return;
                }

                MirroredTarget mt = mapping.Targets.Find(t =>
                    string.Equals(t.FollowerOrderId, order.OrderId, StringComparison.OrdinalIgnoreCase));

                if (state == "cancelled" && mt == null)
                {
                    // Our own cancel removed this target BEFORE the broker's
                    // cancel-echo returned — this is that echo. No-op by design.
                    return;
                }

                if (mt == null)
                {
                    // "rejected" with no matching target — nothing to remove, but
                    // still surface the event for visibility.
                    _log($"HandleFollowerOrderEvent: follower order '{order.OrderId}' state '{state}' " +
                         $"for leader '{leaderOrderId}' — no matching target found in mapping (already removed?).");
                }
                else
                {
                    mapping.Targets.Remove(mt);
                    if (mapping.Targets.Count == 0)
                        _mirroredLeaderOrders.TryRemove(leaderOrderId, out _);
                }

                string eventType = state == "rejected" ? "order_copy_failed" : "order_copy_cancelled";
                string reason = state == "rejected"
                    ? "broker rejected async"
                    : "follower cancelled externally — respected, target removed from mirror";

                _eventQueue.Enqueue(new AutomationEvent
                {
                    EventType = eventType,
                    Severity  = "warning",
                    Payload   = new
                    {
                        order_id   = leaderOrderId,
                        per_target = new[]
                        {
                            new
                            {
                                account  = order.AccountName,
                                order_id = order.OrderId,
                                ok       = false,
                                reason
                            }
                        }
                    }
                });

                _log($"HandleFollowerOrderEvent: leader '{leaderOrderId}' follower order " +
                     $"'{order.OrderId}' on '{order.AccountName}' — state '{state}': {reason}.");
            }
        }

        // -----------------------------------------------------------------------
        // PlaceTargetOrderAsync — one target account
        // -----------------------------------------------------------------------

        /// <summary>
        /// FIX #9/#10 (net-position reconciliation): replaces fill-by-fill mirroring.
        /// Self-heals divergence; removes IsOpening dependency.
        ///
        /// Resolves the target account, reads source and target net positions,
        /// computes the desired target net, gates by CopyOpens/CopyCloses, checks
        /// risk rules, and places ONE delta order if needed.
        ///
        /// Returns a TargetResult describing the outcome.
        /// NEVER throws — all exceptions are caught and returned as failures.
        /// </summary>
        private Task<TargetResult> PlaceTargetOrderAsync(
            FillInfo        fill,
            CopierRoute     route,
            CopierTarget    target,
            AutomationConfig cfg,
            long            dequeuedTicks,
            CancellationToken ct,
            MirroredTarget  exitTwin = null,
            bool            forceReseed = false)
        {
            // NOTE: this method was originally async but has no awaits after the
            // net-reconciliation rewrite.  It is now a synchronous method returning
            // Task.FromResult — callers (ProcessJobAsync via Task.WhenAll) see no
            // difference; the fan-out concurrency is preserved by Task.Run in the caller.
            return Task.FromResult(PlaceTargetOrderCore(fill, route, target, cfg, dequeuedTicks, exitTwin, forceReseed));
        }

        private TargetResult PlaceTargetOrderCore(
            FillInfo        fill,
            CopierRoute     route,
            CopierTarget    target,
            AutomationConfig cfg,
            long            dequeuedTicks,
            MirroredTarget  exitTwin = null,
            bool            forceReseed = false)
        {
            // EXIT-SYNC (v1.8.0): the twin's terminal state (if any) is recorded
            // directly on `result.TwinState` below and surfaced in the aggregated
            // event payload (copy_executed/copy_failed) as "twin_state" — null
            // when this call is not part of an exit-sync job.
            // ================================================================
            // KNOWN RESIDUALS — verify in NT8 sim before live use (FIX F)
            // ================================================================
            //
            // 1. NT position-store timing for SourceNetAtFill (FIX A residual):
            //    SourceNetAtFill is captured inside the NT ExecutionUpdate callback
            //    at fill time, in the same Account.Positions read that computes
            //    IsOpening. Both fields share one lock block. HOWEVER: it is still
            //    an NT8 API timing assumption that Account.Positions has been updated
            //    by NT8 before it fires ExecutionUpdate. Verify in NT8 sim by checking
            //    that SourceNetAtFill matches the post-fill position shown in the
            //    Accounts window.
            //
            // 2. Dropped-last-fill / late-flat scenario:
            //    If the LAST fill in a sequence is dropped (worker queue full) and
            //    the source then goes flat with no further fills, the target can stay
            //    open indefinitely. The idempotency set consumes the ExecutionId, so
            //    only a subsequent fill on a NEW ExecutionId will trigger a reconcile
            //    that heals the divergence. If the source never trades again, the
            //    target remains open. Monitor for this in long-quiet sessions.
            //
            // 3. MaxContracts == 0 means "no cap":
            //    The clamp `if (target.MaxContracts > 0)` treats 0 as uncapped.
            //    A misconfigured MaxContracts=0 silently disables the cap, potentially
            //    allowing an unbounded position. Verify server-side that MaxContracts
            //    is always > 0 when a cap is intended.
            //
            // 4. Cross-mapped instrument FullName must exactly match NT's position FullName:
            //    TranslateInstrument produces e.g. "MNQ 09-26" from "NQ 09-26".
            //    GetPositions() uses pos.Instrument.FullName for matching. If NT8
            //    uses a different canonical form for the micro contract (e.g. "Micro
            //    E-mini NASDAQ-100 09-26"), the target-net seed will always read 0
            //    (flat) and the first-touch seed will be wrong. Verify by logging
            //    pos.Instrument.FullName from GetPositions() for the micro contract
            //    in NT8 sim.
            // ================================================================

            // The "display name" for this target in logs and the aggregated event:
            // prefer the server-config account name, fall back to the connection ID.
            string targetDisplayName = !string.IsNullOrWhiteSpace(target.DestinationAccountName)
                ? target.DestinationAccountName
                : target.DestinationConnectionId;

            var result = new TargetResult
            {
                DestinationAccountName = targetDisplayName,
                Quantity               = 0,
                Success                = false
            };

            try
            {
                // ================================================================
                // STEP 1 — Resolve target account → local NT account name
                // ================================================================
                //
                // Resolution order (mirrors ApplyConfig source resolution):
                //   1. target.DestinationAccountName → ResolveAccountByName()  (primary)
                //   2. target.DestinationConnectionId → FindConnection() +
                //                                       ResolveAccountName()   (fallback)
                string targetAccount = null;

                if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    targetAccount = _platform.ResolveAccountByName(target.DestinationAccountName);
                    if (targetAccount == null)
                    {
                        result.FailureReason =
                            $"destination account '{target.DestinationAccountName}' " +
                            "not found in local NT8 — account may not be connected";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
                {
                    // Fallback: older server response without account_name field.
                    BrokerConnection destConn = FindConnection(cfg, target.DestinationConnectionId);
                    if (destConn == null)
                    {
                        result.FailureReason =
                            $"destination connection '{target.DestinationConnectionId}' not in config";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                    targetAccount = _platform.ResolveAccountName(destConn);
                    if (targetAccount == null)
                    {
                        result.FailureReason =
                            $"no NT account found for connection '{target.DestinationConnectionId}' (fallback)";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                    _log($"Target '{targetDisplayName}': resolved via legacy connection-id " +
                         $"fallback → NT account '{targetAccount}'.");
                }
                else
                {
                    result.FailureReason =
                        "target has neither DestinationAccountName nor DestinationConnectionId " +
                        "(malformed target config)";
                    _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                    return result;
                }

                result.AccountName = targetAccount;

                // ================================================================
                // EXIT-SYNC (v1.8.0) — await the twin follower order terminal
                // ================================================================
                //
                // If this target had a mirrored working-order twin (exitTwin != null,
                // resolved by the caller against the removed MirroredOrder mapping),
                // block briefly until that twin has actually left a live state before
                // the reconcile math below reads/advances the target's net position.
                // Without this, a still-resting twin could independently fill a moment
                // later and double the follower's exposure relative to the leader.
                if (exitTwin != null)
                {
                    string twinState = _platform.AwaitOrderTerminal(targetAccount, exitTwin.FollowerOrderId, 1500);
                    if (string.Equals(twinState, "timeout", StringComparison.OrdinalIgnoreCase))
                    {
                        // One retry cancel — best-effort. If the twin is still resting
                        // after this, we proceed anyway (fail-open on the reconcile so
                        // the follower still converges toward the leader's true exit),
                        // but flag the elevated risk loudly.
                        _platform.CancelWorkingOrder(targetAccount, exitTwin.FollowerOrderId);
                        _log($"ExitSync ERROR [{targetAccount}]: twin follower order " +
                             $"'{exitTwin.FollowerOrderId}' did not reach a terminal state within 1500ms " +
                             "— issued a retry cancel. Residual double-fill risk until confirmed cancelled.");
                        twinState = _platform.AwaitOrderTerminal(targetAccount, exitTwin.FollowerOrderId, 1500);
                    }
                    result.TwinState = twinState;
                }

                // ================================================================
                // STEP 2 — Translate instrument (CrossToMicro)
                // ================================================================
                //
                // Compute the translated instrument name BEFORE reading the target
                // net — the tracker key and the NT position read both use the
                // TRANSLATED instrument (the one we actually hold on the target).
                string targetInstrumentName = TranslateInstrument(fill.InstrumentName, target);

                // ================================================================
                // STEP 3 — Read SOURCE net position (authoritative truth)
                // ================================================================
                //
                // FIX A: use fill.SourceNetAtFill — the signed net captured by the
                // NT adapter inside the ExecutionUpdate callback, in the same
                // Account.Positions lock block that computes IsOpening.  This avoids
                // the race where reading GetPositions(fill.AccountName) off-thread
                // (here in the consumer) could see a stale NT position store.
                //
                // DO NOT call GetPositions(fill.AccountName) here — the consumer
                // runs asynchronously from the fill callback and NT may not have
                // updated Account.Positions by the time this line executes.
                //
                // FIX A: source net captured in the NT execution callback (same
                // context as IsOpening) — NOT re-read off-thread. RESIDUAL: still
                // assumes NT has updated Account.Positions by the time
                // ExecutionUpdate fires for this fill; this is an NT-API timing
                // assumption that MUST be verified in NT8 sim.
                int sourceNet = fill.SourceNetAtFill;

                // ================================================================
                // STEP 4 — Compute desired target net
                // ================================================================
                //
                // FIX D: use MidpointRounding.AwayFromZero so that a source-net of
                // 1 with ScaleRatio = 0.5 produces desired = 1 (not 0 from banker's
                // rounding / ToEven).  Without this, a 50%-scaled single-contract
                // source would leave the target permanently flat.
                // A genuinely-zero product (sourceNet == 0 OR ratio == 0) still
                // yields 0 — that correct flat behavior is preserved.
                // NOTE: we do NOT apply Math.Max(1, ...) — a source-flat position
                // (sourceNet == 0) MUST produce desired = 0 (flat), not desired = 1.
                // That was a root cause of the systematic over-fill in FIX #9.
                int desired = (int)Math.Round(sourceNet * target.ScaleRatio,
                                              MidpointRounding.AwayFromZero);

                // Apply Reverse flag: flip the sign of the desired net.
                if (route.Reverse)
                    desired = -desired;

                // Clamp magnitude to MaxContracts (preserve sign). Null = no cap.
                if (target.MaxContracts.HasValue && target.MaxContracts.Value > 0)
                {
                    int cap = target.MaxContracts.Value;
                    if (desired > cap)
                        desired = cap;
                    else if (desired < -cap)
                        desired = -cap;
                }

                // ================================================================
                // STEP 5 — Tracker key + per-key lock
                // ================================================================

                string trackerKey = $"{targetAccount}|{targetInstrumentName}";
                object keyLock    = _netLocks.GetOrAdd(trackerKey, _ => new object());

                // ================================================================
                // STEP 6/7 — Seed (first touch) + compute delta + gate + order
                //            Gating and order logic run inside the per-key lock.
                //            Seeding uses double-checked locking (FIX C) so that
                //            GetPositions() is NOT called while holding the lock.
                // ================================================================
                //
                // Seeding: if this is the first time we touch this (target, instrument)
                // pair — e.g. on agent startup or after a config reload — read the ACTUAL
                // current NT position on the target account and use that as the starting
                // expected value.  This makes pre-existing positions and restarts safe.
                //
                // FIX C (double-checked locking): GetPositions(targetAccount) can
                // potentially stall if NT's position API is slow or its internal lock
                // is contended.  We must NOT hold keyLock across that call — if it
                // hangs, the entire per-(target, instrument) consumer stalls.
                // Instead: check ContainsKey outside the lock; read GetPositions outside
                // the lock; then re-check ContainsKey inside the lock before writing.
                // This eliminates the lock-acquisition-with-blocking-call pattern.
                //
                // IN-FLIGHT note: expected is advanced on submit success, not fill
                // confirmation.  On liquid futures, market orders fill ~instantly; if a
                // target order is slow, a rapid next reconcile could read a stale NT net
                // — but we reconcile against `expected` (submitted-intent), not raw NT
                // net, EXCEPT on this first-touch seeding.  Verify under rapid-fire fills.
                //
                // NOTE: untested in this environment — REQUIRES NT8 sim verification
                // on a non-funded account before any live use.
                //
                // All gating logic runs INSIDE the per-key lock so that concurrent
                // reconciles for the same (target, instrument) see a consistent view.
                // effectiveDelta is declared and used entirely within the lock block.

                // FIX C: read the seed value BEFORE acquiring the lock, so
                // GetPositions() is never called while keyLock is held.
                // If two threads race to seed the same key, the second thread's
                // ContainsKey re-check inside the lock will find the key already
                // set and skip the write — no double-seed, no stale overwrite.
                int seedValue = 0;
                // EXIT-SYNC (v1.8.0): forceReseed heals tracker drift caused by the
                // twin follower order's own (independent) fill — that fill moves the
                // ACTUAL NT position without ever passing through this engine's
                // _expectedTargetNet bookkeeping, so a stale `expected` value would
                // otherwise cause the reconcile below to either over- or under-shoot.
                // Re-reading the true NT position here, every time, on an exit-sync
                // job guarantees `expected` reflects reality before the delta math runs.
                bool needsSeed = !_expectedTargetNet.ContainsKey(trackerKey) || forceReseed;
                if (needsSeed)
                {
                    // Read actual NT position for this target account outside the lock.
                    seedValue = GetSignedNetPosition(
                        _platform.GetPositions(targetAccount), targetInstrumentName);
                }

                lock (keyLock)
                {
                    // ---- Seed on first touch (FIX C double-checked) OR forced reseed ----
                    if (!_expectedTargetNet.ContainsKey(trackerKey) || forceReseed)
                    {
                        // Another thread may have seeded between our outer check and
                        // acquiring the lock — re-read is safe/idempotent either way.
                        _expectedTargetNet[trackerKey] = seedValue;
                        _log($"NetReconcile SEED [{trackerKey}]: actual NT net = {seedValue}" +
                             (forceReseed ? " (forced reseed — exit-sync)." : "."));
                    }

                    int effectiveDelta;
                    int expected = _expectedTargetNet[trackerKey];
                    int rawDelta = desired - expected;

                    if (rawDelta == 0)
                    {
                        // Target is already where it should be — nothing to do.
                        _log($"NetReconcile [{trackerKey}]: desired={desired} == expected={expected} " +
                             "— no order needed.");
                        result.Success = true; // not a failure — just no action required
                        result.FailureReason = "no delta (already reconciled)";
                        return result;
                    }

                    // ---- CopyOpens / CopyCloses gating -------------------------
                    //
                    // FIX #9/#10: derived from magnitude change (NOT from fill.IsOpening).
                    //
                    // Definitions (relative to expected, which is our committed target net):
                    //   OPENING delta   = |desired| > |expected|  (exposure increasing)
                    //   CLOSING delta   = |desired| < |expected|  (exposure decreasing toward flat)
                    //
                    // Cross-zero case: desired and expected have opposite signs (both non-zero).
                    // This is a close-through-flat then re-open.  We handle it by computing
                    // an effectiveDesired that respects the gates:
                    //   1. If !CopyCloses → skip entirely (we cannot even reach flat).
                    //   2. If CopyCloses but !CopyOpens → effectiveDesired = 0 (reduce to flat only).
                    //   3. If both true → effectiveDesired = desired (full delta allowed).
                    // Then delta = effectiveDesired - expected.

                    int absExpected = Math.Abs(expected);
                    int absDesired  = Math.Abs(desired);
                    bool isOpeningDelta = absDesired > absExpected;
                    bool isClosingDelta = absDesired < absExpected;
                    bool crossesZero    = expected != 0 && desired != 0
                                         && Math.Sign(expected) != Math.Sign(desired);

                    int effectiveDesired;

                    if (crossesZero)
                    {
                        // Close-through-flat scenario.
                        if (!route.CopyCloses)
                        {
                            // Cannot close the existing leg → skip entirely.
                            // FIX B: was missing $ prefix; braces were logged literally.
                            _log($"NetReconcile [{trackerKey}]: cross-zero skipped — " +
                                 $"CopyCloses=false; expected={expected} desired={desired}.");
                            result.FailureReason = "cross-zero skipped: CopyCloses=false";
                            return result;
                        }
                        else if (!route.CopyOpens)
                        {
                            // Can close to flat but cannot re-open the new side.
                            effectiveDesired = 0;
                            // FIX B: was missing $ prefix; braces were logged literally.
                            _log($"NetReconcile [{trackerKey}]: cross-zero — closing to flat only " +
                                 $"(CopyOpens=false); expected={expected} desired={desired} " +
                                 "effectiveDesired=0.");
                        }
                        else
                        {
                            // Both gates open — full delta allowed.
                            effectiveDesired = desired;
                        }
                    }
                    else if (isOpeningDelta && !route.CopyOpens)
                    {
                        // Exposure is increasing but CopyOpens is disabled → skip.
                        _log($"NetReconcile [{trackerKey}]: opening delta skipped — " +
                             $"CopyOpens=false; expected={expected} desired={desired}.");
                        result.FailureReason = "opening delta skipped: CopyOpens=false";
                        return result;
                    }
                    else if (isClosingDelta && !route.CopyCloses)
                    {
                        // Exposure is decreasing but CopyCloses is disabled → skip.
                        _log($"NetReconcile [{trackerKey}]: closing delta skipped — " +
                             $"CopyCloses=false; expected={expected} desired={desired}.");
                        result.FailureReason = "closing delta skipped: CopyCloses=false";
                        return result;
                    }
                    else
                    {
                        // Both flags active or flags match the direction — full delta.
                        effectiveDesired = desired;
                    }

                    effectiveDelta = effectiveDesired - expected;

                    if (effectiveDelta == 0)
                    {
                        // After gating, nothing to send (e.g. cross-zero clamped to flat
                        // and expected was already 0).
                        _log($"NetReconcile [{trackerKey}]: effective delta = 0 after gating — " +
                             "no order needed.");
                        result.Success = true;
                        result.FailureReason = "no effective delta after gating";
                        return result;
                    }

                    // ================================================================
                    // STEP 8 — Pre-trade risk check
                    // ================================================================
                    //
                    // Preserve existing risk check — IsOrderAllowed checks max_contracts,
                    // daily_loss, max_trades_per_day, and tilt cooldown.
                    // If blocked → skip (do NOT update expected).
                    //
                    // IRON RULE (2026-07-02 incident): an order that REDUCES exposure
                    // (moves the signed net closer to flat, e.g. a closing copy of a
                    // leader flatten) must never be blocked by risk rules — this is the
                    // authoritative fill-time check, computed from the exact signed
                    // values (expected, effectiveDelta) this reconcile already derived.
                    bool reducesExposure = expected != 0
                        && Math.Abs(expected + effectiveDelta) <= Math.Abs(expected);

                    bool allowed = _risk.IsOrderAllowed(
                        targetAccount,
                        targetInstrumentName,
                        Math.Abs(effectiveDelta),
                        cfg.RiskRules,
                        cfg.Connections,
                        reducesExposure);

                    if (!allowed)
                    {
                        result.FailureReason = "blocked by risk rule";
                        _log($"NetReconcile [{trackerKey}]: order BLOCKED by risk rule. " +
                             "Expected NOT updated (next reconcile will retry).");
                        return result;
                    }

                    // ================================================================
                    // STEP 9 — Place order
                    // ================================================================

                    bool orderIsBuy = effectiveDelta > 0;
                    int  orderQty   = Math.Abs(effectiveDelta);

                    result.Quantity = orderQty;

                    _log($"NetReconcile [{trackerKey}]: placing {(orderIsBuy ? "BUY" : "SELL")} " +
                         $"{orderQty} {targetInstrumentName} on '{targetAccount}' " +
                         $"(sourceNet={sourceNet} desired={desired} expected={expected} " +
                         $"effectiveDelta={effectiveDelta})" +
                         (targetInstrumentName != fill.InstrumentName
                             ? $" (cross from '{fill.InstrumentName}')"
                             : string.Empty) + ".");

                    // Latency instrumentation: generate a unique 8-char token and embed it
                    // in the order name so we can correlate the follower fill back to this copy.
                    // submitStart/submitEnd straddle ONLY the PlaceMarketOrder call.
                    string copyToken   = Guid.NewGuid().ToString("N").Substring(0, 8);
                    string copyOrderNm = "FinotaurCopier|" + copyToken;
                    long   submitStart = Stopwatch.GetTimestamp();

                    // FIX E: PlaceMarketOrder NEVER throws — NinjaTraderAdapter wraps
                    // every code path in try/catch and returns false on any exception
                    // (see NinjaTraderAdapter.PlaceMarketOrder). No additional try/catch
                    // is needed here. _expectedTargetNet is advanced ONLY on a
                    // confirmed `true` return below, never on `false` or an exception
                    // (there can be no exception here, per the invariant above).
                    // If a future adapter implementation CAN throw, this method's outer
                    // try/catch (at the bottom of PlaceTargetOrderCore) will catch it,
                    // log it, and return a failure result — expected is NOT advanced
                    // because we will have returned before reaching STEP 10.
                    bool submitted = _platform.PlaceMarketOrder(
                        targetAccount,
                        targetInstrumentName,
                        orderIsBuy,
                        orderQty,
                        copyOrderNm);

                    long submitEnd = Stopwatch.GetTimestamp();

                    if (!submitted)
                    {
                        // PlaceMarketOrder failed: do NOT advance expected.
                        // SELF-HEALING: the next source fill will recompute sourceNet
                        // from NT truth and retry the outstanding delta automatically.
                        result.FailureReason = "PlaceMarketOrder returned false (see NT adapter log)";
                        _log($"NetReconcile [{trackerKey}]: PlaceMarketOrder FAILED — " +
                             "expected NOT updated; next reconcile will retry (self-healing).");
                        return result;
                    }

                    // ================================================================
                    // STEP 10 — Advance expected on successful submit
                    // ================================================================
                    //
                    // We advance expected by effectiveDelta (the amount we actually
                    // sent), NOT by (desired - expected) which could differ if gating
                    // clamped effectiveDesired.  This ensures expected always reflects
                    // what we have actually submitted.
                    //
                    // IN-FLIGHT note: expected is advanced on submit, not fill.
                    // On liquid futures this is fine; verify under rapid-fire fills.
                    _expectedTargetNet[trackerKey] = expected + effectiveDelta;

                    _log($"NetReconcile [{trackerKey}]: expected advanced " +
                         $"{expected} → {expected + effectiveDelta}.");

                    // ================================================================
                    // Latency instrumentation: register the pending timing record now
                    // that the order was successfully submitted. Fail-safe — any error
                    // here must NOT prevent STEP 11 or the success result from running.
                    // ================================================================
                    try
                    {
                        if (_pendingTimings.Count < MaxPendingTimings)
                        {
                            _pendingTimings[copyToken] = new CopyTiming
                            {
                                LeaderExecId         = fill.ExecutionId,
                                LeaderExecTime       = fill.Timestamp,
                                LeaderCapturedTicks  = fill.CapturedTicks,
                                DequeuedTicks        = dequeuedTicks,
                                SubmitStartTicks     = submitStart,
                                SubmitEndTicks       = submitEnd,
                                TargetAccount        = targetAccount,
                                Instrument           = targetInstrumentName,
                                Delta                = effectiveDelta,
                                RouteLabel           = route.Label,
                                RegisteredTicks      = submitEnd
                            };
                        }

                        // Age purge: drop any pending timing older than 60s
                        // (follower fill never arrived — e.g. order rejected).
                        long cutoff = Stopwatch.GetTimestamp() - (long)(Stopwatch.Frequency * 60);
                        foreach (var kv in _pendingTimings)
                        {
                            if (kv.Value.RegisteredTicks < cutoff)
                                _pendingTimings.TryRemove(kv.Key, out _);
                        }
                    }
                    catch (Exception ex)
                    {
                        _log($"Latency: pending-timing register failed (non-fatal): {ex.Message}");
                    }

                    // ================================================================
                    // STEP 11 — Update risk counters AFTER successful placement
                    // ================================================================
                    //
                    // Increment copier-opens counter only when the delta is OPENING
                    // (exposure increasing) — so max_trades_per_day counts entries,
                    // not reconciles to flat.
                    //
                    // FIX #6 (account-level risk): AccountName-first resolution,
                    // BrokerConnectionId fallback — same logic as RiskEnforcer.RunAsync.
                    // NOTE: untested in this environment — requires NT8 sim verification.
                    bool isOpeningOrder = Math.Abs(expected + effectiveDelta) > Math.Abs(expected);
                    if (isOpeningOrder)
                    {
                        IncrementOpensForMatchingRules(cfg, targetAccount);
                    }

                    result.Success = true;

                } // end lock(keyLock)

                return result;
            }
            catch (Exception ex)
            {
                result.FailureReason = $"{ex.GetType().Name}: {ex.Message}";
                _log($"PlaceTargetOrderCore exception for target " +
                     $"'{result.DestinationAccountName}': {ex.Message}");
                return result;
            }
        }

        // -----------------------------------------------------------------------
        // TicksToMs — latency math helper
        // -----------------------------------------------------------------------

        /// <summary>
        /// Converts a Stopwatch tick delta to milliseconds using the process-wide
        /// monotonic frequency. Inline helper for latency math — keeps all
        /// instrumentation paths consistent and avoids repetition.
        /// </summary>
        private static double TicksToMs(long ticks)
            => (ticks * 1000.0) / Stopwatch.Frequency;

        // -----------------------------------------------------------------------
        // IncrementOpensForMatchingRules — shared risk-counter helper
        // -----------------------------------------------------------------------

        /// <summary>
        /// RESILIENCE (v1.9.0): factored out of PlaceTargetOrderCore's STEP 11 (the
        /// rule-matching loop that calls RiskEnforcer.IncrementCopierOpens for every
        /// enforced/active risk rule whose resolved account matches
        /// <paramref name="accountName"/>). Pure refactor of that loop's BODY only —
        /// behavior for the original call site (successful market-copy placement) is
        /// unchanged; the isOpeningOrder gate remains at that call site.
        ///
        /// Also called from OnTargetFill (v1.9.0 FEATURE 2) so mirrored FILLS on a
        /// working-order-mirrored follower also count toward max_trades_per_day —
        /// previously only market-copy placements incremented this counter.
        ///
        /// Caller contract: MUST be invoked off the NT thread (IncrementCopierOpens
        /// does file I/O via RiskEnforcer.SaveState) — OnTargetFill wraps this in
        /// Task.Run for that reason; PlaceTargetOrderCore already runs on the
        /// order-consumer background task, not the NT thread.
        /// </summary>
        private void IncrementOpensForMatchingRules(AutomationConfig cfg, string accountName)
        {
            if (cfg == null || string.IsNullOrWhiteSpace(accountName)) return;

            foreach (var rule in cfg.RiskRules ?? new List<RiskRule>())
            {
                if (!rule.Enforce || !rule.IsActive) continue;

                string ruleAccount = null;
                if (!string.IsNullOrWhiteSpace(rule.AccountName))
                {
                    // Primary: resolve via broker account name.
                    ruleAccount = _platform.ResolveAccountByName(rule.AccountName);
                }
                else
                {
                    // Fallback: legacy broker_connection_id path.
                    BrokerConnection ruleConn = FindConnection(cfg, rule.BrokerConnectionId);
                    if (ruleConn != null)
                        ruleAccount = _platform.ResolveAccountName(ruleConn);
                }

                if (ruleAccount != null && string.Equals(ruleAccount, accountName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    _risk.IncrementCopierOpens(rule.Id, accountName);
                    // DIAG (v1.9.1): positive trace — pairs with the mirror-fill trace in
                    // OnTargetFill so a silent counting failure is localizable from logs.
                    _log($"IncrementOpensForMatchingRules: counted 1 copier open for rule " +
                         $"'{rule.Label}' on '{accountName}'.");
                }
            }
        }

        // -----------------------------------------------------------------------
        // OnTargetFill — follower-fill callback for latency resolution (t3)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Invoked when a fill arrives on a TARGET (follower) account.
        /// Matches the fill back to a pending CopyTiming via the order-name token,
        /// computes the 4-stage copy latency, and enqueues a 'copy_latency' event.
        ///
        /// FAIL-SAFE: this method must NEVER throw. It runs on the NT ExecutionUpdate
        /// thread; any exception here could disrupt order flow. All logic is wrapped
        /// in a top-level try/catch.
        /// </summary>
        private void OnTargetFill(FillInfo fill)
        {
            try
            {
                // ============================================================
                // RESILIENCE (v1.9.0) — count mirrored follower opens toward
                // max_trades_per_day. Runs FIRST, independent of (and additive
                // to) the latency-timing logic below — does not consume/return
                // early on the fill, so the latency path always still runs.
                // ============================================================
                try
                {
                    // DIAG (v1.9.1): trace every mirror-named fill through the counting
                    // gate — the success path was previously silent, which made the
                    // 2026-07-03 "count never ran" incident undebuggable from logs.
                    if (fill != null && fill.OrderName != null
                        && fill.OrderName.StartsWith("FinotaurCopier|", StringComparison.Ordinal))
                    {
                        _log($"OnTargetFill: mirror-named fill '{fill.OrderName}' acct='{fill.AccountName}' " +
                             $"isOpening={fill.IsOpening} orderId='{fill.OrderId}'.");
                    }
                    if (fill != null && fill.OrderName != null
                        && fill.OrderName.StartsWith("FinotaurCopier|ord|", StringComparison.Ordinal)
                        && fill.IsOpening)
                    {
                        string dedupKey = fill.OrderId + "|" + fill.AccountName;
                        if (TryMarkFollowerOpenCounted(dedupKey))
                        {
                            AutomationConfig cfgForCount = _cachedConfig;
                            string acctForCount = fill.AccountName;
                            Task.Run(() =>
                            {
                                try
                                {
                                    IncrementOpensForMatchingRules(cfgForCount, acctForCount);
                                }
                                catch (Exception ex)
                                {
                                    _log($"OnTargetFill: IncrementOpensForMatchingRules error (non-fatal): {ex.GetType().Name} — {ex.Message}");
                                }
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Must never disrupt the latency path below.
                    _log($"OnTargetFill: follower-open counting error (non-fatal): {ex.Message}");
                }

                // Only care about fills that carry our copy-order token.
                if (string.IsNullOrEmpty(fill.OrderName)) return;
                if (!fill.OrderName.StartsWith("FinotaurCopier|", StringComparison.Ordinal)) return;

                // Extract token: everything after the first '|'.
                int pipeIdx = fill.OrderName.IndexOf('|');
                if (pipeIdx < 0 || pipeIdx >= fill.OrderName.Length - 1) return;
                string token = fill.OrderName.Substring(pipeIdx + 1);

                // Remove the pending timing record (first follower fill wins; dedupes partials).
                CopyTiming t;
                if (!_pendingTimings.TryRemove(token, out t)) return;

                // Compute 4-stage latency using monotonic ticks.
                double queue_ms           = TicksToMs(t.DequeuedTicks   - t.LeaderCapturedTicks);
                double submit_ms          = TicksToMs(t.SubmitEndTicks   - t.SubmitStartTicks);
                double fill_ms            = TicksToMs(fill.CapturedTicks - t.SubmitEndTicks);
                double total_ms           = TicksToMs(fill.CapturedTicks - t.LeaderCapturedTicks);
                // Wall-clock delta between leader exec time and follower exec time (same NT8 clock).
                double broker_fill_lag_ms = (fill.Timestamp - t.LeaderExecTime).TotalMilliseconds;

                // NOTE: we emit under the already-allowed 'agent_status' event_type
                // (the edge fn VALID_EVENT_TYPES set + the automation_events CHECK
                // constraint reject unknown types). The payload 'kind' marker
                // identifies these as latency telemetry — query with
                //   event_type='agent_status' AND payload->>'kind'='copy_latency'.
                _eventQueue.Enqueue(new AutomationEvent
                {
                    EventType = "agent_status",
                    Severity  = "info",
                    Symbol    = fill.InstrumentName,
                    Payload   = new
                    {
                        kind                = "copy_latency",
                        leader_exec_id      = t.LeaderExecId,
                        route_label         = t.RouteLabel,
                        target_account      = t.TargetAccount,
                        instrument          = t.Instrument,
                        delta               = t.Delta,
                        queue_ms            = Math.Round(queue_ms,           2),
                        submit_ms           = Math.Round(submit_ms,          2),
                        fill_ms             = Math.Round(fill_ms,            2),
                        total_ms            = Math.Round(total_ms,           2),
                        broker_fill_lag_ms  = Math.Round(broker_fill_lag_ms, 2),
                        leader_exec_time    = t.LeaderExecTime.ToString("o"),
                        follower_exec_time  = fill.Timestamp.ToString("o")
                    }
                });

                _log($"CopyLatency [{token}] target='{t.TargetAccount}' " +
                     $"total={Math.Round(total_ms, 2)}ms broker_lag={Math.Round(broker_fill_lag_ms, 2)}ms.");
            }
            catch (Exception ex)
            {
                // Latency instrumentation must never disrupt order flow.
                _log($"OnTargetFill latency error (non-fatal): {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // OnFollowerOrderEvent — follower order-lifecycle callback (v1.9.0 RESILIENCE)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Invoked on every order-lifecycle event on a TARGET (follower) account,
        /// filtered by the adapter (OrderNameFilter.OnlyFinotaurMirrors) to ONLY
        /// our own mirrored follower orders ("FinotaurCopier|ord|*") — the user's
        /// own manual orders on target accounts never reach this callback.
        ///
        /// HOT PATH — runs on the NT OrderUpdate thread. Keep lean: only react to
        /// terminal states (rejected/cancelled); everything else returns
        /// immediately. Enqueues a job for the order-consumer task; issues ZERO
        /// adapter order commands itself (structurally loop-free).
        /// </summary>
        private void OnFollowerOrderEvent(OrderInfo order)
        {
            try
            {
                if (order == null) return;

                string state = (order.State ?? string.Empty).ToLowerInvariant();

                // Only terminal states matter here — everything else (working/
                // accepted/submitted/changesubmitted/partfilled/filled) is a no-op
                // on the follower side; filled followers are handled by the
                // existing fill-latency path (OnTargetFill), not here.
                if (state != "rejected" && state != "cancelled") return;

                AutomationConfig cfg = _cachedConfig;
                if (cfg == null) return;

                bool enqueued = _orderQueue.TryAdd(new OrderCopyJob
                {
                    SourceOrder     = order,
                    Route           = null,
                    Config          = cfg,
                    IsFollowerEvent = true
                });

                if (!enqueued)
                {
                    _log($"FOLLOWER ORDER HOT PATH: order queue full — dropping follower " +
                         $"order event '{order.OrderId}' (state '{state}') on '{order.AccountName}'.");
                }
            }
            catch (Exception ex)
            {
                // Order callbacks must NEVER throw — NT may crash the connection.
                _log($"OnFollowerOrderEvent exception for order '{order?.OrderId}': " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // GetSignedNetPosition — helper used by net reconciliation
        // -----------------------------------------------------------------------

        /// <summary>
        /// Converts the raw AgentPosition array for a given instrument to a signed
        /// net contract count:  positive = long,  negative = short,  0 = flat.
        ///
        /// Matching is case-insensitive on InstrumentName (e.g. "NQ 09-26").
        /// Returns 0 if no matching position is found (flat).
        ///
        /// FIX #9/#10 (net-position reconciliation): this is the central read used
        /// to determine both source truth and (on first-touch seeding) target current
        /// state.  It does NOT throw — a failed platform.GetPositions() call returns
        /// an empty array, which produces 0 (flat), the safe default.
        /// </summary>
        private static int GetSignedNetPosition(AgentPosition[] positions, string instrumentName)
        {
            if (positions == null || string.IsNullOrWhiteSpace(instrumentName))
                return 0;

            foreach (var pos in positions)
            {
                if (string.Equals(pos.InstrumentName, instrumentName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    // AgentPosition.Quantity is always >= 0; sign comes from IsLong.
                    return pos.IsLong ? pos.Quantity : -pos.Quantity;
                }
            }

            return 0; // no open position for this instrument = flat
        }

        /// <summary>
        /// Deterministic follower OCO group id, derived from the leader's OCO group
        /// id plus the destination account. Same (leaderOco, account) always maps to
        /// the same follower group id, so sibling legs mirrored by separate jobs
        /// (e.g. a bracket's stop + target, placed via independent ProcessOrderPlacement
        /// calls) join the SAME follower OCO group on that account. FNV-1a 64-bit hash,
        /// hex-encoded and prefixed "FIN" — 19 chars total, well under broker
        /// order-id/OCO-id length limits.
        /// </summary>
        private static string MakeFollowerOco(string leaderOco, string targetAccount)
        {
            ulong h = 14695981039346656037UL;
            foreach (char c in leaderOco + "|" + targetAccount)
            {
                h ^= c;
                h *= 1099511628211UL;
            }
            return "FIN" + h.ToString("x16");
        }

        // -----------------------------------------------------------------------
        // Idempotency helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Attempts to mark an ExecutionId as processed.
        /// Returns true if this is a NEW id (should process).
        /// Returns false if already seen (duplicate — skip).
        /// Evicts oldest entries when the set exceeds MaxProcessedIds.
        /// </summary>
        private bool TryMarkProcessed(string executionId)
        {
            if (string.IsNullOrWhiteSpace(executionId))
            {
                // Cannot track an empty ID — allow through but log (edge case)
                _log("TryMarkProcessed: fill has no ExecutionId — allowing through. " +
                     "VERIFY (NT8 API): check that ExecutionEventArgs.Execution.ExecutionId is populated.");
                return true;
            }

            // TryAdd returns true only if the key was newly inserted
            if (!_processedIds.TryAdd(executionId, 1))
            {
                // Already seen — duplicate fill (e.g. reconnect replay)
                _log($"Idempotency: duplicate fill '{executionId}' — skipping.");
                return false;
            }

            // Track order of insertion for eviction
            lock (_idEvictionLock)
            {
                _idEvictionQueue.Enqueue(executionId);

                // Evict oldest entries if over cap
                while (_idEvictionQueue.Count > MaxProcessedIds)
                {
                    string oldest = _idEvictionQueue.Dequeue();
                    _processedIds.TryRemove(oldest, out _);
                }
            }

            return true;
        }

        // -----------------------------------------------------------------------
        // Working-order mirroring — ever-mirrored idempotency helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Marks a leader OrderId as having been mirrored via the working-order
        /// path. Structured exactly like TryMarkProcessed's FIFO eviction above.
        /// Safe to call multiple times for the same id (idempotent — TryAdd
        /// simply returns false on repeat). STEP 5: the "was this new" signal
        /// IS now used — SaveCopierState() only runs on a genuine new add, so a
        /// repeat call does not re-serialize the whole set for no reason.
        /// </summary>
        private void MarkLeaderOrderMirrored(string leaderOrderId)
        {
            if (string.IsNullOrWhiteSpace(leaderOrderId)) return;

            if (_everMirroredOrderIds.TryAdd(leaderOrderId, 1))
            {
                lock (_everMirroredEvictionLock)
                {
                    _everMirroredEvictionQueue.Enqueue(leaderOrderId);

                    while (_everMirroredEvictionQueue.Count > MaxEverMirroredOrderIds)
                    {
                        string oldest = _everMirroredEvictionQueue.Dequeue();
                        _everMirroredOrderIds.TryRemove(oldest, out _);
                    }
                }

                // STEP 5 (copier-state persistence): persist on every genuine new
                // mirrored-order id so the fill-skip idempotency set survives an
                // agent restart. Best-effort — see SaveCopierState for I/O safety.
                SaveCopierState();
            }
        }

        /// <summary>
        /// Returns true if the given leader OrderId has ever been mirrored via
        /// the working-order path (subject to the bounded FIFO cap above).
        /// Consulted by the fill-copy hot path to avoid double-copying.
        /// </summary>
        private bool WasLeaderOrderMirrored(string leaderOrderId)
        {
            if (string.IsNullOrWhiteSpace(leaderOrderId)) return false;
            return _everMirroredOrderIds.ContainsKey(leaderOrderId);
        }

        /// <summary>
        /// RESILIENCE (v1.9.0): dedup gate for counting a mirrored follower open
        /// toward max_trades_per_day (see OnTargetFill). Structured exactly like
        /// MarkLeaderOrderMirrored's FIFO eviction above, keyed by
        /// "{fill.OrderId}|{fill.AccountName}" so the SAME follower fill is never
        /// counted twice (e.g. duplicate NT8 fill callbacks). No persistence —
        /// unlike _everMirroredOrderIds, an agent restart losing this in-memory
        /// set only risks a rare double-count, not a correctness issue for the
        /// copy path itself.
        /// </summary>
        /// <returns>true if this is the FIRST time this key was seen (caller should count it); false if already counted.</returns>
        private bool TryMarkFollowerOpenCounted(string dedupKey)
        {
            if (string.IsNullOrWhiteSpace(dedupKey)) return false;

            if (!_countedFollowerOpens.TryAdd(dedupKey, 1)) return false;

            lock (_countedFollowerOpensEvictionLock)
            {
                _countedFollowerOpensEvictionQueue.Enqueue(dedupKey);

                while (_countedFollowerOpensEvictionQueue.Count > MaxCountedFollowerOpens)
                {
                    string oldest = _countedFollowerOpensEvictionQueue.Dequeue();
                    _countedFollowerOpens.TryRemove(oldest, out _);
                }
            }

            return true;
        }

        /// <summary>
        /// STEP 5 (copier-state persistence): serializes _everMirroredOrderIds
        /// (oldest→newest, i.e. the eviction queue order) to disk.
        /// Best-effort: any I/O error is logged and swallowed — must not throw
        /// into the trading path. Mirrors RiskEnforcer.SaveState exactly.
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private void SaveCopierState()
        {
            if (_copierStatePath == null) return;

            try
            {
                var snap = new CopierStateSnapshot
                {
                    SavedAtUtc = DateTime.UtcNow.ToString("o")
                };

                lock (_everMirroredEvictionLock)
                {
                    snap.EverMirroredOrderIds.AddRange(_everMirroredEvictionQueue);
                }

                string json = JsonConvert.SerializeObject(snap, Formatting.Indented);
                string dir  = Path.GetDirectoryName(_copierStatePath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                File.WriteAllText(_copierStatePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                // Non-fatal — log and continue.
                _log($"CopierEngine.SaveCopierState: I/O error (non-fatal): " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        /// <summary>
        /// STEP 5 (copier-state persistence): loads previously persisted
        /// _everMirroredOrderIds from disk and rehydrates the in-memory set +
        /// eviction queue (via the existing MarkLeaderOrderMirrored-style
        /// TryAdd + enqueue + over-cap eviction, so the restored state respects
        /// the same bounded FIFO invariant as normal runtime operation).
        ///
        /// Freshness boundary: if the snapshot is older than 7 days, it is
        /// discarded entirely (deleted from disk) rather than restored — a
        /// week-old set of leader OrderIds has essentially zero chance of still
        /// being relevant (NT8 order ids are not stable across that horizon),
        /// so restoring it would only bloat memory for no protective value.
        ///
        /// Only restores the fill-skip idempotency set — modify/cancel tracking
        /// (_mirroredLeaderOrders) is NOT restored (v2); that mapping is cleared
        /// on every ApplyConfig rebuild by design (see ApplyConfig comments) and
        /// was never intended to survive a full agent restart either.
        ///
        /// Best-effort: any I/O or parse error is logged and swallowed.
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private void LoadCopierState()
        {
            if (_copierStatePath == null || !File.Exists(_copierStatePath)) return;

            try
            {
                string json = File.ReadAllText(_copierStatePath, Encoding.UTF8);
                var snap    = JsonConvert.DeserializeObject<CopierStateSnapshot>(json);
                if (snap == null) return;

                if (DateTime.TryParse(snap.SavedAtUtc, null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out DateTime savedAt))
                {
                    if (DateTime.UtcNow - savedAt > TimeSpan.FromDays(7))
                    {
                        _log("CopierEngine.LoadCopierState: persisted copier-state is older than " +
                             "7 days — discarding (deleting file) instead of restoring stale ids.");
                        try { File.Delete(_copierStatePath); } catch { /* best-effort */ }
                        return;
                    }
                }

                int restored = 0;
                foreach (var id in snap.EverMirroredOrderIds ?? new List<string>())
                {
                    if (string.IsNullOrWhiteSpace(id)) continue;

                    if (_everMirroredOrderIds.TryAdd(id, 1))
                    {
                        lock (_everMirroredEvictionLock)
                        {
                            _everMirroredEvictionQueue.Enqueue(id);

                            while (_everMirroredEvictionQueue.Count > MaxEverMirroredOrderIds)
                            {
                                string oldest = _everMirroredEvictionQueue.Dequeue();
                                _everMirroredOrderIds.TryRemove(oldest, out _);
                            }
                        }
                        restored++;
                    }
                }

                if (restored > 0)
                {
                    _log($"WARNING: Copier state restored: {restored} leader order ids for fill-skip; " +
                         "modify/cancel tracking NOT restored (v2).");
                }
            }
            catch (Exception ex)
            {
                _log($"CopierEngine.LoadCopierState: I/O or parse error (non-fatal): " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Activity summary (for PairingWindow status display)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns a brief human-readable summary of current copier state.
        /// Called by PairingWindow on UI refresh.
        /// </summary>
        public string GetActivitySummary()
        {
            int activeRoutes = _subscriptions.Count;
            int queueDepth   = _workerQueue.Count;
            int processedIds = _processedIds.Count;

            return $"Routes subscribed: {activeRoutes} | " +
                   $"Worker queue depth: {queueDepth} | " +
                   $"Processed fills (session): {processedIds}";
        }

        // -----------------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Finds a BrokerConnection by ID in the config. Returns null if not found.
        /// </summary>
        private static BrokerConnection FindConnection(AutomationConfig config, string connectionId)
        {
            if (config?.Connections == null || connectionId == null) return null;
            return config.Connections.Find(c =>
                string.Equals(c.Id, connectionId, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// FIX #6 (account-level risk): attempts to find a BrokerConnection whose
        /// AccountId matches the given broker account name string.
        /// Returns null if no match — used only for event payload enrichment when
        /// the rule is AccountName-bound (best-effort, same pattern as RiskEnforcer).
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private static BrokerConnection FindConnectionByAccountName(
            AutomationConfig config, string accountName)
        {
            if (config?.Connections == null || string.IsNullOrWhiteSpace(accountName)) return null;
            return config.Connections.Find(c =>
                string.Equals(c.AccountId, accountName, StringComparison.OrdinalIgnoreCase));
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        private bool _disposed;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            // Signal the consumer loop to stop and wait for it to exit.
            _cts.Cancel();
            _workerQueue.CompleteAdding();
            _orderQueue.CompleteAdding();

            try { _consumerTask?.Wait(TimeSpan.FromSeconds(3)); }
            catch { /* best-effort */ }

            try { _orderConsumerTask?.Wait(TimeSpan.FromSeconds(3)); }
            catch { /* best-effort */ }

            // Unsubscribe all source fill handlers
            foreach (var kvp in _subscriptions)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _subscriptions.Clear();

            // WORKING-ORDER MIRRORING: unsubscribe all source order handlers.
            foreach (var kvp in _orderSubscriptions)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _orderSubscriptions.Clear();

            // Latency instrumentation: unsubscribe target fill-latency handlers (best-effort).
            foreach (var kvp in _targetFillSubs)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _targetFillSubs.Clear();
            _pendingTimings.Clear();

            // RESILIENCE (v1.9.0): unsubscribe follower order-lifecycle handlers (best-effort).
            foreach (var kvp in _targetOrderSubs)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _targetOrderSubs.Clear();

            _cts.Dispose();
            _workerQueue.Dispose();
            _orderQueue.Dispose();

            _log("CopierEngine disposed.");
        }
    }
}
