// =============================================================================
// Finotaur Agent — FinotaurAgent.cs
//
// NinjaTrader 8 AddOn entry point.
// Derives from NinjaTrader.NinjaScript.AddOns.AddOnBase.
//
// ═══════════════════════════════════════════════════════════════════════════
// COMPLIANCE BOUNDARY (DO NOT REMOVE THIS COMMENT)
// ═══════════════════════════════════════════════════════════════════════════
//   • This AddOn places orders ONLY via the NinjaTrader 8 Cbi APIs
//     (NinjaTraderAdapter → IPlatformAdapter). It NEVER calls Tradovate,
//     NinjaTrader Cloud, or any broker REST/WS API.
//   • All trade copying is user-to-self only (same user's accounts).
//   • The agent ALWAYS heartbeats, even when master_enabled=false or
//     kill_switch is engaged. This lets the web see the agent is alive
//     while respecting the hard stop.
//   • FAIL-SAFE: on ANY network failure or config parse error, the
//     background loop logs and no-ops. It NEVER crashes NT8.
// ═══════════════════════════════════════════════════════════════════════════
//
// ARCHITECTURE:
//
//   NT8 UI thread
//     └─ AddOnBase.OnStateChange (SetDefaults / Active / Terminated)
//          └─ Creates background Task (_loopTask)
//
//   Background loop Task (dedicated, NOT the NT UI thread)
//     ├─ Every ~10–15 s: GetConfigAsync (with version), HeartbeatAsync
//     ├─ On full config (Unchanged==false): rebuild RiskEnforcer + CopierEngine
//     ├─ On unchanged config: apply master/kill flags only
//     ├─ Every ~5 s: RiskEnforcer.RunAsync (checks platform PnL/positions)
//     └─ Every ~5 s: FlushEventQueueAsync (drain telemetry → server in batches)
//
//   NT fill event thread (via NinjaTraderAdapter)
//     └─ Fires CopierEngine fill callback → enqueues CopyJob (hot path, no network)
//
//   CopierEngine consumer Task
//     └─ Dequeues CopyJob → fans out PlaceMarketOrder concurrently to all targets
//        → enqueues ONE aggregated AutomationEvent to _eventQueue
//
// THREADING SUMMARY:
//   _cachedConfig  — volatile reference; written by loop, read by hot path
//   _masterEnabled / _killEngaged — volatile bools for hot-path gate
//   _eventQueue    — ConcurrentQueue (lock-free; written by copier, drained by loop)
//   All other engine state — ConcurrentDictionary (thread-safe)
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Copier;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Pairing;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Storage;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Main Finotaur Agent AddOn. Derives from AddOnBase (NinjaTrader.NinjaScript.AddOns),
    /// auto-discovered by NT8 from the file path. Overrides OnStateChange and
    /// OnWindowCreated/OnWindowDestroyed for Control Center menu injection.
    /// </summary>
    public class FinotaurAgentAddOn : AddOnBase
    {
        // -----------------------------------------------------------------------
        // Constants
        // -----------------------------------------------------------------------

        private const string AgentVersion    = "1.11.0-bridge";
        private const string MenuItemLabel   = "Finotaur Agent…"; // "Finotaur Agent…"

        /// <summary>
        /// Gates temporary diagnostic output (diag_status events + file-logger append).
        /// Set env var FINOTAUR_DIAG=1 (or =true) to enable.
        /// Production default: off — no diag events emitted, no log file written.
        /// </summary>
        private static readonly bool DiagEnabled =
            string.Equals(Environment.GetEnvironmentVariable("FINOTAUR_DIAG"), "1",
                StringComparison.Ordinal) ||
            string.Equals(Environment.GetEnvironmentVariable("FINOTAUR_DIAG"), "true",
                StringComparison.OrdinalIgnoreCase);

        /// <summary>
        /// Normal poll interval. The background loop sleeps this long between cycles
        /// when everything is healthy.
        /// </summary>
        private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(5); // was 12 s; tightened for faster command delivery

        /// <summary>
        /// Risk enforcer check sub-interval within the poll cycle.
        /// Risk is checked every cycle; the enforcer debounces internally.
        /// </summary>
        private static readonly TimeSpan RiskCheckInterval = TimeSpan.FromSeconds(5);

        /// <summary>
        /// Maximum events to flush per batch. Prevents oversized HTTP payloads.
        /// </summary>
        private const int EventFlushBatchSize = 20;

        // -----------------------------------------------------------------------
        // Components (created in OnStateChange Active, disposed in Terminated)
        // -----------------------------------------------------------------------

        private FinotaurClient   _client;
        private IPlatformAdapter _platform;
        private RiskEnforcer     _risk;
        private CopierEngine     _copier;

        // Market-data WebSocket bridge (browser <-> NT8). Always created on
        // activation; Start()/Stop() are gated behind a persisted on/off toggle
        // (default ON) — see Bridge/BridgeServer.cs BridgeSettingsStore.
        private BridgeServer _bridge;

        // Shared event queue: copier enqueues, background loop flushes.
        // ConcurrentQueue is lock-free — safe from NT fill thread + loop task.
        private readonly ConcurrentQueue<AutomationEvent> _eventQueue =
            new ConcurrentQueue<AutomationEvent>();

        // -----------------------------------------------------------------------
        // Background loop
        // -----------------------------------------------------------------------

        private CancellationTokenSource _loopCts;
        private Task                    _loopTask;

        // -----------------------------------------------------------------------
        // Locally-cached config — hot-path reads this; only the loop writes it
        // -----------------------------------------------------------------------

        /// <summary>
        /// The most recent full config received from the server.
        /// Volatile: written by the background loop, read by the NT fill callback
        /// (hot path). Reads/writes of reference types are atomic on 64-bit CLR.
        /// </summary>
        private volatile AutomationConfig _cachedConfig;

        /// <summary>
        /// Last config version we sent to the server, so it can return a cheap
        /// "unchanged" response if nothing changed. The loop maintains this.
        /// </summary>
        private string _lastConfigVersion;

        /// <summary>
        /// Cached master_enabled flag — updated on EVERY config response (including
        /// Shape-A "unchanged") so the hot path can gate without reading the full config.
        /// </summary>
        private volatile bool _masterEnabled;

        /// <summary>
        /// Cached kill_switch_engaged — same rationale as _masterEnabled.
        /// </summary>
        private volatile bool _killEngaged;

        /// <summary>
        /// The set of account names that were locked in the PREVIOUS config response.
        /// Used to diff against the new locked_accounts list each poll cycle so we
        /// only call LockAccountManual/UnlockAccountManual on CHANGES, not every cycle.
        /// Written and read only from the background loop — no volatile needed.
        /// </summary>
        private HashSet<string> _lockedAccounts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // Observability (displayed in PairingWindow)
        // -----------------------------------------------------------------------

        private DateTime? _lastConfigAt;
        private bool      _lastHeartbeatOk;
        private DateTime? _lastHeartbeatAt;
        private string    _deviceName;

        // -----------------------------------------------------------------------
        // Pairing window (singleton, opened from menu item)
        // -----------------------------------------------------------------------

        private PairingWindow _pairingWindow;
        private readonly object _pairingWindowLock = new object();

        // -----------------------------------------------------------------------
        // OnStateChange — NT8 AddOn lifecycle
        // -----------------------------------------------------------------------

        /// <summary>
        /// NT8 AddOn lifecycle callback. Called by NT8 on load, activate, and unload.
        /// State property is accessed via the inherited State property on AddOnBase.
        /// SetDefaults: called when the AddOn is first loaded.
        /// Active: called when NT8 starts and the AddOn is enabled.
        /// Terminated: called when NT8 shuts down or the AddOn is disabled.
        /// </summary>
        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name        = "Finotaur Agent";
                    Description = "Finotaur local risk enforcement and trade copier agent.";
                    break;

                case State.Active:
                    OnAgentActivated();
                    break;

                case State.Terminated:
                    OnAgentTerminated();
                    break;
            }
        }

        // -----------------------------------------------------------------------
        // AddOn menu item — adds "Finotaur Agent…" to the Control Center Tools menu
        //
        // NT8 AddOns add Control Center menu items by overriding OnWindowCreated /
        // OnWindowDestroyed and inserting an NTMenuItem into the Tools menu.
        // ControlCenter and NTMenuItem are in NinjaTrader.Gui (imported above).
        // -----------------------------------------------------------------------

        private NTMenuItem existingMenuItemInControlCenter;
        private NTMenuItem agentMenuItem;

        protected override void OnWindowCreated(System.Windows.Window window)
        {
            ControlCenter cc = window as ControlCenter;
            if (cc == null) return;
            existingMenuItemInControlCenter = cc.FindFirst("ControlCenterMenuItemTools") as NTMenuItem;
            if (existingMenuItemInControlCenter == null) return;
            agentMenuItem = new NTMenuItem { Header = MenuItemLabel,
                Style = System.Windows.Application.Current.TryFindResource("MainMenuItem") as System.Windows.Style };
            existingMenuItemInControlCenter.Items.Add(agentMenuItem);
            agentMenuItem.Click += OnAgentMenuItemClick;
        }

        protected override void OnWindowDestroyed(System.Windows.Window window)
        {
            if (agentMenuItem != null && window is ControlCenter)
            {
                if (existingMenuItemInControlCenter != null && existingMenuItemInControlCenter.Items.Contains(agentMenuItem))
                    existingMenuItemInControlCenter.Items.Remove(agentMenuItem);
                agentMenuItem.Click -= OnAgentMenuItemClick;
                agentMenuItem = null;
            }
        }

        private void OnAgentMenuItemClick(object sender, System.Windows.RoutedEventArgs e) => OpenPairingWindow();

        // -----------------------------------------------------------------------
        // Activation
        // -----------------------------------------------------------------------

        private void OnAgentActivated()
        {
            try
            {
                _deviceName = System.Environment.MachineName;

                Log("Finotaur Agent activating…");

                // -- HTTP client --
                _client = new FinotaurClient();

                // -- Load stored credentials --
                if (TokenStore.Load(out string token, out _, out string storedDevice))
                {
                    _client.SetDeviceToken(token);
                    if (!string.IsNullOrWhiteSpace(storedDevice))
                        _deviceName = storedDevice;
                    Log($"Loaded credentials for device '{_deviceName}'.");
                }
                else
                {
                    Log("No stored credentials found. Open 'Finotaur Agent…' from Tools to pair.");
                }

                // -- Platform adapter --
                _platform = new NinjaTraderAdapter(logger: Log);

                // -- Risk enforcer --
                _risk = new RiskEnforcer(_platform, _client, logger: Log);

                // -- Copier engine (needs event queue) --
                _copier = new CopierEngine(_platform, _risk, _eventQueue, logger: Log);

                // -- Market-data bridge (browser <-> NT8) --
                // Always constructed; Start() only runs if the persisted toggle is ON
                // (default ON). The toggle can be flipped later from the PairingWindow.
                _bridge = new BridgeServer(AgentVersion, logger: Log);
                if (BridgeSettingsStore.LoadEnabled())
                {
                    if (_bridge.Start())
                        Log($"Market bridge listening on 127.0.0.1:{_bridge.BoundPort}.");
                    else
                        Log("Market bridge failed to start (no free port in range 24888-24892).");
                }
                else
                {
                    Log("Market bridge disabled by persisted setting.");
                }

                // -- Start background loop --
                _loopCts  = new CancellationTokenSource();
                _loopTask = Task.Run(() => BackgroundLoopAsync(_loopCts.Token));

                Log($"Finotaur Agent v{AgentVersion} active. Device: '{_deviceName}'.");
            }
            catch (Exception ex)
            {
                Log($"OnAgentActivated FATAL: {ex.GetType().Name} — {ex.Message}");
                // Do NOT re-throw — AddOn must not crash NT8 on activation.
            }
        }

        // -----------------------------------------------------------------------
        // Termination
        // -----------------------------------------------------------------------

        private void OnAgentTerminated()
        {
            try
            {
                Log("Finotaur Agent terminating…");

                // Signal loop to stop
                _loopCts?.Cancel();
                try { _loopTask?.Wait(TimeSpan.FromSeconds(5)); }
                catch { /* best-effort wait */ }

                // Close pairing window if open
                lock (_pairingWindowLock)
                {
                    try { _pairingWindow?.Close(); }
                    catch { }
                    _pairingWindow = null;
                }

                // Stop the market bridge before disposing the platform adapter it
                // reads NT8 data through — Stop() unhooks all NT8 event handlers.
                try { _bridge?.Stop(); }
                catch (Exception ex) { Log($"Bridge stop error: {ex.GetType().Name} — {ex.Message}"); }
                _bridge = null;

                // Dispose components in reverse creation order
                _copier?.Dispose();
                _platform?.Dispose();
                _client?.Dispose();

                _copier   = null;
                _platform = null;
                _client   = null;
                _risk     = null;

                Log("Finotaur Agent terminated.");
            }
            catch (Exception ex)
            {
                Log($"OnAgentTerminated error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Background loop — the heart of the agent
        // -----------------------------------------------------------------------

        /// <summary>
        /// Runs on a dedicated Task (NOT the NT UI thread).
        /// Owns the periodic config pull, heartbeat, risk checks, and event flush.
        ///
        /// Design principles:
        ///   - Every network call is wrapped in try/catch. A failure is a no-op.
        ///   - The loop NEVER crashes or exits due to an exception — it catches
        ///     and retries on the next cycle. NT8 must remain stable.
        ///   - master_enabled and kill_switch_engaged are applied as hard stops
        ///     EVERY cycle, including from cheap "unchanged" responses.
        /// </summary>
        private async Task BackgroundLoopAsync(CancellationToken ct)
        {
            Log("Background loop started.");

            // Stagger the first config pull by 2 s to let NT8 finish initializing.
            await Task.Delay(TimeSpan.FromSeconds(2), ct).ConfigureAwait(false);

            DateTime lastRiskCheck   = DateTime.MinValue;
            DateTime lastEventFlush  = DateTime.MinValue;
            // Telemetry cadence tracker — account snapshots and diagnostics run on a
            // slower sub-interval (~30 s) to keep DB write load low while the control-
            // plane poll runs at 5 s.
            DateTime lastTelemetryAt = DateTime.MinValue;

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    DateTime now = DateTime.UtcNow;

                    // Telemetry (account snapshots + diagnostics) runs on a slower cadence than
                    // the control-plane poll, to keep DB write load low. ~30s is plenty for
                    // dashboard freshness; the live copy path is event-driven and unaffected.
                    bool telemetryDue = (now - lastTelemetryAt >= TimeSpan.FromSeconds(30));
                    if (telemetryDue) lastTelemetryAt = now;

                    // ============================================================
                    // 1. CONFIG PULL (with version — cheap "unchanged" path)
                    // ============================================================

                    AutomationConfig configResponse = null;
                    if (_client.IsPaired)
                    {
                        try
                        {
                            configResponse = await _client
                                .GetConfigAsync(_lastConfigVersion, ct)
                                .ConfigureAwait(false);
                        }
                        catch (Exception ex)
                        {
                            // Network error — apply fail-safe: do nothing this cycle.
                            Log($"Config pull error: {ex.GetType().Name} — {ex.Message}. " +
                                "Will retry next cycle. Previous config remains active.");
                        }

                        if (configResponse != null)
                        {
                            // Always update the version token and safety flags,
                            // regardless of Unchanged shape.
                            if (!string.IsNullOrEmpty(configResponse.ConfigVersion))
                                _lastConfigVersion = configResponse.ConfigVersion;

                            // Apply master/kill flags from EVERY response (including Shape A).
                            // This is the safety guarantee: even if nothing else changed, the
                            // server can toggle the kill switch and the agent will see it.
                            _masterEnabled = configResponse.MasterEnabled;
                            _killEngaged   = configResponse.KillSwitchEngaged;

                            // Bridge secret: apply whenever the server sends a non-empty
                            // value (present in either Shape A or Shape B). Never clear an
                            // already-loaded secret just because this particular response
                            // omitted the field — see BridgeAuth.SetSecret doc comment.
                            if (!string.IsNullOrWhiteSpace(configResponse.BridgeSecret))
                                BridgeAuth.SetSecret(configResponse.BridgeSecret);

                            if (!configResponse.Unchanged)
                            {
                                // Shape B: full config — rebuild local state.
                                _cachedConfig = configResponse;
                                _lastConfigAt = DateTime.UtcNow;

                                // Rebuild copier subscriptions with the new config.
                                // CopierEngine.ApplyConfig is thread-safe.
                                try
                                {
                                    _copier?.ApplyConfig(configResponse);
                                }
                                catch (Exception ex)
                                {
                                    Log($"CopierEngine.ApplyConfig error: {ex.GetType().Name} — {ex.Message}");
                                }

                                int ruleCount  = configResponse.RiskRules?.Count(r => r.IsActive && r.Enforce) ?? 0;
                                int routeCount = configResponse.CopierRoutes?.Count(r => r.IsActive) ?? 0;

                                // Report how many journal accounts from the server config
                                // are matched to local NT accounts.  This helps diagnose
                                // "why isn't my route working?" without opening NT8 internals.
                                int accountsTotal   = configResponse.Accounts?.Count(a => a.IsActive) ?? 0;
                                int accountsMatched = 0;
                                if (accountsTotal > 0 && _platform != null)
                                {
                                    foreach (var acct in configResponse.Accounts)
                                    {
                                        if (!acct.IsActive) continue;
                                        if (!string.IsNullOrWhiteSpace(acct.AccountName)
                                            && _platform.ResolveAccountByName(acct.AccountName) != null)
                                        {
                                            accountsMatched++;
                                        }
                                    }
                                }

                                Log($"Config updated (v={_lastConfigVersion}): " +
                                    $"{ruleCount} enforced risk rules, {routeCount} active copier routes, " +
                                    $"{accountsMatched}/{accountsTotal} journal accounts matched locally. " +
                                    $"Master={_masterEnabled}, Kill={_killEngaged}.");
                            }
                            else
                            {
                                // Shape A: unchanged — master/kill applied above, no rebuild needed.
                                Log($"Config unchanged (v={_lastConfigVersion}). " +
                                    $"Master={_masterEnabled}, Kill={_killEngaged}.");
                            }

                            // Post kill_switch event if just engaged
                            if (_killEngaged)
                            {
                                _eventQueue.Enqueue(new AutomationEvent
                                {
                                    EventType = "kill_switch",
                                    Severity  = "critical",
                                    Payload   = new
                                    {
                                        message       = "Kill switch engaged from web dashboard. " +
                                                        "All risk enforcement and copying stopped.",
                                        config_version = _lastConfigVersion
                                    }
                                });
                            }

                            // --------------------------------------------------------
                            // WI-2: locked_accounts diff — apply manual lock/unlock
                            // changes from the server config.
                            //
                            // Always update _lockedAccounts so the set stays current,
                            // even when master/kill are off (so diffs are correct on
                            // re-enable). Only call the actual lock/unlock platform
                            // actions when the agent is active (master on + kill off).
                            // Present in both Shape A and Shape B — handled here so it
                            // fires every poll regardless of Unchanged state.
                            // --------------------------------------------------------
                            if (_risk != null)
                            {
                                var newLocked = new HashSet<string>(
                                    configResponse.LockedAccounts
                                    ?? new System.Collections.Generic.List<string>(),
                                    StringComparer.OrdinalIgnoreCase);

                                if (_masterEnabled && !_killEngaged)
                                {
                                    // Newly locked (in new, not in prev) → lock + guard.
                                    foreach (string acct in newLocked)
                                    {
                                        if (!_lockedAccounts.Contains(acct))
                                        {
                                            Log($"WI-2: account '{acct}' newly locked from web — applying LockAccountManual.");
                                            _risk.LockAccountManual(acct);
                                        }
                                    }

                                    // Newly unlocked (in prev, not in new) → remove lock.
                                    foreach (string acct in _lockedAccounts)
                                    {
                                        if (!newLocked.Contains(acct))
                                        {
                                            Log($"WI-2: account '{acct}' unlocked from web — applying UnlockAccountManual.");
                                            _risk.UnlockAccountManual(acct);
                                        }
                                    }
                                }

                                _lockedAccounts = newLocked;
                            }
                        }
                    }

                    // ============================================================
                    // 2. PENDING COMMANDS
                    //    Execute server-initiated commands (flatten, cancel, etc.).
                    //    These run REGARDLESS of master_enabled / kill_switch state —
                    //    flatten/cancel are safety actions that must always work.
                    // ============================================================

                    if (_client.IsPaired && configResponse != null)
                    {
                        var cmds = configResponse.PendingCommands;
                        if (cmds != null && cmds.Count > 0)
                        {
                            // Build the set of account names involved in the current routes:
                            // every route's SourceAccountName plus every target's
                            // DestinationAccountName (distinct, non-null/empty).
                            // This is the "copier universe" we flatten/cancel on.
                            var copierAccounts = new HashSet<string>(
                                StringComparer.OrdinalIgnoreCase);

                            // Use the CACHED full config's routes, NOT configResponse:
                            // a command is delivered in EVERY poll response, including
                            // cheap "unchanged" (Shape A) responses which carry NO routes.
                            // Reading from configResponse on a Shape-A cycle yielded an
                            // empty account universe → flatten_all silently flattened
                            // ZERO accounts. _cachedConfig always holds the last full config.
                            var routes = _cachedConfig?.CopierRoutes
                                         ?? new List<CopierRoute>();
                            foreach (var route in routes)
                            {
                                if (!string.IsNullOrWhiteSpace(route.SourceAccountName))
                                    copierAccounts.Add(route.SourceAccountName);

                                foreach (var target in route.Targets
                                         ?? new List<CopierTarget>())
                                {
                                    if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
                                        copierAccounts.Add(target.DestinationAccountName);
                                }
                            }

                            Log($"Processing {cmds.Count} pending command(s). " +
                                $"Copier account universe: {copierAccounts.Count} account(s).");

                            foreach (var cmd in cmds)
                            {
                                // Wrap each command so one failure never breaks the loop.
                                try
                                {
                                    bool   ok    = true;
                                    string errMsg = null;

                                    switch (cmd.CommandType?.ToLowerInvariant())
                                    {
                                        case "flatten_all":
                                            // Cancel working orders FIRST, THEN flatten positions.
                                            // ORDER MATTERS: FlattenAll now submits explicit market
                                            // orders to close positions; if we cancelled AFTER
                                            // flattening, CancelAllOrders would cancel those very
                                            // just-submitted closing orders before they fill (verified
                                            // in sim: FinotaurFlatten orders showed State=Cancelled).
                                            foreach (string acctName in copierAccounts)
                                            {
                                                bool cancelOk  = _platform.CancelAllOrders(acctName);
                                                bool flatOk    = _platform.FlattenAll(acctName);
                                                if (!flatOk || !cancelOk)
                                                {
                                                    ok = false;
                                                    string detail =
                                                        $"account '{acctName}': " +
                                                        $"flatten={flatOk}, cancel={cancelOk}";
                                                    errMsg = errMsg == null
                                                        ? detail
                                                        : errMsg + "; " + detail;
                                                }
                                            }
                                            Log($"Command flatten_all ({cmd.Id}): " +
                                                (ok ? "OK" : $"partial failure — {errMsg}"));
                                            break;

                                        case "cancel_orders":
                                            // Cancel all working orders on every account.
                                            foreach (string acctName in copierAccounts)
                                            {
                                                bool cancelOk = _platform.CancelAllOrders(acctName);
                                                if (!cancelOk)
                                                {
                                                    ok = false;
                                                    string detail = $"account '{acctName}': cancel=false";
                                                    errMsg = errMsg == null
                                                        ? detail
                                                        : errMsg + "; " + detail;
                                                }
                                            }
                                            Log($"Command cancel_orders ({cmd.Id}): " +
                                                (ok ? "OK" : $"partial failure — {errMsg}"));
                                            break;

                                        case "flatten_symbol":
                                            // Flatten positions for the given symbol on every account.
                                            if (string.IsNullOrWhiteSpace(cmd.Symbol))
                                            {
                                                ok     = false;
                                                errMsg = "flatten_symbol command missing symbol";
                                                Log($"Command flatten_symbol ({cmd.Id}): FAILED — {errMsg}");
                                            }
                                            else
                                            {
                                                foreach (string acctName in copierAccounts)
                                                {
                                                    bool flatOk = _platform.FlattenSymbol(acctName, cmd.Symbol);
                                                    if (!flatOk)
                                                    {
                                                        ok = false;
                                                        string detail =
                                                            $"account '{acctName}': flatten_symbol=false";
                                                        errMsg = errMsg == null
                                                            ? detail
                                                            : errMsg + "; " + detail;
                                                    }
                                                }
                                                Log($"Command flatten_symbol '{cmd.Symbol}' ({cmd.Id}): " +
                                                    (ok ? "OK" : $"partial failure — {errMsg}"));
                                            }
                                            break;

                                        default:
                                            ok     = false;
                                            errMsg = $"unknown command_type '{cmd.CommandType}'";
                                            Log($"Command ({cmd.Id}): FAILED — {errMsg}");
                                            break;
                                    }

                                    // Report result back to the server.
                                    string reportStatus = ok ? "executed" : "failed";
                                    try
                                    {
                                        await _client
                                            .ReportCommandResultAsync(
                                                cmd.Id,
                                                reportStatus,
                                                errMsg,
                                                ct)
                                            .ConfigureAwait(false);
                                    }
                                    catch (Exception reportEx)
                                    {
                                        Log($"ReportCommandResultAsync error for command " +
                                            $"'{cmd.Id}': {reportEx.GetType().Name} — {reportEx.Message}");
                                    }
                                }
                                catch (Exception cmdEx)
                                {
                                    // One command failure must never break the loop or other commands.
                                    Log($"Command '{cmd.Id}' ({cmd.CommandType}) unhandled error: " +
                                        $"{cmdEx.GetType().Name} — {cmdEx.Message}. Reporting as failed.");
                                    try
                                    {
                                        await _client
                                            .ReportCommandResultAsync(
                                                cmd.Id,
                                                "failed",
                                                $"{cmdEx.GetType().Name}: {cmdEx.Message}",
                                                ct)
                                            .ConfigureAwait(false);
                                    }
                                    catch { /* report failure is best-effort */ }
                                }
                            }
                        }
                    }

                    // ============================================================
                    // 3. HEARTBEAT (every cycle, regardless of master/kill state)
                    //    The web must always see the agent is alive, even when stopped.
                    // ============================================================

                    if (_client.IsPaired)
                    {
                        string heartbeatStatus = _killEngaged ? "kill_switch"
                                               : !_masterEnabled ? "disabled"
                                               : "online";
                        try
                        {
                            bool hbOk = await _client
                                .HeartbeatAsync(
                                    heartbeatStatus,
                                    AgentVersion,
                                    (_bridge != null && _bridge.IsRunning) ? (int?)_bridge.BoundPort : null,
                                    _bridge?.AuthedClientCount ?? 0,
                                    ct)
                                .ConfigureAwait(false);

                            _lastHeartbeatOk = hbOk;
                            _lastHeartbeatAt = DateTime.UtcNow;
                        }
                        catch (Exception ex)
                        {
                            _lastHeartbeatOk = false;
                            _lastHeartbeatAt = DateTime.UtcNow;
                            Log($"Heartbeat error: {ex.GetType().Name} — {ex.Message}");
                        }
                    }

                    // ============================================================
                    // 3b. ACCOUNT SNAPSHOT TELEMETRY
                    //     Every cycle, gather balance/PnL/positions for every
                    //     NT8 account the agent can see and POST to the server.
                    //     This is a soft telemetry channel — any failure is logged
                    //     and silently skipped; it NEVER breaks the heartbeat or
                    //     risk loop.
                    // ============================================================

                    if (telemetryDue && _client.IsPaired && _platform != null)
                    {
                        try
                        {
                            string[] accountNames = _platform.GetAccountNames();

                            if (accountNames != null && accountNames.Length > 0)
                            {
                                var snapshots = new List<AccountSnapshot>(accountNames.Length);

                                foreach (string acctName in accountNames)
                                {
                                    // Resolve env from the cached config accounts list.
                                    // If not found there, send null — server accepts null.
                                    string env = null;
                                    AutomationConfig cfg = _cachedConfig;
                                    if (cfg?.Accounts != null)
                                    {
                                        foreach (var cfgAcct in cfg.Accounts)
                                        {
                                            if (string.Equals(cfgAcct.AccountName, acctName,
                                                    StringComparison.OrdinalIgnoreCase))
                                            {
                                                // Normalise to "live" | "demo" as the server expects.
                                                // AutomationAccount.Environment is "live" | "demo" | "sim".
                                                // Map "sim" → "demo" for the snapshot contract.
                                                string raw = cfgAcct.Environment;
                                                if (string.Equals(raw, "live", StringComparison.OrdinalIgnoreCase))
                                                    env = "live";
                                                else if (!string.IsNullOrWhiteSpace(raw))
                                                    env = "demo";
                                                break;
                                            }
                                        }
                                    }

                                    double?         balance   = _platform.GetCashBalance(acctName);
                                    double          dayPnl    = _platform.GetSessionRealizedPnL(acctName);
                                    double          openPnl   = _platform.GetOpenPnL(acctName);
                                    AgentPosition[] positions = _platform.GetPositions(acctName);

                                    var posSnapshots = new List<PositionSnapshot>(positions.Length);
                                    foreach (AgentPosition pos in positions)
                                    {
                                        posSnapshots.Add(new PositionSnapshot
                                        {
                                            Symbol   = pos.InstrumentName,
                                            Qty      = pos.Quantity,
                                            IsLong   = pos.IsLong,
                                            AvgPrice = pos.AveragePrice,
                                            OpenPnl  = pos.UnrealizedPnL
                                        });
                                    }

                                    snapshots.Add(new AccountSnapshot
                                    {
                                        AccountName = acctName,
                                        Env         = env,
                                        Balance     = balance,
                                        DayPnl      = dayPnl,
                                        OpenPnl     = openPnl,
                                        Positions   = posSnapshots
                                    });
                                }

                                await _client
                                    .SendAccountSnapshotAsync(snapshots, ct)
                                    .ConfigureAwait(false);
                            }
                        }
                        catch (Exception ex)
                        {
                            // Soft failure — telemetry MUST NOT impact the risk/heartbeat loop.
                            Log($"AccountSnapshot error: {ex.GetType().Name} — {ex.Message}");
                        }
                    }

                    // ============================================================
                    // 4. RISK ENFORCEMENT
                    //    Only runs when master is enabled and kill is NOT engaged.
                    //    Sub-interval: checked every RiskCheckInterval (5 s).
                    // ============================================================

                    if (_masterEnabled && !_killEngaged && _cachedConfig != null)
                    {
                        if (DateTime.UtcNow - lastRiskCheck >= RiskCheckInterval)
                        {
                            lastRiskCheck = DateTime.UtcNow;
                            try
                            {
                                await _risk.RunAsync(_cachedConfig, ct).ConfigureAwait(false);
                            }
                            catch (Exception ex)
                            {
                                Log($"RiskEnforcer.RunAsync error: {ex.GetType().Name} — {ex.Message}");
                            }
                        }
                    }

                    // ============================================================
                    // DIAGNOSTIC (temporary): emit copier subscription state to the
                    // DB event channel. File/Output logging is unreliable in this
                    // environment (OneDrive locks), so this is how we observe whether
                    // routes are actually subscribed. Throttled to the telemetry cadence
                    // (~30 s) so it does not write to the DB on every 5-s poll cycle.
                    // WI-5: gated behind DiagEnabled (set FINOTAUR_DIAG=1 to enable).
                    // ============================================================
                    if (telemetryDue && DiagEnabled)
                    {
                        try
                        {
                            _eventQueue.Enqueue(new AutomationEvent
                            {
                                EventType = "agent_status",
                                Severity  = "info",
                                Payload   = new
                                {
                                    kind          = "diag_status",
                                    cfg_version   = _lastConfigVersion,
                                    routes_in_cfg = _cachedConfig?.CopierRoutes?.Count ?? -1,
                                    copier        = _copier != null ? _copier.GetActivitySummary() : "(null)",
                                    master        = _masterEnabled,
                                    kill          = _killEngaged
                                }
                            });
                        }
                        catch { /* diagnostic must never break the loop */ }
                    }

                    // ============================================================
                    // 5. EVENT QUEUE FLUSH (async batched telemetry)
                    //    Drain the _eventQueue and post to server in batches.
                    //    The copy hot path never waits for this.
                    // ============================================================

                    if (_client.IsPaired && !_eventQueue.IsEmpty)
                    {
                        if (DateTime.UtcNow - lastEventFlush >= TimeSpan.FromSeconds(3))
                        {
                            lastEventFlush = DateTime.UtcNow;
                            await FlushEventQueueAsync(ct).ConfigureAwait(false);
                        }
                    }

                    // ============================================================
                    // 6. UPDATE PAIRING WINDOW STATUS (if open)
                    // ============================================================

                    PairingWindow window;
                    lock (_pairingWindowLock)
                        window = _pairingWindow;

                    if (window != null)
                    {
                        var snapshot = BuildStatusSnapshot();
                        try { window.UpdateStatus(snapshot); }
                        catch { /* window may be closing — ignore */ }
                    }

                    // ============================================================
                    // 7. WAIT FOR NEXT POLL CYCLE
                    // ============================================================

                    await Task.Delay(PollInterval, ct).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown — break the loop
                    break;
                }
                catch (Exception ex)
                {
                    // Unexpected error — log and continue. The loop MUST NOT exit.
                    Log($"BackgroundLoop unhandled error: {ex.GetType().Name} — {ex.Message}. " +
                        "Continuing on next cycle.");

                    // Brief pause before retry to avoid tight error loops
                    try { await Task.Delay(TimeSpan.FromSeconds(5), ct).ConfigureAwait(false); }
                    catch { break; }
                }
            }

            Log("Background loop exited.");
        }

        // -----------------------------------------------------------------------
        // Event queue flush — async batched telemetry
        // -----------------------------------------------------------------------

        /// <summary>
        /// Drains up to EventFlushBatchSize events from the queue and posts them
        /// to the server one by one (or in future: as a batch endpoint if added).
        ///
        /// This runs off the NT thread and never blocks the copy hot path.
        /// Failures are swallowed — unsent events are lost (telemetry is
        /// best-effort; it must never impact order execution).
        /// </summary>
        private async Task FlushEventQueueAsync(CancellationToken ct)
        {
            int flushed = 0;

            // Drain up to BatchSize events per flush cycle
            while (flushed < EventFlushBatchSize && _eventQueue.TryDequeue(out AutomationEvent evt))
            {
                try
                {
                    await _client.PostEventAsync(evt, ct).ConfigureAwait(false);
                    flushed++;
                }
                catch (Exception ex)
                {
                    // Swallow — telemetry is best-effort. The event is lost.
                    Log($"FlushEventQueue: failed to post '{evt.EventType}': {ex.Message}");
                    // Do NOT re-enqueue — could cause infinite retry loop.
                }
            }

            if (flushed > 0)
                Log($"Flushed {flushed} event(s) to server.");
        }

        // -----------------------------------------------------------------------
        // Pairing window management
        // -----------------------------------------------------------------------

        /// <summary>
        /// Opens or activates the PairingWindow.
        /// Called from the Control Center menu item on the UI thread.
        /// </summary>
        private void OpenPairingWindow()
        {
            // NT8 menu item Click is invoked on the WPF UI thread — _pairingWindow
            // is safe to access here without a Dispatcher.InvokeAsync wrapper.
            lock (_pairingWindowLock)
            {
                if (_pairingWindow != null && _pairingWindow.IsVisible)
                {
                    // Bring existing window to front
                    try
                    {
                        _pairingWindow.Activate();
                        _pairingWindow.Focus();
                    }
                    catch { /* best-effort */ }
                    return;
                }

                // Create a new window
                try
                {
                    _pairingWindow = new PairingWindow(
                        client:       _client,
                        copier:       _copier,
                        bridge:       _bridge,
                        deviceName:   _deviceName,
                        agentVersion: AgentVersion,
                        logger:       Log);

                    // Clean up reference when window is closed
                    _pairingWindow.Closed += (s, e) =>
                    {
                        lock (_pairingWindowLock)
                            _pairingWindow = null;
                    };

                    _pairingWindow.Show();
                }
                catch (Exception ex)
                {
                    Log($"OpenPairingWindow error: {ex.GetType().Name} — {ex.Message}");
                    _pairingWindow = null;
                }
            }
        }

        // -----------------------------------------------------------------------
        // Status snapshot (feeds PairingWindow)
        // -----------------------------------------------------------------------

        private AgentStatusSnapshot BuildStatusSnapshot()
        {
            AutomationConfig cfg = _cachedConfig;

            int activeRules  = cfg?.RiskRules?.Count(r => r.IsActive && r.Enforce) ?? 0;
            int activeRoutes = cfg?.CopierRoutes?.Count(r => r.IsActive) ?? 0;

            // Count how many journal accounts from the server config are matched
            // to local NT accounts (same logic as the config-update log message).
            int accountsTotal   = cfg?.Accounts?.Count(a => a.IsActive) ?? 0;
            int accountsMatched = 0;
            if (accountsTotal > 0 && _platform != null && cfg?.Accounts != null)
            {
                foreach (var acct in cfg.Accounts)
                {
                    if (!acct.IsActive) continue;
                    if (!string.IsNullOrWhiteSpace(acct.AccountName)
                        && _platform.ResolveAccountByName(acct.AccountName) != null)
                    {
                        accountsMatched++;
                    }
                }
            }

            string activity = _copier?.GetActivitySummary() ?? "Copier not initialized.";

            // Bottom status line
            string status;
            if (!_client.IsPaired)
                status = "Not paired — open 'Finotaur Agent…' to pair.";
            else if (_killEngaged)
                status = "KILL SWITCH ENGAGED — all operations stopped.";
            else if (!_masterEnabled)
                status = "Master disabled — agent idle (still heartbeating).";
            else
                status = $"Active — master ON, {activeRules} rules, {activeRoutes} routes, " +
                         $"{accountsMatched}/{accountsTotal} accounts matched.";

            bool bridgeRunning = _bridge != null && _bridge.IsRunning;

            return new AgentStatusSnapshot
            {
                DeviceName        = _deviceName,
                LastConfigAt      = _lastConfigAt,
                ConfigVersion     = _lastConfigVersion,
                MasterEnabled     = _masterEnabled,
                KillSwitchEngaged = _killEngaged,
                ActiveRuleCount   = activeRules,
                ActiveRouteCount  = activeRoutes,
                LastHeartbeatOk   = _lastHeartbeatOk,
                LastHeartbeatAt   = _lastHeartbeatAt,
                ActivitySummary   = activity,
                BottomStatusLine  = status,
                BridgeRunning     = bridgeRunning,
                BridgePort        = bridgeRunning ? (int?)_bridge.BoundPort : null,
                BridgeClientCount = _bridge?.AuthedClientCount ?? 0
            };
        }

        // -----------------------------------------------------------------------
        // Logging
        // -----------------------------------------------------------------------

        /// <summary>
        /// Central log method. All components are wired to this delegate.
        /// Writes to the NT8 Output window (OutputTab1) via the official
        /// NinjaTrader.Code.Output.Process API. PrintTo is in NinjaTrader.NinjaScript.
        /// </summary>
        private static readonly object _logFileLock = new object();

        private static void Log(string message)
        {
            string line = $"[FinotaurAgent] {message}";
            try
            {
                NinjaTrader.Code.Output.Process(line, NinjaTrader.NinjaScript.PrintTo.OutputTab1);
            }
            catch { /* logging must never throw */ }
            // DIAGNOSTIC: Output.Process is unreliable from background threads, so
            // also append every log line to a file we can read straight off disk.
            // WI-5: file-append is gated behind DiagEnabled (set FINOTAUR_DIAG=1 to enable).
            // Path: %TEMP%/finotaur-agent.log
            if (DiagEnabled)
            {
                try
                {
                    // Write to the LOCAL temp dir (NOT UserDataDir, which is under
                    // OneDrive and locks the file during sync → silently dropped lines).
                    string path = System.IO.Path.Combine(
                        System.IO.Path.GetTempPath(), "finotaur-agent.log");
                    lock (_logFileLock)
                    {
                        System.IO.File.AppendAllText(path,
                            DateTime.UtcNow.ToString("o") + " " + line + System.Environment.NewLine);
                    }
                }
                catch { /* diagnostic logging must never throw */ }
            }
        }
    }
}
