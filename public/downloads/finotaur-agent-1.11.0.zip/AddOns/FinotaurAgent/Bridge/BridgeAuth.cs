// =============================================================================
// Finotaur Agent — Bridge/BridgeAuth.cs
//
// Holds the current bridge secret: a shared token the browser must present
// in the hello{token} message to authenticate a WebSocket bridge connection.
// Populated by FinotaurAgent's background loop from the SAME config-poll
// response used for everything else (AutomationConfig.BridgeSecret) — see
// Api/Models.cs and FinotaurAgent.cs.
//
// SECURITY NOTE: the secret is compared with a constant-time comparison to
// avoid timing side-channels. It is never logged.
// =============================================================================

using System;
using System.Text;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge
{
    /// <summary>
    /// Thread-safe holder for the current bridge auth secret. Read by
    /// BridgeSession on every hello{} message; written by FinotaurAgent's
    /// background loop whenever a config response carries a bridge_secret.
    /// </summary>
    public static class BridgeAuth
    {
        private static volatile string _currentSecret;

        /// <summary>True if a non-empty secret is currently loaded.</summary>
        public static bool HasSecret => !string.IsNullOrWhiteSpace(_currentSecret);

        /// <summary>
        /// Updates the current secret. Passing null/empty clears it (all hello
        /// attempts are rejected until a new secret arrives from the server).
        /// Never logs the value.
        /// </summary>
        public static void SetSecret(string secret)
        {
            _currentSecret = string.IsNullOrWhiteSpace(secret) ? null : secret;
        }

        /// <summary>
        /// Constant-time validation of a candidate token against the current
        /// secret. Returns false (never throws) if no secret is loaded yet or
        /// the candidate is null/empty.
        /// </summary>
        public static bool Validate(string candidateToken)
        {
            string secret = _currentSecret; // single volatile read (snapshot)
            if (string.IsNullOrEmpty(secret) || string.IsNullOrEmpty(candidateToken))
                return false;

            return ConstantTimeEquals(secret, candidateToken);
        }

        /// <summary>
        /// Byte-wise constant-time string comparison. Always walks the FULL
        /// length of the longer input (never short-circuits on first mismatch
        /// or on a length difference) so comparison time does not leak how many
        /// leading characters matched.
        /// </summary>
        private static bool ConstantTimeEquals(string a, string b)
        {
            byte[] bytesA = Encoding.UTF8.GetBytes(a);
            byte[] bytesB = Encoding.UTF8.GetBytes(b);

            int diff   = bytesA.Length ^ bytesB.Length;
            int maxLen = Math.Max(bytesA.Length, bytesB.Length);

            for (int i = 0; i < maxLen; i++)
            {
                byte ba = i < bytesA.Length ? bytesA[i] : (byte)0;
                byte bb = i < bytesB.Length ? bytesB[i] : (byte)0;
                diff |= ba ^ bb;
            }

            return diff == 0;
        }
    }
}
