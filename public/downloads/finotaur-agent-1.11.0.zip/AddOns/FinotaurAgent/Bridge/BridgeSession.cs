// =============================================================================
// Finotaur Agent — Bridge/BridgeSession.cs
//
// Per-connection protocol state machine for the market-data bridge.
// AwaitingHello (5s timeout, enforced by BridgeServer's housekeeping loop
// via HelloDeadlineUtc) -> Authed. Owns JSON message parsing/dispatch and
// the client's subscription bookkeeping (for clean Detach-all on disconnect).
//
// THREADING: HandleMessage is called by BridgeServer's reader loop for THIS
// connection only (single-threaded per session for inbound messages).
// SendJson may be called concurrently from MarketHub's flush timers (other
// threads) — it only touches the injected sendText delegate (thread-safe,
// backed by BridgeServer's per-client outbound queue) and the logger.
// =============================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge
{
    public sealed class BridgeSession
    {
        private enum SessionState { AwaitingHello, Authed }

        private readonly MarketHub _hub;
        private readonly Action<string> _sendText;
        private readonly Action<ushort, string> _requestClose;
        private readonly Func<bool> _tryRegisterAuthed;
        private readonly Action _unregisterAuthed;
        private readonly string _agentVersion;
        private readonly Action<string> _log;

        private volatile SessionState _state = SessionState.AwaitingHello;
        private readonly object _subLock = new object();
        private readonly HashSet<string> _subscribedSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private int _backfillInFlight; // 0 = idle, 1 = in progress (Interlocked-guarded)

        public Guid Id { get; } = Guid.NewGuid();

        /// <summary>Deadline for receiving hello{}. Checked by BridgeServer's housekeeping loop.</summary>
        public DateTime HelloDeadlineUtc { get; }

        public bool IsAuthed => _state == SessionState.Authed;

        /// <param name="hub">Shared MarketHub instance.</param>
        /// <param name="sendText">Enqueues a text frame to this client (thread-safe).</param>
        /// <param name="requestClose">Requests a graceful close with a WS close code + reason.</param>
        /// <param name="tryRegisterAuthed">Attempts to claim one of the server's authed-client slots.</param>
        /// <param name="unregisterAuthed">Releases the authed-client slot (idempotent).</param>
        public BridgeSession(
            MarketHub hub,
            Action<string> sendText,
            Action<ushort, string> requestClose,
            Func<bool> tryRegisterAuthed,
            Action unregisterAuthed,
            string agentVersion,
            Action<string> log)
        {
            _hub                = hub ?? throw new ArgumentNullException(nameof(hub));
            _sendText           = sendText ?? throw new ArgumentNullException(nameof(sendText));
            _requestClose       = requestClose ?? throw new ArgumentNullException(nameof(requestClose));
            _tryRegisterAuthed  = tryRegisterAuthed ?? (() => true);
            _unregisterAuthed   = unregisterAuthed ?? (() => { });
            _agentVersion       = agentVersion ?? "unknown";
            _log                = log ?? (m => System.Diagnostics.Debug.WriteLine($"[BridgeSession] {m}"));

            HelloDeadlineUtc = DateTime.UtcNow.AddSeconds(5);
        }

        // -----------------------------------------------------------------------
        // Inbound message dispatch — called by BridgeServer's reader loop for
        // every complete text frame on this connection. Never throws.
        // -----------------------------------------------------------------------

        public void HandleMessage(string json)
        {
            JObject msg;
            try
            {
                msg = JObject.Parse(json);
            }
            catch (Exception ex)
            {
                _log($"BridgeSession[{Id}]: malformed JSON — {ex.Message}");
                SendError("bad_json", "Could not parse message as JSON.");
                return;
            }

            string t = (string)msg["t"];

            if (_state == SessionState.AwaitingHello)
            {
                if (string.Equals(t, "hello", StringComparison.OrdinalIgnoreCase))
                    HandleHello(msg);
                else
                {
                    SendError("auth_required", "Send hello{token} first.");
                    _requestClose(1008, "auth_required");
                }
                return;
            }

            switch (t)
            {
                case "subscribe":   HandleSubscribe(msg);   break;
                case "unsubscribe": HandleUnsubscribe(msg); break;
                case "backfill":    HandleBackfill(msg);    break;
                case "pong":        /* liveness already tracked at the frame level by BridgeServer */ break;
                default:
                    SendError("unknown_message", $"Unknown message type '{t}'.");
                    break;
            }
        }

        // -----------------------------------------------------------------------
        // hello / welcome
        // -----------------------------------------------------------------------

        private void HandleHello(JObject msg)
        {
            string token = (string)msg["token"];

            if (!BridgeAuth.Validate(token))
            {
                _log($"BridgeSession[{Id}]: hello auth FAILED.");
                SendError("auth_failed", "Invalid or missing token.");
                _requestClose(1008, "auth_failed");
                return;
            }

            if (!_tryRegisterAuthed())
            {
                _log($"BridgeSession[{Id}]: rejected — max concurrent bridge clients reached.");
                SendError("too_many_clients", "This device already has the maximum number of bridge connections open.");
                _requestClose(1008, "too_many_clients");
                return;
            }

            _state = SessionState.Authed;

            string feed;
            try { feed = _hub.GetPrimaryFeedName(); }
            catch { feed = "unknown"; }

            SendJson(new
            {
                t     = "welcome",
                v     = 1,
                agent = _agentVersion,
                feed  = feed,
                allow = MarketHub.AllowedRoots
            });

            _log($"BridgeSession[{Id}]: authenticated.");
        }

        // -----------------------------------------------------------------------
        // subscribe / unsubscribe
        // -----------------------------------------------------------------------

        private void HandleSubscribe(JObject msg)
        {
            string sym = (string)msg["sym"];
            bool wantTrades = (bool?)msg["trades"] ?? false;
            bool wantDepth  = (bool?)msg["depth"]  ?? false;

            if (string.IsNullOrWhiteSpace(sym) || !MarketHub.IsSymbolAllowed(sym))
            {
                SendError("bad_symbol",
                    $"Symbol must match an allowed root (NQ/ES/MNQ/MES) in 'ROOT MM-YY' format. Got '{sym}'.");
                return;
            }

            if (!wantTrades && !wantDepth)
            {
                SendError("bad_request", "subscribe requires at least one of trades/depth to be true.");
                return;
            }

            MarketHubAttachResult result = _hub.Attach(this, sym, wantTrades, wantDepth);
            if (!result.Success)
            {
                SendError(result.ErrorCode ?? "no_instrument", result.ErrorMessage ?? $"Instrument '{sym}' not found.");
                return;
            }

            lock (_subLock) _subscribedSymbols.Add(sym);

            SendJson(new { t = "sub_ok", sym = sym, tickSize = result.TickSize });
        }

        private void HandleUnsubscribe(JObject msg)
        {
            string sym = (string)msg["sym"];
            if (string.IsNullOrWhiteSpace(sym)) return;

            _hub.Detach(this, sym);
            lock (_subLock) _subscribedSymbols.Remove(sym);
        }

        // -----------------------------------------------------------------------
        // backfill
        // -----------------------------------------------------------------------

        private void HandleBackfill(JObject msg)
        {
            string id   = (string)msg["id"];
            string sym  = (string)msg["sym"];
            long fromMs = (long?)msg["fromMs"] ?? 0;
            long toMs   = (long?)msg["toMs"]   ?? 0;

            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(sym) || !MarketHub.IsSymbolAllowed(sym))
            {
                SendError("bad_request", "backfill requires a valid id and an allowed sym.");
                return;
            }

            if (Interlocked.CompareExchange(ref _backfillInFlight, 1, 0) != 0)
            {
                SendJson(new { t = "error", code = "busy", msg = "A backfill request is already in progress for this connection." });
                return;
            }

            Instrument instrument = _hub.ResolveInstrument(sym);
            if (instrument == null)
            {
                Interlocked.Exchange(ref _backfillInFlight, 0);
                SendError("no_instrument", $"Instrument '{sym}' not found.");
                return;
            }

            // Kick off on a background Task so this handler (running on the
            // per-connection reader thread) never blocks on BarsRequest.
            Task.Run(() =>
            {
                try
                {
                    BackfillService.Execute(
                        instrument, fromMs, toMs,
                        onChunk: chunk => SendJson(new { t = "bf_chunk", id = id, d = chunk }),
                        onDone: (coveredFromMs, estimatedAggressor) =>
                        {
                            try
                            {
                                SendJson(new
                                {
                                    t = "bf_done",
                                    id = id,
                                    coveredFromMs = coveredFromMs,
                                    estimatedAggressor = estimatedAggressor
                                });
                            }
                            finally
                            {
                                Interlocked.Exchange(ref _backfillInFlight, 0);
                            }
                        },
                        log: _log);
                }
                catch (Exception ex)
                {
                    _log($"BridgeSession[{Id}]: backfill error — {ex.GetType().Name}: {ex.Message}");
                    Interlocked.Exchange(ref _backfillInFlight, 0);
                    SendError("backfill_failed", "Backfill request failed unexpectedly.");
                }
            });
        }

        // -----------------------------------------------------------------------
        // Outbound helpers
        // -----------------------------------------------------------------------

        /// <summary>Sends the app-level keep-alive ping{ts}. Called by BridgeServer every ~15s.</summary>
        public void SendPing()
        {
            SendJson(new { t = "ping", ts = ToUnixMs(DateTime.UtcNow) });
        }

        /// <summary>Serializes and sends any payload object as a text frame. Called from MarketHub's flush timers too.</summary>
        public void SendJson(object payload)
        {
            try
            {
                string json = JsonConvert.SerializeObject(payload);
                _sendText(json);
            }
            catch (Exception ex)
            {
                _log($"BridgeSession[{Id}]: SendJson error — {ex.GetType().Name}: {ex.Message}");
            }
        }

        private void SendError(string code, string message)
        {
            SendJson(new { t = "error", code = code, msg = message });
        }

        private static long ToUnixMs(DateTime utc) =>
            (long)(utc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;

        // -----------------------------------------------------------------------
        // Disconnect
        // -----------------------------------------------------------------------

        /// <summary>Called by BridgeServer once the connection's read/write loops end, on any thread.</summary>
        public void OnDisconnect()
        {
            List<string> syms;
            lock (_subLock)
            {
                syms = new List<string>(_subscribedSymbols);
                _subscribedSymbols.Clear();
            }

            foreach (string sym in syms)
            {
                try { _hub.Detach(this, sym); }
                catch (Exception ex) { _log($"BridgeSession[{Id}]: Detach('{sym}') on disconnect error — {ex.Message}"); }
            }

            if (_state == SessionState.Authed)
            {
                try { _unregisterAuthed(); }
                catch { /* best-effort */ }
            }
        }
    }
}
