// =============================================================================
// Finotaur Agent — Bridge/BackfillService.cs
//
// Serves a bf:{sym,fromMs,toMs} request by pulling 1-tick historical bars
// from NT8 (BarsRequest) and streaming them back in small chunks.
//
// NO historical bid/ask is available from BarsRequest, so the aggressor side
// is ESTIMATED with the classic tick rule (uptick = buy, downtick = sell,
// unchanged = carry the previous side). The wire response always sets
// estimatedAggressor = true so the browser never treats this as exact.
//
// FAIL-SAFE: every path — including "no data in range" and any NT8 error —
// completes with bf_done. An empty result is a NORMAL outcome (e.g. outside
// trading hours), never surfaced as an error to the client.
//
// VERIFY (NT8 API, flagged): NinjaTrader.Data.Bars.GetTime(i) return value's
// DateTimeKind was not independently confirmed here — some NT8 builds return
// bar times as DateTimeKind.Unspecified in the timezone the request was made
// in (we request using .ToLocalTime() bounds, matching the documented
// BarsRequest(instrument, fromLocal, toLocal) constructor). This code calls
// .ToUniversalTime() on the returned time, which is correct if the Kind is
// Local or trustworthy-Unspecified-as-local; if bar times come back already
// UTC-flagged, ToUniversalTime() is a safe no-op. Worth a sanity check against
// a known trade time in NT8 sim before trusting the millisecond timestamps.
// =============================================================================

using System;
using System.Collections.Generic;
using NinjaTrader.Cbi;
using NinjaTrader.Data; // VERIFY (NT8 API, flagged): BarsRequest/BarsPeriod/BarsPeriodType
                        // are assumed to live in NinjaTrader.Data per the documented API
                        // contract for this task. If the compiler reports "type or
                        // namespace not found" for any of the four types used below
                        // (BarsRequest, BarsPeriod, BarsPeriodType, ErrorCode), check the
                        // actual namespace via Editor -> References in your NT8 install and
                        // adjust this using line — the calling code does not need to change.

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Bridge
{
    public static class BackfillService
    {
        private const int MaxChunkSize = 2000;
        private static readonly TimeSpan MaxWindow = TimeSpan.FromHours(8);
        private static readonly DateTime UnixEpochUtc = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        /// <summary>
        /// Executes a backfill request. Never throws — any failure degrades to
        /// an empty result plus a normal bf_done (per the "empty = normal, never
        /// an error to the client" contract).
        /// </summary>
        /// <param name="instrument">Already-resolved instrument (caller does the GetInstrument lookup).</param>
        /// <param name="fromMs">Requested window start, unix ms.</param>
        /// <param name="toMs">Requested window end, unix ms.</param>
        /// <param name="onChunk">Called with up to MaxChunkSize rows [timeMs, price, qty, sideEst] at a time.</param>
        /// <param name="onDone">Called exactly once with (coveredFromMs, estimatedAggressor=true).</param>
        /// <param name="log">Logger delegate (never throws).</param>
        public static void Execute(
            Instrument instrument,
            long fromMs,
            long toMs,
            Action<List<object[]>> onChunk,
            Action<long, bool> onDone,
            Action<string> log)
        {
            long clampedTo = toMs;
            try
            {
                long nowMs = ToUnixMs(DateTime.UtcNow);

                // Clamp: never request future data; never exceed the max window.
                clampedTo = Math.Min(toMs, nowMs);
                long minFrom = clampedTo - (long)MaxWindow.TotalMilliseconds;
                long clampedFrom = Math.Max(fromMs, minFrom);

                if (instrument == null || clampedFrom >= clampedTo)
                {
                    onDone?.Invoke(clampedTo, true);
                    return;
                }

                DateTime fromLocal = FromUnixMs(clampedFrom).ToLocalTime();
                DateTime toLocal   = FromUnixMs(clampedTo).ToLocalTime();

                var request = new BarsRequest(instrument, fromLocal, toLocal)
                {
                    BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Tick, Value = 1 }
                };

                request.Request((bars, errorCode, errorMessage) =>
                {
                    try
                    {
                        if (errorCode != ErrorCode.NoError || bars == null || bars.Bars == null || bars.Bars.Count == 0)
                        {
                            if (errorCode != ErrorCode.NoError)
                            {
                                log?.Invoke(
                                    $"BackfillService: BarsRequest error {errorCode} ('{errorMessage}') for " +
                                    $"'{instrument.FullName}' [{fromLocal:o}..{toLocal:o}]. " +
                                    "Treating as empty — bf_done with coveredFromMs=toMs.");
                            }
                            // Empty result (including a clean NoError-but-zero-ticks window) is
                            // normal — never surfaced as an error to the client.
                            onDone?.Invoke(clampedTo, true);
                            return;
                        }

                        int count = bars.Bars.Count;
                        double prevPrice = double.NaN;
                        int prevSide = 0;
                        var chunk = new List<object[]>(MaxChunkSize);

                        for (int i = 0; i < count; i++)
                        {
                            DateTime tRaw = bars.Bars.GetTime(i);
                            DateTime tUtc = tRaw.Kind == DateTimeKind.Utc ? tRaw : tRaw.ToUniversalTime();
                            double price  = bars.Bars.GetClose(i);
                            double qty    = bars.Bars.GetVolume(i);

                            int side;
                            if (double.IsNaN(prevPrice) || price > prevPrice) side = 1;
                            else if (price < prevPrice) side = -1;
                            else side = prevSide; // unchanged price — carry previous side (tick rule)

                            prevPrice = price;
                            prevSide  = side;

                            chunk.Add(new object[] { ToUnixMs(tUtc), price, qty, side });

                            if (chunk.Count >= MaxChunkSize)
                            {
                                onChunk?.Invoke(chunk);
                                chunk = new List<object[]>(MaxChunkSize);
                            }
                        }

                        if (chunk.Count > 0)
                            onChunk?.Invoke(chunk);

                        onDone?.Invoke(clampedFrom, true);
                    }
                    catch (Exception ex)
                    {
                        log?.Invoke($"BackfillService callback error: {ex.GetType().Name} — {ex.Message}");
                        try { onDone?.Invoke(clampedTo, true); } catch { /* best-effort */ }
                    }
                });
            }
            catch (Exception ex)
            {
                log?.Invoke($"BackfillService.Execute error: {ex.GetType().Name} — {ex.Message}");
                try { onDone?.Invoke(clampedTo, true); } catch { /* best-effort */ }
            }
        }

        private static long ToUnixMs(DateTime utc) => (long)(utc - UnixEpochUtc).TotalMilliseconds;

        private static DateTime FromUnixMs(long ms) => UnixEpochUtc.AddMilliseconds(ms);
    }
}
