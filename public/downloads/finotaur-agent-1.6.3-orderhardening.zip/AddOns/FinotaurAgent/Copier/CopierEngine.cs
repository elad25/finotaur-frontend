// =============================================================================
// Finotaur Agent — Copier/CopierEngine.cs
//
// LOCAL trade-copy engine. Mirrors fills from one NT8 account (the "source")
// to one or more NT8 accounts (the "targets") on the SAME user — completely
// locally, with ZERO network calls on the hot path.
//
// ═══════════════════════════════════════════════════════════════════════════
// COMPLIANCE BOUNDARY (DO NOT REMOVE THIS COMMENT)
// ═══════════════════════════════════════════════════════════════════════════
//   • All order placement uses NT8's local NinjaTrader.Cbi APIs only.
//   • This engine NEVER calls Tradovate, NinjaTrader Cloud, or any broker
//     REST/WebSocket API directly. The execution path is 100% local.
//   • Copying is strictly user-to-self: both source and all targets are
//     the same user's accounts (guaranteed by the server config — the server
//     only returns this user's connections).
//   • FAIL-SAFE: when in doubt, DO NOTHING. Every uncertain path returns
//     without placing orders. No order is ever speculative.
// ═══════════════════════════════════════════════════════════════════════════
//
// SCALE DESIGN (Elad requirement: ~60 accounts/user, fast fan-out):
//
//   HOT PATH IS 100% LOCAL, ZERO NETWORK PER FILL.
//     The NT8 ExecutionUpdate callback does the MINIMUM: validate the fill
//     against the locally-cached config, enqueue a CopyJob to the worker
//     queue, then return immediately. The NT thread is never blocked.
//
//   CONCURRENT FAN-OUT, OFF THE NT THREAD.
//     A dedicated background consumer (BlockingCollection<CopyJob>) dequeues
//     copy jobs and fans out to all targets concurrently via Task.WhenAll.
//     With up to ~59 targets per source fill, PlaceMarketOrder calls run in
//     parallel — the NT data thread is never stalled.
//
//   ONE AGGREGATED EVENT PER SOURCE FILL.
//     After the fan-out completes, ONE 'copy_executed' event is posted
//     summarizing: source symbol/qty, target count, per-target {account,
//     qty, ok/fail}. Failures are included in the same event (or a separate
//     'copy_failed' if the aggregated payload becomes too large — see
//     BATCH_MAX_FAILURES below). We NEVER emit one event per target.
//
//   IDEMPOTENCY.
//     Processed source ExecutionIds are tracked in a bounded concurrent set.
//     On reconnect or replay, duplicate fills are silently dropped.
//
//   TELEMETRY BATCHING (event queue).
//     Events are buffered in a ConcurrentQueue and flushed asynchronously
//     by the agent's background loop (not by the copy hot path). The copy
//     path enqueues and returns; it never blocks on network I/O.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Copier
{
    // =========================================================================
    // Internal data structures
    // =========================================================================

    /// <summary>
    /// Represents one pending copy-fan-out job. Placed on the worker queue
    /// by the NT fill callback (hot path) and consumed by the background worker.
    /// </summary>
    internal sealed class CopyJob
    {
        /// <summary>The normalized fill that triggered this copy.</summary>
        public FillInfo SourceFill { get; set; }

        /// <summary>The route that matched this fill.</summary>
        public CopierRoute Route { get; set; }

        /// <summary>Snapshot of config at the moment the job was enqueued.</summary>
        public AutomationConfig Config { get; set; }
    }

    /// <summary>
    /// Per-target result after attempting a mirrored order.
    /// Used to build the single aggregated 'copy_executed' event.
    /// </summary>
    internal sealed class TargetResult
    {
        /// <summary>
        /// The destination account name from the server config
        /// (DestinationAccountName when available, DestinationConnectionId as fallback).
        /// Used in the aggregated event payload for diagnostics on the web side.
        /// </summary>
        public string DestinationAccountName { get; set; }

        /// <summary>Resolved local NT account name (null if resolution failed).</summary>
        public string AccountName            { get; set; }
        public int    Quantity               { get; set; }
        public bool   Success                { get; set; }
        public string FailureReason          { get; set; }
    }

    // =========================================================================
    // WORKING-ORDER MIRRORING — internal data structures
    //
    // This is a SEPARATE path, ALONGSIDE the fill-copy path above. It mirrors
    // the LEADER's working (limit/stop/stoplimit) orders onto the followers as
    // their own working orders, so the follower fills independently at the
    // same trigger price instead of receiving a market order when the leader
    // fills. See CopierEngine._orderQueue / ProcessOrderJob for the full flow.
    // =========================================================================

    /// <summary>
    /// One pending order-mirroring job. Placed on <see cref="CopierEngine"/>'s
    /// order worker queue by the NT OrderUpdate callback (hot path) and
    /// consumed by the dedicated order-consumer background task.
    /// </summary>
    internal sealed class OrderCopyJob
    {
        /// <summary>The normalized leader working-order event that triggered this job.</summary>
        public OrderInfo SourceOrder { get; set; }

        /// <summary>The route that matched this order.</summary>
        public CopierRoute Route { get; set; }

        /// <summary>Snapshot of config at the moment the job was enqueued.</summary>
        public AutomationConfig Config { get; set; }
    }

    /// <summary>
    /// STEP 5 (copier-state persistence): on-disk snapshot of
    /// CopierEngine._everMirroredOrderIds, so the fill-skip idempotency check
    /// survives an agent restart. Mirrors RiskEnforcer.RiskStateSnapshot's
    /// shape/conventions. Order is oldest→newest (same order as the in-memory
    /// eviction queue), so LoadCopierState can replay TryAdd + enqueue exactly.
    /// </summary>
    internal sealed class CopierStateSnapshot
    {
        public string SavedAtUtc { get; set; }
        public List<string> EverMirroredOrderIds { get; set; } = new List<string>();
    }

    /// <summary>
    /// One follower working order that was placed to mirror a leader working
    /// order on a specific target account.
    /// </summary>
    internal sealed class MirroredTarget
    {
        /// <summary>Resolved local NT account name of the follower.</summary>
        public string TargetAccount { get; set; }

        /// <summary>The follower's NT8 Order.Id, as returned by PlaceWorkingOrder.</summary>
        public string FollowerOrderId { get; set; }

        /// <summary>
        /// Snapshot of CopierTarget.ScaleRatio at placement time, retained so a
        /// later MODIFY can recompute the follower quantity from the leader's
        /// new quantity using the SAME ratio/clamp as the original placement.
        /// </summary>
        public double ScaleRatio { get; set; } = 1.0;

        /// <summary>Snapshot of CopierTarget.MaxContracts at placement time (null = no cap).</summary>
        public int? MaxContracts { get; set; }

        /// <summary>
        /// The translated (TranslateInstrument) instrument name used for this
        /// target at placement time. Used by STEP 3's modify-time risk gate,
        /// which must check the FOLLOWER's instrument (which may differ from
        /// the leader's via CrossToMicro), not the leader's raw symbol.
        /// </summary>
        public string Instrument { get; set; }
    }

    /// <summary>
    /// Tracks a leader working order that has been mirrored to one or more
    /// follower accounts. Keyed by the leader's OrderId in
    /// <see cref="CopierEngine._mirroredLeaderOrders"/>. Used to route
    /// subsequent modify/cancel/fill events on the same leader order to the
    /// correct follower orders.
    /// </summary>
    internal sealed class MirroredOrder
    {
        public string RouteId { get; set; }
        public string LeaderOrderId { get; set; }

        /// <summary>Last-known leader limit price (0 if not applicable to the order type).</summary>
        public double LastLimit { get; set; }

        /// <summary>Last-known leader stop price (0 if not applicable to the order type).</summary>
        public double LastStop { get; set; }

        /// <summary>Last-known leader quantity.</summary>
        public int LastQty { get; set; }

        /// <summary>
        /// Snapshot of the leader order's TimeInForce at placement time ("day" |
        /// "gtc"). Not re-read on modify — TIF is set once at placement mirroring
        /// and is not expected to change on an existing order.
        /// </summary>
        public string Tif { get; set; } = "day";

        public List<MirroredTarget> Targets { get; set; } = new List<MirroredTarget>();
    }

    // =========================================================================
    // CopierEngine
    // =========================================================================

    /// <summary>
    /// Manages fill subscriptions for all active copier routes, fans out mirrored
    /// orders concurrently, and enqueues aggregated telemetry events.
    ///
    /// Lifecycle:
    ///   1. Call ApplyConfig() whenever the agent receives a new AutomationConfig.
    ///   2. The engine subscribes/unsubscribes as routes change.
    ///   3. Call Dispose() when the AddOn shuts down.
    /// </summary>
    public sealed class CopierEngine : IDisposable
    {
        // -----------------------------------------------------------------------
        // Cross-instrument map (full ↔ micro, bidirectional).
        // Key = SOURCE root symbol (upper-case), Value = TARGET root symbol.
        // Used when CopierTarget.CrossToMicro == true.
        // Quantity is NOT adjusted here — scale_ratio handles sizing.
        // -----------------------------------------------------------------------

        private static readonly Dictionary<string, string> CrossMap =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // Equity index futures (CME)
            { "NQ",  "MNQ" }, { "MNQ", "NQ"  },
            { "ES",  "MES" }, { "MES", "ES"  },
            { "RTY", "M2K" }, { "M2K", "RTY" },
            { "YM",  "MYM" }, { "MYM", "YM"  },
            // Metals (CME/COMEX)
            { "GC",  "MGC" }, { "MGC", "GC"  },
            { "SI",  "SIL" }, { "SIL", "SI"  },
            // Energy (CME/NYMEX)
            { "CL",  "MCL" }, { "MCL", "CL"  },
            // FX futures (CME)
            { "6E",  "M6E" }, { "M6E", "6E"  },
            { "6B",  "M6B" }, { "M6B", "6B"  },
            { "6A",  "M6A" }, { "M6A", "6A"  },
            // Crypto futures (CME)
            { "BTC", "MBT" }, { "MBT", "BTC" },
            { "ETH", "MET" }, { "MET", "ETH" },
        };

        /// <summary>
        /// Translates an NT8 full instrument name (e.g. "NQ 09-26") to its
        /// cross-mapped counterpart (e.g. "MNQ 09-26") when CrossToMicro is set.
        ///
        /// The root is the leading token before the first space.  The remainder
        /// (contract month suffix such as " 09-26") is preserved verbatim.
        ///
        /// Returns the original name unchanged if:
        ///   • CrossToMicro is false.
        ///   • The root has no entry in CrossMap.
        ///   • The instrument name is null/empty.
        ///
        /// In all fallback cases a diagnostic message is written via the logger.
        /// The caller MUST NOT drop the order on a fallback — use the original name.
        /// </summary>
        private string TranslateInstrument(string instrumentName, CopierTarget target)
        {
            if (!target.CrossToMicro) return instrumentName;
            if (string.IsNullOrWhiteSpace(instrumentName)) return instrumentName;

            // Split on first space: "NQ 09-26" → root="NQ", suffix=" 09-26"
            int spaceIdx = instrumentName.IndexOf(' ');
            string root   = spaceIdx < 0 ? instrumentName : instrumentName.Substring(0, spaceIdx);
            string suffix = spaceIdx < 0 ? string.Empty   : instrumentName.Substring(spaceIdx);

            if (CrossMap.TryGetValue(root, out string mapped))
            {
                string translated = mapped + suffix;
                _log($"CrossInstrument: '{instrumentName}' → '{translated}' " +
                     $"(CrossToMicro=true, target '{target.DestinationAccountName ?? target.DestinationConnectionId}').");
                return translated;
            }

            // Root not in map — fall back to original, do not drop the copy.
            _log($"CrossInstrument: root '{root}' has no CrossMap entry — " +
                 $"using original instrument '{instrumentName}' (CrossToMicro requested but unsupported root). " +
                 "Add the root pair to CopierEngine.CrossMap if needed.");
            return instrumentName;
        }
        // -----------------------------------------------------------------------
        // Dependencies
        // -----------------------------------------------------------------------

        private readonly IPlatformAdapter   _platform;
        private readonly RiskEnforcer       _risk;
        private readonly Action<string>     _log;

        // -----------------------------------------------------------------------
        // Event queue — telemetry events produced by the copier are placed here.
        // The agent's background loop (FinotaurAgent) drains this queue and
        // flushes to the server via FinotaurClient in batches.
        // The copier NEVER calls FinotaurClient directly — no network on hot path.
        // -----------------------------------------------------------------------

        private readonly ConcurrentQueue<AutomationEvent> _eventQueue;

        // -----------------------------------------------------------------------
        // Worker queue + consumer task
        // The hot path (NT fill callback) enqueues CopyJob objects.
        // A single background consumer Task dequeues and processes them.
        // BlockingCollection provides blocking take + cancellation support.
        // -----------------------------------------------------------------------

        /// <summary>
        /// Maximum pending copy jobs in the queue. If the consumer falls behind
        /// (e.g. NT is very busy), extra fills are silently dropped rather than
        /// blocking the NT thread. In normal operation the queue drains instantly.
        /// </summary>
        private const int WorkerQueueCapacity = 512;

        private readonly BlockingCollection<CopyJob> _workerQueue =
            new BlockingCollection<CopyJob>(WorkerQueueCapacity);

        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private Task _consumerTask;

        // -----------------------------------------------------------------------
        // Active subscriptions — keyed by route.Id
        // Value is the opaque handle returned by IPlatformAdapter.SubscribeFills.
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, object> _subscriptions =
            new ConcurrentDictionary<string, object>();

        // =========================================================================
        // WORKING-ORDER MIRRORING — fields
        //
        // ALONGSIDE (not replacing) the fill-copy path above. Mirrors the leader's
        // working orders (limit/stop/stoplimit) onto followers as their own working
        // orders. Market orders remain handled exclusively by the fill-copy path.
        // =========================================================================

        /// <summary>
        /// Active order subscriptions — keyed by route.Id, parallel to _subscriptions.
        /// Value is the opaque handle returned by IPlatformAdapter.SubscribeOrders.
        /// </summary>
        private readonly ConcurrentDictionary<string, object> _orderSubscriptions =
            new ConcurrentDictionary<string, object>();

        /// <summary>
        /// Leader OrderId → MirroredOrder mapping for working orders currently
        /// being mirrored to one or more followers. Cleared on every config
        /// rebuild (ApplyConfig) — a rebuild loses in-flight modify/cancel
        /// tracking for previously-mirrored orders (logged when it happens).
        /// </summary>
        private readonly ConcurrentDictionary<string, MirroredOrder> _mirroredLeaderOrders =
            new ConcurrentDictionary<string, MirroredOrder>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Bounded FIFO set of leader OrderIds that have EVER been mirrored via
        /// the working-order path, structured exactly like _processedIds /
        /// _idEvictionQueue below. Consulted by the fill-copy hot path to skip
        /// double-copying a fill that came from an order we already mirrored as
        /// a working order (the follower's own working order will fill on its
        /// own). Deliberately NOT cleared on config rebuild — it must survive
        /// reloads so in-flight fills still see the skip.
        /// </summary>
        private const int MaxEverMirroredOrderIds = 100000;
        private readonly ConcurrentDictionary<string, byte> _everMirroredOrderIds =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
        private readonly Queue<string> _everMirroredEvictionQueue = new Queue<string>();
        private readonly object        _everMirroredEvictionLock  = new object();

        /// <summary>
        /// Leader OrderIds whose most recent ProcessOrderPlacement attempt had
        /// EVERY target blocked by the pre-placement risk gate (zero targets
        /// succeeded). No mapping is created for a fully risk-blocked order, so
        /// without this set every subsequent leader OrderUpdate state event
        /// (submitted → accepted → working) would re-run ProcessOrderPlacement,
        /// re-block, and re-emit a duplicate order_copy_failed event. Cleared on
        /// config rebuild (risk rules may change) and on leader terminal states
        /// (filled/cancelled/rejected) so a genuinely re-placed order isn't
        /// wrongly skipped. Scope: risk-blocks only — technical placement
        /// failures (PlaceWorkingOrder returning null, exceptions) are NOT
        /// tracked here and continue to retry on every state event as before.
        /// </summary>
        private readonly ConcurrentDictionary<string, byte> _riskBlockedLeaderOrders =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // STEP 5 (copier-state persistence): path for the JSON snapshot file that
        // persists _everMirroredOrderIds across agent restarts. Mirrors
        // RiskEnforcer's FIX #7 persistence pattern exactly (same directory
        // convention, same best-effort try/catch-swallow semantics).
        // NOTE: untested in this environment — requires NT8 sim verification before live use.
        // -----------------------------------------------------------------------

        private const  string CopierStateFileName = "copier-state.json";
        private readonly string _copierStatePath;

        /// <summary>
        /// Per-leader-order-id locks (like _netLocks below) — serializes
        /// place/modify/cancel handling for one leader order so concurrent
        /// order-state callbacks for the same order cannot race. Cleared on
        /// config rebuild along with _mirroredLeaderOrders.
        /// </summary>
        private readonly ConcurrentDictionary<string, object> _orderLocks =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Maximum pending order-mirroring jobs in the queue. Mirrors
        /// WorkerQueueCapacity — if the order consumer falls behind, extra
        /// order events are dropped rather than blocking the NT thread.
        /// </summary>
        private const int OrderWorkerQueueCapacity = 512;

        private readonly BlockingCollection<OrderCopyJob> _orderQueue =
            new BlockingCollection<OrderCopyJob>(OrderWorkerQueueCapacity);

        private Task _orderConsumerTask;

        // -----------------------------------------------------------------------
        // FIX #9/#10 (net-position reconciliation): per-(targetAccount|instrument)
        // tracker for the expected target net position.
        //
        // Key   = "{targetAccountName}|{translatedInstrumentName}"  (pipe-separated,
        //         both components are the locally-resolved NT names)
        // Value = expected net contracts on the target (signed: + long, − short, 0 flat)
        //
        // "Expected" means the net we believe the target SHOULD have based on orders
        // we have successfully submitted — not the raw NT position (which only updates
        // after fill confirmation).  We advance `expected` on successful PlaceMarketOrder
        // so that a rapid next reconcile does not double-send; on failure we do NOT
        // advance, so the next reconcile will retry the outstanding delta.
        //
        // First-touch / restart seeding: when the key is absent, we READ the target
        // account's actual current NT position and seed from that.  This makes
        // pre-existing positions and agent restarts safe.
        //
        // Thread-safety: ConcurrentDictionary handles concurrent reads/updates.
        // The consumer loop serializes jobs one-at-a-time, but per-target fan-out
        // runs concurrently (Task.WhenAll inside ProcessJobAsync).  Two tasks for
        // the SAME (targetAccount, instrument) could race on the same key.
        // We use a per-key lock (see _netLocks below) to make the
        // read-expected → place-order → update-expected sequence atomic per key.
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, int> _expectedTargetNet =
            new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        // Per-key locks: keyed identically to _expectedTargetNet.
        // Created lazily on first touch.  A simple object per key is sufficient
        // because the critical section is very short (no network/IO inside).
        private readonly ConcurrentDictionary<string, object> _netLocks =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // Tilt tracking: last-known session realized PnL per source account.
        // Updated just before processing each close fill so we can compute the
        // PnL delta and infer win/loss.
        //
        // VERIFY (NT8 API): GetSessionRealizedPnL calls Account.Get(AccountItem.*)
        // internally.  NT8 may update the realized-PnL value asynchronously after
        // the ExecutionUpdate callback fires.  If the adapter always returns the
        // same value before and after a close fill, the delta will be 0 and we
        // cannot determine win/loss from this approach alone.  In that case the
        // TODO below applies: swap in a fill-level P&L signal when NT8 exposes it
        // (e.g. Execution.Profit in a future NT release or via a custom position
        // tracker that maintains average-entry price).
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, double> _lastSourceRealizedPnL =
            new ConcurrentDictionary<string, double>();

        // -----------------------------------------------------------------------
        // Latency instrumentation: per-copy timing, keyed by the unique order token.
        // Populated when a target order is submitted; resolved when the matching
        // follower fill arrives on the target account. Bounded + age-purged so a copy
        // whose follower fill never arrives (e.g. rejected order) cannot leak.
        // -----------------------------------------------------------------------

        internal sealed class CopyTiming
        {
            public string   LeaderExecId;
            public DateTime LeaderExecTime;    // wall-clock leader fill time (FillInfo.Timestamp)
            public long     LeaderCapturedTicks; // t0 monotonic
            public long     DequeuedTicks;      // t1 monotonic
            public long     SubmitStartTicks;   // t2 monotonic
            public long     SubmitEndTicks;     // t2b monotonic
            public string   TargetAccount;
            public string   Instrument;
            public int      Delta;             // signed contracts sent
            public string   RouteLabel;
            public long     RegisteredTicks;   // for age purge
        }

        private readonly ConcurrentDictionary<string, CopyTiming> _pendingTimings =
            new ConcurrentDictionary<string, CopyTiming>(StringComparer.OrdinalIgnoreCase);

        private const int MaxPendingTimings = 4096;

        // Tracks target accounts we've subscribed for follower-fill latency, to avoid double-subscribe.
        private readonly ConcurrentDictionary<string, object> _targetFillSubs =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        // -----------------------------------------------------------------------
        // Idempotency set — tracks ExecutionIds we have already processed.
        // Bounded to prevent unbounded growth across long NT sessions.
        // -----------------------------------------------------------------------

        private const int MaxProcessedIds = 100000;
        private readonly ConcurrentDictionary<string, byte> _processedIds =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);

        // Keep an ordered queue of IDs so we can evict the oldest when the cap
        // is reached (FIFO eviction — simple ring-buffer approximation via a Queue
        // protected by a lock).
        private readonly Queue<string> _idEvictionQueue = new Queue<string>();
        private readonly object        _idEvictionLock  = new object();

        // -----------------------------------------------------------------------
        // Locally-cached config (set by ApplyConfig, read by hot path)
        // Volatile so the NT callback always sees the latest reference.
        // -----------------------------------------------------------------------

        private volatile AutomationConfig _cachedConfig;

        // -----------------------------------------------------------------------
        // Constructor
        // -----------------------------------------------------------------------

        /// <summary>
        /// Creates a CopierEngine.
        /// </summary>
        /// <param name="platform">Platform adapter for account queries and order placement.</param>
        /// <param name="risk">Risk enforcer used for pre-trade checks.</param>
        /// <param name="eventQueue">
        /// Shared queue that the agent's background loop drains for telemetry.
        /// The copier enqueues aggregated events here — never posts to the network.
        /// </param>
        /// <param name="logger">Optional logger delegate.</param>
        public CopierEngine(
            IPlatformAdapter              platform,
            RiskEnforcer                  risk,
            ConcurrentQueue<AutomationEvent> eventQueue,
            Action<string>                logger = null)
        {
            _platform   = platform   ?? throw new ArgumentNullException(nameof(platform));
            _risk       = risk       ?? throw new ArgumentNullException(nameof(risk));
            _eventQueue = eventQueue ?? throw new ArgumentNullException(nameof(eventQueue));
            _log        = logger     ?? (m => System.Diagnostics.Debug.WriteLine($"[CopierEngine] {m}"));

            // STEP 5: resolve the copier-state file path using the same NinjaTrader
            // data directory convention as RiskEnforcer's FIX #7 (_statePath).
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            try
            {
                string ntDataDir;
                try
                {
                    ntDataDir = NinjaTrader.Core.Globals.UserDataDir;
                }
                catch
                {
                    ntDataDir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "NinjaTrader 8");
                }
                _copierStatePath = Path.Combine(ntDataDir, "Finotaur", CopierStateFileName);
            }
            catch (Exception ex)
            {
                _log($"CopierEngine: could not resolve copier-state file path ({ex.Message}); " +
                     "mirrored-order fill-skip idempotency will not persist across restarts.");
                _copierStatePath = null;
            }

            // STEP 5: load any previously persisted _everMirroredOrderIds.
            LoadCopierState();

            // Start the background consumer task.
            // It runs on a dedicated thread pool task so order placement is always
            // off the NT event thread.
            _consumerTask = Task.Run(ConsumerLoop, _cts.Token);

            // WORKING-ORDER MIRRORING: start the dedicated order consumer task,
            // alongside the fill consumer above. Same cancellation token.
            _orderConsumerTask = Task.Run(OrderConsumerLoop, _cts.Token);
        }

        // -----------------------------------------------------------------------
        // ApplyConfig — called by FinotaurAgent on every successful config pull
        // -----------------------------------------------------------------------

        /// <summary>
        /// Rebuilds fill subscriptions from the new config.
        ///
        /// CALL THIS only when the config actually changed (i.e. AutomationConfig
        /// .Unchanged == false). For Shape-A "unchanged" responses, apply the
        /// master/kill flags but do NOT call ApplyConfig — subscriptions are
        /// stable and rebuilding them would create duplicate events.
        ///
        /// Thread-safe: can be called from the agent background loop.
        /// </summary>
        public void ApplyConfig(AutomationConfig config)
        {
            if (config == null)
            {
                _log("ApplyConfig called with null config — skipping.");
                return;
            }

            // Store the new config atomically. The hot path (fill callback) reads
            // _cachedConfig; publishing a new reference is atomic on 64-bit CLR.
            _cachedConfig = config;

            // ------------------------------------------------------------------
            // Unsubscribe routes that are no longer active or no longer present
            // ------------------------------------------------------------------

            var incomingRouteIds = new HashSet<string>(
                (config.CopierRoutes ?? new List<CopierRoute>())
                    .Where(r => r.IsActive)
                    .Select(r => r.Id));

            foreach (var existingRouteId in _subscriptions.Keys.ToList())
            {
                if (!incomingRouteIds.Contains(existingRouteId))
                {
                    if (_subscriptions.TryRemove(existingRouteId, out object handle))
                    {
                        _platform.Unsubscribe(handle);
                        _log($"Unsubscribed route '{existingRouteId}' (no longer active).");
                    }
                }
            }

            // WORKING-ORDER MIRRORING: unsubscribe order subscriptions for routes
            // that are no longer active, symmetrically with _subscriptions above.
            foreach (var existingRouteId in _orderSubscriptions.Keys.ToList())
            {
                if (!incomingRouteIds.Contains(existingRouteId))
                {
                    if (_orderSubscriptions.TryRemove(existingRouteId, out object orderHandle))
                    {
                        _platform.Unsubscribe(orderHandle);
                        _log($"Unsubscribed order-mirroring for route '{existingRouteId}' (no longer active).");
                    }
                }
            }

            // FIX #9/#10 (net-position reconciliation): clear the net-position tracker
            // on every config rebuild so that re-activated or reconfigured routes
            // re-seed from the actual NT position on their first fill.  Stale expected
            // values from a previous config epoch could cause a spurious delta order.
            // The tracker is small (one int per active (targetAccount, instrument) pair)
            // so clearing on config change is safe.
            _expectedTargetNet.Clear();
            _netLocks.Clear();
            _log("ApplyConfig: cleared net-position tracker (will re-seed on next fill per target).");

            // WORKING-ORDER MIRRORING: clear mirrored-order tracking + per-order
            // locks on every config rebuild, same rationale as the net-position
            // tracker above. Previously-mirrored orders LOSE modify/cancel
            // tracking across this rebuild — a leader modify/cancel on an order
            // mirrored under the old config epoch will not find a mapping and
            // will be treated as a fresh PLACEMENT candidate (which will no-op
            // since IsActive/route lookups use the new config). This is a known,
            // logged trade-off — deliberately NOT clearing _everMirroredOrderIds,
            // since that set must survive reloads so in-flight fills still skip.
            //
            // STEP 2f: if any tracked orders are about to be dropped, log a WARNING
            // (not just info) including how many were GTC — those are the ones most
            // likely to still be resting on the leader across a config rebuild, so
            // losing their modify/cancel tracking is the highest-impact case.
            if (_mirroredLeaderOrders.Count > 0)
            {
                int gtcCount = _mirroredLeaderOrders.Values.Count(m =>
                    string.Equals(m.Tif, "gtc", StringComparison.OrdinalIgnoreCase));
                _log($"ApplyConfig WARNING: dropping modify/cancel tracking for " +
                     $"{_mirroredLeaderOrders.Count} mirrored leader order(s) across this config " +
                     $"rebuild ({gtcCount} of which were GTC — most likely to still be live).");
            }

            _mirroredLeaderOrders.Clear();
            _orderLocks.Clear();
            _riskBlockedLeaderOrders.Clear();
            _log("ApplyConfig: cleared mirrored-order tracking (previously-mirrored orders " +
                 "lose modify/cancel tracking across this config rebuild; fill-skip idempotency " +
                 "via _everMirroredOrderIds is preserved). Also cleared risk-blocked leader-order " +
                 "tracking — new config may change risk rules, so re-evaluate fresh.");

            // Latency instrumentation: unsubscribe all previous target-fill subscriptions
            // and clear pending timings before rebuilding.  This mirrors the
            // _expectedTargetNet.Clear() pattern — stale subs from an old config epoch
            // should not persist into the new one.
            foreach (var kv in _targetFillSubs)
            {
                try { _platform.Unsubscribe(kv.Value); }
                catch { /* best-effort */ }
            }
            _targetFillSubs.Clear();
            _pendingTimings.Clear();
            _log("ApplyConfig: cleared target fill-latency subscriptions (will re-subscribe below).");

            // ------------------------------------------------------------------
            // Subscribe new or re-activated routes
            // ------------------------------------------------------------------

            foreach (var route in config.CopierRoutes ?? new List<CopierRoute>())
            {
                if (!route.IsActive)
                {
                    // Ensure any stale subscription is removed
                    if (_subscriptions.TryRemove(route.Id, out object staleHandle))
                    {
                        _platform.Unsubscribe(staleHandle);
                        _log($"Removed subscription for inactive route '{route.Id}'.");
                    }
                    // WORKING-ORDER MIRRORING: ensure any stale order subscription is
                    // removed too, symmetrically.
                    if (_orderSubscriptions.TryRemove(route.Id, out object staleOrderHandle))
                    {
                        _platform.Unsubscribe(staleOrderHandle);
                        _log($"Removed order-mirroring subscription for inactive route '{route.Id}'.");
                    }
                    continue;
                }

                // Already subscribed for this route — no change needed
                if (_subscriptions.ContainsKey(route.Id)) continue;

                // ------------------------------------------------------------------
                // Resolve source account → local NT account name.
                //
                // Resolution order:
                //   1. route.SourceAccountName  → ResolveAccountByName()  (primary)
                //   2. route.SourceConnectionId → FindConnection() +
                //                                 ResolveAccountName()     (fallback)
                //
                // The primary path is the new account-name-based approach.  The
                // fallback supports older server responses that pre-date the
                // accounts array.  Either way: if we cannot resolve to a local NT
                // account, SKIP this route with a diagnostic log — fail-safe.
                // ------------------------------------------------------------------
                string sourceAccount = null;

                if (!string.IsNullOrWhiteSpace(route.SourceAccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    sourceAccount = _platform.ResolveAccountByName(route.SourceAccountName);
                    if (sourceAccount == null)
                    {
                        // Post a status event so the web can surface the gap.
                        _eventQueue.Enqueue(new AutomationEvent
                        {
                            EventType = "agent_status",
                            Severity  = "warning",
                            Payload   = new
                            {
                                message         = $"Copier route '{route.Label}' skipped: " +
                                                  $"source account '{route.SourceAccountName}' " +
                                                  "is not connected in this NT8 instance. " +
                                                  "Open NinjaTrader → Accounts and connect the account.",
                                route_id        = route.Id,
                                source_account  = route.SourceAccountName,
                                source_broker   = route.SourceBroker,
                                source_env      = route.SourceEnvironment
                            }
                        });
                        _log($"ApplyConfig: route '{route.Label}' — source account " +
                             $"'{route.SourceAccountName}' not found locally — SKIPPING. " +
                             "Verify the account is connected in NT8.");
                        continue;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(route.SourceConnectionId))
                {
                    // Fallback: older server response without account_name field.
                    BrokerConnection sourceConn = FindConnection(config, route.SourceConnectionId);
                    if (sourceConn == null)
                    {
                        _log($"ApplyConfig: route '{route.Label}' source connection " +
                             $"'{route.SourceConnectionId}' not found in config — SKIPPING.");
                        continue;
                    }
                    sourceAccount = _platform.ResolveAccountName(sourceConn);
                    if (sourceAccount == null)
                    {
                        _log($"ApplyConfig: route '{route.Label}' — no local NT account for " +
                             $"connection '{route.SourceConnectionId}' (fallback path) — SKIPPING. " +
                             "Ensure the Tradovate account is connected in NT8.");
                        continue;
                    }
                    _log($"ApplyConfig: route '{route.Label}' resolved source via legacy " +
                         $"connection-id fallback → '{sourceAccount}'.");
                }
                else
                {
                    _log($"ApplyConfig: route '{route.Label}' has neither SourceAccountName " +
                         "nor SourceConnectionId — SKIPPING (malformed route).");
                    continue;
                }

                // ------------------------------------------------------------------
                // HOT-PATH FILL CALLBACK
                // Keep this extremely lean: validate + enqueue + return.
                // NO network calls, NO expensive computation here.
                // The NT event thread must not be held.
                // ------------------------------------------------------------------

                // Capture the route ID for the closure to avoid
                // closure-over-loop-variable bugs. The closure reads the full
                // route object from _cachedConfig at fill time (see liveRoute
                // lookup below) rather than capturing the object at subscribe time.
                string capturedRouteId = route.Id;

                object subHandle = _platform.SubscribeFills(sourceAccount, fill =>
                {
                    // -------- HOT PATH START --------
                    // This runs on the NT ExecutionUpdate thread.
                    // Do NOT block, do NOT allocate excessively, do NOT network-call.

                    try
                    {
                        // Load the locally-cached config (atomic volatile read).
                        AutomationConfig cfg = _cachedConfig;
                        if (cfg == null) return;

                        // Hard stop: master disabled or kill engaged.
                        // Always checked first, every fill.
                        if (!cfg.MasterEnabled || cfg.KillSwitchEngaged) return;

                        // WORKING-ORDER MIRRORING: if this fill's originating order was
                        // already mirrored as a working order (see ProcessOrderJob PLACEMENT
                        // below), the follower's own working order fills independently —
                        // do NOT also fan out a market-order copy for it here.
                        if (fill.OrderId != null && WasLeaderOrderMirrored(fill.OrderId))
                        {
                            _log($"Fill '{fill.ExecutionId}' came from mirrored working order '{fill.OrderId}' — skipping fill-copy (follower working order fills independently).");
                            return;
                        }

                        // Use the CURRENT route config from the latest cached config (looked up by
                        // Id) — NOT the route object captured at subscribe time. This makes web-UI
                        // edits to an active route (scale_ratio, targets, copy flags, reverse,
                        // cross_to_micro, symbol_filter) take effect on the very next fill, without
                        // requiring a re-subscribe or agent restart.
                        CopierRoute liveRoute = null;
                        var routesNow = cfg.CopierRoutes;
                        if (routesNow != null)
                        {
                            for (int i = 0; i < routesNow.Count; i++)
                            {
                                var rNow = routesNow[i];
                                if (rNow != null && rNow.IsActive
                                    && string.Equals(rNow.Id, capturedRouteId, StringComparison.OrdinalIgnoreCase))
                                {
                                    liveRoute = rNow;
                                    break;
                                }
                            }
                        }
                        if (liveRoute == null) return; // route deactivated/removed since subscribe — nothing to copy

                        // Idempotency: skip fills we have already processed.
                        if (!TryMarkProcessed(fill.ExecutionId)) return;

                        // Symbol filter (empty = copy all)
                        if (liveRoute.SymbolFilter != null
                            && liveRoute.SymbolFilter.Count > 0)
                        {
                            bool symbolMatch = liveRoute.SymbolFilter.Any(s =>
                                string.Equals(s, fill.InstrumentName,
                                    StringComparison.OrdinalIgnoreCase));
                            if (!symbolMatch) return;
                        }

                        // FIX #9/#10 (net-position reconciliation):
                        // The copy_opens / copy_closes gate is NO LONGER applied here
                        // on the hot path using the fill's IsOpening flag.  That
                        // approach was fragile (#10 timing bug) and prevented
                        // correct net reconciliation.  The gate is now derived from
                        // actual net position magnitude change inside
                        // PlaceTargetOrderAsync — see "CopyOpens / CopyCloses gating"
                        // comment block there.  IsOpening is still populated on the
                        // fill (for tilt tracking and telemetry) but MUST NOT be used
                        // to decide whether to enqueue the copy job.

                        // Enqueue the copy job for the background consumer.
                        // If the queue is full (bounded at WorkerQueueCapacity), TryAdd returns
                        // false and we drop this fill — better to drop than to block the NT thread.
                        bool enqueued = _workerQueue.TryAdd(new CopyJob
                        {
                            SourceFill = fill,
                            Route      = liveRoute,
                            Config     = cfg          // snapshot of config at enqueue time
                        });

                        if (!enqueued)
                        {
                            // Queue is full — log and drop. This should be rare.
                            _log($"HOT PATH: worker queue full — dropping fill " +
                                 $"'{fill.ExecutionId}' on '{fill.InstrumentName}'. " +
                                 "This indicates the consumer is falling behind; " +
                                 "investigate if this happens frequently.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Fill callbacks must NEVER throw — NT may crash the connection.
                        _log($"HOT PATH exception for fill '{fill?.ExecutionId}': " +
                             $"{ex.GetType().Name} — {ex.Message}");
                    }
                    // -------- HOT PATH END --------
                });

                if (subHandle != null)
                {
                    _subscriptions[route.Id] = subHandle;
                    _log($"Subscribed route '{route.Label}' → source account '{sourceAccount}'.");
                }
                else
                {
                    _log($"Failed to subscribe route '{route.Label}' — " +
                         $"SubscribeFills returned null for '{sourceAccount}'.");
                }

                // ------------------------------------------------------------------
                // WORKING-ORDER MIRRORING — HOT-PATH ORDER CALLBACK
                // Runs on the NT OrderUpdate thread. Keep lean: validate + enqueue +
                // return, exactly like the fill hot path above. NO network calls,
                // NO expensive computation here.
                // ------------------------------------------------------------------

                object orderSubHandle = _platform.SubscribeOrders(sourceAccount, order =>
                {
                    // -------- ORDER HOT PATH START --------
                    try
                    {
                        AutomationConfig cfg = _cachedConfig;
                        if (cfg == null) return;

                        // Hard stop: master disabled or kill engaged.
                        if (!cfg.MasterEnabled || cfg.KillSwitchEngaged) return;

                        // Look up the CURRENT route config, same pattern as the fill
                        // hot path — web-UI edits to an active route take effect on
                        // the very next order event without re-subscribe/restart.
                        CopierRoute liveRoute = null;
                        var routesNow = cfg.CopierRoutes;
                        if (routesNow != null)
                        {
                            for (int i = 0; i < routesNow.Count; i++)
                            {
                                var rNow = routesNow[i];
                                if (rNow != null && rNow.IsActive
                                    && string.Equals(rNow.Id, capturedRouteId, StringComparison.OrdinalIgnoreCase))
                                {
                                    liveRoute = rNow;
                                    break;
                                }
                            }
                        }
                        if (liveRoute == null) return; // route deactivated/removed since subscribe

                        // Only mirror WORKING orders (limit/stop/stoplimit/mit). Market
                        // orders are handled exclusively by the fill-copy path above.
                        string ot = order.OrderType;
                        if (ot != "limit" && ot != "stop" && ot != "stoplimit" && ot != "mit") return;

                        // Symbol filter (empty = copy all) — same as fill path.
                        if (liveRoute.SymbolFilter != null
                            && liveRoute.SymbolFilter.Count > 0)
                        {
                            bool symbolMatch = liveRoute.SymbolFilter.Any(s =>
                                string.Equals(s, order.InstrumentName,
                                    StringComparison.OrdinalIgnoreCase));
                            if (!symbolMatch) return;
                        }

                        // Skip our own mirrored (follower) orders — they carry the
                        // "FinotaurCopier|ord|" name prefix and would otherwise be
                        // picked up again on the target account's own subscription.
                        if (!string.IsNullOrEmpty(order.OrderName)
                            && order.OrderName.StartsWith("Finotaur", StringComparison.Ordinal))
                        {
                            return;
                        }

                        bool enqueued = _orderQueue.TryAdd(new OrderCopyJob
                        {
                            SourceOrder = order,
                            Route       = liveRoute,
                            Config      = cfg
                        });

                        if (!enqueued)
                        {
                            _log($"ORDER HOT PATH: order queue full — dropping order " +
                                 $"'{order.OrderId}' on '{order.InstrumentName}'. " +
                                 "This indicates the order consumer is falling behind; " +
                                 "investigate if this happens frequently.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Order callbacks must NEVER throw — NT may crash the connection.
                        _log($"ORDER HOT PATH exception for order '{order?.OrderId}': " +
                             $"{ex.GetType().Name} — {ex.Message}");
                    }
                    // -------- ORDER HOT PATH END --------
                });

                if (orderSubHandle != null)
                {
                    _orderSubscriptions[route.Id] = orderSubHandle;
                    _log($"Subscribed order-mirroring for route '{route.Label}' → source account '{sourceAccount}'.");
                }
                else
                {
                    _log($"Failed to subscribe order-mirroring for route '{route.Label}' — " +
                         $"SubscribeOrders returned null for '{sourceAccount}'.");
                }

                // ------------------------------------------------------------------
                // Latency instrumentation: subscribe each active target account for
                // follower-fill latency (OnTargetFill = t3).  Uses the SAME resolution
                // logic as PlaceTargetOrderCore STEP 1 to find the NT account name.
                // Only subscribes once per target account (tracked in _targetFillSubs).
                // Fail-safe: any exception here is swallowed — this is additive only.
                // ------------------------------------------------------------------
                foreach (var target in route.Targets ?? new List<CopierTarget>())
                {
                    if (!target.IsActive) continue;

                    try
                    {
                        // Resolve target account name using the same STEP 1 logic.
                        string targetAcct = null;
                        if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
                        {
                            targetAcct = _platform.ResolveAccountByName(target.DestinationAccountName);
                        }
                        else if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
                        {
                            BrokerConnection destConn = FindConnection(config, target.DestinationConnectionId);
                            if (destConn != null)
                                targetAcct = _platform.ResolveAccountName(destConn);
                        }

                        if (targetAcct == null) continue;

                        // Subscribe once per resolved target account name.
                        if (_targetFillSubs.ContainsKey(targetAcct)) continue;

                        object latencyHandle = _platform.SubscribeFills(targetAcct, OnTargetFill);
                        if (latencyHandle != null)
                        {
                            _targetFillSubs[targetAcct] = latencyHandle;
                            _log($"Latency: subscribed target account '{targetAcct}' for follower-fill timing.");
                        }
                    }
                    catch (Exception ex)
                    {
                        _log($"Latency: target-fill subscribe error (non-fatal): {ex.Message}");
                    }
                }
            }
        }

        // -----------------------------------------------------------------------
        // ConsumerLoop — runs on a dedicated Task (NOT the NT thread)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Background consumer: dequeues CopyJob objects and fans out orders
        /// to all target accounts concurrently.
        ///
        /// Runs until the CancellationToken is signalled (on Dispose).
        /// All exceptions are caught; the loop never exits on its own.
        /// </summary>
        private void ConsumerLoop()
        {
            _log("CopierEngine consumer loop started.");

            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    // Blocking take — waits for a job, respecting cancellation.
                    CopyJob job = _workerQueue.Take(_cts.Token);
                    ProcessJobAsync(job).GetAwaiter().GetResult();
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown path
                    break;
                }
                catch (Exception ex)
                {
                    // Should not happen; log and continue the loop.
                    _log($"ConsumerLoop unexpected error: {ex.GetType().Name} — {ex.Message}");
                }
            }

            _log("CopierEngine consumer loop stopped.");
        }

        // -----------------------------------------------------------------------
        // ProcessJobAsync — called by consumer, runs off-NT-thread
        // -----------------------------------------------------------------------

        /// <summary>
        /// Processes one CopyJob: resolves target accounts, checks risk rules,
        /// places orders concurrently to all targets, and enqueues ONE aggregated
        /// telemetry event.
        /// </summary>
        private async Task ProcessJobAsync(CopyJob job)
        {
            // Latency instrumentation: t1 — moment this job was dequeued by the consumer.
            long dequeuedTicks = Stopwatch.GetTimestamp();

            FillInfo       fill   = job.SourceFill;
            CopierRoute    route  = job.Route;
            AutomationConfig cfg  = job.Config;

            _log($"Processing copy job: fill '{fill.ExecutionId}' " +
                 $"{(fill.IsBuy ? "BUY" : "SELL")} {fill.Quantity} {fill.InstrumentName} " +
                 $"on '{fill.AccountName}' via route '{route.Label}'.");

            // ------------------------------------------------------------------
            // Tilt pre-snapshot: for CLOSE fills, record the source account's
            // realized PnL BEFORE the fan-out so we can compute the delta after.
            //
            // VERIFY (NT8 API): GetSessionRealizedPnL must return the up-to-date
            // value at the time this line executes — i.e. AFTER the ExecutionUpdate
            // callback has caused NT8 to close the position and book the P&L.
            // The consumer runs off the NT thread (via Task.Run), so there may be
            // a brief race window where NT8 has not yet updated its internal account
            // state.  If the delta is consistently 0 for close fills, NT8's P&L
            // update is asynchronous with respect to the fill callback and this
            // snapshot approach will NOT work — see the TODO note below.
            // ------------------------------------------------------------------
            double preFillRealizedPnL = 0.0;
            if (!fill.IsOpening)
            {
                preFillRealizedPnL = _lastSourceRealizedPnL.GetOrAdd(
                    fill.AccountName,
                    _ => _platform.GetSessionRealizedPnL(fill.AccountName));
            }

            // Build per-target tasks
            var targetResults = new ConcurrentBag<TargetResult>();

            // Fan-out: prepare a Task for each active target
            var targetTasks = new List<Task>();

            foreach (var target in route.Targets ?? new List<CopierTarget>())
            {
                if (!target.IsActive) continue;

                // Capture for closure
                var capturedTarget = target;

                // Capture dequeuedTicks for the closure (same value for all targets in this job).
                long capturedDequeuedTicks = dequeuedTicks;

                targetTasks.Add(Task.Run(async () =>
                {
                    var result = await PlaceTargetOrderAsync(
                        fill, route, capturedTarget, cfg, capturedDequeuedTicks, _cts.Token)
                        .ConfigureAwait(false);
                    targetResults.Add(result);
                }));
            }

            if (targetTasks.Count == 0)
            {
                _log($"Route '{route.Label}': no active targets — nothing to copy.");
                return;
            }

            // Await ALL target placements concurrently.
            // Task.WhenAll does not throw even if individual tasks fail —
            // exceptions are captured inside PlaceTargetOrderAsync and surfaced
            // via TargetResult.Success = false.
            await Task.WhenAll(targetTasks).ConfigureAwait(false);

            // ------------------------------------------------------------------
            // Emit ONE aggregated event (scale requirement: never 1-event-per-target)
            // ------------------------------------------------------------------

            int successCount = targetResults.Count(r => r.Success);
            // NOTE: failCount removed — replaced by realFailCount below, which excludes
            // no-op "no delta" results (Success=false with a non-failure reason).

            // Aggregate per-target summaries — keep payload small.
            // Use DestinationAccountName (server config name) as the primary label;
            // fall back to the resolved NT account name, then the connection ID.
            //
            // FIX #9/#10 (net-position reconciliation): qty now reports the delta
            // actually sent (not a scaled fill qty).  "reason" is non-null both on
            // failure AND on "no delta needed" (Success=true with reason set) so
            // the web can distinguish true failures from no-op reconciles.
            var perTarget = targetResults.Select(r => new
            {
                account  = r.AccountName ?? r.DestinationAccountName,
                delta    = r.Quantity,        // signed delta sent (renamed from qty for clarity)
                qty      = r.Quantity,        // kept for back-compat with web event display
                ok       = r.Success,
                reason   = r.FailureReason    // null only when Success and an order was placed
            }).ToList();

            // A result is a "real failure" (not just a no-op no-delta) when it is
            // !Success AND FailureReason is not one of the no-action reasons.
            int realFailCount = targetResults.Count(r =>
                !r.Success &&
                r.FailureReason != "no delta (already reconciled)" &&
                r.FailureReason != "no effective delta after gating");

            string eventType = realFailCount == 0 ? "copy_executed" : "copy_failed";
            string severity  = realFailCount == 0 ? "info"
                             : (successCount == 0 ? "warning" : "info");

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType          = eventType,
                Severity           = severity,
                // Include the source connection ID for back-compat with existing
                // web event displays; also include the account name for new displays.
                BrokerConnectionId = route.SourceConnectionId,
                Symbol             = fill.InstrumentName,
                Payload            = new
                {
                    execution_id         = fill.ExecutionId,
                    // Source account: prefer the config-level name (what the web
                    // configured), then fall back to the NT fill's account name.
                    source_account       = route.SourceAccountName ?? fill.AccountName,
                    source_account_nt    = fill.AccountName,    // NT-resolved name
                    source_broker        = route.SourceBroker,
                    source_environment   = route.SourceEnvironment,
                    symbol               = fill.InstrumentName,
                    side                 = fill.IsBuy ? "buy" : "sell",
                    source_qty           = fill.Quantity,
                    // FIX #9/#10: is_opening now reflects the fill's IsOpening flag
                    // (still populated by the adapter for tilt tracking / telemetry),
                    // but sizing NO LONGER depends on it.
                    is_opening           = fill.IsOpening,
                    reversed             = route.Reverse,
                    route_id             = route.Id,
                    route_label          = route.Label,
                    reconcile_mode       = true,           // signals web this is a net-reconcile event
                    targets_total        = targetResults.Count,
                    targets_ok           = successCount,
                    targets_failed       = realFailCount,
                    per_target           = perTarget
                }
            });

            _log($"NetReconcile job complete — route '{route.Label}': " +
                 $"{successCount}/{targetResults.Count} targets OK, " +
                 $"{realFailCount} real failures.");

            // ------------------------------------------------------------------
            // Tilt tracking: record fill result for CLOSE fills on the SOURCE
            // account so RiskEnforcer can maintain the consecutive-loss streak.
            //
            // Why source account: tilt is about the human trader going on a losing
            // streak.  The source account is where the human trades; the risk rule
            // that governs that account (matched by route.SourceConnectionId) is
            // the one that carries TiltLossStreak / TiltCooldownMinutes.
            //
            // VERIFY (NT8 API): see pre-snapshot comment above.  If the PnL delta
            // is unreliable (always 0), replace this block with a TODO hook and
            // wire it when NT8 exposes Execution.Profit directly on the fill event.
            // ------------------------------------------------------------------
            if (!fill.IsOpening)
            {
                try
                {
                    await RecordSourceFillTiltAsync(fill, cfg, preFillRealizedPnL, _cts.Token)
                        .ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    // Tilt tracking is bookkeeping — a failure here must never
                    // propagate to the caller or disrupt the copy loop.
                    _log($"RecordSourceFillTiltAsync error (non-fatal): " +
                         $"{ex.GetType().Name} — {ex.Message}");
                }
            }
        }

        // -----------------------------------------------------------------------
        // RecordSourceFillTiltAsync — tilt bookkeeping for close fills
        // -----------------------------------------------------------------------

        /// <summary>
        /// Called after every source close fill.  Computes the realized PnL delta
        /// to determine win/loss, then calls RiskEnforcer.RecordFillResultAsync for
        /// every risk rule that governs the source account.
        ///
        /// Fail-safe: all exceptions are caught by the caller.
        /// </summary>
        private async Task RecordSourceFillTiltAsync(
            FillInfo         fill,
            AutomationConfig cfg,
            double           preFillRealizedPnL,
            CancellationToken ct)
        {
            // FIX #6 (account-level risk): resolve the rule's account using the SAME
            // AccountName-first logic that RiskEnforcer.RunAsync uses.
            // The previous code resolved only via BrokerConnectionId, so rules whose
            // server payload carries account_name (null broker_connection_id) never had
            // their tilt recorded — tilt_loss_streak silently never fired.
            // NOTE: untested in this environment — requires NT8 sim verification before live use.
            string sourceAccount = fill.AccountName;

            foreach (var rule in cfg.RiskRules ?? new List<RiskRule>())
            {
                if (!rule.Enforce || !rule.IsActive) continue;
                if (!rule.TiltLossStreak.HasValue)   continue;   // tilt not configured

                // FIX #6: AccountName-first resolution, BrokerConnectionId fallback.
                BrokerConnection ruleConn = null;
                string ruleAccount = null;

                if (!string.IsNullOrWhiteSpace(rule.AccountName))
                {
                    // Primary: resolve via broker account name (modern server contract).
                    ruleAccount = _platform.ResolveAccountByName(rule.AccountName);
                    // Best-effort: try to find a matching connection for the RecordFillResultAsync
                    // call (used only for event payloads — null is acceptable).
                    ruleConn = FindConnectionByAccountName(cfg, rule.AccountName);
                }
                else
                {
                    // Fallback: legacy broker_connection_id path.
                    ruleConn = FindConnection(cfg, rule.BrokerConnectionId);
                    if (ruleConn != null)
                        ruleAccount = _platform.ResolveAccountName(ruleConn);
                }

                if (ruleAccount == null || !string.Equals(ruleAccount, sourceAccount,
                        StringComparison.OrdinalIgnoreCase)) continue;

                // We have a tilt-enabled rule for the source account.
                // Compute PnL delta to determine win/loss.
                //
                // VERIFY (NT8 API): GetSessionRealizedPnL must reflect the P&L of
                // THIS fill by the time we call it here.  If NT8 updates its account
                // state synchronously before returning from ExecutionUpdate (i.e.
                // before the fill was enqueued), then postFill == preFill because the
                // pre-snapshot was already taken after the P&L update.  In that case,
                // swap preFillRealizedPnL to be captured in the hot-path callback
                // (before enqueue) and postFillRealizedPnL here (after fan-out), OR
                // use a per-position average-entry-price tracker to compute trade P&L
                // directly from fill.Price.
                //
                // TODO (NT8 API — if delta is always 0): implement a lightweight
                // PositionTracker that records average entry price per account+symbol,
                // then computes realized P&L from (fill.Price - avgEntry) * qty *
                // pointValue when a close fill arrives.  Wire that here instead of
                // the GetSessionRealizedPnL delta.
                double postFillRealizedPnL = _platform.GetSessionRealizedPnL(sourceAccount);
                double pnlDelta            = postFillRealizedPnL - preFillRealizedPnL;

                // Update the stored baseline for the next fill's pre-snapshot.
                _lastSourceRealizedPnL[sourceAccount] = postFillRealizedPnL;

                bool wasLoss;
                if (pnlDelta == 0.0)
                {
                    // Delta is zero — NT8 P&L update may be asynchronous; we cannot
                    // reliably determine win/loss.  Log and skip this fill rather than
                    // recording a wrong result.
                    //
                    // VERIFY (NT8 API): if this log fires consistently, the delta
                    // approach is not viable.  Implement the PositionTracker TODO above.
                    _log($"TiltTracker: PnL delta = 0 for close fill '{fill.ExecutionId}' " +
                         $"on '{sourceAccount}' — cannot determine win/loss. " +
                         "Skipping tilt recording for this fill. " +
                         "VERIFY (NT8 API): GetSessionRealizedPnL may not update synchronously.");
                    continue;
                }
                else
                {
                    wasLoss = pnlDelta < 0.0;
                }

                _log($"TiltTracker: close fill '{fill.ExecutionId}' on '{sourceAccount}': " +
                     $"PnL delta = {pnlDelta:+0.00;-0.00} → {(wasLoss ? "LOSS" : "WIN")}.");

                await _risk.RecordFillResultAsync(
                    rule.Id,
                    sourceAccount,
                    wasLoss,
                    rule,
                    ruleConn,
                    ct,
                    pnlDelta: pnlDelta).ConfigureAwait(false);
            }
        }

        // =========================================================================
        // WORKING-ORDER MIRRORING — order consumer + processing
        //
        // ALONGSIDE the fill-copy consumer above (ConsumerLoop / ProcessJobAsync).
        // Mirrors the leader's working (limit/stop/stoplimit) orders onto the
        // followers as their own working orders, so followers fill independently
        // at the same trigger price instead of receiving a market order when the
        // leader fills. See CopierEngine._orderQueue / OnOrderHotPathCallback above.
        // =========================================================================

        /// <summary>
        /// Background consumer for order-mirroring jobs. Dequeues OrderCopyJob
        /// objects and processes them one at a time (mirrors ConsumerLoop's
        /// shape). Runs until the shared CancellationToken is signalled.
        /// All exceptions are caught; the loop never exits on its own.
        /// </summary>
        private void OrderConsumerLoop()
        {
            _log("CopierEngine order-mirroring consumer loop started.");

            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    OrderCopyJob job = _orderQueue.Take(_cts.Token);
                    ProcessOrderJob(job);
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown path
                    break;
                }
                catch (Exception ex)
                {
                    // Should not happen; log and continue the loop.
                    _log($"OrderConsumerLoop unexpected error: {ex.GetType().Name} — {ex.Message}");
                }
            }

            _log("CopierEngine order-mirroring consumer loop stopped.");
        }

        /// <summary>
        /// Resolves a CopierTarget to its local NT account name, using the SAME
        /// resolution order as PlaceTargetOrderCore STEP 1 (DestinationAccountName
        /// primary, DestinationConnectionId fallback). Returns null (with the
        /// failure reason via the out parameter) if resolution fails — the caller
        /// MUST skip this target rather than guess.
        /// </summary>
        private string ResolveTargetAccountForOrder(
            CopierTarget target, AutomationConfig cfg, out string failureReason)
        {
            failureReason = null;

            if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
            {
                string acct = _platform.ResolveAccountByName(target.DestinationAccountName);
                if (acct == null)
                {
                    failureReason =
                        $"destination account '{target.DestinationAccountName}' " +
                        "not found in local NT8 — account may not be connected";
                }
                return acct;
            }

            if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
            {
                BrokerConnection destConn = FindConnection(cfg, target.DestinationConnectionId);
                if (destConn == null)
                {
                    failureReason =
                        $"destination connection '{target.DestinationConnectionId}' not in config";
                    return null;
                }
                string acct = _platform.ResolveAccountName(destConn);
                if (acct == null)
                {
                    failureReason =
                        $"no NT account found for connection '{target.DestinationConnectionId}' (fallback)";
                }
                return acct;
            }

            failureReason =
                "target has neither DestinationAccountName nor DestinationConnectionId " +
                "(malformed target config)";
            return null;
        }

        /// <summary>
        /// Processes one OrderCopyJob: decides PLACEMENT / MODIFY / CANCEL /
        /// FILLED-PARTFILLED action from the leader order's State, serialized
        /// under a per-leader-order-id lock so concurrent order-state callbacks
        /// for the same leader order cannot race each other.
        ///
        /// NEVER throws — all exceptions are caught and logged; this runs on the
        /// dedicated order-consumer Task, off the NT thread, but must still never
        /// bring down the consumer loop.
        /// </summary>
        private void ProcessOrderJob(OrderCopyJob job)
        {
            try
            {
                OrderInfo        order = job.SourceOrder;
                CopierRoute      route = job.Route;
                AutomationConfig cfg   = job.Config;

                if (order == null || string.IsNullOrWhiteSpace(order.OrderId))
                {
                    _log("ProcessOrderJob: order or OrderId missing — skipping.");
                    return;
                }

                string leaderOrderId = order.OrderId;
                string state = (order.State ?? string.Empty).ToLowerInvariant();

                object orderLock = _orderLocks.GetOrAdd(leaderOrderId, _ => new object());

                lock (orderLock)
                {
                    bool hasMapping = _mirroredLeaderOrders.TryGetValue(leaderOrderId, out MirroredOrder mapping);

                    switch (state)
                    {
                        case "working":
                        case "accepted":
                        case "submitted":
                            if (!hasMapping)
                            {
                                ProcessOrderPlacement(order, route, cfg, leaderOrderId);
                            }
                            else
                            {
                                // Already mirrored and no material change — treat as a
                                // potential MODIFY candidate too (state transitions like
                                // accepted → working can repeat with the same prices).
                                ProcessOrderModifyIfChanged(order, mapping, leaderOrderId, cfg, route);
                            }
                            break;

                        case "changesubmitted":
                            if (hasMapping)
                            {
                                ProcessOrderModifyIfChanged(order, mapping, leaderOrderId, cfg, route);
                            }
                            else
                            {
                                _log($"ProcessOrderJob: MODIFY-like state '{state}' for leader order " +
                                     $"'{leaderOrderId}' with no mirrored mapping — nothing to modify.");
                            }
                            break;

                        case "cancelled":
                        case "rejected":
                            if (hasMapping)
                            {
                                ProcessOrderCancel(mapping, leaderOrderId, state);
                            }
                            // Leader terminal state — a fully risk-blocked order (no mapping,
                            // so ProcessOrderCancel above did not run) must still clear the
                            // skip-list entry so a genuinely new order reusing this id (or a
                            // resubmitted leader order) is re-evaluated fresh. No-op if absent.
                            _riskBlockedLeaderOrders.TryRemove(leaderOrderId, out _);
                            break;

                        case "filled":
                            if (hasMapping)
                            {
                                // Followers' own working orders fill on their own —
                                // no market order, no cancel. Just stop tracking.
                                _mirroredLeaderOrders.TryRemove(leaderOrderId, out _);
                                _log($"ProcessOrderJob: leader order '{leaderOrderId}' FILLED — " +
                                     "follower working orders left in place to fill independently; " +
                                     "stopped tracking this leader order.");
                            }
                            // Leader terminal state — clear risk-blocked skip-list entry
                            // regardless of hasMapping (safe no-op if absent).
                            _riskBlockedLeaderOrders.TryRemove(leaderOrderId, out _);
                            break;

                        case "partfilled":
                            // Keep the mapping — more fills/modifies/cancels may follow.
                            // Nothing to do here; followers fill on their own.
                            break;

                        default:
                            // "other" or unrecognized state — fail-safe: do nothing.
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ProcessOrderJob exception for order '{job?.SourceOrder?.OrderId}': " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        /// <summary>
        /// PLACEMENT: mirrors a newly-seen leader working order to every active
        /// target on the route. Must be called under the per-leader-order lock.
        ///
        /// NOTE (v2 TODO): async broker rejects of follower orders are invisible
        /// here — PlaceWorkingOrder's Submit() call returns a pre-ack Order.Id;
        /// this engine does not subscribe target accounts, so a later broker-side
        /// rejection of the follower order is never observed or reported. v2:
        /// subscribe targets filtered to our own order names ("FinotaurCopier*")
        /// to catch late rejects.
        /// </summary>
        private void ProcessOrderPlacement(
            OrderInfo order, CopierRoute route, AutomationConfig cfg, string leaderOrderId)
        {
            if (_riskBlockedLeaderOrders.ContainsKey(leaderOrderId))
            {
                _log($"OrderMirror PLACEMENT SKIP (leader '{leaderOrderId}'): previously risk-blocked " +
                     "on all targets — skipping re-placement until a terminal state or config rebuild clears it.");
                return;
            }

            var mirrored = new MirroredOrder
            {
                RouteId       = route.Id,
                LeaderOrderId = leaderOrderId,
                LastLimit     = order.LimitPrice,
                LastStop      = order.StopPrice,
                LastQty       = order.Quantity,
                Tif           = order.Tif,
            };

            var perTarget = new List<object>();
            int targetsOk = 0;
            int targetsTotal = 0;
            bool anyRiskBlocked = false;

            foreach (var target in route.Targets ?? new List<CopierTarget>())
            {
                if (!target.IsActive) continue;
                targetsTotal++;

                string targetDisplayName = !string.IsNullOrWhiteSpace(target.DestinationAccountName)
                    ? target.DestinationAccountName
                    : target.DestinationConnectionId;

                try
                {
                    string targetAccount = ResolveTargetAccountForOrder(target, cfg, out string resolveFailure);
                    if (targetAccount == null)
                    {
                        _log($"OrderMirror PLACEMENT SKIP ({targetDisplayName}): {resolveFailure}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason = resolveFailure });
                        continue;
                    }

                    string instr = TranslateInstrument(order.InstrumentName, target);

                    int qty = (int)Math.Round(order.Quantity * target.ScaleRatio, MidpointRounding.AwayFromZero);
                    if (target.MaxContracts.HasValue && target.MaxContracts.Value > 0 && qty > target.MaxContracts.Value)
                        qty = target.MaxContracts.Value;

                    if (qty <= 0)
                    {
                        string reason = "scaled quantity <= 0 — skipped";
                        _log($"OrderMirror PLACEMENT SKIP ({targetDisplayName}): {reason}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                        continue;
                    }

                    bool isBuy = route.Reverse ? !order.IsBuy : order.IsBuy;

                    // Pre-placement risk gate — same semantics as the fill path (PlaceTargetOrderCore).
                    // NOTE: projects against current POSITION only, not other outstanding working
                    // orders (same approximation as the fill path). Mirrored-order fills do not
                    // count toward max_trades_per_day (v2).
                    //
                    // IRON RULE (2026-07-02 incident): an order that REDUCES exposure (e.g. a
                    // mirrored stop-loss/closing order placed while the follower is already at
                    // its contracts limit) must never be blocked by risk rules. Approximate the
                    // signed order direction from isBuy and compare against the follower's
                    // CURRENT signed net (same GetSignedNetPosition helper the fill path uses
                    // for seeding). This is a placement-time approximation only — the position
                    // can change between placement and fill; the fill-time check in
                    // PlaceTargetOrderCore remains the authoritative gate.
                    int followerSignedNet = GetSignedNetPosition(
                        _platform.GetPositions(targetAccount), instr);
                    int orderSignedQty = isBuy ? qty : -qty;
                    bool reducesExposure = followerSignedNet != 0
                        && Math.Abs(followerSignedNet + orderSignedQty) <= Math.Abs(followerSignedNet);

                    if (!_risk.IsOrderAllowed(targetAccount, instr, qty, cfg.RiskRules, cfg.Connections, reducesExposure))
                    {
                        string reason = "blocked by risk rule";
                        _log($"OrderMirror PLACEMENT BLOCKED ({targetDisplayName} → '{targetAccount}'): {reason}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                        anyRiskBlocked = true;
                        continue;
                    }

                    string ot = order.OrderType; // already validated to be limit/stop/stoplimit/mit by the hot path
                    double limitPrice = 0.0;
                    double stopPrice  = 0.0;
                    if (ot == "limit")
                    {
                        limitPrice = order.LimitPrice;
                    }
                    else if (ot == "stop" || ot == "mit")
                    {
                        // MIT (Market-If-Touched) trigger rides Order.StopPrice, same
                        // field as a plain stop — NT8 convention (see NinjaTraderAdapter
                        // SubscribeOrders/PlaceWorkingOrder for the matching mapping).
                        stopPrice = order.StopPrice;
                    }
                    else // "stoplimit"
                    {
                        limitPrice = order.LimitPrice;
                        stopPrice  = order.StopPrice;
                    }

                    string orderName = $"FinotaurCopier|ord|{leaderOrderId}|{targetAccount}";

                    string followerId = _platform.PlaceWorkingOrder(
                        targetAccount, instr, isBuy, qty, ot, limitPrice, stopPrice, orderName, order.Tif);

                    if (followerId != null)
                    {
                        mirrored.Targets.Add(new MirroredTarget
                        {
                            TargetAccount   = targetAccount,
                            FollowerOrderId = followerId,
                            ScaleRatio      = target.ScaleRatio,
                            MaxContracts    = target.MaxContracts,
                            Instrument      = instr
                        });
                        targetsOk++;
                        _log($"OrderMirror PLACEMENT ({targetDisplayName} → '{targetAccount}'): " +
                             $"placed follower {ot} order '{followerId}' " +
                             $"{(isBuy ? "BUY" : "SELL")} {qty} {instr} " +
                             $"(limit={limitPrice}, stop={stopPrice}, tif={order.Tif}).");
                        perTarget.Add(new { account = targetDisplayName, ok = true, order_id = followerId, qty });
                    }
                    else
                    {
                        string reason = "PlaceWorkingOrder returned null (see NT adapter log)";
                        _log($"OrderMirror PLACEMENT FAILED ({targetDisplayName} → '{targetAccount}'): {reason}.");
                        perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                    }
                }
                catch (Exception ex)
                {
                    string reason = $"{ex.GetType().Name}: {ex.Message}";
                    _log($"OrderMirror PLACEMENT exception ({targetDisplayName}): {reason}");
                    perTarget.Add(new { account = targetDisplayName, ok = false, reason });
                }
            }

            if (mirrored.Targets.Count > 0)
            {
                _mirroredLeaderOrders[leaderOrderId] = mirrored;
                MarkLeaderOrderMirrored(leaderOrderId);
            }
            else if (anyRiskBlocked)
            {
                // No target succeeded and at least one was risk-blocked — remember this
                // leader order so the next OrderUpdate state event (e.g. accepted → working)
                // doesn't re-run placement and re-emit a duplicate order_copy_failed event.
                // Partial successes (mirrored.Targets.Count > 0) already create a mapping
                // above and never reach this branch.
                _riskBlockedLeaderOrders.TryAdd(leaderOrderId, 1);
            }

            string eventType = targetsOk > 0 ? "order_copy_executed" : "order_copy_failed";
            // STEP 4a: any per-target failure downgrades severity to "warning" even
            // when the overall eventType stays order_copy_executed (partial success
            // is still worth flagging — some followers did not get the order).
            string severity  = (targetsTotal - targetsOk) > 0
                ? "warning"
                : (targetsOk > 0 ? "info" : "info");

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType          = eventType,
                Severity           = severity,
                BrokerConnectionId = route.SourceConnectionId,
                Symbol             = order.InstrumentName,
                Payload            = new
                {
                    order_id        = leaderOrderId,
                    source_account  = route.SourceAccountName,
                    symbol          = order.InstrumentName,
                    side            = order.IsBuy ? "buy" : "sell",
                    order_type      = order.OrderType,
                    limit_price     = order.LimitPrice,
                    stop_price      = order.StopPrice,
                    source_qty      = order.Quantity,
                    tif             = order.Tif,
                    reversed        = route.Reverse,
                    route_id        = route.Id,
                    route_label     = route.Label,
                    targets_total   = targetsTotal,
                    targets_ok      = targetsOk,
                    targets_failed  = targetsTotal - targetsOk,
                    per_target      = perTarget
                }
            });

            _log($"OrderMirror PLACEMENT complete — route '{route.Label}': " +
                 $"{targetsOk}/{targetsTotal} targets OK for leader order '{leaderOrderId}'.");
        }

        /// <summary>
        /// MODIFY: if the leader order's price/quantity changed since last seen,
        /// propagate a scaled modify to every mirrored follower order. Must be
        /// called under the per-leader-order lock.
        ///
        /// STEP 3b: quantity INCREASES are gated by the same pre-trade risk check
        /// as placement — a leader adding size to a resting order is economically
        /// equivalent to a new order and must not silently bypass max_contracts /
        /// daily-loss / etc. Quantity DECREASES and price-only changes are NEVER
        /// re-gated — blocking a stop-loss adjustment (or a size reduction) would
        /// strand followers with worse risk than the leader, which is the opposite
        /// of what the gate is for.
        ///
        /// IRON RULE (2026-07-02 incident): even a quantity INCREASE must bypass
        /// the gate if it still reduces the follower's exposure (e.g. enlarging a
        /// stop-loss/closing order to cover a bigger position). `route` is passed
        /// in only to resolve Reverse for the order-side computation — same
        /// isBuy formula ProcessOrderPlacement uses.
        /// </summary>
        private void ProcessOrderModifyIfChanged(
            OrderInfo order, MirroredOrder mapping, string leaderOrderId, AutomationConfig cfg, CopierRoute route)
        {
            bool changed = order.LimitPrice != mapping.LastLimit
                        || order.StopPrice  != mapping.LastStop
                        || order.Quantity   != mapping.LastQty;

            if (!changed) return;

            string ot = order.OrderType;
            var perTarget = new List<object>();
            int targetsOk = 0;

            foreach (var mt in mapping.Targets)
            {
                try
                {
                    // Recompute the follower quantity using the SAME ratio/clamp as
                    // the original placement (snapshotted on MirroredTarget).
                    int scaledQty = (int)Math.Round(order.Quantity * mt.ScaleRatio, MidpointRounding.AwayFromZero);
                    if (mt.MaxContracts.HasValue && mt.MaxContracts.Value > 0 && scaledQty > mt.MaxContracts.Value)
                        scaledQty = mt.MaxContracts.Value;

                    // <=0 to ModifyWorkingOrder means "leave unchanged"; only pass a
                    // new quantity when the LEADER quantity actually changed and the
                    // recomputed follower quantity is valid (>0).
                    int qtyArg = (order.Quantity != mapping.LastQty && scaledQty > 0)
                        ? scaledQty
                        : -1;

                    // STEP 3b: gate ONLY quantity increases. Recompute what the
                    // follower quantity was under the PREVIOUS leader quantity
                    // (mapping.LastQty), using the same ratio/clamp, so we can
                    // isolate the follower-side delta rather than gating the
                    // full new quantity.
                    string qtyBlockReason = null;
                    if (qtyArg > 0)
                    {
                        int prevScaledQty = (int)Math.Round(mapping.LastQty * mt.ScaleRatio, MidpointRounding.AwayFromZero);
                        if (mt.MaxContracts.HasValue && mt.MaxContracts.Value > 0 && prevScaledQty > mt.MaxContracts.Value)
                            prevScaledQty = mt.MaxContracts.Value;

                        int qtyDelta = scaledQty - prevScaledQty;
                        if (qtyDelta > 0)
                        {
                            string gateInstrument = mt.Instrument ?? order.InstrumentName;

                            // IRON RULE: even though qty is increasing, the order may still
                            // be REDUCING the follower's exposure (e.g. a stop-loss/closing
                            // order enlarged to cover a bigger position). Derive the order's
                            // signed direction the same way ProcessOrderPlacement does, and
                            // compare against the follower's CURRENT signed net.
                            bool modifyIsBuy = route != null && route.Reverse ? !order.IsBuy : order.IsBuy;
                            int followerSignedNet = GetSignedNetPosition(
                                _platform.GetPositions(mt.TargetAccount), gateInstrument);
                            int orderSignedQtyDelta = modifyIsBuy ? qtyDelta : -qtyDelta;
                            bool modifyReducesExposure = followerSignedNet != 0
                                && Math.Abs(followerSignedNet + orderSignedQtyDelta) <= Math.Abs(followerSignedNet);

                            if (!_risk.IsOrderAllowed(mt.TargetAccount, gateInstrument, qtyDelta, cfg.RiskRules, cfg.Connections, modifyReducesExposure))
                            {
                                // Suppress the qty change only — price-only changes are
                                // NEVER re-gated (blocking a stop-loss adjustment would
                                // strand followers). Fall through with qtyArg reset so
                                // ModifyWorkingOrder still applies newLimit/newStop below.
                                qtyBlockReason = "qty increase blocked by risk rule — price-only modify applied";
                                qtyArg = -1;
                            }
                        }
                    }

                    double newLimit = (ot == "limit" || ot == "stoplimit")
                        ? (order.LimitPrice != mapping.LastLimit ? order.LimitPrice : -1)
                        : -1;
                    double newStop = (ot == "stop" || ot == "stoplimit" || ot == "mit")
                        ? (order.StopPrice != mapping.LastStop ? order.StopPrice : -1)
                        : -1;

                    bool ok = _platform.ModifyWorkingOrder(mt.TargetAccount, mt.FollowerOrderId, qtyArg, newLimit, newStop);
                    if (ok) targetsOk++;

                    _log($"OrderMirror MODIFY ({mt.TargetAccount}, follower '{mt.FollowerOrderId}'): " +
                         $"qty={qtyArg} limit={newLimit} stop={newStop} → {(ok ? "OK" : "FAILED")}" +
                         (qtyBlockReason != null ? $" [{qtyBlockReason}]" : string.Empty) + ".");

                    perTarget.Add(new
                    {
                        account  = mt.TargetAccount,
                        order_id = mt.FollowerOrderId,
                        ok,
                        reason   = qtyBlockReason ?? (ok ? null : "ModifyWorkingOrder returned false (see NT adapter log)")
                    });
                }
                catch (Exception ex)
                {
                    _log($"OrderMirror MODIFY exception ({mt.TargetAccount}, follower '{mt.FollowerOrderId}'): {ex.Message}");
                    perTarget.Add(new { account = mt.TargetAccount, order_id = mt.FollowerOrderId, ok = false, reason = ex.Message });
                }
            }

            mapping.LastLimit = order.LimitPrice;
            mapping.LastStop  = order.StopPrice;
            mapping.LastQty   = order.Quantity;

            // STEP 4b: same per-target-failure severity rule as PLACEMENT — any
            // target below full success downgrades to "warning".
            string severity = targetsOk < mapping.Targets.Count ? "warning" : "info";

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType = "order_copy_modified",
                Severity  = severity,
                Symbol    = order.InstrumentName,
                Payload   = new
                {
                    order_id       = leaderOrderId,
                    symbol         = order.InstrumentName,
                    order_type     = order.OrderType,
                    limit_price    = order.LimitPrice,
                    stop_price     = order.StopPrice,
                    source_qty     = order.Quantity,
                    route_id       = mapping.RouteId,
                    targets_total  = mapping.Targets.Count,
                    targets_ok     = targetsOk,
                    targets_failed = mapping.Targets.Count - targetsOk,
                    per_target     = perTarget
                }
            });

            _log($"OrderMirror MODIFY complete — leader order '{leaderOrderId}': " +
                 $"{targetsOk}/{mapping.Targets.Count} targets OK.");
        }

        /// <summary>
        /// CANCEL: cancels every mirrored follower order and stops tracking the
        /// leader order. Must be called under the per-leader-order lock. Does
        /// NOT remove the leader order id from _everMirroredOrderIds — that set
        /// must persist so any late fill on this (now-cancelled) leader order
        /// still correctly skips the fill-copy path.
        /// </summary>
        private void ProcessOrderCancel(MirroredOrder mapping, string leaderOrderId, string state)
        {
            var perTarget = new List<object>();
            int targetsOk = 0;

            foreach (var mt in mapping.Targets)
            {
                try
                {
                    bool ok = _platform.CancelWorkingOrder(mt.TargetAccount, mt.FollowerOrderId);
                    if (ok) targetsOk++;

                    _log($"OrderMirror CANCEL ({mt.TargetAccount}, follower '{mt.FollowerOrderId}') " +
                         $"triggered by leader state '{state}': {(ok ? "OK" : "FAILED")}.");

                    perTarget.Add(new
                    {
                        account  = mt.TargetAccount,
                        order_id = mt.FollowerOrderId,
                        ok,
                        reason   = ok ? null : "CancelWorkingOrder returned false (see NT adapter log)"
                    });
                }
                catch (Exception ex)
                {
                    _log($"OrderMirror CANCEL exception ({mt.TargetAccount}, follower '{mt.FollowerOrderId}'): {ex.Message}");
                    perTarget.Add(new { account = mt.TargetAccount, order_id = mt.FollowerOrderId, ok = false, reason = ex.Message });
                }
            }

            _mirroredLeaderOrders.TryRemove(leaderOrderId, out _);

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType = "order_copy_cancelled",
                Severity  = "info",
                Payload   = new
                {
                    order_id       = leaderOrderId,
                    leader_state   = state,
                    route_id       = mapping.RouteId,
                    targets_total  = mapping.Targets.Count,
                    targets_ok     = targetsOk,
                    targets_failed = mapping.Targets.Count - targetsOk,
                    per_target     = perTarget
                }
            });

            _log($"OrderMirror CANCEL complete — leader order '{leaderOrderId}' (state '{state}'): " +
                 $"{targetsOk}/{mapping.Targets.Count} follower cancels OK.");
        }

        // -----------------------------------------------------------------------
        // PlaceTargetOrderAsync — one target account
        // -----------------------------------------------------------------------

        /// <summary>
        /// FIX #9/#10 (net-position reconciliation): replaces fill-by-fill mirroring.
        /// Self-heals divergence; removes IsOpening dependency.
        ///
        /// Resolves the target account, reads source and target net positions,
        /// computes the desired target net, gates by CopyOpens/CopyCloses, checks
        /// risk rules, and places ONE delta order if needed.
        ///
        /// Returns a TargetResult describing the outcome.
        /// NEVER throws — all exceptions are caught and returned as failures.
        /// </summary>
        private Task<TargetResult> PlaceTargetOrderAsync(
            FillInfo        fill,
            CopierRoute     route,
            CopierTarget    target,
            AutomationConfig cfg,
            long            dequeuedTicks,
            CancellationToken ct)
        {
            // NOTE: this method was originally async but has no awaits after the
            // net-reconciliation rewrite.  It is now a synchronous method returning
            // Task.FromResult — callers (ProcessJobAsync via Task.WhenAll) see no
            // difference; the fan-out concurrency is preserved by Task.Run in the caller.
            return Task.FromResult(PlaceTargetOrderCore(fill, route, target, cfg, dequeuedTicks));
        }

        private TargetResult PlaceTargetOrderCore(
            FillInfo        fill,
            CopierRoute     route,
            CopierTarget    target,
            AutomationConfig cfg,
            long            dequeuedTicks)
        {
            // ================================================================
            // KNOWN RESIDUALS — verify in NT8 sim before live use (FIX F)
            // ================================================================
            //
            // 1. NT position-store timing for SourceNetAtFill (FIX A residual):
            //    SourceNetAtFill is captured inside the NT ExecutionUpdate callback
            //    at fill time, in the same Account.Positions read that computes
            //    IsOpening. Both fields share one lock block. HOWEVER: it is still
            //    an NT8 API timing assumption that Account.Positions has been updated
            //    by NT8 before it fires ExecutionUpdate. Verify in NT8 sim by checking
            //    that SourceNetAtFill matches the post-fill position shown in the
            //    Accounts window.
            //
            // 2. Dropped-last-fill / late-flat scenario:
            //    If the LAST fill in a sequence is dropped (worker queue full) and
            //    the source then goes flat with no further fills, the target can stay
            //    open indefinitely. The idempotency set consumes the ExecutionId, so
            //    only a subsequent fill on a NEW ExecutionId will trigger a reconcile
            //    that heals the divergence. If the source never trades again, the
            //    target remains open. Monitor for this in long-quiet sessions.
            //
            // 3. MaxContracts == 0 means "no cap":
            //    The clamp `if (target.MaxContracts > 0)` treats 0 as uncapped.
            //    A misconfigured MaxContracts=0 silently disables the cap, potentially
            //    allowing an unbounded position. Verify server-side that MaxContracts
            //    is always > 0 when a cap is intended.
            //
            // 4. Cross-mapped instrument FullName must exactly match NT's position FullName:
            //    TranslateInstrument produces e.g. "MNQ 09-26" from "NQ 09-26".
            //    GetPositions() uses pos.Instrument.FullName for matching. If NT8
            //    uses a different canonical form for the micro contract (e.g. "Micro
            //    E-mini NASDAQ-100 09-26"), the target-net seed will always read 0
            //    (flat) and the first-touch seed will be wrong. Verify by logging
            //    pos.Instrument.FullName from GetPositions() for the micro contract
            //    in NT8 sim.
            // ================================================================

            // The "display name" for this target in logs and the aggregated event:
            // prefer the server-config account name, fall back to the connection ID.
            string targetDisplayName = !string.IsNullOrWhiteSpace(target.DestinationAccountName)
                ? target.DestinationAccountName
                : target.DestinationConnectionId;

            var result = new TargetResult
            {
                DestinationAccountName = targetDisplayName,
                Quantity               = 0,
                Success                = false
            };

            try
            {
                // ================================================================
                // STEP 1 — Resolve target account → local NT account name
                // ================================================================
                //
                // Resolution order (mirrors ApplyConfig source resolution):
                //   1. target.DestinationAccountName → ResolveAccountByName()  (primary)
                //   2. target.DestinationConnectionId → FindConnection() +
                //                                       ResolveAccountName()   (fallback)
                string targetAccount = null;

                if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    targetAccount = _platform.ResolveAccountByName(target.DestinationAccountName);
                    if (targetAccount == null)
                    {
                        result.FailureReason =
                            $"destination account '{target.DestinationAccountName}' " +
                            "not found in local NT8 — account may not be connected";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
                {
                    // Fallback: older server response without account_name field.
                    BrokerConnection destConn = FindConnection(cfg, target.DestinationConnectionId);
                    if (destConn == null)
                    {
                        result.FailureReason =
                            $"destination connection '{target.DestinationConnectionId}' not in config";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                    targetAccount = _platform.ResolveAccountName(destConn);
                    if (targetAccount == null)
                    {
                        result.FailureReason =
                            $"no NT account found for connection '{target.DestinationConnectionId}' (fallback)";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                    _log($"Target '{targetDisplayName}': resolved via legacy connection-id " +
                         $"fallback → NT account '{targetAccount}'.");
                }
                else
                {
                    result.FailureReason =
                        "target has neither DestinationAccountName nor DestinationConnectionId " +
                        "(malformed target config)";
                    _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                    return result;
                }

                result.AccountName = targetAccount;

                // ================================================================
                // STEP 2 — Translate instrument (CrossToMicro)
                // ================================================================
                //
                // Compute the translated instrument name BEFORE reading the target
                // net — the tracker key and the NT position read both use the
                // TRANSLATED instrument (the one we actually hold on the target).
                string targetInstrumentName = TranslateInstrument(fill.InstrumentName, target);

                // ================================================================
                // STEP 3 — Read SOURCE net position (authoritative truth)
                // ================================================================
                //
                // FIX A: use fill.SourceNetAtFill — the signed net captured by the
                // NT adapter inside the ExecutionUpdate callback, in the same
                // Account.Positions lock block that computes IsOpening.  This avoids
                // the race where reading GetPositions(fill.AccountName) off-thread
                // (here in the consumer) could see a stale NT position store.
                //
                // DO NOT call GetPositions(fill.AccountName) here — the consumer
                // runs asynchronously from the fill callback and NT may not have
                // updated Account.Positions by the time this line executes.
                //
                // FIX A: source net captured in the NT execution callback (same
                // context as IsOpening) — NOT re-read off-thread. RESIDUAL: still
                // assumes NT has updated Account.Positions by the time
                // ExecutionUpdate fires for this fill; this is an NT-API timing
                // assumption that MUST be verified in NT8 sim.
                int sourceNet = fill.SourceNetAtFill;

                // ================================================================
                // STEP 4 — Compute desired target net
                // ================================================================
                //
                // FIX D: use MidpointRounding.AwayFromZero so that a source-net of
                // 1 with ScaleRatio = 0.5 produces desired = 1 (not 0 from banker's
                // rounding / ToEven).  Without this, a 50%-scaled single-contract
                // source would leave the target permanently flat.
                // A genuinely-zero product (sourceNet == 0 OR ratio == 0) still
                // yields 0 — that correct flat behavior is preserved.
                // NOTE: we do NOT apply Math.Max(1, ...) — a source-flat position
                // (sourceNet == 0) MUST produce desired = 0 (flat), not desired = 1.
                // That was a root cause of the systematic over-fill in FIX #9.
                int desired = (int)Math.Round(sourceNet * target.ScaleRatio,
                                              MidpointRounding.AwayFromZero);

                // Apply Reverse flag: flip the sign of the desired net.
                if (route.Reverse)
                    desired = -desired;

                // Clamp magnitude to MaxContracts (preserve sign). Null = no cap.
                if (target.MaxContracts.HasValue && target.MaxContracts.Value > 0)
                {
                    int cap = target.MaxContracts.Value;
                    if (desired > cap)
                        desired = cap;
                    else if (desired < -cap)
                        desired = -cap;
                }

                // ================================================================
                // STEP 5 — Tracker key + per-key lock
                // ================================================================

                string trackerKey = $"{targetAccount}|{targetInstrumentName}";
                object keyLock    = _netLocks.GetOrAdd(trackerKey, _ => new object());

                // ================================================================
                // STEP 6/7 — Seed (first touch) + compute delta + gate + order
                //            Gating and order logic run inside the per-key lock.
                //            Seeding uses double-checked locking (FIX C) so that
                //            GetPositions() is NOT called while holding the lock.
                // ================================================================
                //
                // Seeding: if this is the first time we touch this (target, instrument)
                // pair — e.g. on agent startup or after a config reload — read the ACTUAL
                // current NT position on the target account and use that as the starting
                // expected value.  This makes pre-existing positions and restarts safe.
                //
                // FIX C (double-checked locking): GetPositions(targetAccount) can
                // potentially stall if NT's position API is slow or its internal lock
                // is contended.  We must NOT hold keyLock across that call — if it
                // hangs, the entire per-(target, instrument) consumer stalls.
                // Instead: check ContainsKey outside the lock; read GetPositions outside
                // the lock; then re-check ContainsKey inside the lock before writing.
                // This eliminates the lock-acquisition-with-blocking-call pattern.
                //
                // IN-FLIGHT note: expected is advanced on submit success, not fill
                // confirmation.  On liquid futures, market orders fill ~instantly; if a
                // target order is slow, a rapid next reconcile could read a stale NT net
                // — but we reconcile against `expected` (submitted-intent), not raw NT
                // net, EXCEPT on this first-touch seeding.  Verify under rapid-fire fills.
                //
                // NOTE: untested in this environment — REQUIRES NT8 sim verification
                // on a non-funded account before any live use.
                //
                // All gating logic runs INSIDE the per-key lock so that concurrent
                // reconciles for the same (target, instrument) see a consistent view.
                // effectiveDelta is declared and used entirely within the lock block.

                // FIX C: read the seed value BEFORE acquiring the lock, so
                // GetPositions() is never called while keyLock is held.
                // If two threads race to seed the same key, the second thread's
                // ContainsKey re-check inside the lock will find the key already
                // set and skip the write — no double-seed, no stale overwrite.
                int seedValue = 0;
                bool needsSeed = !_expectedTargetNet.ContainsKey(trackerKey);
                if (needsSeed)
                {
                    // Read actual NT position for this target account outside the lock.
                    seedValue = GetSignedNetPosition(
                        _platform.GetPositions(targetAccount), targetInstrumentName);
                }

                lock (keyLock)
                {
                    // ---- Seed on first touch (FIX C double-checked) ----
                    if (!_expectedTargetNet.ContainsKey(trackerKey))
                    {
                        // Another thread may have seeded between our outer check and
                        // acquiring the lock — ContainsKey here is the definitive gate.
                        _expectedTargetNet[trackerKey] = seedValue;
                        _log($"NetReconcile SEED [{trackerKey}]: actual NT net = {seedValue}.");
                    }

                    int effectiveDelta;
                    int expected = _expectedTargetNet[trackerKey];
                    int rawDelta = desired - expected;

                    if (rawDelta == 0)
                    {
                        // Target is already where it should be — nothing to do.
                        _log($"NetReconcile [{trackerKey}]: desired={desired} == expected={expected} " +
                             "— no order needed.");
                        result.Success = true; // not a failure — just no action required
                        result.FailureReason = "no delta (already reconciled)";
                        return result;
                    }

                    // ---- CopyOpens / CopyCloses gating -------------------------
                    //
                    // FIX #9/#10: derived from magnitude change (NOT from fill.IsOpening).
                    //
                    // Definitions (relative to expected, which is our committed target net):
                    //   OPENING delta   = |desired| > |expected|  (exposure increasing)
                    //   CLOSING delta   = |desired| < |expected|  (exposure decreasing toward flat)
                    //
                    // Cross-zero case: desired and expected have opposite signs (both non-zero).
                    // This is a close-through-flat then re-open.  We handle it by computing
                    // an effectiveDesired that respects the gates:
                    //   1. If !CopyCloses → skip entirely (we cannot even reach flat).
                    //   2. If CopyCloses but !CopyOpens → effectiveDesired = 0 (reduce to flat only).
                    //   3. If both true → effectiveDesired = desired (full delta allowed).
                    // Then delta = effectiveDesired - expected.

                    int absExpected = Math.Abs(expected);
                    int absDesired  = Math.Abs(desired);
                    bool isOpeningDelta = absDesired > absExpected;
                    bool isClosingDelta = absDesired < absExpected;
                    bool crossesZero    = expected != 0 && desired != 0
                                         && Math.Sign(expected) != Math.Sign(desired);

                    int effectiveDesired;

                    if (crossesZero)
                    {
                        // Close-through-flat scenario.
                        if (!route.CopyCloses)
                        {
                            // Cannot close the existing leg → skip entirely.
                            // FIX B: was missing $ prefix; braces were logged literally.
                            _log($"NetReconcile [{trackerKey}]: cross-zero skipped — " +
                                 $"CopyCloses=false; expected={expected} desired={desired}.");
                            result.FailureReason = "cross-zero skipped: CopyCloses=false";
                            return result;
                        }
                        else if (!route.CopyOpens)
                        {
                            // Can close to flat but cannot re-open the new side.
                            effectiveDesired = 0;
                            // FIX B: was missing $ prefix; braces were logged literally.
                            _log($"NetReconcile [{trackerKey}]: cross-zero — closing to flat only " +
                                 $"(CopyOpens=false); expected={expected} desired={desired} " +
                                 "effectiveDesired=0.");
                        }
                        else
                        {
                            // Both gates open — full delta allowed.
                            effectiveDesired = desired;
                        }
                    }
                    else if (isOpeningDelta && !route.CopyOpens)
                    {
                        // Exposure is increasing but CopyOpens is disabled → skip.
                        _log($"NetReconcile [{trackerKey}]: opening delta skipped — " +
                             $"CopyOpens=false; expected={expected} desired={desired}.");
                        result.FailureReason = "opening delta skipped: CopyOpens=false";
                        return result;
                    }
                    else if (isClosingDelta && !route.CopyCloses)
                    {
                        // Exposure is decreasing but CopyCloses is disabled → skip.
                        _log($"NetReconcile [{trackerKey}]: closing delta skipped — " +
                             $"CopyCloses=false; expected={expected} desired={desired}.");
                        result.FailureReason = "closing delta skipped: CopyCloses=false";
                        return result;
                    }
                    else
                    {
                        // Both flags active or flags match the direction — full delta.
                        effectiveDesired = desired;
                    }

                    effectiveDelta = effectiveDesired - expected;

                    if (effectiveDelta == 0)
                    {
                        // After gating, nothing to send (e.g. cross-zero clamped to flat
                        // and expected was already 0).
                        _log($"NetReconcile [{trackerKey}]: effective delta = 0 after gating — " +
                             "no order needed.");
                        result.Success = true;
                        result.FailureReason = "no effective delta after gating";
                        return result;
                    }

                    // ================================================================
                    // STEP 8 — Pre-trade risk check
                    // ================================================================
                    //
                    // Preserve existing risk check — IsOrderAllowed checks max_contracts,
                    // daily_loss, max_trades_per_day, and tilt cooldown.
                    // If blocked → skip (do NOT update expected).
                    //
                    // IRON RULE (2026-07-02 incident): an order that REDUCES exposure
                    // (moves the signed net closer to flat, e.g. a closing copy of a
                    // leader flatten) must never be blocked by risk rules — this is the
                    // authoritative fill-time check, computed from the exact signed
                    // values (expected, effectiveDelta) this reconcile already derived.
                    bool reducesExposure = expected != 0
                        && Math.Abs(expected + effectiveDelta) <= Math.Abs(expected);

                    bool allowed = _risk.IsOrderAllowed(
                        targetAccount,
                        targetInstrumentName,
                        Math.Abs(effectiveDelta),
                        cfg.RiskRules,
                        cfg.Connections,
                        reducesExposure);

                    if (!allowed)
                    {
                        result.FailureReason = "blocked by risk rule";
                        _log($"NetReconcile [{trackerKey}]: order BLOCKED by risk rule. " +
                             "Expected NOT updated (next reconcile will retry).");
                        return result;
                    }

                    // ================================================================
                    // STEP 9 — Place order
                    // ================================================================

                    bool orderIsBuy = effectiveDelta > 0;
                    int  orderQty   = Math.Abs(effectiveDelta);

                    result.Quantity = orderQty;

                    _log($"NetReconcile [{trackerKey}]: placing {(orderIsBuy ? "BUY" : "SELL")} " +
                         $"{orderQty} {targetInstrumentName} on '{targetAccount}' " +
                         $"(sourceNet={sourceNet} desired={desired} expected={expected} " +
                         $"effectiveDelta={effectiveDelta})" +
                         (targetInstrumentName != fill.InstrumentName
                             ? $" (cross from '{fill.InstrumentName}')"
                             : string.Empty) + ".");

                    // Latency instrumentation: generate a unique 8-char token and embed it
                    // in the order name so we can correlate the follower fill back to this copy.
                    // submitStart/submitEnd straddle ONLY the PlaceMarketOrder call.
                    string copyToken   = Guid.NewGuid().ToString("N").Substring(0, 8);
                    string copyOrderNm = "FinotaurCopier|" + copyToken;
                    long   submitStart = Stopwatch.GetTimestamp();

                    // FIX E: PlaceMarketOrder NEVER throws — NinjaTraderAdapter wraps
                    // every code path in try/catch and returns false on any exception
                    // (see NinjaTraderAdapter.PlaceMarketOrder). No additional try/catch
                    // is needed here. _expectedTargetNet is advanced ONLY on a
                    // confirmed `true` return below, never on `false` or an exception
                    // (there can be no exception here, per the invariant above).
                    // If a future adapter implementation CAN throw, this method's outer
                    // try/catch (at the bottom of PlaceTargetOrderCore) will catch it,
                    // log it, and return a failure result — expected is NOT advanced
                    // because we will have returned before reaching STEP 10.
                    bool submitted = _platform.PlaceMarketOrder(
                        targetAccount,
                        targetInstrumentName,
                        orderIsBuy,
                        orderQty,
                        copyOrderNm);

                    long submitEnd = Stopwatch.GetTimestamp();

                    if (!submitted)
                    {
                        // PlaceMarketOrder failed: do NOT advance expected.
                        // SELF-HEALING: the next source fill will recompute sourceNet
                        // from NT truth and retry the outstanding delta automatically.
                        result.FailureReason = "PlaceMarketOrder returned false (see NT adapter log)";
                        _log($"NetReconcile [{trackerKey}]: PlaceMarketOrder FAILED — " +
                             "expected NOT updated; next reconcile will retry (self-healing).");
                        return result;
                    }

                    // ================================================================
                    // STEP 10 — Advance expected on successful submit
                    // ================================================================
                    //
                    // We advance expected by effectiveDelta (the amount we actually
                    // sent), NOT by (desired - expected) which could differ if gating
                    // clamped effectiveDesired.  This ensures expected always reflects
                    // what we have actually submitted.
                    //
                    // IN-FLIGHT note: expected is advanced on submit, not fill.
                    // On liquid futures this is fine; verify under rapid-fire fills.
                    _expectedTargetNet[trackerKey] = expected + effectiveDelta;

                    _log($"NetReconcile [{trackerKey}]: expected advanced " +
                         $"{expected} → {expected + effectiveDelta}.");

                    // ================================================================
                    // Latency instrumentation: register the pending timing record now
                    // that the order was successfully submitted. Fail-safe — any error
                    // here must NOT prevent STEP 11 or the success result from running.
                    // ================================================================
                    try
                    {
                        if (_pendingTimings.Count < MaxPendingTimings)
                        {
                            _pendingTimings[copyToken] = new CopyTiming
                            {
                                LeaderExecId         = fill.ExecutionId,
                                LeaderExecTime       = fill.Timestamp,
                                LeaderCapturedTicks  = fill.CapturedTicks,
                                DequeuedTicks        = dequeuedTicks,
                                SubmitStartTicks     = submitStart,
                                SubmitEndTicks       = submitEnd,
                                TargetAccount        = targetAccount,
                                Instrument           = targetInstrumentName,
                                Delta                = effectiveDelta,
                                RouteLabel           = route.Label,
                                RegisteredTicks      = submitEnd
                            };
                        }

                        // Age purge: drop any pending timing older than 60s
                        // (follower fill never arrived — e.g. order rejected).
                        long cutoff = Stopwatch.GetTimestamp() - (long)(Stopwatch.Frequency * 60);
                        foreach (var kv in _pendingTimings)
                        {
                            if (kv.Value.RegisteredTicks < cutoff)
                                _pendingTimings.TryRemove(kv.Key, out _);
                        }
                    }
                    catch (Exception ex)
                    {
                        _log($"Latency: pending-timing register failed (non-fatal): {ex.Message}");
                    }

                    // ================================================================
                    // STEP 11 — Update risk counters AFTER successful placement
                    // ================================================================
                    //
                    // Increment copier-opens counter only when the delta is OPENING
                    // (exposure increasing) — so max_trades_per_day counts entries,
                    // not reconciles to flat.
                    //
                    // FIX #6 (account-level risk): AccountName-first resolution,
                    // BrokerConnectionId fallback — same logic as RiskEnforcer.RunAsync.
                    // NOTE: untested in this environment — requires NT8 sim verification.
                    bool isOpeningOrder = Math.Abs(expected + effectiveDelta) > Math.Abs(expected);
                    if (isOpeningOrder)
                    {
                        foreach (var rule in cfg.RiskRules ?? new List<RiskRule>())
                        {
                            if (!rule.Enforce || !rule.IsActive) continue;

                            string ruleAccount = null;
                            if (!string.IsNullOrWhiteSpace(rule.AccountName))
                            {
                                // Primary: resolve via broker account name.
                                ruleAccount = _platform.ResolveAccountByName(rule.AccountName);
                            }
                            else
                            {
                                // Fallback: legacy broker_connection_id path.
                                BrokerConnection ruleConn = FindConnection(cfg, rule.BrokerConnectionId);
                                if (ruleConn != null)
                                    ruleAccount = _platform.ResolveAccountName(ruleConn);
                            }

                            if (ruleAccount != null && string.Equals(ruleAccount, targetAccount,
                                    StringComparison.OrdinalIgnoreCase))
                            {
                                _risk.IncrementCopierOpens(rule.Id, targetAccount);
                            }
                        }
                    }

                    result.Success = true;

                } // end lock(keyLock)

                return result;
            }
            catch (Exception ex)
            {
                result.FailureReason = $"{ex.GetType().Name}: {ex.Message}";
                _log($"PlaceTargetOrderCore exception for target " +
                     $"'{result.DestinationAccountName}': {ex.Message}");
                return result;
            }
        }

        // -----------------------------------------------------------------------
        // TicksToMs — latency math helper
        // -----------------------------------------------------------------------

        /// <summary>
        /// Converts a Stopwatch tick delta to milliseconds using the process-wide
        /// monotonic frequency. Inline helper for latency math — keeps all
        /// instrumentation paths consistent and avoids repetition.
        /// </summary>
        private static double TicksToMs(long ticks)
            => (ticks * 1000.0) / Stopwatch.Frequency;

        // -----------------------------------------------------------------------
        // OnTargetFill — follower-fill callback for latency resolution (t3)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Invoked when a fill arrives on a TARGET (follower) account.
        /// Matches the fill back to a pending CopyTiming via the order-name token,
        /// computes the 4-stage copy latency, and enqueues a 'copy_latency' event.
        ///
        /// FAIL-SAFE: this method must NEVER throw. It runs on the NT ExecutionUpdate
        /// thread; any exception here could disrupt order flow. All logic is wrapped
        /// in a top-level try/catch.
        /// </summary>
        private void OnTargetFill(FillInfo fill)
        {
            try
            {
                // Only care about fills that carry our copy-order token.
                if (string.IsNullOrEmpty(fill.OrderName)) return;
                if (!fill.OrderName.StartsWith("FinotaurCopier|", StringComparison.Ordinal)) return;

                // Extract token: everything after the first '|'.
                int pipeIdx = fill.OrderName.IndexOf('|');
                if (pipeIdx < 0 || pipeIdx >= fill.OrderName.Length - 1) return;
                string token = fill.OrderName.Substring(pipeIdx + 1);

                // Remove the pending timing record (first follower fill wins; dedupes partials).
                CopyTiming t;
                if (!_pendingTimings.TryRemove(token, out t)) return;

                // Compute 4-stage latency using monotonic ticks.
                double queue_ms           = TicksToMs(t.DequeuedTicks   - t.LeaderCapturedTicks);
                double submit_ms          = TicksToMs(t.SubmitEndTicks   - t.SubmitStartTicks);
                double fill_ms            = TicksToMs(fill.CapturedTicks - t.SubmitEndTicks);
                double total_ms           = TicksToMs(fill.CapturedTicks - t.LeaderCapturedTicks);
                // Wall-clock delta between leader exec time and follower exec time (same NT8 clock).
                double broker_fill_lag_ms = (fill.Timestamp - t.LeaderExecTime).TotalMilliseconds;

                // NOTE: we emit under the already-allowed 'agent_status' event_type
                // (the edge fn VALID_EVENT_TYPES set + the automation_events CHECK
                // constraint reject unknown types). The payload 'kind' marker
                // identifies these as latency telemetry — query with
                //   event_type='agent_status' AND payload->>'kind'='copy_latency'.
                _eventQueue.Enqueue(new AutomationEvent
                {
                    EventType = "agent_status",
                    Severity  = "info",
                    Symbol    = fill.InstrumentName,
                    Payload   = new
                    {
                        kind                = "copy_latency",
                        leader_exec_id      = t.LeaderExecId,
                        route_label         = t.RouteLabel,
                        target_account      = t.TargetAccount,
                        instrument          = t.Instrument,
                        delta               = t.Delta,
                        queue_ms            = Math.Round(queue_ms,           2),
                        submit_ms           = Math.Round(submit_ms,          2),
                        fill_ms             = Math.Round(fill_ms,            2),
                        total_ms            = Math.Round(total_ms,           2),
                        broker_fill_lag_ms  = Math.Round(broker_fill_lag_ms, 2),
                        leader_exec_time    = t.LeaderExecTime.ToString("o"),
                        follower_exec_time  = fill.Timestamp.ToString("o")
                    }
                });

                _log($"CopyLatency [{token}] target='{t.TargetAccount}' " +
                     $"total={Math.Round(total_ms, 2)}ms broker_lag={Math.Round(broker_fill_lag_ms, 2)}ms.");
            }
            catch (Exception ex)
            {
                // Latency instrumentation must never disrupt order flow.
                _log($"OnTargetFill latency error (non-fatal): {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // GetSignedNetPosition — helper used by net reconciliation
        // -----------------------------------------------------------------------

        /// <summary>
        /// Converts the raw AgentPosition array for a given instrument to a signed
        /// net contract count:  positive = long,  negative = short,  0 = flat.
        ///
        /// Matching is case-insensitive on InstrumentName (e.g. "NQ 09-26").
        /// Returns 0 if no matching position is found (flat).
        ///
        /// FIX #9/#10 (net-position reconciliation): this is the central read used
        /// to determine both source truth and (on first-touch seeding) target current
        /// state.  It does NOT throw — a failed platform.GetPositions() call returns
        /// an empty array, which produces 0 (flat), the safe default.
        /// </summary>
        private static int GetSignedNetPosition(AgentPosition[] positions, string instrumentName)
        {
            if (positions == null || string.IsNullOrWhiteSpace(instrumentName))
                return 0;

            foreach (var pos in positions)
            {
                if (string.Equals(pos.InstrumentName, instrumentName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    // AgentPosition.Quantity is always >= 0; sign comes from IsLong.
                    return pos.IsLong ? pos.Quantity : -pos.Quantity;
                }
            }

            return 0; // no open position for this instrument = flat
        }

        // -----------------------------------------------------------------------
        // Idempotency helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Attempts to mark an ExecutionId as processed.
        /// Returns true if this is a NEW id (should process).
        /// Returns false if already seen (duplicate — skip).
        /// Evicts oldest entries when the set exceeds MaxProcessedIds.
        /// </summary>
        private bool TryMarkProcessed(string executionId)
        {
            if (string.IsNullOrWhiteSpace(executionId))
            {
                // Cannot track an empty ID — allow through but log (edge case)
                _log("TryMarkProcessed: fill has no ExecutionId — allowing through. " +
                     "VERIFY (NT8 API): check that ExecutionEventArgs.Execution.ExecutionId is populated.");
                return true;
            }

            // TryAdd returns true only if the key was newly inserted
            if (!_processedIds.TryAdd(executionId, 1))
            {
                // Already seen — duplicate fill (e.g. reconnect replay)
                _log($"Idempotency: duplicate fill '{executionId}' — skipping.");
                return false;
            }

            // Track order of insertion for eviction
            lock (_idEvictionLock)
            {
                _idEvictionQueue.Enqueue(executionId);

                // Evict oldest entries if over cap
                while (_idEvictionQueue.Count > MaxProcessedIds)
                {
                    string oldest = _idEvictionQueue.Dequeue();
                    _processedIds.TryRemove(oldest, out _);
                }
            }

            return true;
        }

        // -----------------------------------------------------------------------
        // Working-order mirroring — ever-mirrored idempotency helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Marks a leader OrderId as having been mirrored via the working-order
        /// path. Structured exactly like TryMarkProcessed's FIFO eviction above.
        /// Safe to call multiple times for the same id (idempotent — TryAdd
        /// simply returns false on repeat). STEP 5: the "was this new" signal
        /// IS now used — SaveCopierState() only runs on a genuine new add, so a
        /// repeat call does not re-serialize the whole set for no reason.
        /// </summary>
        private void MarkLeaderOrderMirrored(string leaderOrderId)
        {
            if (string.IsNullOrWhiteSpace(leaderOrderId)) return;

            if (_everMirroredOrderIds.TryAdd(leaderOrderId, 1))
            {
                lock (_everMirroredEvictionLock)
                {
                    _everMirroredEvictionQueue.Enqueue(leaderOrderId);

                    while (_everMirroredEvictionQueue.Count > MaxEverMirroredOrderIds)
                    {
                        string oldest = _everMirroredEvictionQueue.Dequeue();
                        _everMirroredOrderIds.TryRemove(oldest, out _);
                    }
                }

                // STEP 5 (copier-state persistence): persist on every genuine new
                // mirrored-order id so the fill-skip idempotency set survives an
                // agent restart. Best-effort — see SaveCopierState for I/O safety.
                SaveCopierState();
            }
        }

        /// <summary>
        /// Returns true if the given leader OrderId has ever been mirrored via
        /// the working-order path (subject to the bounded FIFO cap above).
        /// Consulted by the fill-copy hot path to avoid double-copying.
        /// </summary>
        private bool WasLeaderOrderMirrored(string leaderOrderId)
        {
            if (string.IsNullOrWhiteSpace(leaderOrderId)) return false;
            return _everMirroredOrderIds.ContainsKey(leaderOrderId);
        }

        /// <summary>
        /// STEP 5 (copier-state persistence): serializes _everMirroredOrderIds
        /// (oldest→newest, i.e. the eviction queue order) to disk.
        /// Best-effort: any I/O error is logged and swallowed — must not throw
        /// into the trading path. Mirrors RiskEnforcer.SaveState exactly.
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private void SaveCopierState()
        {
            if (_copierStatePath == null) return;

            try
            {
                var snap = new CopierStateSnapshot
                {
                    SavedAtUtc = DateTime.UtcNow.ToString("o")
                };

                lock (_everMirroredEvictionLock)
                {
                    snap.EverMirroredOrderIds.AddRange(_everMirroredEvictionQueue);
                }

                string json = JsonConvert.SerializeObject(snap, Formatting.Indented);
                string dir  = Path.GetDirectoryName(_copierStatePath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                File.WriteAllText(_copierStatePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                // Non-fatal — log and continue.
                _log($"CopierEngine.SaveCopierState: I/O error (non-fatal): " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        /// <summary>
        /// STEP 5 (copier-state persistence): loads previously persisted
        /// _everMirroredOrderIds from disk and rehydrates the in-memory set +
        /// eviction queue (via the existing MarkLeaderOrderMirrored-style
        /// TryAdd + enqueue + over-cap eviction, so the restored state respects
        /// the same bounded FIFO invariant as normal runtime operation).
        ///
        /// Freshness boundary: if the snapshot is older than 7 days, it is
        /// discarded entirely (deleted from disk) rather than restored — a
        /// week-old set of leader OrderIds has essentially zero chance of still
        /// being relevant (NT8 order ids are not stable across that horizon),
        /// so restoring it would only bloat memory for no protective value.
        ///
        /// Only restores the fill-skip idempotency set — modify/cancel tracking
        /// (_mirroredLeaderOrders) is NOT restored (v2); that mapping is cleared
        /// on every ApplyConfig rebuild by design (see ApplyConfig comments) and
        /// was never intended to survive a full agent restart either.
        ///
        /// Best-effort: any I/O or parse error is logged and swallowed.
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private void LoadCopierState()
        {
            if (_copierStatePath == null || !File.Exists(_copierStatePath)) return;

            try
            {
                string json = File.ReadAllText(_copierStatePath, Encoding.UTF8);
                var snap    = JsonConvert.DeserializeObject<CopierStateSnapshot>(json);
                if (snap == null) return;

                if (DateTime.TryParse(snap.SavedAtUtc, null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out DateTime savedAt))
                {
                    if (DateTime.UtcNow - savedAt > TimeSpan.FromDays(7))
                    {
                        _log("CopierEngine.LoadCopierState: persisted copier-state is older than " +
                             "7 days — discarding (deleting file) instead of restoring stale ids.");
                        try { File.Delete(_copierStatePath); } catch { /* best-effort */ }
                        return;
                    }
                }

                int restored = 0;
                foreach (var id in snap.EverMirroredOrderIds ?? new List<string>())
                {
                    if (string.IsNullOrWhiteSpace(id)) continue;

                    if (_everMirroredOrderIds.TryAdd(id, 1))
                    {
                        lock (_everMirroredEvictionLock)
                        {
                            _everMirroredEvictionQueue.Enqueue(id);

                            while (_everMirroredEvictionQueue.Count > MaxEverMirroredOrderIds)
                            {
                                string oldest = _everMirroredEvictionQueue.Dequeue();
                                _everMirroredOrderIds.TryRemove(oldest, out _);
                            }
                        }
                        restored++;
                    }
                }

                if (restored > 0)
                {
                    _log($"WARNING: Copier state restored: {restored} leader order ids for fill-skip; " +
                         "modify/cancel tracking NOT restored (v2).");
                }
            }
            catch (Exception ex)
            {
                _log($"CopierEngine.LoadCopierState: I/O or parse error (non-fatal): " +
                     $"{ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Activity summary (for PairingWindow status display)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns a brief human-readable summary of current copier state.
        /// Called by PairingWindow on UI refresh.
        /// </summary>
        public string GetActivitySummary()
        {
            int activeRoutes = _subscriptions.Count;
            int queueDepth   = _workerQueue.Count;
            int processedIds = _processedIds.Count;

            return $"Routes subscribed: {activeRoutes} | " +
                   $"Worker queue depth: {queueDepth} | " +
                   $"Processed fills (session): {processedIds}";
        }

        // -----------------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Finds a BrokerConnection by ID in the config. Returns null if not found.
        /// </summary>
        private static BrokerConnection FindConnection(AutomationConfig config, string connectionId)
        {
            if (config?.Connections == null || connectionId == null) return null;
            return config.Connections.Find(c =>
                string.Equals(c.Id, connectionId, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// FIX #6 (account-level risk): attempts to find a BrokerConnection whose
        /// AccountId matches the given broker account name string.
        /// Returns null if no match — used only for event payload enrichment when
        /// the rule is AccountName-bound (best-effort, same pattern as RiskEnforcer).
        /// NOTE: untested in this environment — requires NT8 sim verification before live use.
        /// </summary>
        private static BrokerConnection FindConnectionByAccountName(
            AutomationConfig config, string accountName)
        {
            if (config?.Connections == null || string.IsNullOrWhiteSpace(accountName)) return null;
            return config.Connections.Find(c =>
                string.Equals(c.AccountId, accountName, StringComparison.OrdinalIgnoreCase));
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        private bool _disposed;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            // Signal the consumer loop to stop and wait for it to exit.
            _cts.Cancel();
            _workerQueue.CompleteAdding();
            _orderQueue.CompleteAdding();

            try { _consumerTask?.Wait(TimeSpan.FromSeconds(3)); }
            catch { /* best-effort */ }

            try { _orderConsumerTask?.Wait(TimeSpan.FromSeconds(3)); }
            catch { /* best-effort */ }

            // Unsubscribe all source fill handlers
            foreach (var kvp in _subscriptions)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _subscriptions.Clear();

            // WORKING-ORDER MIRRORING: unsubscribe all source order handlers.
            foreach (var kvp in _orderSubscriptions)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _orderSubscriptions.Clear();

            // Latency instrumentation: unsubscribe target fill-latency handlers (best-effort).
            foreach (var kvp in _targetFillSubs)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _targetFillSubs.Clear();
            _pendingTimings.Clear();

            _cts.Dispose();
            _workerQueue.Dispose();
            _orderQueue.Dispose();

            _log("CopierEngine disposed.");
        }
    }
}
