// =============================================================================
// Finotaur Agent — Api/Models.cs
// POCOs that map 1:1 to the JSON shapes returned by the automation-agent
// Supabase edge function. All deserialization uses Newtonsoft.Json, which
// ships with NinjaTrader 8.
//
// VERIFY (NT8 API): NinjaTrader 8 bundles Newtonsoft.Json. If a future NT8
// version removes it, switch to System.Text.Json and annotate properties with
// [JsonPropertyName("...")] instead of [JsonProperty("...")].
// =============================================================================

using System;
using System.Collections.Generic;
using Newtonsoft.Json;          // VERIFY: bundled with NT8

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api
{
    // -------------------------------------------------------------------------
    // Top-level config response (action == 'config')
    // -------------------------------------------------------------------------

    /// <summary>
    /// Root object returned by POST automation-agent {action:'config'}.
    ///
    /// CONFIG VERSIONING (added for scale requirement #4):
    ///   The server supports a cheap "unchanged" response to avoid re-serializing
    ///   large configs on every poll. Two response shapes exist:
    ///
    ///   Shape A — nothing changed since the last poll (unchanged == true):
    ///     { "unchanged": true, "config_version": "...", "master_enabled": bool,
    ///       "kill_switch_engaged": bool, "served_at": "..." }
    ///   Only master_enabled + kill_switch_engaged are populated.
    ///   The agent MUST apply those two flags (safety) but MUST NOT rebuild
    ///   its local config from this response (settings/rules/routes are null).
    ///
    ///   Shape B — full config (unchanged == false, or first poll):
    ///     { "unchanged": false, "config_version": "...", "settings": {...},
    ///       "risk_rules": [...], "copier_routes": [...], "connections": [...],
    ///       "accounts": [...], "master_enabled": bool, "kill_switch_engaged": bool,
    ///       "served_at": "..." }
    ///   The agent rebuilds its local config from this response.
    ///
    ///   The agent sends its last-seen config_version in the request body so the
    ///   server can decide which shape to return. On the very first poll, the
    ///   agent sends null/empty and always receives Shape B.
    /// </summary>
    public class AutomationConfig
    {
        // ------------------------------------------------------------------
        // Config versioning fields (Shape A + Shape B both carry these)
        // ------------------------------------------------------------------

        /// <summary>
        /// When true, the server determined nothing changed since the client's
        /// last-seen config_version. Only master_enabled, kill_switch_engaged,
        /// and served_at are populated in this response — do NOT overwrite the
        /// local settings/rules/routes from a Shape-A response.
        /// </summary>
        [JsonProperty("unchanged")]
        public bool Unchanged { get; set; }

        /// <summary>
        /// Opaque version token assigned by the server. Sent back on the next
        /// request so the server can decide whether to return Shape A or B.
        /// Store this alongside the cached config; do NOT log it.
        /// </summary>
        [JsonProperty("config_version")]
        public string ConfigVersion { get; set; }

        // ------------------------------------------------------------------
        // Safety flags — present in BOTH Shape A and Shape B.
        // The agent ALWAYS applies these, even on unchanged responses.
        // ------------------------------------------------------------------

        /// <summary>
        /// Mirrors AutomationSettings.MasterEnabled but is hoisted to the top
        /// level so the agent can apply it from a cheap Shape-A response without
        /// deserializing the full settings object.
        /// </summary>
        [JsonProperty("master_enabled")]
        public bool MasterEnabled { get; set; }

        /// <summary>
        /// Mirrors AutomationSettings.KillSwitchEngaged. Same hoisting rationale.
        /// </summary>
        [JsonProperty("kill_switch_engaged")]
        public bool KillSwitchEngaged { get; set; }

        // ------------------------------------------------------------------
        // Full config payload — only populated when Unchanged == false (Shape B)
        // ------------------------------------------------------------------

        [JsonProperty("settings")]
        public AutomationSettings Settings { get; set; }

        [JsonProperty("risk_rules")]
        public List<RiskRule> RiskRules { get; set; } = new List<RiskRule>();

        [JsonProperty("copier_routes")]
        public List<CopierRoute> CopierRoutes { get; set; } = new List<CopierRoute>();

        /// <summary>
        /// Legacy broker-connection records.  Still present in the response so
        /// that risk rules (which key by broker_connection_id) can resolve their
        /// account names.  Copier routing now prefers the account-level fields on
        /// CopierRoute / CopierTarget directly — see SourceAccountName /
        /// DestinationAccountName.
        /// </summary>
        [JsonProperty("connections")]
        public List<BrokerConnection> Connections { get; set; } = new List<BrokerConnection>();

        /// <summary>
        /// The user's tradeable journal accounts — the same set shown in the
        /// FINOTAUR web journal account picker.  Each entry carries the broker
        /// account name (e.g. "MFFUEVBLDR161429081") which NinjaTrader uses as
        /// Account.Name locally.
        ///
        /// The agent logs how many of these it can match to local NT accounts so
        /// the user can diagnose missing connections from the NT side.
        ///
        /// Populated only in Shape B responses (Unchanged == false).
        /// </summary>
        [JsonProperty("accounts")]
        public List<AutomationAccount> Accounts { get; set; } = new List<AutomationAccount>();

        /// <summary>
        /// Commands queued by the server for this agent to execute.
        /// Present in BOTH Shape A and Shape B responses — the agent must
        /// process and report these regardless of Unchanged state.
        /// Null or empty means no pending commands this cycle.
        /// </summary>
        [JsonProperty("pending_commands")]
        public List<AgentCommand> PendingCommands { get; set; } = new List<AgentCommand>();

        /// <summary>
        /// Account names that the user has manually Locked from the web dashboard.
        /// Populated in BOTH Shape A and Shape B responses so the agent can act on
        /// lock/unlock changes immediately without waiting for a full config rebuild.
        /// Null from the server deserializes to an empty list (never null in agent).
        /// Each entry is the broker account name string (same as AccountName in
        /// AutomationAccount / CopierRoute.SourceAccountName).
        /// </summary>
        [JsonProperty("locked_accounts")]
        public List<string> LockedAccounts { get; set; } = new List<string>();

        /// <summary>ISO-8601 timestamp when this config was assembled server-side.</summary>
        [JsonProperty("served_at")]
        public string ServedAt { get; set; }
    }

    // -------------------------------------------------------------------------
    // AgentCommand — a customer-initiated command pulled from the server
    // -------------------------------------------------------------------------

    /// <summary>
    /// One pending command from the server, included in the config-poll response.
    /// The agent executes the command and reports the result via ReportCommandResultAsync.
    ///
    /// command_type values:
    ///   "flatten_all"    — flatten all positions AND cancel all orders on all copier accounts
    ///   "cancel_orders"  — cancel all working orders on all copier accounts
    ///   "flatten_symbol" — flatten positions in the given symbol on all copier accounts
    /// </summary>
    public class AgentCommand
    {
        /// <summary>Unique command ID (UUID). Reported back in ReportCommandResultAsync.</summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>"flatten_all" | "cancel_orders" | "flatten_symbol"</summary>
        [JsonProperty("command_type")]
        public string CommandType { get; set; }

        /// <summary>
        /// Instrument symbol for flatten_symbol commands (e.g. "NQ 09-26").
        /// Null or empty for flatten_all and cancel_orders.
        /// </summary>
        [JsonProperty("symbol")]
        public string Symbol { get; set; }
    }

    // -------------------------------------------------------------------------
    // AutomationAccount — account-level config entry (replaces connection-level
    // routing for the copier; risk rules still use BrokerConnection)
    // -------------------------------------------------------------------------

    /// <summary>
    /// One of the user's tradeable journal accounts, as returned by the server.
    ///
    /// <para>
    /// <b>account_name</b> is the broker-side account name — for Tradovate this is
    /// the alphanumeric string like "MFFUEVBLDR161429081" that NinjaTrader shows as
    /// Account.Name in the Accounts tab.  This is the primary matching key.
    /// </para>
    ///
    /// <para>
    /// <b>account_id</b> is the broker-side numeric ID (e.g. "12345").  Retained for
    /// diagnostics and back-compat with the legacy ResolveAccountName path.
    /// </para>
    /// </summary>
    public class AutomationAccount
    {
        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        /// <summary>
        /// The broker account name as it appears in NinjaTrader (e.g.
        /// "MFFUEVBLDR161429081").  Used as the primary matching key for
        /// ResolveAccountByName — match Account.Name case-insensitively.
        /// </summary>
        [JsonProperty("account_name")]
        public string AccountName { get; set; }

        /// <summary>E.g. "tradovate"</summary>
        [JsonProperty("broker")]
        public string Broker { get; set; }

        /// <summary>"live" | "demo" | "sim"</summary>
        [JsonProperty("environment")]
        public string Environment { get; set; }

        [JsonProperty("is_active")]
        public bool IsActive { get; set; }
    }

    // -------------------------------------------------------------------------
    // Settings — master on/off, kill switch
    // -------------------------------------------------------------------------

    /// <summary>
    /// Global per-user automation settings. The agent MUST honor both flags
    /// as a hard stop before enforcing any rule or copying any order.
    /// </summary>
    public class AutomationSettings
    {
        /// <summary>
        /// When false, the agent does nothing (no risk enforcement, no copying).
        /// It continues to send heartbeats so the web knows it is alive.
        /// </summary>
        [JsonProperty("master_enabled")]
        public bool MasterEnabled { get; set; }

        /// <summary>
        /// When true, the kill switch has been engaged from the web dashboard.
        /// Same effect as master_enabled == false. The agent immediately stops
        /// all activity and posts a 'kill_switch' event.
        /// </summary>
        [JsonProperty("kill_switch_engaged")]
        public bool KillSwitchEngaged { get; set; }

        /// <summary>Last time settings were changed, as ISO-8601 string.</summary>
        [JsonProperty("updated_at")]
        public string UpdatedAt { get; set; }
    }

    // -------------------------------------------------------------------------
    // RiskRule
    // -------------------------------------------------------------------------

    /// <summary>
    /// A single risk guardrail for one broker connection (account).
    /// The agent enforces this locally when enforce == true.
    /// Rules with enforce == false are advisory only (web dashboard shows them);
    /// the agent IGNORES advisory rules entirely — do not act on them.
    /// </summary>
    public class RiskRule
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>Matches BrokerConnection.Id to scope this rule to one account.</summary>
        [JsonProperty("broker_connection_id")]
        public string BrokerConnectionId { get; set; }

        /// <summary>Human-readable label for logging and event payloads.</summary>
        [JsonProperty("label")]
        public string Label { get; set; }

        // ---- Monetary limits (null = not configured, skip that check) --------

        /// <summary>
        /// Flatten-all threshold: if sessionRealizedPnL + openPnL drops to or
        /// below the negative of this value, flatten the account.
        /// E.g. value = 500 means flatten when loss >= $500.
        /// null means this check is disabled for this rule.
        /// </summary>
        [JsonProperty("daily_loss_limit_usd")]
        public double? DailyLossLimitUsd { get; set; }

        /// <summary>
        /// Block/reduce when open contracts in any single instrument exceed this.
        /// null = disabled.
        /// </summary>
        [JsonProperty("max_contracts")]
        public int? MaxContracts { get; set; }

        /// <summary>
        /// Block/reduce when total open position market value exceeds this (USD).
        /// null = disabled.
        /// VERIFY (NT8 API): computing position market value requires bid/ask or
        /// last price per instrument. Use MarketDataType.Last from the Instrument
        /// if available, otherwise skip this check and post a risk_alert event
        /// explaining the data was unavailable.
        /// </summary>
        [JsonProperty("max_position_usd")]
        public double? MaxPositionUsd { get; set; }

        /// <summary>
        /// Maximum copier-originated opens per calendar day (UTC).
        /// Manual trades are NOT counted (we cannot un-trade them);
        /// this only blocks further copier opens once the limit is reached.
        /// null = disabled.
        /// </summary>
        [JsonProperty("max_trades_per_day")]
        public int? MaxTradesPerDay { get; set; }

        // ---- Tilt protection -------------------------------------------------

        /// <summary>
        /// After this many consecutive losing trades on the account, enter
        /// cooldown. null = disabled.
        /// </summary>
        [JsonProperty("tilt_loss_streak")]
        public int? TiltLossStreak { get; set; }

        /// <summary>
        /// How many minutes the cooldown lasts once triggered. Only relevant
        /// when tilt_loss_streak is set.
        /// </summary>
        [JsonProperty("tilt_cooldown_minutes")]
        public int? TiltCooldownMinutes { get; set; }

        // ---- New extended fields (added to match full server contract) ----------

        /// <summary>
        /// The broker-side account ID for this rule's target account.
        /// Informational; use AccountName for NT resolution (it is more reliable).
        /// null = not set.
        /// </summary>
        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        /// <summary>
        /// The broker account name (e.g. "MFFUEVBLDR161429081") for this rule.
        /// When non-empty, RiskEnforcer resolves the local NT account via
        /// ResolveAccountByName FIRST, falling back to the legacy BrokerConnectionId
        /// path only when this is null/empty.
        /// null = use legacy broker_connection_id path.
        /// </summary>
        [JsonProperty("account_name")]
        public string AccountName { get; set; }

        /// <summary>
        /// Per-trade loss limit (USD). On a losing CLOSE fill, if the realized loss
        /// for that single trade meets or exceeds this value → breach.
        /// null = disabled.
        /// </summary>
        [JsonProperty("max_loss_per_trade_usd")]
        public double? MaxLossPerTradeUsd { get; set; }

        /// <summary>
        /// Weekly loss limit (USD). Breach when weekly realized + open PnL drops to
        /// or below the negative of this value. Week resets Sunday 00:00 local time.
        /// null = disabled.
        /// </summary>
        [JsonProperty("max_weekly_loss_usd")]
        public double? MaxWeeklyLossUsd { get; set; }

        /// <summary>
        /// Per-trade profit target (USD, best-effort). When a single open position's
        /// unrealized PnL for that symbol meets or exceeds this value, treated as a
        /// take-profit breach. Enforced at poll frequency — not tick-by-tick.
        /// null = disabled.
        /// </summary>
        [JsonProperty("trade_profit_target_usd")]
        public double? TradeProfitTargetUsd { get; set; }

        /// <summary>
        /// Daily profit target (USD). When realized + open PnL for the session meets
        /// or exceeds this value → breach (lock for rest of day).
        /// null = disabled.
        /// </summary>
        [JsonProperty("daily_profit_target_usd")]
        public double? DailyProfitTargetUsd { get; set; }

        /// <summary>
        /// Weekly profit target (USD). When realized + open PnL for the week meets
        /// or exceeds this value → breach (lock for rest of week).
        /// null = disabled.
        /// </summary>
        [JsonProperty("weekly_profit_target_usd")]
        public double? WeeklyProfitTargetUsd { get; set; }

        /// <summary>
        /// Maximum total open contracts across ALL instruments on the account
        /// (account-total cap, distinct from per-instrument max_contracts).
        /// Breach if total open contracts exceeds this value.
        /// null = disabled.
        /// </summary>
        [JsonProperty("max_position_size")]
        public int? MaxPositionSize { get; set; }

        /// <summary>
        /// Action to execute on any risk breach for this rule.
        /// "pause_copies"  = block new copier opens for this account; do NOT flatten.
        /// "stop_copies"   = block new copier opens AND flatten existing positions.
        /// "close_lock"    = flatten + block ALL activity until period reset.
        /// null / unknown  = legacy behavior (flatten for loss limits, alert for others).
        /// </summary>
        [JsonProperty("risk_breach_action")]
        public string RiskBreachAction { get; set; }

        // ---- Enforcement flag -----------------------------------------------

        /// <summary>
        /// TRUE  = agent enforces locally (flatten, block, etc.).
        /// FALSE = advisory only; agent completely ignores.
        /// The agent MUST check this flag before acting.
        /// </summary>
        [JsonProperty("enforce")]
        public bool Enforce { get; set; }

        /// <summary>
        /// If false, this rule is soft-deleted on the server. Agent skips it.
        /// </summary>
        [JsonProperty("is_active")]
        public bool IsActive { get; set; }
    }

    // -------------------------------------------------------------------------
    // CopierRoute + CopierTarget
    // -------------------------------------------------------------------------

    /// <summary>
    /// Describes one copy-trading route: fills on the source account are
    /// mirrored to one or more target accounts. Source and all targets are
    /// the same user's accounts (guaranteed by the server — config only returns
    /// this user's connections). This is user-to-self only.
    ///
    /// <para>
    /// ACCOUNT RESOLUTION ORDER (preferred → fallback):
    ///   1. <see cref="SourceAccountName"/> — resolved via
    ///      <c>IPlatformAdapter.ResolveAccountByName()</c> (exact name match).
    ///   2. <see cref="SourceConnectionId"/> + legacy <c>ResolveAccountName(BrokerConnection)</c>
    ///      — used only when SourceAccountName is null/empty (back-compat with
    ///      older server responses that pre-date the accounts array).
    /// </para>
    /// </summary>
    public class CopierRoute
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        // ---- Account-level fields (primary — added with accounts array) ------

        /// <summary>
        /// Server-side AutomationAccount.account_id for the source account.
        /// Informational; not used directly for NT matching — use SourceAccountName.
        /// </summary>
        [JsonProperty("source_account_id")]
        public string SourceAccountId { get; set; }

        /// <summary>
        /// The broker account name as shown in NinjaTrader (e.g.
        /// "MFFUEVBLDR161429081").  <b>Primary matching key</b>: the engine calls
        /// <c>IPlatformAdapter.ResolveAccountByName(SourceAccountName)</c> to find
        /// the local NT account.  Must not be null/empty on a well-formed config.
        /// </summary>
        [JsonProperty("source_account_name")]
        public string SourceAccountName { get; set; }

        /// <summary>E.g. "tradovate"</summary>
        [JsonProperty("source_broker")]
        public string SourceBroker { get; set; }

        /// <summary>"live" | "demo" | "sim"</summary>
        [JsonProperty("source_environment")]
        public string SourceEnvironment { get; set; }

        // ---- Legacy connection-id field (back-compat — kept optional/nullable) -

        /// <summary>
        /// Legacy field: maps to BrokerConnection.Id.  No longer the primary
        /// routing key; retained so that older server responses (pre-accounts
        /// array) can still resolve a source account via the BrokerConnection
        /// fallback path.  May be null on newer server responses.
        /// </summary>
        [JsonProperty("source_connection_id")]
        public string SourceConnectionId { get; set; }

        // ---- Route behaviour fields ------------------------------------------

        [JsonProperty("label")]
        public string Label { get; set; }

        /// <summary>
        /// Instrument symbols to copy. Empty list means copy all symbols.
        /// When non-empty, only fills whose instrument name matches one of these
        /// strings (case-insensitive) are copied.
        /// </summary>
        [JsonProperty("symbol_filter")]
        public List<string> SymbolFilter { get; set; } = new List<string>();

        /// <summary>Mirror opening fills from source to target.</summary>
        [JsonProperty("copy_opens")]
        public bool CopyOpens { get; set; }

        /// <summary>Mirror closing fills from source to target.</summary>
        [JsonProperty("copy_closes")]
        public bool CopyCloses { get; set; }

        /// <summary>
        /// When true, flip the direction: a source BUY becomes a target SELL
        /// and vice-versa. Use with caution — documented for completeness.
        /// </summary>
        [JsonProperty("reverse")]
        public bool Reverse { get; set; }

        [JsonProperty("is_active")]
        public bool IsActive { get; set; }

        [JsonProperty("targets")]
        public List<CopierTarget> Targets { get; set; } = new List<CopierTarget>();
    }

    /// <summary>
    /// One destination account within a CopierRoute.
    ///
    /// <para>
    /// ACCOUNT RESOLUTION ORDER (preferred → fallback):
    ///   1. <see cref="DestinationAccountName"/> — resolved via
    ///      <c>IPlatformAdapter.ResolveAccountByName()</c>.
    ///   2. <see cref="DestinationConnectionId"/> + legacy
    ///      <c>ResolveAccountName(BrokerConnection)</c> fallback.
    /// </para>
    /// </summary>
    public class CopierTarget
    {
        // ---- Account-level fields (primary — added with accounts array) ------

        /// <summary>
        /// Server-side AutomationAccount.account_id for the destination account.
        /// Informational; not used directly for NT matching — use DestinationAccountName.
        /// </summary>
        [JsonProperty("destination_account_id")]
        public string DestinationAccountId { get; set; }

        /// <summary>
        /// The broker account name as shown in NinjaTrader (e.g.
        /// "MFFUEVBLDR161429081").  <b>Primary matching key</b>: the engine calls
        /// <c>IPlatformAdapter.ResolveAccountByName(DestinationAccountName)</c> to
        /// find the local NT account.
        /// </summary>
        [JsonProperty("destination_account_name")]
        public string DestinationAccountName { get; set; }

        /// <summary>E.g. "tradovate"</summary>
        [JsonProperty("destination_broker")]
        public string DestinationBroker { get; set; }

        /// <summary>"live" | "demo" | "sim"</summary>
        [JsonProperty("destination_environment")]
        public string DestinationEnvironment { get; set; }

        // ---- Legacy connection-id field (back-compat — kept optional/nullable) -

        /// <summary>
        /// Legacy field: maps to BrokerConnection.Id.  Retained for back-compat
        /// with older server responses.  May be null on newer responses.
        /// </summary>
        [JsonProperty("destination_connection_id")]
        public string DestinationConnectionId { get; set; }

        // ---- Target behaviour fields -----------------------------------------

        /// <summary>
        /// Multiply source quantity by this ratio. E.g. 0.5 = half size.
        /// Result is rounded to nearest integer; minimum 1 if copy should proceed.
        /// </summary>
        [JsonProperty("scale_ratio")]
        public double ScaleRatio { get; set; } = 1.0;

        /// <summary>
        /// Hard cap on contracts sent to this target, regardless of scale_ratio.
        /// 0 or null means no cap beyond the ratio.
        /// </summary>
        // Nullable: the DB column is null when no cap is set (the common case).
        // Newtonsoft THROWS when converting JSON null to a non-nullable int, which
        // fails the ENTIRE config deserialization → the agent never applies config,
        // never subscribes routes, never copies. This MUST stay int?.
        [JsonProperty("max_contracts")]
        public int? MaxContracts { get; set; }

        /// <summary>
        /// When true, translate the source instrument root to its micro/full
        /// counterpart using the built-in CROSS_MAP in CopierEngine before placing
        /// the target order. E.g. NQ → MNQ, ES → MES.
        /// Quantity is NOT auto-multiplied — the scale_ratio already handles sizing.
        /// If the source root has no CROSS_MAP entry, the original instrument is used.
        /// </summary>
        [JsonProperty("cross_to_micro")]
        public bool CrossToMicro { get; set; }

        [JsonProperty("is_active")]
        public bool IsActive { get; set; }
    }

    // -------------------------------------------------------------------------
    // BrokerConnection — maps server-side connections to local NT accounts
    // -------------------------------------------------------------------------

    /// <summary>
    /// A broker connection record from the FINOTAUR web platform.
    /// The agent maps this to a local NinjaTrader Account by matching
    /// account_id (or account_name) to Account.Name. If no confident match
    /// is found, the agent skips that connection, logs it, and posts an
    /// agent_status event. It does NOT guess.
    /// </summary>
    public class BrokerConnection
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>E.g. "tradovate"</summary>
        [JsonProperty("broker")]
        public string Broker { get; set; }

        /// <summary>"live" | "demo" | "sim" — agent always prefers SIM/demo for testing.</summary>
        [JsonProperty("environment")]
        public string Environment { get; set; }

        /// <summary>
        /// The broker-side account identifier. For Tradovate this is the numeric
        /// account ID (e.g. "12345"). Used to match against NT Account.Name.
        /// VERIFY (NT8 API): for Tradovate connections, NT Account.Name may be
        /// the Tradovate account name/number string. Confirm with a live account.
        /// </summary>
        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        [JsonProperty("is_active")]
        public bool IsActive { get; set; }

        /// <summary>"active" | "error" | "disconnected" | etc.</summary>
        [JsonProperty("status")]
        public string Status { get; set; }
    }

    // -------------------------------------------------------------------------
    // Outbound event payload
    // -------------------------------------------------------------------------

    /// <summary>
    /// Payload sent to POST automation-agent {action:'event'}.
    /// The agent posts these to inform the web of local enforcement actions.
    /// </summary>
    public class AutomationEvent
    {
        /// <summary>
        /// One of: 'risk_alert', 'risk_enforced', 'copy_executed',
        /// 'copy_failed', 'agent_status', 'kill_switch'.
        /// </summary>
        [JsonProperty("event_type")]
        public string EventType { get; set; }

        /// <summary>"info" | "warning" | "critical" — optional.</summary>
        [JsonProperty("severity")]
        public string Severity { get; set; }

        /// <summary>Which broker connection this event relates to, if any.</summary>
        [JsonProperty("broker_connection_id")]
        public string BrokerConnectionId { get; set; }

        /// <summary>Instrument symbol involved, if any.</summary>
        [JsonProperty("symbol")]
        public string Symbol { get; set; }

        /// <summary>
        /// Arbitrary structured payload. Keep it small and non-sensitive.
        /// Never include account credentials or token material.
        /// </summary>
        [JsonProperty("payload")]
        public object Payload { get; set; }
    }

    // -------------------------------------------------------------------------
    // Pairing response
    // -------------------------------------------------------------------------

    /// <summary>
    /// Response from POST automation-pair.
    /// The device_token is sensitive — stored encrypted via TokenStore, never logged.
    /// </summary>
    public class PairingResponse
    {
        [JsonProperty("device_token")]
        public string DeviceToken { get; set; }

        [JsonProperty("device_id")]
        public string DeviceId { get; set; }

        /// <summary>Non-null on error from the server.</summary>
        [JsonProperty("error")]
        public string Error { get; set; }
    }

    // -------------------------------------------------------------------------
    // Heartbeat response
    // -------------------------------------------------------------------------

    public class HeartbeatResponse
    {
        [JsonProperty("ok")]
        public bool Ok { get; set; }
    }

    // -------------------------------------------------------------------------
    // Generic event response
    // -------------------------------------------------------------------------

    public class EventResponse
    {
        [JsonProperty("ok")]
        public bool Ok { get; set; }
    }

    // -------------------------------------------------------------------------
    // Internal helper — account info surfaced to the UI
    // -------------------------------------------------------------------------

    /// <summary>
    /// Lightweight account descriptor used by IPlatformAdapter.GetAccounts().
    /// Not a JSON model — purely internal.
    /// </summary>
    public class AgentAccount
    {
        public string Name { get; set; }
        public string ConnectionName { get; set; }
        public bool IsSimulation { get; set; }
    }

    // -------------------------------------------------------------------------
    // Account snapshot telemetry — sent with action:'account_snapshot'
    // -------------------------------------------------------------------------

    /// <summary>
    /// One open position within an AccountSnapshot.
    /// JSON key names match the server contract exactly (snake_case / camelCase
    /// as specified by the edge function).
    /// </summary>
    public class PositionSnapshot
    {
        [JsonProperty("symbol")]
        public string Symbol { get; set; }

        [JsonProperty("qty")]
        public int Qty { get; set; }

        /// <summary>true = long position, false = short.</summary>
        [JsonProperty("isLong")]
        public bool IsLong { get; set; }

        [JsonProperty("avgPrice")]
        public double AvgPrice { get; set; }

        [JsonProperty("openPnl")]
        public double OpenPnl { get; set; }
    }

    /// <summary>
    /// Per-account telemetry payload. One entry per NT8 account per cycle.
    /// </summary>
    public class AccountSnapshot
    {
        [JsonProperty("account_name")]
        public string AccountName { get; set; }

        /// <summary>"live" | "demo" | null if environment is unknown.</summary>
        [JsonProperty("env")]
        public string Env { get; set; }

        /// <summary>Account cash balance in USD. Null if unavailable.</summary>
        [JsonProperty("balance")]
        public double? Balance { get; set; }

        /// <summary>Session realized PnL in USD. Null if unavailable.</summary>
        [JsonProperty("day_pnl")]
        public double? DayPnl { get; set; }

        /// <summary>Total unrealized PnL in USD. Null if unavailable.</summary>
        [JsonProperty("open_pnl")]
        public double? OpenPnl { get; set; }

        [JsonProperty("positions")]
        public List<PositionSnapshot> Positions { get; set; } = new List<PositionSnapshot>();
    }

    /// <summary>
    /// Response from POST automation-agent {action:'account_snapshot'}.
    /// </summary>
    public class AccountSnapshotResponse
    {
        [JsonProperty("ok")]
        public bool Ok { get; set; }

        [JsonProperty("upserted")]
        public int Upserted { get; set; }
    }

    // -------------------------------------------------------------------------
    // Fill info — used by CopierEngine fill callbacks
    // -------------------------------------------------------------------------

    /// <summary>
    /// Normalized fill record emitted by IPlatformAdapter fill subscriptions.
    /// Decoupled from NT8's ExecutionEventArgs to allow future adapters.
    /// </summary>
    public class FillInfo
    {
        /// <summary>
        /// Unique ID for this execution from the broker/NT. Used for
        /// idempotency in CopierEngine (never copy the same fill twice).
        /// VERIFY (NT8 API): NT ExecutionEventArgs has ExecutionId (string).
        /// Use that as the unique key.
        /// </summary>
        public string ExecutionId { get; set; }

        public string AccountName { get; set; }
        public string InstrumentName { get; set; }

        /// <summary>true = Buy, false = Sell</summary>
        public bool IsBuy { get; set; }

        public int Quantity { get; set; }
        public double Price { get; set; }

        /// <summary>
        /// true = this fill OPENED a position (net position grew).
        /// false = this fill CLOSED/REDUCED a position.
        /// VERIFY (NT8 API): NT8 does not directly give IsOpening per fill.
        /// Approximate by tracking position before vs. after.
        /// See NinjaTraderAdapter for the approximation logic.
        /// </summary>
        public bool IsOpening { get; set; }

        /// <summary>
        /// FIX A: The signed net position on the SOURCE account for this
        /// instrument, captured inside the NT ExecutionUpdate callback at
        /// the same moment IsOpening is computed — i.e. in the same NT
        /// thread context and the same Account.Positions read.
        ///
        /// Positive = long, negative = short, 0 = flat.
        ///
        /// This value is set by NinjaTraderAdapter.SubscribeFills immediately
        /// after computing IsOpening, so both fields share the same
        /// Account.Positions snapshot.  CopierEngine.PlaceTargetOrderCore
        /// uses this instead of calling GetPositions(fill.AccountName)
        /// off-thread, which could race against NT's async position update.
        ///
        /// RESIDUAL: still assumes NT has updated Account.Positions by the
        /// time ExecutionUpdate fires for this fill. This is an NT8 API
        /// timing assumption that MUST be verified in NT8 sim.
        /// </summary>
        public int SourceNetAtFill { get; set; }

        public DateTime Timestamp { get; set; }

        /// <summary>The originating order's Name (e.g. "FinotaurCopier|ab12cd34"). Read from exec.Order?.Name. Used to correlate a follower fill back to the copy that produced it.</summary>
        public string OrderName { get; set; }

        /// <summary>Monotonic timestamp (Stopwatch.GetTimestamp) captured the instant this fill's ExecutionUpdate callback fired. Used for high-res latency math. NOT a wall-clock; compare only against other GetTimestamp values.</summary>
        public long CapturedTicks { get; set; }

        /// <summary>
        /// The NT8 Order.Id of the source order that produced this fill. Read from
        /// exec.Order?.Id.ToString(). Used to correlate a fill back to a mirrored
        /// working order (e.g. a working order placed via PlaceWorkingOrder that
        /// later fills).
        /// </summary>
        public string OrderId { get; set; }
    }

    // -------------------------------------------------------------------------
    // Order info — used by CopierEngine working-order callbacks
    // -------------------------------------------------------------------------

    /// <summary>
    /// Normalized working-order lifecycle record emitted by IPlatformAdapter
    /// order subscriptions (SubscribeOrders). Decoupled from NT8's
    /// OrderEventArgs to allow future adapters.
    /// </summary>
    public class OrderInfo
    {
        /// <summary>
        /// NT8 Order.Id.ToString() — stable within the session. Used to
        /// correlate subsequent modify/cancel calls and fill correlation.
        /// </summary>
        public string OrderId { get; set; }

        public string AccountName { get; set; }

        /// <summary>Instrument.FullName e.g. "NQ 09-26".</summary>
        public string InstrumentName { get; set; }

        /// <summary>true = Buy/BuyToCover, false = Sell/SellShort.</summary>
        public bool IsBuy { get; set; }

        public int Quantity { get; set; }

        /// <summary>"limit" | "stop" | "stoplimit" | "mit" | "market" | "other"</summary>
        public string OrderType { get; set; }

        public double LimitPrice { get; set; }

        public double StopPrice { get; set; }

        /// <summary>
        /// "working"|"accepted"|"submitted"|"changesubmitted"|"partfilled"|
        /// "filled"|"cancelled"|"rejected"|"other"
        /// </summary>
        public string State { get; set; }

        /// <summary>Order.Name (used to skip our own "Finotaur*" orders).</summary>
        public string OrderName { get; set; }

        /// <summary>"day" | "gtc" — anything else normalized to "day".</summary>
        public string Tif { get; set; } = "day";

        public DateTime Timestamp { get; set; }
    }
}
