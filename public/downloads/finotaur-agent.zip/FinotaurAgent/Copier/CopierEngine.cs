// =============================================================================
// Finotaur Agent — Copier/CopierEngine.cs
//
// LOCAL trade-copy engine. Mirrors fills from one NT8 account (the "source")
// to one or more NT8 accounts (the "targets") on the SAME user — completely
// locally, with ZERO network calls on the hot path.
//
// ═══════════════════════════════════════════════════════════════════════════
// COMPLIANCE BOUNDARY (DO NOT REMOVE THIS COMMENT)
// ═══════════════════════════════════════════════════════════════════════════
//   • All order placement uses NT8's local NinjaTrader.Cbi APIs only.
//   • This engine NEVER calls Tradovate, NinjaTrader Cloud, or any broker
//     REST/WebSocket API directly. The execution path is 100% local.
//   • Copying is strictly user-to-self: both source and all targets are
//     the same user's accounts (guaranteed by the server config — the server
//     only returns this user's connections).
//   • FAIL-SAFE: when in doubt, DO NOTHING. Every uncertain path returns
//     without placing orders. No order is ever speculative.
// ═══════════════════════════════════════════════════════════════════════════
//
// SCALE DESIGN (Elad requirement: ~60 accounts/user, fast fan-out):
//
//   HOT PATH IS 100% LOCAL, ZERO NETWORK PER FILL.
//     The NT8 ExecutionUpdate callback does the MINIMUM: validate the fill
//     against the locally-cached config, enqueue a CopyJob to the worker
//     queue, then return immediately. The NT thread is never blocked.
//
//   CONCURRENT FAN-OUT, OFF THE NT THREAD.
//     A dedicated background consumer (BlockingCollection<CopyJob>) dequeues
//     copy jobs and fans out to all targets concurrently via Task.WhenAll.
//     With up to ~59 targets per source fill, PlaceMarketOrder calls run in
//     parallel — the NT data thread is never stalled.
//
//   ONE AGGREGATED EVENT PER SOURCE FILL.
//     After the fan-out completes, ONE 'copy_executed' event is posted
//     summarizing: source symbol/qty, target count, per-target {account,
//     qty, ok/fail}. Failures are included in the same event (or a separate
//     'copy_failed' if the aggregated payload becomes too large — see
//     BATCH_MAX_FAILURES below). We NEVER emit one event per target.
//
//   IDEMPOTENCY.
//     Processed source ExecutionIds are tracked in a bounded concurrent set.
//     On reconnect or replay, duplicate fills are silently dropped.
//
//   TELEMETRY BATCHING (event queue).
//     Events are buffered in a ConcurrentQueue and flushed asynchronously
//     by the agent's background loop (not by the copy hot path). The copy
//     path enqueues and returns; it never blocks on network I/O.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Copier
{
    // =========================================================================
    // Internal data structures
    // =========================================================================

    /// <summary>
    /// Represents one pending copy-fan-out job. Placed on the worker queue
    /// by the NT fill callback (hot path) and consumed by the background worker.
    /// </summary>
    internal sealed class CopyJob
    {
        /// <summary>The normalized fill that triggered this copy.</summary>
        public FillInfo SourceFill { get; set; }

        /// <summary>The route that matched this fill.</summary>
        public CopierRoute Route { get; set; }

        /// <summary>Snapshot of config at the moment the job was enqueued.</summary>
        public AutomationConfig Config { get; set; }
    }

    /// <summary>
    /// Per-target result after attempting a mirrored order.
    /// Used to build the single aggregated 'copy_executed' event.
    /// </summary>
    internal sealed class TargetResult
    {
        /// <summary>
        /// The destination account name from the server config
        /// (DestinationAccountName when available, DestinationConnectionId as fallback).
        /// Used in the aggregated event payload for diagnostics on the web side.
        /// </summary>
        public string DestinationAccountName { get; set; }

        /// <summary>Resolved local NT account name (null if resolution failed).</summary>
        public string AccountName            { get; set; }
        public int    Quantity               { get; set; }
        public bool   Success                { get; set; }
        public string FailureReason          { get; set; }
    }

    // =========================================================================
    // CopierEngine
    // =========================================================================

    /// <summary>
    /// Manages fill subscriptions for all active copier routes, fans out mirrored
    /// orders concurrently, and enqueues aggregated telemetry events.
    ///
    /// Lifecycle:
    ///   1. Call ApplyConfig() whenever the agent receives a new AutomationConfig.
    ///   2. The engine subscribes/unsubscribes as routes change.
    ///   3. Call Dispose() when the AddOn shuts down.
    /// </summary>
    public sealed class CopierEngine : IDisposable
    {
        // -----------------------------------------------------------------------
        // Dependencies
        // -----------------------------------------------------------------------

        private readonly IPlatformAdapter   _platform;
        private readonly RiskEnforcer       _risk;
        private readonly Action<string>     _log;

        // -----------------------------------------------------------------------
        // Event queue — telemetry events produced by the copier are placed here.
        // The agent's background loop (FinotaurAgent) drains this queue and
        // flushes to the server via FinotaurClient in batches.
        // The copier NEVER calls FinotaurClient directly — no network on hot path.
        // -----------------------------------------------------------------------

        private readonly ConcurrentQueue<AutomationEvent> _eventQueue;

        // -----------------------------------------------------------------------
        // Worker queue + consumer task
        // The hot path (NT fill callback) enqueues CopyJob objects.
        // A single background consumer Task dequeues and processes them.
        // BlockingCollection provides blocking take + cancellation support.
        // -----------------------------------------------------------------------

        /// <summary>
        /// Maximum pending copy jobs in the queue. If the consumer falls behind
        /// (e.g. NT is very busy), extra fills are silently dropped rather than
        /// blocking the NT thread. In normal operation the queue drains instantly.
        /// </summary>
        private const int WorkerQueueCapacity = 512;

        private readonly BlockingCollection<CopyJob> _workerQueue =
            new BlockingCollection<CopyJob>(WorkerQueueCapacity);

        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private Task _consumerTask;

        // -----------------------------------------------------------------------
        // Active subscriptions — keyed by route.Id
        // Value is the opaque handle returned by IPlatformAdapter.SubscribeFills.
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, object> _subscriptions =
            new ConcurrentDictionary<string, object>();

        // -----------------------------------------------------------------------
        // Tilt tracking: last-known session realized PnL per source account.
        // Updated just before processing each close fill so we can compute the
        // PnL delta and infer win/loss.
        //
        // VERIFY (NT8 API): GetSessionRealizedPnL calls Account.Get(AccountItem.*)
        // internally.  NT8 may update the realized-PnL value asynchronously after
        // the ExecutionUpdate callback fires.  If the adapter always returns the
        // same value before and after a close fill, the delta will be 0 and we
        // cannot determine win/loss from this approach alone.  In that case the
        // TODO below applies: swap in a fill-level P&L signal when NT8 exposes it
        // (e.g. Execution.Profit in a future NT release or via a custom position
        // tracker that maintains average-entry price).
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, double> _lastSourceRealizedPnL =
            new ConcurrentDictionary<string, double>();

        // -----------------------------------------------------------------------
        // Idempotency set — tracks ExecutionIds we have already processed.
        // Bounded to prevent unbounded growth across long NT sessions.
        // -----------------------------------------------------------------------

        private const int MaxProcessedIds = 100_000;
        private readonly ConcurrentDictionary<string, byte> _processedIds =
            new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);

        // Keep an ordered queue of IDs so we can evict the oldest when the cap
        // is reached (FIFO eviction — simple ring-buffer approximation via a Queue
        // protected by a lock).
        private readonly Queue<string> _idEvictionQueue = new Queue<string>();
        private readonly object        _idEvictionLock  = new object();

        // -----------------------------------------------------------------------
        // Locally-cached config (set by ApplyConfig, read by hot path)
        // Volatile so the NT callback always sees the latest reference.
        // -----------------------------------------------------------------------

        private volatile AutomationConfig _cachedConfig;

        // -----------------------------------------------------------------------
        // Constructor
        // -----------------------------------------------------------------------

        /// <summary>
        /// Creates a CopierEngine.
        /// </summary>
        /// <param name="platform">Platform adapter for account queries and order placement.</param>
        /// <param name="risk">Risk enforcer used for pre-trade checks.</param>
        /// <param name="eventQueue">
        /// Shared queue that the agent's background loop drains for telemetry.
        /// The copier enqueues aggregated events here — never posts to the network.
        /// </param>
        /// <param name="logger">Optional logger delegate.</param>
        public CopierEngine(
            IPlatformAdapter              platform,
            RiskEnforcer                  risk,
            ConcurrentQueue<AutomationEvent> eventQueue,
            Action<string>                logger = null)
        {
            _platform   = platform   ?? throw new ArgumentNullException(nameof(platform));
            _risk       = risk       ?? throw new ArgumentNullException(nameof(risk));
            _eventQueue = eventQueue ?? throw new ArgumentNullException(nameof(eventQueue));
            _log        = logger     ?? (m => System.Diagnostics.Debug.WriteLine($"[CopierEngine] {m}"));

            // Start the background consumer task.
            // It runs on a dedicated thread pool task so order placement is always
            // off the NT event thread.
            _consumerTask = Task.Run(ConsumerLoop, _cts.Token);
        }

        // -----------------------------------------------------------------------
        // ApplyConfig — called by FinotaurAgent on every successful config pull
        // -----------------------------------------------------------------------

        /// <summary>
        /// Rebuilds fill subscriptions from the new config.
        ///
        /// CALL THIS only when the config actually changed (i.e. AutomationConfig
        /// .Unchanged == false). For Shape-A "unchanged" responses, apply the
        /// master/kill flags but do NOT call ApplyConfig — subscriptions are
        /// stable and rebuilding them would create duplicate events.
        ///
        /// Thread-safe: can be called from the agent background loop.
        /// </summary>
        public void ApplyConfig(AutomationConfig config)
        {
            if (config == null)
            {
                _log("ApplyConfig called with null config — skipping.");
                return;
            }

            // Store the new config atomically. The hot path (fill callback) reads
            // _cachedConfig; publishing a new reference is atomic on 64-bit CLR.
            _cachedConfig = config;

            // ------------------------------------------------------------------
            // Unsubscribe routes that are no longer active or no longer present
            // ------------------------------------------------------------------

            var incomingRouteIds = new HashSet<string>(
                (config.CopierRoutes ?? new List<CopierRoute>())
                    .Where(r => r.IsActive)
                    .Select(r => r.Id));

            foreach (var existingRouteId in _subscriptions.Keys.ToList())
            {
                if (!incomingRouteIds.Contains(existingRouteId))
                {
                    if (_subscriptions.TryRemove(existingRouteId, out object handle))
                    {
                        _platform.Unsubscribe(handle);
                        _log($"Unsubscribed route '{existingRouteId}' (no longer active).");
                    }
                }
            }

            // ------------------------------------------------------------------
            // Subscribe new or re-activated routes
            // ------------------------------------------------------------------

            foreach (var route in config.CopierRoutes ?? new List<CopierRoute>())
            {
                if (!route.IsActive)
                {
                    // Ensure any stale subscription is removed
                    if (_subscriptions.TryRemove(route.Id, out object staleHandle))
                    {
                        _platform.Unsubscribe(staleHandle);
                        _log($"Removed subscription for inactive route '{route.Id}'.");
                    }
                    continue;
                }

                // Already subscribed for this route — no change needed
                if (_subscriptions.ContainsKey(route.Id)) continue;

                // ------------------------------------------------------------------
                // Resolve source account → local NT account name.
                //
                // Resolution order:
                //   1. route.SourceAccountName  → ResolveAccountByName()  (primary)
                //   2. route.SourceConnectionId → FindConnection() +
                //                                 ResolveAccountName()     (fallback)
                //
                // The primary path is the new account-name-based approach.  The
                // fallback supports older server responses that pre-date the
                // accounts array.  Either way: if we cannot resolve to a local NT
                // account, SKIP this route with a diagnostic log — fail-safe.
                // ------------------------------------------------------------------
                string sourceAccount = null;

                if (!string.IsNullOrWhiteSpace(route.SourceAccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    sourceAccount = _platform.ResolveAccountByName(route.SourceAccountName);
                    if (sourceAccount == null)
                    {
                        // Post a status event so the web can surface the gap.
                        _eventQueue.Enqueue(new AutomationEvent
                        {
                            EventType = "agent_status",
                            Severity  = "warning",
                            Payload   = new
                            {
                                message         = $"Copier route '{route.Label}' skipped: " +
                                                  $"source account '{route.SourceAccountName}' " +
                                                  "is not connected in this NT8 instance. " +
                                                  "Open NinjaTrader → Accounts and connect the account.",
                                route_id        = route.Id,
                                source_account  = route.SourceAccountName,
                                source_broker   = route.SourceBroker,
                                source_env      = route.SourceEnvironment
                            }
                        });
                        _log($"ApplyConfig: route '{route.Label}' — source account " +
                             $"'{route.SourceAccountName}' not found locally — SKIPPING. " +
                             "Verify the account is connected in NT8.");
                        continue;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(route.SourceConnectionId))
                {
                    // Fallback: older server response without account_name field.
                    BrokerConnection sourceConn = FindConnection(config, route.SourceConnectionId);
                    if (sourceConn == null)
                    {
                        _log($"ApplyConfig: route '{route.Label}' source connection " +
                             $"'{route.SourceConnectionId}' not found in config — SKIPPING.");
                        continue;
                    }
                    sourceAccount = _platform.ResolveAccountName(sourceConn);
                    if (sourceAccount == null)
                    {
                        _log($"ApplyConfig: route '{route.Label}' — no local NT account for " +
                             $"connection '{route.SourceConnectionId}' (fallback path) — SKIPPING. " +
                             "Ensure the Tradovate account is connected in NT8.");
                        continue;
                    }
                    _log($"ApplyConfig: route '{route.Label}' resolved source via legacy " +
                         $"connection-id fallback → '{sourceAccount}'.");
                }
                else
                {
                    _log($"ApplyConfig: route '{route.Label}' has neither SourceAccountName " +
                         "nor SourceConnectionId — SKIPPING (malformed route).");
                    continue;
                }

                // ------------------------------------------------------------------
                // HOT-PATH FILL CALLBACK
                // Keep this extremely lean: validate + enqueue + return.
                // NO network calls, NO expensive computation here.
                // The NT event thread must not be held.
                // ------------------------------------------------------------------

                // Capture route (and the route ID for the closure) to avoid
                // closure-over-loop-variable bugs.
                var capturedRoute = route;

                object subHandle = _platform.SubscribeFills(sourceAccount, fill =>
                {
                    // -------- HOT PATH START --------
                    // This runs on the NT ExecutionUpdate thread.
                    // Do NOT block, do NOT allocate excessively, do NOT network-call.

                    try
                    {
                        // Load the locally-cached config (atomic volatile read).
                        AutomationConfig cfg = _cachedConfig;
                        if (cfg == null) return;

                        // Hard stop: master disabled or kill engaged.
                        // Always checked first, every fill.
                        if (!cfg.MasterEnabled || cfg.KillSwitchEngaged) return;

                        // Idempotency: skip fills we have already processed.
                        if (!TryMarkProcessed(fill.ExecutionId)) return;

                        // Symbol filter (empty = copy all)
                        if (capturedRoute.SymbolFilter != null
                            && capturedRoute.SymbolFilter.Count > 0)
                        {
                            bool symbolMatch = capturedRoute.SymbolFilter.Any(s =>
                                string.Equals(s, fill.InstrumentName,
                                    StringComparison.OrdinalIgnoreCase));
                            if (!symbolMatch) return;
                        }

                        // copy_opens / copy_closes gate
                        if (fill.IsOpening  && !capturedRoute.CopyOpens)  return;
                        if (!fill.IsOpening && !capturedRoute.CopyCloses) return;

                        // Enqueue the copy job for the background consumer.
                        // If the queue is full (bounded at WorkerQueueCapacity), TryAdd returns
                        // false and we drop this fill — better to drop than to block the NT thread.
                        bool enqueued = _workerQueue.TryAdd(new CopyJob
                        {
                            SourceFill = fill,
                            Route      = capturedRoute,
                            Config     = cfg          // snapshot of config at enqueue time
                        });

                        if (!enqueued)
                        {
                            // Queue is full — log and drop. This should be rare.
                            _log($"HOT PATH: worker queue full — dropping fill " +
                                 $"'{fill.ExecutionId}' on '{fill.InstrumentName}'. " +
                                 "This indicates the consumer is falling behind; " +
                                 "investigate if this happens frequently.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Fill callbacks must NEVER throw — NT may crash the connection.
                        _log($"HOT PATH exception for fill '{fill?.ExecutionId}': " +
                             $"{ex.GetType().Name} — {ex.Message}");
                    }
                    // -------- HOT PATH END --------
                });

                if (subHandle != null)
                {
                    _subscriptions[route.Id] = subHandle;
                    _log($"Subscribed route '{route.Label}' → source account '{sourceAccount}'.");
                }
                else
                {
                    _log($"Failed to subscribe route '{route.Label}' — " +
                         $"SubscribeFills returned null for '{sourceAccount}'.");
                }
            }
        }

        // -----------------------------------------------------------------------
        // ConsumerLoop — runs on a dedicated Task (NOT the NT thread)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Background consumer: dequeues CopyJob objects and fans out orders
        /// to all target accounts concurrently.
        ///
        /// Runs until the CancellationToken is signalled (on Dispose).
        /// All exceptions are caught; the loop never exits on its own.
        /// </summary>
        private void ConsumerLoop()
        {
            _log("CopierEngine consumer loop started.");

            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    // Blocking take — waits for a job, respecting cancellation.
                    CopyJob job = _workerQueue.Take(_cts.Token);
                    ProcessJobAsync(job).GetAwaiter().GetResult();
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown path
                    break;
                }
                catch (Exception ex)
                {
                    // Should not happen; log and continue the loop.
                    _log($"ConsumerLoop unexpected error: {ex.GetType().Name} — {ex.Message}");
                }
            }

            _log("CopierEngine consumer loop stopped.");
        }

        // -----------------------------------------------------------------------
        // ProcessJobAsync — called by consumer, runs off-NT-thread
        // -----------------------------------------------------------------------

        /// <summary>
        /// Processes one CopyJob: resolves target accounts, checks risk rules,
        /// places orders concurrently to all targets, and enqueues ONE aggregated
        /// telemetry event.
        /// </summary>
        private async Task ProcessJobAsync(CopyJob job)
        {
            FillInfo       fill   = job.SourceFill;
            CopierRoute    route  = job.Route;
            AutomationConfig cfg  = job.Config;

            _log($"Processing copy job: fill '{fill.ExecutionId}' " +
                 $"{(fill.IsBuy ? "BUY" : "SELL")} {fill.Quantity} {fill.InstrumentName} " +
                 $"on '{fill.AccountName}' via route '{route.Label}'.");

            // ------------------------------------------------------------------
            // Tilt pre-snapshot: for CLOSE fills, record the source account's
            // realized PnL BEFORE the fan-out so we can compute the delta after.
            //
            // VERIFY (NT8 API): GetSessionRealizedPnL must return the up-to-date
            // value at the time this line executes — i.e. AFTER the ExecutionUpdate
            // callback has caused NT8 to close the position and book the P&L.
            // The consumer runs off the NT thread (via Task.Run), so there may be
            // a brief race window where NT8 has not yet updated its internal account
            // state.  If the delta is consistently 0 for close fills, NT8's P&L
            // update is asynchronous with respect to the fill callback and this
            // snapshot approach will NOT work — see the TODO note below.
            // ------------------------------------------------------------------
            double preFillRealizedPnL = 0.0;
            if (!fill.IsOpening)
            {
                preFillRealizedPnL = _lastSourceRealizedPnL.GetOrAdd(
                    fill.AccountName,
                    _ => _platform.GetSessionRealizedPnL(fill.AccountName));
            }

            // Build per-target tasks
            var targetResults = new ConcurrentBag<TargetResult>();

            // Fan-out: prepare a Task for each active target
            var targetTasks = new List<Task>();

            foreach (var target in route.Targets ?? new List<CopierTarget>())
            {
                if (!target.IsActive) continue;

                // Capture for closure
                var capturedTarget = target;

                targetTasks.Add(Task.Run(async () =>
                {
                    var result = await PlaceTargetOrderAsync(
                        fill, route, capturedTarget, cfg, _cts.Token)
                        .ConfigureAwait(false);
                    targetResults.Add(result);
                }));
            }

            if (targetTasks.Count == 0)
            {
                _log($"Route '{route.Label}': no active targets — nothing to copy.");
                return;
            }

            // Await ALL target placements concurrently.
            // Task.WhenAll does not throw even if individual tasks fail —
            // exceptions are captured inside PlaceTargetOrderAsync and surfaced
            // via TargetResult.Success = false.
            await Task.WhenAll(targetTasks).ConfigureAwait(false);

            // ------------------------------------------------------------------
            // Emit ONE aggregated event (scale requirement: never 1-event-per-target)
            // ------------------------------------------------------------------

            int successCount = targetResults.Count(r => r.Success);
            int failCount    = targetResults.Count(r => !r.Success);

            // Aggregate per-target summaries — keep payload small.
            // Use DestinationAccountName (server config name) as the primary label;
            // fall back to the resolved NT account name, then the connection ID.
            var perTarget = targetResults.Select(r => new
            {
                account  = r.AccountName ?? r.DestinationAccountName,
                qty      = r.Quantity,
                ok       = r.Success,
                reason   = r.FailureReason  // null on success
            }).ToList();

            string eventType = failCount == 0 ? "copy_executed" : "copy_failed";
            string severity  = failCount == 0 ? "info"
                             : (successCount == 0 ? "warning" : "info");

            _eventQueue.Enqueue(new AutomationEvent
            {
                EventType          = eventType,
                Severity           = severity,
                // Include the source connection ID for back-compat with existing
                // web event displays; also include the account name for new displays.
                BrokerConnectionId = route.SourceConnectionId,
                Symbol             = fill.InstrumentName,
                Payload            = new
                {
                    execution_id         = fill.ExecutionId,
                    // Source account: prefer the config-level name (what the web
                    // configured), then fall back to the NT fill's account name.
                    source_account       = route.SourceAccountName ?? fill.AccountName,
                    source_account_nt    = fill.AccountName,    // NT-resolved name
                    source_broker        = route.SourceBroker,
                    source_environment   = route.SourceEnvironment,
                    symbol               = fill.InstrumentName,
                    side                 = fill.IsBuy ? "buy" : "sell",
                    source_qty           = fill.Quantity,
                    is_opening           = fill.IsOpening,
                    reversed             = route.Reverse,
                    route_id             = route.Id,
                    route_label          = route.Label,
                    targets_total        = targetResults.Count,
                    targets_ok           = successCount,
                    targets_failed       = failCount,
                    per_target           = perTarget
                }
            });

            _log($"Copy job complete — route '{route.Label}': " +
                 $"{successCount}/{targetResults.Count} targets OK, {failCount} failed.");

            // ------------------------------------------------------------------
            // Tilt tracking: record fill result for CLOSE fills on the SOURCE
            // account so RiskEnforcer can maintain the consecutive-loss streak.
            //
            // Why source account: tilt is about the human trader going on a losing
            // streak.  The source account is where the human trades; the risk rule
            // that governs that account (matched by route.SourceConnectionId) is
            // the one that carries TiltLossStreak / TiltCooldownMinutes.
            //
            // VERIFY (NT8 API): see pre-snapshot comment above.  If the PnL delta
            // is unreliable (always 0), replace this block with a TODO hook and
            // wire it when NT8 exposes Execution.Profit directly on the fill event.
            // ------------------------------------------------------------------
            if (!fill.IsOpening)
            {
                try
                {
                    await RecordSourceFillTiltAsync(fill, cfg, preFillRealizedPnL, _cts.Token)
                        .ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    // Tilt tracking is bookkeeping — a failure here must never
                    // propagate to the caller or disrupt the copy loop.
                    _log($"RecordSourceFillTiltAsync error (non-fatal): " +
                         $"{ex.GetType().Name} — {ex.Message}");
                }
            }
        }

        // -----------------------------------------------------------------------
        // RecordSourceFillTiltAsync — tilt bookkeeping for close fills
        // -----------------------------------------------------------------------

        /// <summary>
        /// Called after every source close fill.  Computes the realized PnL delta
        /// to determine win/loss, then calls RiskEnforcer.RecordFillResultAsync for
        /// every risk rule that governs the source account.
        ///
        /// Fail-safe: all exceptions are caught by the caller.
        /// </summary>
        private async Task RecordSourceFillTiltAsync(
            FillInfo         fill,
            AutomationConfig cfg,
            double           preFillRealizedPnL,
            CancellationToken ct)
        {
            // Find risk rules that govern the SOURCE account (by SourceConnectionId).
            // A rule governs an account when its BrokerConnectionId resolves to that account.
            string sourceAccount = fill.AccountName;

            foreach (var rule in cfg.RiskRules ?? new List<RiskRule>())
            {
                if (!rule.Enforce || !rule.IsActive) continue;
                if (!rule.TiltLossStreak.HasValue)   continue;   // tilt not configured

                BrokerConnection ruleConn = FindConnection(cfg, rule.BrokerConnectionId);
                if (ruleConn == null) continue;

                string ruleAccount = _platform.ResolveAccountName(ruleConn);
                if (!string.Equals(ruleAccount, sourceAccount,
                        StringComparison.OrdinalIgnoreCase)) continue;

                // We have a tilt-enabled rule for the source account.
                // Compute PnL delta to determine win/loss.
                //
                // VERIFY (NT8 API): GetSessionRealizedPnL must reflect the P&L of
                // THIS fill by the time we call it here.  If NT8 updates its account
                // state synchronously before returning from ExecutionUpdate (i.e.
                // before the fill was enqueued), then postFill == preFill because the
                // pre-snapshot was already taken after the P&L update.  In that case,
                // swap preFillRealizedPnL to be captured in the hot-path callback
                // (before enqueue) and postFillRealizedPnL here (after fan-out), OR
                // use a per-position average-entry-price tracker to compute trade P&L
                // directly from fill.Price.
                //
                // TODO (NT8 API — if delta is always 0): implement a lightweight
                // PositionTracker that records average entry price per account+symbol,
                // then computes realized P&L from (fill.Price - avgEntry) * qty *
                // pointValue when a close fill arrives.  Wire that here instead of
                // the GetSessionRealizedPnL delta.
                double postFillRealizedPnL = _platform.GetSessionRealizedPnL(sourceAccount);
                double pnlDelta            = postFillRealizedPnL - preFillRealizedPnL;

                // Update the stored baseline for the next fill's pre-snapshot.
                _lastSourceRealizedPnL[sourceAccount] = postFillRealizedPnL;

                bool wasLoss;
                if (pnlDelta == 0.0)
                {
                    // Delta is zero — NT8 P&L update may be asynchronous; we cannot
                    // reliably determine win/loss.  Log and skip this fill rather than
                    // recording a wrong result.
                    //
                    // VERIFY (NT8 API): if this log fires consistently, the delta
                    // approach is not viable.  Implement the PositionTracker TODO above.
                    _log($"TiltTracker: PnL delta = 0 for close fill '{fill.ExecutionId}' " +
                         $"on '{sourceAccount}' — cannot determine win/loss. " +
                         "Skipping tilt recording for this fill. " +
                         "VERIFY (NT8 API): GetSessionRealizedPnL may not update synchronously.");
                    continue;
                }
                else
                {
                    wasLoss = pnlDelta < 0.0;
                }

                _log($"TiltTracker: close fill '{fill.ExecutionId}' on '{sourceAccount}': " +
                     $"PnL delta = {pnlDelta:+0.00;-0.00} → {(wasLoss ? "LOSS" : "WIN")}.");

                await _risk.RecordFillResultAsync(
                    rule.Id,
                    sourceAccount,
                    wasLoss,
                    rule,
                    ruleConn,
                    ct).ConfigureAwait(false);
            }
        }

        // -----------------------------------------------------------------------
        // PlaceTargetOrderAsync — one target account
        // -----------------------------------------------------------------------

        /// <summary>
        /// Resolves the target account, checks risk rules, computes scaled quantity,
        /// and places the mirrored order. Returns a TargetResult describing the outcome.
        /// NEVER throws — all exceptions are caught and returned as failures.
        /// </summary>
        private async Task<TargetResult> PlaceTargetOrderAsync(
            FillInfo        fill,
            CopierRoute     route,
            CopierTarget    target,
            AutomationConfig cfg,
            CancellationToken ct)
        {
            // The "display name" for this target in logs and the aggregated event:
            // prefer the server-config account name, fall back to the connection ID.
            string targetDisplayName = !string.IsNullOrWhiteSpace(target.DestinationAccountName)
                ? target.DestinationAccountName
                : target.DestinationConnectionId;

            var result = new TargetResult
            {
                DestinationAccountName = targetDisplayName,
                Quantity               = 0,
                Success                = false
            };

            try
            {
                // ---- 1. Resolve target account → local NT account name -------
                //
                // Resolution order (mirrors ApplyConfig source resolution):
                //   1. target.DestinationAccountName → ResolveAccountByName()  (primary)
                //   2. target.DestinationConnectionId → FindConnection() +
                //                                       ResolveAccountName()   (fallback)
                string targetAccount = null;

                if (!string.IsNullOrWhiteSpace(target.DestinationAccountName))
                {
                    // Primary: server gave us the exact broker account name.
                    targetAccount = _platform.ResolveAccountByName(target.DestinationAccountName);
                    if (targetAccount == null)
                    {
                        result.FailureReason =
                            $"destination account '{target.DestinationAccountName}' " +
                            "not found in local NT8 — account may not be connected";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(target.DestinationConnectionId))
                {
                    // Fallback: older server response without account_name field.
                    BrokerConnection destConn = FindConnection(cfg, target.DestinationConnectionId);
                    if (destConn == null)
                    {
                        result.FailureReason =
                            $"destination connection '{target.DestinationConnectionId}' not in config";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                    targetAccount = _platform.ResolveAccountName(destConn);
                    if (targetAccount == null)
                    {
                        result.FailureReason =
                            $"no NT account found for connection '{target.DestinationConnectionId}' (fallback)";
                        _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                        return result;
                    }
                    _log($"Target '{targetDisplayName}': resolved via legacy connection-id " +
                         $"fallback → NT account '{targetAccount}'.");
                }
                else
                {
                    result.FailureReason =
                        "target has neither DestinationAccountName nor DestinationConnectionId " +
                        "(malformed target config)";
                    _log($"Target SKIP ({targetDisplayName}): {result.FailureReason}.");
                    return result;
                }

                result.AccountName = targetAccount;

                // ---- 2. Compute scaled quantity ------------------------------

                // Scale ratio: source qty × scale_ratio, rounded to nearest int, min 1
                double rawQty   = fill.Quantity * target.ScaleRatio;
                int    scaledQty = Math.Max(1, (int)Math.Round(rawQty));

                // Hard cap: target.MaxContracts > 0 means apply it
                if (target.MaxContracts > 0 && scaledQty > target.MaxContracts)
                {
                    _log($"Target '{targetAccount}': clamping qty {scaledQty} → {target.MaxContracts} " +
                         $"(max_contracts cap).");
                    scaledQty = target.MaxContracts;
                }

                result.Quantity = scaledQty;

                // ---- 3. Apply reverse (flip side if route.Reverse) -----------
                bool copiedIsBuy = route.Reverse ? !fill.IsBuy : fill.IsBuy;

                // ---- 4. Pre-trade risk check ---------------------------------
                // IsOrderAllowed checks max_contracts, daily_loss, max_trades_per_day,
                // and tilt cooldown. If blocked → skip with a failure result.
                bool allowed = _risk.IsOrderAllowed(
                    targetAccount,
                    fill.InstrumentName,
                    scaledQty,
                    cfg.RiskRules,
                    cfg.Connections);

                if (!allowed)
                {
                    result.FailureReason = "blocked by risk rule";
                    _log($"Target '{targetAccount}': order BLOCKED by risk rule. Skipping.");
                    return result;
                }

                // ---- 5. Place the order via the platform adapter -------------
                // PlaceMarketOrder is fire-and-forget from this perspective;
                // confirmations arrive via fill callbacks (not awaited here).
                bool submitted = _platform.PlaceMarketOrder(
                    targetAccount,
                    fill.InstrumentName,
                    copiedIsBuy,
                    scaledQty);

                if (!submitted)
                {
                    result.FailureReason = "PlaceMarketOrder returned false (see NT adapter log)";
                    _log($"Target '{targetAccount}': PlaceMarketOrder failed for " +
                         $"'{fill.InstrumentName}'.");
                    return result;
                }

                // ---- 6. Update risk counters AFTER successful placement ------
                // Find the risk rule governing this target account and increment
                // the copier-opens counter (used by max_trades_per_day check).
                if (fill.IsOpening)
                {
                    foreach (var rule in cfg.RiskRules ?? new List<RiskRule>())
                    {
                        if (!rule.Enforce || !rule.IsActive) continue;
                        BrokerConnection ruleConn = FindConnection(cfg, rule.BrokerConnectionId);
                        if (ruleConn == null) continue;
                        string ruleAccount = _platform.ResolveAccountName(ruleConn);
                        if (string.Equals(ruleAccount, targetAccount,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            _risk.IncrementCopierOpens(rule.Id, targetAccount);
                        }
                    }
                }

                result.Success = true;
                _log($"Target '{targetAccount}': placed {(copiedIsBuy ? "BUY" : "SELL")} " +
                     $"{scaledQty} {fill.InstrumentName} OK.");

                return result;
            }
            catch (Exception ex)
            {
                result.FailureReason = $"{ex.GetType().Name}: {ex.Message}";
                _log($"PlaceTargetOrderAsync exception for target " +
                     $"'{result.DestinationAccountName}': {ex.Message}");
                return result;
            }
        }

        // -----------------------------------------------------------------------
        // Idempotency helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Attempts to mark an ExecutionId as processed.
        /// Returns true if this is a NEW id (should process).
        /// Returns false if already seen (duplicate — skip).
        /// Evicts oldest entries when the set exceeds MaxProcessedIds.
        /// </summary>
        private bool TryMarkProcessed(string executionId)
        {
            if (string.IsNullOrWhiteSpace(executionId))
            {
                // Cannot track an empty ID — allow through but log (edge case)
                _log("TryMarkProcessed: fill has no ExecutionId — allowing through. " +
                     "VERIFY (NT8 API): check that ExecutionEventArgs.Execution.ExecutionId is populated.");
                return true;
            }

            // TryAdd returns true only if the key was newly inserted
            if (!_processedIds.TryAdd(executionId, 1))
            {
                // Already seen — duplicate fill (e.g. reconnect replay)
                _log($"Idempotency: duplicate fill '{executionId}' — skipping.");
                return false;
            }

            // Track order of insertion for eviction
            lock (_idEvictionLock)
            {
                _idEvictionQueue.Enqueue(executionId);

                // Evict oldest entries if over cap
                while (_idEvictionQueue.Count > MaxProcessedIds)
                {
                    string oldest = _idEvictionQueue.Dequeue();
                    _processedIds.TryRemove(oldest, out _);
                }
            }

            return true;
        }

        // -----------------------------------------------------------------------
        // Activity summary (for PairingWindow status display)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns a brief human-readable summary of current copier state.
        /// Called by PairingWindow on UI refresh.
        /// </summary>
        public string GetActivitySummary()
        {
            int activeRoutes = _subscriptions.Count;
            int queueDepth   = _workerQueue.Count;
            int processedIds = _processedIds.Count;

            return $"Routes subscribed: {activeRoutes} | " +
                   $"Worker queue depth: {queueDepth} | " +
                   $"Processed fills (session): {processedIds}";
        }

        // -----------------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Finds a BrokerConnection by ID in the config. Returns null if not found.
        /// </summary>
        private static BrokerConnection FindConnection(AutomationConfig config, string connectionId)
        {
            if (config?.Connections == null || connectionId == null) return null;
            return config.Connections.Find(c =>
                string.Equals(c.Id, connectionId, StringComparison.OrdinalIgnoreCase));
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        private bool _disposed;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            // Signal the consumer loop to stop and wait for it to exit.
            _cts.Cancel();
            _workerQueue.CompleteAdding();

            try { _consumerTask?.Wait(TimeSpan.FromSeconds(3)); }
            catch { /* best-effort */ }

            // Unsubscribe all fill handlers
            foreach (var kvp in _subscriptions)
            {
                try { _platform.Unsubscribe(kvp.Value); }
                catch { /* best-effort cleanup */ }
            }
            _subscriptions.Clear();

            _cts.Dispose();
            _workerQueue.Dispose();

            _log("CopierEngine disposed.");
        }
    }
}
