// =============================================================================
// Finotaur Agent — Platform/IPlatformAdapter.cs
//
// Abstraction layer between the agent's logic (RiskEnforcer, CopierEngine)
// and the platform-specific trading APIs.
//
// The current concrete implementation is NinjaTraderAdapter (NT8).
// The interface is designed so a future adapter (e.g. for a different platform
// or a mock for unit testing) can be dropped in without changing the engines.
//
// KEY DESIGN DECISIONS (document for future implementors):
//   1. All monetary values are in USD.
//   2. Positions are current open positions (not historical fills).
//   3. "Session realized PnL" means today's closed P&L from the broker
//      (or as close as the platform API allows — document approximations).
//   4. PlaceMarketOrder is fire-and-forget from the caller's perspective;
//      fill confirmation comes via the FillSubscription callback.
//   5. account_id from BrokerConnection is matched to platform accounts by
//      the adapter. If no match is found, the adapter skips that account
//      and must NOT guess.
// =============================================================================

using System;
using System.Collections.Generic;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform
{
    /// <summary>
    /// Platform-agnostic trading interface used by RiskEnforcer and CopierEngine.
    /// All implementations must be thread-safe (the agent runs a background loop).
    /// </summary>
    public interface IPlatformAdapter : IDisposable
    {
        // -----------------------------------------------------------------------
        // Account discovery
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns all accounts currently visible to the platform.
        /// Includes simulation and live accounts — callers must filter by environment.
        /// NEVER returns null; returns an empty collection if no accounts are found.
        /// </summary>
        IEnumerable<AgentAccount> GetAccounts();

        /// <summary>
        /// Attempts to resolve a BrokerConnection (from the server config) to a
        /// local platform account name. Returns null if no confident match is found.
        /// Callers MUST treat null as "skip this connection — do nothing."
        ///
        /// Used by: risk-rule resolution (which still keys off BrokerConnectionId).
        /// For copier routing, prefer <see cref="ResolveAccountByName"/> which
        /// matches directly on the broker account name string.
        /// </summary>
        string ResolveAccountName(BrokerConnection connection);

        /// <summary>
        /// Resolves a broker account name (e.g. "MFFUEVBLDR161429081" — the value
        /// the FINOTAUR server returns as <c>account_name</c> on an
        /// <c>AutomationAccount</c>, <c>CopierRoute.SourceAccountName</c>, or
        /// <c>CopierTarget.DestinationAccountName</c>) to the local NT
        /// <c>Account.Name</c>.
        ///
        /// <para>
        /// Matching is case-insensitive and trims leading/trailing whitespace.
        /// Returns the NT account's own <c>Account.Name</c> string (canonical form)
        /// on success, or <c>null</c> if no local account matches.
        /// </para>
        ///
        /// <para>
        /// Callers MUST treat null as "this account is not connected in NT8 —
        /// skip the route/target and emit a diagnostic event."  Do NOT guess.
        /// </para>
        /// </summary>
        /// <param name="accountName">
        /// The broker account name from the server config (e.g.
        /// "MFFUEVBLDR161429081").  Must not be null or whitespace.
        /// </param>
        /// <returns>
        /// The NT <c>Account.Name</c> of the matching local account, or
        /// <c>null</c> if no confident match was found.
        /// </returns>
        string ResolveAccountByName(string accountName);

        // -----------------------------------------------------------------------
        // Position and PnL queries
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns all current open positions for the named account.
        /// Returns an empty array if the account has no positions or is not found.
        /// NEVER returns null.
        /// </summary>
        AgentPosition[] GetPositions(string accountName);

        /// <summary>
        /// Returns today's realized PnL (closed trades only) for the named account,
        /// in USD. Returns 0.0 if unavailable (never throws).
        /// VERIFY (NT8 API): NinjaTrader's Account.Get(AccountItem.CashValue) or
        /// similar may be needed. Document the exact API call in NinjaTraderAdapter.
        /// </summary>
        double GetSessionRealizedPnL(string accountName);

        /// <summary>
        /// Returns the total unrealized PnL across all open positions for the
        /// named account, in USD. Returns 0.0 if unavailable.
        /// </summary>
        double GetOpenPnL(string accountName);

        /// <summary>
        /// Returns the total number of open contracts across all instruments for
        /// the named account. If symbol is provided, scopes to that instrument only.
        /// Returns 0 if account is not found.
        /// </summary>
        int GetOpenContracts(string accountName, string symbol = null);

        // -----------------------------------------------------------------------
        // Order actions (all must be locally guarded by the caller)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Flattens ALL open positions on the named account immediately using a
        /// market order. Used by the daily-loss risk enforcer.
        ///
        /// FAIL-SAFE: If the account cannot be found, DO NOTHING and return false.
        /// Never throw. Never guess.
        /// </summary>
        /// <returns>True if the flatten command was issued, false if skipped/errored.</returns>
        bool FlattenAll(string accountName);

        /// <summary>
        /// Flattens open positions in a specific instrument on the named account.
        /// Used for per-symbol risk enforcement.
        /// FAIL-SAFE: same rules as FlattenAll.
        /// </summary>
        bool FlattenSymbol(string accountName, string symbol);

        /// <summary>
        /// Places a market order for the specified quantity.
        /// Used by CopierEngine to mirror source fills.
        ///
        /// FAIL-SAFE: If account, instrument, or quantity cannot be validated,
        /// DO NOTHING and return false. Never throw.
        /// </summary>
        /// <param name="accountName">Target account name (resolved by ResolveAccountName).</param>
        /// <param name="instrumentName">NT8 instrument name, e.g. "NQ 09-26".</param>
        /// <param name="isBuy">true = Buy, false = Sell.</param>
        /// <param name="quantity">Number of contracts. Must be >= 1.</param>
        /// <returns>True if order was submitted, false if skipped.</returns>
        bool PlaceMarketOrder(string accountName, string instrumentName, bool isBuy, int quantity);

        // -----------------------------------------------------------------------
        // Fill subscription (used by CopierEngine)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Registers a callback that fires on every new fill on the named account.
        /// The callback receives a normalized FillInfo object.
        ///
        /// Callers must call Unsubscribe with the returned handle to deregister.
        /// Multiple subscriptions on the same account are supported.
        /// </summary>
        /// <param name="accountName">Account to watch.</param>
        /// <param name="onFill">Callback fired on each new fill.</param>
        /// <returns>
        /// An opaque subscription handle passed to Unsubscribe.
        /// Returns null if the account was not found — caller must not proceed.
        /// </returns>
        object SubscribeFills(string accountName, Action<FillInfo> onFill);

        /// <summary>
        /// Deregisters a fill subscription previously returned by SubscribeFills.
        /// Safe to call with a null handle (no-op).
        /// </summary>
        void Unsubscribe(object subscriptionHandle);
    }

    // -------------------------------------------------------------------------
    // Supporting types used by IPlatformAdapter
    // -------------------------------------------------------------------------

    /// <summary>
    /// A single open position on a platform account.
    /// </summary>
    public class AgentPosition
    {
        /// <summary>Platform instrument name (e.g. "NQ 09-26", "ES 09-26").</summary>
        public string InstrumentName { get; set; }

        /// <summary>Number of open contracts (always positive).</summary>
        public int Quantity { get; set; }

        /// <summary>true = Long, false = Short.</summary>
        public bool IsLong { get; set; }

        /// <summary>Current unrealized PnL for this position in USD.</summary>
        public double UnrealizedPnL { get; set; }

        /// <summary>
        /// Current market value of the position in USD (quantity * price * point value).
        /// VERIFY (NT8 API): may require Instrument.MasterInstrument.PointValue.
        /// Set to 0.0 if not computable — RiskEnforcer will skip max_position_usd check.
        /// </summary>
        public double MarketValueUsd { get; set; }
    }
}
