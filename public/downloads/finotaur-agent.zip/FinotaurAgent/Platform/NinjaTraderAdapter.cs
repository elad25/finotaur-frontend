// =============================================================================
// Finotaur Agent — Platform/NinjaTraderAdapter.cs
//
// IPlatformAdapter implementation against the NinjaTrader 8 Cbi (client-broker
// interface) API. All NT8 API calls are annotated with VERIFY comments where
// the exact method signatures or availability in AddOn context is uncertain.
//
// COMPILE-TIME NOTE:
//   This file references types in NinjaTrader.Cbi and NinjaTrader.Core.
//   These assemblies are available in the NT8 NinjaScript environment.
//   If you see "type not found" errors, check that you are compiling inside
//   the NinjaTrader NinjaScript Editor (not a standalone .NET project).
//
// THREADING:
//   NT8's Account.All collection must be accessed under lock(Account.All).
//   All public methods in this adapter acquire that lock when touching Account.All.
//   Fill callbacks may arrive on NT8's internal threads — the onFill delegate
//   is invoked directly; callers must be thread-safe.
//
// ACCOUNT MATCHING:
//   The server returns BrokerConnection.account_id (a string, e.g. "12345" for
//   Tradovate). We match it to NT8 Account.Name. Tradovate's NT8 account name
//   may be "Demo 12345" or just "12345" depending on NT8 version and connection.
//   The matching strategy: try exact match first, then suffix match.
//   If ambiguous or no match: skip and post agent_status event.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;                   // Account, Order, Execution, Position, etc.
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;

// VERIFY (NT8 API): confirm namespace for Account, OrderAction, OrderType, etc.
// In NT8 strategies: NinjaTrader.Cbi.Account, NinjaTrader.Cbi.OrderAction, etc.
// These are the same namespaces in AddOn context, but confirm in the NT8 API docs.

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform
{
    /// <summary>
    /// NT8-specific IPlatformAdapter. Uses NinjaTrader.Cbi APIs for all
    /// account queries and order submission.
    ///
    /// Every public method is fail-safe: it catches all exceptions, logs them,
    /// and returns a safe default (null / false / 0 / empty). It NEVER throws.
    /// </summary>
    public class NinjaTraderAdapter : IPlatformAdapter
    {
        // -----------------------------------------------------------------------
        // Fill subscription bookkeeping
        // -----------------------------------------------------------------------

        // Handle type for fill subscriptions. Wraps the account name + the
        // delegate so we can unhook from ExecutionUpdate.
        private class FillSubscription
        {
            public string AccountName   { get; set; }
            public Action<FillInfo> OnFill { get; set; }

            // We store the NT8-level handler so we can -= it on Unsubscribe.
            // VERIFY (NT8 API): ExecutionUpdate signature is:
            //   private void Handler(object sender, ExecutionEventArgs e)
            // where sender is the Account.
            public EventHandler<ExecutionEventArgs> NtHandler { get; set; }
        }

        // Thread-safe dictionary from subscription ID -> subscription
        private readonly ConcurrentDictionary<Guid, FillSubscription> _subscriptions =
            new ConcurrentDictionary<Guid, FillSubscription>();

        // Track which account objects we have hooked so we only hook once per account.
        private readonly ConcurrentDictionary<string, Account> _hookedAccounts =
            new ConcurrentDictionary<string, Account>();

        // -----------------------------------------------------------------------
        // Logger (injected to avoid circular dependencies)
        // -----------------------------------------------------------------------

        private readonly Action<string> _log;

        public NinjaTraderAdapter(Action<string> logger = null)
        {
            _log = logger ?? (msg => System.Diagnostics.Debug.WriteLine($"[NtAdapter] {msg}"));
        }

        // -----------------------------------------------------------------------
        // GetAccounts
        // -----------------------------------------------------------------------

        public IEnumerable<AgentAccount> GetAccounts()
        {
            var result = new List<AgentAccount>();
            try
            {
                // VERIFY (NT8 API): Account.All is the collection of all accounts
                // registered in the NT8 Control Center. Must lock before iterating.
                lock (Account.All)
                {
                    foreach (Account acct in Account.All)
                    {
                        result.Add(new AgentAccount
                        {
                            Name           = acct.Name,
                            // VERIFY (NT8 API): Account.Connection?.Name gives the
                            // connection profile name (e.g. "Tradovate").
                            ConnectionName = acct.Connection?.Name ?? "Unknown",
                            // VERIFY (NT8 API): Simulated accounts in NT8 may have
                            // Account.Name containing "Sim" or Connection.Options
                            // indicating simulation. Check your account names.
                            IsSimulation   = acct.Name.IndexOf("Sim", StringComparison.OrdinalIgnoreCase) >= 0
                                          || acct.Name.IndexOf("Demo", StringComparison.OrdinalIgnoreCase) >= 0
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"GetAccounts error: {ex.Message}");
            }
            return result;
        }

        // -----------------------------------------------------------------------
        // ResolveAccountName
        // -----------------------------------------------------------------------

        public string ResolveAccountName(BrokerConnection connection)
        {
            if (connection == null || string.IsNullOrWhiteSpace(connection.AccountId))
                return null;

            string targetId = connection.AccountId.Trim();

            try
            {
                lock (Account.All)
                {
                    // Strategy 1: exact match on Account.Name
                    Account exact = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, targetId, StringComparison.OrdinalIgnoreCase));
                    if (exact != null) return exact.Name;

                    // Strategy 2: Account.Name ends with the account_id
                    // (e.g. "Demo 12345" matched by "12345")
                    Account suffix = Account.All.FirstOrDefault(a =>
                        a.Name.EndsWith(targetId, StringComparison.OrdinalIgnoreCase));
                    if (suffix != null)
                    {
                        _log($"ResolveAccountName: matched '{targetId}' to NT account " +
                             $"'{suffix.Name}' by suffix. VERIFY this is the correct account.");
                        return suffix.Name;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ResolveAccountName error for connection {connection.Id}: {ex.Message}");
            }

            _log($"ResolveAccountName: NO match for account_id='{targetId}'. " +
                 "Skipping this connection. Check that the Tradovate account is connected in NT8.");
            return null;
        }

        // -----------------------------------------------------------------------
        // ResolveAccountByName
        // -----------------------------------------------------------------------

        /// <summary>
        /// Resolves a broker account name string (e.g. "MFFUEVBLDR161429081",
        /// the value the FINOTAUR server returns as <c>account_name</c>) to the
        /// local NT <c>Account.Name</c> by a case-insensitive exact match.
        ///
        /// <para>
        /// This is the <b>primary</b> account-resolution path for copier routing.
        /// It is simpler than <see cref="ResolveAccountName(BrokerConnection)"/>
        /// because the server now sends the exact NT account name directly, so we
        /// do not need the numeric-ID suffix-match heuristic.
        /// </para>
        ///
        /// Returns <c>null</c> if no local account matches.  The caller MUST treat
        /// null as "this account is not connected in NT8 — skip and log."
        /// </summary>
        public string ResolveAccountByName(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
            {
                _log("ResolveAccountByName: called with null/empty accountName — returning null.");
                return null;
            }

            string target = accountName.Trim();

            try
            {
                // VERIFY (NT8 API): Account.All must be accessed under lock(Account.All).
                // Iterate and compare Account.Name case-insensitively.
                lock (Account.All)
                {
                    Account match = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, target, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        // Return the canonical NT name (preserves its original casing).
                        return match.Name;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ResolveAccountByName error for '{target}': {ex.Message}");
                return null;
            }

            _log($"ResolveAccountByName: NO local NT account matched '{target}'. " +
                 "The account may not be connected in NT8. " +
                 "Open NinjaTrader Control Center → Accounts and verify the account name. " +
                 "Skipping this route/target.");
            return null;
        }

        // -----------------------------------------------------------------------
        // GetPositions
        // -----------------------------------------------------------------------

        public AgentPosition[] GetPositions(string accountName)
        {
            var positions = new List<AgentPosition>();
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return positions.ToArray();

                // VERIFY (NT8 API): Account.Positions is IEnumerable<Position>.
                // Position has: MarketPosition (Long/Short/Flat), Quantity, Instrument,
                // UnrealizedProfitLoss (in account currency).
                lock (Account.All)
                {
                    foreach (Position pos in acct.Positions)
                    {
                        // VERIFY (NT8 API): MarketPosition.Flat means no position — skip.
                        if (pos.MarketPosition == MarketPosition.Flat) continue;

                        double pointValue = 1.0;
                        try
                        {
                            // VERIFY (NT8 API): Instrument.MasterInstrument.PointValue
                            // gives the dollar value of one point movement per contract.
                            pointValue = pos.Instrument.MasterInstrument.PointValue;
                        }
                        catch { /* best-effort; leave pointValue = 1.0 */ }

                        // VERIFY (NT8 API): pos.AveragePrice is the average entry price.
                        double marketValue = pos.AveragePrice * pos.Quantity * pointValue;

                        positions.Add(new AgentPosition
                        {
                            InstrumentName  = pos.Instrument.FullName,
                            Quantity        = pos.Quantity,
                            IsLong          = pos.MarketPosition == MarketPosition.Long,
                            // VERIFY (NT8 API): UnrealizedProfitLoss is in account currency (USD).
                            UnrealizedPnL   = pos.UnrealizedProfitLoss,
                            MarketValueUsd  = marketValue
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"GetPositions error for '{accountName}': {ex.Message}");
            }
            return positions.ToArray();
        }

        // -----------------------------------------------------------------------
        // GetSessionRealizedPnL
        // -----------------------------------------------------------------------

        public double GetSessionRealizedPnL(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return 0.0;

                // VERIFY (NT8 API): Account.Get(AccountItem.RealizedProfitLoss) returns
                // the session realized PnL. Confirm the AccountItem enum value and that
                // it represents today's P&L (not cumulative from account inception).
                // Alternative: Account.Get(AccountItem.CashValue) - Account.Get(AccountItem.InitialCashBalance)
                // but that may not be day-scoped. Check NinjaTrader API reference.
                double realized = acct.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);

                // VERIFY (NT8 API): Currency.UsDollar — confirm this enum exists in NT8 Cbi.
                // If not, use Currency.Default or omit the currency parameter.
                return realized;
            }
            catch (Exception ex)
            {
                _log($"GetSessionRealizedPnL error for '{accountName}': {ex.Message}");
                return 0.0;
            }
        }

        // -----------------------------------------------------------------------
        // GetOpenPnL
        // -----------------------------------------------------------------------

        public double GetOpenPnL(string accountName)
        {
            try
            {
                AgentPosition[] positions = GetPositions(accountName);
                return positions.Sum(p => p.UnrealizedPnL);
            }
            catch (Exception ex)
            {
                _log($"GetOpenPnL error for '{accountName}': {ex.Message}");
                return 0.0;
            }
        }

        // -----------------------------------------------------------------------
        // GetOpenContracts
        // -----------------------------------------------------------------------

        public int GetOpenContracts(string accountName, string symbol = null)
        {
            try
            {
                AgentPosition[] positions = GetPositions(accountName);

                if (string.IsNullOrWhiteSpace(symbol))
                    return positions.Sum(p => p.Quantity);

                return positions
                    .Where(p => p.InstrumentName.IndexOf(symbol, StringComparison.OrdinalIgnoreCase) >= 0)
                    .Sum(p => p.Quantity);
            }
            catch (Exception ex)
            {
                _log($"GetOpenContracts error for '{accountName}': {ex.Message}");
                return 0;
            }
        }

        // -----------------------------------------------------------------------
        // FlattenAll
        // -----------------------------------------------------------------------

        public bool FlattenAll(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"FlattenAll: account '{accountName}' not found — SKIPPING (fail-safe).");
                    return false;
                }

                _log($"FlattenAll: Issuing flatten on account '{accountName}'.");

                // VERIFY (NT8 API): account.Flatten() flattens all positions with
                // market orders. In NT8 this may be:
                //   acct.Flatten(null);      // flatten all instruments
                // or
                //   acct.FlattenEverything(); // if that method exists
                // Check the NT8 Cbi.Account API for the exact signature.
                acct.Flatten(null);    // VERIFY: pass null = all instruments

                return true;
            }
            catch (Exception ex)
            {
                _log($"FlattenAll error for '{accountName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // FlattenSymbol
        // -----------------------------------------------------------------------

        public bool FlattenSymbol(string accountName, string symbol)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null || string.IsNullOrWhiteSpace(symbol))
                {
                    _log($"FlattenSymbol: precondition failed for '{accountName}/{symbol}' — SKIPPING.");
                    return false;
                }

                // VERIFY (NT8 API): Find the Instrument by name and pass to Flatten.
                // Instrument.GetInstrument(string name) may require an exact NT8 name.
                // Alternatively iterate acct.Positions, find the matching position,
                // and submit a market order in the opposite direction.
                Instrument instr = Instrument.GetInstrument(symbol);
                if (instr == null)
                {
                    _log($"FlattenSymbol: instrument '{symbol}' not found in NT8 — SKIPPING.");
                    return false;
                }

                _log($"FlattenSymbol: Issuing flatten on '{accountName}' / '{symbol}'.");
                acct.Flatten(instr);   // VERIFY: overload that accepts Instrument object

                return true;
            }
            catch (Exception ex)
            {
                _log($"FlattenSymbol error for '{accountName}/{symbol}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // PlaceMarketOrder
        // -----------------------------------------------------------------------

        public bool PlaceMarketOrder(string accountName, string instrumentName, bool isBuy, int quantity)
        {
            // Hard guards — never submit a zero or negative qty order.
            if (quantity < 1)
            {
                _log($"PlaceMarketOrder: quantity={quantity} is invalid — SKIPPING.");
                return false;
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"PlaceMarketOrder: account '{accountName}' not found — SKIPPING.");
                    return false;
                }

                // VERIFY (NT8 API): Instrument.GetInstrument(string) returns the instrument
                // or null if not found. The name must match NT8's exact format (e.g. "NQ 09-26").
                Instrument instr = Instrument.GetInstrument(instrumentName);
                if (instr == null)
                {
                    _log($"PlaceMarketOrder: instrument '{instrumentName}' not found in NT8 — SKIPPING.");
                    return false;
                }

                OrderAction action = isBuy ? OrderAction.Buy : OrderAction.Sell;

                _log($"PlaceMarketOrder: {action} {quantity} {instrumentName} on '{accountName}'.");

                // VERIFY (NT8 API): Account.CreateOrder + Account.Submit is the NT8 way to
                // submit orders programmatically outside a strategy.
                // Alternative: use acct.Submit(new Order { ... }) if CreateOrder is not available.
                // Check NinjaTrader 8 AddOn examples for the correct pattern.
                //
                // The order below uses TimeInForce.Day (good for the session).
                // Adjust if the platform requires a different TIF for market orders.
                Order order = acct.CreateOrder(
                    instr,
                    action,
                    OrderType.Market,
                    TimeInForce.Day,   // VERIFY: may need TimeInForce.Gtc or TimeInForce.Default
                    quantity,
                    0,                 // limit price (not used for market)
                    0,                 // stop price (not used for market)
                    string.Empty,      // OCO id
                    "FinotaurCopier",  // custom label visible in the Executions tab
                    DateTime.Now,
                    null               // advanced options
                );

                if (order == null)
                {
                    _log($"PlaceMarketOrder: CreateOrder returned null for {instrumentName} — SKIPPING.");
                    return false;
                }

                acct.Submit(new[] { order }); // VERIFY: Submit signature in AddOn context

                return true;
            }
            catch (Exception ex)
            {
                _log($"PlaceMarketOrder error for '{accountName}/{instrumentName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // SubscribeFills / Unsubscribe
        // -----------------------------------------------------------------------

        public object SubscribeFills(string accountName, Action<FillInfo> onFill)
        {
            if (onFill == null) return null;

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"SubscribeFills: account '{accountName}' not found — cannot subscribe.");
                    return null;
                }

                var sub = new FillSubscription
                {
                    AccountName = accountName,
                    OnFill      = onFill
                };

                // Build the NT8 ExecutionUpdate handler
                // VERIFY (NT8 API): ExecutionEventArgs.Execution contains:
                //   Execution.ExecutionId (string)
                //   Execution.Order.OrderAction (Buy/Sell)
                //   Execution.Quantity
                //   Execution.Price
                //   Execution.Instrument.FullName
                //   Execution.Time
                //   Execution.Account.Name
                // Confirm these properties on ExecutionEventArgs.Execution in NT8.
                EventHandler<ExecutionEventArgs> ntHandler = (sender, e) =>
                {
                    try
                    {
                        var exec = e.Execution;
                        if (exec == null) return;
                        if (!string.Equals(exec.Account?.Name, accountName,
                                StringComparison.OrdinalIgnoreCase)) return;

                        // Approximate IsOpening: if order action is Buy and position was
                        // flat/short, or Sell and position was flat/long.
                        // This is a best-effort approximation — the adapter does not track
                        // pre-fill position state. CopierEngine uses this flag but has its
                        // own copy_opens/copy_closes logic to fall back on.
                        // VERIFY (NT8 API): a more precise approach is to track positions
                        // before each fill and compare after. Implement if needed.
                        bool isBuy = exec.Order?.OrderAction == OrderAction.Buy ||
                                     exec.Order?.OrderAction == OrderAction.BuyToCover;
                        bool isOpening = isBuy;  // simplified: Buy = opening a long
                                                  // VERIFY: refine with position tracking

                        var fill = new FillInfo
                        {
                            ExecutionId    = exec.ExecutionId,
                            AccountName    = exec.Account?.Name,
                            InstrumentName = exec.Instrument?.FullName,
                            IsBuy          = isBuy,
                            Quantity       = exec.Quantity,
                            Price          = exec.Price,
                            IsOpening      = isOpening,
                            Timestamp      = exec.Time
                        };

                        sub.OnFill(fill);
                    }
                    catch (Exception ex)
                    {
                        _log($"SubscribeFills handler error: {ex.Message}");
                    }
                };

                sub.NtHandler = ntHandler;

                // Hook into the account's ExecutionUpdate event.
                // We only hook each account once to avoid duplicate callbacks.
                if (_hookedAccounts.TryAdd(accountName, acct))
                {
                    acct.ExecutionUpdate += ntHandler; // VERIFY (NT8 API): ExecutionUpdate event name on Account
                }
                else
                {
                    // Account already hooked for another subscription — add just the handler
                    acct.ExecutionUpdate += ntHandler;
                }

                var id = Guid.NewGuid();
                _subscriptions[id] = sub;

                _log($"SubscribeFills: subscribed to '{accountName}' (sub id: {id}).");
                return id; // opaque handle
            }
            catch (Exception ex)
            {
                _log($"SubscribeFills error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        public void Unsubscribe(object subscriptionHandle)
        {
            if (subscriptionHandle == null) return;
            if (!(subscriptionHandle is Guid id)) return;

            try
            {
                if (!_subscriptions.TryRemove(id, out FillSubscription sub)) return;

                Account acct = FindAccount(sub.AccountName);
                if (acct != null && sub.NtHandler != null)
                {
                    acct.ExecutionUpdate -= sub.NtHandler; // VERIFY (NT8 API): -= event handler removal
                }

                _log($"Unsubscribe: removed subscription {id} for '{sub.AccountName}'.");
            }
            catch (Exception ex)
            {
                _log($"Unsubscribe error: {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Private helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Finds an NT8 Account by name. Returns null if not found (never throws).
        /// Caller is responsible for null-checking.
        /// </summary>
        private Account FindAccount(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return null;
            try
            {
                lock (Account.All)
                {
                    return Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, accountName, StringComparison.OrdinalIgnoreCase));
                }
            }
            catch (Exception ex)
            {
                _log($"FindAccount error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        private bool _disposed;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            // Unhook all remaining subscriptions
            foreach (var kvp in _subscriptions)
            {
                try
                {
                    Account acct = FindAccount(kvp.Value.AccountName);
                    if (acct != null && kvp.Value.NtHandler != null)
                        acct.ExecutionUpdate -= kvp.Value.NtHandler;
                }
                catch { /* best-effort cleanup */ }
            }
            _subscriptions.Clear();
            _hookedAccounts.Clear();
        }
    }
}
