// =============================================================================
// Finotaur Agent — Risk/RiskEnforcer.cs
//
// LOCAL risk enforcement engine. Runs on every poll cycle, checking platform
// state against the active risk rules fetched from the FINOTAUR server.
//
// ENFORCEMENT PHILOSOPHY:
//   - Only rules with enforce == true AND is_active == true are enforced.
//   - Advisory (enforce == false) rules are COMPLETELY ignored by this class.
//   - On ANY uncertainty (missing data, unknown account) → do nothing.
//   - Debounce: once an enforcement action fires, it is NOT re-fired every poll
//     until the condition is resolved (e.g. the account is re-opened or the day
//     resets). This prevents spam flattening.
//   - All enforcement actions trigger a PostEventAsync call to the web.
//
// THREAD SAFETY:
//   RunAsync is called from the agent's background loop. CheckAndDebounce on
//   the debounce dictionaries is protected by a simple lock.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk
{
    public class RiskEnforcer
    {
        // -----------------------------------------------------------------------
        // Dependencies
        // -----------------------------------------------------------------------

        private readonly IPlatformAdapter _platform;
        private readonly FinotaurClient   _client;
        private readonly Action<string>   _log;

        // -----------------------------------------------------------------------
        // Debounce state
        // Key = "{ruleId}:{accountName}:{checkType}"
        // Value = DateTime when the last enforcement/alert was fired
        // -----------------------------------------------------------------------

        private readonly ConcurrentDictionary<string, DateTime> _firedAt =
            new ConcurrentDictionary<string, DateTime>();

        // Tilt state per account-rule:
        //   Key   = "{ruleId}:{accountName}"
        //   Value = consecutive losing trade count
        private readonly ConcurrentDictionary<string, int> _lossStreaks =
            new ConcurrentDictionary<string, int>();

        // Tilt cooldown end times:
        //   Key   = "{ruleId}:{accountName}"
        //   Value = DateTime when tilt cooldown expires
        private readonly ConcurrentDictionary<string, DateTime> _tiltUntil =
            new ConcurrentDictionary<string, DateTime>();

        // Per-day copier open counts:
        //   Key   = "{ruleId}:{accountName}:{utcDate}"
        //   Value = count of copier opens today
        // This is maintained externally by CopierEngine calling IncrementCopierOpens.
        private readonly ConcurrentDictionary<string, int> _dailyCopierOpens =
            new ConcurrentDictionary<string, int>();

        // Debounce interval — avoid firing the same enforcement more than once
        // per interval. Prevents flatten spam on every poll.
        private static readonly TimeSpan DebounceInterval = TimeSpan.FromSeconds(30);

        // -----------------------------------------------------------------------
        // Constructor
        // -----------------------------------------------------------------------

        public RiskEnforcer(
            IPlatformAdapter platform,
            FinotaurClient   client,
            Action<string>   logger = null)
        {
            _platform = platform;
            _client   = client;
            _log      = logger ?? (m => System.Diagnostics.Debug.WriteLine($"[RiskEnforcer] {m}"));
        }

        // -----------------------------------------------------------------------
        // RunAsync — called every poll cycle with the current config
        // -----------------------------------------------------------------------

        /// <summary>
        /// Evaluates all active+enforced risk rules against current platform state.
        /// Safe to call frequently — individual checks are debounced.
        /// Does nothing if rules list is null or empty.
        /// </summary>
        public async Task RunAsync(
            AutomationConfig config,
            CancellationToken ct = default)
        {
            if (config?.RiskRules == null) return;

            foreach (var rule in config.RiskRules)
            {
                if (ct.IsCancellationRequested) break;

                // Skip advisory rules — agent never enforces these
                if (!rule.Enforce || !rule.IsActive) continue;

                // Find the matching broker connection
                BrokerConnection conn = FindConnection(config, rule.BrokerConnectionId);
                if (conn == null)
                {
                    _log($"RiskEnforcer: rule '{rule.Label}' references unknown " +
                         $"connection '{rule.BrokerConnectionId}' — SKIPPING.");
                    continue;
                }

                // Map connection to a local NT account
                string accountName = _platform.ResolveAccountName(conn);
                if (accountName == null)
                {
                    // No match — already logged by adapter; do not act
                    continue;
                }

                await EvaluateRuleAsync(rule, conn, accountName, ct).ConfigureAwait(false);
            }
        }

        // -----------------------------------------------------------------------
        // EvaluateRuleAsync — one rule, one account
        // -----------------------------------------------------------------------

        private async Task EvaluateRuleAsync(
            RiskRule rule,
            BrokerConnection conn,
            string accountName,
            CancellationToken ct)
        {
            // ---- (a) Daily loss limit ----------------------------------------
            if (rule.DailyLossLimitUsd.HasValue)
            {
                double realized = _platform.GetSessionRealizedPnL(accountName);
                double openPnl  = _platform.GetOpenPnL(accountName);
                double totalPnl = realized + openPnl;

                // Breach condition: totalPnl <= -(daily_loss_limit_usd)
                // E.g. limit = 500 -> flatten when totalPnl <= -500
                double threshold = -Math.Abs(rule.DailyLossLimitUsd.Value);

                if (totalPnl <= threshold)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:daily_loss";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ENFORCED — daily loss limit hit on '{accountName}'. " +
                             $"Total PnL: {totalPnl:C2} <= threshold {threshold:C2}. Flattening.");

                        _platform.FlattenAll(accountName);

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_enforced",
                            Severity           = "critical",
                            BrokerConnectionId = conn.Id,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id          = rule.Id,
                                rule_label       = rule.Label,
                                check            = "daily_loss",
                                realized_pnl     = realized,
                                open_pnl         = openPnl,
                                total_pnl        = totalPnl,
                                threshold        = threshold,
                                action           = "flatten_all"
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
                else
                {
                    // Condition no longer met — clear debounce so it can fire again
                    // if PnL recovers above threshold and then breaches again.
                    ClearDebounce($"{rule.Id}:{accountName}:daily_loss");
                }
            }

            // ---- (b) Max contracts per instrument ---------------------------
            if (rule.MaxContracts.HasValue)
            {
                AgentPosition[] positions = _platform.GetPositions(accountName);
                foreach (var pos in positions)
                {
                    if (pos.Quantity > rule.MaxContracts.Value)
                    {
                        string debounceKey = $"{rule.Id}:{accountName}:max_contracts:{pos.InstrumentName}";
                        if (ShouldFire(debounceKey))
                        {
                            _log($"RISK ALERT — max_contracts exceeded on '{accountName}' / " +
                                 $"'{pos.InstrumentName}': {pos.Quantity} > {rule.MaxContracts.Value}. " +
                                 "Flattening to symbol (not full account).");

                            // Flatten the specific instrument rather than the whole account
                            _platform.FlattenSymbol(accountName, pos.InstrumentName);

                            await _client.PostEventAsync(new AutomationEvent
                            {
                                EventType          = "risk_enforced",
                                Severity           = "warning",
                                BrokerConnectionId = conn.Id,
                                Symbol             = pos.InstrumentName,
                                Payload            = new
                                {
                                    rule_id      = rule.Id,
                                    rule_label   = rule.Label,
                                    check        = "max_contracts",
                                    current_qty  = pos.Quantity,
                                    max_allowed  = rule.MaxContracts.Value,
                                    action       = "flatten_symbol"
                                }
                            }, ct).ConfigureAwait(false);
                        }
                    }
                    else
                    {
                        ClearDebounce($"{rule.Id}:{accountName}:max_contracts:{pos.InstrumentName}");
                    }
                }
            }

            // ---- (c) Max position USD --------------------------------------
            if (rule.MaxPositionUsd.HasValue)
            {
                AgentPosition[] positions = _platform.GetPositions(accountName);
                foreach (var pos in positions)
                {
                    // MarketValueUsd may be 0 if not computable — skip in that case
                    if (pos.MarketValueUsd <= 0) continue;

                    if (pos.MarketValueUsd > rule.MaxPositionUsd.Value)
                    {
                        string debounceKey = $"{rule.Id}:{accountName}:max_pos_usd:{pos.InstrumentName}";
                        if (ShouldFire(debounceKey))
                        {
                            _log($"RISK ALERT — max_position_usd exceeded on '{accountName}' / " +
                                 $"'{pos.InstrumentName}': {pos.MarketValueUsd:C2} > " +
                                 $"{rule.MaxPositionUsd.Value:C2}.");

                            // Post alert — do not flatten for this check (could be legitimate
                            // large position); flatten is reserved for daily loss and max_contracts.
                            // Change this behavior if Elad decides enforcement should flatten here too.
                            await _client.PostEventAsync(new AutomationEvent
                            {
                                EventType          = "risk_alert",
                                Severity           = "warning",
                                BrokerConnectionId = conn.Id,
                                Symbol             = pos.InstrumentName,
                                Payload            = new
                                {
                                    rule_id       = rule.Id,
                                    rule_label    = rule.Label,
                                    check         = "max_position_usd",
                                    position_usd  = pos.MarketValueUsd,
                                    max_allowed   = rule.MaxPositionUsd.Value,
                                    action        = "alert_only"
                                }
                            }, ct).ConfigureAwait(false);
                        }
                    }
                    else
                    {
                        ClearDebounce($"{rule.Id}:{accountName}:max_pos_usd:{pos.InstrumentName}");
                    }
                }
            }

            // ---- (d) Max trades per day (copier opens) ----------------------
            // The actual count is maintained by IncrementCopierOpens, called by
            // CopierEngine. Here we check the limit and post an alert if crossed.
            // The copier engine calls IsWithinTradeLimit before placing orders.
            if (rule.MaxTradesPerDay.HasValue)
            {
                int todayCount = GetDailyCopierOpens(rule.Id, accountName);
                if (todayCount > rule.MaxTradesPerDay.Value)
                {
                    string debounceKey = $"{rule.Id}:{accountName}:max_trades";
                    if (ShouldFire(debounceKey))
                    {
                        _log($"RISK ALERT — max_trades_per_day exceeded on '{accountName}': " +
                             $"{todayCount} copier opens today, limit is {rule.MaxTradesPerDay.Value}. " +
                             "Further copier opens are blocked for this account today.");

                        await _client.PostEventAsync(new AutomationEvent
                        {
                            EventType          = "risk_alert",
                            Severity           = "warning",
                            BrokerConnectionId = conn.Id,
                            Symbol             = null,
                            Payload            = new
                            {
                                rule_id     = rule.Id,
                                rule_label  = rule.Label,
                                check       = "max_trades_per_day",
                                today_opens = todayCount,
                                max_allowed = rule.MaxTradesPerDay.Value,
                                action      = "copier_opens_blocked"
                            }
                        }, ct).ConfigureAwait(false);
                    }
                }
            }

            // ---- (e) Tilt cooldown enforcement ------------------------------
            // Tilt state is updated by RecordFillResult (called by CopierEngine).
            // Here we just post a heartbeat-level check to ensure the cooldown
            // event is logged when it starts. The CopierEngine calls IsInTiltCooldown.
            if (rule.TiltLossStreak.HasValue && rule.TiltCooldownMinutes.HasValue)
            {
                string tiltKey = $"{rule.Id}:{accountName}";
                if (_tiltUntil.TryGetValue(tiltKey, out DateTime cooldownEnd))
                {
                    if (DateTime.UtcNow < cooldownEnd)
                    {
                        // Still in cooldown — no additional alert needed here;
                        // CopierEngine blocks opens and event was already posted
                        // when the tilt was triggered.
                    }
                    else
                    {
                        // Cooldown expired — remove the tilt marker
                        _tiltUntil.TryRemove(tiltKey, out _);
                        _lossStreaks.TryUpdate(tiltKey, 0, _lossStreaks.GetOrAdd(tiltKey, 0));
                        _log($"Tilt cooldown expired for rule '{rule.Label}' on '{accountName}'.");
                    }
                }
            }
        }

        // -----------------------------------------------------------------------
        // CopierEngine integration — pre-trade check
        // -----------------------------------------------------------------------

        /// <summary>
        /// Called by CopierEngine BEFORE placing a mirrored order.
        /// Returns false (block) if any enforced risk rule would be violated.
        /// Returns true (allow) if all checks pass.
        /// </summary>
        public bool IsOrderAllowed(
            string accountName,
            string instrumentName,
            int    quantity,
            List<RiskRule> rules,
            List<BrokerConnection> connections)
        {
            if (rules == null) return true;

            foreach (var rule in rules)
            {
                if (!rule.Enforce || !rule.IsActive) continue;

                BrokerConnection conn = connections?.Find(c => c.Id == rule.BrokerConnectionId);
                if (conn == null) continue;

                string mappedName = _platform.ResolveAccountName(conn);
                if (mappedName == null || !string.Equals(mappedName, accountName,
                        StringComparison.OrdinalIgnoreCase)) continue;

                // Check max_trades_per_day
                if (rule.MaxTradesPerDay.HasValue)
                {
                    int todayCount = GetDailyCopierOpens(rule.Id, accountName);
                    if (todayCount >= rule.MaxTradesPerDay.Value)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"max_trades_per_day ({rule.MaxTradesPerDay.Value}) reached.");
                        return false;
                    }
                }

                // Check tilt cooldown
                if (rule.TiltLossStreak.HasValue)
                {
                    if (IsInTiltCooldown(rule.Id, accountName))
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             "tilt cooldown is active.");
                        return false;
                    }
                }

                // Check max_contracts (would adding `quantity` breach the limit?)
                if (rule.MaxContracts.HasValue)
                {
                    int currentContracts = _platform.GetOpenContracts(accountName, instrumentName);
                    if (currentContracts + quantity > rule.MaxContracts.Value)
                    {
                        // Clamp rather than block: the copier engine should reduce qty, not skip.
                        // Return false here so the engine can recalculate and re-check.
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}/{instrumentName}' — " +
                             $"max_contracts would be exceeded ({currentContracts}+{quantity} > " +
                             $"{rule.MaxContracts.Value}).");
                        return false;
                    }
                }

                // Check daily_loss (should not be opening new positions if already blown)
                if (rule.DailyLossLimitUsd.HasValue)
                {
                    double totalPnl   = _platform.GetSessionRealizedPnL(accountName)
                                      + _platform.GetOpenPnL(accountName);
                    double threshold  = -Math.Abs(rule.DailyLossLimitUsd.Value);
                    if (totalPnl <= threshold)
                    {
                        _log($"IsOrderAllowed: BLOCKED on '{accountName}' — " +
                             $"daily loss limit already breached (PnL={totalPnl:C2}).");
                        return false;
                    }
                }
            }

            return true; // all checks passed
        }

        // -----------------------------------------------------------------------
        // Tilt tracking (called by CopierEngine when a copier fill result is known)
        // -----------------------------------------------------------------------

        /// <summary>
        /// Records a copier fill outcome for tilt tracking purposes.
        /// Call this after every copier-originated order that results in a close.
        /// </summary>
        /// <param name="ruleId">The risk rule ID governing this account.</param>
        /// <param name="accountName">The target account name.</param>
        /// <param name="wasLoss">true if the closed trade was a loss.</param>
        /// <param name="rule">The full rule, to read tilt parameters.</param>
        public async Task RecordFillResultAsync(
            string ruleId,
            string accountName,
            bool wasLoss,
            RiskRule rule,
            BrokerConnection conn,
            CancellationToken ct = default)
        {
            if (!rule.TiltLossStreak.HasValue || !rule.TiltCooldownMinutes.HasValue) return;

            string tiltKey = $"{ruleId}:{accountName}";

            if (wasLoss)
            {
                int streak = _lossStreaks.AddOrUpdate(tiltKey, 1, (k, v) => v + 1);
                _log($"Tilt tracker: '{accountName}' loss streak = {streak}.");

                if (streak >= rule.TiltLossStreak.Value && !IsInTiltCooldown(ruleId, accountName))
                {
                    DateTime cooldownEnd = DateTime.UtcNow.AddMinutes(rule.TiltCooldownMinutes.Value);
                    _tiltUntil[tiltKey] = cooldownEnd;

                    _log($"TILT TRIGGERED on '{accountName}': {streak} consecutive losses. " +
                         $"Copier blocked until {cooldownEnd:u}.");

                    await _client.PostEventAsync(new AutomationEvent
                    {
                        EventType          = "risk_alert",
                        Severity           = "warning",
                        BrokerConnectionId = conn?.Id,
                        Payload            = new
                        {
                            rule_id           = ruleId,
                            rule_label        = rule.Label,
                            check             = "tilt",
                            loss_streak       = streak,
                            cooldown_minutes  = rule.TiltCooldownMinutes.Value,
                            cooldown_ends_utc = cooldownEnd.ToString("o"),
                            action            = "copier_opens_blocked_tilt"
                        }
                    }, ct).ConfigureAwait(false);
                }
            }
            else
            {
                // Winning trade resets the streak
                _lossStreaks.TryUpdate(tiltKey, 0, _lossStreaks.GetOrAdd(tiltKey, 0));
            }
        }

        // -----------------------------------------------------------------------
        // Daily copier open counter (called by CopierEngine)
        // -----------------------------------------------------------------------

        public void IncrementCopierOpens(string ruleId, string accountName)
        {
            string key = $"{ruleId}:{accountName}:{DateTime.UtcNow:yyyy-MM-dd}";
            _dailyCopierOpens.AddOrUpdate(key, 1, (k, v) => v + 1);
        }

        private int GetDailyCopierOpens(string ruleId, string accountName)
        {
            string key = $"{ruleId}:{accountName}:{DateTime.UtcNow:yyyy-MM-dd}";
            _dailyCopierOpens.TryGetValue(key, out int count);
            return count;
        }

        // -----------------------------------------------------------------------
        // Public query helpers (used by CopierEngine)
        // -----------------------------------------------------------------------

        public bool IsInTiltCooldown(string ruleId, string accountName)
        {
            string tiltKey = $"{ruleId}:{accountName}";
            if (!_tiltUntil.TryGetValue(tiltKey, out DateTime until)) return false;
            return DateTime.UtcNow < until;
        }

        // -----------------------------------------------------------------------
        // Debounce helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns true if enough time has passed since the last fire for this key.
        /// Side-effect: records the current time as the fire time.
        /// </summary>
        private bool ShouldFire(string key)
        {
            DateTime now = DateTime.UtcNow;
            if (_firedAt.TryGetValue(key, out DateTime last))
            {
                if (now - last < DebounceInterval)
                    return false;
            }
            _firedAt[key] = now;
            return true;
        }

        private void ClearDebounce(string key)
        {
            _firedAt.TryRemove(key, out _);
        }

        // -----------------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------------

        private static BrokerConnection FindConnection(AutomationConfig config, string connectionId)
        {
            if (config?.Connections == null || connectionId == null) return null;
            return config.Connections.Find(c => c.Id == connectionId);
        }
    }
}
