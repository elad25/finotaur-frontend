// =============================================================================
// Finotaur Agent — FinotaurAgent.cs
//
// NinjaTrader 8 AddOn entry point.
// Derives from NinjaTrader.NinjaScript.AddOns.AddOnBase.
//
// ═══════════════════════════════════════════════════════════════════════════
// COMPLIANCE BOUNDARY (DO NOT REMOVE THIS COMMENT)
// ═══════════════════════════════════════════════════════════════════════════
//   • This AddOn places orders ONLY via the NinjaTrader 8 Cbi APIs
//     (NinjaTraderAdapter → IPlatformAdapter). It NEVER calls Tradovate,
//     NinjaTrader Cloud, or any broker REST/WS API.
//   • All trade copying is user-to-self only (same user's accounts).
//   • The agent ALWAYS heartbeats, even when master_enabled=false or
//     kill_switch is engaged. This lets the web see the agent is alive
//     while respecting the hard stop.
//   • FAIL-SAFE: on ANY network failure or config parse error, the
//     background loop logs and no-ops. It NEVER crashes NT8.
// ═══════════════════════════════════════════════════════════════════════════
//
// ARCHITECTURE:
//
//   NT8 UI thread
//     └─ AddOnBase.OnStateChange (SetDefaults / Active / Terminated)
//          └─ Creates background Task (_loopTask)
//
//   Background loop Task (dedicated, NOT the NT UI thread)
//     ├─ Every ~10–15 s: GetConfigAsync (with version), HeartbeatAsync
//     ├─ On full config (Unchanged==false): rebuild RiskEnforcer + CopierEngine
//     ├─ On unchanged config: apply master/kill flags only
//     ├─ Every ~5 s: RiskEnforcer.RunAsync (checks platform PnL/positions)
//     └─ Every ~5 s: FlushEventQueueAsync (drain telemetry → server in batches)
//
//   NT fill event thread (via NinjaTraderAdapter)
//     └─ Fires CopierEngine fill callback → enqueues CopyJob (hot path, no network)
//
//   CopierEngine consumer Task
//     └─ Dequeues CopyJob → fans out PlaceMarketOrder concurrently to all targets
//        → enqueues ONE aggregated AutomationEvent to _eventQueue
//
// THREADING SUMMARY:
//   _cachedConfig  — volatile reference; written by loop, read by hot path
//   _masterEnabled / _killEngaged — volatile bools for hot-path gate
//   _eventQueue    — ConcurrentQueue (lock-free; written by copier, drained by loop)
//   All other engine state — ConcurrentDictionary (thread-safe)
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Copier;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Pairing;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Risk;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Storage;

// VERIFY (NT8 API): AddOnBase lives in NinjaTrader.NinjaScript.AddOns namespace.
// In NT8 it is typically in NinjaTrader.Core.dll or NinjaTrader.NinjaScript.dll.
// Confirm the exact assembly in the NT8 AddOn developer docs.

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Main Finotaur Agent AddOn.
    ///
    /// VERIFY (NT8 API): The attribute and base-class requirements for NT8 AddOns.
    /// In NT8, an AddOn typically:
    ///   - Derives from AddOnBase (in NinjaTrader.NinjaScript.AddOns)
    ///   - Is decorated with [AddOn] attribute or auto-discovered by file path
    ///   - Overrides OnStateChange(NinjaScriptState state)
    ///   - Adds Control Center menu items via the protected MenuItems property or
    ///     a OnMenuItemsChanged override
    /// Check the NT8 AddOn sample project for exact requirements.
    /// </summary>
    public class FinotaurAgent : AddOnBase
    {
        // -----------------------------------------------------------------------
        // Constants
        // -----------------------------------------------------------------------

        private const string AgentVersion    = "1.0.0";
        private const string MenuItemLabel   = "Finotaur Agent…"; // "Finotaur Agent…"

        /// <summary>
        /// Normal poll interval. The background loop sleeps this long between cycles
        /// when everything is healthy.
        /// </summary>
        private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(12);

        /// <summary>
        /// Risk enforcer check sub-interval within the poll cycle.
        /// Risk is checked every cycle; the enforcer debounces internally.
        /// </summary>
        private static readonly TimeSpan RiskCheckInterval = TimeSpan.FromSeconds(5);

        /// <summary>
        /// Maximum events to flush per batch. Prevents oversized HTTP payloads.
        /// </summary>
        private const int EventFlushBatchSize = 20;

        // -----------------------------------------------------------------------
        // Components (created in OnStateChange Active, disposed in Terminated)
        // -----------------------------------------------------------------------

        private FinotaurClient   _client;
        private IPlatformAdapter _platform;
        private RiskEnforcer     _risk;
        private CopierEngine     _copier;

        // Shared event queue: copier enqueues, background loop flushes.
        // ConcurrentQueue is lock-free — safe from NT fill thread + loop task.
        private readonly ConcurrentQueue<AutomationEvent> _eventQueue =
            new ConcurrentQueue<AutomationEvent>();

        // -----------------------------------------------------------------------
        // Background loop
        // -----------------------------------------------------------------------

        private CancellationTokenSource _loopCts;
        private Task                    _loopTask;

        // -----------------------------------------------------------------------
        // Locally-cached config — hot-path reads this; only the loop writes it
        // -----------------------------------------------------------------------

        /// <summary>
        /// The most recent full config received from the server.
        /// Volatile: written by the background loop, read by the NT fill callback
        /// (hot path). Reads/writes of reference types are atomic on 64-bit CLR.
        /// </summary>
        private volatile AutomationConfig _cachedConfig;

        /// <summary>
        /// Last config version we sent to the server, so it can return a cheap
        /// "unchanged" response if nothing changed. The loop maintains this.
        /// </summary>
        private string _lastConfigVersion;

        /// <summary>
        /// Cached master_enabled flag — updated on EVERY config response (including
        /// Shape-A "unchanged") so the hot path can gate without reading the full config.
        /// </summary>
        private volatile bool _masterEnabled;

        /// <summary>
        /// Cached kill_switch_engaged — same rationale as _masterEnabled.
        /// </summary>
        private volatile bool _killEngaged;

        // -----------------------------------------------------------------------
        // Observability (displayed in PairingWindow)
        // -----------------------------------------------------------------------

        private DateTime? _lastConfigAt;
        private bool      _lastHeartbeatOk;
        private DateTime? _lastHeartbeatAt;
        private string    _deviceName;

        // -----------------------------------------------------------------------
        // Pairing window (singleton, opened from menu item)
        // -----------------------------------------------------------------------

        private PairingWindow _pairingWindow;
        private readonly object _pairingWindowLock = new object();

        // -----------------------------------------------------------------------
        // OnStateChange — NT8 AddOn lifecycle
        // -----------------------------------------------------------------------

        /// <summary>
        /// NT8 AddOn lifecycle callback. Called by NT8 on load, activate, and unload.
        ///
        /// VERIFY (NT8 API): AddOnBase.OnStateChange(NinjaScriptState state) signature.
        /// In NT8 the parameter type is NinjaScriptState (an enum).
        /// SetDefaults: called when the AddOn is first loaded.
        /// Active: called when NT8 starts and the AddOn is enabled.
        /// Terminated: called when NT8 shuts down or the AddOn is disabled.
        /// </summary>
        protected override void OnStateChange()
        {
            // VERIFY (NT8 API): In NT8, the state is accessed via State property.
            // The pattern is: if (State == State.SetDefaults) { ... }
            //                 else if (State == State.Active) { ... }
            //                 else if (State == State.Terminated) { ... }
            // Adjust the switch below to match the NT8 State enum name if different.

            switch (State)   // VERIFY (NT8 API): 'State' property on AddOnBase
            {
                case State.SetDefaults:
                    // VERIFY (NT8 API): Name and Description are AddOnBase properties.
                    // In some NT8 versions they may be called differently (e.g. DisplayName).
                    Name        = "Finotaur Agent";
                    Description = "Finotaur local risk enforcement and trade copier agent.";
                    break;

                case State.Active:
                    OnAgentActivated();
                    break;

                case State.Terminated:
                    OnAgentTerminated();
                    break;
            }
        }

        // -----------------------------------------------------------------------
        // AddOn menu item — adds "Finotaur Agent…" to NT8 Tools menu
        // -----------------------------------------------------------------------

        /// <summary>
        /// VERIFY (NT8 API): NT8 AddOns add Control Center menu items by overriding
        /// this method and returning NTMenuItem objects. Confirm the exact override
        /// name and NTMenuItem type. This is a common pattern; the exact API
        /// varies between NT8 versions.
        ///
        /// Alternative: in some NT8 versions, menu items are wired in OnStateChange
        /// Active by adding to a NinjaTrader.Gui.NTMenuItem collection.
        /// </summary>
        protected override System.Windows.Controls.MenuItem GetMenuItem()
        {
            // VERIFY (NT8 API): AddOnBase may provide GetMenuItem() or a similar
            // hook. If not, add the menu item via:
            //   NinjaTrader.Gui.Tools.NTWindow.AddMenuItem(header, onClick)
            // or the NTMenuItem API from the NT8 AddOn developer documentation.

            var menuItem = new System.Windows.Controls.MenuItem
            {
                Header = MenuItemLabel
            };
            menuItem.Click += (s, e) => OpenPairingWindow();
            return menuItem;
        }

        // -----------------------------------------------------------------------
        // Activation
        // -----------------------------------------------------------------------

        private void OnAgentActivated()
        {
            try
            {
                _deviceName = System.Environment.MachineName;

                Log("Finotaur Agent activating…");

                // -- HTTP client --
                _client = new FinotaurClient();

                // -- Load stored credentials --
                if (TokenStore.Load(out string token, out _, out string storedDevice))
                {
                    _client.SetDeviceToken(token);
                    if (!string.IsNullOrWhiteSpace(storedDevice))
                        _deviceName = storedDevice;
                    Log($"Loaded credentials for device '{_deviceName}'.");
                }
                else
                {
                    Log("No stored credentials found. Open 'Finotaur Agent…' from Tools to pair.");
                }

                // -- Platform adapter --
                _platform = new NinjaTraderAdapter(logger: Log);

                // -- Risk enforcer --
                _risk = new RiskEnforcer(_platform, _client, logger: Log);

                // -- Copier engine (needs event queue) --
                _copier = new CopierEngine(_platform, _risk, _eventQueue, logger: Log);

                // -- Start background loop --
                _loopCts  = new CancellationTokenSource();
                _loopTask = Task.Run(() => BackgroundLoopAsync(_loopCts.Token));

                Log($"Finotaur Agent v{AgentVersion} active. Device: '{_deviceName}'.");
            }
            catch (Exception ex)
            {
                Log($"OnAgentActivated FATAL: {ex.GetType().Name} — {ex.Message}");
                // Do NOT re-throw — AddOn must not crash NT8 on activation.
            }
        }

        // -----------------------------------------------------------------------
        // Termination
        // -----------------------------------------------------------------------

        private void OnAgentTerminated()
        {
            try
            {
                Log("Finotaur Agent terminating…");

                // Signal loop to stop
                _loopCts?.Cancel();
                try { _loopTask?.Wait(TimeSpan.FromSeconds(5)); }
                catch { /* best-effort wait */ }

                // Close pairing window if open
                lock (_pairingWindowLock)
                {
                    try { _pairingWindow?.Close(); }
                    catch { }
                    _pairingWindow = null;
                }

                // Dispose components in reverse creation order
                _copier?.Dispose();
                _platform?.Dispose();
                _client?.Dispose();

                _copier   = null;
                _platform = null;
                _client   = null;
                _risk     = null;

                Log("Finotaur Agent terminated.");
            }
            catch (Exception ex)
            {
                Log($"OnAgentTerminated error: {ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Background loop — the heart of the agent
        // -----------------------------------------------------------------------

        /// <summary>
        /// Runs on a dedicated Task (NOT the NT UI thread).
        /// Owns the periodic config pull, heartbeat, risk checks, and event flush.
        ///
        /// Design principles:
        ///   - Every network call is wrapped in try/catch. A failure is a no-op.
        ///   - The loop NEVER crashes or exits due to an exception — it catches
        ///     and retries on the next cycle. NT8 must remain stable.
        ///   - master_enabled and kill_switch_engaged are applied as hard stops
        ///     EVERY cycle, including from cheap "unchanged" responses.
        /// </summary>
        private async Task BackgroundLoopAsync(CancellationToken ct)
        {
            Log("Background loop started.");

            // Stagger the first config pull by 2 s to let NT8 finish initializing.
            await Task.Delay(TimeSpan.FromSeconds(2), ct).ConfigureAwait(false);

            DateTime lastRiskCheck  = DateTime.MinValue;
            DateTime lastEventFlush = DateTime.MinValue;

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    DateTime now = DateTime.UtcNow;

                    // ============================================================
                    // 1. CONFIG PULL (with version — cheap "unchanged" path)
                    // ============================================================

                    if (_client.IsPaired)
                    {
                        AutomationConfig configResponse = null;
                        try
                        {
                            configResponse = await _client
                                .GetConfigAsync(_lastConfigVersion, ct)
                                .ConfigureAwait(false);
                        }
                        catch (Exception ex)
                        {
                            // Network error — apply fail-safe: do nothing this cycle.
                            Log($"Config pull error: {ex.GetType().Name} — {ex.Message}. " +
                                "Will retry next cycle. Previous config remains active.");
                        }

                        if (configResponse != null)
                        {
                            // Always update the version token and safety flags,
                            // regardless of Unchanged shape.
                            if (!string.IsNullOrEmpty(configResponse.ConfigVersion))
                                _lastConfigVersion = configResponse.ConfigVersion;

                            // Apply master/kill flags from EVERY response (including Shape A).
                            // This is the safety guarantee: even if nothing else changed, the
                            // server can toggle the kill switch and the agent will see it.
                            _masterEnabled = configResponse.MasterEnabled;
                            _killEngaged   = configResponse.KillSwitchEngaged;

                            if (!configResponse.Unchanged)
                            {
                                // Shape B: full config — rebuild local state.
                                _cachedConfig = configResponse;
                                _lastConfigAt = DateTime.UtcNow;

                                // Rebuild copier subscriptions with the new config.
                                // CopierEngine.ApplyConfig is thread-safe.
                                try
                                {
                                    _copier?.ApplyConfig(configResponse);
                                }
                                catch (Exception ex)
                                {
                                    Log($"CopierEngine.ApplyConfig error: {ex.GetType().Name} — {ex.Message}");
                                }

                                int ruleCount  = configResponse.RiskRules?.Count(r => r.IsActive && r.Enforce) ?? 0;
                                int routeCount = configResponse.CopierRoutes?.Count(r => r.IsActive) ?? 0;

                                // Report how many journal accounts from the server config
                                // are matched to local NT accounts.  This helps diagnose
                                // "why isn't my route working?" without opening NT8 internals.
                                int accountsTotal   = configResponse.Accounts?.Count(a => a.IsActive) ?? 0;
                                int accountsMatched = 0;
                                if (accountsTotal > 0 && _platform != null)
                                {
                                    foreach (var acct in configResponse.Accounts)
                                    {
                                        if (!acct.IsActive) continue;
                                        if (!string.IsNullOrWhiteSpace(acct.AccountName)
                                            && _platform.ResolveAccountByName(acct.AccountName) != null)
                                        {
                                            accountsMatched++;
                                        }
                                    }
                                }

                                Log($"Config updated (v={_lastConfigVersion}): " +
                                    $"{ruleCount} enforced risk rules, {routeCount} active copier routes, " +
                                    $"{accountsMatched}/{accountsTotal} journal accounts matched locally. " +
                                    $"Master={_masterEnabled}, Kill={_killEngaged}.");
                            }
                            else
                            {
                                // Shape A: unchanged — master/kill applied above, no rebuild needed.
                                Log($"Config unchanged (v={_lastConfigVersion}). " +
                                    $"Master={_masterEnabled}, Kill={_killEngaged}.");
                            }

                            // Post kill_switch event if just engaged
                            if (_killEngaged)
                            {
                                _eventQueue.Enqueue(new AutomationEvent
                                {
                                    EventType = "kill_switch",
                                    Severity  = "critical",
                                    Payload   = new
                                    {
                                        message       = "Kill switch engaged from web dashboard. " +
                                                        "All risk enforcement and copying stopped.",
                                        config_version = _lastConfigVersion
                                    }
                                });
                            }
                        }
                    }

                    // ============================================================
                    // 2. HEARTBEAT (every cycle, regardless of master/kill state)
                    //    The web must always see the agent is alive, even when stopped.
                    // ============================================================

                    if (_client.IsPaired)
                    {
                        string heartbeatStatus = _killEngaged ? "kill_switch"
                                               : !_masterEnabled ? "disabled"
                                               : "online";
                        try
                        {
                            bool hbOk = await _client
                                .HeartbeatAsync(heartbeatStatus, AgentVersion, ct)
                                .ConfigureAwait(false);

                            _lastHeartbeatOk = hbOk;
                            _lastHeartbeatAt = DateTime.UtcNow;
                        }
                        catch (Exception ex)
                        {
                            _lastHeartbeatOk = false;
                            _lastHeartbeatAt = DateTime.UtcNow;
                            Log($"Heartbeat error: {ex.GetType().Name} — {ex.Message}");
                        }
                    }

                    // ============================================================
                    // 3. RISK ENFORCEMENT
                    //    Only runs when master is enabled and kill is NOT engaged.
                    //    Sub-interval: checked every RiskCheckInterval (5 s).
                    // ============================================================

                    if (_masterEnabled && !_killEngaged && _cachedConfig != null)
                    {
                        if (DateTime.UtcNow - lastRiskCheck >= RiskCheckInterval)
                        {
                            lastRiskCheck = DateTime.UtcNow;
                            try
                            {
                                await _risk.RunAsync(_cachedConfig, ct).ConfigureAwait(false);
                            }
                            catch (Exception ex)
                            {
                                Log($"RiskEnforcer.RunAsync error: {ex.GetType().Name} — {ex.Message}");
                            }
                        }
                    }

                    // ============================================================
                    // 4. EVENT QUEUE FLUSH (async batched telemetry)
                    //    Drain the _eventQueue and post to server in batches.
                    //    The copy hot path never waits for this.
                    // ============================================================

                    if (_client.IsPaired && !_eventQueue.IsEmpty)
                    {
                        if (DateTime.UtcNow - lastEventFlush >= TimeSpan.FromSeconds(3))
                        {
                            lastEventFlush = DateTime.UtcNow;
                            await FlushEventQueueAsync(ct).ConfigureAwait(false);
                        }
                    }

                    // ============================================================
                    // 5. UPDATE PAIRING WINDOW STATUS (if open)
                    // ============================================================

                    PairingWindow window;
                    lock (_pairingWindowLock)
                        window = _pairingWindow;

                    if (window != null)
                    {
                        var snapshot = BuildStatusSnapshot();
                        try { window.UpdateStatus(snapshot); }
                        catch { /* window may be closing — ignore */ }
                    }

                    // ============================================================
                    // 6. WAIT FOR NEXT POLL CYCLE
                    // ============================================================

                    await Task.Delay(PollInterval, ct).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    // Normal shutdown — break the loop
                    break;
                }
                catch (Exception ex)
                {
                    // Unexpected error — log and continue. The loop MUST NOT exit.
                    Log($"BackgroundLoop unhandled error: {ex.GetType().Name} — {ex.Message}. " +
                        "Continuing on next cycle.");

                    // Brief pause before retry to avoid tight error loops
                    try { await Task.Delay(TimeSpan.FromSeconds(5), ct).ConfigureAwait(false); }
                    catch { break; }
                }
            }

            Log("Background loop exited.");
        }

        // -----------------------------------------------------------------------
        // Event queue flush — async batched telemetry
        // -----------------------------------------------------------------------

        /// <summary>
        /// Drains up to EventFlushBatchSize events from the queue and posts them
        /// to the server one by one (or in future: as a batch endpoint if added).
        ///
        /// This runs off the NT thread and never blocks the copy hot path.
        /// Failures are swallowed — unsent events are lost (telemetry is
        /// best-effort; it must never impact order execution).
        /// </summary>
        private async Task FlushEventQueueAsync(CancellationToken ct)
        {
            int flushed = 0;

            // Drain up to BatchSize events per flush cycle
            while (flushed < EventFlushBatchSize && _eventQueue.TryDequeue(out AutomationEvent evt))
            {
                try
                {
                    await _client.PostEventAsync(evt, ct).ConfigureAwait(false);
                    flushed++;
                }
                catch (Exception ex)
                {
                    // Swallow — telemetry is best-effort. The event is lost.
                    Log($"FlushEventQueue: failed to post '{evt.EventType}': {ex.Message}");
                    // Do NOT re-enqueue — could cause infinite retry loop.
                }
            }

            if (flushed > 0)
                Log($"Flushed {flushed} event(s) to server.");
        }

        // -----------------------------------------------------------------------
        // Pairing window management
        // -----------------------------------------------------------------------

        /// <summary>
        /// Opens or activates the PairingWindow.
        /// Called from the Control Center menu item on the UI thread.
        /// </summary>
        private void OpenPairingWindow()
        {
            // VERIFY (NT8 API): Menu item Click is invoked on the NT UI thread.
            // If it is not, marshal to the WPF Dispatcher before accessing _pairingWindow.

            lock (_pairingWindowLock)
            {
                if (_pairingWindow != null && _pairingWindow.IsVisible)
                {
                    // Bring existing window to front
                    try
                    {
                        _pairingWindow.Activate();
                        _pairingWindow.Focus();
                    }
                    catch { /* best-effort */ }
                    return;
                }

                // Create a new window
                try
                {
                    _pairingWindow = new PairingWindow(
                        client:       _client,
                        copier:       _copier,
                        deviceName:   _deviceName,
                        agentVersion: AgentVersion,
                        logger:       Log);

                    // Clean up reference when window is closed
                    _pairingWindow.Closed += (s, e) =>
                    {
                        lock (_pairingWindowLock)
                            _pairingWindow = null;
                    };

                    _pairingWindow.Show();
                }
                catch (Exception ex)
                {
                    Log($"OpenPairingWindow error: {ex.GetType().Name} — {ex.Message}");
                    _pairingWindow = null;
                }
            }
        }

        // -----------------------------------------------------------------------
        // Status snapshot (feeds PairingWindow)
        // -----------------------------------------------------------------------

        private AgentStatusSnapshot BuildStatusSnapshot()
        {
            AutomationConfig cfg = _cachedConfig;

            int activeRules  = cfg?.RiskRules?.Count(r => r.IsActive && r.Enforce) ?? 0;
            int activeRoutes = cfg?.CopierRoutes?.Count(r => r.IsActive) ?? 0;

            // Count how many journal accounts from the server config are matched
            // to local NT accounts (same logic as the config-update log message).
            int accountsTotal   = cfg?.Accounts?.Count(a => a.IsActive) ?? 0;
            int accountsMatched = 0;
            if (accountsTotal > 0 && _platform != null && cfg?.Accounts != null)
            {
                foreach (var acct in cfg.Accounts)
                {
                    if (!acct.IsActive) continue;
                    if (!string.IsNullOrWhiteSpace(acct.AccountName)
                        && _platform.ResolveAccountByName(acct.AccountName) != null)
                    {
                        accountsMatched++;
                    }
                }
            }

            string activity = _copier?.GetActivitySummary() ?? "Copier not initialized.";

            // Bottom status line
            string status;
            if (!_client.IsPaired)
                status = "Not paired — open 'Finotaur Agent…' to pair.";
            else if (_killEngaged)
                status = "KILL SWITCH ENGAGED — all operations stopped.";
            else if (!_masterEnabled)
                status = "Master disabled — agent idle (still heartbeating).";
            else
                status = $"Active — master ON, {activeRules} rules, {activeRoutes} routes, " +
                         $"{accountsMatched}/{accountsTotal} accounts matched.";

            return new AgentStatusSnapshot
            {
                DeviceName        = _deviceName,
                LastConfigAt      = _lastConfigAt,
                ConfigVersion     = _lastConfigVersion,
                MasterEnabled     = _masterEnabled,
                KillSwitchEngaged = _killEngaged,
                ActiveRuleCount   = activeRules,
                ActiveRouteCount  = activeRoutes,
                LastHeartbeatOk   = _lastHeartbeatOk,
                LastHeartbeatAt   = _lastHeartbeatAt,
                ActivitySummary   = activity,
                BottomStatusLine  = status
            };
        }

        // -----------------------------------------------------------------------
        // Logging
        // -----------------------------------------------------------------------

        /// <summary>
        /// Central log method. All components are wired to this delegate.
        ///
        /// VERIFY (NT8 API): In AddOn context, writing to the NT8 output window
        /// is done via NinjaTrader.Code.Output.Process(message, PrintTo.OutputTab1)
        /// from a strategy, or possibly Code.Output.Process from AddOnBase.
        /// Confirm the correct API and add it here.
        /// Currently using Debug.WriteLine as a guaranteed fallback that works
        /// in all contexts.
        /// </summary>
        private static void Log(string message)
        {
            try
            {
                string line = $"[FinotaurAgent] {message}";

                System.Diagnostics.Debug.WriteLine(line);

                // VERIFY (NT8 API): Uncomment the correct output method:
                // Option A (from AddOnBase, NT8 8.1+):
                //   NinjaTrader.Code.Output.Process(line, PrintTo.OutputTab1);
                // Option B (via static reference if available in AddOn context):
                //   NinjaTrader.NinjaScript.NinjaScript.Log(line, NinjaTrader.Cbi.LogLevel.Information);
                // Check the NT8 developer documentation for AddOn logging patterns.
            }
            catch { /* logging must never throw */ }
        }
    }
}
