// =============================================================================
// Finotaur Agent — Storage/TokenStore.cs
//
// Persists the device_token and device_id as plain UTF-8 JSON in the user's
// NinjaTrader data directory. The device token is a local bearer token issued
// by the Finotaur server; storing it unencrypted in the NT8 user data folder
// (a local, user-owned directory) is acceptable for this desktop addon.
//
// The store file lives at:
//   %USERPROFILE%\Documents\NinjaTrader 8\Finotaur\agent.dat
//
// NinjaTrader.Core.Globals.UserDataDir is a string containing the per-user
// NT8 data directory (e.g. Documents\NinjaTrader 8\). Available in both
// strategy and AddOn contexts. A try/catch fallback to MyDocuments is kept
// for resilience.
// =============================================================================

using System;
using System.IO;
using System.Text;
using Newtonsoft.Json;               // VERIFY: bundled with NT8

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Storage
{
    /// <summary>
    /// Encrypted local store for the agent's device credentials.
    /// Never write the device token to log files or UI text fields.
    /// </summary>
    public static class TokenStore
    {
        // -----------------------------------------------------------------------
        // File location
        // -----------------------------------------------------------------------

        private const string SubFolder  = "Finotaur";
        private const string FileName   = "agent.dat";

        /// <summary>
        /// Full path to the encrypted credentials file.
        /// Uses NinjaTrader.Core.Globals.UserDataDir (the per-user NT8 data folder,
        /// e.g. Documents\NinjaTrader 8\) with a Documents fallback for resilience.
        /// </summary>
        public static string StoreFilePath
        {
            get
            {
                string ntDataDir;
                try
                {
                    // NinjaTrader.Core.Globals.UserDataDir is a string (confirmed NT8 API).
                    ntDataDir = NinjaTrader.Core.Globals.UserDataDir;
                }
                catch
                {
                    // Fallback: standard Documents folder
                    ntDataDir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "NinjaTrader 8");
                }

                return Path.Combine(ntDataDir, SubFolder, FileName);
            }
        }

        // -----------------------------------------------------------------------
        // Data shape persisted to disk
        // -----------------------------------------------------------------------

        private class StoredCredentials
        {
            [JsonProperty("device_token")]
            public string DeviceToken { get; set; }

            [JsonProperty("device_id")]
            public string DeviceId { get; set; }

            [JsonProperty("device_name")]
            public string DeviceName { get; set; }

            [JsonProperty("paired_at")]
            public string PairedAt { get; set; }
        }

        // -----------------------------------------------------------------------
        // Save
        // -----------------------------------------------------------------------

        /// <summary>
        /// Saves the device credentials as plain UTF-8 JSON.
        /// Creates the directory if it does not exist.
        /// </summary>
        /// <param name="deviceToken">Opaque bearer token — NEVER log this value.</param>
        /// <param name="deviceId">Server-assigned device identifier (non-sensitive).</param>
        /// <param name="deviceName">Human-readable machine name (non-sensitive).</param>
        /// <returns>True on success, false on any error (caller should re-pair).</returns>
        public static bool Save(string deviceToken, string deviceId, string deviceName)
        {
            if (string.IsNullOrWhiteSpace(deviceToken))
            {
                Log("Save called with empty deviceToken — aborting.");
                return false;
            }

            try
            {
                var creds = new StoredCredentials
                {
                    DeviceToken = deviceToken,
                    DeviceId    = deviceId,
                    DeviceName  = deviceName,
                    PairedAt    = DateTime.UtcNow.ToString("o")
                };

                string json = JsonConvert.SerializeObject(creds);

                // Ensure directory exists
                string dir = Path.GetDirectoryName(StoreFilePath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                File.WriteAllText(StoreFilePath, json, Encoding.UTF8);
                Log($"Credentials saved to {StoreFilePath}.");
                return true;
            }
            catch (Exception ex)
            {
                Log($"Save failed: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // Load
        // -----------------------------------------------------------------------

        /// <summary>
        /// Loads stored credentials from the plain UTF-8 JSON file.
        /// </summary>
        /// <param name="deviceToken">Output: the device token. Treat as secret.</param>
        /// <param name="deviceId">Output: the device ID.</param>
        /// <param name="deviceName">Output: the device name.</param>
        /// <returns>True if credentials were loaded successfully, false otherwise.</returns>
        public static bool Load(
            out string deviceToken,
            out string deviceId,
            out string deviceName)
        {
            deviceToken = null;
            deviceId    = null;
            deviceName  = null;

            if (!File.Exists(StoreFilePath))
            {
                Log("No credentials file found — agent is not yet paired.");
                return false;
            }

            try
            {
                string json  = File.ReadAllText(StoreFilePath, Encoding.UTF8);
                var creds    = JsonConvert.DeserializeObject<StoredCredentials>(json);

                if (string.IsNullOrWhiteSpace(creds?.DeviceToken))
                {
                    Log("Credentials file exists but token is empty — need to re-pair.");
                    return false;
                }

                deviceToken = creds.DeviceToken;
                deviceId    = creds.DeviceId;
                deviceName  = creds.DeviceName;

                Log($"Credentials loaded for device '{deviceName}' (id: {deviceId}). " +
                    "Token loaded — value NOT logged.");
                return true;
            }
            catch (Exception ex)
            {
                Log($"Load failed: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // Clear
        // -----------------------------------------------------------------------

        /// <summary>
        /// Deletes the stored credentials file. Used when the user wants to unpair
        /// or re-pair this device. The device_token on the server is NOT revoked
        /// by this call — do that from the web UI.
        /// </summary>
        /// <returns>True if deleted or did not exist, false on IO error.</returns>
        public static bool Clear()
        {
            try
            {
                if (File.Exists(StoreFilePath))
                {
                    File.Delete(StoreFilePath);
                    Log("Credentials file deleted.");
                }
                else
                {
                    Log("Clear called but no credentials file existed.");
                }
                return true;
            }
            catch (Exception ex)
            {
                Log($"Clear failed: {ex.GetType().Name} — {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Returns true if a credentials file exists on disk.
        /// Does NOT validate that it can be decrypted.
        /// </summary>
        public static bool HasCredentials => File.Exists(StoreFilePath);

        private static void Log(string message)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine($"[TokenStore] {message}");
            }
            catch { /* logging must never throw */ }
        }
    }
}
