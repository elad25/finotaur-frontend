// =============================================================================
// Finotaur Agent — Platform/NinjaTraderAdapter.cs
//
// IPlatformAdapter implementation against the NinjaTrader 8 Cbi (client-broker
// interface) API. All NT8 API calls are annotated with VERIFY comments where
// the exact method signatures or availability in AddOn context is uncertain.
//
// COMPILE-TIME NOTE:
//   This file references types in NinjaTrader.Cbi and NinjaTrader.Core.
//   These assemblies are available in the NT8 NinjaScript environment.
//   If you see "type not found" errors, check that you are compiling inside
//   the NinjaTrader NinjaScript Editor (not a standalone .NET project).
//
// THREADING:
//   NT8's Account.All collection must be accessed under lock(Account.All).
//   All public methods in this adapter acquire that lock when touching Account.All.
//   Fill callbacks may arrive on NT8's internal threads — the onFill delegate
//   is invoked directly; callers must be thread-safe.
//
// ACCOUNT MATCHING:
//   The server returns BrokerConnection.account_id (a string, e.g. "12345" for
//   Tradovate). We match it to NT8 Account.Name. Tradovate's NT8 account name
//   may be "Demo 12345" or just "12345" depending on NT8 version and connection.
//   The matching strategy: try exact match first, then suffix match.
//   If ambiguous or no match: skip and post agent_status event.
// =============================================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;                   // Account, Order, Execution, Position, etc.
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;

// Account, Order, OrderAction, OrderType, OrderEntry, TimeInForce, Instrument,
// Execution, ExecutionEventArgs, AccountItem, Currency, CustomOrder are all in NinjaTrader.Cbi.

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Platform
{
    /// <summary>
    /// NT8-specific IPlatformAdapter. Uses NinjaTrader.Cbi APIs for all
    /// account queries and order submission.
    ///
    /// Every public method is fail-safe: it catches all exceptions, logs them,
    /// and returns a safe default (null / false / 0 / empty). It NEVER throws.
    /// </summary>
    public class NinjaTraderAdapter : IPlatformAdapter
    {
        // -----------------------------------------------------------------------
        // Fill subscription bookkeeping
        // -----------------------------------------------------------------------

        // Handle type for fill subscriptions. Wraps the account name + the
        // delegate so we can unhook from ExecutionUpdate.
        private class FillSubscription
        {
            public string AccountName   { get; set; }
            public Action<FillInfo> OnFill { get; set; }

            // NT8-level handler stored for -= on Unsubscribe.
            // ExecutionUpdate signature: void Handler(object sender, ExecutionEventArgs e)
            // where sender is the Account.
            public EventHandler<ExecutionEventArgs> NtHandler { get; set; }
        }

        // Thread-safe dictionary from subscription ID -> subscription
        private readonly ConcurrentDictionary<Guid, FillSubscription> _subscriptions =
            new ConcurrentDictionary<Guid, FillSubscription>();

        // Track which account objects we have hooked so we only hook once per account.
        private readonly ConcurrentDictionary<string, Account> _hookedAccounts =
            new ConcurrentDictionary<string, Account>();

        // -----------------------------------------------------------------------
        // Logger (injected to avoid circular dependencies)
        // -----------------------------------------------------------------------

        private readonly Action<string> _log;

        public NinjaTraderAdapter(Action<string> logger = null)
        {
            _log = logger ?? (msg => System.Diagnostics.Debug.WriteLine($"[NtAdapter] {msg}"));
        }

        // -----------------------------------------------------------------------
        // GetAccounts
        // -----------------------------------------------------------------------

        public IEnumerable<AgentAccount> GetAccounts()
        {
            var result = new List<AgentAccount>();
            try
            {
                // Account.All is IList<Account>; must lock before iterating.
                lock (Account.All)
                {
                    foreach (Account acct in Account.All)
                    {
                        result.Add(new AgentAccount
                        {
                            Name           = acct.Name,
                            // Account.Connection.Options.Name is the connection profile name (e.g. "Tradovate").
                            ConnectionName = acct.Connection?.Options?.Name ?? "Unknown",
                            // Simulated/demo accounts are identified by name substring.
                            IsSimulation   = acct.Name.IndexOf("Sim", StringComparison.OrdinalIgnoreCase) >= 0
                                          || acct.Name.IndexOf("Demo", StringComparison.OrdinalIgnoreCase) >= 0
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"GetAccounts error: {ex.Message}");
            }
            return result;
        }

        // -----------------------------------------------------------------------
        // ResolveAccountName
        // -----------------------------------------------------------------------

        public string ResolveAccountName(BrokerConnection connection)
        {
            if (connection == null || string.IsNullOrWhiteSpace(connection.AccountId))
                return null;

            string targetId = connection.AccountId.Trim();

            try
            {
                // Account.All must be accessed under lock(Account.All) per NT8 threading rules.
                lock (Account.All)
                {
                    // Strategy 1: exact match on Account.Name
                    Account exact = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, targetId, StringComparison.OrdinalIgnoreCase));
                    if (exact != null) return exact.Name;

                    // Strategy 2: Account.Name ends with the account_id
                    // (e.g. "Demo 12345" matched by "12345")
                    Account suffix = Account.All.FirstOrDefault(a =>
                        a.Name.EndsWith(targetId, StringComparison.OrdinalIgnoreCase));
                    if (suffix != null)
                    {
                        _log($"ResolveAccountName: matched '{targetId}' to NT account '{suffix.Name}' by suffix.");
                        return suffix.Name;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ResolveAccountName error for connection {connection.Id}: {ex.Message}");
            }

            _log($"ResolveAccountName: NO match for account_id='{targetId}'. " +
                 "Skipping this connection. Check that the Tradovate account is connected in NT8.");
            return null;
        }

        // -----------------------------------------------------------------------
        // ResolveAccountByName
        // -----------------------------------------------------------------------

        /// <summary>
        /// Resolves a broker account name string (e.g. "MFFUEVBLDR161429081",
        /// the value the FINOTAUR server returns as <c>account_name</c>) to the
        /// local NT <c>Account.Name</c> by a case-insensitive exact match.
        ///
        /// <para>
        /// This is the <b>primary</b> account-resolution path for copier routing.
        /// It is simpler than <see cref="ResolveAccountName(BrokerConnection)"/>
        /// because the server now sends the exact NT account name directly, so we
        /// do not need the numeric-ID suffix-match heuristic.
        /// </para>
        ///
        /// Returns <c>null</c> if no local account matches.  The caller MUST treat
        /// null as "this account is not connected in NT8 — skip and log."
        /// </summary>
        public string ResolveAccountByName(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
            {
                _log("ResolveAccountByName: called with null/empty accountName — returning null.");
                return null;
            }

            string target = accountName.Trim();

            try
            {
                // Account.All (IList<Account>) must be accessed under lock(Account.All).
                lock (Account.All)
                {
                    Account match = Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, target, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        // Return the canonical NT name (preserves its original casing).
                        return match.Name;
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"ResolveAccountByName error for '{target}': {ex.Message}");
                return null;
            }

            _log($"ResolveAccountByName: NO local NT account matched '{target}'. " +
                 "The account may not be connected in NT8. " +
                 "Open NinjaTrader Control Center → Accounts and verify the account name. " +
                 "Skipping this route/target.");
            return null;
        }

        // -----------------------------------------------------------------------
        // GetPositions
        // -----------------------------------------------------------------------

        public AgentPosition[] GetPositions(string accountName)
        {
            var positions = new List<AgentPosition>();
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return positions.ToArray();

                // Account.Positions is IEnumerable<Position> (NinjaTrader.Cbi).
                // Position has: MarketPosition, Quantity, Instrument, UnrealizedProfitLoss.
                lock (Account.All)
                {
                    foreach (Position pos in acct.Positions)
                    {
                        // MarketPosition.Flat means no open position — skip.
                        if (pos.MarketPosition == MarketPosition.Flat) continue;

                        double pointValue = 1.0;
                        try
                        {
                            // Instrument.MasterInstrument.PointValue gives the dollar
                            // value of one point movement per contract.
                            pointValue = pos.Instrument.MasterInstrument.PointValue;
                        }
                        catch { /* best-effort; leave pointValue = 1.0 */ }

                        // pos.AveragePrice is the average entry price.
                        double marketValue = pos.AveragePrice * pos.Quantity * pointValue;

                        positions.Add(new AgentPosition
                        {
                            InstrumentName  = pos.Instrument.FullName,
                            Quantity        = pos.Quantity,
                            IsLong          = pos.MarketPosition == MarketPosition.Long,
                            // NT8 Position has no UnrealizedProfitLoss property.
                            // Per-position unrealized PnL is not available without a
                            // market price; use 0.0 here and obtain account-level
                            // unrealized PnL via GetOpenPnL() which calls
                            // account.Get(AccountItem.UnrealizedProfitLoss, ...).
                            UnrealizedPnL   = 0.0,
                            MarketValueUsd  = marketValue
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log($"GetPositions error for '{accountName}': {ex.Message}");
            }
            return positions.ToArray();
        }

        // -----------------------------------------------------------------------
        // GetSessionRealizedPnL
        // -----------------------------------------------------------------------

        public double GetSessionRealizedPnL(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return 0.0;

                // account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar) returns
                // the session realized PnL in USD. AccountItem and Currency are in NinjaTrader.Cbi.
                double realized = acct.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
                return realized;
            }
            catch (Exception ex)
            {
                _log($"GetSessionRealizedPnL error for '{accountName}': {ex.Message}");
                return 0.0;
            }
        }

        // -----------------------------------------------------------------------
        // GetOpenPnL
        // -----------------------------------------------------------------------

        public double GetOpenPnL(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null) return 0.0;

                // account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar) returns
                // the total account-level unrealized PnL in USD. This is the confirmed NT8
                // API; Position has no UnrealizedProfitLoss property.
                return acct.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
            }
            catch (Exception ex)
            {
                _log($"GetOpenPnL error for '{accountName}': {ex.Message}");
                return 0.0;
            }
        }

        // -----------------------------------------------------------------------
        // GetOpenContracts
        // -----------------------------------------------------------------------

        public int GetOpenContracts(string accountName, string symbol = null)
        {
            try
            {
                AgentPosition[] positions = GetPositions(accountName);

                if (string.IsNullOrWhiteSpace(symbol))
                    return positions.Sum(p => p.Quantity);

                return positions
                    .Where(p => p.InstrumentName.IndexOf(symbol, StringComparison.OrdinalIgnoreCase) >= 0)
                    .Sum(p => p.Quantity);
            }
            catch (Exception ex)
            {
                _log($"GetOpenContracts error for '{accountName}': {ex.Message}");
                return 0;
            }
        }

        // -----------------------------------------------------------------------
        // FlattenAll
        // -----------------------------------------------------------------------

        public bool FlattenAll(string accountName)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"FlattenAll: account '{accountName}' not found — SKIPPING (fail-safe).");
                    return false;
                }

                _log($"FlattenAll: Issuing flatten on account '{accountName}'.");

                // account.Flatten(ICollection<Instrument>) — passing an empty array
                // flattens all open positions on the account.
                acct.Flatten(new Instrument[0]);

                return true;
            }
            catch (Exception ex)
            {
                _log($"FlattenAll error for '{accountName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // FlattenSymbol
        // -----------------------------------------------------------------------

        public bool FlattenSymbol(string accountName, string symbol)
        {
            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null || string.IsNullOrWhiteSpace(symbol))
                {
                    _log($"FlattenSymbol: precondition failed for '{accountName}/{symbol}' — SKIPPING.");
                    return false;
                }

                // Instrument.GetInstrument(string) returns null if not found.
                // The name must match NT8's exact format (e.g. "NQ 09-26").
                Instrument instr = Instrument.GetInstrument(symbol);
                if (instr == null)
                {
                    _log($"FlattenSymbol: instrument '{symbol}' not found in NT8 — SKIPPING.");
                    return false;
                }

                _log($"FlattenSymbol: Issuing flatten on '{accountName}' / '{symbol}'.");
                // account.Flatten(ICollection<Instrument>) — pass the target instrument.
                acct.Flatten(new[] { instr });

                return true;
            }
            catch (Exception ex)
            {
                _log($"FlattenSymbol error for '{accountName}/{symbol}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // PlaceMarketOrder
        // -----------------------------------------------------------------------

        public bool PlaceMarketOrder(string accountName, string instrumentName, bool isBuy, int quantity)
        {
            // Hard guards — never submit a zero or negative qty order.
            if (quantity < 1)
            {
                _log($"PlaceMarketOrder: quantity={quantity} is invalid — SKIPPING.");
                return false;
            }

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"PlaceMarketOrder: account '{accountName}' not found — SKIPPING.");
                    return false;
                }

                // Instrument.GetInstrument(string) returns null if not found.
                // The name must match NT8's exact format (e.g. "NQ 09-26").
                Instrument instr = Instrument.GetInstrument(instrumentName);
                if (instr == null)
                {
                    _log($"PlaceMarketOrder: instrument '{instrumentName}' not found in NT8 — SKIPPING.");
                    return false;
                }

                OrderAction action = isBuy ? OrderAction.Buy : OrderAction.Sell;

                _log($"PlaceMarketOrder: {action} {quantity} {instrumentName} on '{accountName}'.");

                // Official 12-arg CreateOrder signature:
                //   account.CreateOrder(Instrument, OrderAction, OrderType, OrderEntry,
                //                       TimeInForce, int qty, double limitPrice, double stopPrice,
                //                       string oco, string name, DateTime gtd, CustomOrder customOrder)
                // Returns Order; then account.Submit(new[] { order }).
                Order order = acct.CreateOrder(
                    instr,
                    action,
                    OrderType.Market,
                    OrderEntry.Automated,
                    TimeInForce.Day,
                    quantity,
                    0,                                    // limitPrice (not used for market)
                    0,                                    // stopPrice (not used for market)
                    string.Empty,                         // oco id
                    "FinotaurCopier",                     // name — visible in Executions tab
                    NinjaTrader.Core.Globals.MaxDate,     // gtd
                    null                                  // customOrder
                );

                if (order == null)
                {
                    _log($"PlaceMarketOrder: CreateOrder returned null for {instrumentName} — SKIPPING.");
                    return false;
                }

                acct.Submit(new[] { order });

                return true;
            }
            catch (Exception ex)
            {
                _log($"PlaceMarketOrder error for '{accountName}/{instrumentName}': {ex.Message}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // SubscribeFills / Unsubscribe
        // -----------------------------------------------------------------------

        public object SubscribeFills(string accountName, Action<FillInfo> onFill)
        {
            if (onFill == null) return null;

            try
            {
                Account acct = FindAccount(accountName);
                if (acct == null)
                {
                    _log($"SubscribeFills: account '{accountName}' not found — cannot subscribe.");
                    return null;
                }

                var sub = new FillSubscription
                {
                    AccountName = accountName,
                    OnFill      = onFill
                };

                // Build the NT8 ExecutionUpdate handler.
                // ExecutionEventArgs.Execution (type Execution in NinjaTrader.Cbi) exposes:
                //   .ExecutionId (string), .Instrument, .Price, .Quantity,
                //   .MarketPosition, .Order, .Account — all confirmed in NT8 Cbi.
                EventHandler<ExecutionEventArgs> ntHandler = (sender, e) =>
                {
                    try
                    {
                        var exec = e.Execution;
                        if (exec == null) return;
                        if (!string.Equals(exec.Account?.Name, accountName,
                                StringComparison.OrdinalIgnoreCase)) return;

                        // IsOpening approximation: Buy action = opening a long.
                        // CopierEngine has its own copy_opens/copy_closes gate as a fallback.
                        bool isBuy = exec.Order?.OrderAction == OrderAction.Buy ||
                                     exec.Order?.OrderAction == OrderAction.BuyToCover;
                        bool isOpening = isBuy;  // simplified; refine with position tracking if needed

                        var fill = new FillInfo
                        {
                            ExecutionId    = exec.ExecutionId,
                            AccountName    = exec.Account?.Name,
                            InstrumentName = exec.Instrument?.FullName,
                            IsBuy          = isBuy,
                            Quantity       = exec.Quantity,
                            Price          = exec.Price,
                            IsOpening      = isOpening,
                            Timestamp      = exec.Time
                        };

                        sub.OnFill(fill);
                    }
                    catch (Exception ex)
                    {
                        _log($"SubscribeFills handler error: {ex.Message}");
                    }
                };

                sub.NtHandler = ntHandler;

                // Hook into the account's ExecutionUpdate event.
                // account.ExecutionUpdate is EventHandler<ExecutionEventArgs> on NinjaTrader.Cbi.Account.
                // We track _hookedAccounts for logging, but always attach the handler
                // (each subscription needs its own handler for independent -= on Unsubscribe).
                _hookedAccounts.TryAdd(accountName, acct);
                acct.ExecutionUpdate += ntHandler;

                var id = Guid.NewGuid();
                _subscriptions[id] = sub;

                _log($"SubscribeFills: subscribed to '{accountName}' (sub id: {id}).");
                return id; // opaque handle
            }
            catch (Exception ex)
            {
                _log($"SubscribeFills error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        public void Unsubscribe(object subscriptionHandle)
        {
            if (subscriptionHandle == null) return;
            if (!(subscriptionHandle is Guid id)) return;

            try
            {
                if (!_subscriptions.TryRemove(id, out FillSubscription sub)) return;

                Account acct = FindAccount(sub.AccountName);
                if (acct != null && sub.NtHandler != null)
                {
                    acct.ExecutionUpdate -= sub.NtHandler;
                }

                _log($"Unsubscribe: removed subscription {id} for '{sub.AccountName}'.");
            }
            catch (Exception ex)
            {
                _log($"Unsubscribe error: {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // Private helpers
        // -----------------------------------------------------------------------

        /// <summary>
        /// Finds an NT8 Account by name. Returns null if not found (never throws).
        /// Caller is responsible for null-checking.
        /// </summary>
        private Account FindAccount(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return null;
            try
            {
                lock (Account.All)
                {
                    return Account.All.FirstOrDefault(a =>
                        string.Equals(a.Name, accountName, StringComparison.OrdinalIgnoreCase));
                }
            }
            catch (Exception ex)
            {
                _log($"FindAccount error for '{accountName}': {ex.Message}");
                return null;
            }
        }

        // -----------------------------------------------------------------------
        // IDisposable
        // -----------------------------------------------------------------------

        private bool _disposed;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            // Unhook all remaining subscriptions
            foreach (var kvp in _subscriptions)
            {
                try
                {
                    Account acct = FindAccount(kvp.Value.AccountName);
                    if (acct != null && kvp.Value.NtHandler != null)
                        acct.ExecutionUpdate -= kvp.Value.NtHandler;
                }
                catch { /* best-effort cleanup */ }
            }
            _subscriptions.Clear();
            _hookedAccounts.Clear();
        }
    }
}
