// =============================================================================
// Finotaur Agent — Pairing/PairingWindow.xaml.cs
//
// Pure-C# WPF window — NO XAML, NO InitializeComponent(), NO partial class.
//
// NinjaScript does NOT compile .xaml files, so generated control fields from
// PairingWindow.xaml do not exist at runtime → every x:Name reference
// (TxtHeartbeat, TxtPairingStatus, etc.) would produce CS0103. This file
// replaces the XAML-backed code-behind with a self-contained window that
// builds its entire UI in the constructor.
//
// The .xaml file is left on disk but is inert — NinjaScript ignores it.
//
// THREADING:
//   All UI updates MUST run on the WPF Dispatcher thread. The agent's background
//   loop calls UpdateStatus() which marshals via Dispatcher.Invoke. Never
//   touch WPF controls from a background Task directly.
//
// SECURITY:
//   The pairing code is a short-lived, server-generated token. It is OK to
//   display (the user must type or paste it). The device_token received back
//   is NEVER displayed — it is passed directly to TokenStore.Save and the
//   in-memory FinotaurClient. Do not log or display it.
// =============================================================================

using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Api;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Copier;
using NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Storage;

namespace NinjaTrader.NinjaScript.AddOns.FinotaurAgent.Pairing
{
    // =========================================================================
    // AgentStatusSnapshot — data transfer object for UpdateStatus()
    // Populated by FinotaurAgent and passed to the window on each poll.
    // =========================================================================

    /// <summary>
    /// Snapshot of the agent's current state, passed to PairingWindow.UpdateStatus().
    /// All fields are read-only from the window's perspective.
    /// </summary>
    public sealed class AgentStatusSnapshot
    {
        public string    DeviceName        { get; set; }
        public DateTime? LastConfigAt      { get; set; }
        public string    ConfigVersion     { get; set; }
        public bool      MasterEnabled     { get; set; }
        public bool      KillSwitchEngaged { get; set; }
        public int       ActiveRuleCount   { get; set; }
        public int       ActiveRouteCount  { get; set; }
        public bool      LastHeartbeatOk   { get; set; }
        public DateTime? LastHeartbeatAt   { get; set; }
        /// <summary>One-liner from CopierEngine.GetActivitySummary().</summary>
        public string    ActivitySummary   { get; set; }
        /// <summary>One-liner for the bottom status bar.</summary>
        public string    BottomStatusLine  { get; set; }
    }

    // =========================================================================
    // PairingWindow — self-contained WPF window (no XAML dependency)
    // =========================================================================

    /// <summary>
    /// Pairing + live-status window for the Finotaur Agent AddOn.
    /// Derives from <see cref="Window"/> (standard WPF). If NT8 requires
    /// NTWindow, change the base class to NinjaTrader.Gui.Tools.NTWindow —
    /// all public members used by FinotaurAgent.cs come from the Window base
    /// and will remain identical.
    /// </summary>
    public class PairingWindow : Window   // NOT partial — no XAML companion needed
    {
        // -----------------------------------------------------------------------
        // Dependencies injected by FinotaurAgent
        // -----------------------------------------------------------------------

        private readonly FinotaurClient  _client;
        private readonly CopierEngine    _copier;    // may be null before first config
        private readonly Action<string>  _log;
        private readonly string          _deviceName;
        private readonly string          _agentVersion;

        // -----------------------------------------------------------------------
        // UI control fields (replaces x:Name XAML attributes)
        // -----------------------------------------------------------------------

        private TextBlock  _txtVersion;
        private TextBox    _txtPairingCode;
        private Button     _btnPair;
        private TextBlock  _txtPairingStatus;
        private TextBlock  _txtDeviceName;
        private TextBlock  _txtLastConfig;
        private TextBlock  _txtConfigVersion;
        private Ellipse    _dotMaster;
        private TextBlock  _txtMasterState;
        private Ellipse    _dotKill;
        private TextBlock  _txtKillState;
        private TextBlock  _txtRuleCount;
        private TextBlock  _txtRouteCount;
        private Ellipse    _dotHeartbeat;
        private TextBlock  _txtHeartbeat;
        private TextBlock  _txtCopierActivity;
        private TextBlock  _txtBottomStatus;
        private Button     _btnRefresh;
        private Button     _btnUnpair;

        // -----------------------------------------------------------------------
        // Colour palette (mirrors the XAML resources)
        // -----------------------------------------------------------------------

        // FINOTAUR brand palette — matte black + gold
        private static readonly Color   _colGold    = Color.FromRgb(201, 166,  70);  // #C9A646
        private static readonly Color   _colPanel   = Color.FromRgb( 22,  22,  23);  // #161617
        private static readonly Color   _colBorder  = Color.FromRgb( 46,  42,  26);  // #2E2A1A gold-tinted dim
        private static readonly Color   _colAccent  = Color.FromRgb(255,  69,  58);  // #FF453A red
        private static readonly Color   _colBg      = Color.FromRgb( 10,  10,  11);  // #0A0A0B near-black
        private static readonly Color   _colText    = Color.FromRgb(244, 244, 245);  // #F4F4F5
        private static readonly Color   _colMuted   = Color.FromRgb(154, 154, 158);  // #9A9A9E
        private static readonly Color   _colGray    = Color.FromRgb( 80,  80,  84);  // #505054 neutral unset dot
        private static readonly Color   _colGreen   = Color.FromRgb( 52, 199,  89);  // #34C759 online/ok
        private static readonly Color   _colRed     = Color.FromRgb(255,  69,  58);  // #FF453A error/kill

        private static SolidColorBrush  Brush(Color c) => new SolidColorBrush(c);

        // -----------------------------------------------------------------------
        // Constructor — builds UI entirely in code
        // -----------------------------------------------------------------------

        /// <summary>
        /// Creates the PairingWindow and builds the entire WPF UI in code.
        /// No XAML, no InitializeComponent().
        /// </summary>
        /// <param name="client">HTTP client (already has device token loaded if paired).</param>
        /// <param name="copier">CopierEngine instance (may be null if not yet started).</param>
        /// <param name="deviceName">Human-readable name for this machine.</param>
        /// <param name="agentVersion">Semantic version string, e.g. "1.0.0".</param>
        /// <param name="logger">Logger delegate (same as used by the agent).</param>
        public PairingWindow(
            FinotaurClient  client,
            CopierEngine    copier,
            string          deviceName,
            string          agentVersion,
            Action<string>  logger = null)
        {
            _client       = client       ?? throw new ArgumentNullException(nameof(client));
            _copier       = copier;
            _deviceName   = deviceName   ?? System.Environment.MachineName;
            _agentVersion = agentVersion ?? "1.0.0";
            _log          = logger       ?? (m => System.Diagnostics.Debug.WriteLine($"[PairingWindow] {m}"));

            // Window chrome
            Title                 = "Finotaur Agent";
            Width                 = 540;
            Height                = 640;
            MinWidth              = 420;
            MinHeight             = 500;
            ResizeMode            = ResizeMode.CanResize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background            = Brush(_colBg);
            Foreground            = Brush(_colText);
            FontFamily            = new FontFamily("Segoe UI");
            FontSize              = 13;

            // Build the UI tree and set it as the window content
            Content = BuildUi();

            // Populate initial state once the visual tree is ready
            Loaded += OnWindowLoaded;
        }

        // -----------------------------------------------------------------------
        // UI construction
        // -----------------------------------------------------------------------

        private UIElement BuildUi()
        {
            var root = new Grid { Margin = new Thickness(20) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // 0 header
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // 1 pairing
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // 2 status
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // 3 activity
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // 4 bottom bar

            // Build each section once, assign its row, then add to root.
            UIElement header   = BuildHeader();
            UIElement pairing  = BuildPairing();
            UIElement status   = BuildStatus();
            UIElement activity = BuildActivity();
            UIElement bottom   = BuildBottomBar();

            Grid.SetRow(header,   0);
            Grid.SetRow(pairing,  1);
            Grid.SetRow(status,   2);
            Grid.SetRow(activity, 3);
            Grid.SetRow(bottom,   4);

            root.Children.Add(header);
            root.Children.Add(pairing);
            root.Children.Add(status);
            root.Children.Add(activity);
            root.Children.Add(bottom);

            return root;
        }

        // --- Row 0: Header ---

        private UIElement BuildHeader()
        {
            var panel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 16)
            };

            // Gold circle as logo placeholder
            panel.Children.Add(new Ellipse
            {
                Width               = 36,
                Height              = 36,
                Fill                = Brush(_colGold),
                VerticalAlignment   = VerticalAlignment.Center,
                Margin              = new Thickness(0, 0, 10, 0)
            });

            var textStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            textStack.Children.Add(new TextBlock
            {
                Text       = "FINOTAUR AGENT",
                FontSize   = 18,
                FontWeight = FontWeights.Bold,
                Foreground = Brush(_colGold)
            });

            _txtVersion = new TextBlock
            {
                Text       = $"v{_agentVersion}",
                FontSize   = 11,
                Foreground = Brush(_colMuted)
            };
            textStack.Children.Add(_txtVersion);
            panel.Children.Add(textStack);

            return panel;
        }

        // --- Row 1: Pairing section ---

        private UIElement BuildPairing()
        {
            var border = new Border
            {
                Background      = Brush(_colPanel),
                BorderBrush     = Brush(_colBorder),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(16),
                Margin          = new Thickness(0, 0, 0, 12)
            };

            var stack = new StackPanel();

            stack.Children.Add(MakeSectionLabel("DEVICE PAIRING"));

            stack.Children.Add(new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                Foreground   = Brush(_colMuted),
                FontSize     = 11,
                Margin       = new Thickness(0, 0, 0, 10),
                Text         = "1. Open FINOTAUR web app   " +
                               "2. Go to Settings → Automation → Agent tab   " +
                               "3. Click 'Pair a new device'   " +
                               "4. Copy the code and paste it below."
            });

            // Code entry row
            var codeGrid = new Grid();
            codeGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            codeGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _txtPairingCode = new TextBox
            {
                Margin       = new Thickness(0, 0, 8, 0),
                Padding      = new Thickness(10, 8, 10, 8),
                FontSize     = 14,
                FontFamily   = new FontFamily("Courier New"),
                Background   = Brush(Color.FromRgb(14, 14, 16)),  // #0E0E10 deep input bg
                Foreground   = Brush(_colText),
                BorderBrush  = Brush(_colBorder),                  // #2E2A1A gold-dim border
                CaretBrush   = Brush(_colGold),
                MaxLength    = 12,
                ToolTip      = "Paste the pairing code from the web app here"
            };
            _txtPairingCode.KeyDown += OnPairingCodeKeyDown;
            Grid.SetColumn(_txtPairingCode, 0);
            codeGrid.Children.Add(_txtPairingCode);

            _btnPair = new Button
            {
                Content   = "Pair",
                MinWidth  = 80,
                Padding   = new Thickness(16, 8, 16, 8),
                Cursor    = System.Windows.Input.Cursors.Hand,
                Background = Brush(_colGold),
                Foreground = Brush(_colBg),           // #0A0A0B near-black text on gold button
                FontWeight = FontWeights.Bold,
                BorderThickness = new Thickness(0)
            };
            _btnPair.Click += OnBtnPairClick;
            Grid.SetColumn(_btnPair, 1);
            codeGrid.Children.Add(_btnPair);

            stack.Children.Add(codeGrid);

            _txtPairingStatus = new TextBlock
            {
                Margin     = new Thickness(0, 8, 0, 0),
                FontSize   = 12,
                Foreground = Brush(_colMuted),
                Text       = "Not paired. Enter a code from the web app."
            };
            stack.Children.Add(_txtPairingStatus);

            border.Child = stack;
            return border;
        }

        // --- Row 2: Live status section ---

        private UIElement BuildStatus()
        {
            var border = new Border
            {
                Background      = Brush(_colPanel),
                BorderBrush     = Brush(_colBorder),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(16),
                Margin          = new Thickness(0, 0, 0, 12)
            };

            var stack = new StackPanel();
            stack.Children.Add(MakeSectionLabel("LIVE STATUS"));

            // Device name
            stack.Children.Add(MakeStatusRow("Device name:", out _txtDeviceName, "—"));
            // Last config
            stack.Children.Add(MakeStatusRow("Last config:", out _txtLastConfig, "—"));
            // Config version
            stack.Children.Add(MakeStatusRow("Config version:", out _txtConfigVersion, "—"));

            // Master enabled (with dot)
            stack.Children.Add(MakeStatusRowWithDot("Master enabled:", out _dotMaster, out _txtMasterState, "—"));
            // Kill switch
            stack.Children.Add(MakeStatusRowWithDot("Kill switch:", out _dotKill, out _txtKillState, "—"));

            // Active risk rules
            stack.Children.Add(MakeStatusRow("Active risk rules:", out _txtRuleCount, "—"));
            // Active routes
            stack.Children.Add(MakeStatusRow("Active routes:", out _txtRouteCount, "—"));

            // Last heartbeat
            stack.Children.Add(MakeStatusRowWithDot("Last heartbeat:", out _dotHeartbeat, out _txtHeartbeat, "—"));

            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Content = stack
            };

            border.Child = scroll;
            return border;
        }

        // --- Row 3: Agent activity ---

        private UIElement BuildActivity()
        {
            var border = new Border
            {
                Background      = Brush(_colPanel),
                BorderBrush     = Brush(_colBorder),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(16),
                Margin          = new Thickness(0, 0, 0, 12),
                MaxHeight       = 120
            };

            var stack = new StackPanel();
            stack.Children.Add(MakeSectionLabel("AGENT ACTIVITY"));

            _txtCopierActivity = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                FontSize     = 11,
                Foreground   = Brush(_colMuted),
                Text         = "No activity yet."
            };
            stack.Children.Add(_txtCopierActivity);
            border.Child = stack;
            return border;
        }

        // --- Row 4: Bottom bar ---

        private UIElement BuildBottomBar()
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _txtBottomStatus = new TextBlock
            {
                VerticalAlignment = VerticalAlignment.Center,
                FontSize          = 11,
                Foreground        = Brush(_colMuted),
                Text              = "Idle"
            };
            Grid.SetColumn(_txtBottomStatus, 0);
            grid.Children.Add(_txtBottomStatus);

            _btnRefresh = new Button
            {
                Content         = "Refresh",
                Margin          = new Thickness(0, 0, 8, 0),
                Padding         = new Thickness(12, 6, 12, 6),
                Background      = Brush(_colPanel),   // #161617 dark card bg
                Foreground      = Brush(_colText),     // #F4F4F5
                BorderBrush     = Brush(_colBorder),   // #2E2A1A gold-dim border
                BorderThickness = new Thickness(1),
                Cursor          = System.Windows.Input.Cursors.Hand
            };
            _btnRefresh.Click += OnBtnRefreshClick;
            Grid.SetColumn(_btnRefresh, 1);
            grid.Children.Add(_btnRefresh);

            _btnUnpair = new Button
            {
                Content         = "Unpair",
                Padding         = new Thickness(12, 6, 12, 6),
                Background      = Brush(Color.FromRgb(18, 6, 6)),  // very dark red tint, near-black
                Foreground      = Brush(_colAccent),                // #FF453A red
                BorderBrush     = Brush(_colAccent),
                BorderThickness = new Thickness(1),
                Cursor          = System.Windows.Input.Cursors.Hand
            };
            _btnUnpair.Click += OnBtnUnpairClick;
            Grid.SetColumn(_btnUnpair, 2);
            grid.Children.Add(_btnUnpair);

            return grid;
        }

        // -----------------------------------------------------------------------
        // Layout helpers
        // -----------------------------------------------------------------------

        private TextBlock MakeSectionLabel(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 11,
            FontWeight = FontWeights.SemiBold,
            Foreground = Brush(_colGold),   // gold accent on section headings
            Margin     = new Thickness(0, 10, 0, 8)
        };

        /// <summary>Two-column label + value row (no dot indicator).</summary>
        private UIElement MakeStatusRow(string label, out TextBlock valueBlock, string defaultValue = "—")
        {
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(160) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            grid.Children.Add(new TextBlock
            {
                Text       = label,
                Foreground = Brush(_colMuted),
                FontSize   = 12
            });

            valueBlock = new TextBlock { Text = defaultValue, Foreground = Brush(_colText), FontSize = 13 };
            Grid.SetColumn(valueBlock, 1);
            grid.Children.Add(valueBlock);

            return grid;
        }

        /// <summary>Two-column label + [dot + text] row (for state indicators).</summary>
        private UIElement MakeStatusRowWithDot(
            string     label,
            out Ellipse    dot,
            out TextBlock  valueBlock,
            string     defaultValue = "—")
        {
            var grid = new Grid { Margin = new Thickness(0, 6, 0, 4) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(160) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            grid.Children.Add(new TextBlock
            {
                Text       = label,
                Foreground = Brush(_colMuted),
                FontSize   = 12
            });

            var dotPanel = new StackPanel { Orientation = Orientation.Horizontal };
            Grid.SetColumn(dotPanel, 1);

            dot = new Ellipse
            {
                Width             = 10,
                Height            = 10,
                Fill              = Brush(_colGray),
                Margin            = new Thickness(0, 0, 6, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            dotPanel.Children.Add(dot);

            valueBlock = new TextBlock { Text = defaultValue, Foreground = Brush(_colText), FontSize = 13 };
            dotPanel.Children.Add(valueBlock);

            grid.Children.Add(dotPanel);
            return grid;
        }

        // -----------------------------------------------------------------------
        // Window loaded — set initial UI state
        // -----------------------------------------------------------------------

        private void OnWindowLoaded(object sender, RoutedEventArgs e)
        {
            _txtVersion.Text = $"v{_agentVersion}";

            if (_client.IsPaired)
            {
                if (TokenStore.Load(out _, out _, out string storedDeviceName))
                    SetPairedUi(storedDeviceName ?? _deviceName);
                else
                    SetPairedUi(_deviceName);
            }
            else
            {
                SetUnpairedUi();
            }
        }

        // -----------------------------------------------------------------------
        // Pair button + Enter key handler
        // -----------------------------------------------------------------------

        private void OnBtnPairClick(object sender, RoutedEventArgs e)
        {
            _ = DoPairAsync();
        }

        private void OnPairingCodeKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                _ = DoPairAsync();
        }

        private async Task DoPairAsync()
        {
            string code = _txtPairingCode.Text?.Trim();
            if (string.IsNullOrWhiteSpace(code))
            {
                SetPairingStatusText("Please enter the pairing code from the web app.", isError: true);
                return;
            }

            _btnPair.IsEnabled = false;
            SetPairingStatusText("Pairing…");

            try
            {
                // Network call — off UI thread via async/await
                PairingResponse result = await _client.PairAsync(
                    code,
                    _deviceName,
                    _agentVersion,
                    CancellationToken.None).ConfigureAwait(false);

                // Marshal back to UI thread for all control updates
                await Dispatcher.InvokeAsync(() =>
                {
                    if (result?.DeviceToken != null)
                    {
                        bool saved = TokenStore.Save(
                            result.DeviceToken,
                            result.DeviceId ?? string.Empty,
                            _deviceName);

                        if (saved)
                        {
                            _client.SetDeviceToken(result.DeviceToken);
                            _txtPairingCode.Text = string.Empty;
                            SetPairedUi(_deviceName);
                            SetPairingStatusText("Paired successfully! The agent is now active.", isError: false);
                            _log("Pairing successful.");
                        }
                        else
                        {
                            SetPairingStatusText(
                                "Pairing succeeded but credential save failed. " +
                                "Check write access to the NT8 data folder.",
                                isError: true);
                        }
                    }
                    else
                    {
                        SetPairingStatusText(
                            "Pairing failed. Check the code and try again. " +
                            "(Code may have expired — generate a new one in the web app.)",
                            isError: true);
                        _log("Pairing failed — null response or server error.");
                    }

                    _btnPair.IsEnabled = true;
                });
            }
            catch (Exception ex)
            {
                await Dispatcher.InvokeAsync(() =>
                {
                    SetPairingStatusText($"Error: {ex.Message}", isError: true);
                    _btnPair.IsEnabled = true;
                });
                _log($"DoPairAsync exception: {ex.GetType().Name} — {ex.Message}");
            }
        }

        // -----------------------------------------------------------------------
        // UpdateStatus — called by FinotaurAgent on every poll cycle
        //
        // Thread-safe: can be called from any thread.
        // Marshals all UI mutations via Dispatcher.Invoke.
        // -----------------------------------------------------------------------

        /// <summary>
        /// Refreshes the live-status area with the latest agent state.
        /// Safe to call from any thread (marshals to UI thread internally).
        /// </summary>
        public void UpdateStatus(AgentStatusSnapshot snapshot)
        {
            if (snapshot == null) return;

            // Dispatcher.Invoke (synchronous) keeps the background loop from
            // racing ahead of a slow UI thread. Use InvokeAsync if you prefer
            // fire-and-forget semantics — both are correct here.
            Dispatcher.Invoke(() =>
            {
                try
                {
                    _txtDeviceName.Text = snapshot.DeviceName ?? "—";

                    _txtLastConfig.Text = snapshot.LastConfigAt.HasValue
                        ? snapshot.LastConfigAt.Value.ToLocalTime().ToString("HH:mm:ss")
                        : "—";
                    _txtConfigVersion.Text = snapshot.ConfigVersion ?? "—";

                    UpdateStateIndicator(
                        _dotMaster, _txtMasterState,
                        snapshot.MasterEnabled,
                        "ON", "OFF",
                        onColor:  _colGreen,   // #34C759
                        offColor: _colGold);   // #C9A646 gold for disabled/OFF states

                    bool killEngaged = snapshot.KillSwitchEngaged;
                    UpdateStateIndicator(
                        _dotKill, _txtKillState,
                        !killEngaged,
                        "Not engaged", "ENGAGED — all operations stopped",
                        onColor:  _colGreen,   // #34C759
                        offColor: _colRed);    // #FF453A kill switch engaged

                    _txtRuleCount.Text  = snapshot.ActiveRuleCount.ToString();
                    _txtRouteCount.Text = snapshot.ActiveRouteCount.ToString();

                    UpdateStateIndicator(
                        _dotHeartbeat, _txtHeartbeat,
                        snapshot.LastHeartbeatOk,
                        snapshot.LastHeartbeatAt.HasValue
                            ? $"OK ({snapshot.LastHeartbeatAt.Value.ToLocalTime():HH:mm:ss})"
                            : "OK",
                        snapshot.LastHeartbeatAt.HasValue
                            ? $"Failed ({snapshot.LastHeartbeatAt.Value.ToLocalTime():HH:mm:ss})"
                            : "Failed",
                        onColor:  _colGreen,   // #34C759
                        offColor: _colRed);    // #FF453A heartbeat failed

                    _txtCopierActivity.Text = snapshot.ActivitySummary   ?? "No activity yet.";
                    _txtBottomStatus.Text   = snapshot.BottomStatusLine  ?? "Active";
                }
                catch (Exception ex)
                {
                    // UI update must never crash the background loop
                    _log($"UpdateStatus UI error: {ex.GetType().Name} — {ex.Message}");
                }
            });
        }

        // -----------------------------------------------------------------------
        // Refresh button
        // -----------------------------------------------------------------------

        private void OnBtnRefreshClick(object sender, RoutedEventArgs e)
        {
            _txtBottomStatus.Text = "Refreshing on next poll cycle…";
            _log("User pressed Refresh — next poll will update status.");
        }

        // -----------------------------------------------------------------------
        // Unpair button
        // -----------------------------------------------------------------------

        private void OnBtnUnpairClick(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show(
                "This will remove this device's credentials from this machine.\n\n" +
                "To fully revoke access, also remove the device from the web app " +
                "(Settings → Automation → Devices).\n\n" +
                "Continue?",
                "Unpair Finotaur Agent",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (confirm != MessageBoxResult.Yes) return;

            TokenStore.Clear();
            _client.SetDeviceToken(null);
            SetUnpairedUi();
            SetPairingStatusText("Device unpaired. Enter a new pairing code to re-pair.", isError: false);
            _log("Device unpaired by user.");
        }

        // -----------------------------------------------------------------------
        // UI state helpers
        // -----------------------------------------------------------------------

        private void SetPairedUi(string deviceName)
        {
            _txtDeviceName.Text        = deviceName;
            _txtPairingStatus.Text     = $"Paired as: {deviceName}";
            _txtPairingStatus.Foreground = Brush(_colGreen);  // #34C759
            _btnPair.IsEnabled         = false;
            _txtPairingCode.IsEnabled  = false;
        }

        private void SetUnpairedUi()
        {
            _txtDeviceName.Text      = "—";
            _txtLastConfig.Text      = "—";
            _txtConfigVersion.Text   = "—";
            _txtRuleCount.Text       = "—";
            _txtRouteCount.Text      = "—";
            _txtCopierActivity.Text  = "Not paired.";
            _txtBottomStatus.Text    = "Not paired.";
            _btnPair.IsEnabled       = true;
            _txtPairingCode.IsEnabled = true;

            _dotMaster.Fill          = Brush(_colGray);
            _txtMasterState.Text     = "—";
            _dotKill.Fill            = Brush(_colGray);
            _txtKillState.Text       = "—";
            _dotHeartbeat.Fill       = Brush(_colGray);
            _txtHeartbeat.Text       = "—";
        }

        private void SetPairingStatusText(string message, bool isError = false)
        {
            _txtPairingStatus.Text       = message;
            _txtPairingStatus.Foreground = isError
                ? Brush(_colRed)    // #FF453A
                : Brush(_colMuted);
        }

        /// <summary>
        /// Updates a status dot + text pair based on a boolean condition.
        /// </summary>
        private static void UpdateStateIndicator(
            Ellipse   dot,
            TextBlock label,
            bool      isGoodState,
            string    goodText,
            string    badText,
            Color     onColor,
            Color     offColor)
        {
            dot.Fill         = Brush(isGoodState ? onColor : offColor);
            label.Text       = isGoodState ? goodText : badText;
            label.Foreground = Brush(isGoodState ? onColor : offColor);
        }
    }
}
