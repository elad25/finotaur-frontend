import { NextApiRequest, NextApiResponse } from 'next';
import { testNewsletter } from '@/lib/newsletter/test';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const result = await testNewsletter();
  
  if (result) {
    return res.status(200).json({
      success: true,
      subject: result.newsletter.subject,
      sections: result.newsletter.sections,
      html: result.html,
    });
  } else {
    return res.status(500).json({ success: false, error: 'Test failed' });
  }
}