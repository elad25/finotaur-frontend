// ==========================================
// Newsletter Module - Main Export
// Version 5.0 - AI Agents SDK
// ==========================================

// Builder
export { NewsletterBuilder, createNewsletterBuilder } from './builder';
export type { NewsletterBuilderConfig } from './builder';

// Collectors
export { createMarketDataCollector } from './collectors/index.js';

// AI Processor - NOW USING AGENTS SDK! ← שינוי קריטי
export { createAIProcessor, NewsletterAIProcessor } from './ai/ai-processor-adapter';
export type { MarketDataInput, GeneratedNewsletter } from './ai/agents-workflow-sdk';

// Email
export { createEmailSender } from './email/sender';
export { generateEmailHTML, generatePlainText } from './email/template';

// Types
export * from './types';