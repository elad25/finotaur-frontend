// ==========================================
// Newsletter System Types (JS version)
// ==========================================

export const DEFAULT_NEWSLETTER_CONFIG = {
  sendTime: "09:00",
  timezone: "America/New_York",
  daysToSend: [1, 2, 3, 4, 5],
  maxRecipientsPerBatch: 100,
  enableTracking: true,
};