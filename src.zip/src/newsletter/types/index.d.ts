// ==========================================
// Newsletter System Types - Declarations
// ==========================================

// Re-export all types from other modules for convenience
export * from '../collectors/index';
export * from '../ai/processor';
export * from '../email/sender';
export * from '../email/template';

export interface NewsletterConfig {
  sendTime: string;
  timezone: string;
  daysToSend: number[];
  maxRecipientsPerBatch: number;
  enableTracking: boolean;
}

export declare const DEFAULT_NEWSLETTER_CONFIG: NewsletterConfig;

// Additional shared types
export interface Subscriber {
  id: string;
  email: string;
  name?: string;
  subscribedAt: string;
  status: 'active' | 'unsubscribed' | 'bounced';
  preferences?: {
    frequency?: 'daily' | 'weekly';
    categories?: string[];
  };
}

export interface NewsletterRun {
  id: string;
  startedAt: string;
  completedAt?: string;
  status: 'running' | 'completed' | 'failed';
  recipientCount: number;
  sentCount: number;
  failedCount: number;
  error?: string;
}

export interface ScheduleConfig {
  enabled: boolean;
  time: string;
  timezone: string;
  days: number[];
  skipHolidays?: boolean;
}