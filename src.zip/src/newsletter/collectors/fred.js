// ==========================================
// FRED API Collector
// ==========================================

const FRED_BASE_URL = 'https://api.stlouisfed.org/fred/series/observations';

const FRED_SERIES = {
  CPIAUCSL: { name: 'CPI (All Urban Consumers)', unit: '%' },
  PCEPI: { name: 'PCE Price Index', unit: '%' },
  FEDFUNDS: { name: 'Federal Funds Rate', unit: '%' },
  DGS10: { name: '10-Year Treasury Yield', unit: '%' },
  DGS2: { name: '2-Year Treasury Yield', unit: '%' },
  UNRATE: { name: 'Unemployment Rate', unit: '%' },
  PAYEMS: { name: 'Nonfarm Payrolls', unit: 'thousands' },
  ICSA: { name: 'Initial Jobless Claims', unit: 'thousands' },
  GDP: { name: 'Real GDP', unit: 'billions $' },
  HOUST: { name: 'Housing Starts', unit: 'thousands' },
  UMCSENT: { name: 'Consumer Sentiment', unit: 'index' },
};

export class FredCollector {
  constructor(config) {
    this.apiKey = config.apiKey;
    this.seriesIds = config.seriesIds || Object.keys(FRED_SERIES);
  }

  async fetchSeries(seriesId) {
    try {
      const params = new URLSearchParams({
        series_id: seriesId,
        api_key: this.apiKey,
        file_type: 'json',
        limit: '2',
        sort_order: 'desc',
      });

      const response = await fetch(`${FRED_BASE_URL}?${params}`);
      
      if (!response.ok) {
        console.error(`FRED API error for ${seriesId}:`, response.status);
        return null;
      }

      const data = await response.json();
      
      if (!data.observations || data.observations.length === 0) {
        return null;
      }

      const latest = data.observations[0];
      const previous = data.observations[1];
      
      const currentValue = parseFloat(latest.value);
      const previousValue = previous ? parseFloat(previous.value) : currentValue;
      
      if (isNaN(currentValue)) {
        return null;
      }

      const seriesInfo = FRED_SERIES[seriesId];

      return {
        id: seriesId,
        name: seriesInfo.name,
        value: currentValue,
        previousValue: previousValue,
        change: currentValue - previousValue,
        unit: seriesInfo.unit,
        date: latest.date,
        source: 'FRED',
      };
    } catch (error) {
      console.error(`Error fetching FRED series ${seriesId}:`, error);
      return null;
    }
  }

  async collectAll() {
    console.log(`📊 FRED: Fetching ${this.seriesIds.length} indicators...`);
    
    const results = await Promise.all(
      this.seriesIds.map(id => this.fetchSeries(id))
    );

    const indicators = results.filter(r => r !== null);
    
    console.log(`📊 FRED: Collected ${indicators.length} indicators`);
    
    return indicators;
  }

  async collectKeyIndicators() {
    const keyIndicators = ['FEDFUNDS', 'DGS10', 'DGS2', 'UNRATE', 'CPIAUCSL'];

    const results = await Promise.all(
      keyIndicators.map(id => this.fetchSeries(id))
    );

    return results.filter(r => r !== null);
  }
}

export function createFredCollector(apiKey) {
  return new FredCollector({ apiKey });
}

export { FRED_SERIES };