// ==========================================
// Finnhub API Collector
// ==========================================

const FINNHUB_BASE_URL = 'https://finnhub.io/api/v1';

export class FinnhubCollector {
  constructor(config) {
    this.apiKey = config.apiKey;
  }

  async fetchMarketNews(category = 'general', limit = 10) {
    try {
      console.log(`📰 Finnhub: Fetching ${category} news...`);
      
      const params = new URLSearchParams({
        category,
        token: this.apiKey,
      });

      const response = await fetch(`${FINNHUB_BASE_URL}/news?${params}`);
      
      if (!response.ok) {
        console.error('Finnhub news API error:', response.status);
        return [];
      }

      const data = await response.json();
      
      const news = data.slice(0, limit).map(item => ({
        id: item.id.toString(),
        headline: item.headline,
        summary: item.summary,
        source: item.source,
        url: item.url,
        datetime: item.datetime,
        category: item.category,
        related: item.related ? item.related.split(',') : undefined,
      }));

      console.log(`📰 Finnhub: Collected ${news.length} news items`);
      
      return news;
    } catch (error) {
      console.error('Error fetching Finnhub news:', error);
      return [];
    }
  }

  async fetchCompanyNews(symbol, daysBack = 7) {
    try {
      const toDate = new Date();
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - daysBack);

      const params = new URLSearchParams({
        symbol,
        from: fromDate.toISOString().split('T')[0],
        to: toDate.toISOString().split('T')[0],
        token: this.apiKey,
      });

      const response = await fetch(`${FINNHUB_BASE_URL}/company-news?${params}`);
      
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      
      return data.slice(0, 5).map(item => ({
        id: item.id.toString(),
        headline: item.headline,
        summary: item.summary,
        source: item.source,
        url: item.url,
        datetime: item.datetime,
        category: 'company',
        related: [symbol],
      }));
    } catch (error) {
      console.error(`Error fetching company news for ${symbol}:`, error);
      return [];
    }
  }

  async fetchForexRates() {
    try {
      console.log('💱 Finnhub: Fetching forex rates...');
      
      const pairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD'];
      const rates = [];

      for (const pair of pairs) {
        const symbol = `OANDA:${pair.replace('/', '_')}`;
        
        const params = new URLSearchParams({
          symbol,
          token: this.apiKey,
        });

        const response = await fetch(`${FINNHUB_BASE_URL}/quote?${params}`);
        
        if (response.ok) {
          const data = await response.json();
          
          if (data.c) {
            rates.push({
              pair,
              rate: data.c,
              change: data.d || 0,
              changePercent: data.dp || 0,
            });
          }
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      console.log(`💱 Finnhub: Collected ${rates.length} forex rates`);
      
      return rates;
    } catch (error) {
      console.error('Error fetching forex rates:', error);
      return [];
    }
  }

  async fetchCryptoPrices() {
    try {
      console.log('₿ Finnhub: Fetching crypto prices...');
      
      const cryptos = [
        { symbol: 'BINANCE:BTCUSDT', name: 'Bitcoin', displaySymbol: 'BTC' },
        { symbol: 'BINANCE:ETHUSDT', name: 'Ethereum', displaySymbol: 'ETH' },
        { symbol: 'BINANCE:SOLUSDT', name: 'Solana', displaySymbol: 'SOL' },
      ];

      const prices = [];

      for (const crypto of cryptos) {
        const params = new URLSearchParams({
          symbol: crypto.symbol,
          token: this.apiKey,
        });

        const response = await fetch(`${FINNHUB_BASE_URL}/quote?${params}`);
        
        if (response.ok) {
          const data = await response.json();
          
          if (data.c) {
            prices.push({
              symbol: crypto.displaySymbol,
              name: crypto.name,
              price: data.c,
              change24h: data.d || 0,
              changePercent24h: data.dp || 0,
              marketCap: 0,
            });
          }
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      console.log(`₿ Finnhub: Collected ${prices.length} crypto prices`);
      
      return prices;
    } catch (error) {
      console.error('Error fetching crypto prices:', error);
      return [];
    }
  }

  async collectAll() {
    const [news, forex, crypto] = await Promise.all([
      this.fetchMarketNews('general', 10),
      this.fetchForexRates(),
      this.fetchCryptoPrices(),
    ]);

    return { news, forex, crypto };
  }
}

export function createFinnhubCollector(apiKey) {
  return new FinnhubCollector({ apiKey });
}