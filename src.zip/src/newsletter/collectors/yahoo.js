// ==========================================
// Yahoo Finance Collector - Fixed
// With proper array validation
// ==========================================

const YAHOO_QUOTE_URL = 'https://query1.finance.yahoo.com/v7/finance/quote';

const MARKET_INDICES = [
  { symbol: '^GSPC', name: 'S&P 500' },
  { symbol: '^DJI', name: 'Dow Jones' },
  { symbol: '^IXIC', name: 'NASDAQ' },
  { symbol: '^RUT', name: 'Russell 2000' },
  { symbol: '^VIX', name: 'VIX' },
];

const WATCHED_STOCKS = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA', 'BRK-B',
  'JPM', 'V', 'JNJ', 'WMT', 'PG', 'MA', 'UNH', 'HD', 'DIS', 'NFLX',
  'PYPL', 'ADBE', 'CRM', 'INTC', 'AMD', 'ORCL', 'CSCO', 'PEP', 'KO',
  'NKE', 'MCD', 'BA', 'CAT', 'GS', 'MS', 'C', 'WFC', 'XOM', 'CVX',
];

export class YahooFinanceCollector {
  async fetchQuotes(symbols) {
    try {
      // ✅ FIX: Validate symbols is an array
      if (!symbols || !Array.isArray(symbols) || symbols.length === 0) {
        console.warn('⚠️ Yahoo: No valid symbols provided');
        return [];
      }
      
      const symbolsParam = symbols.join(',');
      
      const response = await fetch(
        `${YAHOO_QUOTE_URL}?symbols=${symbolsParam}`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          },
        }
      );

      if (!response.ok) {
        console.error('❌ Yahoo Finance API error:', response.status);
        return [];
      }

      const data = await response.json();
      
      // ✅ FIX: Validate response structure
      if (!data?.quoteResponse?.result) {
        console.warn('⚠️ Yahoo: Invalid response structure');
        return [];
      }
      
      return data.quoteResponse.result;
    } catch (error) {
      console.error('❌ Error fetching Yahoo Finance quotes:', error.message);
      return [];
    }
  }

  async fetchMarketIndices() {
    console.log('📈 Yahoo: Fetching market indices...');
    
    const symbols = MARKET_INDICES.map(i => i.symbol);
    const quotes = await this.fetchQuotes(symbols);

    // ✅ FIX: Handle empty quotes
    if (!quotes || quotes.length === 0) {
      console.warn('⚠️ Yahoo: No index data received');
      return [];
    }

    const indices = quotes.map(quote => {
      const indexInfo = MARKET_INDICES.find(i => i.symbol === quote.symbol);
      
      return {
        symbol: quote.symbol,
        name: indexInfo?.name || quote.shortName || quote.symbol,
        price: quote.regularMarketPrice || 0,
        change: quote.regularMarketChange || 0,
        changePercent: quote.regularMarketChangePercent || 0,
        previousClose: quote.regularMarketPreviousClose || 0,
      };
    });

    console.log(`📈 Yahoo: Collected ${indices.length} indices`);
    
    return indices;
  }

  async fetchTopMovers(limit = 5) {
    console.log('🚀 Yahoo: Fetching top movers...');
    
    const quotes = await this.fetchQuotes(WATCHED_STOCKS);

    // ✅ FIX: Handle empty quotes
    if (!quotes || quotes.length === 0) {
      console.warn('⚠️ Yahoo: No stock data received');
      return { gainers: [], losers: [] };
    }

    const validQuotes = quotes.filter(q => 
      q.regularMarketPrice && 
      q.regularMarketChangePercent !== undefined
    );

    if (validQuotes.length === 0) {
      console.warn('⚠️ Yahoo: No valid quotes after filtering');
      return { gainers: [], losers: [] };
    }

    const sorted = [...validQuotes].sort(
      (a, b) => b.regularMarketChangePercent - a.regularMarketChangePercent
    );

    const mapToMover = (quote, direction) => ({
      symbol: quote.symbol,
      name: quote.shortName || quote.symbol,
      price: quote.regularMarketPrice || 0,
      change: quote.regularMarketChange || 0,
      changePercent: quote.regularMarketChangePercent || 0,
      volume: quote.regularMarketVolume || 0,
      direction,
    });

    const gainers = sorted
      .filter(q => q.regularMarketChangePercent > 0)
      .slice(0, limit)
      .map(q => mapToMover(q, 'up'));

    const losers = sorted
      .filter(q => q.regularMarketChangePercent < 0)
      .slice(-limit)
      .reverse()
      .map(q => mapToMover(q, 'down'));

    console.log(`🚀 Yahoo: Found ${gainers.length} gainers, ${losers.length} losers`);
    
    return { gainers, losers };
  }

  async fetchStock(symbol) {
    if (!symbol) {
      console.warn('⚠️ Yahoo: No symbol provided');
      return null;
    }
    
    const quotes = await this.fetchQuotes([symbol]);
    
    if (!quotes || quotes.length === 0) {
      return null;
    }

    const quote = quotes[0];
    const direction = quote.regularMarketChangePercent >= 0 ? 'up' : 'down';

    return {
      symbol: quote.symbol,
      name: quote.shortName || quote.symbol,
      price: quote.regularMarketPrice || 0,
      change: quote.regularMarketChange || 0,
      changePercent: quote.regularMarketChangePercent || 0,
      volume: quote.regularMarketVolume || 0,
      direction,
    };
  }

  async collectAll() {
    try {
      const [indices, movers] = await Promise.all([
        this.fetchMarketIndices(),
        this.fetchTopMovers(5),
      ]);

      return {
        indices: indices || [],
        gainers: movers?.gainers || [],
        losers: movers?.losers || [],
      };
    } catch (error) {
      console.error('❌ Yahoo collectAll error:', error.message);
      return {
        indices: [],
        gainers: [],
        losers: [],
      };
    }
  }
}

export function createYahooCollector() {
  return new YahooFinanceCollector();
}

export { MARKET_INDICES, WATCHED_STOCKS };