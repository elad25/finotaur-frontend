// ==========================================
// Market Data Collector - Type Declarations
// ==========================================

export interface MarketIndex {
  symbol: string;
  name: string;
  price?: number;
  change?: number;
  changePercent?: number;
  previousClose?: number;
  high?: number;
  low?: number;
}

export interface SectorPerformance {
  symbol: string;
  name: string;
  price?: number;
  change?: number;
  changePercent?: number;
}

export interface TopMover {
  symbol: string;
  price?: number;
  change?: number;
  changePercent?: number;
}

export interface GlobalMarkets {
  asia: MarketIndex[];
  europe: MarketIndex[];
}

export interface CryptoPrice {
  symbol: string;
  name: string;
  price?: number;
  changePercent24h?: number;
}

export interface ForexRate {
  pair: string;
  name: string;
  rate?: number;
  changePercent?: number;
}

export interface Commodity {
  name: string;
  price?: number;
  changePercent?: number;
}

export interface NewsItem {
  headline: string;
  summary: string;
  source: string;
  url: string;
  datetime: string;
  related: string[];
}

export interface VolatilityData {
  vix: number;
  vixChange: number;
  vixChangePercent: number;
  putCallRatio: number;
  vixTerm: string;
}

export interface MarketDataCollectorConfig {
  finnhubApiKey?: string;
  fredApiKey?: string;
}

export interface CollectedMarketData {
  marketIndices: MarketIndex[];
  sectorPerformance: SectorPerformance[];
  topGainers: TopMover[];
  topLosers: TopMover[];
  globalMarkets: GlobalMarkets;
  crypto: CryptoPrice[];
  forex: ForexRate[];
  commodities: Commodity[];
  news: NewsItem[];
  volatility: VolatilityData;
  analystRatings: any[];
  earningsToday: any[];
  economicCalendar: any[];
  premarketMovers: any[];
  unusualOptions: any[];
  shortInterest: any[];
  sectorFlow: any[];
  optionsMetrics: Record<string, any>;
  timestamp: string;
  collectionDuration: number;
}

export interface QuickCollectedData {
  marketIndices: MarketIndex[];
  analystRatings: any[];
  earningsToday: any[];
  economicCalendar: any[];
  unusualOptions: any[];
  timestamp: string;
}

export declare class MarketDataCollector {
  constructor(config?: MarketDataCollectorConfig);
  
  finnhubKey: string;
  fredKey: string;
  analystCollector: any;
  optionsCollector: any;
  
  fetchYahooQuote(symbol: string): Promise<{
    symbol: string;
    price: number;
    change: number;
    changePercent: number;
    previousClose: number;
    volume: number;
    high: number;
    low: number;
    open: number;
  } | null>;
  
  fetchMarketIndices(): Promise<MarketIndex[]>;
  fetchSectorPerformance(): Promise<SectorPerformance[]>;
  fetchTopMovers(): Promise<{ gainers: TopMover[]; losers: TopMover[] }>;
  fetchGlobalMarkets(): Promise<GlobalMarkets>;
  fetchCrypto(): Promise<CryptoPrice[]>;
  fetchForex(): Promise<ForexRate[]>;
  fetchCommodities(): Promise<Commodity[]>;
  fetchNews(): Promise<NewsItem[]>;
  getVolatilityData(marketIndices?: MarketIndex[]): Promise<VolatilityData>;
  collectAll(): Promise<CollectedMarketData>;
  collectQuick(): Promise<QuickCollectedData>;
}

export declare function createMarketDataCollector(config?: MarketDataCollectorConfig): MarketDataCollector;

// These may be in separate files - add stubs
export declare function createFredCollector(config?: any): any;
export declare function createFinnhubCollector(config?: any): any;
export declare function createYahooCollector(config?: any): any;