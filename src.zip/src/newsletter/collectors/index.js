// ==========================================
// Market Data Collector - Main Orchestrator
// Version 2.0 - Enhanced Data Collection
// ==========================================

import { createAnalystCollector } from './analyst.js';
import { createOptionsCollector } from './options.js';

// Yahoo Finance symbols
const MARKET_INDICES = [
  { symbol: '^GSPC', name: 'S&P 500' },
  { symbol: '^IXIC', name: 'NASDAQ Composite' },
  { symbol: '^DJI', name: 'Dow Jones' },
  { symbol: '^RUT', name: 'Russell 2000' },
  { symbol: '^VIX', name: 'VIX' },
];

const SECTOR_ETFS = [
  { symbol: 'XLK', name: 'Technology' },
  { symbol: 'XLV', name: 'Healthcare' },
  { symbol: 'XLF', name: 'Financials' },
  { symbol: 'XLY', name: 'Consumer Discretionary' },
  { symbol: 'XLC', name: 'Communication Services' },
  { symbol: 'XLI', name: 'Industrials' },
  { symbol: 'XLP', name: 'Consumer Staples' },
  { symbol: 'XLE', name: 'Energy' },
  { symbol: 'XLU', name: 'Utilities' },
  { symbol: 'XLRE', name: 'Real Estate' },
  { symbol: 'XLB', name: 'Materials' },
];

const GLOBAL_INDICES = {
  asia: [
    { symbol: '^N225', name: 'Nikkei 225' },
    { symbol: '^HSI', name: 'Hang Seng' },
    { symbol: '000001.SS', name: 'Shanghai Composite' },
    { symbol: '^KS11', name: 'KOSPI' },
    { symbol: '^AXJO', name: 'ASX 200' },
  ],
  europe: [
    { symbol: '^STOXX50E', name: 'Euro Stoxx 50' },
    { symbol: '^GDAXI', name: 'DAX' },
    { symbol: '^FTSE', name: 'FTSE 100' },
    { symbol: '^FCHI', name: 'CAC 40' },
  ],
};

export class MarketDataCollector {
  constructor(config = {}) {
    this.finnhubKey = config.finnhubApiKey || '';
    this.fredKey = config.fredApiKey || '';
    
    this.analystCollector = createAnalystCollector({
      finnhubApiKey: this.finnhubKey,
    });
    
    this.optionsCollector = createOptionsCollector();
  }

  /**
   * Fetch quote from Yahoo Finance
   */
  async fetchYahooQuote(symbol) {
    try {
      const response = await fetch(
        `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1d&range=2d`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          },
        }
      );

      if (!response.ok) return null;

      const data = await response.json();
      const result = data.chart?.result?.[0];
      
      if (!result?.meta) return null;

      const meta = result.meta;
      const quotes = result.indicators?.quote?.[0];
      const timestamps = result.timestamp || [];
      
      // Get previous close for change calculation
      let previousClose = meta.chartPreviousClose || meta.previousClose;
      let currentPrice = meta.regularMarketPrice;
      
      // If we have quote data, use the last values
      if (quotes && timestamps.length > 0) {
        const lastIdx = timestamps.length - 1;
        if (quotes.close && quotes.close[lastIdx]) {
          currentPrice = quotes.close[lastIdx];
        }
      }

      const change = currentPrice - previousClose;
      const changePercent = previousClose ? (change / previousClose) * 100 : 0;

      return {
        symbol: meta.symbol,
        price: currentPrice,
        change,
        changePercent,
        previousClose,
        volume: meta.regularMarketVolume,
        high: meta.regularMarketDayHigh,
        low: meta.regularMarketDayLow,
        open: meta.regularMarketOpen,
      };
    } catch (error) {
      console.error(`Error fetching ${symbol}:`, error.message);
      return null;
    }
  }

  /**
   * Fetch market indices
   */
  async fetchMarketIndices() {
    console.log('📊 Fetching Market Indices...');
    
    const results = [];
    
    for (const index of MARKET_INDICES) {
      const quote = await this.fetchYahooQuote(index.symbol);
      if (quote) {
        results.push({
          ...index,
          price: quote.price,
          change: quote.change,
          changePercent: quote.changePercent,
          previousClose: quote.previousClose,
          high: quote.high,
          low: quote.low,
        });
      }
      await new Promise(r => setTimeout(r, 100)); // Rate limit
    }
    
    console.log(`📊 Fetched ${results.length} indices`);
    return results;
  }

  /**
   * Fetch sector performance
   */
  async fetchSectorPerformance() {
    console.log('📈 Fetching Sector Performance...');
    
    const results = [];
    
    for (const sector of SECTOR_ETFS) {
      const quote = await this.fetchYahooQuote(sector.symbol);
      if (quote) {
        results.push({
          ...sector,
          price: quote.price,
          change: quote.change,
          changePercent: quote.changePercent,
        });
      }
      await new Promise(r => setTimeout(r, 100));
    }
    
    // Sort by performance
    results.sort((a, b) => (b.changePercent || 0) - (a.changePercent || 0));
    
    console.log(`📈 Fetched ${results.length} sectors`);
    return results;
  }

  /**
   * Fetch top movers
   */
  async fetchTopMovers() {
    console.log('🚀 Fetching Top Movers...');
    
    // Use a predefined list of active stocks
    const watchlist = [
      'NVDA', 'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'AMD',
      'CRM', 'AVGO', 'ORCL', 'NFLX', 'ADBE', 'INTC', 'MU', 'QCOM',
      'JPM', 'BAC', 'GS', 'MS', 'V', 'MA', 'PYPL',
      'UNH', 'JNJ', 'LLY', 'PFE', 'ABBV', 'MRK',
      'XOM', 'CVX', 'COP',
      'WMT', 'COST', 'TGT', 'HD', 'LOW',
    ];
    
    const quotes = [];
    
    for (const symbol of watchlist.slice(0, 25)) { // Limit to avoid rate limiting
      const quote = await this.fetchYahooQuote(symbol);
      if (quote && quote.changePercent !== undefined) {
        quotes.push({
          symbol,
          price: quote.price,
          change: quote.change,
          changePercent: quote.changePercent,
        });
      }
      await new Promise(r => setTimeout(r, 80));
    }
    
    // Sort and separate gainers/losers
    const sorted = quotes.sort((a, b) => (b.changePercent || 0) - (a.changePercent || 0));
    
    const gainers = sorted.filter(q => q.changePercent > 0).slice(0, 10);
    const losers = sorted.filter(q => q.changePercent < 0).slice(-10).reverse();
    
    console.log(`🚀 Found ${gainers.length} gainers, ${losers.length} losers`);
    
    return { gainers, losers };
  }

  /**
   * Fetch global markets
   */
  async fetchGlobalMarkets() {
    console.log('🌍 Fetching Global Markets...');
    
    const asia = [];
    const europe = [];
    
    for (const index of GLOBAL_INDICES.asia) {
      const quote = await this.fetchYahooQuote(index.symbol);
      if (quote) {
        asia.push({
          ...index,
          price: quote.price,
          changePercent: quote.changePercent,
        });
      }
      await new Promise(r => setTimeout(r, 100));
    }
    
    for (const index of GLOBAL_INDICES.europe) {
      const quote = await this.fetchYahooQuote(index.symbol);
      if (quote) {
        europe.push({
          ...index,
          price: quote.price,
          changePercent: quote.changePercent,
        });
      }
      await new Promise(r => setTimeout(r, 100));
    }
    
    console.log(`🌍 Fetched ${asia.length} Asia, ${europe.length} Europe indices`);
    
    return { asia, europe };
  }

  /**
   * Fetch crypto prices
   */
  async fetchCrypto() {
    console.log('₿ Fetching Crypto...');
    
    const cryptos = [
      { symbol: 'BTC-USD', name: 'Bitcoin' },
      { symbol: 'ETH-USD', name: 'Ethereum' },
    ];
    
    const results = [];
    
    for (const crypto of cryptos) {
      const quote = await this.fetchYahooQuote(crypto.symbol);
      if (quote) {
        results.push({
          symbol: crypto.name === 'Bitcoin' ? 'BTC' : 'ETH',
          name: crypto.name,
          price: quote.price,
          changePercent24h: quote.changePercent,
        });
      }
    }
    
    console.log(`₿ Fetched ${results.length} crypto prices`);
    return results;
  }

  /**
   * Fetch forex rates
   */
  async fetchForex() {
    console.log('💱 Fetching Forex...');
    
    const pairs = [
      { symbol: 'DX-Y.NYB', pair: 'DXY', name: 'Dollar Index' },
      { symbol: 'EURUSD=X', pair: 'EUR/USD', name: 'Euro' },
      { symbol: 'USDJPY=X', pair: 'USD/JPY', name: 'Japanese Yen' },
      { symbol: 'GBPUSD=X', pair: 'GBP/USD', name: 'British Pound' },
    ];
    
    const results = [];
    
    for (const fx of pairs) {
      const quote = await this.fetchYahooQuote(fx.symbol);
      if (quote) {
        results.push({
          pair: fx.pair,
          name: fx.name,
          rate: quote.price,
          changePercent: quote.changePercent,
        });
      }
      await new Promise(r => setTimeout(r, 100));
    }
    
    console.log(`💱 Fetched ${results.length} forex pairs`);
    return results;
  }

  /**
   * Fetch commodities
   */
  async fetchCommodities() {
    console.log('🛢️ Fetching Commodities...');
    
    const commodities = [
      { symbol: 'CL=F', name: 'WTI Crude Oil' },
      { symbol: 'GC=F', name: 'Gold' },
      { symbol: 'SI=F', name: 'Silver' },
      { symbol: 'NG=F', name: 'Natural Gas' },
      { symbol: 'HG=F', name: 'Copper' },
    ];
    
    const results = [];
    
    for (const commodity of commodities) {
      const quote = await this.fetchYahooQuote(commodity.symbol);
      if (quote) {
        results.push({
          name: commodity.name,
          price: quote.price,
          changePercent: quote.changePercent,
        });
      }
      await new Promise(r => setTimeout(r, 100));
    }
    
    console.log(`🛢️ Fetched ${commodities.length} commodities`);
    return results;
  }

  /**
   * Fetch news from Finnhub
   */
  async fetchNews() {
    console.log('📰 Fetching News...');
    
    if (!this.finnhubKey) {
      console.log('📰 No Finnhub API key, skipping news');
      return [];
    }
    
    try {
      const response = await fetch(
        `https://finnhub.io/api/v1/news?category=general&token=${this.finnhubKey}`
      );
      
      if (!response.ok) return [];
      
      const data = await response.json();
      
      const news = (data || []).slice(0, 15).map(item => ({
        headline: item.headline,
        summary: item.summary,
        source: item.source,
        url: item.url,
        datetime: new Date(item.datetime * 1000).toISOString(),
        related: item.related ? item.related.split(',') : [],
      }));
      
      console.log(`📰 Fetched ${news.length} news items`);
      return news;
    } catch (error) {
      console.error('Error fetching news:', error.message);
      return [];
    }
  }

  /**
   * Get volatility data
   */
  async getVolatilityData(marketIndices) {
    const vixData = marketIndices?.find(i => i.name === 'VIX');
    
    return {
      vix: vixData?.price || 14.5,
      vixChange: vixData?.change || -0.5,
      vixChangePercent: vixData?.changePercent || -3.2,
      putCallRatio: 0.82, // Would come from options data
      vixTerm: 'Contango', // Would come from futures data
    };
  }

  /**
   * Collect all market data - FULL
   */
  async collectAll() {
    console.log('\n' + '═'.repeat(60));
    console.log('📊 STARTING FULL DATA COLLECTION');
    console.log('═'.repeat(60) + '\n');
    
    const startTime = Date.now();
    
    try {
      // Parallel fetching for efficiency
      const [
        marketIndices,
        sectorPerformance,
        movers,
        globalMarkets,
        crypto,
        forex,
        commodities,
        news,
        analystData,
        optionsData,
      ] = await Promise.all([
        this.fetchMarketIndices().catch(e => { console.error('Market indices error:', e.message); return []; }),
        this.fetchSectorPerformance().catch(e => { console.error('Sector error:', e.message); return []; }),
        this.fetchTopMovers().catch(e => { console.error('Movers error:', e.message); return { gainers: [], losers: [] }; }),
        this.fetchGlobalMarkets().catch(e => { console.error('Global error:', e.message); return { asia: [], europe: [] }; }),
        this.fetchCrypto().catch(e => { console.error('Crypto error:', e.message); return []; }),
        this.fetchForex().catch(e => { console.error('Forex error:', e.message); return []; }),
        this.fetchCommodities().catch(e => { console.error('Commodities error:', e.message); return []; }),
        this.fetchNews().catch(e => { console.error('News error:', e.message); return []; }),
        this.analystCollector.collectAll().catch(e => { console.error('Analyst error:', e.message); return {}; }),
        this.optionsCollector.collectAll().catch(e => { console.error('Options error:', e.message); return {}; }),
      ]);
      
      const volatility = await this.getVolatilityData(marketIndices);
      
      const duration = Date.now() - startTime;
      
      console.log('\n' + '═'.repeat(60));
      console.log(`✅ DATA COLLECTION COMPLETE in ${(duration / 1000).toFixed(1)}s`);
      console.log('═'.repeat(60));
      console.log(`   📊 Indices: ${marketIndices.length}`);
      console.log(`   📈 Sectors: ${sectorPerformance.length}`);
      console.log(`   🚀 Gainers: ${movers.gainers?.length || 0}`);
      console.log(`   📉 Losers: ${movers.losers?.length || 0}`);
      console.log(`   🎯 Analyst Actions: ${analystData.analystRatings?.length || 0}`);
      console.log(`   🔥 Options Activity: ${optionsData.unusualOptions?.length || 0}`);
      console.log(`   📅 Economic Events: ${analystData.economicCalendar?.length || 0}`);
      console.log(`   📰 News Items: ${news.length}`);
      console.log('═'.repeat(60) + '\n');
      
      return {
        marketIndices,
        sectorPerformance,
        topGainers: movers.gainers || [],
        topLosers: movers.losers || [],
        globalMarkets,
        crypto,
        forex,
        commodities,
        news,
        volatility,
        // Analyst collector data
        analystRatings: analystData.analystRatings || [],
        earningsToday: analystData.earningsToday || [],
        economicCalendar: analystData.economicCalendar || [],
        premarketMovers: analystData.premarketMovers || [],
        // Options collector data
        unusualOptions: optionsData.unusualOptions || [],
        shortInterest: optionsData.shortInterest || [],
        sectorFlow: optionsData.sectorFlow || [],
        optionsMetrics: optionsData.marketMetrics || {},
        // Metadata
        timestamp: new Date().toISOString(),
        collectionDuration: duration,
      };
    } catch (error) {
      console.error('❌ Data collection failed:', error);
      throw error;
    }
  }

  /**
   * Quick collection for preview
   */
  async collectQuick() {
    console.log('⚡ Quick data collection...');
    
    const [marketIndices, analystData, optionsData] = await Promise.all([
      this.fetchMarketIndices().catch(() => []),
      this.analystCollector.collectAll().catch(() => ({})),
      this.optionsCollector.collectAll().catch(() => ({})),
    ]);
    
    return {
      marketIndices,
      analystRatings: analystData.analystRatings || [],
      earningsToday: analystData.earningsToday || [],
      economicCalendar: analystData.economicCalendar || [],
      unusualOptions: optionsData.unusualOptions || [],
      timestamp: new Date().toISOString(),
    };
  }
}

export function createMarketDataCollector(config) {
  return new MarketDataCollector(config);
}