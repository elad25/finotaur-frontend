// ==========================================
// PDF Generator v25.0 - IMPROVED PAGE BREAKS
// ==========================================
// Improvements:
// - 60% rule strictly enforced
// - Section headers NEVER start at page bottom
// - Text never overflows margins
// - Proper orphan/widow control
// ==========================================

import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';

// ============ COLORS ============
const COLORS = {
  gold: '#C9A646',
  black: '#000000',
  darkText: '#1A1A1A',
  mediumGray: '#555555',
  lightGray: '#888888',
  veryLightGray: '#CCCCCC',
  ultraLightGray: '#EEEEEE',
  white: '#FFFFFF',
  green: '#16A34A',
  red: '#DC2626',
};

// ============ TYPOGRAPHY ============
const FONT_DIR = path.join(process.cwd(), 'static', 'fonts');
const INTER_REGULAR = path.join(FONT_DIR, 'Inter_18pt-Regular.ttf');
const INTER_BOLD = path.join(FONT_DIR, 'Inter_18pt-Bold.ttf');

const hasInterFont = fs.existsSync(INTER_REGULAR) && fs.existsSync(INTER_BOLD);

const FONTS = {
  title: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  heading: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  body: hasInterFont ? 'Inter-Regular' : 'Helvetica',
  bold: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
};

function registerFonts(doc) {
  if (hasInterFont) {
    doc.registerFont('Inter-Regular', INTER_REGULAR);
    doc.registerFont('Inter-Bold', INTER_BOLD);
    console.log('[PDF] Using Inter font');
  } else {
    console.log('[PDF] Inter font not found at', FONT_DIR);
  }
}

const SIZES = {
  coverTitle: 32,
  coverDate: 14,
  coverTagline: 11,
  sectionTitle: 16,
  subSection: 12,
  stockTicker: 13,
  body: 11,
  small: 10,
  footer: 8,
};

// ============ PAGE LAYOUT ============
const PAGE = {
  width: 612,
  height: 792,
  marginLeft: 50,
  marginRight: 50,
  marginTop: 60,
  marginBottom: 50,
  
  get contentWidth() { return this.width - this.marginLeft - this.marginRight; },
  get contentTop() { return this.marginTop + 25; },
  get footerY() { return this.height - 30; },
  get contentBottom() { return this.footerY - 25; }, // Actual bottom of content area
  get safeBottom() { return this.footerY - 40; }, // Safe zone before footer
  get contentHeight() { return this.contentBottom - this.contentTop; },
  // 60% threshold - after this point, start new section on new page
  get threshold60() { return this.contentTop + (this.contentHeight * 0.60); },
  // Minimum space needed for a section header + some content
  get minSectionSpace() { return 80; }, // At least 80px for header + first paragraph
  // Minimum space needed before starting new content
  get minContentSpace() { return 40; },
};

// ============ SECTION CONFIGURATION ============
const SECTION_CONFIG = {
  'what-changed': { 
    title: 'MARKET EVENTS', 
    subtitle: 'What Moved the Market',
    altIds: ['what-changed-today', 'market-pulse'],
  },
  'market-focus': { 
    title: "TODAY'S FOCUS", 
    subtitle: 'Key Themes',
    altIds: ['story-spine', 'market-map'],
  },
  'top-insights': { 
    title: 'TOP 3 INSIGHTS', 
    subtitle: 'Key Themes Today',
    altIds: ['top-3-insights', 'top-3', 'top-insights'],
  },
  'macro': { 
    title: 'MACRO ARENA', 
    subtitle: 'Rates, Curve & Fed',
    altIds: ['macro-arena'],
  },
  'market-structure': { 
    title: 'MARKET STRUCTURE', 
    subtitle: 'CTA, Gamma & Positioning',
    altIds: ['market-structure', 'structure', 'cta-levels', 'dealer-gamma', 'positioning-data'],
  },
  'cross-asset': { 
    title: 'CROSS-ASSET', 
    subtitle: 'Intermarket Analysis',
    altIds: ['cross-asset', 'gold-dxy', 'correlations', 'intermarket'],
  },
  'sector': { 
    title: 'SECTOR ROTATION', 
    subtitle: 'Where Money Flows',
    altIds: ['sector-rotation'],
  },
  'analyst': { 
    title: 'ANALYST ARENA', 
    subtitle: 'Rating Changes',
    altIds: ['analyst-arena', 'analyst-actions', 'rating-changes', 'upgrades-downgrades'],
  },
  'news': { 
    title: 'NEWS & CATALYSTS', 
    subtitle: 'Headlines & Events',
    altIds: ['news-and-catalysts', 'news-catalysts', 'earnings-watch'],
  },
  'earnings': { 
    title: 'EARNINGS REPORTS', 
    subtitle: 'Results & Reactions',
    altIds: ['featured-earnings', 'earnings-calendar'],
  },
  'options': { 
    title: 'OPTIONS FLOW', 
    subtitle: 'Smart Money Read',
   altIds: ['options-flow', 'optionsFlow'],
  },
  'liquidity': { 
    title: 'LIQUIDITY MAP', 
    subtitle: 'Where The Stops Are',
    altIds: ['liquidity-map', 'liquidity-zones', 'where-the-stops-are'],
  },
  'tactical': { 
    title: 'TACTICAL CORNER', 
    subtitle: 'Key Levels & Setups',
    altIds: ['tactical', 'tactical-corner', 'technical-levels', 'support-resistance', 'levels'],
  },
  'scenario-matrix': { 
    title: 'SCENARIO MATRIX', 
    subtitle: 'Bull / Base / Bear',
    altIds: ['scenario-matrix', 'scenarios', 'bull-bear', 'scenario'],
  },
  'ideas': { 
    title: 'IDEAS & TAKEAWAYS', 
    subtitle: 'Trade Opportunities',
    altIds: ['ideas-and-takeaways', 'trade-ideas', 'ideas'],
  },
  'desk-view': { 
    title: 'THE DESK VIEW', 
    subtitle: 'Final Positioning',
    altIds: ['the-desk-view', 'desk-view', 'final-view'],
  },
  'focus': { 
    title: 'FOCUS ZONE', 
    subtitle: 'What to Watch',
    altIds: ['focus-zone'],
  },
  'bottom-line': { 
    title: 'BOTTOM LINE', 
    subtitle: "Trader's Take",
    altIds: ['bottom-line'],
  },
};

const SECTION_ORDER = Object.keys(SECTION_CONFIG);
const COPYRIGHT = '© 2025 FINOTAUR';

// Known tickers
const KNOWN_TICKERS = [
  'AAPL', 'MSFT', 'GOOGL', 'GOOG', 'AMZN', 'NVDA', 'META', 'TSLA',
  'JPM', 'V', 'JNJ', 'WMT', 'PG', 'MA', 'HD', 'CVX', 'MRK', 'ABBV',
  'COST', 'AVGO', 'KO', 'PEP', 'TMO', 'MCD', 'CSCO', 'ACN', 'ABT',
  'SMCI', 'COIN', 'NOW', 'MRVL', 'MSTR', 'AI', 'AMD', 'INTC', 'QCOM',
  'SPY', 'QQQ', 'IWM', 'XLF', 'XLE', 'XLK', 'XLV', 'XLI', 'XLC',
  'VIX', 'SPX', 'DXY', 'GLD', 'TLT'
];

// ============ HELPER: Check if we need a page break ============
function needsPageBreak(currentY, requiredSpace) {
  return currentY + requiredSpace > PAGE.safeBottom;
}

// ============ HELPER: Check if past 60% threshold for new section ============
function pastThresholdForNewSection(currentY) {
  return currentY > PAGE.threshold60;
}

// ============ HELPER: Calculate text height ============
function getTextHeight(doc, text, options = {}) {
  const width = options.width || PAGE.contentWidth;
  return doc.heightOfString(text, { width, ...options });
}

// ============ HELPER: Estimate section header height ============
function getSectionHeaderHeight(doc, section) {
  // Title + underline + subtitle + padding
  doc.font(FONTS.bold).fontSize(SIZES.sectionTitle);
  const titleHeight = 17 + 8; // title + underline gap
  const subtitleHeight = section.subtitle ? 16 : 0;
  return titleHeight + subtitleHeight + 10; // Extra padding
}

// ============ MAIN EXPORT ============
export async function generateNewsletterPDFBufferWithCharts(newsletter, chartData = null) {
  return new Promise((resolve, reject) => {
    try {
      const reportDate = newsletter.reportDate || new Date().toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      const reportMode = newsletter.reportMode || 'DAILY';
      const sections = newsletter.sections || [];

      console.log(`[PDF v25] Starting - IMPROVED PAGE BREAKS`);

      const organizedSections = organizeSections(sections);
      const validSections = [];
      
      for (const sectionId of SECTION_ORDER) {
        const config = SECTION_CONFIG[sectionId];
        const content = organizedSections[sectionId];
        if (content && content.trim().length >= 20) {
          validSections.push({
            id: sectionId,
            ...config,
            content: content.trim(),
          });
        }
      }

      console.log(`[PDF v25] Processing ${validSections.length} sections`);

      const doc = new PDFDocument({
        size: 'letter',
        margin: 0,
        autoFirstPage: false,
        info: {
          Title: `Finotaur ${reportMode} Report - ${reportDate}`,
          Author: 'Finotaur',
          Subject: 'Institutional Market Intelligence',
          Creator: 'Finotaur v25.0',
        },
      });

      registerFonts(doc);

      const chunks = [];
      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(chunks);
        console.log(`[PDF v25] Complete: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      let currentPageNumber = 0;
      
      const addContentPage = () => {
        doc.addPage();
        currentPageNumber++;
        drawPageHeader(doc, reportDate);
        return PAGE.contentTop;
      };

      const drawFooter = (pageNum) => {
        doc.strokeColor(COLORS.veryLightGray)
           .lineWidth(0.3)
           .moveTo(PAGE.marginLeft, PAGE.footerY - 8)
           .lineTo(PAGE.width - PAGE.marginRight, PAGE.footerY - 8)
           .stroke();

        doc.font(FONTS.body).fontSize(SIZES.footer).fillColor(COLORS.lightGray);
        doc.text(COPYRIGHT, PAGE.marginLeft, PAGE.footerY, { lineBreak: false });
        doc.text('For educational purposes only. Not investment advice.', 
          PAGE.width / 2 - 100, PAGE.footerY, { width: 200, align: 'center', lineBreak: false });
        doc.text(`${pageNum}`, PAGE.width - PAGE.marginRight - 20, PAGE.footerY, { 
          width: 20, align: 'right', lineBreak: false 
        });
      };

      // ========== COVER PAGE ==========
      doc.addPage();
      const logoData = newsletter.logoBuffer || newsletter.logoBase64 || newsletter.logoPath || null;
      drawCoverPage(doc, reportDate, reportMode, logoData);

// ========== CONTENT PAGES ==========
      let currentY = addContentPage();
      let contentPageNum = 1;

      // Add header disclaimer on first content page
      currentY = addHeaderDisclaimer(doc, currentY);

      for (let i = 0; i < validSections.length; i++) {
        const section = validSections[i];
        const headerHeight = getSectionHeaderHeight(doc, section);
        
        // RULE: If we're past 60% OR not enough space for header + min content, start new page
        if (pastThresholdForNewSection(currentY) || 
            needsPageBreak(currentY, headerHeight + PAGE.minSectionSpace)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }

        const newPageCallback = () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        };

        if (section.id === 'bottom-line') {
          currentY = drawBottomLine(doc, section, currentY, newPageCallback);
        } else if (section.id === 'analyst' || section.id === 'news') {
          currentY = drawStockSection(doc, section, currentY, newPageCallback);
} else if (section.id === 'options') {
          currentY = drawOptionsSection(doc, section, currentY, newPageCallback);
        } else if (section.id === 'liquidity') {
          currentY = drawLiquiditySection(doc, section, currentY, newPageCallback);
        } else {
          currentY = drawSection(doc, section, currentY, newPageCallback);
        }

        currentY += 25;
      }

drawFooter(contentPageNum);
      
      // Add full disclaimer section at the end
      generateDisclaimerSection(doc);
      
      console.log(`[PDF v25] Generated: 1 cover + ${contentPageNum} content pages + disclaimer`);
      doc.end();

    } catch (error) {
      console.error('[PDF v25] Error:', error);
      reject(error);
    }
  });
}

// ============ ORGANIZE SECTIONS ============
function organizeSections(sections) {
  const organized = {};

  for (const sectionId of SECTION_ORDER) {
    const config = SECTION_CONFIG[sectionId];
    for (const section of sections) {
      const inputId = section.id || section.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-') || '';
      
      if (inputId === sectionId || 
          config.altIds.some((alt) => inputId.includes(alt) || inputId === alt)) {
        if (!organized[sectionId]) {
          organized[sectionId] = '';
        }
        organized[sectionId] += '\n' + (section.content || '');
      }
    }
  }

  return organized;
}

// ============ COVER PAGE ============
function drawCoverPage(doc, reportDate, reportMode, logoData) {
  const centerX = PAGE.width / 2;
  const isWeekly = reportMode === 'WEEKLY';

  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  doc.rect(0, 0, PAGE.width, 4).fill(COLORS.gold);

  const logoY = 180;
  let logoLoaded = false;
  
  if (logoData) {
    try {
      if (Buffer.isBuffer(logoData)) {
        doc.image(logoData, centerX - 120, logoY, { width: 240 });
        logoLoaded = true;
      } else if (typeof logoData === 'string') {
        if (logoData.startsWith('data:image')) {
          const base64Data = logoData.split(',')[1];
          const buffer = Buffer.from(base64Data, 'base64');
          doc.image(buffer, centerX - 120, logoY, { width: 240 });
          logoLoaded = true;
        } else if (fs.existsSync(logoData)) {
          doc.image(logoData, centerX - 120, logoY, { width: 240 });
          logoLoaded = true;
        }
      }
    } catch (e) {
      console.log('[PDF] Logo load failed:', e.message);
      logoLoaded = false;
    }
  }
  
  if (!logoLoaded) {
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(36)
       .text('FINOTAUR', 0, logoY + 100, { align: 'center', width: PAGE.width });
  }

  const titleY = logoY + 300;
  
  doc.fillColor(COLORS.white)
     .font(FONTS.title)
     .fontSize(SIZES.coverTitle)
     .text(isWeekly ? 'WEEKLY MARKET REPORT' : 'DAILY MARKET REPORT', 0, titleY, { 
       align: 'center', width: PAGE.width 
     });

  doc.strokeColor(COLORS.gold)
     .lineWidth(2)
     .moveTo(centerX - 140, titleY + 45)
     .lineTo(centerX + 140, titleY + 45)
     .stroke();

  doc.fillColor(COLORS.white)
     .font(FONTS.body)
     .fontSize(SIZES.coverDate)
     .text(reportDate, 0, titleY + 65, { align: 'center', width: PAGE.width });

  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.coverTagline)
     .text('Institutional-Style Market Intelligence', 0, titleY + 95, { 
       align: 'center', width: PAGE.width 
     });

  doc.rect(0, PAGE.height - 4, PAGE.width, 4).fill(COLORS.gold);

  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.footer)
     .text(COPYRIGHT, 0, PAGE.height - 25, { align: 'center', width: PAGE.width });
}

// ============ PAGE HEADER ============
function drawPageHeader(doc, reportDate) {
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(10)
     .text('FINOTAUR', PAGE.marginLeft, 30, { lineBreak: false });

  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.small)
     .text(reportDate, PAGE.width - PAGE.marginRight - 150, 30, { 
       width: 150, align: 'right', lineBreak: false 
     });

  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .moveTo(PAGE.marginLeft, 45)
     .lineTo(PAGE.width - PAGE.marginRight, 45)
     .stroke();
}
// ============ HEADER DISCLAIMER ============
function addHeaderDisclaimer(doc, y) {
  const warningBoxY = y;
  const boxHeight = 45;
  
  // Warning box background (light yellow/cream)
  doc.fillColor('#FFF8E7')
     .rect(PAGE.marginLeft, warningBoxY, PAGE.contentWidth, boxHeight)
     .fill();
  
  // Warning box border (gold)
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .rect(PAGE.marginLeft, warningBoxY, PAGE.contentWidth, boxHeight)
     .stroke();
  
  // Warning text
  doc.fillColor('#8B6914')
     .font(FONTS.bold)
     .fontSize(9)
     .text('FOR EDUCATIONAL PURPOSES ONLY - NOT INVESTMENT ADVICE', 
           PAGE.marginLeft, warningBoxY + 10, { width: PAGE.contentWidth, align: 'center' });
  
  doc.font(FONTS.body)
     .fontSize(8)
     .text('This is market commentary, not a recommendation to buy or sell any security.', 
           PAGE.marginLeft, warningBoxY + 22, { width: PAGE.contentWidth, align: 'center' });
  
  doc.text('See full disclaimer at the end of this report.', 
           PAGE.marginLeft, warningBoxY + 32, { width: PAGE.contentWidth, align: 'center' });
  
  return warningBoxY + boxHeight + 15;
}
// ============ DRAW SECTION HEADER ============
function drawSectionHeader(doc, section, startY) {
  let y = startY;

  doc.fillColor(COLORS.black)
     .font(FONTS.bold)
     .fontSize(SIZES.sectionTitle)
     .text(section.title, PAGE.marginLeft, y, { lineBreak: false });

  const titleWidth = doc.widthOfString(section.title);
  y += 17;
  doc.strokeColor(COLORS.black)
     .lineWidth(1.5)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + titleWidth, y)
     .stroke();
  y += 8;

  if (section.subtitle) {
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.subSection)
       .text(section.subtitle, PAGE.marginLeft, y, { lineBreak: false });
    y += 16;
  }

  return y;
}

// ============ DRAW REGULAR SECTION ============
function drawSection(doc, section, startY, onPageBreak) {
  let y = startY;
  
  // Special handling for SECTOR ROTATION - add chart
  if (section.id === 'sector') {
    const sectorData = parseSectorDataFromContent(section.content);
    
    if (sectorData.length >= 3) {
      // Calculate total height needed: header + chart + some text
      const headerHeight = getSectionHeaderHeight(doc, section);
      const chartHeight = sectorData.length * (14 + 3) + 50; // barHeight + barGap + margins
      const totalNeeded = headerHeight + chartHeight + 60; // Extra for text below
      
      // Check if we need a new page for the ENTIRE section
      if (needsPageBreak(y, totalNeeded) || pastThresholdForNewSection(y)) {
        if (onPageBreak) {
          y = onPageBreak();
        }
      }
      
      y = drawSectionHeader(doc, section, y);
      y = drawSectorPerformanceChart(doc, sectorData, y, onPageBreak);
      y += 10;
    } else {
      y = drawSectionHeader(doc, section, y);
    }
    
    // Then render the text content (filtered to remove the raw data lines)
    y = renderSectorContent(doc, section.content, y, onPageBreak);
  } else {
    y = drawSectionHeader(doc, section, y);
    y = renderContent(doc, section.content, y, onPageBreak);
  }
  
  return y;
}

// ============ RENDER SECTOR CONTENT (filtered) ============
function renderSectorContent(doc, content, startY, onPageBreak) {
  let y = startY;
  const lines = content.split('\n').map(l => l.trim()).filter(l => l);
  
  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = cleanText(rawLine);
    if (!line || line.length < 2 || /^[═─\-]{3,}$/.test(line)) continue;
    
    // Skip lines that contain sector performance data (already shown in chart)
    // This includes "Leaders:", "Middle:", "Laggards:" lines with sector data
    if (/^Leaders:/i.test(line) || /^Middle:/i.test(line) || /^Laggards:/i.test(line)) {
      continue;
    }
    
    // Skip "Cycle Phase:" line
    if (/^Cycle Phase:/i.test(line)) {
      continue;
    }
    
    // Skip "MAG7 Breadth:" line (we'll show this separately if needed)
    if (/^MAG7 Breadth:/i.test(line)) {
      continue;
    }
    
    // Skip lines that list MAG7 stocks with percentages (AAPL -0.15%, TSLA -0.56%...)
    if (/^[A-Z]{2,5}\s+[+-]?\d+\.?\d*%,/.test(line)) {
      continue;
    }
    
    // Skip lines that are just listing sectors with percentages
    const sectorListPattern = /^[A-Za-z\s]+\([A-Z]+\)\s*[+-]?\d+\.?\d*%/;
    if (sectorListPattern.test(line)) continue;
    
    // Check for page break
    if (needsPageBreak(y, 20)) {
      if (onPageBreak) {
        y = onPageBreak();
      } else {
        break;
      }
    }

    const isHeader = /^[A-Z][A-Z\s\-]+:?$/.test(line) && line.length < 50 && !line.includes('$');
    const isBullet = /^[•\-\*►]/.test(line);
    const isLabel = /^[A-Za-z][A-Za-z\s]+:\s*.+/.test(line) && line.length < 120;
    const isFramework = /^—\s*.+\s*—$/.test(line);

    if (isFramework) {
      y += 10;
      const text = line.replace(/^—\s*/, '').replace(/\s*—$/, '');
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(text, PAGE.marginLeft, y, { lineBreak: false });
      const w = doc.widthOfString(text);
      y += 13;
      doc.strokeColor(COLORS.veryLightGray)
         .lineWidth(0.5)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + w, y)
         .stroke();
      y += 8;
      
    } else if (isHeader) {
      if (needsPageBreak(y, 60)) {
        if (onPageBreak) y = onPageBreak();
      }
      y += 10;
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(line.replace(/:$/, ''), PAGE.marginLeft, y, { lineBreak: false });
      const w = doc.widthOfString(line.replace(/:$/, ''));
      y += 13;
      doc.strokeColor(COLORS.veryLightGray)
         .lineWidth(0.5)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + w, y)
         .stroke();
      y += 6;
      
    } else if (isLabel && !/^(Leaders|Middle|Laggards):/i.test(line)) {
      const ci = line.indexOf(':');
      const label = line.substring(0, ci).trim();
      const value = line.substring(ci + 1).trim();
      
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.bold)
         .fontSize(SIZES.small)
         .text(label + ':', PAGE.marginLeft, y, { lineBreak: false });
      
      const vc = getTextColor(value);
      
      const lw = doc.widthOfString(label + ': ');
      doc.fillColor(vc)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(value, PAGE.marginLeft + lw + 3, y, { width: PAGE.contentWidth - lw - 5 });
      const vh = doc.heightOfString(value, { width: PAGE.contentWidth - lw - 5 });
      y += Math.max(vh, 12) + 4;
      
    } else if (isBullet) {
      const bt = line.replace(/^[•\-\*►]\s*/, '');
      doc.fillColor(COLORS.gold)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('•', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .text(bt, PAGE.marginLeft + 18, y, { width: PAGE.contentWidth - 20 });
      const bh = doc.heightOfString(bt, { width: PAGE.contentWidth - 20 });
      y += bh + 4;
      
    } else {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(line, PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 2 });
      const ph = doc.heightOfString(line, { width: PAGE.contentWidth, lineGap: 2 });
      y += ph + 5;
    }
  }

  return y;
}

// ============ DRAW STOCK SECTION (ANALYST/NEWS) ============
function drawStockSection(doc, section, startY, onPageBreak) {
  let y = drawSectionHeader(doc, section, startY);

  const stockBlocks = parseStockBlocks(section.content);
  
  for (const block of stockBlocks) {
    // Estimate block height
    let estimatedHeight = 30; // Base height for any block
    if (block.type === 'stock') {
      estimatedHeight = 60 + (block.details.length * 15);
    }
    
    // Check if we need a page break
    if (needsPageBreak(y, estimatedHeight)) {
      if (onPageBreak) {
        y = onPageBreak();
      } else {
        break;
      }
    }

    if (block.type === 'stock') {
      y += 8;
      
      doc.strokeColor(COLORS.gold)
         .lineWidth(4)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft, y + 14)
         .stroke();
      
      const displayText = block.fullLine || block.ticker;
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.stockTicker)
         .text(displayText, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
      
      const headerHeight = doc.heightOfString(displayText, { width: PAGE.contentWidth - 12 });
      y += Math.max(headerHeight, 14) + 4;
      
      if (block.consensus || block.current || block.target) {
        let infoLine = '';
        if (block.consensus) infoLine += `Consensus: ${block.consensus}`;
        if (block.current) infoLine += `${infoLine ? '  |  ' : ''}Current: ${block.current}`;
        if (block.target) infoLine += `${infoLine ? '  |  ' : ''}Target: ${block.target}`;
        
        if (infoLine) {
          // Check for overflow before drawing
          if (needsPageBreak(y, 20)) {
            if (onPageBreak) y = onPageBreak();
          }
          doc.fillColor(COLORS.darkText)
             .font(FONTS.bold)
             .fontSize(SIZES.body)
             .text(infoLine, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
          y += 14;
        }
      }
      
      for (const line of block.details) {
        if (needsPageBreak(y, 20)) {
          if (onPageBreak) y = onPageBreak();
        }
        
        doc.fillColor(COLORS.mediumGray)
           .font(FONTS.body)
           .fontSize(SIZES.small)
           .text(line, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
        const h = doc.heightOfString(line, { width: PAGE.contentWidth - 12 });
        y += h + 2;
      }
      
      y += 6;
      
    } else if (block.type === 'header') {
      // Ensure header doesn't start at bottom of page
      if (needsPageBreak(y, PAGE.minSectionSpace)) {
        if (onPageBreak) y = onPageBreak();
      }
      
      y += 10;
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(block.text, PAGE.marginLeft, y, { lineBreak: false });
      
      const hw = doc.widthOfString(block.text);
      y += 13;
      doc.strokeColor(COLORS.veryLightGray)
         .lineWidth(0.5)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + hw, y)
         .stroke();
      y += 6;
      
    } else {
      if (needsPageBreak(y, 20)) {
        if (onPageBreak) y = onPageBreak();
      }
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(block.text, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      const h = doc.heightOfString(block.text, { width: PAGE.contentWidth });
      y += h + 4;
    }
  }

  return y;
}

// ============ PARSE STOCK BLOCKS ============
function parseStockBlocks(content) {
  const lines = content.split('\n').map(l => l.trim()).filter(l => l);
  const blocks = [];
  
  let i = 0;
  while (i < lines.length) {
    const line = cleanText(lines[i]);
    if (!line || line.length < 2 || /^[═─\-]{3,}$/.test(line)) {
      i++;
      continue;
    }

    const ticker = extractTicker(line);
    
    if (ticker) {
      const stockBlock = {
        type: 'stock',
        ticker: ticker,
        fullLine: line,
        consensus: null,
        current: null,
        target: null,
        details: []
      };
      
      const headerInfo = extractStockInfo(line);
      if (headerInfo.consensus) stockBlock.consensus = headerInfo.consensus;
      
      i++;
      
      while (i < lines.length) {
        const nextLine = cleanText(lines[i]);
        if (!nextLine || nextLine.length < 2) {
          i++;
          continue;
        }
        if (/^[═─\-]{3,}$/.test(nextLine)) {
          i++;
          continue;
        }
        
        if (extractTicker(nextLine)) {
          break;
        }
        
        if (isSubHeader(nextLine)) {
          break;
        }
        
        const priceMatch = nextLine.match(/Current\s+\$?([\d.,]+).*?Target\s+\$?([\d.,]+)\s*\(([^)]+)\)/i);
        if (priceMatch) {
          stockBlock.current = '$' + priceMatch[1];
          stockBlock.target = '$' + priceMatch[2] + ' (' + priceMatch[3] + ')';
          i++;
          continue;
        }
        
        const consensusMatch = nextLine.match(/Consensus:\s*(.*)/i);
        if (consensusMatch) {
          stockBlock.consensus = consensusMatch[1].trim();
          i++;
          continue;
        }
        
        if (/^(Thesis|Note|Trade|What|Event|Bias|Aggressive|Speculative):/i.test(nextLine)) {
          stockBlock.details.push(nextLine);
          i++;
          continue;
        }
        
        if (nextLine.length > 15 && nextLine.length < 200 && /[a-z]/.test(nextLine)) {
          if (!extractTicker(nextLine)) {
            stockBlock.details.push(nextLine);
          }
        }
        
        i++;
      }
      
      blocks.push(stockBlock);
      continue;
    }
    
    if (isSubHeader(line)) {
      blocks.push({ type: 'header', text: line.replace(/:$/, '') });
      i++;
      continue;
    }
    
    blocks.push({ type: 'text', text: line });
    i++;
  }
  
  return blocks;
}

// ============ EXTRACT TICKER ============
function extractTicker(line) {
  const dashMatch = line.match(/^([A-Z]{1,5})\s*[—\-–]\s*.+/);
  if (dashMatch) return dashMatch[1];
  
  const convMatch = line.match(/^CONVERGENCE:\s*([A-Z]{1,5})/i);
  if (convMatch) return convMatch[1];
  
  const tickerInParens = line.match(/\(Ticker:\s*([A-Z]{1,5})\)/i);
  if (tickerInParens) return tickerInParens[1];
  
  const standaloneMatch = line.match(/^([A-Z]{2,5})$/);
  if (standaloneMatch && KNOWN_TICKERS.includes(standaloneMatch[1])) {
    return standaloneMatch[1];
  }
  
  for (const t of KNOWN_TICKERS) {
    if (line.startsWith(t + ' ') || line.startsWith(t + ' —') || line.startsWith(t + ' -')) {
      const rest = line.substring(t.length + 1);
      if (rest.length > 5 && /[a-z]/i.test(rest) && !/^\d/.test(rest.trim())) {
        return t;
      }
    }
  }
  
  return null;
}

// ============ EXTRACT STOCK INFO FROM HEADER ============
function extractStockInfo(line) {
  const info = { consensus: null };
  
  if (/Bullish/i.test(line)) info.consensus = 'Bullish';
  else if (/Bearish/i.test(line)) info.consensus = 'Bearish';
  else if (/Neutral/i.test(line)) info.consensus = 'Neutral';
  
  return info;
}

// ============ IS SUB HEADER ============
function isSubHeader(line) {
  if (/^CONVERGENCE:/i.test(line)) return false;
  if (/\(Ticker:/i.test(line)) return false;
  
  return /^[A-Z][A-Z\s\-()0-9]+:?$/.test(line) && 
         line.length < 50 && 
         !line.includes('$') &&
         !extractTicker(line);
}

// ============ RENDER CONTENT (for non-stock sections) ============
function renderContent(doc, content, startY, onPageBreak) {
  let y = startY;
  const lines = content.split('\n').map(l => l.trim()).filter(l => l);
  
  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = cleanText(rawLine);
    if (!line || line.length < 2 || /^[═─\-]{3,}$/.test(line)) continue;
    
    // Determine line type and estimate height
    const isHeader = /^[A-Z][A-Z\s\-]+:?$/.test(line) && line.length < 50 && !line.includes('$');
    const isBullet = /^[•\-\*►]/.test(line);
    const isLabel = /^[A-Za-z][A-Za-z\s]+:\s*.+/.test(line) && line.length < 120;
    const isFramework = /^—\s*.+\s*—$/.test(line);

    // Estimate height for this line
    let estimatedHeight = 20;
    if (isHeader || isFramework) {
      estimatedHeight = 35; // Headers need more space
    }

    // For headers/frameworks, ensure there's space for content after them
    if (isHeader || isFramework) {
      // Need at least 60px for header + some content
      if (needsPageBreak(y, 60)) {
        if (onPageBreak) {
          y = onPageBreak();
        } else {
          break;
        }
      }
    } else {
      // Regular content - just check for basic overflow
      if (needsPageBreak(y, estimatedHeight)) {
        if (onPageBreak) {
          y = onPageBreak();
        } else {
          break;
        }
      }
    }

    if (isFramework) {
      y += 10;
      const text = line.replace(/^—\s*/, '').replace(/\s*—$/, '');
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(text, PAGE.marginLeft, y, { lineBreak: false });
      const w = doc.widthOfString(text);
      y += 13;
      doc.strokeColor(COLORS.veryLightGray)
         .lineWidth(0.5)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + w, y)
         .stroke();
      y += 8;
      
    } else if (isHeader) {
      y += 10;
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(line.replace(/:$/, ''), PAGE.marginLeft, y, { lineBreak: false });
      const w = doc.widthOfString(line.replace(/:$/, ''));
      y += 13;
      doc.strokeColor(COLORS.veryLightGray)
         .lineWidth(0.5)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + w, y)
         .stroke();
      y += 6;
      
    } else if (isLabel) {
      const ci = line.indexOf(':');
      const label = line.substring(0, ci).trim();
      const value = line.substring(ci + 1).trim();
      
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.bold)
         .fontSize(SIZES.small)
         .text(label + ':', PAGE.marginLeft, y, { lineBreak: false });
      
      const vc = getTextColor(value);
      
      const lw = doc.widthOfString(label + ': ');
      doc.fillColor(vc)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(value, PAGE.marginLeft + lw + 3, y, { width: PAGE.contentWidth - lw - 5 });
      const vh = doc.heightOfString(value, { width: PAGE.contentWidth - lw - 5 });
      y += Math.max(vh, 12) + 4;
      
    } else if (isBullet) {
      const bt = line.replace(/^[•\-\*►]\s*/, '');
      doc.fillColor(COLORS.gold)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('•', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .text(bt, PAGE.marginLeft + 18, y, { width: PAGE.contentWidth - 20 });
      const bh = doc.heightOfString(bt, { width: PAGE.contentWidth - 20 });
      y += bh + 4;
      
    } else {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(line, PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 2 });
      const ph = doc.heightOfString(line, { width: PAGE.contentWidth, lineGap: 2 });
      y += ph + 5;
    }
  }

  return y;
}

// ============ DRAW OPTIONS SECTION ============
// ============ DRAW OPTIONS SECTION ============
function drawOptionsSection(doc, section, startY, onPageBreak) {
  let y = drawSectionHeader(doc, section, startY);

  const lines = section.content.split('\n').map(l => l.trim()).filter(l => l);
  
  for (let i = 0; i < lines.length; i++) {
    const line = cleanText(lines[i]);
    if (!line || line.length < 2 || /^[═─\-]{3,}$/.test(line)) continue;
    
    // Page break check
    if (needsPageBreak(y, 30)) {
      if (onPageBreak) {
        y = onPageBreak();
      } else {
        break;
      }
    }

    // Detect line types for narrative format
    const isVerdictLine = /^(BULLISH|BEARISH|NEUTRAL|SLIGHT)/i.test(line);
    const isTradeNumberLine = /^\[\d+\]\s+[A-Z]{1,5}\s*[—\-–]/i.test(line);
    const isExpLine = /^Exp\s+\$?\d+/i.test(line);
    const isExecLine = /^Exec:/i.test(line);
    const isReadLine = /^→/i.test(line);
    const isTableHeader = /^(Premium|Share|Blocks|CALLS|PUTS)/i.test(line);
    const isSectionHeader = /^(TODAY'?S VERDICT|TOP TRADES|FLOW BREAKDOWN|NEW POSITIONS|STRIKE WALLS|BOTTOM LINE)/i.test(line);
    const isSubHeaderLine = /^[A-Z][A-Z\s\-]+:?$/.test(line) && line.length < 50 && !line.includes('$') && !isSectionHeader;
    const isLabelValue = /^[A-Za-z][A-Za-z\s\/]+:\s*.+/.test(line) && line.length < 120;
    const isBullet = /^[•\-\*►]/.test(line);
    const isFlowLine = isOptionsFlowLine(line);

    // Section headers (TODAY'S VERDICT, TOP TRADES, etc.)
    if (isSectionHeader) {
      if (needsPageBreak(y, 60)) {
        if (onPageBreak) y = onPageBreak();
      }
      y += 12;
      const headerText = line.replace(/:$/, '');
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(headerText, PAGE.marginLeft, y, { lineBreak: false });
      
      const hw = doc.widthOfString(headerText);
      y += 13;
      doc.strokeColor(COLORS.gold)
         .lineWidth(1)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + hw, y)
         .stroke();
      y += 8;
      
    // Verdict line (🟢 BULLISH | $45.2M Premium | 12 Blocks)
    } else if (isVerdictLine) {
      y += 4;
      doc.strokeColor(COLORS.gold)
         .lineWidth(4)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft, y + 16)
         .stroke();
      
      // Determine color based on verdict
      let verdictColor = COLORS.black;
      if (/BULLISH/i.test(line)) verdictColor = COLORS.green;
      else if (/BEARISH/i.test(line)) verdictColor = COLORS.red;
      
      doc.fillColor(verdictColor)
         .font(FONTS.bold)
         .fontSize(SIZES.body + 2)
         .text(line, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
      
      const lineHeight = doc.heightOfString(line, { width: PAGE.contentWidth - 12 });
      y += Math.max(lineHeight, 16) + 6;
      
    // Trade number lines ([1] NVDA — $2.3M CALL BUY)
    } else if (isTradeNumberLine) {
      y += 6;
      doc.strokeColor(COLORS.gold)
         .lineWidth(3)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft, y + 14)
         .stroke();
      
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.body + 1)
         .text(line, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
      
      const lineHeight = doc.heightOfString(line, { width: PAGE.contentWidth - 12 });
      y += Math.max(lineHeight, 14) + 2;
      
    // Exp/DTE/OTM line
    } else if (isExpLine) {
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text('    ' + line, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 20 });
      y += 12;
      
    // Exec line
    } else if (isExecLine) {
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text('    ' + line, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 20 });
      y += 12;
      
    // Read/Analysis line (→ Major institutional...)
    } else if (isReadLine) {
      const readText = line.replace(/^→\s*/, '');
      doc.fillColor(COLORS.gold)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('→', PAGE.marginLeft + 10, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(readText, PAGE.marginLeft + 25, y, { width: PAGE.contentWidth - 30 });
      const rh = doc.heightOfString(readText, { width: PAGE.contentWidth - 30 });
      y += rh + 6;
      
    // Table-style rows (Premium:, Share:, Blocks:)
    } else if (isTableHeader || /^(CALLS|PUTS)\s+/i.test(line)) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text(line, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      y += 14;
      
    // Regular sub-headers
    } else if (isSubHeaderLine) {
      if (needsPageBreak(y, 60)) {
        if (onPageBreak) y = onPageBreak();
      }
      y += 10;
      const headerText = line.replace(/:$/, '');
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection)
         .text(headerText, PAGE.marginLeft, y, { lineBreak: false });
      
      const hw = doc.widthOfString(headerText);
      y += 13;
      doc.strokeColor(COLORS.veryLightGray)
         .lineWidth(0.5)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + hw, y)
         .stroke();
      y += 6;
      
    // Label: Value pairs
    } else if (isLabelValue) {
      const ci = line.indexOf(':');
      const label = line.substring(0, ci).trim();
      const value = line.substring(ci + 1).trim();
      
      const isKeyMetric = /^(Put\/Call|Tradable Signal|Key Level|Timeframe|Invalidates|P\/C Ratio)/i.test(label);
      
      if (isKeyMetric) {
        doc.strokeColor(COLORS.gold)
           .lineWidth(3)
           .moveTo(PAGE.marginLeft, y)
           .lineTo(PAGE.marginLeft, y + 12)
           .stroke();
      }
      
      const xOffset = isKeyMetric ? 10 : 0;
      
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.bold)
         .fontSize(SIZES.small)
         .text(label + ':', PAGE.marginLeft + xOffset, y, { lineBreak: false });
      
      const vc = getTextColor(value);
      
      const lw = doc.widthOfString(label + ': ');
      doc.fillColor(vc)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(value, PAGE.marginLeft + xOffset + lw + 3, y, { width: PAGE.contentWidth - lw - xOffset - 5 });
      
      const vh = doc.heightOfString(value, { width: PAGE.contentWidth - lw - xOffset - 5 });
      y += Math.max(vh, 12) + 4;
      
    // Legacy flow lines
    } else if (isFlowLine) {
      y += 6;
      
      doc.strokeColor(COLORS.gold)
         .lineWidth(4)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft, y + 14)
         .stroke();
      
      doc.fillColor(COLORS.black)
         .font(FONTS.bold)
         .fontSize(SIZES.body + 1)
         .text(line, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
      
      const lineHeight = doc.heightOfString(line, { width: PAGE.contentWidth - 12 });
      y += Math.max(lineHeight, 14) + 4;
      
    // Bullets
    } else if (isBullet) {
      const bt = line.replace(/^[•\-\*►]\s*/, '');
      doc.fillColor(COLORS.gold)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('•', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .text(bt, PAGE.marginLeft + 18, y, { width: PAGE.contentWidth - 20 });
      const bh = doc.heightOfString(bt, { width: PAGE.contentWidth - 20 });
      y += bh + 4;
      
    // Regular text
    } else {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(line, PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 2 });
      const ph = doc.heightOfString(line, { width: PAGE.contentWidth, lineGap: 2 });
      y += ph + 5;
    }
  }

  return y;
}

// ============ DRAW LIQUIDITY MAP SECTION ============
function drawLiquiditySection(doc, section, startY, onPageBreak) {
  let y = drawSectionHeader(doc, section, startY);

  const lines = section.content.split('\n').map(l => l.trim()).filter(l => l);
  
  for (let i = 0; i < lines.length; i++) {
    const line = cleanText(lines[i]);
    if (!line || line.length < 2 || /^[═─\-]{3,}$/.test(line)) continue;
    
    if (needsPageBreak(y, 30)) {
      if (onPageBreak) y = onPageBreak();
      else break;
    }

    const isZoneLine = /^→/.test(line);
    const isSubHeaderLine = /^(ABOVE PRICE|BELOW PRICE|SESSION CONTEXT|THE SWEEP SETUP|WHERE THE STOPS ARE)/i.test(line);

    if (isZoneLine) {
      y += 4;
      doc.strokeColor(COLORS.gold).lineWidth(4)
         .moveTo(PAGE.marginLeft, y).lineTo(PAGE.marginLeft, y + 14).stroke();
      
      const zoneText = line.replace(/^→\s*/, '');
      const isEQH = /EQH/i.test(zoneText);
      const isEQL = /EQL/i.test(zoneText);
      const textColor = isEQH ? COLORS.green : isEQL ? COLORS.red : COLORS.black;
      
      doc.fillColor(textColor).font(FONTS.bold).fontSize(SIZES.body)
         .text(zoneText, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 12 });
      y += doc.heightOfString(zoneText, { width: PAGE.contentWidth - 12 }) + 2;
      
    } else if (isSubHeaderLine) {
      if (needsPageBreak(y, 60)) { if (onPageBreak) y = onPageBreak(); }
      y += 12;
      let headerColor = COLORS.black;
      if (/ABOVE/i.test(line)) headerColor = COLORS.green;
      else if (/BELOW/i.test(line)) headerColor = COLORS.red;
      
      doc.fillColor(headerColor).font(FONTS.bold).fontSize(SIZES.subSection)
         .text(line, PAGE.marginLeft, y, { lineBreak: false });
      const hw = doc.widthOfString(line);
      y += 13;
      doc.strokeColor(headerColor === COLORS.black ? COLORS.veryLightGray : headerColor)
         .lineWidth(0.5).moveTo(PAGE.marginLeft, y).lineTo(PAGE.marginLeft + hw, y).stroke();
      y += 6;
      
    } else {
      doc.fillColor(COLORS.darkText).font(FONTS.body).fontSize(SIZES.body)
         .text(line, PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 2 });
      y += doc.heightOfString(line, { width: PAGE.contentWidth, lineGap: 2 }) + 5;
    }
  }
  return y;
}
// ============ CHECK IF OPTIONS FLOW LINE ============
function isOptionsFlowLine(line) {
  const patterns = [
    /^[A-Z]{1,5}\s+\d+(\.\d+)?[CP]\s*[—\-–]/i,
    /^[A-Z]{1,5}\s+\d+(\.\d+)?[CP]\s+.*premium/i,
    /^[A-Z]{1,5}\s+.*\d+[CP]\s+strike/i,
    /^[A-Z]{1,5}\s+is seeing.*call|put/i,
    /^[A-Z]{1,5}\s+.*contracts.*strike/i,
    // New narrative format patterns
    /^\[\d+\]\s+[A-Z]{1,5}\s*[—\-–]/i,  // [1] NVDA — $2.3M CALL BUY
    /^Exp\s+\$?\d+/i,                     // Exp $150 | DTE: 14
  ];
  
  return patterns.some(p => p.test(line));
}

// ============ BOTTOM LINE SECTION ============
function drawBottomLine(doc, section, startY, onPageBreak) {
  let y = startY;

  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + 60, y)
     .stroke();

  y += 12;

  doc.fillColor(COLORS.black)
     .font(FONTS.bold)
     .fontSize(SIZES.sectionTitle + 2)
     .text(section.title, PAGE.marginLeft, y, { lineBreak: false });

  const tw = doc.widthOfString(section.title);
  y += 19;
  doc.strokeColor(COLORS.black)
     .lineWidth(1.5)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + tw, y)
     .stroke();

  y += 8;

  doc.fillColor(COLORS.mediumGray)
     .font(FONTS.body)
     .fontSize(SIZES.subSection)
     .text(section.subtitle, PAGE.marginLeft, y, { lineBreak: false });

  y += 18;

  const lines = section.content.split('\n').map(l => l.trim()).filter(l => l);
  
  for (const rawLine of lines) {
    // Always check for page break before each line
    if (needsPageBreak(y, 30)) {
      if (onPageBreak) y = onPageBreak();
      else break;
    }
    
    const line = cleanText(rawLine);
    if (!line || line.length < 3 || /^[═─\-]{3,}$/.test(line)) continue;

    if (/^(Bias|Risk|Key Level|Level|View|Verdict):/i.test(line)) {
      const ci = line.indexOf(':');
      const label = line.substring(0, ci).trim();
      const value = line.substring(ci + 1).trim();
      
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.bold)
         .fontSize(SIZES.small)
         .text(label + ':', PAGE.marginLeft, y, { lineBreak: false });
      
      const lw = doc.widthOfString(label + ': ');
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(value, PAGE.marginLeft + lw + 3, y, { width: PAGE.contentWidth - lw - 5 });
      const vh = doc.heightOfString(value, { width: PAGE.contentWidth - lw - 5 });
      y += Math.max(vh, 12) + 4;
      
    } else if (/^(KEY TAKEAWAY|If You Read Nothing)/i.test(line)) {
      // Ensure KEY TAKEAWAY has space for content after it
      if (needsPageBreak(y, 50)) {
        if (onPageBreak) y = onPageBreak();
      }
      y += 8;
      doc.fillColor(COLORS.gold)
         .font(FONTS.bold)
         .fontSize(SIZES.small)
         .text('KEY TAKEAWAY', PAGE.marginLeft, y, { lineBreak: false });
      y += 14;
      
    } else if (/^[•\-\*]/.test(line)) {
      const bt = line.replace(/^[•\-\*]\s*/, '');
      doc.fillColor(COLORS.gold).text('•', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(bt, PAGE.marginLeft + 18, y, { width: PAGE.contentWidth - 20 });
      y += doc.heightOfString(bt, { width: PAGE.contentWidth - 20 }) + 4;
      
    } else {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(line, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      y += doc.heightOfString(line, { width: PAGE.contentWidth }) + 4;
    }
  }

  y += 8;
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + 60, y)
     .stroke();

  return y + 5;
}

// ============ CLEAN TEXT ============
function cleanText(text) {
  if (!text) return '';
  
  return text
    .replace(/[\u{1F300}-\u{1F9FF}]/gu, '')
    .replace(/[\u{2600}-\u{26FF}]/gu, '')
    .replace(/[\u{2700}-\u{27BF}]/gu, '')
    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
    .replace(/[\u{1F1E0}-\u{1F1FF}]/gu, '')
    .replace(/[📊📖💰🌍🌏📚🎯🏛️⬆️⬇️📅📈🔗⚡📉📌⚠️🎰💼✅❌🔥💹🏗️📡📰🔄📐🔍🔧🎨📦🏆⭐🗺️📝💡🎲📆🤖📄🟨🟦🟩🟪🔹🔴🟢🔵🟡]/g, '')
    .replace(/\*\*/g, '')
    .replace(/\#\#/g, '')
    .replace(/\#/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// ============ DRAW SECTOR PERFORMANCE CHART ============
function drawSectorPerformanceChart(doc, sectorData, startY, onPageBreak) {
  let y = startY;
  
  // Chart dimensions - COMPACT VERSION
  const chartLeft = PAGE.marginLeft;
  const chartWidth = PAGE.contentWidth;
  const barHeight = 14; // Smaller bars
  const barGap = 3; // Less gap
  const labelWidth = 130; // Space for sector names
  const valueWidth = 50; // Space for percentage values
  const barAreaWidth = chartWidth - labelWidth - valueWidth - 20;
  const barStartX = chartLeft + labelWidth + 10;
  
  // Calculate total chart height FIRST
  const chartHeight = sectorData.length * (barHeight + barGap) + 35;
  
  // Check if we have enough space for the ENTIRE chart
  if (needsPageBreak(y, chartHeight)) {
    if (onPageBreak) {
      y = onPageBreak();
    }
  }
  
  // Find max absolute value for scaling
  const maxAbsValue = Math.max(...sectorData.map(s => Math.abs(s.performance)));
  const scale = barAreaWidth / 2 / Math.max(maxAbsValue, 3); // At least 3% scale
  
  // Center line X position (0% line)
  const zeroX = barStartX + (barAreaWidth / 2);
  
  // Chart title
  doc.fillColor(COLORS.black)
     .font(FONTS.bold)
     .fontSize(SIZES.small)
     .text('1 DAY PERFORMANCE', chartLeft, y, { lineBreak: false });
  y += 15;
  
  const chartStartY = y;
  
  // Draw each sector bar
  for (let i = 0; i < sectorData.length; i++) {
    const sector = sectorData[i];
    const barY = y + (i * (barHeight + barGap));
    
    // Sector label (right-aligned)
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(9) // Smaller font
       .text(sector.name, chartLeft, barY + 2, { 
         width: labelWidth - 5, 
         align: 'right',
         lineBreak: false 
       });
    
    // Calculate bar width and position
    const barWidth = Math.abs(sector.performance) * scale;
    const isPositive = sector.performance >= 0;
    const barX = isPositive ? zeroX : zeroX - barWidth;
    const barColor = isPositive ? COLORS.green : COLORS.red;
    
    // Draw the bar
    doc.fillColor(barColor)
       .rect(barX, barY, barWidth, barHeight - 2)
       .fill();
    
    // Performance value
    const perfText = (sector.performance >= 0 ? '+' : '') + sector.performance.toFixed(2) + '%';
    
    doc.fillColor(isPositive ? COLORS.green : COLORS.red)
       .font(FONTS.bold)
       .fontSize(9) // Smaller font
       .text(perfText, barStartX + barAreaWidth + 5, barY + 2, { 
         width: valueWidth, 
         align: 'left',
         lineBreak: false 
       });
  }
  
  y += sectorData.length * (barHeight + barGap) + 10;
  
  // Draw axis line at 0%
  doc.strokeColor(COLORS.veryLightGray)
     .lineWidth(0.5)
     .moveTo(zeroX, chartStartY)
     .lineTo(zeroX, y - 10)
     .stroke();
  
  // Draw scale markers
  const scaleMarks = [1, 2, 3];
  doc.fontSize(7).fillColor(COLORS.lightGray).font(FONTS.body);
  
  for (const mark of scaleMarks) {
    const posX = zeroX + (mark * scale);
    const negX = zeroX - (mark * scale);
    
    // Positive side
    if (posX < barStartX + barAreaWidth) {
      doc.text(mark + '%', posX - 8, y - 8, { lineBreak: false });
    }
    // Negative side  
    if (negX > barStartX) {
      doc.text('-' + mark + '%', negX - 12, y - 8, { lineBreak: false });
    }
  }
  doc.text('0%', zeroX - 6, y - 8, { lineBreak: false });
  
  return y + 5;
}

// ============ PARSE SECTOR DATA FROM CONTENT ============
function parseSectorDataFromContent(content) {
  const sectors = [];
  const lines = content.split('\n');
  
  // Pattern: "Consumer Staples (XLP) +0.53%" or "Technology (XLK) -2.89%"
  // Also matches: "XLP +0.53%" or "XLK -2.89%"
  const sectorPattern = /([A-Za-z\s]+)\s*\(([A-Z]+)\)\s*([+-]?\d+\.?\d*)%/g;
  const simplePattern = /^([A-Z]{2,4})\s+([+-]?\d+\.?\d*)%/;
  
  // Sector name mapping
  const sectorNames = {
    'XLP': 'Consumer Staples',
    'XLV': 'Healthcare',
    'XLRE': 'Real Estate',
    'XLY': 'Consumer Cyclical',
    'XLF': 'Financials',
    'XLU': 'Utilities',
    'XLE': 'Energy',
    'XLI': 'Industrials',
    'XLC': 'Communication Services',
    'XLB': 'Basic Materials',
    'XLK': 'Technology',
  };
  
  const foundSectors = new Map();
  
  for (const line of lines) {
    // Try full pattern first
    let match;
    const regex = new RegExp(sectorPattern.source, 'g');
    while ((match = regex.exec(line)) !== null) {
      const ticker = match[2];
      const perf = parseFloat(match[3]);
      if (!isNaN(perf) && sectorNames[ticker]) {
        foundSectors.set(ticker, {
          name: sectorNames[ticker],
          ticker: ticker,
          performance: perf
        });
      }
    }
    
    // Try to find in "Leaders:", "Laggards:" format
    if (line.includes(':')) {
      const parts = line.split(/,\s*/);
      for (const part of parts) {
        const sectorMatch = part.match(/([A-Za-z\s]+)\s*\(([A-Z]+)\)\s*([+-]?\d+\.?\d*)%/);
        if (sectorMatch) {
          const ticker = sectorMatch[2];
          const perf = parseFloat(sectorMatch[3]);
          if (!isNaN(perf) && sectorNames[ticker]) {
            foundSectors.set(ticker, {
              name: sectorNames[ticker],
              ticker: ticker,
              performance: perf
            });
          }
        }
      }
    }
  }
  
  // Convert to array and sort by performance (best to worst)
  const result = Array.from(foundSectors.values());
  result.sort((a, b) => b.performance - a.performance);
  
  return result;
}

// ============ GET TEXT COLOR ============
function getTextColor(text) {
  if (!text) return COLORS.darkText;
  
  if (text.length > 60) return COLORS.darkText;
  
  const percentMatch = text.match(/([+-]?\d+\.?\d*)%/);
  if (percentMatch) {
    const value = parseFloat(percentMatch[1]);
    if (value >= 0.3) return COLORS.green;
    if (value <= -0.3) return COLORS.red;
  }
  
  const parenMatch = text.match(/\(([+-]?\d+\.?\d*)%?\)/);
  if (parenMatch) {
    const value = parseFloat(parenMatch[1]);
    if (value >= 0.3) return COLORS.green;
    if (value <= -0.3) return COLORS.red;
  }
  
  return COLORS.darkText;
}

// ============ FILE-BASED GENERATION ============
export async function generateNewsletterPDFWithCharts(newsletter, chartData, outputPath) {
  const buffer = await generateNewsletterPDFBufferWithCharts(newsletter, chartData);
  fs.writeFileSync(outputPath, buffer);
  return {
    path: outputPath,
    filename: path.basename(outputPath),
    size: buffer.length,
  };
}
// ============ FULL DISCLAIMER SECTION ============
function generateDisclaimerSection(doc) {
  doc.addPage();
  let y = 60;
  
  doc.fillColor(COLORS.gold)
     .fontSize(14)
     .font(FONTS.bold)
     .text('IMPORTANT DISCLAIMER', PAGE.marginLeft, y, { align: 'center', width: PAGE.contentWidth });
  
  y += 30;
  
  const disclaimerSections = [
    {
      title: 'GENERAL INFORMATION ONLY',
      content: 'This report is produced by Finotaur for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.'
    },
    {
      title: 'NOT INVESTMENT ADVICE',
      content: 'This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. Finotaur is NOT a registered investment adviser or broker-dealer.'
    },
    {
      title: 'RISK DISCLOSURE',
      content: 'Trading and investing involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital.'
    },
    {
      title: 'NO GUARANTEES',
      content: 'Finotaur makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.'
    },
    {
      title: 'YOUR RESPONSIBILITY',
      content: 'You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.'
    },
    {
      title: 'LIMITATION OF LIABILITY',
      content: 'Finotaur shall NOT be liable for any damages arising from your use of or reliance on this report.'
    }
  ];
  
  doc.fillColor(COLORS.darkText);
  
  for (const section of disclaimerSections) {
    if (y > 680) {
      doc.addPage();
      y = 60;
    }
    
    doc.font(FONTS.bold).fontSize(9).text(section.title, PAGE.marginLeft, y);
    y += 12;
    
    doc.font(FONTS.body).fontSize(8)
       .text(section.content, PAGE.marginLeft, y, { width: PAGE.contentWidth, align: 'justify' });
    
    y += doc.heightOfString(section.content, { width: PAGE.contentWidth }) + 15;
  }
  
  y += 10;
  doc.font(FONTS.bold).fontSize(8).fillColor(COLORS.lightGray)
     .text('By reading this report, you acknowledge that you have read and agree to this disclaimer.', 
           PAGE.marginLeft, y, { width: PAGE.contentWidth, align: 'center' });
  
  y += 20;
  doc.text(`© ${new Date().getFullYear()} Finotaur. All rights reserved.`, 
           PAGE.marginLeft, y, { width: PAGE.contentWidth, align: 'center' });
}
export default {
  generateNewsletterPDFBufferWithCharts,
  generateNewsletterPDFWithCharts,
};