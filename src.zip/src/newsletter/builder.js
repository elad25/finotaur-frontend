// ==========================================
// Newsletter Builder - v5.1.0
// With Admin Note Support
// ==========================================
// 🔥 v5.1.0 CHANGES:
// - sendNewsletter now accepts options with adminNote
// - sendTestEmail passes adminNote to email sender
// - Admin notes are logged in newsletter_send_logs
// ==========================================

import { createMarketDataCollector } from './collectors/index.js';
import { createAIProcessor } from './ai/ai-processor-adapter.js';
import { createEmailSender } from './email/sender.js';
import { generateEmailHTML } from './email/template.js';
import { createClient } from '@supabase/supabase-js';
import { generateCharts, cleanupOldCharts } from './charts/index.js';

export class NewsletterBuilder {
  constructor(config) {
    this.collector = createMarketDataCollector({
      fredApiKey: config.fredApiKey,
      finnhubApiKey: config.finnhubApiKey,
    });

    // ═══════════════════════════════════════════════════════════
    // AI Processor - Now using Agents SDK (Version 5.0)
    // ═══════════════════════════════════════════════════════════
    this.aiProcessor = createAIProcessor({
      apiKey: config.openaiApiKey,
      model: config.openaiModel || 'gpt-4o',
      debug: config.debug || false,
    });

    this.emailSender = createEmailSender({
      apiKey: config.resendApiKey,
      fromEmail: config.fromEmail,
      fromName: config.fromName,
      replyTo: config.replyTo,
      usePDF: config.usePDF !== false,
    });

    this.supabase = createClient(config.supabaseUrl, config.supabaseServiceKey);
    
    // Charts configuration
    this.enableCharts = config.enableCharts !== false;
    this.debug = config.debug || false;
  }

  // ==========================================
  // 📊 STEP 1: COLLECT DATA + GENERATE CHARTS
  // ==========================================
  async collectData() {
    console.log('\n' + '═'.repeat(60));
    console.log('📊 STEP 1: Collecting Market Data');
    console.log('═'.repeat(60) + '\n');
    
    const marketData = await this.collector.collectAll();
    
    // Generate charts if enabled
    if (this.enableCharts) {
      try {
        console.log('\n📈 Generating Charts...');
        const chartsResult = await generateCharts(marketData);
        marketData.chartPaths = chartsResult.charts;
        console.log(`✅ Generated ${Object.keys(chartsResult.charts).length} charts`);
      } catch (e) {
        console.warn('⚠️ Chart generation failed:', e.message);
        marketData.chartPaths = {};
      }
    } else {
      marketData.chartPaths = {};
    }
    
    return marketData;
  }

  // ==========================================
  // 🤖 STEP 2: GENERATE CONTENT (AI Agents SDK)
  // ==========================================
  async generateContent(data) {
    console.log('\n' + '═'.repeat(60));
    console.log('🤖 STEP 2: Generating Newsletter Content');
    console.log(`   Using: ${this.aiProcessor.getInfo().type} v${this.aiProcessor.getInfo().version}`);
    console.log(`   Agents: ${this.aiProcessor.getInfo().agentCount}`);
    console.log('═'.repeat(60) + '\n');
    
    const newsletter = await this.aiProcessor.generateNewsletter(data);
    
    // Attach chart paths to newsletter
    newsletter.chartPaths = data.chartPaths || {};
    
    return newsletter;
  }

  // ==========================================
  // 💾 STEP 3: SAVE TO DATABASE
  // ==========================================
  async saveToDatabase(newsletter, audienceType = 'manual') {
    console.log('\n' + '═'.repeat(60));
    console.log('💾 STEP 3: Saving to Database');
    console.log('═'.repeat(60) + '\n');

    const htmlContent = generateEmailHTML(newsletter);

    const { data, error } = await this.supabase
      .from('newsletters')
      .insert({
        subject: newsletter.subject,
        preheader: newsletter.preheader || '',
        status: 'draft',
        content: newsletter.sections,
        html_content: htmlContent,
        has_charts: Object.keys(newsletter.chartPaths || {}).length > 0,
        report_mode: newsletter.reportMode || 'DAILY',
        market_sentiment: newsletter.marketSentiment || 'neutral',
        audience_type: audienceType,
        version: newsletter.version || '5.1',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) {
      console.error('❌ Database error:', error);
      throw new Error(`Failed to save newsletter: ${error.message}`);
    }

    console.log(`✅ Newsletter saved with ID: ${data.id}`);
    return data;
  }

  // ==========================================
  // 👥 STEP 4: GET SUBSCRIBERS BY AUDIENCE TYPE
  // ==========================================
  async getActiveSubscribers(audienceType = 'premium') {
    console.log('\n' + '═'.repeat(60));
    console.log(`👥 STEP 4: Fetching Subscribers (${audienceType})`);
    console.log('═'.repeat(60) + '\n');

    let recipients = [];

    if (audienceType === 'premium') {
      const { data, error } = await this.supabase
        .from('profiles')
        .select('id, email, full_name, newsletter_preferences')
        .eq('account_type', 'premium')
        .not('email', 'is', null);

      if (error) {
        console.error('❌ Error fetching premium users:', error);
        throw new Error(`Failed to fetch premium users: ${error.message}`);
      }

      const optedIn = (data || []).filter(user => {
        if (!user.newsletter_preferences) return true;
        return user.newsletter_preferences.daily_newsletter !== false;
      });

      recipients = optedIn.map(user => ({
        email: user.email,
        firstName: user.full_name?.split(' ')[0] || '',
        lastName: user.full_name?.split(' ').slice(1).join(' ') || '',
        subscriberId: user.id,
        isPremium: true,
      }));

      console.log(`✅ Found ${data?.length || 0} premium users, ${recipients.length} opted-in`);

    } else if (audienceType === 'newsletter') {
      const { data, error } = await this.supabase
        .from('newsletter_subscribers')
        .select('id, email, first_name, last_name, preferences')
        .eq('status', 'active')
        .eq('email_verified', true);

      if (error) {
        console.error('❌ Error fetching newsletter subscribers:', error);
        throw new Error(`Failed to fetch subscribers: ${error.message}`);
      }

      recipients = (data || [])
        .filter(sub => sub.preferences?.daily_newsletter !== false)
        .map(sub => ({
          email: sub.email,
          firstName: sub.first_name || '',
          lastName: sub.last_name || '',
          subscriberId: sub.id,
          isPremium: false,
        }));

      console.log(`✅ Found ${recipients.length} newsletter subscribers`);

    } else if (audienceType === 'both') {
      const [premiumResult, newsletterResult] = await Promise.all([
        this.supabase
          .from('profiles')
          .select('id, email, full_name, newsletter_preferences')
          .eq('account_type', 'premium')
          .not('email', 'is', null),
        this.supabase
          .from('newsletter_subscribers')
          .select('id, email, first_name, last_name, preferences')
          .eq('status', 'active')
          .eq('email_verified', true),
      ]);

      const premiumEmails = new Set();
      const premiumRecipients = (premiumResult.data || [])
        .filter(user => {
          if (!user.newsletter_preferences) return true;
          return user.newsletter_preferences.daily_newsletter !== false;
        })
        .map(user => {
          premiumEmails.add(user.email?.toLowerCase());
          return {
            email: user.email,
            firstName: user.full_name?.split(' ')[0] || '',
            lastName: user.full_name?.split(' ').slice(1).join(' ') || '',
            subscriberId: user.id,
            isPremium: true,
          };
        });

      const newsletterRecipients = (newsletterResult.data || [])
        .filter(sub => 
          sub.preferences?.daily_newsletter !== false &&
          !premiumEmails.has(sub.email?.toLowerCase())
        )
        .map(sub => ({
          email: sub.email,
          firstName: sub.first_name || '',
          lastName: sub.last_name || '',
          subscriberId: sub.id,
          isPremium: false,
        }));

      recipients = [...premiumRecipients, ...newsletterRecipients];
      console.log(`✅ Found ${premiumRecipients.length} premium + ${newsletterRecipients.length} newsletter = ${recipients.length} total`);
    }

    recipients = recipients.filter(r => r.email && r.email.includes('@'));

    return recipients;
  }

  // ==========================================
  // 🎯 GET CUSTOM RECIPIENTS BY IDS
  // ==========================================
  async getCustomRecipients(recipientIds = [], recipientEmails = []) {
    console.log('\n' + '═'.repeat(60));
    console.log('👥 STEP 4: Fetching Custom Recipients');
    console.log('═'.repeat(60) + '\n');

    let recipients = [];

    if (recipientIds.length > 0) {
      const { data, error } = await this.supabase
        .from('profiles')
        .select('id, email, full_name')
        .in('id', recipientIds);

      if (error) {
        console.error('❌ Error fetching recipients by ID:', error);
        throw new Error(`Failed to fetch recipients: ${error.message}`);
      }

      recipients = (data || []).map(user => ({
        email: user.email,
        firstName: user.full_name?.split(' ')[0] || '',
        lastName: user.full_name?.split(' ').slice(1).join(' ') || '',
        subscriberId: user.id,
        isPremium: true,
      }));

      console.log(`✅ Found ${recipients.length} recipients by ID`);

    } else if (recipientEmails.length > 0) {
      recipients = recipientEmails.map(email => ({
        email,
        firstName: '',
        lastName: '',
        subscriberId: null,
        isPremium: true,
      }));

      console.log(`✅ Using ${recipients.length} email addresses`);
    }

    recipients = recipients.filter(r => r.email && r.email.includes('@'));

    return recipients;
  }

  // ==========================================
  // 📊 GET AUDIENCE COUNTS
  // ==========================================
  async getAudienceCounts() {
    const { data: premiumData } = await this.supabase
      .from('profiles')
      .select('id, newsletter_preferences')
      .eq('account_type', 'premium')
      .not('email', 'is', null);

    const premiumOptedIn = (premiumData || []).filter(user => {
      if (!user.newsletter_preferences) return true;
      return user.newsletter_preferences.daily_newsletter !== false;
    }).length;

    const { count: newsletterCount } = await this.supabase
      .from('newsletter_subscribers')
      .select('id', { count: 'exact', head: true })
      .eq('status', 'active')
      .eq('email_verified', true);

    return {
      premium: premiumOptedIn,
      newsletter: newsletterCount || 0,
    };
  }

  // ==========================================
  // 📨 STEP 5: SEND NEWSLETTER
  // 🔥 UPDATED: Now accepts options with adminNote
  // ==========================================
  async sendNewsletter(newsletterId, newsletter, recipients, options = {}) {
    console.log('\n' + '═'.repeat(60));
    console.log('📨 STEP 5: Sending Newsletter');
    console.log('═'.repeat(60) + '\n');

    const { 
      adminNote = null,      // ✅ Admin note to include in email
      segments = [],         // ✅ Audience segments for logging
      sentBy = null,         // ✅ Admin user who sent (for audit)
    } = options;

    if (adminNote) {
      console.log(`📝 Including admin note: "${adminNote.substring(0, 50)}${adminNote.length > 50 ? '...' : ''}"`);
    }

    // Update newsletter status to sending
    await this.supabase
      .from('newsletters')
      .update({
        status: 'sending',
        recipient_count: recipients.length,
        updated_at: new Date().toISOString(),
      })
      .eq('id', newsletterId);

    // ✅ Pass adminNote and segments to email sender
    const result = await this.emailSender.sendBatchOptimized(recipients, newsletter, {
      adminNote,
      segments,
      sentBy,
      processorInfo: this.aiProcessor.getInfo(),
    });

    const finalStatus = result.failed === 0 ? 'sent' : (result.sent === 0 ? 'failed' : 'sent');

    // Update newsletter final status
    await this.supabase
      .from('newsletters')
      .update({
        status: finalStatus,
        sent_at: new Date().toISOString(),
        sent_count: result.sent,
        failed_count: result.failed,
        updated_at: new Date().toISOString(),
      })
      .eq('id', newsletterId);

    console.log(`\n✅ Newsletter ${finalStatus}!`);
    console.log(`   📧 Sent: ${result.sent}`);
    console.log(`   ❌ Failed: ${result.failed}`);
    if (adminNote) {
      console.log(`   📝 Admin note included: Yes`);
    }
    
    return result;
  }

  // ==========================================
  // 🚀 RUN FULL PIPELINE (Standard)
  // ==========================================
  async runFullPipeline(audienceType = 'premium', options = {}) {
    const processorInfo = this.aiProcessor.getInfo();
    const { adminNote = null } = options;
    
    console.log(`\n${'🚀'.repeat(20)}`);
    console.log(`STARTING NEWSLETTER PIPELINE`);
    console.log(`Audience: ${audienceType.toUpperCase()}`);
    console.log(`Charts: ${this.enableCharts ? 'ENABLED' : 'DISABLED'}`);
    console.log(`AI Engine: ${processorInfo.type} v${processorInfo.version}`);
    console.log(`Agents: ${processorInfo.agentCount}`);
    if (adminNote) {
      console.log(`Admin Note: Yes`);
    }
    console.log(`${'🚀'.repeat(20)}\n`);
    
    const startTime = Date.now();

    try {
      const marketData = await this.collectData();
      const newsletter = await this.generateContent(marketData);
      const record = await this.saveToDatabase(newsletter, audienceType);
      const recipients = await this.getActiveSubscribers(audienceType);

      if (recipients.length === 0) {
        console.log('\n⚠️ No subscribers found. Skipping send.');
        
        await this.supabase
          .from('newsletters')
          .update({
            status: 'sent',
            recipient_count: 0,
            sent_count: 0,
            sent_at: new Date().toISOString(),
          })
          .eq('id', record.id);

        return {
          newsletter,
          record,
          sendResult: { total: 0, sent: 0, failed: 0, results: [] },
        };
      }

      const sendResult = await this.sendNewsletter(record.id, newsletter, recipients, { adminNote });

      const duration = Date.now() - startTime;
      console.log(`\n✨ Pipeline complete in ${(duration / 1000).toFixed(1)}s ✨\n`);

      // Cleanup old charts
      cleanupOldCharts();

      return { newsletter, record, sendResult };
      
    } catch (error) {
      console.error('\n❌ Pipeline failed:', error);
      throw error;
    }
  }

  // ==========================================
  // 🚀 RUN FULL PIPELINE WITH CUSTOM RECIPIENTS
  // ==========================================
  async runFullPipelineWithCustomRecipients(recipientIds = [], recipientEmails = [], options = {}) {
    const processorInfo = this.aiProcessor.getInfo();
    const { adminNote = null, segments = [] } = options;
    
    console.log(`\n${'🚀'.repeat(20)}`);
    console.log(`STARTING NEWSLETTER PIPELINE`);
    console.log(`Custom Recipients: ${recipientIds.length || recipientEmails.length}`);
    console.log(`Charts: ${this.enableCharts ? 'ENABLED' : 'DISABLED'}`);
    console.log(`AI Engine: ${processorInfo.type} v${processorInfo.version}`);
    if (adminNote) {
      console.log(`Admin Note: Yes`);
    }
    console.log(`${'🚀'.repeat(20)}\n`);
    
    const startTime = Date.now();

    try {
      const marketData = await this.collectData();
      const newsletter = await this.generateContent(marketData);
      const record = await this.saveToDatabase(newsletter, 'custom');
      const recipients = await this.getCustomRecipients(recipientIds, recipientEmails);

      if (recipients.length === 0) {
        console.log('\n⚠️ No recipients found. Skipping send.');
        
        await this.supabase
          .from('newsletters')
          .update({
            status: 'sent',
            recipient_count: 0,
            sent_count: 0,
            sent_at: new Date().toISOString(),
          })
          .eq('id', record.id);

        return {
          newsletter,
          record,
          sendResult: { total: 0, sent: 0, failed: 0, results: [] },
        };
      }

      const sendResult = await this.sendNewsletter(record.id, newsletter, recipients, { 
        adminNote, 
        segments,
      });

      const duration = Date.now() - startTime;
      console.log(`\n✨ Pipeline complete in ${(duration / 1000).toFixed(1)}s ✨\n`);

      // Cleanup old charts
      cleanupOldCharts();

      return { newsletter, record, sendResult };
      
    } catch (error) {
      console.error('\n❌ Pipeline failed:', error);
      throw error;
    }
  }

  // ==========================================
  // 🔍 GENERATE PREVIEW
  // ==========================================
  async generatePreview() {
    console.log('\n🔍 Generating Newsletter Preview...\n');
    console.log(`   AI Engine: ${this.aiProcessor.getInfo().type} v${this.aiProcessor.getInfo().version}`);

    try {
      const marketData = await this.collector.collectQuick();
      
      // Generate charts for preview
      if (this.enableCharts) {
        try {
          const chartsResult = await generateCharts(marketData);
          marketData.chartPaths = chartsResult.charts;
          console.log(`📊 Generated ${Object.keys(chartsResult.charts).length} charts for preview`);
        } catch (e) {
          console.warn('⚠️ Chart generation failed:', e.message);
          marketData.chartPaths = {};
        }
      } else {
        marketData.chartPaths = {};
      }
      
      const newsletter = await this.aiProcessor.generateNewsletter(marketData);
      newsletter.chartPaths = marketData.chartPaths;
      
      const html = generateEmailHTML(newsletter);
      const counts = await this.getAudienceCounts();

      console.log(`✅ Preview generated`);
      console.log(`   📊 Premium: ${counts.premium}`);
      console.log(`   📧 Newsletter: ${counts.newsletter}`);
      console.log(`   📈 Charts: ${Object.keys(newsletter.chartPaths).length}`);

      return {
        newsletter,
        html,
        subscriberCount: counts.newsletter,
        premiumCount: counts.premium,
        audienceCounts: counts,
        chartPaths: newsletter.chartPaths,
        processorInfo: this.aiProcessor.getInfo(),
      };
      
    } catch (error) {
      console.error('❌ Preview failed:', error);
      throw error;
    }
  }

  // ==========================================
  // 🧪 SEND TEST EMAIL
  // 🔥 UPDATED: Now passes adminNote to email sender
  // ==========================================
  async sendTestEmail(testEmail, options = {}) {
    const { adminNote = null } = options;
    
    console.log(`\n🧪 Sending test email to ${testEmail}...`);
    if (adminNote) {
      console.log(`   📝 With admin note: "${adminNote.substring(0, 50)}${adminNote.length > 50 ? '...' : ''}"`);
    }
    console.log();

    try {
      const { newsletter } = await this.generatePreview();
      
      // ✅ Pass adminNote to sendTest
      const result = await this.emailSender.sendTest(testEmail, newsletter, { 
        adminNote,
        usePDF: true,
      });

      if (result.success) {
        console.log(`✅ Test email sent to ${testEmail}`);
        if (adminNote) {
          console.log(`   📝 Admin note included: Yes`);
        }
      } else {
        console.log(`❌ Test email failed: ${result.error}`);
      }

      return result.success;
      
    } catch (error) {
      console.error('❌ Test email failed:', error);
      return false;
    }
  }

  // ==========================================
  // ℹ️ GET PROCESSOR INFO
  // ==========================================
  getProcessorInfo() {
    return this.aiProcessor.getInfo();
  }
}

export function createNewsletterBuilder(config) {
  return new NewsletterBuilder(config);
}