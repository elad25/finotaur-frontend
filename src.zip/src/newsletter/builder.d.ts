// ==========================================
// Type Declarations for builder.js
// ==========================================

export interface NewsletterBuilderConfig {
  fredApiKey?: string;
  finnhubApiKey?: string;
  openaiApiKey: string;
  openaiModel?: string;
  resendApiKey: string;
  fromEmail?: string;
  fromName?: string;
  replyTo?: string;
  usePDF?: boolean;
  supabaseUrl: string;
  supabaseServiceKey: string;
  enableCharts?: boolean;
  debug?: boolean;
  promptConfig?: any;
}

export interface Recipient {
  email: string;
  firstName: string;
  lastName: string;
  subscriberId: string | null;
  isPremium: boolean;
}

export interface SendResult {
  total: number;
  sent: number;
  failed: number;
  results: any[];
}

export interface AudienceCounts {
  premium: number;
  newsletter: number;
}

export interface PreviewResult {
  newsletter: any;
  html: string;
  subscriberCount: number;
  premiumCount: number;
  audienceCounts: AudienceCounts;
  chartPaths: Record<string, string>;
}

export interface PipelineResult {
  newsletter: any;
  record: any;
  sendResult: SendResult;
}

export declare class NewsletterBuilder {
  constructor(config: NewsletterBuilderConfig);
  
  collectData(): Promise<any>;
  generateContent(data: any): Promise<any>;
  saveToDatabase(newsletter: any): Promise<any>;
  getActiveSubscribers(audienceType?: 'premium' | 'newsletter' | 'both'): Promise<Recipient[]>;
  getCustomRecipients(recipientIds?: string[], recipientEmails?: string[]): Promise<Recipient[]>;
  getAudienceCounts(): Promise<AudienceCounts>;
  sendNewsletter(newsletterId: string, newsletter: any, recipients: Recipient[]): Promise<SendResult>;
  runFullPipeline(audienceType?: 'premium' | 'newsletter' | 'both'): Promise<PipelineResult>;
  runFullPipelineWithCustomRecipients(recipientIds?: string[], recipientEmails?: string[]): Promise<PipelineResult>;
  generatePreview(): Promise<PreviewResult>;
  sendTestEmail(testEmail: string, options?: any): Promise<boolean>;
  getProcessorInfo(): { version: string; model: string; type: string; agentCount: number; workflowId: string };
}

export declare function createNewsletterBuilder(config: NewsletterBuilderConfig): NewsletterBuilder;