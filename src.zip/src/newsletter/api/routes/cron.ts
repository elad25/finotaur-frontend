// ==========================================
// API Route: Newsletter Cron Job
// Path: /pages/api/newsletter/cron.ts
// Called by: Vercel Cron / External scheduler
// Schedule: 0 14 * * 1-5 (9:00 AM ET, Mon-Fri)
// ==========================================

import { NextApiRequest, NextApiResponse } from 'next';
import { handleCron } from '@/lib/newsletter/api/handlers';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Only allow POST or GET (for cron services)
  if (req.method !== 'POST' && req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Get auth token from header or query
  const authToken = 
    req.headers['x-cron-secret'] as string ||
    req.headers.authorization?.replace('Bearer ', '') ||
    req.query.secret as string;

  try {
    console.log('⏰ Cron job triggered at:', new Date().toISOString());
    
    const result = await handleCron(authToken);
    
    if (result.success) {
      return res.status(200).json(result);
    } else if (result.error === 'Unauthorized') {
      return res.status(401).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error('Newsletter cron error:', error);
    return res.status(500).json({ 
      success: false, 
      error: 'Internal server error' 
    });
  }
}

// Increase timeout for cron route
export const config = {
  maxDuration: 300, // 5 minutes
};