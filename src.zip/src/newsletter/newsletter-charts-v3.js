// ==========================================
// Newsletter Charts v6.0 - Minimal Institutional
// ==========================================
// Design Standards:
// - NO emojis in titles
// - Black & white base with semantic colors
// - Clean typography
// - Minimal decoration
// - Professional axis labels
// ==========================================

import { ChartJSNodeCanvas } from 'chartjs-node-canvas';
import fs from 'fs';
import path from 'path';

// ============ CHART CONFIGURATION ============
const CHART_WIDTH = 800;
const CHART_HEIGHT = 360;
const CHART_BG_COLOR = '#FFFFFF';

// Minimal Color Palette
const COLORS = {
  // Base
  black: '#000000',
  darkGray: '#333333',
  mediumGray: '#666666',
  lightGray: '#CCCCCC',
  bgGray: '#F5F5F5',
  white: '#FFFFFF',
  
  // Semantic (only for data)
  green: '#2E7D32',
  lightGreen: '#66BB6A',
  paleGreen: '#C8E6C9',
  red: '#C62828',
  lightRed: '#EF5350',
  paleRed: '#FFCDD2',
  
  // Accent
  gold: '#C9A955',
};

// Chart.js canvas renderer
const chartJSNodeCanvas = new ChartJSNodeCanvas({
  width: CHART_WIDTH,
  height: CHART_HEIGHT,
  backgroundColour: CHART_BG_COLOR,
  plugins: {
    modern: ['chartjs-plugin-datalabels'],
  },
});

// ============ MAIN EXPORT ============
export async function generateAllCharts(marketData, outputDir) {
  console.log('[Charts v6] Generating minimal charts...');

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const charts = {};
  const sectionCharts = {};
  const errors = [];

  // 1. Market Overview
  try {
    const p1 = path.join(outputDir, 'market_overview.png');
    await generateMarketOverviewChart(marketData, p1);
    charts.marketOverview = p1;
    sectionCharts['market-pulse'] = p1;
    sectionCharts['what-changed'] = p1;
    console.log('  [OK] Market Overview');
  } catch (err) {
    console.error('  [ERR] Market Overview:', err.message);
    errors.push({ chart: 'marketOverview', error: err.message });
  }

  // 2. Sector Performance
  try {
    const p2 = path.join(outputDir, 'sector_performance.png');
    await generateSectorChart(marketData, p2);
    charts.sectorPerformance = p2;
    sectionCharts['sector-rotation'] = p2;
    console.log('  [OK] Sector Performance');
  } catch (err) {
    console.error('  [ERR] Sector Performance:', err.message);
    errors.push({ chart: 'sectorPerformance', error: err.message });
  }

  // 3. Volatility
  try {
    const p3 = path.join(outputDir, 'volatility.png');
    await generateVolatilityChart(marketData, p3);
    charts.volatility = p3;
    sectionCharts['market-structure'] = p3;
    console.log('  [OK] Volatility');
  } catch (err) {
    console.error('  [ERR] Volatility:', err.message);
    errors.push({ chart: 'volatility', error: err.message });
  }

  // 4. Technical Levels
  try {
    const p4 = path.join(outputDir, 'technical_levels.png');
    await generateTechnicalLevelsChart(marketData, p4);
    charts.technicalLevels = p4;
    sectionCharts['technical-levels'] = p4;
    console.log('  [OK] Technical Levels');
  } catch (err) {
    console.error('  [ERR] Technical Levels:', err.message);
    errors.push({ chart: 'technicalLevels', error: err.message });
  }

  // 5. Options Flow
  try {
    const p5 = path.join(outputDir, 'options_flow.png');
    await generateOptionsFlowChart(marketData, p5);
    charts.optionsFlow = p5;
    sectionCharts['options-flow'] = p5;
    console.log('  [OK] Options Flow');
  } catch (err) {
    console.error('  [ERR] Options Flow:', err.message);
    errors.push({ chart: 'optionsFlow', error: err.message });
  }

  // 6. Bond Yields
  try {
    const p6 = path.join(outputDir, 'bonds.png');
    await generateBondsChart(marketData, p6);
    charts.bonds = p6;
    sectionCharts['macro-arena'] = p6;
    console.log('  [OK] Bond Yields');
  } catch (err) {
    console.error('  [ERR] Bond Yields:', err.message);
    errors.push({ chart: 'bonds', error: err.message });
  }

  const chartCount = Object.keys(charts).length;
  console.log(`[Charts v6] Generated ${chartCount}/6 charts`);

  return {
    charts,
    sectionCharts,
    errors,
    chartCount,
    outputDir,
  };
}

// ============ 1. MARKET OVERVIEW ============
async function generateMarketOverviewChart(marketData, outputPath) {
  const indices = extractIndicesData(marketData);

  const labels = indices.map(i => i.symbol);
  const data = indices.map(i => i.change);
  const colors = data.map(v => v >= 0 ? COLORS.green : COLORS.red);

  const config = {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Daily Change %',
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1,
        borderRadius: 2,
      }],
    },
    options: {
      responsive: false,
      layout: {
        padding: { top: 30, right: 25, bottom: 15, left: 25 },
      },
      plugins: {
        title: {
          display: true,
          text: 'MAJOR INDICES - DAILY CHANGE',
          font: { size: 14, weight: 'bold', family: 'Helvetica' },
          color: COLORS.black,
          padding: { bottom: 20 },
        },
        legend: { display: false },
        tooltip: {
          backgroundColor: COLORS.darkGray,
          titleFont: { size: 12, weight: 'bold' },
          bodyFont: { size: 11 },
          padding: 8,
          cornerRadius: 2,
          callbacks: {
            label: (ctx) => `${ctx.parsed.y > 0 ? '+' : ''}${ctx.parsed.y.toFixed(2)}%`,
          },
        },
        datalabels: {
          display: true,
          anchor: 'end',
          align: 'top',
          color: COLORS.darkGray,
          font: { size: 10, weight: 'bold' },
          formatter: (value) => `${value > 0 ? '+' : ''}${value.toFixed(2)}%`,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: COLORS.lightGray, lineWidth: 0.5 },
          ticks: {
            callback: (value) => `${value > 0 ? '+' : ''}${value.toFixed(1)}%`,
            color: COLORS.mediumGray,
            font: { size: 10 },
          },
          border: { display: false },
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.black,
            font: { size: 11, weight: 'bold' },
          },
          border: { display: false },
        },
      },
    },
  };

  const buffer = await chartJSNodeCanvas.renderToBuffer(config);
  fs.writeFileSync(outputPath, buffer);
}

// ============ 2. SECTOR PERFORMANCE ============
async function generateSectorChart(marketData, outputPath) {
  const sectors = extractSectorData(marketData);
  sectors.sort((a, b) => b.change - a.change);

  const labels = sectors.map(s => s.name);
  const data = sectors.map(s => s.change);

  // Gradient colors based on performance
  const colors = data.map(v => {
    if (v >= 1.0) return COLORS.green;
    if (v >= 0) return COLORS.lightGreen;
    if (v >= -1.0) return COLORS.lightRed;
    return COLORS.red;
  });

  const config = {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Performance %',
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1,
        borderRadius: 2,
      }],
    },
    options: {
      indexAxis: 'y',
      responsive: false,
      layout: {
        padding: { top: 30, right: 40, bottom: 15, left: 10 },
      },
      plugins: {
        title: {
          display: true,
          text: 'SECTOR PERFORMANCE',
          font: { size: 14, weight: 'bold', family: 'Helvetica' },
          color: COLORS.black,
          padding: { bottom: 15 },
        },
        legend: { display: false },
        datalabels: {
          display: true,
          anchor: 'end',
          align: 'right',
          color: COLORS.darkGray,
          font: { size: 9, weight: 'bold' },
          formatter: (value) => `${value > 0 ? '+' : ''}${value.toFixed(2)}%`,
        },
      },
      scales: {
        x: {
          grid: { color: COLORS.lightGray, lineWidth: 0.5 },
          ticks: {
            callback: (value) => `${value > 0 ? '+' : ''}${value.toFixed(1)}%`,
            color: COLORS.mediumGray,
            font: { size: 9 },
          },
          border: { display: false },
        },
        y: {
          grid: { display: false },
          ticks: {
            color: COLORS.darkGray,
            font: { size: 10 },
          },
          border: { display: false },
        },
      },
    },
  };

  const buffer = await chartJSNodeCanvas.renderToBuffer(config);
  fs.writeFileSync(outputPath, buffer);
}

// ============ 3. VOLATILITY ============
async function generateVolatilityChart(marketData, outputPath) {
  const volData = extractVolatilityData(marketData);

  const config = {
    type: 'bar',
    data: {
      labels: ['VIX', 'VIX 9D', 'VIX 3M', 'VVIX/10'],
      datasets: [{
        label: 'Level',
        data: [volData.vix, volData.vix9d, volData.vix3m, volData.vvix / 10],
        backgroundColor: [
          COLORS.darkGray,
          COLORS.mediumGray,
          COLORS.lightGray,
          COLORS.gold,
        ],
        borderRadius: 2,
        borderWidth: 0,
      }],
    },
    options: {
      responsive: false,
      layout: {
        padding: { top: 30, right: 25, bottom: 15, left: 25 },
      },
      plugins: {
        title: {
          display: true,
          text: 'VOLATILITY STRUCTURE',
          font: { size: 14, weight: 'bold', family: 'Helvetica' },
          color: COLORS.black,
          padding: { bottom: 5 },
        },
        subtitle: {
          display: true,
          text: `Term Structure: ${volData.termStructure}`,
          font: { size: 11 },
          color: volData.termStructure.includes('Backwardation') ? COLORS.red : COLORS.green,
          padding: { bottom: 15 },
        },
        legend: { display: false },
        datalabels: {
          display: true,
          anchor: 'end',
          align: 'top',
          color: COLORS.darkGray,
          font: { size: 10, weight: 'bold' },
          formatter: (value) => value.toFixed(1),
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          max: Math.max(volData.vix, volData.vix9d, volData.vvix / 10) * 1.3,
          grid: { color: COLORS.lightGray },
          ticks: { color: COLORS.mediumGray, font: { size: 10 } },
          border: { display: false },
        },
        x: {
          grid: { display: false },
          ticks: { color: COLORS.darkGray, font: { size: 10 } },
          border: { display: false },
        },
      },
    },
  };

  const buffer = await chartJSNodeCanvas.renderToBuffer(config);
  fs.writeFileSync(outputPath, buffer);
}

// ============ 4. TECHNICAL LEVELS ============
async function generateTechnicalLevelsChart(marketData, outputPath) {
  const levels = extractTechnicalLevels(marketData);
  const currentPrice = levels.spyPrice;

  const config = {
    type: 'bar',
    data: {
      labels: ['S2', 'S1', 'CURRENT', 'R1', 'R2'],
      datasets: [{
        label: 'Price Level',
        data: [
          levels.support2,
          levels.support1,
          currentPrice,
          levels.resistance1,
          levels.resistance2,
        ],
        backgroundColor: [
          COLORS.red,
          COLORS.lightRed,
          COLORS.gold,
          COLORS.lightGreen,
          COLORS.green,
        ],
        borderRadius: 2,
      }],
    },
    options: {
      responsive: false,
      layout: {
        padding: { top: 30, right: 25, bottom: 15, left: 25 },
      },
      plugins: {
        title: {
          display: true,
          text: 'SPY KEY LEVELS',
          font: { size: 14, weight: 'bold', family: 'Helvetica' },
          color: COLORS.black,
          padding: { bottom: 5 },
        },
        subtitle: {
          display: true,
          text: `Current: $${currentPrice.toFixed(2)}`,
          font: { size: 11 },
          color: COLORS.darkGray,
          padding: { bottom: 15 },
        },
        legend: { display: false },
        datalabels: {
          display: true,
          anchor: 'end',
          align: 'top',
          color: COLORS.darkGray,
          font: { size: 9, weight: 'bold' },
          formatter: (value) => `$${value.toFixed(0)}`,
        },
      },
      scales: {
        y: {
          min: levels.support2 * 0.98,
          max: levels.resistance2 * 1.02,
          grid: { color: COLORS.lightGray },
          ticks: {
            callback: (value) => `$${value.toFixed(0)}`,
            color: COLORS.mediumGray,
            font: { size: 10 },
          },
          border: { display: false },
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.darkGray,
            font: { size: 10, weight: 'bold' },
          },
          border: { display: false },
        },
      },
    },
  };

  const buffer = await chartJSNodeCanvas.renderToBuffer(config);
  fs.writeFileSync(outputPath, buffer);
}

// ============ 5. OPTIONS FLOW ============
async function generateOptionsFlowChart(marketData, outputPath) {
  const options = extractOptionsData(marketData);
  const pcRatio = options.putCallRatio;

  let sentiment;
  if (pcRatio > 1.2) {
    sentiment = 'BEARISH';
  } else if (pcRatio < 0.7) {
    sentiment = 'BULLISH';
  } else {
    sentiment = 'NEUTRAL';
  }

  const config = {
    type: 'doughnut',
    data: {
      labels: ['Puts', 'Calls'],
      datasets: [{
        data: [pcRatio * 50, (2 - pcRatio) * 50],
        backgroundColor: [COLORS.red, COLORS.green],
        borderWidth: 2,
        borderColor: COLORS.white,
        circumference: 180,
        rotation: 270,
      }],
    },
    options: {
      responsive: false,
      cutout: '65%',
      layout: {
        padding: { top: 40, bottom: 80 },
      },
      plugins: {
        title: {
          display: true,
          text: 'OPTIONS SENTIMENT',
          font: { size: 14, weight: 'bold', family: 'Helvetica' },
          color: COLORS.black,
          padding: { bottom: 20 },
        },
        subtitle: {
          display: true,
          text: `Put/Call: ${pcRatio.toFixed(2)} | ${sentiment}`,
          font: { size: 12, weight: 'bold' },
          color: pcRatio > 1 ? COLORS.red : COLORS.green,
          padding: { top: 10 },
        },
        legend: {
          display: true,
          position: 'bottom',
          labels: {
            usePointStyle: true,
            pointStyle: 'circle',
            padding: 20,
            font: { size: 11 },
            color: COLORS.darkGray,
          },
        },
        datalabels: {
          display: false,
        },
      },
    },
  };

  const buffer = await chartJSNodeCanvas.renderToBuffer(config);
  fs.writeFileSync(outputPath, buffer);
}

// ============ 6. BOND YIELDS ============
async function generateBondsChart(marketData, outputPath) {
  const bonds = extractBondData(marketData);

  const config = {
    type: 'bar',
    data: {
      labels: ['2Y', '10Y', '30Y', 'Spread'],
      datasets: [{
        label: 'Yield %',
        data: [bonds.yield2y, bonds.yield10y, bonds.yield30y, bonds.spread],
        backgroundColor: [
          COLORS.lightGray,
          COLORS.mediumGray,
          COLORS.darkGray,
          bonds.spread < 0 ? COLORS.red : COLORS.green,
        ],
        borderRadius: 2,
      }],
    },
    options: {
      responsive: false,
      layout: {
        padding: { top: 30, right: 25, bottom: 15, left: 25 },
      },
      plugins: {
        title: {
          display: true,
          text: 'TREASURY YIELDS',
          font: { size: 14, weight: 'bold', family: 'Helvetica' },
          color: COLORS.black,
          padding: { bottom: 5 },
        },
        subtitle: {
          display: true,
          text: `Curve: ${bonds.spread < 0 ? 'INVERTED' : 'Normal'}`,
          font: { size: 11, weight: 'bold' },
          color: bonds.spread < 0 ? COLORS.red : COLORS.green,
          padding: { bottom: 15 },
        },
        legend: { display: false },
        datalabels: {
          display: true,
          anchor: 'end',
          align: 'top',
          color: COLORS.darkGray,
          font: { size: 10, weight: 'bold' },
          formatter: (value) => `${value.toFixed(2)}%`,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: COLORS.lightGray },
          ticks: {
            callback: (value) => `${value.toFixed(1)}%`,
            color: COLORS.mediumGray,
            font: { size: 10 },
          },
          border: { display: false },
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.darkGray,
            font: { size: 10 },
          },
          border: { display: false },
        },
      },
    },
  };

  const buffer = await chartJSNodeCanvas.renderToBuffer(config);
  fs.writeFileSync(outputPath, buffer);
}

// ============ DATA EXTRACTORS ============

function extractIndicesData(marketData) {
  const defaultIndices = [
    { symbol: 'SPY', change: 0.5 },
    { symbol: 'QQQ', change: 0.8 },
    { symbol: 'IWM', change: -0.3 },
    { symbol: 'DIA', change: 0.2 },
  ];

  if (marketData?.indices) {
    return marketData.indices.map(idx => ({
      symbol: idx.symbol || idx.ticker,
      change: parseFloat(idx.change || idx.changePercent || 0),
    }));
  }

  if (marketData?.spy || marketData?.SPY) {
    return [
      { symbol: 'SPY', change: parseFloat(marketData.spy?.change || marketData.SPY?.change || 0) },
      { symbol: 'QQQ', change: parseFloat(marketData.qqq?.change || marketData.QQQ?.change || 0) },
      { symbol: 'IWM', change: parseFloat(marketData.iwm?.change || marketData.IWM?.change || 0) },
      { symbol: 'DIA', change: parseFloat(marketData.dia?.change || marketData.DIA?.change || 0) },
    ];
  }

  return defaultIndices;
}

function extractSectorData(marketData) {
  const sectorMap = {
    XLK: 'Technology',
    XLF: 'Financials',
    XLV: 'Healthcare',
    XLE: 'Energy',
    XLI: 'Industrials',
    XLY: 'Consumer Disc',
    XLP: 'Consumer Stpl',
    XLU: 'Utilities',
    XLB: 'Materials',
    XLRE: 'Real Estate',
    XLC: 'Communication',
  };

  if (marketData?.sectors) {
    return marketData.sectors.map(s => ({
      name: s.name || sectorMap[s.symbol] || s.symbol,
      change: parseFloat(s.change || s.changePercent || 0),
    }));
  }

  // Default data
  return [
    { name: 'Technology', change: 1.2 },
    { name: 'Financials', change: 0.8 },
    { name: 'Healthcare', change: 0.3 },
    { name: 'Energy', change: -0.5 },
    { name: 'Industrials', change: 0.6 },
    { name: 'Consumer Disc', change: -0.2 },
    { name: 'Utilities', change: -0.8 },
    { name: 'Materials', change: 0.4 },
    { name: 'Real Estate', change: -1.1 },
    { name: 'Communication', change: 0.9 },
  ];
}

function extractVolatilityData(marketData) {
  let vix = 15, vix9d = 14, vix3m = 16, vvix = 85;

  if (marketData?.volatility) {
    vix = parseFloat(marketData.volatility.vix || vix);
    vix9d = parseFloat(marketData.volatility.vix9d || vix9d);
    vix3m = parseFloat(marketData.volatility.vix3m || vix * 1.05);
    vvix = parseFloat(marketData.volatility.vvix || vvix);
  } else if (marketData?.vix) {
    vix = parseFloat(marketData.vix);
    vix9d = parseFloat(marketData.vix9d || vix * 0.95);
    vix3m = parseFloat(marketData.vix3m || vix * 1.05);
    vvix = parseFloat(marketData.vvix || 85);
  }

  const termStructure = vix9d > vix ? 'Backwardation' : 'Contango';
  return { vix, vix9d, vix3m, vvix, termStructure };
}

function extractTechnicalLevels(marketData) {
  let spyPrice = 500;
  let support1 = 495, support2 = 488;
  let resistance1 = 508, resistance2 = 515;

  if (marketData?.technicalLevels?.spy) {
    const spy = marketData.technicalLevels.spy;
    spyPrice = parseFloat(spy.price || spy.current || spyPrice);
    support1 = parseFloat(spy.support1 || spy.s1 || spyPrice * 0.99);
    support2 = parseFloat(spy.support2 || spy.s2 || spyPrice * 0.975);
    resistance1 = parseFloat(spy.resistance1 || spy.r1 || spyPrice * 1.01);
    resistance2 = parseFloat(spy.resistance2 || spy.r2 || spyPrice * 1.025);
  } else if (marketData?.spy?.price) {
    spyPrice = parseFloat(marketData.spy.price);
    support1 = spyPrice * 0.99;
    support2 = spyPrice * 0.975;
    resistance1 = spyPrice * 1.01;
    resistance2 = spyPrice * 1.025;
  }

  return { spyPrice, support1, support2, resistance1, resistance2 };
}

function extractOptionsData(marketData) {
  let putCallRatio = 0.85;

  if (marketData?.optionsFlow) {
    putCallRatio = parseFloat(marketData.optionsFlow.putCallRatio || marketData.optionsFlow.pcRatio || putCallRatio);
  } else if (marketData?.options) {
    putCallRatio = parseFloat(marketData.options.putCallRatio || marketData.options.pcr || putCallRatio);
  }

  return { putCallRatio };
}

function extractBondData(marketData) {
  let yield2y = 4.5, yield10y = 4.2, yield30y = 4.4;

  if (marketData?.bonds) {
    yield2y = parseFloat(marketData.bonds.yield2y || marketData.bonds['2y'] || yield2y);
    yield10y = parseFloat(marketData.bonds.yield10y || marketData.bonds['10y'] || yield10y);
    yield30y = parseFloat(marketData.bonds.yield30y || marketData.bonds['30y'] || yield30y);
  } else if (marketData?.treasury) {
    yield2y = parseFloat(marketData.treasury.yield2y || yield2y);
    yield10y = parseFloat(marketData.treasury.yield10y || yield10y);
    yield30y = parseFloat(marketData.treasury.yield30y || yield30y);
  }

  return { yield2y, yield10y, yield30y, spread: yield10y - yield2y };
}

// ============ EXPORTS ============
export default {
  generateAllCharts,
};