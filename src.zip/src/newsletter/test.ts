// ==========================================
// Newsletter Test Script
// Run with: npx ts-node src/lib/newsletter/test.ts
// Or import and call testNewsletter() from anywhere
// ==========================================

import { createMarketDataCollector } from './collectors';
import { createAIProcessor } from './ai/processor';
import { generateEmailHTML } from './email/template';

export async function testNewsletter() {
  console.log('🚀 Starting Newsletter Test...\n');

  // Check environment variables
  const requiredKeys = ['FINNHUB_API_KEY', 'OPENAI_API_KEY'];
  const missing = requiredKeys.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    console.error('❌ Missing API keys:', missing.join(', '));
    return null;
  }

  try {
    // Step 1: Collect Data
    console.log('📊 Step 1: Collecting market data...');
    const collector = createMarketDataCollector({
      fredApiKey: process.env.FRED_API_KEY || '',
      finnhubApiKey: process.env.FINNHUB_API_KEY!,
    });
    
    const data = await collector.collectQuick(); // Quick version for testing
    console.log('✅ Data collected!');
    console.log(`   - ${data.marketIndices.length} indices`);
    console.log(`   - ${data.topGainers.length} gainers`);
    console.log(`   - ${data.topLosers.length} losers`);
    console.log(`   - ${data.news.length} news items\n`);

    // Step 2: Generate with AI
    console.log('🤖 Step 2: Generating newsletter with AI...');
    const aiProcessor = createAIProcessor(process.env.OPENAI_API_KEY!);
    const newsletter = await aiProcessor.generateNewsletter(data);
    console.log('✅ Newsletter generated!\n');

    // Show results
    console.log('========================================');
    console.log('📧 GENERATED NEWSLETTER');
    console.log('========================================\n');
    console.log(`📌 Subject: ${newsletter.subject}`);
    console.log(`📝 Preheader: ${newsletter.preheader}\n`);
    
    newsletter.sections.forEach((section, i) => {
      console.log(`--- Section ${i + 1}: ${section.title} ---`);
      console.log(section.content);
      console.log('');
    });

    // Generate HTML
    const html = generateEmailHTML(newsletter);
    console.log(`✅ HTML generated (${html.length} characters)\n`);

    return { newsletter, html, data };
  } catch (error) {
    console.error('❌ Test failed:', error);
    return null;
  }
}

// Run if called directly
if (require.main === module) {
  require('dotenv').config({ path: '.env.local' });
  testNewsletter().then(() => process.exit(0));
}