// ==========================================
// Chart Orchestrator v2.1 - Fixed Version
// ==========================================

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

const CHART_OUTPUT_DIR = '/tmp/finotaur-charts';

// Ensure output directory exists
function ensureChartDir() {
  if (!fs.existsSync(CHART_OUTPUT_DIR)) {
    fs.mkdirSync(CHART_OUTPUT_DIR, { recursive: true });
  }
}

// ============ Generate All Charts ============
export async function generateAllCharts(marketData, report = null, themes = []) {
  ensureChartDir();
  
  console.log('📊 Generating charts...');
  
  const charts = {};
  
  try {
    // 1. Market Overview Chart
    const marketOverviewPath = await generateMarketOverviewChart(marketData);
    if (marketOverviewPath) charts.marketOverview = marketOverviewPath;
    
    // 2. Sector Performance Chart
    const sectorPath = await generateSectorChart(marketData);
    if (sectorPath) charts.sectorPerformance = sectorPath;
    
    // 3. VIX/Volatility Chart
    const vixPath = await generateVIXChart(marketData);
    if (vixPath) charts.volatility = vixPath;
    
    console.log('✅ Generated ' + Object.keys(charts).length + ' charts');
    
  } catch (error) {
    console.error('❌ Chart generation error:', error);
  }
  
  return charts;
}

// ============ Orchestrate Charts (compatibility) ============
export async function orchestrateCharts(reportText, marketData, options = {}) {
  const charts = await generateAllCharts(marketData, reportText);
  
  // Map charts to sections
  const sectionCharts = {
    'MARKET_MAP': ['marketOverview'],
    'MARKET_PULSE': ['marketOverview'],
    'SECTOR_ROTATION': ['sectorPerformance'],
    'MARKET_STRUCTURE': ['volatility'],
  };
  
  return {
    charts,
    sectionCharts,
    themes: [],
    primaryTheme: null,
    analysis: null,
  };
}

// ============ Prepare Charts for PDF ============
export async function prepareChartsForPDF(charts) {
  const prepared = {};
  
  for (const [key, chartPath] of Object.entries(charts)) {
    if (chartPath && fs.existsSync(chartPath)) {
      prepared[key] = {
        path: chartPath,
        buffer: fs.readFileSync(chartPath),
        exists: true,
      };
    }
  }
  
  return prepared;
}

// ============ Market Overview Chart ============
async function generateMarketOverviewChart(marketData) {
  const outputPath = path.join(CHART_OUTPUT_DIR, 'market-overview-' + Date.now() + '.png');
  
  // Extract data
  const indices = marketData?.indices || {};
  const spy = indices.SPY || { price: 682.80, change: -0.03 };
  const qqq = indices.QQQ || { price: 622.85, change: -0.35 };
  const iwm = indices.IWM || { price: 251.59, change: 0.12 };
  const dia = indices.DIA || { price: 477.44, change: 0.24 };
  
  const pythonCode = [
    'import matplotlib',
    "matplotlib.use('Agg')",
    'import matplotlib.pyplot as plt',
    'import numpy as np',
    '',
    "labels = ['SPY', 'QQQ', 'IWM', 'DIA']",
    'changes = [' + spy.change + ', ' + qqq.change + ', ' + iwm.change + ', ' + dia.change + ']',
    'prices = [' + spy.price + ', ' + qqq.price + ', ' + iwm.price + ', ' + dia.price + ']',
    '',
    "colors = ['#059669' if c >= 0 else '#DC2626' for c in changes]",
    '',
    "fig, ax = plt.subplots(figsize=(8, 4), facecolor='white')",
    "ax.set_facecolor('white')",
    '',
    'bars = ax.bar(labels, changes, color=colors, edgecolor="none", width=0.6)',
    '',
    'for bar, change, price in zip(bars, changes, prices):',
    '    height = bar.get_height()',
    '    label_y = height + 0.02 if height >= 0 else height - 0.08',
    "    ax.annotate(f'{change:+.2f}%',",
    '                xy=(bar.get_x() + bar.get_width() / 2, label_y),',
    "                ha='center', va='bottom' if height >= 0 else 'top',",
    "                fontsize=11, fontweight='bold',",
    "                color='#059669' if change >= 0 else '#DC2626')",
    "    ax.annotate(f'${price:.2f}',",
    '                xy=(bar.get_x() + bar.get_width() / 2, -0.4),',
    "                ha='center', va='top',",
    "                fontsize=9, color='#6B7280')",
    '',
    "ax.axhline(y=0, color='#E5E7EB', linewidth=1)",
    "ax.set_ylabel('Change (%)', fontsize=10, color='#374151')",
    "ax.set_title('Major Indices Performance', fontsize=14, fontweight='bold', color='#1E3A8A', pad=15)",
    "ax.spines['top'].set_visible(False)",
    "ax.spines['right'].set_visible(False)",
    "ax.spines['left'].set_color('#E5E7EB')",
    "ax.spines['bottom'].set_color('#E5E7EB')",
    "ax.tick_params(colors='#374151')",
    'ax.set_ylim(-0.6, 0.6)',
    '',
    'plt.tight_layout()',
    "plt.savefig('" + outputPath + "', dpi=150, bbox_inches='tight', facecolor='white', edgecolor='none')",
    'plt.close()',
    "print('Chart saved')",
  ].join('\n');

  try {
    await runPython(pythonCode);
    if (fs.existsSync(outputPath)) {
      return outputPath;
    }
    return null;
  } catch (error) {
    console.error('Market overview chart error:', error.message);
    return null;
  }
}

// ============ Sector Performance Chart ============
async function generateSectorChart(marketData) {
  const outputPath = path.join(CHART_OUTPUT_DIR, 'sector-' + Date.now() + '.png');
  
  // Extract sector data
  const sectors = marketData?.sectors || [
    { name: 'Industrials', change: 0.82 },
    { name: 'Healthcare', change: 0.62 },
    { name: 'Real Estate', change: 0.54 },
    { name: 'Consumer Disc', change: 0.54 },
    { name: 'Materials', change: 0.48 },
    { name: 'Financials', change: 0.25 },
    { name: 'Energy', change: 0.07 },
    { name: 'Utilities', change: -0.34 },
    { name: 'Technology', change: -0.52 },
  ];
  
  // Sort by performance
  const sortedSectors = [...sectors].sort((a, b) => b.change - a.change);
  const names = sortedSectors.map(s => s.name).slice(0, 9);
  const changes = sortedSectors.map(s => s.change).slice(0, 9);
  
  const pythonCode = [
    'import matplotlib',
    "matplotlib.use('Agg')",
    'import matplotlib.pyplot as plt',
    'import numpy as np',
    '',
    'names = ' + JSON.stringify(names),
    'changes = ' + JSON.stringify(changes),
    '',
    "colors = ['#059669' if c >= 0 else '#DC2626' for c in changes]",
    '',
    "fig, ax = plt.subplots(figsize=(8, 5), facecolor='white')",
    "ax.set_facecolor('white')",
    '',
    'y_pos = np.arange(len(names))',
    'bars = ax.barh(y_pos, changes, color=colors, edgecolor="none", height=0.6)',
    '',
    'for bar, change in zip(bars, changes):',
    '    width = bar.get_width()',
    '    label_x = width + 0.02 if width >= 0 else width - 0.02',
    "    ax.annotate(f'{change:+.2f}%',",
    '                xy=(label_x, bar.get_y() + bar.get_height()/2),',
    "                ha='left' if width >= 0 else 'right',",
    "                va='center',",
    "                fontsize=9, fontweight='bold',",
    "                color='#059669' if change >= 0 else '#DC2626')",
    '',
    'ax.set_yticks(y_pos)',
    'ax.set_yticklabels(names)',
    'ax.invert_yaxis()',
    "ax.axvline(x=0, color='#E5E7EB', linewidth=1)",
    "ax.set_xlabel('Change (%)', fontsize=10, color='#374151')",
    "ax.set_title('Sector Rotation', fontsize=14, fontweight='bold', color='#1E3A8A', pad=15)",
    "ax.spines['top'].set_visible(False)",
    "ax.spines['right'].set_visible(False)",
    "ax.spines['left'].set_color('#E5E7EB')",
    "ax.spines['bottom'].set_color('#E5E7EB')",
    "ax.tick_params(colors='#374151')",
    '',
    'plt.tight_layout()',
    "plt.savefig('" + outputPath + "', dpi=150, bbox_inches='tight', facecolor='white', edgecolor='none')",
    'plt.close()',
    "print('Chart saved')",
  ].join('\n');

  try {
    await runPython(pythonCode);
    if (fs.existsSync(outputPath)) {
      return outputPath;
    }
    return null;
  } catch (error) {
    console.error('Sector chart error:', error.message);
    return null;
  }
}

// ============ VIX Chart ============
async function generateVIXChart(marketData) {
  const outputPath = path.join(CHART_OUTPUT_DIR, 'vix-' + Date.now() + '.png');
  
  const vix = marketData?.vix?.value || 16.93;
  const vixChange = marketData?.vix?.change || 1.62;
  
  const pythonCode = [
    'import matplotlib',
    "matplotlib.use('Agg')",
    'import matplotlib.pyplot as plt',
    'import numpy as np',
    '',
    'vix_value = ' + vix,
    'vix_change = ' + vixChange,
    '',
    "fig, ax = plt.subplots(figsize=(6, 3), facecolor='white')",
    "ax.set_facecolor('white')",
    '',
    'zones = [',
    "    (0, 12, '#059669', 'Low'),",
    "    (12, 20, '#F59E0B', 'Normal'),",
    "    (20, 30, '#F97316', 'Elevated'),",
    "    (30, 50, '#DC2626', 'High'),",
    ']',
    '',
    'for start, end, color, label in zones:',
    '    ax.barh(0, end-start, left=start, height=0.6, color=color, alpha=0.3)',
    "    ax.text((start+end)/2, 0.5, label, ha='center', va='center', fontsize=8, color=color)",
    '',
    "ax.scatter([vix_value], [0], s=200, color='#1E3A8A', zorder=5, marker='v')",
    "ax.annotate(f'VIX: {vix_value:.2f}',",
    '            xy=(vix_value, -0.15),',
    "            ha='center', va='top',",
    "            fontsize=12, fontweight='bold', color='#1E3A8A')",
    '',
    "change_text = f'({vix_change:+.2f}%)'",
    "change_color = '#DC2626' if vix_change > 0 else '#059669'",
    'ax.annotate(change_text,',
    '            xy=(vix_value, -0.35),',
    "            ha='center', va='top',",
    '            fontsize=10, color=change_color)',
    '',
    'ax.set_xlim(0, 50)',
    'ax.set_ylim(-0.8, 0.8)',
    "ax.set_title('VIX - Volatility Index', fontsize=14, fontweight='bold', color='#1E3A8A', pad=15)",
    "ax.spines['top'].set_visible(False)",
    "ax.spines['right'].set_visible(False)",
    "ax.spines['left'].set_visible(False)",
    "ax.spines['bottom'].set_color('#E5E7EB')",
    'ax.set_yticks([])',
    "ax.set_xlabel('VIX Level', fontsize=10, color='#374151')",
    "ax.tick_params(colors='#374151')",
    '',
    'plt.tight_layout()',
    "plt.savefig('" + outputPath + "', dpi=150, bbox_inches='tight', facecolor='white', edgecolor='none')",
    'plt.close()',
    "print('Chart saved')",
  ].join('\n');

  try {
    await runPython(pythonCode);
    if (fs.existsSync(outputPath)) {
      return outputPath;
    }
    return null;
  } catch (error) {
    console.error('VIX chart error:', error.message);
    return null;
  }
}

// ============ Run Python ============
function runPython(script) {
  return new Promise((resolve, reject) => {
    const python = spawn('python3', ['-c', script]);
    
    let stdout = '';
    let stderr = '';
    
    python.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    python.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    python.on('close', (code) => {
      if (code === 0) {
        resolve(stdout);
      } else {
        reject(new Error('Python error (code ' + code + '): ' + stderr));
      }
    });
    
    python.on('error', reject);
  });
}

// ============ Cleanup Old Charts ============
export function cleanupOldCharts(outputDir = CHART_OUTPUT_DIR, maxAgeHours = 4) {
  try {
    if (!fs.existsSync(outputDir)) return;
    
    const files = fs.readdirSync(outputDir);
    const now = Date.now();
    const maxAge = maxAgeHours * 60 * 60 * 1000;
    
    for (const file of files) {
      const filePath = path.join(outputDir, file);
      try {
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > maxAge) {
          fs.unlinkSync(filePath);
          console.log('🗑️ Deleted old chart: ' + file);
        }
      } catch (e) {
        // Ignore individual file errors
      }
    }
  } catch (error) {
    console.error('Chart cleanup error:', error.message);
  }
}

export default {
  generateAllCharts,
  orchestrateCharts,
  prepareChartsForPDF,
  cleanupOldCharts,
};