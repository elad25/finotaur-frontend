// ==========================================
// Charts Module - Legacy Exports
// For backward compatibility with existing code
// ==========================================

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CHART_CONFIG = {
  pythonScript: path.join(__dirname, 'chart-generator.py'),
  outputDir: '/tmp/finotaur-charts',
  python: 'python3',
};

/**
 * Transform collector data to chart format (legacy)
 */
export function transformMarketDataForCharts(collectorData) {
  const chartData = {};

  // 1. Indices
  if (collectorData.indices) {
    chartData.indices = {};
    const indexMap = {
      'SPY': 'SPY', '^GSPC': 'SPY', 'S&P 500': 'SPY',
      'QQQ': 'QQQ', '^NDX': 'QQQ', 'NASDAQ': 'QQQ',
      'DIA': 'DIA', '^DJI': 'DIA', 'Dow Jones': 'DIA',
      'IWM': 'IWM', '^RUT': 'IWM', 'Russell 2000': 'IWM',
    };

    for (const [key, data] of Object.entries(collectorData.indices)) {
      const symbol = indexMap[key] || key;
      if (['SPY', 'QQQ', 'DIA', 'IWM'].includes(symbol)) {
        chartData.indices[symbol] = {
          change_pct: data.changePercent || data.change_pct || 0,
          price: data.price || data.regularMarketPrice || 0,
        };
      }
    }
  }

  // 2. Sectors
  if (collectorData.sectors) {
    chartData.sectors = {};
    for (const sector of (Array.isArray(collectorData.sectors) ? collectorData.sectors : Object.values(collectorData.sectors))) {
      const symbol = sector.symbol || sector.etf;
      if (symbol) {
        chartData.sectors[symbol] = {
          name: sector.name || symbol,
          change_pct: sector.changePercent || sector.change_pct || 0,
        };
      }
    }
  }

  // 3. VIX
  if (collectorData.indices?.vix) {
    chartData.vix = { value: collectorData.indices.vix.price || 15 };
  }

  return chartData;
}

/**
 * Generate charts using legacy Python script
 */
export async function generateCharts(marketData, outputDir = CHART_CONFIG.outputDir) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    const chartData = marketData.indices && marketData.sectors 
      ? marketData 
      : transformMarketDataForCharts(marketData);

    const dataPath = path.join(outputDir, `data_${Date.now()}.json`);
    fs.writeFileSync(dataPath, JSON.stringify(chartData, null, 2));

    console.log('📊 Generating charts (legacy)...');

    const python = spawn(CHART_CONFIG.python, [
      CHART_CONFIG.pythonScript,
      '--data', dataPath,
      '--output', outputDir,
    ]);

    let stdout = '';
    let stderr = '';

    python.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    python.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    python.on('close', (code) => {
      try { fs.unlinkSync(dataPath); } catch (e) {}

      if (code === 0) {
        const chartPaths = {};
        const jsonMatch = stdout.match(/--- CHART_PATHS_JSON ---\n(.+)/s);
        
        if (jsonMatch) {
          try {
            Object.assign(chartPaths, JSON.parse(jsonMatch[1].trim()));
          } catch (e) {}
        }

        if (Object.keys(chartPaths).length === 0) {
          const files = fs.readdirSync(outputDir);
          for (const file of files) {
            if (file.endsWith('.png')) {
              const name = file.split('_')[0];
              chartPaths[name] = path.join(outputDir, file);
            }
          }
        }

        console.log(`✅ Generated ${Object.keys(chartPaths).length} charts`);
        resolve({ success: true, charts: chartPaths, outputDir });
      } else {
        console.error('❌ Chart generation failed:', stderr);
        reject(new Error(`Chart generation failed: ${stderr}`));
      }
    });

    python.on('error', (err) => {
      reject(err);
    });
  });
}

/**
 * Read chart as base64
 */
export function readChartAsBase64(chartPath) {
  if (!fs.existsSync(chartPath)) {
    throw new Error(`Chart not found: ${chartPath}`);
  }
  return fs.readFileSync(chartPath).toString('base64');
}

/**
 * Get chart as data URI
 */
export function getChartDataUri(chartPath) {
  return `data:image/png;base64,${readChartAsBase64(chartPath)}`;
}

/**
 * Generate charts with base64 data for email
 */
export async function generateChartsForEmail(marketData) {
  const result = await generateCharts(marketData);
  
  const chartsWithData = {};
  
  for (const [name, chartPath] of Object.entries(result.charts)) {
    try {
      chartsWithData[name] = {
        path: chartPath,
        base64: readChartAsBase64(chartPath),
        dataUri: getChartDataUri(chartPath),
      };
    } catch (e) {
      console.warn(`Could not read chart ${name}:`, e.message);
    }
  }
  
  return chartsWithData;
}

/**
 * Cleanup old charts
 */
export function cleanupOldCharts(outputDir = CHART_CONFIG.outputDir, maxAgeHours = 24) {
  const maxAge = maxAgeHours * 60 * 60 * 1000;
  const now = Date.now();

  try {
    if (!fs.existsSync(outputDir)) return;

    const files = fs.readdirSync(outputDir);
    let cleaned = 0;

    for (const file of files) {
      if (file.endsWith('.png') || file.endsWith('.json')) {
        const filePath = path.join(outputDir, file);
        const stats = fs.statSync(filePath);

        if (now - stats.mtimeMs > maxAge) {
          fs.unlinkSync(filePath);
          cleaned++;
        }
      }
    }

    if (cleaned > 0) {
      console.log(`🧹 Cleaned ${cleaned} old chart files`);
    }
  } catch (e) {}
}

export default {
  generateCharts,
  generateChartsForEmail,
  transformMarketDataForCharts,
  readChartAsBase64,
  getChartDataUri,
  cleanupOldCharts,
};