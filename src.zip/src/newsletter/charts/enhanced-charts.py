# -*- coding: utf-8 -*-
"""
Finotaur Enhanced Chart Generator v2.0
======================================
1. Market Overview Chart (FIXED - always generated)
2. Dynamic Charts based on report themes

Usage:
    python enhanced-charts.py --data market_data.json --output ./charts/
    python enhanced-charts.py --demo
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import FancyBboxPatch, Wedge
import numpy as np
import json
import sys
import os
from datetime import datetime, timedelta
import requests

# ============================================
# FINOTAUR COLOR PALETTE
# ============================================
COLORS = {
    'gold': '#C9A646',
    'gold_light': '#E5D59A',
    'gold_dark': '#8B7030',
    'dark_bg': '#0d0d18',
    'dark_accent': '#1a1a2e',
    'dark_card': '#252540',
    'text_primary': '#ffffff',
    'text_secondary': '#9ca3af',
    'text_muted': '#6b7280',
    'positive': '#10b981',
    'positive_light': '#34d399',
    'negative': '#ef4444',
    'negative_light': '#f87171',
    'neutral': '#6b7280',
    'warning': '#f59e0b',
    'spy_color': '#3b82f6',
    'qqq_color': '#8b5cf6',
    'iwm_color': '#06b6d4',
    'vix_color': '#ef4444',
}

plt.rcParams.update({
    'figure.facecolor': COLORS['dark_bg'],
    'axes.facecolor': COLORS['dark_accent'],
    'axes.edgecolor': COLORS['gold'],
    'axes.labelcolor': COLORS['text_primary'],
    'axes.titlecolor': COLORS['gold'],
    'xtick.color': COLORS['text_secondary'],
    'ytick.color': COLORS['text_secondary'],
    'text.color': COLORS['text_primary'],
    'grid.color': COLORS['dark_card'],
    'grid.alpha': 0.5,
    'font.family': 'sans-serif',
    'font.size': 10,
})


# ============================================
# POLYGON API - HISTORICAL DATA FETCHER
# ============================================
def fetch_historical_data(symbol, days=5, api_key=None):
    """Fetch historical daily data from Polygon API"""
    if not api_key:
        api_key = os.environ.get('POLYGON_API_KEY')
    
    if not api_key:
        print(f"⚠️ No Polygon API key for {symbol}")
        return None
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days + 5)
    
    url = f"https://api.polygon.io/v2/aggs/ticker/{symbol}/range/1/day/{start_date.strftime('%Y-%m-%d')}/{end_date.strftime('%Y-%m-%d')}"
    params = {'apiKey': api_key, 'adjusted': 'true', 'sort': 'asc'}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('results'):
                results = data['results'][-days:]
                return {
                    'dates': [datetime.fromtimestamp(r['t'] / 1000) for r in results],
                    'close': [r['c'] for r in results],
                    'open': [r['o'] for r in results],
                    'high': [r['h'] for r in results],
                    'low': [r['l'] for r in results],
                    'volume': [r['v'] for r in results],
                }
        print(f"⚠️ Polygon API error for {symbol}: {response.status_code}")
        return None
    except Exception as e:
        print(f"⚠️ Error fetching {symbol}: {e}")
        return None


def fetch_vix_historical(days=5, api_key=None):
    """Fetch VIX historical data"""
    if not api_key:
        api_key = os.environ.get('POLYGON_API_KEY')
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days + 5)
    
    url = f"https://api.polygon.io/v2/aggs/ticker/I:VIX/range/1/day/{start_date.strftime('%Y-%m-%d')}/{end_date.strftime('%Y-%m-%d')}"
    params = {'apiKey': api_key, 'adjusted': 'true', 'sort': 'asc'}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('results'):
                results = data['results'][-days:]
                return {
                    'dates': [datetime.fromtimestamp(r['t'] / 1000) for r in results],
                    'close': [r['c'] for r in results],
                }
    except:
        pass
    
    # Fallback: try VXX and estimate
    vxx_data = fetch_historical_data('VXX', days, api_key)
    if vxx_data:
        return {
            'dates': vxx_data['dates'],
            'close': [p * 0.54 for p in vxx_data['close']],
        }
    
    return None


# ============================================
# CHART 1: MARKET OVERVIEW (FIXED - ALWAYS GENERATED)
# ============================================
def create_market_overview_chart(data, output_path, api_key=None):
    """
    THE FIXED CHART - Market Overview
    Shows SPY, QQQ, IWM on left axis and VIX on right axis
    """
    print("📊 Creating Market Overview Chart (Fixed)...")
    
    spy_hist = fetch_historical_data('SPY', 5, api_key)
    qqq_hist = fetch_historical_data('QQQ', 5, api_key)
    iwm_hist = fetch_historical_data('IWM', 5, api_key)
    vix_hist = fetch_vix_historical(5, api_key)
    
    if not spy_hist or not qqq_hist:
        print("⚠️ Using fallback data for Market Overview")
        return create_market_overview_fallback(data, output_path)
    
    fig, ax1 = plt.subplots(figsize=(10, 5), dpi=150)
    
    def normalize(prices):
        if not prices or prices[0] == 0:
            return prices
        return [(p / prices[0] - 1) * 100 for p in prices]
    
    dates = spy_hist['dates']
    spy_norm = normalize(spy_hist['close'])
    qqq_norm = normalize(qqq_hist['close'])
    iwm_norm = normalize(iwm_hist['close']) if iwm_hist else [0] * len(dates)
    
    ax1.plot(dates, spy_norm, color=COLORS['spy_color'], linewidth=2.5, 
             label=f"SPY ({spy_norm[-1]:+.2f}%)", marker='o', markersize=4)
    ax1.plot(dates, qqq_norm, color=COLORS['qqq_color'], linewidth=2.5, 
             label=f"QQQ ({qqq_norm[-1]:+.2f}%)", marker='s', markersize=4)
    if iwm_hist:
        ax1.plot(dates, iwm_norm, color=COLORS['iwm_color'], linewidth=2.5, 
                 label=f"IWM ({iwm_norm[-1]:+.2f}%)", marker='^', markersize=4)
    
    ax1.set_ylabel('% Change', fontsize=11, color=COLORS['text_primary'])
    ax1.axhline(y=0, color=COLORS['gold'], linewidth=1, alpha=0.5, linestyle='--')
    ax1.tick_params(axis='y', labelcolor=COLORS['text_primary'])
    ax1.yaxis.grid(True, alpha=0.3, linestyle='--')
    
    ax2 = ax1.twinx()
    if vix_hist:
        ax2.fill_between(vix_hist['dates'], vix_hist['close'], alpha=0.2, color=COLORS['vix_color'])
        ax2.plot(vix_hist['dates'], vix_hist['close'], color=COLORS['vix_color'], 
                 linewidth=2, linestyle='--', label=f"VIX ({vix_hist['close'][-1]:.1f})")
        ax2.set_ylabel('VIX', fontsize=11, color=COLORS['vix_color'])
        ax2.tick_params(axis='y', labelcolor=COLORS['vix_color'])
        ax2.axhline(y=20, color=COLORS['warning'], linewidth=0.8, alpha=0.5, linestyle=':')
        ax2.axhline(y=30, color=COLORS['negative'], linewidth=0.8, alpha=0.5, linestyle=':')
    
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b %d'))
    ax1.xaxis.set_major_locator(mdates.DayLocator())
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=0, ha='center')
    
    ax1.set_title('MARKET OVERVIEW — 5 Day Performance', fontsize=14, fontweight='bold',
                  color=COLORS['gold'], pad=15)
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels() if vix_hist else ([], [])
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', framealpha=0.9, fontsize=9)
    
    ax1.spines['top'].set_visible(False)
    ax2.spines['top'].set_visible(False)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ Market Overview saved: {output_path}")
    return output_path


def create_market_overview_fallback(data, output_path):
    """Fallback when historical data unavailable"""
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    indices = ['SPY', 'QQQ', 'IWM', 'DIA']
    changes = []
    
    for idx in indices:
        key = idx.lower() if idx.lower() in data.get('indices', {}) else idx
        val = data.get('indices', {}).get(key, {})
        changes.append(val.get('changePercent', val.get('change_pct', 0)))
    
    colors = [COLORS['positive'] if c >= 0 else COLORS['negative'] for c in changes]
    
    bars = ax.bar(indices, changes, color=colors, edgecolor='none', alpha=0.9, width=0.6)
    
    for bar, change in zip(bars, changes):
        height = bar.get_height()
        sign = '+' if change >= 0 else ''
        ax.text(bar.get_x() + bar.get_width()/2, height + 0.05,
               f'{sign}{change:.2f}%', ha='center', va='bottom',
               fontsize=12, fontweight='bold',
               color=COLORS['positive'] if change >= 0 else COLORS['negative'])
    
    ax.axhline(y=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_ylabel('Daily Change (%)', fontsize=10)
    ax.set_title('MARKET OVERVIEW — Today', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.yaxis.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# DYNAMIC CHART: YIELD CURVE
# ============================================
def create_yield_curve_chart(data, output_path):
    """Yield curve visualization"""
    print("📊 Creating Yield Curve Chart...")
    
    fig, ax = plt.subplots(figsize=(8, 4), dpi=150)
    
    rates = data.get('rates', {})
    
    maturities = ['2Y', '5Y', '10Y', '30Y']
    yields_values = [
        rates.get('us02y', {}).get('yield', 4.5),
        rates.get('us05y', {}).get('yield', 4.3) if 'us05y' in rates else 4.3,
        rates.get('us10y', {}).get('yield', 4.4),
        rates.get('us30y', {}).get('yield', 4.6) if 'us30y' in rates else 4.6,
    ]
    
    x = np.arange(len(maturities))
    
    ax.plot(x, yields_values, color=COLORS['gold'], linewidth=3, marker='o', 
            markersize=10, markerfacecolor=COLORS['dark_bg'], markeredgewidth=2)
    ax.fill_between(x, yields_values, alpha=0.2, color=COLORS['gold'])
    
    for i, (mat, yld) in enumerate(zip(maturities, yields_values)):
        ax.annotate(f'{yld:.2f}%', (i, yld), textcoords="offset points",
                   xytext=(0, 12), ha='center', fontsize=11, fontweight='bold',
                   color=COLORS['text_primary'])
    
    spread = yields_values[2] - yields_values[0]
    spread_color = COLORS['positive'] if spread > 0 else COLORS['negative']
    ax.text(0.98, 0.98, f'2s10s: {spread*100:+.0f}bps', transform=ax.transAxes,
           ha='right', va='top', fontsize=12, fontweight='bold',
           color=spread_color,
           bbox=dict(boxstyle='round', facecolor=COLORS['dark_card'], alpha=0.8))
    
    ax.set_xticks(x)
    ax.set_xticklabels(maturities, fontsize=12, fontweight='bold')
    ax.set_ylabel('Yield (%)', fontsize=11)
    ax.set_title('TREASURY YIELD CURVE', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.yaxis.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ Yield Curve saved: {output_path}")
    return output_path


# ============================================
# DYNAMIC CHART: CTA POSITIONING
# ============================================
def create_cta_positioning_chart(data, output_path):
    """CTA positioning levels"""
    print("📊 Creating CTA Positioning Chart...")
    
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    positioning = data.get('positioningData', {}).get('ctaPositioning', {})
    spy_price = data.get('indices', {}).get('spy', {}).get('price', 600)
    
    spx_current = positioning.get('spxCurrentLevel', int(spy_price * 10))
    spx_add = positioning.get('spxAddLevel', int(spx_current * 1.01))
    spx_flat = positioning.get('spxFlatTrigger', int(spx_current * 0.97))
    spx_short = positioning.get('spxShortTrigger', int(spx_current * 0.95))
    
    levels = [
        ('Short Trigger', spx_short, COLORS['negative'], '━━'),
        ('Flat Trigger', spx_flat, COLORS['warning'], '━━'),
        ('Current', spx_current, COLORS['gold'], '━━'),
        ('Add Level', spx_add, COLORS['positive'], '━━'),
    ]
    
    y_pos = np.arange(len(levels))
    
    for i, (label, level, color, style) in enumerate(levels):
        bar_width = 0.4
        ax.barh(i, level, height=bar_width, color=color, alpha=0.7, edgecolor=color)
        ax.text(level + 20, i, f'{level:,}', va='center', ha='left',
               fontsize=11, fontweight='bold', color=color)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels([l[0] for l in levels], fontsize=11, fontweight='bold')
    ax.set_xlabel('SPX Level', fontsize=10)
    ax.set_title('CTA POSITIONING LEVELS', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    trend = positioning.get('trend', 'LONG')
    conviction = positioning.get('conviction', 'HIGH')
    ax.text(0.02, 0.98, f'CTAs: {trend} ({conviction})', transform=ax.transAxes,
           ha='left', va='top', fontsize=11, fontweight='bold',
           color=COLORS['positive'] if trend == 'LONG' else COLORS['negative'],
           bbox=dict(boxstyle='round', facecolor=COLORS['dark_card'], alpha=0.8))
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.xaxis.grid(True, alpha=0.3, linestyle='--')
    
    all_levels = [l[1] for l in levels]
    ax.set_xlim(min(all_levels) * 0.98, max(all_levels) * 1.02)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ CTA Positioning saved: {output_path}")
    return output_path


# ============================================
# DYNAMIC CHART: SECTOR ROTATION
# ============================================
def create_sector_rotation_chart(data, output_path):
    """Sector rotation heatmap"""
    print("📊 Creating Sector Rotation Chart...")
    
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    sectors = data.get('sectors', [])
    
    if not sectors:
        sectors = [
            {'symbol': 'XLK', 'name': 'Technology', 'changePercent': 0},
            {'symbol': 'XLF', 'name': 'Financials', 'changePercent': 0},
            {'symbol': 'XLE', 'name': 'Energy', 'changePercent': 0},
            {'symbol': 'XLV', 'name': 'Healthcare', 'changePercent': 0},
            {'symbol': 'XLY', 'name': 'Consumer Disc', 'changePercent': 0},
        ]
    
    sorted_sectors = sorted(sectors, key=lambda x: x.get('changePercent', 0), reverse=True)[:11]
    
    names = [s.get('name', s.get('symbol', '')) for s in sorted_sectors]
    changes = [s.get('changePercent', 0) for s in sorted_sectors]
    
    colors = [COLORS['positive'] if c >= 0 else COLORS['negative'] for c in changes]
    
    y_pos = np.arange(len(names))
    bars = ax.barh(y_pos, changes, color=colors, edgecolor='none', alpha=0.85, height=0.7)
    
    for i, (bar, change) in enumerate(zip(bars, changes)):
        sign = '+' if change >= 0 else ''
        color = COLORS['positive'] if change >= 0 else COLORS['negative']
        
        if change >= 0:
            ax.text(change + 0.05, i, f'{sign}{change:.2f}%', va='center', ha='left',
                   fontsize=10, fontweight='bold', color=color)
        else:
            ax.text(change - 0.05, i, f'{sign}{change:.2f}%', va='center', ha='right',
                   fontsize=10, fontweight='bold', color=color)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(names, fontsize=10, fontweight='bold')
    ax.axvline(x=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_xlabel('Daily Change (%)', fontsize=10)
    ax.set_title('SECTOR ROTATION', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    if len(sorted_sectors) > 0:
        leader = sorted_sectors[0].get('name', sorted_sectors[0].get('symbol', ''))
        laggard = sorted_sectors[-1].get('name', sorted_sectors[-1].get('symbol', ''))
        ax.text(0.98, 0.02, f'Leader: {leader} | Laggard: {laggard}', 
               transform=ax.transAxes, ha='right', va='bottom',
               fontsize=9, color=COLORS['text_secondary'])
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.xaxis.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ Sector Rotation saved: {output_path}")
    return output_path


# ============================================
# DYNAMIC CHART: VIX REGIME
# ============================================
def create_vix_regime_chart(data, output_path):
    """VIX gauge with regime zones"""
    print("📊 Creating VIX Regime Chart...")
    
    fig, ax = plt.subplots(figsize=(6, 4), dpi=150)
    
    vix_data = data.get('indices', {}).get('vix', {})
    vix_value = vix_data.get('price', 16)
    vix_change = vix_data.get('changePercent', 0)
    
    center = (0.5, 0.35)
    radius = 0.35
    
    zones = [
        (0, 12, COLORS['positive'], 'Complacency'),
        (12, 16, COLORS['positive_light'], 'Low Vol'),
        (16, 20, COLORS['gold'], 'Normal'),
        (20, 25, COLORS['warning'], 'Elevated'),
        (25, 35, COLORS['negative_light'], 'Fear'),
        (35, 50, COLORS['negative'], 'Panic'),
    ]
    
    for start_val, end_val, color, label in zones:
        start_angle = 180 - (start_val / 50) * 180
        end_angle = 180 - (end_val / 50) * 180
        
        wedge = Wedge(center, radius, end_angle, start_angle, width=0.1,
                     facecolor=color, edgecolor='none', alpha=0.8)
        ax.add_patch(wedge)
    
    vix_clamped = max(0, min(vix_value, 50))
    needle_angle = 180 - (vix_clamped / 50) * 180
    needle_angle_rad = np.radians(needle_angle)
    
    needle_length = radius - 0.05
    needle_x = center[0] + needle_length * np.cos(needle_angle_rad)
    needle_y = center[1] + needle_length * np.sin(needle_angle_rad)
    
    ax.annotate('', xy=(needle_x, needle_y), xytext=center,
               arrowprops=dict(arrowstyle='->', color=COLORS['gold'], lw=3))
    
    center_circle = plt.Circle(center, 0.04, facecolor=COLORS['dark_card'],
                              edgecolor=COLORS['gold'], linewidth=2)
    ax.add_patch(center_circle)
    
    ax.text(center[0], center[1] - 0.12, f'{vix_value:.1f}',
           ha='center', va='top', fontsize=28, fontweight='bold',
           color=COLORS['gold'])
    
    change_color = COLORS['negative'] if vix_change > 0 else COLORS['positive']
    ax.text(center[0], center[1] - 0.22, f'{vix_change:+.1f}%',
           ha='center', va='top', fontsize=12, fontweight='bold',
           color=change_color)
    
    ax.text(0.1, 0.28, 'GREED', fontsize=8, color=COLORS['positive'], fontweight='bold')
    ax.text(0.85, 0.28, 'FEAR', fontsize=8, color=COLORS['negative'], fontweight='bold')
    
    ax.set_title('VIX FEAR & GREED', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=10)
    
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 0.65)
    ax.set_aspect('equal')
    ax.axis('off')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ VIX Regime saved: {output_path}")
    return output_path


# ============================================
# DYNAMIC CHART: OPTIONS FLOW
# ============================================
def create_options_flow_chart(data, output_path):
    """Top options flow visualization"""
    print("📊 Creating Options Flow Chart...")
    
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    uoa = data.get('uoa', [])[:10]
    
    if not uoa:
        ax.text(0.5, 0.5, 'No significant options flow data', 
               ha='center', va='center', fontsize=14, color=COLORS['text_secondary'])
        ax.axis('off')
        plt.savefig(output_path, dpi=150, bbox_inches='tight',
                    facecolor=COLORS['dark_bg'], edgecolor='none')
        plt.close()
        return output_path
    
    symbols = [f.get('symbol', 'UNK') for f in uoa]
    vol_oi = [f.get('volOiRatio', 1) for f in uoa]
    types = [f.get('type', 'CALL') for f in uoa]
    
    colors = [COLORS['positive'] if t == 'CALL' else COLORS['negative'] for t in types]
    
    y_pos = np.arange(len(symbols))
    bars = ax.barh(y_pos, vol_oi, color=colors, edgecolor='none', alpha=0.85, height=0.6)
    
    for i, (bar, flow) in enumerate(zip(bars, uoa)):
        strike = flow.get('strike', 0)
        flow_type = flow.get('type', 'CALL')
        vol_oi_val = flow.get('volOiRatio', 1)
        
        label = f"${strike} {flow_type} ({vol_oi_val:.1f}x)"
        ax.text(vol_oi_val + 0.1, i, label, va='center', ha='left',
               fontsize=9, color=COLORS['text_primary'])
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(symbols, fontsize=10, fontweight='bold')
    ax.set_xlabel('Volume/OI Ratio', fontsize=10)
    ax.set_title('UNUSUAL OPTIONS ACTIVITY', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=COLORS['positive'], label='CALLS'),
        Patch(facecolor=COLORS['negative'], label='PUTS'),
    ]
    ax.legend(handles=legend_elements, loc='lower right', framealpha=0.9)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.xaxis.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ Options Flow saved: {output_path}")
    return output_path


# ============================================
# DYNAMIC CHART: GROWTH VS VALUE
# ============================================
def create_growth_value_chart(data, output_path, api_key=None):
    """QQQ vs IWM spread"""
    print("📊 Creating Growth vs Value Chart...")
    
    qqq_hist = fetch_historical_data('QQQ', 5, api_key)
    iwm_hist = fetch_historical_data('IWM', 5, api_key)
    
    if not qqq_hist or not iwm_hist:
        return create_growth_value_fallback(data, output_path)
    
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    def normalize(prices):
        if not prices or prices[0] == 0:
            return prices
        return [(p / prices[0] - 1) * 100 for p in prices]
    
    dates = qqq_hist['dates']
    qqq_norm = normalize(qqq_hist['close'])
    iwm_norm = normalize(iwm_hist['close'])
    spread = [q - i for q, i in zip(qqq_norm, iwm_norm)]
    
    ax.plot(dates, qqq_norm, color=COLORS['qqq_color'], linewidth=2.5,
            label=f"QQQ (Growth) {qqq_norm[-1]:+.2f}%", marker='o', markersize=4)
    ax.plot(dates, iwm_norm, color=COLORS['iwm_color'], linewidth=2.5,
            label=f"IWM (Value) {iwm_norm[-1]:+.2f}%", marker='s', markersize=4)
    
    ax.fill_between(dates, qqq_norm, iwm_norm, alpha=0.2,
                   color=COLORS['positive'] if spread[-1] > 0 else COLORS['negative'])
    
    ax.axhline(y=0, color=COLORS['gold'], linewidth=1, alpha=0.5, linestyle='--')
    
    spread_color = COLORS['positive'] if spread[-1] > 0 else COLORS['negative']
    leadership = "Growth Leading" if spread[-1] > 0 else "Value Leading"
    ax.text(0.98, 0.98, f'{leadership}: {spread[-1]:+.2f}%', transform=ax.transAxes,
           ha='right', va='top', fontsize=11, fontweight='bold',
           color=spread_color,
           bbox=dict(boxstyle='round', facecolor=COLORS['dark_card'], alpha=0.8))
    
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %d'))
    ax.set_ylabel('% Change', fontsize=10)
    ax.set_title('GROWTH VS VALUE — 5 Day Spread', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    ax.legend(loc='upper left', framealpha=0.9)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.yaxis.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    print(f"   ✅ Growth vs Value saved: {output_path}")
    return output_path


def create_growth_value_fallback(data, output_path):
    """Fallback when historical data unavailable"""
    fig, ax = plt.subplots(figsize=(8, 4), dpi=150)
    
    qqq = data.get('indices', {}).get('qqq', {}).get('changePercent', 0)
    iwm = data.get('indices', {}).get('iwm', {}).get('changePercent', 0)
    spy = data.get('indices', {}).get('spy', {}).get('changePercent', 0)
    
    indices = ['QQQ\n(Growth)', 'SPY\n(Blend)', 'IWM\n(Value)']
    changes = [qqq, spy, iwm]
    colors = [COLORS['qqq_color'], COLORS['spy_color'], COLORS['iwm_color']]
    
    bars = ax.bar(indices, changes, color=colors, edgecolor='none', alpha=0.85, width=0.5)
    
    for bar, change in zip(bars, changes):
        height = bar.get_height()
        sign = '+' if change >= 0 else ''
        ax.text(bar.get_x() + bar.get_width()/2, height + 0.05,
               f'{sign}{change:.2f}%', ha='center', va='bottom',
               fontsize=11, fontweight='bold', color=COLORS['text_primary'])
    
    ax.axhline(y=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_ylabel('Daily Change (%)', fontsize=10)
    ax.set_title('GROWTH VS VALUE — Today', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.yaxis.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# MAIN CHART ORCHESTRATOR
# ============================================
CHART_GENERATORS = {
    'market_overview': create_market_overview_chart,
    'yield_curve': create_yield_curve_chart,
    'cta_positioning': create_cta_positioning_chart,
    'sector_rotation': create_sector_rotation_chart,
    'vix_regime': create_vix_regime_chart,
    'options_heatmap': create_options_flow_chart,
    'growth_value_spread': create_growth_value_chart,
}


def generate_charts(market_data, chart_recommendations, output_dir, api_key=None):
    """Generate charts based on recommendations"""
    os.makedirs(output_dir, exist_ok=True)
    
    charts = {}
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 1. ALWAYS generate Market Overview (FIXED CHART)
    overview_path = os.path.join(output_dir, f'market_overview_{timestamp}.png')
    try:
        charts['market_overview'] = create_market_overview_chart(market_data, overview_path, api_key)
    except Exception as e:
        print(f"❌ Market Overview failed: {e}")
    
    # 2. Generate dynamic charts based on recommendations
    for rec in chart_recommendations:
        chart_type = rec.get('chartType')
        if chart_type in CHART_GENERATORS and chart_type != 'market_overview':
            try:
                path = os.path.join(output_dir, f'{chart_type}_{timestamp}.png')
                generator = CHART_GENERATORS[chart_type]
                
                if chart_type in ['growth_value_spread']:
                    result = generator(market_data, path, api_key)
                else:
                    result = generator(market_data, path)
                
                if result:
                    charts[chart_type] = result
                    
            except Exception as e:
                print(f"❌ {chart_type} failed: {e}")
    
    return charts


# ============================================
# CLI INTERFACE
# ============================================
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate Finotaur Newsletter Charts v2')
    parser.add_argument('--data', type=str, help='Path to market data JSON')
    parser.add_argument('--themes', type=str, help='Path to theme recommendations JSON')
    parser.add_argument('--output', type=str, default='./charts', help='Output directory')
    parser.add_argument('--demo', action='store_true', help='Generate demo charts')
    parser.add_argument('--api-key', type=str, help='Polygon API key')
    
    args = parser.parse_args()
    
    api_key = args.api_key or os.environ.get('POLYGON_API_KEY')
    
    if args.demo:
        print('\n🎨 Generating Demo Charts v2...\n')
        
        demo_data = {
            'indices': {
                'spy': {'price': 607.25, 'changePercent': 0.85},
                'qqq': {'price': 525.80, 'changePercent': 1.23},
                'iwm': {'price': 238.90, 'changePercent': -0.18},
                'dia': {'price': 448.50, 'changePercent': 0.42},
                'vix': {'price': 16.5, 'changePercent': 8.2},
            },
            'rates': {
                'us02y': {'yield': 4.52},
                'us10y': {'yield': 4.38},
                'us30y': {'yield': 4.55},
            },
            'sectors': [
                {'symbol': 'XLK', 'name': 'Technology', 'changePercent': 1.8},
                {'symbol': 'XLF', 'name': 'Financials', 'changePercent': 0.9},
                {'symbol': 'XLE', 'name': 'Energy', 'changePercent': -1.2},
                {'symbol': 'XLV', 'name': 'Healthcare', 'changePercent': 0.5},
                {'symbol': 'XLY', 'name': 'Consumer Disc', 'changePercent': 1.1},
                {'symbol': 'XLP', 'name': 'Consumer Staples', 'changePercent': -0.2},
                {'symbol': 'XLI', 'name': 'Industrials', 'changePercent': 0.3},
                {'symbol': 'XLU', 'name': 'Utilities', 'changePercent': -0.5},
            ],
            'positioningData': {
                'ctaPositioning': {
                    'trend': 'LONG',
                    'conviction': 'HIGH',
                    'spxCurrentLevel': 6070,
                    'spxAddLevel': 6130,
                    'spxFlatTrigger': 5890,
                    'spxShortTrigger': 5770,
                }
            },
            'uoa': [
                {'symbol': 'NVDA', 'type': 'CALL', 'strike': 150, 'volOiRatio': 3.5},
                {'symbol': 'TSLA', 'type': 'CALL', 'strike': 450, 'volOiRatio': 2.8},
                {'symbol': 'SPY', 'type': 'PUT', 'strike': 600, 'volOiRatio': 2.1},
                {'symbol': 'AAPL', 'type': 'CALL', 'strike': 250, 'volOiRatio': 1.9},
                {'symbol': 'AMD', 'type': 'CALL', 'strike': 180, 'volOiRatio': 1.7},
            ],
        }
        
        demo_recommendations = [
            {'chartType': 'yield_curve', 'section': 'MACRO_ARENA', 'importance': 0.8},
            {'chartType': 'cta_positioning', 'section': 'MARKET_STRUCTURE', 'importance': 0.75},
            {'chartType': 'sector_rotation', 'section': 'SECTOR_ROTATION', 'importance': 0.7},
            {'chartType': 'vix_regime', 'section': 'MARKET_PULSE', 'importance': 0.65},
        ]
        
        charts = generate_charts(demo_data, demo_recommendations, args.output, api_key)
        
        print(f'\n✅ Generated {len(charts)} charts in {args.output}/')
        for name, path in charts.items():
            print(f'   - {name}: {path}')
        
    elif args.data:
        with open(args.data, 'r') as f:
            market_data = json.load(f)
        
        recommendations = []
        if args.themes:
            with open(args.themes, 'r') as f:
                recommendations = json.load(f)
        
        charts = generate_charts(market_data, recommendations, args.output, api_key)
        
        print(f'\n✅ Generated {len(charts)} charts')
        print('\n--- CHART_PATHS_JSON ---')
        print(json.dumps(charts))
    
    else:
        parser.print_help()