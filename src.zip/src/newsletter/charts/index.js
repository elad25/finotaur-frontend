// ==========================================
// Newsletter Chart Generator - JavaScript Wrapper
// Integrates Python chart generator with Node.js
// ==========================================

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CHART_CONFIG = {
  pythonScript: path.join(__dirname, 'chart-generator.py'),
  outputDir: '/tmp/finotaur-charts',
  python: 'python3',
};

/**
 * Transform collector data to chart format
 */
export function transformMarketDataForCharts(collectorData) {
  const chartData = {};

  // 1. Indices
  if (collectorData.indices) {
    chartData.indices = {};
    const indexMap = {
      'SPY': 'SPY', '^GSPC': 'SPY', 'S&P 500': 'SPY',
      'QQQ': 'QQQ', '^NDX': 'QQQ', 'NASDAQ': 'QQQ',
      'DIA': 'DIA', '^DJI': 'DIA', 'Dow Jones': 'DIA',
      'IWM': 'IWM', '^RUT': 'IWM', 'Russell 2000': 'IWM',
    };

    for (const [key, data] of Object.entries(collectorData.indices)) {
      const symbol = indexMap[key] || key;
      if (['SPY', 'QQQ', 'DIA', 'IWM'].includes(symbol)) {
        chartData.indices[symbol] = {
          change_pct: data.changePercent || data.change_pct || 0,
          price: data.price || data.regularMarketPrice || 0,
        };
      }
    }
  }

  // 2. Sectors
  if (collectorData.sectors) {
    chartData.sectors = {};
    for (const [symbol, data] of Object.entries(collectorData.sectors)) {
      chartData.sectors[symbol] = {
        name: data.name || symbol,
        change_pct: data.changePercent || data.change_pct || 0,
      };
    }
  }

  // 3. VIX
  if (collectorData.vix) {
    chartData.vix = { value: collectorData.vix.price || collectorData.vix.value || 15 };
  } else if (collectorData.indices?.['^VIX']) {
    chartData.vix = { value: collectorData.indices['^VIX'].price || 15 };
  }

  // 4. Global Markets
  if (collectorData.global || collectorData.globalMarkets) {
    const global = collectorData.global || collectorData.globalMarkets;
    chartData.global = { asia: {}, europe: {} };

    const asiaKeys = ['Nikkei', 'Hang Seng', 'Shanghai', '^N225', '^HSI', '000001.SS'];
    const europeKeys = ['DAX', 'FTSE', 'CAC', '^GDAXI', '^FTSE', '^FCHI', 'STOXX'];

    for (const [key, data] of Object.entries(global)) {
      const change = data.changePercent || data.change_pct || 0;
      
      if (asiaKeys.some(m => key.includes(m))) {
        chartData.global.asia[key] = { change_pct: change };
      } else if (europeKeys.some(m => key.includes(m))) {
        chartData.global.europe[key] = { change_pct: change };
      }
    }
  }

  // 5. Assets
  chartData.assets = {};
  
  if (chartData.indices?.SPY) {
    chartData.assets.equities = {
      change_pct: chartData.indices.SPY.change_pct,
      label: 'S&P 500',
    };
  }

  if (collectorData.commodities?.gold || collectorData.commodities?.['GC=F']) {
    const gold = collectorData.commodities.gold || collectorData.commodities['GC=F'];
    chartData.assets.gold = {
      change_pct: gold.changePercent || gold.change_pct || 0,
      label: 'Gold',
    };
  }

  if (collectorData.commodities?.oil || collectorData.commodities?.['CL=F']) {
    const oil = collectorData.commodities.oil || collectorData.commodities['CL=F'];
    chartData.assets.oil = {
      change_pct: oil.changePercent || oil.change_pct || 0,
      label: 'WTI Crude',
    };
  }

  // 6. Crypto
  if (collectorData.crypto) {
    chartData.crypto = {};
    
    const btc = collectorData.crypto.BTC || collectorData.crypto['BTC-USD'];
    if (btc) {
      chartData.crypto.BTC = {
        price: btc.price || 0,
        change_pct: btc.changePercent || btc.change_pct || 0,
      };
      chartData.assets.bitcoin = {
        change_pct: btc.changePercent || btc.change_pct || 0,
        label: 'Bitcoin',
      };
    }
    
    const eth = collectorData.crypto.ETH || collectorData.crypto['ETH-USD'];
    if (eth) {
      chartData.crypto.ETH = {
        price: eth.price || 0,
        change_pct: eth.changePercent || eth.change_pct || 0,
      };
    }
  }

  return chartData;
}

/**
 * Generate all charts using Python
 */
export async function generateCharts(marketData, outputDir = CHART_CONFIG.outputDir) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    // Transform if needed
    const chartData = marketData.indices && marketData.sectors 
      ? marketData 
      : transformMarketDataForCharts(marketData);

    // Write temp data file
    const dataPath = path.join(outputDir, `data_${Date.now()}.json`);
    fs.writeFileSync(dataPath, JSON.stringify(chartData, null, 2));

    console.log('📊 Generating charts...');

    const python = spawn(CHART_CONFIG.python, [
      CHART_CONFIG.pythonScript,
      '--data', dataPath,
      '--output', outputDir,
    ]);

    let stdout = '';
    let stderr = '';

    python.stdout.on('data', (data) => {
      stdout += data.toString();
      console.log(data.toString().trim());
    });

    python.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    python.on('close', (code) => {
      // Cleanup
      try { fs.unlinkSync(dataPath); } catch (e) {}

      if (code === 0) {
        // Parse paths from output
        const chartPaths = {};
        const jsonMatch = stdout.match(/--- CHART_PATHS_JSON ---\n(.+)/s);
        
        if (jsonMatch) {
          try {
            Object.assign(chartPaths, JSON.parse(jsonMatch[1].trim()));
          } catch (e) {}
        }

        // Fallback: scan directory
        if (Object.keys(chartPaths).length === 0) {
          const files = fs.readdirSync(outputDir);
          for (const file of files) {
            if (file.endsWith('.png')) {
              const name = file.split('_')[0];
              chartPaths[name] = path.join(outputDir, file);
            }
          }
        }

        console.log(`✅ Generated ${Object.keys(chartPaths).length} charts`);
        resolve({ success: true, charts: chartPaths, outputDir });
      } else {
        console.error('❌ Chart generation failed:', stderr);
        reject(new Error(`Chart generation failed: ${stderr}`));
      }
    });

    python.on('error', (err) => {
      reject(err);
    });
  });
}

/**
 * Read chart as base64
 */
export function readChartAsBase64(chartPath) {
  if (!fs.existsSync(chartPath)) {
    throw new Error(`Chart not found: ${chartPath}`);
  }
  return fs.readFileSync(chartPath).toString('base64');
}

/**
 * Get chart as data URI
 */
export function getChartDataUri(chartPath) {
  return `data:image/png;base64,${readChartAsBase64(chartPath)}`;
}

/**
 * Generate charts with base64 data for email
 */
export async function generateChartsForEmail(marketData) {
  const result = await generateCharts(marketData);
  
  const chartsWithData = {};
  
  for (const [name, chartPath] of Object.entries(result.charts)) {
    try {
      chartsWithData[name] = {
        path: chartPath,
        base64: readChartAsBase64(chartPath),
        dataUri: getChartDataUri(chartPath),
      };
    } catch (e) {
      console.warn(`Could not read chart ${name}:`, e.message);
    }
  }
  
  return chartsWithData;
}

/**
 * Cleanup old charts
 */
export function cleanupOldCharts(outputDir = CHART_CONFIG.outputDir, maxAgeHours = 24) {
  const maxAge = maxAgeHours * 60 * 60 * 1000;
  const now = Date.now();

  try {
    if (!fs.existsSync(outputDir)) return;

    const files = fs.readdirSync(outputDir);
    let cleaned = 0;

    for (const file of files) {
      if (file.endsWith('.png') || file.endsWith('.json')) {
        const filePath = path.join(outputDir, file);
        const stats = fs.statSync(filePath);

        if (now - stats.mtimeMs > maxAge) {
          fs.unlinkSync(filePath);
          cleaned++;
        }
      }
    }

    if (cleaned > 0) {
      console.log(`🧹 Cleaned ${cleaned} old chart files`);
    }
  } catch (e) {}
}

export default {
  generateCharts,
  generateChartsForEmail,
  transformMarketDataForCharts,
  readChartAsBase64,
  getChartDataUri,
  cleanupOldCharts,
};