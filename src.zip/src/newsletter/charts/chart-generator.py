# -*- coding: utf-8 -*-
"""
Finotaur Newsletter Chart Generator
===================================
Professional, institutional-grade charts for market reports.
Goldman Sachs / JPMorgan style design.

Usage:
    python chart-generator.py --data market_data.json --output ./charts/
    python chart-generator.py --demo --output ./demo_charts/
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Wedge
import numpy as np
import json
import sys
import os
from datetime import datetime

# ============================================
# FINOTAUR COLOR PALETTE
# ============================================
COLORS = {
    'gold': '#C9A646',
    'gold_light': '#E5D59A',
    'gold_dark': '#8B7030',
    'dark_bg': '#0d0d18',
    'dark_accent': '#1a1a2e',
    'dark_card': '#252540',
    'text_primary': '#ffffff',
    'text_secondary': '#9ca3af',
    'text_muted': '#6b7280',
    'positive': '#10b981',
    'positive_light': '#34d399',
    'negative': '#ef4444',
    'negative_light': '#f87171',
    'neutral': '#6b7280',
    'warning': '#f59e0b',
}

# ============================================
# MATPLOTLIB CONFIGURATION
# ============================================
plt.rcParams.update({
    'figure.facecolor': COLORS['dark_bg'],
    'axes.facecolor': COLORS['dark_accent'],
    'axes.edgecolor': COLORS['gold'],
    'axes.labelcolor': COLORS['text_primary'],
    'axes.titlecolor': COLORS['gold'],
    'xtick.color': COLORS['text_secondary'],
    'ytick.color': COLORS['text_secondary'],
    'text.color': COLORS['text_primary'],
    'grid.color': COLORS['dark_card'],
    'grid.alpha': 0.5,
    'font.family': 'sans-serif',
    'font.sans-serif': ['Helvetica', 'Arial', 'DejaVu Sans'],
    'font.size': 10,
    'axes.titlesize': 14,
    'axes.labelsize': 11,
    'legend.facecolor': COLORS['dark_accent'],
    'legend.edgecolor': COLORS['gold'],
    'legend.labelcolor': COLORS['text_primary'],
})


# ============================================
# CHART 1: MARKET INDICES
# ============================================
def create_market_indices_chart(data, output_path):
    """
    Horizontal bar chart showing major US indices performance.
    """
    fig, ax = plt.subplots(figsize=(8, 4), dpi=150)
    
    indices = ['S&P 500', 'NASDAQ 100', 'Dow Jones', 'Russell 2000']
    symbols = ['SPY', 'QQQ', 'DIA', 'IWM']
    
    changes = []
    prices = []
    for sym in symbols:
        if sym in data:
            changes.append(data[sym].get('change_pct', 0))
            prices.append(data[sym].get('price', 0))
        else:
            changes.append(0)
            prices.append(0)
    
    colors = [COLORS['positive'] if c >= 0 else COLORS['negative'] for c in changes]
    y_pos = np.arange(len(indices))
    
    bars = ax.barh(y_pos, changes, height=0.6, color=colors, edgecolor='none', alpha=0.9)
    
    for i, (bar, change, price) in enumerate(zip(bars, changes, prices)):
        sign = '+' if change >= 0 else ''
        label = f'{sign}{change:.2f}%'
        
        if change >= 0:
            ax.text(change + 0.1, i, label, va='center', ha='left', 
                   fontweight='bold', color=COLORS['positive'], fontsize=11)
        else:
            ax.text(change - 0.1, i, label, va='center', ha='right',
                   fontweight='bold', color=COLORS['negative'], fontsize=11)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(indices, fontsize=11, fontweight='bold')
    ax.axvline(x=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_xlabel('Daily Change (%)', fontsize=10)
    ax.set_title('U.S. MARKET INDICES', fontsize=14, fontweight='bold', 
                color=COLORS['gold'], pad=15)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color(COLORS['gold'])
    ax.spines['bottom'].set_color(COLORS['gold'])
    
    ax.xaxis.grid(True, alpha=0.3, linestyle='--')
    ax.set_axisbelow(True)
    
    max_abs = max(abs(min(changes)) if changes else 1, abs(max(changes)) if changes else 1, 1)
    ax.set_xlim(-max_abs * 1.5, max_abs * 1.5)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight', 
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# CHART 2: SECTOR HEATMAP
# ============================================
def create_sector_heatmap(data, output_path):
    """
    Grid heatmap showing sector performance.
    """
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    sectors = [
        ('XLK', 'Tech'),
        ('XLV', 'Health'),
        ('XLF', 'Finance'),
        ('XLE', 'Energy'),
        ('XLI', 'Industrial'),
        ('XLY', 'Cons Disc'),
        ('XLP', 'Cons Stap'),
        ('XLU', 'Utilities'),
        ('XLRE', 'Real Est'),
        ('XLB', 'Materials'),
        ('XLC', 'Comms'),
    ]
    
    n_cols = 6
    n_rows = 2
    box_width = 1.0
    box_height = 0.8
    gap = 0.1
    
    changes = [data.get(s[0], {}).get('change_pct', 0) for s in sectors]
    max_change = max(abs(min(changes)) if changes else 1, abs(max(changes)) if changes else 1, 1)
    
    for i, (symbol, name) in enumerate(sectors):
        row = i // n_cols
        col = i % n_cols
        
        x = col * (box_width + gap)
        y = (n_rows - 1 - row) * (box_height + gap)
        
        change = data.get(symbol, {}).get('change_pct', 0)
        
        if change >= 0:
            intensity = min(change / max_change, 1)
            color = plt.cm.Greens(0.3 + intensity * 0.5)
        else:
            intensity = min(abs(change) / max_change, 1)
            color = plt.cm.Reds(0.3 + intensity * 0.5)
        
        rect = FancyBboxPatch(
            (x, y), box_width, box_height,
            boxstyle="round,pad=0.02,rounding_size=0.1",
            facecolor=color,
            edgecolor=COLORS['gold'],
            linewidth=1,
            alpha=0.9
        )
        ax.add_patch(rect)
        
        ax.text(x + box_width/2, y + box_height * 0.65, name,
               ha='center', va='center', fontsize=10, fontweight='bold',
               color='white')
        
        sign = '+' if change >= 0 else ''
        ax.text(x + box_width/2, y + box_height * 0.3, f'{sign}{change:.1f}%',
               ha='center', va='center', fontsize=12, fontweight='bold',
               color='white')
    
    ax.set_xlim(-0.2, n_cols * (box_width + gap))
    ax.set_ylim(-0.2, n_rows * (box_height + gap))
    ax.set_aspect('equal')
    ax.axis('off')
    
    ax.set_title('SECTOR PERFORMANCE', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# CHART 3: VIX GAUGE
# ============================================
def create_vix_gauge(vix_value, output_path):
    """
    Semi-circular gauge showing VIX level with fear/greed zones.
    """
    fig, ax = plt.subplots(figsize=(6, 4), dpi=150)
    
    center = (0.5, 0.3)
    radius = 0.4
    
    zones = [
        (0, 12, '#10b981', 'Greed'),
        (12, 20, '#34d399', 'Low Vol'),
        (20, 25, '#fbbf24', 'Moderate'),
        (25, 30, '#f97316', 'Elevated'),
        (30, 50, '#ef4444', 'Fear'),
    ]
    
    for start_val, end_val, color, label in zones:
        start_angle = 180 - (start_val / 50) * 180
        end_angle = 180 - (end_val / 50) * 180
        
        wedge = Wedge(center, radius, end_angle, start_angle, width=0.12,
                     facecolor=color, edgecolor='none', alpha=0.8)
        ax.add_patch(wedge)
    
    outer_ring = Wedge(center, radius + 0.02, 0, 180, width=0.02,
                      facecolor='none', edgecolor=COLORS['gold'], linewidth=2)
    ax.add_patch(outer_ring)
    
    vix_clamped = max(0, min(vix_value, 50))
    needle_angle = 180 - (vix_clamped / 50) * 180
    needle_angle_rad = np.radians(needle_angle)
    
    needle_length = radius - 0.05
    needle_x = center[0] + needle_length * np.cos(needle_angle_rad)
    needle_y = center[1] + needle_length * np.sin(needle_angle_rad)
    
    ax.annotate('', xy=(needle_x, needle_y), xytext=center,
               arrowprops=dict(arrowstyle='->', color=COLORS['gold'],
                             lw=3, mutation_scale=15))
    
    center_circle = plt.Circle(center, 0.05, facecolor=COLORS['dark_card'], 
                              edgecolor=COLORS['gold'], linewidth=2)
    ax.add_patch(center_circle)
    
    ax.text(center[0], center[1] - 0.15, f'{vix_value:.1f}',
           ha='center', va='top', fontsize=28, fontweight='bold',
           color=COLORS['gold'])
    
    ax.text(center[0], center[1] - 0.25, 'VIX',
           ha='center', va='top', fontsize=12, fontweight='bold',
           color=COLORS['text_secondary'])
    
    ax.text(0.08, 0.25, 'GREED', fontsize=8, color=COLORS['positive'], fontweight='bold')
    ax.text(0.85, 0.25, 'FEAR', fontsize=8, color=COLORS['negative'], fontweight='bold')
    
    ax.set_title('VIX FEAR & GREED GAUGE', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=10)
    
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 0.7)
    ax.set_aspect('equal')
    ax.axis('off')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# CHART 4: GLOBAL MARKETS
# ============================================
def create_global_markets_chart(data, output_path):
    """
    Grouped bar chart showing global market performance.
    """
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    
    markets = []
    regions = []
    changes = []
    
    region_order = ['asia', 'europe']
    region_labels = {'asia': 'Asia', 'europe': 'Europe'}
    region_colors = {'asia': '#f97316', 'europe': '#3b82f6'}
    
    for region in region_order:
        if region in data:
            for market_name, market_data in data[region].items():
                markets.append(market_name)
                regions.append(region)
                changes.append(market_data.get('change_pct', 0))
    
    if not markets:
        plt.close()
        return None
    
    x = np.arange(len(markets))
    
    bar_colors = []
    for i, (region, change) in enumerate(zip(regions, changes)):
        if change < 0:
            bar_colors.append(COLORS['negative'])
        else:
            bar_colors.append(region_colors[region])
    
    bars = ax.bar(x, changes, color=bar_colors, edgecolor='none', alpha=0.9, width=0.7)
    
    for bar, change in zip(bars, changes):
        height = bar.get_height()
        sign = '+' if change >= 0 else ''
        va = 'bottom' if change >= 0 else 'top'
        offset = 0.1 if change >= 0 else -0.1
        color = COLORS['positive'] if change >= 0 else COLORS['negative']
        
        ax.text(bar.get_x() + bar.get_width()/2, height + offset,
               f'{sign}{change:.1f}%', ha='center', va=va,
               fontsize=10, fontweight='bold', color=color)
    
    ax.set_xticks(x)
    ax.set_xticklabels(markets, rotation=45, ha='right', fontsize=10)
    ax.axhline(y=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_ylabel('Daily Change (%)', fontsize=10)
    ax.set_title('GLOBAL MARKETS OVERVIEW', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    current_region = regions[0] if regions else None
    for i, region in enumerate(regions):
        if region != current_region:
            ax.axvline(x=i - 0.5, color=COLORS['gold'], linewidth=1, 
                      linestyle='--', alpha=0.3)
            current_region = region
    
    legend_patches = [mpatches.Patch(color=region_colors[region], label=region_labels[region])
                     for region in region_order if region in data]
    ax.legend(handles=legend_patches, loc='upper right', framealpha=0.9)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color(COLORS['gold'])
    ax.spines['bottom'].set_color(COLORS['gold'])
    
    ax.yaxis.grid(True, alpha=0.3, linestyle='--')
    ax.set_axisbelow(True)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# CHART 5: ASSET CLASS COMPARISON
# ============================================
def create_asset_comparison_chart(data, output_path):
    """
    Comparison chart for different asset classes.
    """
    fig, ax = plt.subplots(figsize=(8, 5), dpi=150)
    
    asset_config = {
        'equities': {'color': '#3b82f6'},
        'bonds': {'color': '#8b5cf6'},
        'gold': {'color': '#fbbf24'},
        'oil': {'color': '#f97316'},
        'bitcoin': {'color': '#f7931a'},
    }
    
    labels = []
    changes = []
    colors = []
    
    for asset_key in ['equities', 'bonds', 'gold', 'oil', 'bitcoin']:
        if asset_key in data:
            asset_data = data[asset_key]
            labels.append(asset_data.get('label', asset_key.title()))
            change = asset_data.get('change_pct', 0)
            changes.append(change)
            
            config = asset_config.get(asset_key, {'color': '#6b7280'})
            if change >= 0:
                colors.append(config['color'])
            else:
                colors.append(COLORS['negative'])
    
    if not labels:
        plt.close()
        return None
    
    y_pos = np.arange(len(labels))
    
    bars = ax.barh(y_pos, changes, height=0.6, color=colors, edgecolor='none', alpha=0.9)
    
    for i, (bar, change, label) in enumerate(zip(bars, changes, labels)):
        sign = '+' if change >= 0 else ''
        value_label = f'{sign}{change:.1f}%'
        
        if change >= 0:
            ax.text(change + 0.15, i, value_label, va='center', ha='left',
                   fontweight='bold', color=COLORS['positive'], fontsize=11)
        else:
            ax.text(change - 0.15, i, value_label, va='center', ha='right',
                   fontweight='bold', color=COLORS['negative'], fontsize=11)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=11, fontweight='bold')
    
    ax.axvline(x=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_xlabel('Daily Change (%)', fontsize=10)
    ax.set_title('ASSET CLASS PERFORMANCE', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color(COLORS['gold'])
    ax.spines['bottom'].set_color(COLORS['gold'])
    
    ax.xaxis.grid(True, alpha=0.3, linestyle='--')
    ax.set_axisbelow(True)
    
    max_abs = max(abs(min(changes)) if changes else 1, abs(max(changes)) if changes else 1, 1)
    ax.set_xlim(-max_abs * 1.5, max_abs * 1.5)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# CHART 6: CRYPTO
# ============================================
def create_crypto_chart(data, output_path):
    """
    Cryptocurrency performance chart.
    """
    fig, ax = plt.subplots(figsize=(6, 4), dpi=150)
    
    crypto_config = {
        'BTC': {'name': 'Bitcoin', 'color': '#f7931a'},
        'ETH': {'name': 'Ethereum', 'color': '#627eea'},
    }
    
    cryptos = []
    prices = []
    changes = []
    colors = []
    
    for symbol in ['BTC', 'ETH']:
        if symbol in data:
            cryptos.append(symbol)
            prices.append(data[symbol].get('price', 0))
            changes.append(data[symbol].get('change_pct', 0))
            colors.append(crypto_config[symbol]['color'])
    
    if not cryptos:
        plt.close()
        return None
    
    x = np.arange(len(cryptos))
    bars = ax.bar(x, changes, color=colors, edgecolor='none', alpha=0.9, width=0.5)
    
    for bar, change, price in zip(bars, changes, prices):
        height = bar.get_height()
        sign = '+' if change >= 0 else ''
        color = COLORS['positive'] if change >= 0 else COLORS['negative']
        
        ax.text(bar.get_x() + bar.get_width()/2, height + 0.2,
               f'{sign}{change:.1f}%', ha='center', va='bottom',
               fontsize=14, fontweight='bold', color=color)
        
        ax.text(bar.get_x() + bar.get_width()/2, 0.1,
               f'${price:,.0f}', ha='center', va='bottom',
               fontsize=10, color=COLORS['text_secondary'])
    
    ax.set_xticks(x)
    ax.set_xticklabels(cryptos, fontsize=14, fontweight='bold')
    
    ax.axhline(y=0, color=COLORS['gold'], linewidth=1, alpha=0.5)
    ax.set_ylabel('24h Change (%)', fontsize=10)
    ax.set_title('CRYPTO CORNER', fontsize=14, fontweight='bold',
                color=COLORS['gold'], pad=15)
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color(COLORS['gold'])
    ax.spines['bottom'].set_color(COLORS['gold'])
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor=COLORS['dark_bg'], edgecolor='none')
    plt.close()
    
    return output_path


# ============================================
# MAIN: GENERATE ALL CHARTS
# ============================================
def generate_all_charts(market_data, output_dir):
    """
    Generate all charts from market data.
    Returns dict of chart paths.
    """
    os.makedirs(output_dir, exist_ok=True)
    
    charts = {}
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 1. Market Indices
    if 'indices' in market_data:
        path = os.path.join(output_dir, f'market_indices_{timestamp}.png')
        result = create_market_indices_chart(market_data['indices'], path)
        if result:
            charts['market_indices'] = path
            print(f'✅ Created: market_indices')
    
    # 2. Sector Heatmap
    if 'sectors' in market_data:
        path = os.path.join(output_dir, f'sector_heatmap_{timestamp}.png')
        result = create_sector_heatmap(market_data['sectors'], path)
        if result:
            charts['sector_heatmap'] = path
            print(f'✅ Created: sector_heatmap')
    
    # 3. VIX Gauge
    if 'vix' in market_data:
        path = os.path.join(output_dir, f'vix_gauge_{timestamp}.png')
        vix_value = market_data['vix'].get('value', market_data['vix'].get('price', 15))
        result = create_vix_gauge(vix_value, path)
        if result:
            charts['vix_gauge'] = path
            print(f'✅ Created: vix_gauge')
    
    # 4. Global Markets
    if 'global' in market_data:
        path = os.path.join(output_dir, f'global_markets_{timestamp}.png')
        result = create_global_markets_chart(market_data['global'], path)
        if result:
            charts['global_markets'] = path
            print(f'✅ Created: global_markets')
    
    # 5. Asset Comparison
    if 'assets' in market_data:
        path = os.path.join(output_dir, f'asset_comparison_{timestamp}.png')
        result = create_asset_comparison_chart(market_data['assets'], path)
        if result:
            charts['asset_comparison'] = path
            print(f'✅ Created: asset_comparison')
    
    # 6. Crypto
    if 'crypto' in market_data:
        path = os.path.join(output_dir, f'crypto_{timestamp}.png')
        result = create_crypto_chart(market_data['crypto'], path)
        if result:
            charts['crypto'] = path
            print(f'✅ Created: crypto')
    
    return charts


# ============================================
# CLI INTERFACE
# ============================================
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate Finotaur Newsletter Charts')
    parser.add_argument('--data', type=str, help='Path to market data JSON file')
    parser.add_argument('--output', type=str, default='./charts', help='Output directory')
    parser.add_argument('--demo', action='store_true', help='Generate demo charts')
    
    args = parser.parse_args()
    
    if args.demo:
        demo_data = {
            'indices': {
                'SPY': {'change_pct': 0.85, 'price': 607.25},
                'QQQ': {'change_pct': 1.23, 'price': 525.80},
                'DIA': {'change_pct': 0.42, 'price': 448.50},
                'IWM': {'change_pct': -0.18, 'price': 238.90},
            },
            'sectors': {
                'XLK': {'name': 'Technology', 'change_pct': 1.8},
                'XLV': {'name': 'Healthcare', 'change_pct': 0.5},
                'XLF': {'name': 'Financials', 'change_pct': 0.9},
                'XLE': {'name': 'Energy', 'change_pct': -1.2},
                'XLI': {'name': 'Industrials', 'change_pct': 0.3},
                'XLY': {'name': 'Consumer Disc', 'change_pct': 1.1},
                'XLP': {'name': 'Consumer Staples', 'change_pct': -0.2},
                'XLU': {'name': 'Utilities', 'change_pct': -0.5},
                'XLRE': {'name': 'Real Estate', 'change_pct': 0.1},
                'XLB': {'name': 'Materials', 'change_pct': 0.6},
                'XLC': {'name': 'Communications', 'change_pct': 1.4},
            },
            'vix': {'value': 14.2},
            'global': {
                'asia': {
                    'Nikkei 225': {'change_pct': 0.75},
                    'Hang Seng': {'change_pct': -0.82},
                    'Shanghai': {'change_pct': 0.31},
                },
                'europe': {
                    'DAX': {'change_pct': 1.05},
                    'FTSE 100': {'change_pct': 0.45},
                    'CAC 40': {'change_pct': 0.68},
                },
            },
            'assets': {
                'equities': {'change_pct': 0.85, 'label': 'S&P 500'},
                'bonds': {'change_pct': -0.15, 'label': '10Y Treasury'},
                'gold': {'change_pct': 0.42, 'label': 'Gold'},
                'oil': {'change_pct': -1.85, 'label': 'WTI Crude'},
                'bitcoin': {'change_pct': 2.35, 'label': 'Bitcoin'},
            },
            'crypto': {
                'BTC': {'price': 97500, 'change_pct': 2.35},
                'ETH': {'price': 3680, 'change_pct': 3.15},
            },
        }
        
        print('\n🎨 Generating Demo Charts...\n')
        charts = generate_all_charts(demo_data, args.output)
        print(f'\n✅ Generated {len(charts)} charts in {args.output}/')
        
    elif args.data:
        with open(args.data, 'r') as f:
            market_data = json.load(f)
        
        print('\n🎨 Generating Charts...\n')
        charts = generate_all_charts(market_data, args.output)
        print(f'\n✅ Generated {len(charts)} charts')
        
        # Output JSON for Node.js
        print('\n--- CHART_PATHS_JSON ---')
        print(json.dumps(charts))
        
    else:
        parser.print_help()