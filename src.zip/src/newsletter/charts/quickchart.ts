// ==========================================
// QuickChart.io Integration
// Generates chart URLs for email newsletters
// Version 5.0
// ==========================================

const QUICKCHART_BASE = 'https://quickchart.io/chart';

// Finotaur color scheme
const COLORS = {
  background: '#0d0d18',
  gold: '#C9A646',
  positive: '#10b981',
  negative: '#ef4444',
  neutral: '#6b7280',
  text: '#ffffff',
  grid: '#2d2d3d'
};

interface IndexData {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
}

interface SectorData {
  sector: string;
  etf: string;
  performance: number;
}

interface AssetData {
  name: string;
  price: number;
  changePercent: number;
}

interface CryptoData {
  symbol: string;
  price: number;
  changePercent24h: number;
}

interface MarketData {
  name: string;
  price: number;
  changePercent: number;
}

// ============================================
// CHART GENERATORS
// ============================================

export function generateIndicesChartUrl(indices: IndexData[]): string {
  if (!indices || indices.length === 0) return '';

  const labels = indices.map(i => i.symbol);
  const data = indices.map(i => i.changePercent);
  const colors = data.map(d => d >= 0 ? COLORS.positive : COLORS.negative);

  const config = {
    type: 'horizontalBar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1
      }]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Major Indices Performance',
        fontColor: COLORS.text,
        fontSize: 14
      },
      scales: {
        xAxes: [{
          ticks: { fontColor: COLORS.text, callback: (v: number) => v + '%' },
          gridLines: { color: COLORS.grid }
        }],
        yAxes: [{
          ticks: { fontColor: COLORS.text },
          gridLines: { color: COLORS.grid }
        }]
      },
      plugins: {
        datalabels: {
          anchor: 'end',
          align: 'end',
          color: COLORS.text,
          formatter: (v: number) => v.toFixed(2) + '%'
        }
      }
    }
  };

  return `${QUICKCHART_BASE}?c=${encodeURIComponent(JSON.stringify(config))}&w=500&h=300&bkg=${encodeURIComponent(COLORS.background)}`;
}

export function generateSectorChartUrl(sectors: SectorData[]): string {
  if (!sectors || sectors.length === 0) return '';

  // Sort by performance
  const sorted = [...sectors].sort((a, b) => b.performance - a.performance);
  
  const labels = sorted.map(s => s.sector.replace('_', ' '));
  const data = sorted.map(s => s.performance);
  const colors = data.map(d => d >= 0 ? COLORS.positive : COLORS.negative);

  const config = {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1
      }]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Sector Performance',
        fontColor: COLORS.text,
        fontSize: 14
      },
      scales: {
        xAxes: [{
          ticks: { fontColor: COLORS.text, maxRotation: 45, minRotation: 45 },
          gridLines: { color: COLORS.grid }
        }],
        yAxes: [{
          ticks: { fontColor: COLORS.text, callback: (v: number) => v + '%' },
          gridLines: { color: COLORS.grid }
        }]
      }
    }
  };

  return `${QUICKCHART_BASE}?c=${encodeURIComponent(JSON.stringify(config))}&w=700&h=350&bkg=${encodeURIComponent(COLORS.background)}`;
}

export function generateVixGaugeUrl(vixValue: number): string {
  if (!vixValue) return '';

  // VIX zones: green <18, yellow 18-25, red >25
  let color = COLORS.positive;
  let label = 'Low';
  if (vixValue >= 25) {
    color = COLORS.negative;
    label = 'High';
  } else if (vixValue >= 18) {
    color = COLORS.gold;
    label = 'Elevated';
  }

  const config = {
    type: 'radialGauge',
    data: {
      datasets: [{
        data: [vixValue],
        backgroundColor: color,
        borderWidth: 0
      }]
    },
    options: {
      domain: [0, 50],
      trackColor: COLORS.grid,
      centerPercentage: 80,
      centerArea: {
        text: (val: number) => val.toFixed(1),
        fontColor: COLORS.text,
        fontSize: 32
      },
      title: {
        display: true,
        text: `VIX - ${label}`,
        fontColor: COLORS.text,
        fontSize: 14
      }
    }
  };

  return `${QUICKCHART_BASE}?c=${encodeURIComponent(JSON.stringify(config))}&w=300&h=250&bkg=${encodeURIComponent(COLORS.background)}`;
}

export function generateAssetComparisonUrl(assets: AssetData[]): string {
  if (!assets || assets.length === 0) return '';

  const labels = assets.map(a => a.name);
  const data = assets.map(a => a.changePercent);
  const colors = data.map(d => d >= 0 ? COLORS.positive : COLORS.negative);

  const config = {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Change %',
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1
      }]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Asset Class Performance',
        fontColor: COLORS.text,
        fontSize: 14
      },
      scales: {
        xAxes: [{
          ticks: { fontColor: COLORS.text },
          gridLines: { color: COLORS.grid }
        }],
        yAxes: [{
          ticks: { fontColor: COLORS.text, callback: (v: number) => v + '%' },
          gridLines: { color: COLORS.grid }
        }]
      }
    }
  };

  return `${QUICKCHART_BASE}?c=${encodeURIComponent(JSON.stringify(config))}&w=500&h=300&bkg=${encodeURIComponent(COLORS.background)}`;
}

export function generateGlobalMarketsUrl(asia: MarketData[], europe: MarketData[]): string {
  const allMarkets = [
    ...(asia || []).map(m => ({ ...m, region: 'Asia' })),
    ...(europe || []).map(m => ({ ...m, region: 'Europe' }))
  ];

  if (allMarkets.length === 0) return '';

  const labels = allMarkets.map(m => m.name);
  const data = allMarkets.map(m => m.changePercent);
  const colors = data.map(d => d >= 0 ? COLORS.positive : COLORS.negative);

  const config = {
    type: 'horizontalBar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1
      }]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Global Markets',
        fontColor: COLORS.text,
        fontSize: 14
      },
      scales: {
        xAxes: [{
          ticks: { fontColor: COLORS.text, callback: (v: number) => v + '%' },
          gridLines: { color: COLORS.grid }
        }],
        yAxes: [{
          ticks: { fontColor: COLORS.text },
          gridLines: { color: COLORS.grid }
        }]
      }
    }
  };

  return `${QUICKCHART_BASE}?c=${encodeURIComponent(JSON.stringify(config))}&w=500&h=400&bkg=${encodeURIComponent(COLORS.background)}`;
}

export function generateCryptoChartUrl(crypto: CryptoData[]): string {
  if (!crypto || crypto.length === 0) return '';

  const labels = crypto.map(c => c.symbol);
  const data = crypto.map(c => c.changePercent24h);
  const colors = data.map(d => d >= 0 ? COLORS.positive : COLORS.negative);

  const config = {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: '24h Change',
        data,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 1
      }]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Crypto 24h Performance',
        fontColor: COLORS.text,
        fontSize: 14
      },
      scales: {
        xAxes: [{
          ticks: { fontColor: COLORS.text },
          gridLines: { color: COLORS.grid }
        }],
        yAxes: [{
          ticks: { fontColor: COLORS.text, callback: (v: number) => v + '%' },
          gridLines: { color: COLORS.grid }
        }]
      }
    }
  };

  return `${QUICKCHART_BASE}?c=${encodeURIComponent(JSON.stringify(config))}&w=400&h=300&bkg=${encodeURIComponent(COLORS.background)}`;
}

// ============================================
// MAIN GENERATOR
// ============================================

export interface ChartUrls {
  indices?: string;
  sectors?: string;
  vix?: string;
  assets?: string;
  globalMarkets?: string;
  crypto?: string;
}

export function generateAllChartUrls(marketData: any): ChartUrls {
  const chartUrls: ChartUrls = {};

  try {
    // Indices chart
    const indices = marketData.indices || marketData.marketIndices;
    if (indices?.length > 0) {
      chartUrls.indices = generateIndicesChartUrl(indices);
    }

    // Sectors chart
    const sectors = marketData.sectorPerformance || marketData.sectors;
    if (sectors?.length > 0) {
      const normalizedSectors = sectors.map((s: any) => ({
        sector: s.sector || s.name || s.symbol,
        etf: s.etf || s.symbol || '',
        performance: s.performance ?? s.changePercent ?? 0
      }));
      chartUrls.sectors = generateSectorChartUrl(normalizedSectors);
    }

    // VIX gauge
    const vix = marketData.volatility?.vix;
    const vixValue = typeof vix === 'number' ? vix : vix?.price;
    if (vixValue) {
      chartUrls.vix = generateVixGaugeUrl(vixValue);
    }

    // Commodities as assets
    if (marketData.commodities?.length > 0) {
      chartUrls.assets = generateAssetComparisonUrl(marketData.commodities);
    }

    // Global markets
    if (marketData.globalMarkets?.asia?.length > 0 || marketData.globalMarkets?.europe?.length > 0) {
      chartUrls.globalMarkets = generateGlobalMarketsUrl(
        marketData.globalMarkets?.asia || [],
        marketData.globalMarkets?.europe || []
      );
    }

    // Crypto
    if (marketData.crypto?.length > 0) {
      chartUrls.crypto = generateCryptoChartUrl(marketData.crypto);
    }

  } catch (error) {
    console.error('Error generating chart URLs:', error);
  }

  return chartUrls;
}

// ============================================
// HTML GENERATOR
// ============================================

export function generateChartsHtml(chartUrls: ChartUrls): string {
  const charts: string[] = [];

  if (chartUrls.indices) {
    charts.push(`
      <div style="margin: 20px 0; text-align: center;">
        <img src="${chartUrls.indices}" alt="Major Indices Performance" style="max-width: 100%; height: auto; border-radius: 8px;" />
      </div>
    `);
  }

  if (chartUrls.sectors) {
    charts.push(`
      <div style="margin: 20px 0; text-align: center;">
        <img src="${chartUrls.sectors}" alt="Sector Performance" style="max-width: 100%; height: auto; border-radius: 8px;" />
      </div>
    `);
  }

  if (chartUrls.vix) {
    charts.push(`
      <div style="margin: 20px 0; text-align: center;">
        <img src="${chartUrls.vix}" alt="VIX Gauge" style="max-width: 300px; height: auto; border-radius: 8px;" />
      </div>
    `);
  }

  if (chartUrls.globalMarkets) {
    charts.push(`
      <div style="margin: 20px 0; text-align: center;">
        <img src="${chartUrls.globalMarkets}" alt="Global Markets" style="max-width: 100%; height: auto; border-radius: 8px;" />
      </div>
    `);
  }

  if (chartUrls.crypto) {
    charts.push(`
      <div style="margin: 20px 0; text-align: center;">
        <img src="${chartUrls.crypto}" alt="Crypto Performance" style="max-width: 100%; height: auto; border-radius: 8px;" />
      </div>
    `);
  }

  return charts.join('\n');
}