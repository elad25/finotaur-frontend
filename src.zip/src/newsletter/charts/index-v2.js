// ==========================================
// Charts Module Index v2.0
// Exports all chart-related functionality
// ==========================================

// Theme Analysis
export { 
  analyzeReportThemes, 
  mapChartsToSections, 
  shouldGenerateChart,
  getThemeSummary,
  THEME_DEFINITIONS 
} from './theme-analyzer.js';

// Chart Orchestration
export {
  orchestrateCharts,
  prepareChartsForPDF,
  getChartInsertionPoints,
  readChartAsBase64,
  getChartDataUri,
  cleanupOldCharts,
  shouldGenerateCharts,
} from './chart-orchestrator.js';

// Legacy exports for backward compatibility
export {
  generateCharts,
  generateChartsForEmail,
  transformMarketDataForCharts,
} from './index-legacy.js';

// Default export
export default {
  // Analysis
  analyzeReportThemes,
  mapChartsToSections,
  getThemeSummary,
  
  // Orchestration
  orchestrateCharts,
  prepareChartsForPDF,
  getChartInsertionPoints,
  
  // Utilities
  readChartAsBase64,
  getChartDataUri,
  cleanupOldCharts,
  shouldGenerateCharts,
};