// ==========================================
// Theme Analyzer for Dynamic Chart Generation
// Analyzes report content to determine which charts to generate
// ==========================================

/**
 * Theme definitions with keywords and importance weights
 */
const THEME_DEFINITIONS = {
  // Macro/Rates themes
  yield_curve: {
    keywords: ['yield curve', 'curve steepening', 'curve flattening', 'inverted', '2s10s', '10y', '2y', 'treasury', 'bond'],
    weight: 1.2,
    chartType: 'yield_curve',
    section: 'MACRO_ARENA'
  },
  fed_policy: {
    keywords: ['fed', 'fomc', 'rate cut', 'rate hike', 'powell', 'inflation', 'cpi', 'pce', 'dovish', 'hawkish'],
    weight: 1.1,
    chartType: 'fed_expectations',
    section: 'MACRO_ARENA'
  },
  
  // Positioning/Flow themes
  cta_positioning: {
    keywords: ['cta', 'trend following', 'systematic', 'add level', 'flat trigger', 'short trigger'],
    weight: 1.3,
    chartType: 'cta_positioning',
    section: 'MARKET_STRUCTURE'
  },
  gamma_exposure: {
    keywords: ['gamma', 'dealer', 'gamma flip', 'positive gamma', 'negative gamma', 'vol selling', 'vol buying'],
    weight: 1.2,
    chartType: 'gamma_levels',
    section: 'MARKET_STRUCTURE'
  },
  options_flow: {
    keywords: ['unusual options', 'call sweep', 'put sweep', 'premium', 'open interest', 'vol/oi', 'smart money'],
    weight: 1.0,
    chartType: 'options_heatmap',
    section: 'OPTIONS_FLOW'
  },
  
  // Rotation themes
  sector_rotation: {
    keywords: ['rotation', 'sector', 'cyclical', 'defensive', 'growth to value', 'value to growth', 'leadership'],
    weight: 1.1,
    chartType: 'sector_rotation',
    section: 'SECTOR_ROTATION'
  },
  growth_value: {
    keywords: ['growth', 'value', 'qqq vs', 'tech vs', 'iwm vs', 'small cap', 'mega cap', 'broadening'],
    weight: 1.0,
    chartType: 'growth_value_spread',
    section: 'SECTOR_ROTATION'
  },
  
  // Cross-asset themes
  risk_sentiment: {
    keywords: ['risk on', 'risk off', 'safe haven', 'flight to safety', 'gold rally', 'yen strength', 'vix spike'],
    weight: 1.2,
    chartType: 'risk_sentiment',
    section: 'CROSS_ASSET'
  },
  commodity_move: {
    keywords: ['oil', 'crude', 'gold', 'copper', 'commodity', 'energy', 'wti', 'brent'],
    weight: 0.9,
    chartType: 'commodity_comparison',
    section: 'CROSS_ASSET'
  },
  crypto_correlation: {
    keywords: ['bitcoin', 'btc', 'crypto', 'ethereum', 'eth', 'correlation'],
    weight: 0.8,
    chartType: 'crypto_correlation',
    section: 'CROSS_ASSET'
  },
  
  // Technical themes
  breakout: {
    keywords: ['breakout', 'breakdown', 'new high', 'new low', 'resistance break', 'support break'],
    weight: 1.0,
    chartType: 'key_levels',
    section: 'TECHNICAL_LEVELS'
  },
  volatility_regime: {
    keywords: ['vix', 'volatility', 'fear', 'complacency', 'vol crush', 'vol expansion'],
    weight: 1.1,
    chartType: 'vix_regime',
    section: 'MARKET_PULSE'
  }
};

/**
 * Analyze report text and extract themes with importance scores
 */
export function analyzeReportThemes(reportText, marketData = null) {
  if (!reportText || typeof reportText !== 'string') {
    return { themes: [], primaryTheme: null, chartRecommendations: [] };
  }

  const lowerText = reportText.toLowerCase();
  const themes = [];

  // Score each theme based on keyword presence and frequency
  for (const [themeName, definition] of Object.entries(THEME_DEFINITIONS)) {
    let score = 0;
    let matchCount = 0;
    const matchedKeywords = [];

    for (const keyword of definition.keywords) {
      const regex = new RegExp(keyword.toLowerCase(), 'gi');
      const matches = lowerText.match(regex);
      
      if (matches) {
        matchCount += matches.length;
        matchedKeywords.push(keyword);
        // Diminishing returns for repeated keywords
        score += Math.log2(matches.length + 1) * definition.weight;
      }
    }

    // Normalize score (0-1 range)
    const normalizedScore = Math.min(score / 10, 1);

    if (normalizedScore > 0.15) { // Minimum threshold
      themes.push({
        name: themeName,
        score: +normalizedScore.toFixed(3),
        matchCount,
        matchedKeywords,
        chartType: definition.chartType,
        section: definition.section,
        weight: definition.weight
      });
    }
  }

  // Sort by score descending
  themes.sort((a, b) => b.score - a.score);

  // Determine primary theme
  const primaryTheme = themes.length > 0 ? themes[0] : null;

  // Generate chart recommendations (themes with score > 0.5)
  const chartRecommendations = themes
    .filter(t => t.score > 0.5)
    .map(t => ({
      chartType: t.chartType,
      section: t.section,
      importance: t.score,
      reason: `High relevance: ${t.matchedKeywords.slice(0, 3).join(', ')}`
    }));

  // Add context-specific recommendations based on market data
  if (marketData) {
    const additionalCharts = getContextualCharts(marketData, themes);
    chartRecommendations.push(...additionalCharts);
  }

  // Deduplicate and limit to top 4 dynamic charts
  const uniqueCharts = deduplicateCharts(chartRecommendations).slice(0, 4);

  return {
    themes,
    primaryTheme,
    chartRecommendations: uniqueCharts,
    analysis: {
      totalThemesDetected: themes.length,
      strongThemes: themes.filter(t => t.score > 0.6).length,
      dominantSection: primaryTheme?.section || 'MARKET_PULSE'
    }
  };
}

/**
 * Get additional chart recommendations based on market conditions
 */
function getContextualCharts(marketData, detectedThemes) {
  const recommendations = [];
  const detectedChartTypes = new Set(detectedThemes.map(t => t.chartType));

  // VIX spike detection
  const vixChange = marketData.indices?.vix?.changePercent || 0;
  if (Math.abs(vixChange) > 10 && !detectedChartTypes.has('vix_regime')) {
    recommendations.push({
      chartType: 'vix_regime',
      section: 'MARKET_PULSE',
      importance: 0.8,
      reason: `VIX moved ${vixChange > 0 ? '+' : ''}${vixChange.toFixed(1)}% - significant vol shift`
    });
  }

  // Sector divergence detection
  if (marketData.sectors && marketData.sectors.length > 0) {
    const sorted = [...marketData.sectors].sort((a, b) => 
      (b.changePercent || 0) - (a.changePercent || 0)
    );
    const spread = (sorted[0]?.changePercent || 0) - (sorted[sorted.length - 1]?.changePercent || 0);
    
    if (spread > 2 && !detectedChartTypes.has('sector_rotation')) {
      recommendations.push({
        chartType: 'sector_rotation',
        section: 'SECTOR_ROTATION',
        importance: 0.7,
        reason: `Sector spread of ${spread.toFixed(1)}% - rotation in progress`
      });
    }
  }

  // Index divergence detection
  const qqqChange = marketData.indices?.qqq?.changePercent || 0;
  const spyChange = marketData.indices?.spy?.changePercent || 0;
  const iwmChange = marketData.indices?.iwm?.changePercent || 0;
  
  const qqqVsSpy = qqqChange - spyChange;
  const iwmVsSpy = iwmChange - spyChange;
  
  if (Math.abs(qqqVsSpy) > 0.8 || Math.abs(iwmVsSpy) > 1) {
    if (!detectedChartTypes.has('growth_value_spread')) {
      recommendations.push({
        chartType: 'growth_value_spread',
        section: 'SECTOR_ROTATION',
        importance: 0.65,
        reason: `Index divergence: QQQ-SPY ${qqqVsSpy > 0 ? '+' : ''}${qqqVsSpy.toFixed(2)}%`
      });
    }
  }

  return recommendations;
}

/**
 * Deduplicate chart recommendations
 */
function deduplicateCharts(recommendations) {
  const seen = new Map();
  
  for (const rec of recommendations) {
    const existing = seen.get(rec.chartType);
    if (!existing || rec.importance > existing.importance) {
      seen.set(rec.chartType, rec);
    }
  }
  
  return Array.from(seen.values()).sort((a, b) => b.importance - a.importance);
}

/**
 * Determine which sections should have charts embedded
 */
export function mapChartsToSections(chartRecommendations) {
  const sectionCharts = {};
  
  for (const rec of chartRecommendations) {
    if (!sectionCharts[rec.section]) {
      sectionCharts[rec.section] = [];
    }
    sectionCharts[rec.section].push(rec.chartType);
  }
  
  return sectionCharts;
}

/**
 * Quick theme check for specific chart type
 */
export function shouldGenerateChart(reportText, chartType) {
  const analysis = analyzeReportThemes(reportText);
  return analysis.chartRecommendations.some(r => r.chartType === chartType);
}

/**
 * Get theme summary for logging/debugging
 */
export function getThemeSummary(analysis) {
  if (!analysis || !analysis.themes) return 'No themes detected';
  
  const summary = analysis.themes
    .slice(0, 5)
    .map(t => `${t.name}: ${(t.score * 100).toFixed(0)}%`)
    .join(' | ');
  
  return summary || 'No significant themes';
}

export default {
  analyzeReportThemes,
  mapChartsToSections,
  shouldGenerateChart,
  getThemeSummary,
  THEME_DEFINITIONS
};