// ==========================================
// AI Newsletter Processor - Type Declarations
// Version 3.0 - Enhanced Institutional Grade
// ==========================================

export interface QualityThresholds {
  minTotalWords: number;
  targetWords: number;
  minSections: number;
  targetSections: number;
  minAnalystActions: number;
  targetAnalystActions: number;
  minOptionsActivity: number;
  targetOptionsActivity: number;
  minFocusStocks: number;
  targetFocusStocks: number;
  minExecutiveSummaryWords: number;
  minSectionWords: number;
  minTacticalScenarios: number;
  requireYieldCurve: boolean;
  requireBreadthIndicators: boolean;
  requireBullBearCases: boolean;
}

export interface DateInfo {
  today: string;
  time: string;
  yesterday: string;
  isWeekend: boolean;
  dayOfWeek: number;
  timestamp: string;
}

export interface NewsletterSection {
  id: string;
  title: string;
  content: string;
  highlights?: string[];
  type?: 'analysis' | 'data' | 'actionable' | 'disclaimer';
}

export interface AnalystAction {
  ticker: string;
  company?: string;
  firm: string;
  analyst?: string;
  action: 'Upgraded' | 'Downgraded' | 'Initiated' | 'Maintained' | 'Price Target Change';
  fromRating?: string;
  toRating?: string;
  rating?: string;
  priceTarget: number | string;
  previousTarget?: number;
  upside?: number;
  commentary: string;
}

export interface UnusualOption {
  ticker: string;
  type: 'Calls' | 'Puts' | 'call' | 'put';
  strike: number;
  expiry: string;
  volume: number;
  openInterest: number;
  premium: string;
  sentiment: 'Bullish' | 'Bearish' | 'Neutral';
  interpretation: string;
}

export interface KeyLevelRange {
  support: number[];
  resistance: number[];
  pivot?: number;
}

export interface VIXLevels {
  low: number;
  elevated: number;
  high: number;
}

export interface YieldLevel {
  support: number;
  resistance: number;
  current: number;
}

export interface KeyLevels {
  spx?: KeyLevelRange;
  ndx?: KeyLevelRange;
  dji?: KeyLevelRange;
  rut?: KeyLevelRange;
  vix?: VIXLevels;
  tnx?: YieldLevel;
  // Legacy support
  spy?: KeyLevelRange;
  qqq?: KeyLevelRange;
  iwm?: KeyLevelRange;
}

export interface FocusStock {
  ticker: string;
  company?: string;
  story: string;
  catalyst: string;
  currentPrice?: number;
  support: number;
  resistance: number;
  stopLoss?: number;
  target?: number;
  thesis: string;
  bullCase?: string;
  bearCase?: string;
  risk?: string;
  timeHorizon?: string;
  riskReward?: string;
}

export interface SectorPerformance {
  sector: string;
  etf: string;
  performance: number;
  driver: string;
}

export interface EconomicEvent {
  time: string;
  event: string;
  forecast?: string;
  previous?: string;
  importance: 'High' | 'Medium' | 'Low';
  implication?: string;
}

export interface BreadthIndicators {
  advanceDecline?: {
    nyse: number;
    nasdaq: number;
  };
  newHighsLows?: {
    nyse: { highs: number; lows: number };
    nasdaq: { highs: number; lows: number };
  };
  percentAbove50MA?: number;
  percentAbove200MA?: number;
}

export interface YieldCurve {
  twoYear: number;
  fiveYear?: number;
  tenYear: number;
  thirtyYear?: number;
  spread2s10s: number;
  interpretation: string;
}

export interface TacticalScenario {
  probability: number;
  trigger?: string;
  target?: number;
  range?: string;
  bias?: string;
}

export interface TacticalScenarios {
  bullish: TacticalScenario;
  bearish: TacticalScenario;
  base: TacticalScenario;
}

export interface GeneratedNewsletter {
  subject: string;
  preheader: string;
  sections: NewsletterSection[];
  marketSentiment: 'bullish' | 'bearish' | 'neutral' | 'cautious' | 'mixed';
  alertType: string | null;
  analystActions: AnalystAction[];
  unusualOptions: UnusualOption[];
  keyLevels: KeyLevels;
  focusStocks: FocusStock[];
  sectorPerformance: SectorPerformance[];
  economicCalendar: EconomicEvent[];
  breadthIndicators: BreadthIndicators;
  yieldCurve: YieldCurve;
  tacticalScenarios: TacticalScenarios;
  topPicks: string[];
  riskLevel: 'low' | 'medium' | 'high' | 'elevated';
  marketTheme: string;
  tradingBias: 'bullish' | 'bearish' | 'neutral' | 'cautious';
  generatedAt: string;
  dataTimestamp: string;
  reportDate: string;
  marketRecapDate: string;
  version: string;
  quality: {
    valid: boolean;
    stats: {
      sectionCount: number;
      analystCount: number;
      optionsCount: number;
      focusCount: number;
      estimatedWords: number;
      hasYieldCurve: boolean;
      hasBreadthIndicators: boolean;
      hasTacticalScenarios: boolean;
    };
    attempts: number;
  };
}

export interface QuickSummary {
  summary: string;
  sentiment: 'bullish' | 'bearish' | 'neutral' | 'cautious';
  topEvent: string;
  riskLevel: 'low' | 'medium' | 'high';
}

export interface ValidationResult {
  valid: boolean;
  issues: string[];
  warnings: string[];
  stats: {
    sectionCount: number;
    analystCount: number;
    optionsCount: number;
    focusCount: number;
    estimatedWords: number;
    hasYieldCurve: boolean;
    hasBreadthIndicators: boolean;
    hasTacticalScenarios: boolean;
  };
}

export interface AIProcessorConfig {
  apiKey: string;
  model?: string;
  promptBuilder?: any;
  maxRetries?: number;
}

export interface ProcessorInfo {
  version: string;
  model: string;
  maxRetries: number;
  qualityThresholds: QualityThresholds;
  requiredSections: string[];
  promptConfig: any;
}

export interface SectionConfig {
  id: string;
  title: string;
  emoji: string;
  enabled: boolean;
  order: number;
  minWords: number;
}

export interface PromptBuilderConfig {
  sections?: SectionConfig[];
  companyName?: string;
  maxWords?: number;
  minWords?: number;
}

// Market Data Input Types
export interface MarketIndex {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
}

export interface FuturesData {
  symbol: string;
  price: number;
  changePercent: number;
}

export interface SectorData {
  symbol: string;
  name: string;
  changePercent: number;
}

export interface VolatilityData {
  vix?: {
    price: number;
    change: number;
  };
  putCallRatio?: number;
}

export interface TreasuryYield {
  name: string;
  yield: number;
  change: number;
}

export interface CommodityData {
  name: string;
  price: number;
  changePercent: number;
}

export interface CryptoData {
  symbol: string;
  price: number;
  changePercent24h: number;
}

export interface GlobalMarketData {
  asia?: Array<{ name: string; price: number; changePercent: number }>;
  europe?: Array<{ name: string; price: number; changePercent: number }>;
}

export interface NewsItem {
  headline?: string;
  title?: string;
  tickers?: string[];
}

export interface PremarketMover {
  symbol: string;
  price: number;
  changePercent: number;
  reason?: string;
}

export interface EarningsData {
  today?: Array<{ symbol: string; company?: string; time?: string }>;
  upcoming?: Array<{ symbol: string; date?: string }>;
}

export interface BreadthData {
  advanceDecline?: {
    nyse?: number;
    nasdaq?: number;
  };
  newHighsLows?: {
    nyseHighs?: number;
    nyseLows?: number;
    nasdaqHighs?: number;
    nasdaqLows?: number;
  };
  percentAbove50MA?: number;
  percentAbove200MA?: number;
}

export interface MarketDataInput {
  timestamp?: string;
  indices?: MarketIndex[];
  futures?: FuturesData[];
  sectors?: SectorData[];
  volatility?: VolatilityData;
  treasuryYields?: TreasuryYield[];
  commodities?: CommodityData[];
  crypto?: CryptoData[];
  globalMarkets?: GlobalMarketData;
  economicCalendar?: EconomicEvent[];
  analystActions?: AnalystAction[];
  optionsActivity?: UnusualOption[];
  earnings?: EarningsData;
  news?: NewsItem[];
  premarketMovers?: PremarketMover[];
  breadth?: BreadthData;
  earningsToday?: Array<{ symbol: string }>;
}

// Class declarations
export declare class NewsletterAIProcessor {
  constructor(config: AIProcessorConfig);
  
  openai: any;
  model: string;
  promptBuilder: any;
  maxRetries: number;
  version: string;
  
  getCurrentDateInfo(): DateInfo;
  detectAlertType(data: MarketDataInput): string | null;
  buildEnhancedDataPrompt(data: MarketDataInput): string;
  validateContent(parsed: any): ValidationResult;
  buildEnhancementPrompt(originalContent: any, validationResult: ValidationResult): string;
  parseResponse(content: string): any;
  generateNewsletter(data: MarketDataInput): Promise<GeneratedNewsletter>;
  generateQuickSummary(data: MarketDataInput): Promise<QuickSummary>;
  updatePromptConfig(config: PromptBuilderConfig): void;
  getPromptConfig(): any;
  getInfo(): ProcessorInfo;
}

export declare class PromptBuilder {
  constructor(config?: PromptBuilderConfig);
  
  sections: SectionConfig[];
  companyName: string;
  maxWords: number;
  minWords: number;
  version: string;
  
  buildSystemPrompt(): string;
  buildDataPrompt(data: MarketDataInput): string;
  getEnabledSections(): SectionConfig[];
  updateSection(sectionId: string, updates: Partial<SectionConfig>): void;
  toggleSection(sectionId: string, enabled: boolean): void;
  getConfig(): any;
  getAlertPrompt(alertType: string): string | null;
  validateContent(content: any): { valid: boolean; issues: string[] };
}

export declare function createAIProcessor(
  apiKey: string,
  model?: string,
  config?: Partial<AIProcessorConfig>
): NewsletterAIProcessor;

export declare function createPromptBuilder(
  config?: PromptBuilderConfig
): PromptBuilder;

export declare const QUALITY_THRESHOLDS: QualityThresholds;
export declare const REQUIRED_SECTIONS: string[];
export declare const NEWSLETTER_SECTIONS: SectionConfig[];
export declare const SYSTEM_PROMPT: string;
export declare const SECTION_PROMPTS: Record<string, string>;
export declare const ALERT_PROMPTS: Record<string, string>;