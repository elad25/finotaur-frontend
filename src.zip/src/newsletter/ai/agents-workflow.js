// ==========================================
// Finotaur AI Agents Workflow
// OpenAI Agents SDK Integration
// Version 4.0 - Multi-Agent Architecture
// ==========================================

import OpenAI from 'openai';

/**
 * Agent Definitions for Finotaur Newsletter System
 * Based on OpenAI Agent Builder workflow
 */

const WORKFLOW_ID = 'wf_692f34a4d5048190939855033bc2421e0465397527296bc6';

// ============================================
// AGENT CONFIGURATIONS
// ============================================

const AGENTS = {
  // Agent 1 - Data Normalizer
  dataNormalizer: {
    name: 'AGENT 1 — Data Normalizer',
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 4096,
    instructions: `Your job: Convert RAW MARKET DATA into perfectly normalized state.* objects.

STRICT RULES:
- Output JSON ONLY, no text.
- Never hallucinate.
- No missing fields.
- Every item MUST contain:
    • significance_score (1-10)
    • tags (choose from ["macro","fx","rates","geopolitics","corporate","sector"])
- Convert "category" into tags array.
- Never leave null sector — if sector unknown use "".
- Keep structure EXACTLY:

{
  "state.date": "...",
  "state.weekday": "...",
  "state.normalized_futures": [...],
  "state.normalized_macro": [...],
  "state.normalized_macro_events": [...],
  "state.normalized_calendar": [...],
  "state.normalized_headlines": [...],
  "state.normalized_analyst_raw": [...],
  "state.normalized_uoa_raw": [...],
  "state.normalized_corporate_raw": [...],
  "state.normalized_earnings_raw": [...],
  "state.normalized_sector_performance": [...],
  "state.normalized_technical": [...],
  "state.normalized_extra": [...]
}

TAG LOGIC:
- Macro → ["macro"]
- FX things → ["fx","macro"]
- Rates/yields → ["rates","macro"]
- Geopolitics → ["geopolitics","macro"]
- Headlines/Analyst/UOA/Earnings related to a sector → ["sector"]
- Corporate → ["corporate","sector"]
- Technical → ["sector"]
- Extra assets → ["macro"]

DO NOT OUTPUT ANYTHING BUT THE FINAL JSON.`
  },

  // Agent 2 - Global Macro Analyst
  globalMacroAnalyst: {
    name: 'AGENT 2 — Global Macro Analyst',
    model: 'gpt-4o',
    temperature: 0.8,
    maxTokens: 3000,
    instructions: `You are AGENT 2 — GLOBAL MACRO ANALYST (GS TRADING DESK MODE).

Your job: Convert normalized macro data into a short, institutional macro section.

STRUCTURE:
1. Global Growth/Inflation Theme (4–6 bullets)
2. Rates & Yield Curve
3. FX positioning (USDJPY, EURUSD, DXY)
4. Commodities (Oil/Gold/Copper)
5. Geopolitics (Middle East / China / Europe)
6. Global Sentiment Score (1–10)
7. Structural weekly themes OR daily delta (based on report_mode)

TONE:
- Goldman Sachs macro morning note
- No storytelling — only desk logic
- Use bullets, no long paragraphs
- Every line must imply trade relevance
- Use real numbers when provided

If data missing → infer regime only (risk-on / risk-off / mixed).

Output JSON:
{ "state.global_macro_section": "..." }`
  },

  // Agent 3 - US Market Analyst
  usMarketAnalyst: {
    name: 'AGENT 3 — US Market Analyst',
    model: 'gpt-4o',
    temperature: 0.8,
    maxTokens: 3000,
    instructions: `You are AGENT 3 — US MARKET ANALYST.

Use futures + sector performance + breadth + headlines to produce:

1. Market character (risk-on/off/mixed)
2. Leadership/Laggards Map
3. Sector structural rotation
4. ETF flows / positioning
5. Breadth & momentum
6. Implications for swing traders

TONE:
- Institutional trading desk
- Price action relevance
- No fluff

Output JSON:
{ "state.us_market_section": "..." }`
  },

  // Agent 4 - Economic Calendar Analyst
  economicCalendarAnalyst: {
    name: 'AGENT 4 — Economic Calendar Analyst',
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 2500,
    instructions: `You are AGENT 4 — ECONOMIC CALENDAR ANALYST.

For EVERY economic event, provide:
1. Event name & time
2. Why it matters (1-2 sentences)
3. Beat scenario → market reaction map
4. Miss scenario → market reaction map
5. Sector sensitivity (which sectors react most)

STRUCTURE:
- Group by importance (HIGH / MEDIUM / LOW)
- Include Fed speakers with hawk/dove bias
- Include earnings if market-moving

Output JSON:
{ "state.calendar_section": "..." }`
  },

  // Agent 5 - Analyst Ratings Analyst
  analystRatingsAnalyst: {
    name: 'AGENT 5 — Analyst Ratings Analyst',
    model: 'gpt-4o',
    temperature: 0.8,
    maxTokens: 3500,
    instructions: `You are AGENT 5 — ANALYST RATINGS ANALYST (HEDGE FUND DESK MODE).

Your job: Produce an institutional-grade analyst rating synthesis.
Always generate a full actionable section — even if raw input is empty.

MANDATORY FILTERS:
- Include ONLY: upgrades, downgrades, PT changes > ±10%
- Ignore reiterations, neutral notes, PT changes ≤ 10%
- When raw is empty → infer sector read-through & expected analyst behavior

OUTPUT STRUCTURE:

1. WINNERS
   - Only upgrades & PT hikes >10%
   - Driver: revenue inflection, margin reset, structural cycle
   - Hedge fund playbook: momentum chase, skewed long exposure

2. LOSERS
   - Only downgrades & PT cuts >10%
   - Identify fundamental deterioration
   - HF playbook: short bias, fade rallies

3. SECTOR SPILLOVER
   - Peers likely to react
   - Supplier → downstream → competitor chain
   - Cross-sector effects

4. ACTIONABLE TRADING IMPLICATION
   - Long/short bias for next 1–5 days
   - Execution mode: breakout / pullback / fade
   - Invalid level where idea fails

FALLBACK MODE (When raw is empty):
- Identify likely sectors where analysts normally adjust ratings
- Highlight expected rerates (semis, retail, energy, financials)
- Produce synthetic institutional commentary
- Provide long/short actionable biases per sector

STYLE:
- Hedge fund desk tone
- High compression
- No storytelling, no generic commentary
- Pure institutional direction

Output JSON:
{ "state.analyst_section": "..." }`
  },

  // Agent 6 - Unusual Options Flow Analyst
  unusualOptionsAnalyst: {
    name: 'AGENT 6 — Unusual Options Flow Analyst',
    model: 'gpt-4o',
    temperature: 0.8,
    maxTokens: 4000,
    instructions: `You are AGENT 6 — UNUSUAL OPTIONS FLOW ANALYST.

Your job: Produce a full institutional UOA synthesis.
Always output a full section — even if raw input is empty.

MANDATORY FILTERS:
- Minimum premium > $500,000
- Include ONLY: call sweep, put sweep, call block, put block
- Assign: continuation or reversal tag
- Identify hedge ONLY if explicitly indicated

FOR EACH FLOW PROVIDE:
- Ticker
- Flow type (call sweep, put block, etc.)
- Premium size ($X.XM)
- Strike + expiry
- Direction: bullish / bearish
- Tag: continuation / reversal
- Deep interpretation: institutional intent + risk appetite
- Implied trade: long/short/neutral + risk note

ADVANCED REQUIREMENTS:
For each flow, add:
- Follow-through probability (%)
- Reversal probability (%)
- Execution levels (where to join / where to avoid chasing)
- Risk trigger (invalid level)
- 1–3 day expected skew (momentum / chop / unwind)

CLUSTER SUMMARY (MANDATORY):
- Sector direction: risk-on / risk-off
- Rotation vs hedging signals
- What hedge funds likely adjust next
- Whether flow supports or contradicts market structure

TRADER APPLICATION (MANDATORY):
- When to follow momentum
- When to fade reversals
- Hedge opportunities
- Pairs-trade maps

FALLBACK MODE (when raw is empty):
- Construct flow clusters based on current macro regime
- Provide synthetic example flows
- Generate a full actionable map

STYLE:
- Sell-side derivatives desk
- Zero fluff
- Probability-weighted insights

Output JSON:
{ "state.uoa_section": "..." }`
  },

  // Agent 7 - Corporate & Earnings Analyst
  corporateEarningsAnalyst: {
    name: 'AGENT 7 — Corporate & Earnings Analyst',
    model: 'gpt-4o',
    temperature: 0.8,
    maxTokens: 4000,
    instructions: `You are AGENT 7 — CORPORATE & EARNINGS ANALYST (HEDGE FUND DESK MODE).

Your job: Convert corporate headlines + earnings into institutional insight.
Always output full structured sections — even if raw arrays are empty.

CORPORATE SECTION REQUIREMENTS (ALWAYS REQUIRED):

1. WINNERS
   - Based on positive headlines
   - Driver explanation

2. LOSERS
   - Based on negative headlines
   - Risk factors

3. SECTOR READ-THROUGH
   - Who benefits
   - Who is pressured

4. COMPETITIVE IMPACT
   - Pricing power shifts
   - Market share shifts
   - Regulatory implications

5. EXECUTION RISKS
   - Delays, supply chain
   - Regulatory pressure
   - Cost inflation

6. IMPLIED CATALYSTS
   - Product cycles
   - Demand shifts
   - Policy/regulation catalysts

7. ACTIONABLE TRADE IDEAS (1–2)
   - Each MUST include long/short + timeframe

EARNINGS SECTION REQUIREMENTS:
For each earnings result, provide:
1. Beat/miss summary
2. Guidance significance
3. Estimate revision implication
4. Sector contagion effect
5. Competitors likely to react next
6. 1–5 day swing-trade implication
7. Clear long/short directional call

FALLBACK MODE (MANDATORY):
When raw is empty → produce synthetic read-through for:
Tech/AI, Retail/Consumer, Airlines, Energy, Financials.

STYLE:
- Goldman Sachs TMT + JPM Healthcare + Morgan Stanley Macro tone
- Zero fluff, zero storytelling
- Only: Impact → Reaction → Trade Idea

Output JSON:
{
  "state.corporate_section": "...",
  "state.earnings_section": "..."
}`
  },

  // Agent 8 - Technical Levels Analyst
  technicalLevelsAnalyst: {
    name: 'AGENT 8 — Technical Levels Analyst',
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 3000,
    instructions: `You are AGENT 8 — TECHNICAL LEVELS ANALYST (GOLDMAN FUTURES DESK MODE).

Your job: Convert technical data into a fast, microstructure-driven technical outlook.

STRUCTURE (always):
1. Key Technical Structure (48–72h)
   - SPX / NDX / RTY / DJI regime
   - Higher-highs/higher-lows or lower-lows/lower-highs

2. Breakout / Fakeout Logic
   - Key levels to watch
   - Volume confirmation requirements

3. Breadth Interaction
   - A/D ratio implications
   - Sector participation

4. Volatility Triggers
   - VIX regime
   - IV percentile

5. Liquidity Pockets
   - Key gamma levels
   - Options walls

6. Trading Implications
   - Long setups (24–72h)
   - Short setups (24–72h)
   - Key invalidation levels

TONE:
- Futures trading desk
- Zero fluff
- No storytelling
- Behavioural structure only (HH/HL, LL/LH, liquidity)

If RAW empty → infer SPX regime (low-vol grind, range compression, or expansion).

Output JSON:
{ "state.technical_section": "..." }`
  },

  // Agent 10 - Extra Assets (BTC/Gold/DXY)
  extraAssetsAnalyst: {
    name: 'AGENT 10 — Extra Assets Analyst',
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 2000,
    instructions: `You are AGENT 10 — EXTRA ASSETS ANALYST.

Analyze BTC / Gold / DXY / Crypto:
1. Why they moved
2. What it means for equities
3. Cross-asset confirmation
4. ETF flow signals (BTC ETFs, Gold ETFs)

Output JSON:
{ "state.extra_section": "..." }`
  },

  // Agent 11 - Strategic Catalyst Engine
  strategicCatalystEngine: {
    name: 'AGENT 11 — Strategic Catalyst Engine',
    model: 'gpt-4o',
    temperature: 0.8,
    maxTokens: 4000,
    instructions: `You are AGENT 11 — STRATEGIC CATALYST ENGINE.

Your job: Produce institutional catalyst intelligence.

MANDATORY OUTPUTS:

TOP 5 CATALYSTS:
- Select highest-impact macro, policy, sector, or earnings events
- Explain why each catalyst matters
- Connect catalyst → asset class → expected reaction
- No price levels

SECTOR STRUCTURAL SHIFTS:
- Capital rotation trends (Tech → Defensives, Growth → Value, etc.)
- Regime drivers: yields, vol, geopolitics, FX, liquidity
- Benefiting sectors vs pressured sectors

CROSS-ASSET CONFIRMATION:
Include 3–5 items:
- Rates behaviour
- USD trends
- Gold/safe-haven flows
- Crypto as liquidity proxy
- Credit spreads
Explain what each confirms about the market regime.

GEOPOLITICAL TRIGGER MAP:
- 3–5 risk areas
- What event would escalate/de-escalate
- Which assets react and why

WINNER-LOSER MAP:
- Today's/this week's clear winners with reasoning
- Today's/this week's clear losers with reasoning
- Sector implications

WEEKLY POSITION TRADING IDEA (MONDAY ONLY):
Rules:
- FX or Commodities only
- Cross-asset thesis
- Timeframe: 1–3 weeks
- Include: Thesis, Entry criteria (behavioural), Risk control, Sizing

STYLE:
- Macro hedge fund tone
- Zero fluff
- Cause → Effect → Trade

Output JSON:
{
  "state.top_5_catalysts": [...],
  "state.sector_structural_shifts": [...],
  "state.cross_asset_confirmation": [...],
  "state.geopolitical_trigger_map": [...],
  "state.winner_loser_map": {...},
  "state.position_trading_idea": {...}
}`
  },

  // Agent 12 - Weekly vs Daily Logic Engine
  weeklyDailyLogic: {
    name: 'AGENT 12 — Weekly vs. Daily Logic Engine',
    model: 'gpt-4o',
    temperature: 0.3,
    maxTokens: 500,
    instructions: `Your job: determine report mode.

If weekday = Sunday or Monday:
   report_mode = "WEEKLY"
Else:
   report_mode = "DAILY"

Additional logic:
- Weekly themes included ONLY if changed materially vs previous week.
- Daily = only deltas.
- Position Trading idea ONLY on Monday.

Output JSON:
{
  "state.report_mode": "DAILY" or "WEEKLY",
  "state.logic_summary": "3–5 line explanation why"
}`
  },

  // Agent 9 - Master Report Generator
  masterReportGenerator: {
    name: 'AGENT 9 — MASTER REPORT GENERATOR',
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 8000,
    instructions: `Your job is to assemble the FULL Finotaur Report using ALL state variables.

RULES:
1. Use all provided state variables
2. If any section is missing → skip silently
3. Never mention missing data

OUTPUT FORMAT:

------------------------------------------------------------
FINOTAUR — MARKET INTELLIGENCE REPORT
DATE: {date}
MODE: {report_mode}
------------------------------------------------------------

SECTION 1 — GLOBAL MACRO & CROSS-ASSET
{global_macro_section}
{cross_asset_confirmation}
{geopolitical_trigger_map}

SECTION 2 — US MARKET STRUCTURE
{us_market_section}

SECTION 3 — ECONOMIC CALENDAR PLAYBOOK
{calendar_section}

SECTION 4 — ANALYST ACTIONS & SENTIMENT
{analyst_section}

SECTION 5 — UNUSUAL OPTIONS ACTIVITY
{uoa_section}

SECTION 6 — CORPORATE & EARNINGS LANDSCAPE
{corporate_section}
{earnings_section}

SECTION 7 — TECHNICAL OUTLOOK
{technical_section}

SECTION 8 — STRATEGIC CATALYST ENGINE
Top Catalysts:
{top_5_catalysts}

Sector Structural Shifts:
{sector_structural_shifts}

Winner–Loser Map:
{winner_loser_map}

SECTION 9 — POSITION TRADING IDEAS (Weekly Only)
{position_trading_idea}  (only if report_mode == "WEEKLY")

SECTION 10 — EXTRA ASSETS
{extra_section}

------------------------------------------------------------
FINOTAUR SUMMARY (5 bullets)
------------------------------------------------------------
• Theme: [One sentence on dominant narrative]
• Levels: [Key SPX/NDX support/resistance]
• Opportunity: [Best trade idea today]
• Risk: [Biggest risk to watch]
• Action: [What traders should do]

STYLE:
- Goldman Sachs / Morgan Stanley tone
- High compression of insights
- No filler language
- Always answer: what is happening, why it matters, implications, sector/flow/technical linkage`
  }
};

// ============================================
// WORKFLOW ORCHESTRATOR CLASS
// ============================================

export class FinotaurAgentsWorkflow {
  constructor(config) {
    this.openai = new OpenAI({
      apiKey: config.apiKey
    });
    this.model = config.model || 'gpt-4o';
    this.debug = config.debug || false;
    this.workflowId = WORKFLOW_ID;
  }

  /**
   * Log debug messages
   */
  log(message, data = null) {
    if (this.debug) {
      console.log(`[Agents Workflow] ${message}`);
      if (data) console.log(JSON.stringify(data, null, 2));
    }
  }

  /**
   * Run a single agent
   */
  async runAgent(agentConfig, inputText, context = '') {
    const startTime = Date.now();
    this.log(`Running ${agentConfig.name}...`);

    try {
      const response = await this.openai.chat.completions.create({
        model: agentConfig.model || this.model,
        messages: [
          { role: 'system', content: agentConfig.instructions },
          { role: 'user', content: context ? `${context}\n\n${inputText}` : inputText }
        ],
        temperature: agentConfig.temperature || 0.7,
        max_tokens: agentConfig.maxTokens || 2048,
        response_format: { type: 'json_object' }
      });

      const content = response.choices[0]?.message?.content;
      const duration = Date.now() - startTime;
      this.log(`${agentConfig.name} completed in ${duration}ms`);

      try {
        return JSON.parse(content);
      } catch {
        // If JSON parsing fails, return the raw content
        return { raw_output: content };
      }
    } catch (error) {
      console.error(`Error in ${agentConfig.name}:`, error.message);
      return { error: error.message };
    }
  }

  /**
   * Format raw market data for Agent 1
   */
  formatRawDataForNormalizer(data) {
    return `Here is today's raw data.

Futures:
${JSON.stringify(data.futures || [], null, 2)}

Global notes:
${JSON.stringify(data.globalMarkets || data.global_notes || [], null, 2)}

Macro events:
${JSON.stringify(data.macroEvents || data.macro_events || [], null, 2)}

Calendar:
${JSON.stringify(data.economicCalendar || data.calendar || [], null, 2)}

Headlines:
${JSON.stringify(data.news || data.headlines || [], null, 2)}

Analyst actions:
${JSON.stringify(data.analystRatings || data.analyst_actions || [], null, 2)}

UOA:
${JSON.stringify(data.unusualOptions || data.uoa || [], null, 2)}

Corporate:
${JSON.stringify(data.corporateNews || data.corporate || [], null, 2)}

Earnings:
${JSON.stringify(data.earnings || [], null, 2)}

Sectors:
${JSON.stringify(data.sectorPerformance || data.sectors || [], null, 2)}

Technicals:
${JSON.stringify(data.technicals || [], null, 2)}

Extra (Crypto/Gold/DXY):
${JSON.stringify(data.crypto || data.extra || [], null, 2)}

Treasury Yields:
${JSON.stringify(data.treasuryYields || [], null, 2)}

Commodities:
${JSON.stringify(data.commodities || [], null, 2)}

Forex:
${JSON.stringify(data.forex || [], null, 2)}

Market Indices:
${JSON.stringify(data.marketIndices || data.indices || [], null, 2)}

Top Gainers:
${JSON.stringify(data.topGainers || [], null, 2)}

Top Losers:
${JSON.stringify(data.topLosers || [], null, 2)}

Volatility:
${JSON.stringify(data.volatility || {}, null, 2)}

Breadth:
${JSON.stringify(data.breadth || {}, null, 2)}

Pre-Market Movers:
${JSON.stringify(data.premarketMovers || [], null, 2)}

Timestamp: ${data.timestamp || new Date().toISOString()}`;
  }

  /**
   * Get current date info
   */
  getDateInfo() {
    const now = new Date();
    const nyTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    
    const dateStr = now.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'America/New_York'
    });
    
    const dayOfWeek = nyTime.getDay();
    const weekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayOfWeek];
    
    return {
      date: dateStr,
      weekday,
      dayOfWeek,
      isWeeklyMode: dayOfWeek === 0 || dayOfWeek === 1,
      timestamp: now.toISOString()
    };
  }

  /**
   * Run the full workflow
   */
  async runWorkflow(rawData) {
    console.log('═'.repeat(70));
    console.log('🏛️  FINOTAUR AI AGENTS WORKFLOW v4.0');
    console.log('═'.repeat(70));

    const dateInfo = this.getDateInfo();
    console.log(`📅 Report Date: ${dateInfo.date}`);
    console.log(`📆 Day: ${dateInfo.weekday}`);
    console.log(`📊 Mode: ${dateInfo.isWeeklyMode ? 'WEEKLY' : 'DAILY'}`);
    console.log('─'.repeat(70));

    const startTime = Date.now();
    const state = {};

    // Step 1: Normalize Data (Agent 1)
    console.log('\n🔄 Step 1/6: Normalizing data...');
    const normalizedInput = this.formatRawDataForNormalizer(rawData);
    const normalizedResult = await this.runAgent(AGENTS.dataNormalizer, normalizedInput);
    Object.assign(state, normalizedResult);
    state['state.date'] = dateInfo.date;
    state['state.weekday'] = dateInfo.weekday;

    // Step 2: Determine Report Mode (Agent 12)
    console.log('\n🔄 Step 2/6: Determining report mode...');
    const modeResult = await this.runAgent(
      AGENTS.weeklyDailyLogic,
      `Current weekday: ${dateInfo.weekday}\nDay of week: ${dateInfo.dayOfWeek}`
    );
    Object.assign(state, modeResult);
    const reportMode = state['state.report_mode'] || (dateInfo.isWeeklyMode ? 'WEEKLY' : 'DAILY');
    console.log(`   Mode: ${reportMode}`);

    // Step 3: Run Parallel Analysis Agents (Agents 2-8, 10)
    console.log('\n🔄 Step 3/6: Running analysis agents in parallel...');
    
    const parallelResults = await Promise.all([
      // Agent 2 - Global Macro
      this.runAgent(
        AGENTS.globalMacroAnalyst,
        `Use the global macro data and generate today's global_macro_section.
        Report Mode: ${reportMode}`,
        JSON.stringify({
          normalized_global: state['state.normalized_macro'] || [],
          normalized_macro_events: state['state.normalized_macro_events'] || [],
          normalized_extra: state['state.normalized_extra'] || []
        })
      ),

      // Agent 3 - US Market
      this.runAgent(
        AGENTS.usMarketAnalyst,
        'Use US futures, sector performance and headlines to build today\'s us_market_section.',
        JSON.stringify({
          normalized_futures: state['state.normalized_futures'] || [],
          normalized_headlines: state['state.normalized_headlines'] || [],
          normalized_sector_performance: state['state.normalized_sector_performance'] || []
        })
      ),

      // Agent 4 - Economic Calendar
      this.runAgent(
        AGENTS.economicCalendarAnalyst,
        'Use today\'s calendar and macro events to generate the calendar_section.',
        JSON.stringify({
          normalized_calendar: state['state.normalized_calendar'] || [],
          normalized_macro_events: state['state.normalized_macro_events'] || []
        })
      ),

      // Agent 5 - Analyst Ratings
      this.runAgent(
        AGENTS.analystRatingsAnalyst,
        'Use the analyst actions to build the filtered, trade-focused analyst_section.',
        JSON.stringify({
          normalized_analyst_raw: state['state.normalized_analyst_raw'] || []
        })
      ),

      // Agent 6 - Options Flow
      this.runAgent(
        AGENTS.unusualOptionsAnalyst,
        'Use the unusual options activity to create the uoa_section.',
        JSON.stringify({
          normalized_uoa_raw: state['state.normalized_uoa_raw'] || []
        })
      ),

      // Agent 7 - Corporate & Earnings
      this.runAgent(
        AGENTS.corporateEarningsAnalyst,
        'Convert corporate headlines + earnings into institutional insight.',
        JSON.stringify({
          normalized_corporate_raw: state['state.normalized_corporate_raw'] || [],
          normalized_earnings_raw: state['state.normalized_earnings_raw'] || []
        })
      ),

      // Agent 8 - Technical Levels
      this.runAgent(
        AGENTS.technicalLevelsAnalyst,
        'Use the technical levels to build today\'s technical_section.',
        JSON.stringify({
          normalized_technical: state['state.normalized_technical'] || []
        })
      ),

      // Agent 10 - Extra Assets
      this.runAgent(
        AGENTS.extraAssetsAnalyst,
        'Analyze BTC / Gold / DXY and their implications.',
        JSON.stringify({
          normalized_extra: state['state.normalized_extra'] || [],
          crypto: rawData.crypto || []
        })
      )
    ]);

    // Merge parallel results
    parallelResults.forEach(result => {
      if (result && !result.error) {
        Object.assign(state, result);
      }
    });

    console.log('   ✅ All analysis agents completed');

    // Step 4: Strategic Catalyst Engine (Agent 11)
    console.log('\n🔄 Step 4/6: Running Strategic Catalyst Engine...');
    const catalystResult = await this.runAgent(
      AGENTS.strategicCatalystEngine,
      `Use the current state and produce your outputs. Report Mode: ${reportMode}`,
      JSON.stringify({
        normalized_headlines: state['state.normalized_headlines'] || [],
        normalized_macro: state['state.normalized_macro'] || [],
        normalized_macro_events: state['state.normalized_macro_events'] || [],
        normalized_analyst_raw: state['state.normalized_analyst_raw'] || [],
        normalized_corporate_raw: state['state.normalized_corporate_raw'] || [],
        normalized_earnings_raw: state['state.normalized_earnings_raw'] || [],
        normalized_uoa_raw: state['state.normalized_uoa_raw'] || [],
        normalized_sector_performance: state['state.normalized_sector_performance'] || []
      })
    );
    Object.assign(state, catalystResult);

    // Step 5: Master Report Generator (Agent 9)
    console.log('\n🔄 Step 5/6: Generating master report...');
    const reportInput = {
      date: state['state.date'] || dateInfo.date,
      report_mode: reportMode,
      global_macro_section: state['state.global_macro_section'] || '',
      us_market_section: state['state.us_market_section'] || '',
      calendar_section: state['state.calendar_section'] || '',
      analyst_section: state['state.analyst_section'] || '',
      uoa_section: state['state.uoa_section'] || '',
      corporate_section: state['state.corporate_section'] || '',
      earnings_section: state['state.earnings_section'] || '',
      technical_section: state['state.technical_section'] || '',
      extra_section: state['state.extra_section'] || '',
      top_5_catalysts: state['state.top_5_catalysts'] || [],
      sector_structural_shifts: state['state.sector_structural_shifts'] || [],
      cross_asset_confirmation: state['state.cross_asset_confirmation'] || [],
      geopolitical_trigger_map: state['state.geopolitical_trigger_map'] || [],
      winner_loser_map: state['state.winner_loser_map'] || {},
      position_trading_idea: reportMode === 'WEEKLY' ? (state['state.position_trading_idea'] || {}) : null
    };

    const masterReport = await this.runAgent(
      AGENTS.masterReportGenerator,
      'Assemble the full FINOTAUR Market Report using all sections and data.',
      JSON.stringify(reportInput)
    );

    // Step 6: Format Final Output
    console.log('\n🔄 Step 6/6: Formatting final output...');
    
    const duration = Date.now() - startTime;
    console.log('\n' + '═'.repeat(70));
    console.log(`✅ Workflow completed in ${(duration / 1000).toFixed(1)}s`);
    console.log('═'.repeat(70));

    return this.formatFinalOutput(state, masterReport, dateInfo, reportMode);
  }

  /**
   * Format the final newsletter output
   */
  formatFinalOutput(state, masterReport, dateInfo, reportMode) {
    // Extract the report text
    let reportText = masterReport['state.full_report'] || 
                     masterReport.full_report || 
                     masterReport.raw_output || 
                     '';

    // If we got JSON, try to extract the report
    if (typeof reportText === 'object') {
      reportText = JSON.stringify(reportText, null, 2);
    }

    // Build sections array for email template
    const sections = [];

    // Add each section
    if (state['state.global_macro_section']) {
      sections.push({
        id: 'global_macro',
        title: '🌍 Global Macro & Cross-Asset',
        content: state['state.global_macro_section'],
        type: 'analysis'
      });
    }

    if (state['state.us_market_section']) {
      sections.push({
        id: 'us_market',
        title: '🇺🇸 US Market Structure',
        content: state['state.us_market_section'],
        type: 'analysis'
      });
    }

    if (state['state.calendar_section']) {
      sections.push({
        id: 'calendar',
        title: '📅 Economic Calendar Playbook',
        content: state['state.calendar_section'],
        type: 'data'
      });
    }

    if (state['state.analyst_section']) {
      sections.push({
        id: 'analyst_arena',
        title: '🎯 Analyst Actions & Sentiment',
        content: state['state.analyst_section'],
        type: 'analysis'
      });
    }

    if (state['state.uoa_section']) {
      sections.push({
        id: 'unusual_options',
        title: '🔥 Unusual Options Activity',
        content: state['state.uoa_section'],
        type: 'analysis'
      });
    }

    if (state['state.corporate_section'] || state['state.earnings_section']) {
      sections.push({
        id: 'corporate_earnings',
        title: '💼 Corporate & Earnings Landscape',
        content: `${state['state.corporate_section'] || ''}\n\n${state['state.earnings_section'] || ''}`,
        type: 'analysis'
      });
    }

    if (state['state.technical_section']) {
      sections.push({
        id: 'technical',
        title: '📐 Technical Outlook',
        content: state['state.technical_section'],
        type: 'analysis'
      });
    }

    if (state['state.extra_section']) {
      sections.push({
        id: 'extra_assets',
        title: '₿ Extra Assets (BTC/Gold/DXY)',
        content: state['state.extra_section'],
        type: 'analysis'
      });
    }

    // Add catalyst section
    const catalystContent = [];
    if (state['state.top_5_catalysts']?.length > 0) {
      catalystContent.push('**Top 5 Catalysts:**');
      if (Array.isArray(state['state.top_5_catalysts'])) {
        state['state.top_5_catalysts'].forEach((c, i) => {
          catalystContent.push(`${i + 1}. ${typeof c === 'string' ? c : JSON.stringify(c)}`);
        });
      }
    }
    if (state['state.sector_structural_shifts']?.length > 0) {
      catalystContent.push('\n**Sector Structural Shifts:**');
      if (Array.isArray(state['state.sector_structural_shifts'])) {
        state['state.sector_structural_shifts'].forEach(s => {
          catalystContent.push(`• ${typeof s === 'string' ? s : JSON.stringify(s)}`);
        });
      }
    }
    if (catalystContent.length > 0) {
      sections.push({
        id: 'strategic_catalysts',
        title: '🧭 Strategic Catalyst Engine',
        content: catalystContent.join('\n'),
        type: 'actionable'
      });
    }

    // Weekly position idea (only on Monday/Sunday)
    if (reportMode === 'WEEKLY' && state['state.position_trading_idea']) {
      sections.push({
        id: 'position_trading',
        title: '📈 Weekly Position Trading Idea',
        content: typeof state['state.position_trading_idea'] === 'string' 
          ? state['state.position_trading_idea']
          : JSON.stringify(state['state.position_trading_idea'], null, 2),
        type: 'actionable'
      });
    }

    // Disclaimer
    sections.push({
      id: 'disclaimer',
      title: '📜 Disclaimer',
      content: 'This report is for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. All investments carry risk, including potential loss of principal. Consult a qualified financial advisor before making investment decisions.',
      type: 'disclaimer'
    });

    // Determine sentiment from the report
    let marketSentiment = 'neutral';
    const reportLower = (reportText + JSON.stringify(state)).toLowerCase();
    if (reportLower.includes('risk-on') || reportLower.includes('bullish')) {
      marketSentiment = 'bullish';
    } else if (reportLower.includes('risk-off') || reportLower.includes('bearish')) {
      marketSentiment = 'bearish';
    } else if (reportLower.includes('cautious') || reportLower.includes('mixed')) {
      marketSentiment = 'cautious';
    }

    // Build subject line
    const modeEmoji = reportMode === 'WEEKLY' ? '📊' : '📈';
    const sentimentEmoji = {
      bullish: '🟢',
      bearish: '🔴',
      neutral: '⚪',
      cautious: '🟡'
    }[marketSentiment] || '📊';

    return {
      subject: `${modeEmoji} Finotaur ${reportMode} Report — ${dateInfo.date.split(',')[0]} ${sentimentEmoji}`,
      preheader: `Institutional-grade market intelligence for ${dateInfo.weekday}`,
      sections,
      marketSentiment,
      reportMode,
      reportDate: dateInfo.date,
      generatedAt: new Date().toISOString(),
      version: '4.0',
      
      // Include raw state for debugging/advanced use
      analystActions: state['state.normalized_analyst_raw'] || [],
      unusualOptions: state['state.normalized_uoa_raw'] || [],
      focusStocks: [],
      topPicks: [],
      keyLevels: {},
      sectorPerformance: state['state.normalized_sector_performance'] || [],
      economicCalendar: state['state.normalized_calendar'] || [],
      
      // Catalyst data
      catalysts: state['state.top_5_catalysts'] || [],
      sectorShifts: state['state.sector_structural_shifts'] || [],
      crossAssetConfirmation: state['state.cross_asset_confirmation'] || [],
      geopoliticalTriggers: state['state.geopolitical_trigger_map'] || [],
      winnerLoserMap: state['state.winner_loser_map'] || {},
      
      // Full report text
      fullReportText: reportText
    };
  }

  /**
   * Generate quick summary (for alerts)
   */
  async generateQuickSummary(data) {
    const dateInfo = this.getDateInfo();
    
    const response = await this.openai.chat.completions.create({
      model: this.model,
      messages: [{
        role: 'user',
        content: `Generate a brief (4-5 sentences) market summary for ${dateInfo.date}.

Data: ${JSON.stringify(data).slice(0, 2000)}

Output JSON:
{
  "summary": "...",
  "sentiment": "bullish|bearish|neutral|cautious",
  "topEvent": "...",
  "riskLevel": "low|medium|high"
}`
      }],
      temperature: 0.7,
      max_tokens: 500,
      response_format: { type: 'json_object' }
    });

    try {
      return JSON.parse(response.choices[0]?.message?.content);
    } catch {
      return {
        summary: 'Market summary unavailable',
        sentiment: 'neutral',
        topEvent: 'N/A',
        riskLevel: 'medium'
      };
    }
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

export function createAgentsWorkflow(apiKey, config = {}) {
  return new FinotaurAgentsWorkflow({
    apiKey,
    model: config.model || 'gpt-4o',
    debug: config.debug || false
  });
}

export { AGENTS, WORKFLOW_ID };