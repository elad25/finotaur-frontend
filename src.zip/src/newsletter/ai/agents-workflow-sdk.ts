// ==========================================
// Finotaur AI Agents Workflow
// @openai/agents SDK Implementation
// Version 5.0 - Full Multi-Agent Architecture
// ==========================================

import { Agent, run } from "@openai/agents";

// ============================================
// TYPES
// ============================================

export interface MarketDataInput {
  timestamp?: string;
  indices?: Array<{ symbol: string; price: number; change: number; changePercent: number }>;
  marketIndices?: Array<{ symbol: string; price: number; change: number; changePercent: number }>;
  futures?: Array<{ symbol: string; price: number; changePercent: number }>;
  globalMarkets?: {
    asia?: Array<{ name: string; price: number; changePercent: number }>;
    europe?: Array<{ name: string; price: number; changePercent: number }>;
  };
  sectors?: Array<{ symbol: string; name: string; changePercent: number }>;
  sectorPerformance?: Array<{ sector: string; etf: string; performance: number }>;
  treasuryYields?: Array<{ name: string; yield: number; change: number }>;
  commodities?: Array<{ name: string; price: number; changePercent: number }>;
  forex?: Array<{ pair: string; rate: number; changePercent: number }>;
  crypto?: Array<{ symbol: string; price: number; changePercent24h: number }>;
  volatility?: { vix?: { price: number; change: number } | number; putCallRatio?: number };
  topGainers?: Array<{ symbol: string; price: number; changePercent: number; name?: string }>;
  topLosers?: Array<{ symbol: string; price: number; changePercent: number; name?: string }>;
  premarketMovers?: Array<{ symbol: string; price: number; changePercent: number; reason?: string }>;
  news?: Array<{ headline?: string; title?: string; source?: string; tickers?: string[] }>;
  economicCalendar?: Array<{ time: string; event: string; forecast?: string; previous?: string; importance: string }>;
  analystRatings?: any[];
  analyst_actions?: any[];
  unusualOptions?: any[];
  uoa?: any[];
  corporateNews?: any[];
  corporate?: any[];
  earnings?: any[];
  earningsToday?: Array<{ symbol: string; company?: string; time?: string }>;
  technicals?: any[];
  breadth?: {
    advanceDecline?: { nyse?: number; nasdaq?: number };
    newHighsLows?: { nyseHighs?: number; nyseLows?: number; nasdaqHighs?: number; nasdaqLows?: number };
    percentAbove50MA?: number;
    percentAbove200MA?: number;
  };
  chartUrls?: Record<string, string>;
  chartPaths?: Record<string, string>;
}

export interface NewsletterSection {
  id: string;
  title: string;
  content: string;
  type: 'analysis' | 'data' | 'actionable' | 'disclaimer';
  highlights?: string[];
}

export interface GeneratedNewsletter {
  subject: string;
  preheader: string;
  sections: NewsletterSection[];
  marketSentiment: 'bullish' | 'bearish' | 'neutral' | 'cautious' | 'mixed';
  reportMode: 'DAILY' | 'WEEKLY';
  alertType?: string | null;
  analystActions: any[];
  unusualOptions: any[];
  keyLevels: any;
  focusStocks: any[];
  sectorPerformance: any[];
  economicCalendar: any[];
  catalysts: any[];
  sectorShifts: any[];
  crossAssetConfirmation: any[];
  geopoliticalTriggers: any[];
  winnerLoserMap: any;
  tacticalScenarios: any;
  topPicks: string[];
  riskLevel: 'low' | 'medium' | 'high' | 'elevated';
  marketTheme: string;
  tradingBias: string;
  generatedAt: string;
  dataTimestamp: string;
  reportDate: string;
  marketRecapDate?: string;
  version: string;
  quality: {
    valid: boolean;
    stats: { sectionCount: number; analystCount: number; optionsCount: number };
    attempts: number;
  };
  fullReportText: string;
  chartUrls?: Record<string, string>;
  chartPaths?: Record<string, string>;
}

interface WorkflowState {
  rawData: MarketDataInput;
  date: string;
  weekday: string;
  reportMode: 'DAILY' | 'WEEKLY';
  logicSummary: string;
  normalizedFutures: any[];
  normalizedMacro: any[];
  normalizedMacroEvents: any[];
  normalizedCalendar: any[];
  normalizedHeadlines: any[];
  normalizedAnalystRaw: any[];
  normalizedUoaRaw: any[];
  normalizedCorporateRaw: any[];
  normalizedEarningsRaw: any[];
  normalizedSectorPerformance: any[];
  normalizedTechnical: any[];
  normalizedExtra: any[];
  globalMacroSection: string;
  usMarketSection: string;
  calendarSection: string;
  analystSection: string;
  uoaSection: string;
  corporateSection: string;
  earningsSection: string;
  technicalSection: string;
  extraSection: string;
  top5Catalysts: any[];
  sectorStructuralShifts: any[];
  crossAssetConfirmation: any[];
  geopoliticalTriggerMap: any[];
  winnerLoserMap: any;
  positionTradingIdea: any | null;
  fullReport: string;
}

// ============================================
// AGENT DEFINITIONS
// ============================================

const MODEL = "gpt-4o";

// Agent 1: Data Normalizer
const agent1DataNormalizer = new Agent({
  name: "AGENT 1 — Data Normalizer",
  model: MODEL,
  instructions: `Your job: Convert RAW MARKET DATA into perfectly normalized JSON objects.

STRICT RULES:
- Output JSON ONLY, no text before or after.
- Never hallucinate data - use only what's provided.
- No missing fields - use empty arrays [] if no data.
- Every item MUST contain:
    • significance_score (1-10)
    • tags (choose from ["macro","fx","rates","geopolitics","corporate","sector"])

OUTPUT STRUCTURE (EXACTLY):
{
  "date": "YYYY-MM-DD",
  "weekday": "Monday|Tuesday|...",
  "normalized_futures": [{ "symbol": "ES", "price": 6000, "change": 0.5, "changePercent": 0.08, "significance_score": 7, "tags": ["macro"] }],
  "normalized_macro": [{ "event": "...", "value": "...", "impact": "high|medium|low", "significance_score": 8, "tags": ["macro"] }],
  "normalized_macro_events": [],
  "normalized_calendar": [{ "time": "8:30 AM", "event": "CPI", "forecast": "3.2%", "previous": "3.3%", "importance": "high", "significance_score": 9, "tags": ["macro","rates"] }],
  "normalized_headlines": [{ "title": "...", "source": "...", "tickers": [], "sentiment": "positive|negative|neutral", "significance_score": 6, "tags": ["corporate"] }],
  "normalized_analyst_raw": [{ "ticker": "NVDA", "firm": "MS", "action": "upgrade", "fromRating": "Hold", "toRating": "Buy", "priceTarget": 150, "significance_score": 8, "tags": ["sector"] }],
  "normalized_uoa_raw": [{ "ticker": "AAPL", "type": "call_sweep", "strike": 200, "expiry": "Dec 20", "premium": 2500000, "volume": 15000, "direction": "bullish", "tag": "continuation", "significance_score": 7, "tags": ["sector"] }],
  "normalized_corporate_raw": [],
  "normalized_earnings_raw": [],
  "normalized_sector_performance": [{ "sector": "Technology", "etf": "XLK", "performance": 1.2, "significance_score": 6, "tags": ["sector"] }],
  "normalized_technical": [],
  "normalized_extra": []
}

DO NOT OUTPUT ANYTHING BUT THE FINAL JSON.`,
});

// Agent 2: Global Macro Analyst
const agent2GlobalMacroAnalyst = new Agent({
  name: "AGENT 2 — Global Macro Analyst",
  model: MODEL,
  instructions: `You are AGENT 2 — GLOBAL MACRO ANALYST (Goldman Sachs Trading Desk Mode).

Your job: Convert normalized macro data into a short, institutional macro section.

STRUCTURE (ALL REQUIRED):
1. Global Growth/Inflation Theme (4–6 bullets)
2. Rates & Yield Curve (10Y, 2Y, 2s10s spread, direction)
3. FX Positioning (DXY, USDJPY, EURUSD with levels)
4. Commodities (Oil, Gold, Copper with prices & implications)
5. Geopolitics (Middle East, China, Europe - risk assessment)
6. Global Sentiment Score (1–10 with justification)
7. Weekly themes OR daily delta (based on report_mode)

TONE:
- Goldman Sachs macro morning note style
- No storytelling — only trading desk logic
- Use bullets, no long paragraphs
- Every line must imply trade relevance
- Include real numbers from the data

OUTPUT FORMAT:
{ "global_macro_section": "..." }

If data is limited → infer regime (risk-on / risk-off / mixed) and explain why.`,
});

// Agent 3: US Market Analyst
const agent3UsMarketAnalyst = new Agent({
  name: "AGENT 3 — US Market Analyst",
  model: MODEL,
  instructions: `You are AGENT 3 — US MARKET ANALYST (Institutional Trading Desk Mode).

Use futures, sector performance, breadth, and headlines to produce:

STRUCTURE:
1. Market Character (risk-on/off/mixed with evidence)
2. Index Performance (SPX, NDX, DJI, RUT with levels & changes)
3. Leadership/Laggards Map (which sectors driving, which dragging)
4. Sector Structural Rotation (where capital is flowing)
5. Breadth Analysis (advance/decline, new highs/lows, % above MAs)
6. Volume & Positioning (unusual activity, gamma levels)
7. Implications for Swing Traders (actionable bias)

TONE: Institutional trading desk, price action relevance, no fluff.

OUTPUT FORMAT:
{ "us_market_section": "..." }`,
});

// Agent 4: Economic Calendar Analyst
const agent4EconomicCalendarAnalyst = new Agent({
  name: "AGENT 4 — Economic Calendar Analyst",
  model: MODEL,
  instructions: `You are AGENT 4 — ECONOMIC CALENDAR ANALYST.

For EVERY economic event in the calendar, provide:

STRUCTURE PER EVENT:
1. Event Name & Time (ET)
2. Consensus vs Previous (with numbers)
3. Why It Matters (1-2 sentences of market impact)
4. Beat Scenario → specific market reaction (indices, yields, sectors)
5. Miss Scenario → specific market reaction
6. Sector Sensitivity (which sectors react most)

GROUP BY IMPORTANCE: HIGH / MEDIUM / LOW

OUTPUT FORMAT:
{ "calendar_section": "..." }`,
});

// Agent 5: Analyst Ratings Analyst
const agent5AnalystRatingsAnalyst = new Agent({
  name: "AGENT 5 — Analyst Ratings Analyst",
  model: MODEL,
  instructions: `You are AGENT 5 — ANALYST RATINGS ANALYST (Hedge Fund Desk Mode).

Your job: Produce institutional-grade analyst rating synthesis.
Always generate a full section — even if input is limited.

OUTPUT STRUCTURE:

1. WINNERS (Upgrades & PT Hikes)
   - Ticker, Firm, New Rating, New PT
   - Driver (revenue inflection, margin reset, cycle turn)
   - HF Playbook (momentum chase, skewed long)

2. LOSERS (Downgrades & PT Cuts)
   - Ticker, Firm, New Rating, New PT
   - Deterioration thesis
   - HF Playbook (short bias, fade rallies)

3. SECTOR SPILLOVER
   - Peers likely to react
   - Supply chain implications

4. ACTIONABLE TRADING IMPLICATION
   - Long/short bias for next 1–5 days
   - Execution mode: breakout / pullback / fade

FALLBACK MODE (if raw data is empty):
- State "No significant analyst actions today" and provide general market context

OUTPUT FORMAT:
{ "analyst_section": "..." }`,
});

// Agent 6: Unusual Options Flow Analyst
const agent6UnusualOptionsAnalyst = new Agent({
  name: "AGENT 6 — Unusual Options Flow Analyst",
  model: MODEL,
  instructions: `You are AGENT 6 — UNUSUAL OPTIONS FLOW ANALYST (Derivatives Desk Mode).

Your job: Produce full institutional UOA synthesis.
Always output a complete section — even if raw input is limited.

FOR EACH SIGNIFICANT FLOW:
- Ticker & Flow Type
- Premium Size ($X.XM)
- Strike + Expiry
- Volume vs Open Interest
- Direction: bullish / bearish
- Interpretation: institutional intent & risk appetite
- Implied Trade: long/short/neutral + risk note

CLUSTER SUMMARY (REQUIRED):
- Sector direction: risk-on / risk-off
- Rotation vs hedging signals
- What smart money is positioning for

TRADER APPLICATION:
- When to follow momentum
- When to fade reversals
- Hedge opportunities

FALLBACK MODE (if raw data is empty):
- State "No significant unusual options activity detected" and provide general flow context

OUTPUT FORMAT:
{ "uoa_section": "..." }`,
});

// Agent 7: Corporate & Earnings Analyst
const agent7CorporateEarningsAnalyst = new Agent({
  name: "AGENT 7 — Corporate & Earnings Analyst",
  model: MODEL,
  instructions: `You are AGENT 7 — CORPORATE & EARNINGS ANALYST (Hedge Fund Desk Mode).

Your job: Convert corporate headlines + earnings into institutional trading insights.

CORPORATE SECTION (ALL BLOCKS REQUIRED):
1. WINNERS (based on positive headlines)
2. LOSERS (based on negative headlines)
3. SECTOR READ-THROUGH
4. COMPETITIVE IMPACT
5. EXECUTION RISKS
6. IMPLIED CATALYSTS
7. ACTIONABLE TRADE IDEAS (1-2)

EARNINGS SECTION (FOR EACH REPORT):
1. Beat/miss summary
2. Guidance significance
3. Sector contagion
4. 1–5 day swing implication
5. Long/short call with trigger

FALLBACK MODE (if data is empty):
- State "No major corporate news today" and infer market themes from other data

OUTPUT FORMAT:
{
  "corporate_section": "...",
  "earnings_section": "..."
}`,
});

// Agent 8: Technical Levels Analyst
const agent8TechnicalLevelsAnalyst = new Agent({
  name: "AGENT 8 — Technical Levels Analyst",
  model: MODEL,
  instructions: `You are AGENT 8 — TECHNICAL LEVELS ANALYST (Futures Trading Desk Mode).

STRUCTURE (ALL REQUIRED):
1. KEY TECHNICAL STRUCTURE (48–72h outlook)
   - SPX: current level, pivot, support levels, resistance levels
   - NDX: current level, pivot, support levels, resistance levels
   - Key breakout/breakdown levels

2. BREAKOUT / FAKEOUT LOGIC
   - What confirms a breakout
   - What signals a fakeout

3. BREADTH INTERACTION
   - How breadth supports or contradicts price action

4. VOLATILITY TRIGGERS
   - VIX levels to watch
   - Gamma exposure implications

5. LIQUIDITY POCKETS
   - Where stops are clustered
   - Where liquidity sits

6. TRADING IMPLICATIONS
   - Long setup criteria
   - Short setup criteria
   - Range-bound strategy

STYLE: Futures trading desk, behavioral structure only, zero fluff.

OUTPUT FORMAT:
{ "technical_section": "..." }`,
});

// Agent 10: Extra Assets Analyst (BTC/Gold/DXY)
const agent10ExtraAssetsAnalyst = new Agent({
  name: "AGENT 10 — Extra Assets Analyst",
  model: MODEL,
  instructions: `You are AGENT 10 — EXTRA ASSETS ANALYST.

Cover: BTC, Gold, DXY (Dollar Index)

FOR EACH ASSET:
1. Current Level & Daily Change
2. Why It Moved (driver analysis)
3. Cross-Asset Implication (how it affects equities)
4. Confirmation Signal (supports or contradicts risk sentiment)

SYNTHESIS:
- Overall cross-asset message
- Risk-on vs risk-off signal from alternatives

OUTPUT FORMAT:
{ "extra_section": "..." }`,
});

// Agent 11: Strategic Catalyst Engine
const agent11StrategicCatalystEngine = new Agent({
  name: "AGENT 11 — Strategic Catalyst Engine",
  model: MODEL,
  instructions: `You are AGENT 11 — STRATEGIC CATALYST ENGINE.

MANDATORY OUTPUTS:

1. TOP 5 CATALYSTS
   - Highest-impact events for the session
   - Connect catalyst → asset class → expected reaction
   - Format: { "name": "...", "impact": "high|medium|low", "affectedAssets": [...], "expectedReaction": "..." }

2. SECTOR STRUCTURAL SHIFTS
   - Capital rotation trends
   - Regime drivers
   - Format: { "from": "...", "to": "...", "driver": "...", "confidence": 0.8 }

3. CROSS-ASSET CONFIRMATION (3–5 items)
   - Rates, USD, Gold, Crypto, Credit spreads
   - Format: { "asset": "...", "signal": "...", "implication": "..." }

4. GEOPOLITICAL TRIGGER MAP (3–5 risks)
   - Region, risk, escalation/de-escalation triggers
   - Format: { "region": "...", "risk": "...", "escalationTrigger": "...", "deescalationTrigger": "...", "affectedAssets": [...] }

5. WINNER/LOSER MAP
   - Winners: ticker, reason, sector
   - Losers: ticker, reason, sector

6. POSITION TRADING IDEA (Weekly Mode Only)
   - FX or Commodities
   - Cross-asset thesis
   - Entry criteria, risk control, sizing

OUTPUT FORMAT (JSON):
{
  "top_5_catalysts": [...],
  "sector_structural_shifts": [...],
  "cross_asset_confirmation": [...],
  "geopolitical_trigger_map": [...],
  "winner_loser_map": { "winners": [...], "losers": [...] },
  "position_trading_idea": { ... } or null
}`,
});

// Agent 12: Weekly vs Daily Logic Engine
const agent12WeeklyDailyLogic = new Agent({
  name: "AGENT 12 — Weekly vs Daily Logic Engine",
  model: MODEL,
  instructions: `Your job: Determine report mode based on the current day.

LOGIC:
- If weekday is Sunday or Monday → report_mode = "WEEKLY"
- Otherwise → report_mode = "DAILY"

OUTPUT FORMAT (JSON only):
{
  "report_mode": "DAILY" or "WEEKLY",
  "logic_summary": "Brief explanation of the decision"
}`,
});

// Agent 9: Master Report Generator
const agent9MasterReportGenerator = new Agent({
  name: "AGENT 9 — Master Report Generator",
  model: MODEL,
  instructions: `You are AGENT 9 — MASTER REPORT GENERATOR.

Assemble the FULL Finotaur Market Intelligence Report using all section data provided.

REPORT STRUCTURE:

════════════════════════════════════════════════════════════════════
FINOTAUR — MARKET INTELLIGENCE REPORT
DATE: {date}
MODE: {report_mode}
════════════════════════════════════════════════════════════════════

SECTION 1 — GLOBAL MACRO & CROSS-ASSET
{global_macro_section}

SECTION 2 — US MARKET STRUCTURE
{us_market_section}

SECTION 3 — ECONOMIC CALENDAR PLAYBOOK
{calendar_section}

SECTION 4 — ANALYST ACTIONS & SENTIMENT
{analyst_section}

SECTION 5 — UNUSUAL OPTIONS ACTIVITY
{uoa_section}

SECTION 6 — CORPORATE & EARNINGS LANDSCAPE
{corporate_section}
{earnings_section}

SECTION 7 — TECHNICAL OUTLOOK
{technical_section}

SECTION 8 — EXTRA ASSETS (BTC/Gold/DXY)
{extra_section}

SECTION 9 — STRATEGIC CATALYST ENGINE
- Top 5 Catalysts
- Sector Shifts
- Cross-Asset Confirmation
- Geopolitical Triggers
- Winner/Loser Map

SECTION 10 — POSITION TRADING IDEAS (Weekly Only)

════════════════════════════════════════════════════════════════════
FINOTAUR SUMMARY
════════════════════════════════════════════════════════════════════
- [3-5 bullet summary of key takeaways]

Also output these fields:
- subject: Email subject line (compelling, 50-70 chars)
- preheader: Email preheader (80-100 chars)
- market_sentiment: bullish | bearish | neutral | cautious | mixed
- market_theme: One-line market theme
- trading_bias: bullish | bearish | neutral
- risk_level: low | medium | high | elevated
- top_picks: Array of 3-5 ticker symbols

RULES:
- If any section is empty, skip it silently
- Goldman Sachs / Morgan Stanley tone
- High compression of insights

OUTPUT FORMAT (JSON):
{
  "full_report": "The complete formatted report as a single string",
  "subject": "...",
  "preheader": "...",
  "market_sentiment": "...",
  "market_theme": "...",
  "trading_bias": "...",
  "risk_level": "...",
  "top_picks": [...]
}`,
});

// ============================================
// WORKFLOW CLASS
// ============================================

export class FinotaurAgentsWorkflow {
  private debug: boolean;
  private workflowId: string;

  constructor(config: { debug?: boolean } = {}) {
    this.debug = config.debug || false;
    this.workflowId = `wf_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private log(message: string, data?: any): void {
    if (this.debug) {
      console.log(`[${this.workflowId}] ${message}`, data || '');
    }
  }

  private getDateInfo(): { date: string; weekday: string; dayOfWeek: number; isWeeklyMode: boolean; timestamp: string } {
    const now = new Date();
    const nyTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    
    const dateStr = now.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'America/New_York'
    });

    const weekday = now.toLocaleDateString('en-US', { weekday: 'long', timeZone: 'America/New_York' });
    const dayOfWeek = nyTime.getDay();
    const isWeeklyMode = dayOfWeek === 0 || dayOfWeek === 1;

    return { date: dateStr, weekday, dayOfWeek, isWeeklyMode, timestamp: now.toISOString() };
  }

  private formatRawDataForNormalizer(data: MarketDataInput): string {
    const sections: string[] = [];
    const dateInfo = this.getDateInfo();
    
    sections.push(`=== DATE INFO ===\nDate: ${dateInfo.date}\nWeekday: ${dateInfo.weekday}`);

    const indices = data.indices || data.marketIndices || [];
    if (indices.length > 0) sections.push(`=== MARKET INDICES ===\n${JSON.stringify(indices, null, 2)}`);

    const futures = data.futures || [];
    if (futures.length > 0) sections.push(`=== FUTURES ===\n${JSON.stringify(futures, null, 2)}`);

    if (data.globalMarkets) sections.push(`=== GLOBAL MARKETS ===\n${JSON.stringify(data.globalMarkets, null, 2)}`);

    const sectors = data.sectors || data.sectorPerformance || [];
    if (sectors.length > 0) sections.push(`=== SECTORS ===\n${JSON.stringify(sectors, null, 2)}`);

    if (data.treasuryYields?.length) sections.push(`=== TREASURY YIELDS ===\n${JSON.stringify(data.treasuryYields, null, 2)}`);
    if (data.commodities?.length) sections.push(`=== COMMODITIES ===\n${JSON.stringify(data.commodities, null, 2)}`);
    if (data.forex?.length) sections.push(`=== FOREX ===\n${JSON.stringify(data.forex, null, 2)}`);
    if (data.crypto?.length) sections.push(`=== CRYPTO ===\n${JSON.stringify(data.crypto, null, 2)}`);
    if (data.volatility) sections.push(`=== VOLATILITY ===\n${JSON.stringify(data.volatility, null, 2)}`);
    if (data.topGainers?.length) sections.push(`=== TOP GAINERS ===\n${JSON.stringify(data.topGainers, null, 2)}`);
    if (data.topLosers?.length) sections.push(`=== TOP LOSERS ===\n${JSON.stringify(data.topLosers, null, 2)}`);
    if (data.news?.length) sections.push(`=== NEWS HEADLINES ===\n${JSON.stringify(data.news, null, 2)}`);
    if (data.economicCalendar?.length) sections.push(`=== ECONOMIC CALENDAR ===\n${JSON.stringify(data.economicCalendar, null, 2)}`);

    const analystData = data.analystRatings || data.analyst_actions || [];
    if (analystData.length > 0) sections.push(`=== ANALYST RATINGS ===\n${JSON.stringify(analystData, null, 2)}`);

    const optionsData = data.unusualOptions || data.uoa || [];
    if (optionsData.length > 0) sections.push(`=== UNUSUAL OPTIONS ===\n${JSON.stringify(optionsData, null, 2)}`);

    const corpData = data.corporateNews || data.corporate || [];
    if (corpData.length > 0) sections.push(`=== CORPORATE NEWS ===\n${JSON.stringify(corpData, null, 2)}`);

    const earningsData = data.earnings || data.earningsToday || [];
    if (earningsData.length > 0) sections.push(`=== EARNINGS ===\n${JSON.stringify(earningsData, null, 2)}`);

    if (data.breadth) sections.push(`=== MARKET BREADTH ===\n${JSON.stringify(data.breadth, null, 2)}`);
    if (data.technicals?.length) sections.push(`=== TECHNICALS ===\n${JSON.stringify(data.technicals, null, 2)}`);

    return sections.join('\n\n');
  }

  private parseAgentResponse(response: string): any {
    try {
      return JSON.parse(response);
    } catch {
      // Try to extract JSON from markdown code blocks
      const jsonMatch = response.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[1].trim());
        } catch {
          // Continue to next extraction method
        }
      }
      
      // Try to find raw JSON object
      const rawJsonMatch = response.match(/\{[\s\S]*\}/);
      if (rawJsonMatch) {
        try {
          return JSON.parse(rawJsonMatch[0]);
        } catch {
          return { raw_output: response };
        }
      }
      return { raw_output: response };
    }
  }

  private async runAgent(agent: Agent, input: string): Promise<any> {
    console.log(`\n═══════════════════════════════════════════════════════════`);
    console.log(`🤖 Running: ${agent.name}`);
    console.log(`═══════════════════════════════════════════════════════════`);

    const result = await run(agent, input);
    
    if (!result.finalOutput) {
      throw new Error(`${agent.name} returned no output`);
    }

    this.log(`${agent.name} raw output:`, result.finalOutput.substring(0, 500));
    
    return this.parseAgentResponse(result.finalOutput);
  }

  async runWorkflow(rawData: MarketDataInput): Promise<GeneratedNewsletter> {
    console.log('\n╔══════════════════════════════════════════════════════════╗');
    console.log('║     FINOTAUR AI AGENTS WORKFLOW v5.0                      ║');
    console.log('║     @openai/agents SDK Implementation                     ║');
    console.log('╚══════════════════════════════════════════════════════════╝\n');

    const dateInfo = this.getDateInfo();
    
    // Initialize state
    const state: WorkflowState = {
      rawData,
      date: dateInfo.date,
      weekday: dateInfo.weekday,
      reportMode: dateInfo.isWeeklyMode ? 'WEEKLY' : 'DAILY',
      logicSummary: '',
      normalizedFutures: [],
      normalizedMacro: [],
      normalizedMacroEvents: [],
      normalizedCalendar: [],
      normalizedHeadlines: [],
      normalizedAnalystRaw: [],
      normalizedUoaRaw: [],
      normalizedCorporateRaw: [],
      normalizedEarningsRaw: [],
      normalizedSectorPerformance: [],
      normalizedTechnical: [],
      normalizedExtra: [],
      globalMacroSection: '',
      usMarketSection: '',
      calendarSection: '',
      analystSection: '',
      uoaSection: '',
      corporateSection: '',
      earningsSection: '',
      technicalSection: '',
      extraSection: '',
      top5Catalysts: [],
      sectorStructuralShifts: [],
      crossAssetConfirmation: [],
      geopoliticalTriggerMap: [],
      winnerLoserMap: { winners: [], losers: [] },
      positionTradingIdea: null,
      fullReport: ''
    };

    try {
      // ═══════════════════════════════════════════════════════════
      // STEP 1: Data Normalization
      // ═══════════════════════════════════════════════════════════
      const formattedData = this.formatRawDataForNormalizer(rawData);
      const normalizedResult = await this.runAgent(agent1DataNormalizer, formattedData);
      
      state.normalizedFutures = normalizedResult.normalized_futures || [];
      state.normalizedMacro = normalizedResult.normalized_macro || [];
      state.normalizedMacroEvents = normalizedResult.normalized_macro_events || [];
      state.normalizedCalendar = normalizedResult.normalized_calendar || [];
      state.normalizedHeadlines = normalizedResult.normalized_headlines || [];
      state.normalizedAnalystRaw = normalizedResult.normalized_analyst_raw || [];
      state.normalizedUoaRaw = normalizedResult.normalized_uoa_raw || [];
      state.normalizedCorporateRaw = normalizedResult.normalized_corporate_raw || [];
      state.normalizedEarningsRaw = normalizedResult.normalized_earnings_raw || [];
      state.normalizedSectorPerformance = normalizedResult.normalized_sector_performance || [];
      state.normalizedTechnical = normalizedResult.normalized_technical || [];
      state.normalizedExtra = normalizedResult.normalized_extra || [];

      console.log('✅ Data normalized successfully');

      // ═══════════════════════════════════════════════════════════
      // STEP 2: Determine Report Mode
      // ═══════════════════════════════════════════════════════════
      const modeInput = `Current date: ${state.date}\nWeekday: ${state.weekday}`;
      const modeResult = await this.runAgent(agent12WeeklyDailyLogic, modeInput);
      
      state.reportMode = modeResult.report_mode || (dateInfo.isWeeklyMode ? 'WEEKLY' : 'DAILY');
      state.logicSummary = modeResult.logic_summary || '';
      
      console.log(`✅ Report mode: ${state.reportMode}`);

      // ═══════════════════════════════════════════════════════════
      // STEP 3: Run Section Analysts (Sequential)
      // ═══════════════════════════════════════════════════════════
      
      // Agent 2: Global Macro
      const macroInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Normalized Macro Data: ${JSON.stringify(state.normalizedMacro)}
Normalized Macro Events: ${JSON.stringify(state.normalizedMacroEvents)}
Futures: ${JSON.stringify(state.normalizedFutures)}
Raw Forex: ${JSON.stringify(rawData.forex || [])}
Raw Commodities: ${JSON.stringify(rawData.commodities || [])}
Raw Treasury Yields: ${JSON.stringify(rawData.treasuryYields || [])}
`;
      const macroResult = await this.runAgent(agent2GlobalMacroAnalyst, macroInput);
      state.globalMacroSection = macroResult.global_macro_section || macroResult.raw_output || '';

      // Agent 3: US Market
      const usMarketInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Futures: ${JSON.stringify(state.normalizedFutures)}
Sector Performance: ${JSON.stringify(state.normalizedSectorPerformance)}
Headlines: ${JSON.stringify(state.normalizedHeadlines)}
Breadth: ${JSON.stringify(rawData.breadth || {})}
Top Gainers: ${JSON.stringify(rawData.topGainers || [])}
Top Losers: ${JSON.stringify(rawData.topLosers || [])}
`;
      const usMarketResult = await this.runAgent(agent3UsMarketAnalyst, usMarketInput);
      state.usMarketSection = usMarketResult.us_market_section || usMarketResult.raw_output || '';

      // Agent 4: Economic Calendar
      const calendarInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Economic Calendar: ${JSON.stringify(state.normalizedCalendar)}
Raw Calendar: ${JSON.stringify(rawData.economicCalendar || [])}
`;
      const calendarResult = await this.runAgent(agent4EconomicCalendarAnalyst, calendarInput);
      state.calendarSection = calendarResult.calendar_section || calendarResult.raw_output || '';

      // Agent 5: Analyst Ratings
      const analystInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Analyst Actions: ${JSON.stringify(state.normalizedAnalystRaw)}
Raw Analyst Data: ${JSON.stringify(rawData.analystRatings || rawData.analyst_actions || [])}
`;
      const analystResult = await this.runAgent(agent5AnalystRatingsAnalyst, analystInput);
      state.analystSection = analystResult.analyst_section || analystResult.raw_output || '';

      // Agent 6: Unusual Options
      const uoaInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Unusual Options: ${JSON.stringify(state.normalizedUoaRaw)}
Raw UOA Data: ${JSON.stringify(rawData.unusualOptions || rawData.uoa || [])}
`;
      const uoaResult = await this.runAgent(agent6UnusualOptionsAnalyst, uoaInput);
      state.uoaSection = uoaResult.uoa_section || uoaResult.raw_output || '';

      // Agent 7: Corporate & Earnings
      const corporateInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Corporate News: ${JSON.stringify(state.normalizedCorporateRaw)}
Earnings: ${JSON.stringify(state.normalizedEarningsRaw)}
Headlines: ${JSON.stringify(state.normalizedHeadlines)}
Raw Corporate: ${JSON.stringify(rawData.corporateNews || rawData.corporate || [])}
Raw Earnings: ${JSON.stringify(rawData.earnings || rawData.earningsToday || [])}
`;
      const corporateResult = await this.runAgent(agent7CorporateEarningsAnalyst, corporateInput);
      state.corporateSection = corporateResult.corporate_section || '';
      state.earningsSection = corporateResult.earnings_section || '';

      // Agent 8: Technical Levels
      const technicalInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Futures: ${JSON.stringify(state.normalizedFutures)}
Technical Data: ${JSON.stringify(state.normalizedTechnical)}
Breadth: ${JSON.stringify(rawData.breadth || {})}
Volatility: ${JSON.stringify(rawData.volatility || {})}
`;
      const technicalResult = await this.runAgent(agent8TechnicalLevelsAnalyst, technicalInput);
      state.technicalSection = technicalResult.technical_section || technicalResult.raw_output || '';

      // Agent 10: Extra Assets
      const extraInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}
Crypto: ${JSON.stringify(rawData.crypto || [])}
Commodities: ${JSON.stringify(rawData.commodities || [])}
Forex: ${JSON.stringify(rawData.forex || [])}
`;
      const extraResult = await this.runAgent(agent10ExtraAssetsAnalyst, extraInput);
      state.extraSection = extraResult.extra_section || extraResult.raw_output || '';

      console.log('✅ All section analysts completed');

      // ═══════════════════════════════════════════════════════════
      // STEP 4: Strategic Catalyst Engine
      // ═══════════════════════════════════════════════════════════
      const strategicInput = `
Report Mode: ${state.reportMode}
Date: ${state.date}

All Section Summaries:
- Global Macro: ${state.globalMacroSection.substring(0, 500)}...
- US Market: ${state.usMarketSection.substring(0, 500)}...
- Calendar: ${state.calendarSection.substring(0, 500)}...
- Analyst: ${state.analystSection.substring(0, 500)}...
- Options: ${state.uoaSection.substring(0, 500)}...
- Corporate: ${state.corporateSection.substring(0, 500)}...
- Technical: ${state.technicalSection.substring(0, 500)}...
- Extra Assets: ${state.extraSection.substring(0, 500)}...

Raw Data Summary:
- Top Gainers: ${JSON.stringify((rawData.topGainers || []).slice(0, 5))}
- Top Losers: ${JSON.stringify((rawData.topLosers || []).slice(0, 5))}
- Key Headlines: ${JSON.stringify((rawData.news || []).slice(0, 5))}
`;
      const strategicResult = await this.runAgent(agent11StrategicCatalystEngine, strategicInput);
      
      state.top5Catalysts = strategicResult.top_5_catalysts || [];
      state.sectorStructuralShifts = strategicResult.sector_structural_shifts || [];
      state.crossAssetConfirmation = strategicResult.cross_asset_confirmation || [];
      state.geopoliticalTriggerMap = strategicResult.geopolitical_trigger_map || [];
      state.winnerLoserMap = strategicResult.winner_loser_map || { winners: [], losers: [] };
      state.positionTradingIdea = strategicResult.position_trading_idea || null;

      console.log('✅ Strategic catalyst engine completed');

      // ═══════════════════════════════════════════════════════════
      // STEP 5: Master Report Generation
      // ═══════════════════════════════════════════════════════════
      const masterInput = `
Date: ${state.date}
Report Mode: ${state.reportMode}

=== SECTION DATA ===

GLOBAL MACRO SECTION:
${state.globalMacroSection}

US MARKET SECTION:
${state.usMarketSection}

ECONOMIC CALENDAR SECTION:
${state.calendarSection}

ANALYST ACTIONS SECTION:
${state.analystSection}

UNUSUAL OPTIONS SECTION:
${state.uoaSection}

CORPORATE & EARNINGS SECTION:
${state.corporateSection}
${state.earningsSection}

TECHNICAL OUTLOOK SECTION:
${state.technicalSection}

EXTRA ASSETS SECTION:
${state.extraSection}

=== STRATEGIC DATA ===
Top 5 Catalysts: ${JSON.stringify(state.top5Catalysts)}
Sector Shifts: ${JSON.stringify(state.sectorStructuralShifts)}
Cross-Asset Confirmation: ${JSON.stringify(state.crossAssetConfirmation)}
Geopolitical Triggers: ${JSON.stringify(state.geopoliticalTriggerMap)}
Winner/Loser Map: ${JSON.stringify(state.winnerLoserMap)}
Position Trading Idea: ${JSON.stringify(state.positionTradingIdea)}
`;
      const masterResult = await this.runAgent(agent9MasterReportGenerator, masterInput);

      state.fullReport = masterResult.full_report || masterResult.raw_output || '';

      console.log('✅ Master report generated');

      // ═══════════════════════════════════════════════════════════
      // STEP 6: Format Final Output
      // ═══════════════════════════════════════════════════════════
      return this.formatFinalOutput(state, masterResult, dateInfo, rawData);

    } catch (error) {
      console.error('❌ Workflow error:', error);
      throw error;
    }
  }

  private formatFinalOutput(
    state: WorkflowState, 
    masterResult: any, 
    dateInfo: any,
    rawData: MarketDataInput
  ): GeneratedNewsletter {
    // ════════════════════════════════════════════════════════════
    // FIX: Use 'as const' to ensure literal types for 'type' property
    // ════════════════════════════════════════════════════════════
    const sections: NewsletterSection[] = [
      {
        id: 'global-macro',
        title: '🌍 Global Macro & Cross-Asset',
        content: state.globalMacroSection,
        type: 'analysis' as const
      },
      {
        id: 'us-market',
        title: '🇺🇸 US Market Structure',
        content: state.usMarketSection,
        type: 'analysis' as const
      },
      {
        id: 'economic-calendar',
        title: '📅 Economic Calendar Playbook',
        content: state.calendarSection,
        type: 'data' as const
      },
      {
        id: 'analyst-actions',
        title: '📊 Analyst Actions & Sentiment',
        content: state.analystSection,
        type: 'actionable' as const
      },
      {
        id: 'unusual-options',
        title: '🎯 Unusual Options Activity',
        content: state.uoaSection,
        type: 'actionable' as const
      },
      {
        id: 'corporate-earnings',
        title: '🏢 Corporate & Earnings',
        content: `${state.corporateSection}\n\n${state.earningsSection}`,
        type: 'analysis' as const
      },
      {
        id: 'technical-outlook',
        title: '📈 Technical Outlook',
        content: state.technicalSection,
        type: 'analysis' as const
      },
      {
        id: 'extra-assets',
        title: '₿ Extra Assets (BTC/Gold/DXY)',
        content: state.extraSection,
        type: 'analysis' as const
      }
    ].filter(s => s.content && s.content.trim().length > 0);

    return {
      subject: masterResult.subject || `Finotaur Market Intelligence - ${dateInfo.date}`,
      preheader: masterResult.preheader || `${state.reportMode} market analysis and trading insights`,
      sections,
      marketSentiment: masterResult.market_sentiment || 'neutral',
      reportMode: state.reportMode,
      alertType: null,
      analystActions: state.normalizedAnalystRaw,
      unusualOptions: state.normalizedUoaRaw,
      keyLevels: this.extractKeyLevels(state.technicalSection),
      focusStocks: this.extractFocusStocks(state, masterResult),
      sectorPerformance: state.normalizedSectorPerformance,
      economicCalendar: state.normalizedCalendar,
      catalysts: state.top5Catalysts,
      sectorShifts: state.sectorStructuralShifts,
      crossAssetConfirmation: state.crossAssetConfirmation,
      geopoliticalTriggers: state.geopoliticalTriggerMap,
      winnerLoserMap: state.winnerLoserMap,
      tacticalScenarios: this.extractTacticalScenarios(masterResult),
      topPicks: masterResult.top_picks || [],
      riskLevel: masterResult.risk_level || 'medium',
      marketTheme: masterResult.market_theme || 'Mixed signals across asset classes',
      tradingBias: masterResult.trading_bias || 'neutral',
      generatedAt: new Date().toISOString(),
      dataTimestamp: rawData.timestamp || new Date().toISOString(),
      reportDate: dateInfo.date,
      marketRecapDate: dateInfo.date,
      version: '5.0-agents-sdk',
      quality: {
        valid: true,
        stats: {
          sectionCount: sections.length,
          analystCount: state.normalizedAnalystRaw.length,
          optionsCount: state.normalizedUoaRaw.length
        },
        attempts: 1
      },
      fullReportText: state.fullReport,
      chartUrls: rawData.chartUrls,
      chartPaths: rawData.chartPaths
    };
  }

  private extractKeyLevels(technicalSection: string): any {
    // Default key levels - can be enhanced to parse from technical section
    return {
      spx: { current: 0, pivot: 0, support: [], resistance: [] },
      ndx: { current: 0, pivot: 0, support: [], resistance: [] },
      vix: { current: 0, low: 15, elevated: 20, high: 30 }
    };
  }

  private extractFocusStocks(state: WorkflowState, masterResult: any): any[] {
    const stocks: any[] = [];
    
    // Extract from winner/loser map
    if (state.winnerLoserMap?.winners) {
      stocks.push(...state.winnerLoserMap.winners.map((w: any) => ({
        symbol: w.ticker,
        reason: w.reason,
        direction: 'bullish'
      })));
    }
    
    if (state.winnerLoserMap?.losers) {
      stocks.push(...state.winnerLoserMap.losers.map((l: any) => ({
        symbol: l.ticker,
        reason: l.reason,
        direction: 'bearish'
      })));
    }

    return stocks.slice(0, 10);
  }

  private extractTacticalScenarios(masterResult: any): any {
    return {
      bullish: { probability: 0.33, trigger: 'Break above resistance', action: 'Add long exposure' },
      bearish: { probability: 0.33, trigger: 'Break below support', action: 'Reduce risk' },
      base: { probability: 0.34, bias: 'Range-bound', action: 'Trade the range' }
    };
  }

  async generateQuickSummary(data: MarketDataInput): Promise<{ summary: string; sentiment: string; topEvent: string; riskLevel: string }> {
    const quickAgent = new Agent({
      name: "Quick Summary Agent",
      model: MODEL,
      instructions: `Generate a brief 2-3 sentence market summary. Output JSON only:
{
  "summary": "Brief market overview",
  "sentiment": "bullish|bearish|neutral|cautious",
  "topEvent": "Most important event/development",
  "riskLevel": "low|medium|high"
}`
    });

    const input = `
Market Data Summary:
- Indices: ${JSON.stringify((data.indices || data.marketIndices || []).slice(0, 4))}
- Top News: ${JSON.stringify((data.news || []).slice(0, 3))}
- VIX: ${JSON.stringify(data.volatility?.vix)}
`;

    const result = await this.runAgent(quickAgent, input);
    return {
      summary: result.summary || 'Markets are trading mixed with no clear direction.',
      sentiment: result.sentiment || 'neutral',
      topEvent: result.topEvent || 'No major events',
      riskLevel: result.riskLevel || 'medium'
    };
  }
}

// ============================================
// EXPORTS
// ============================================

export function createAgentsWorkflow(config?: { debug?: boolean }): FinotaurAgentsWorkflow {
  return new FinotaurAgentsWorkflow(config);
}