// ==========================================
// Type Definitions for Finotaur AI Agents Workflow
// Version 4.0
// ==========================================

// ============================================
// AGENT CONFIGURATION TYPES
// ============================================

export interface AgentConfig {
  name: string;
  model: string;
  temperature: number;
  maxTokens: number;
  instructions: string;
}

export interface AgentsMap {
  dataNormalizer: AgentConfig;
  globalMacroAnalyst: AgentConfig;
  usMarketAnalyst: AgentConfig;
  economicCalendarAnalyst: AgentConfig;
  analystRatingsAnalyst: AgentConfig;
  unusualOptionsAnalyst: AgentConfig;
  corporateEarningsAnalyst: AgentConfig;
  technicalLevelsAnalyst: AgentConfig;
  extraAssetsAnalyst: AgentConfig;
  strategicCatalystEngine: AgentConfig;
  weeklyDailyLogic: AgentConfig;
  masterReportGenerator: AgentConfig;
}

// ============================================
// STATE TYPES (Output from Agents)
// ============================================

export interface NormalizedFutures {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  significance_score: number;
  tags: string[];
}

export interface NormalizedMacro {
  event: string;
  value?: number | string;
  previous?: number | string;
  impact: 'high' | 'medium' | 'low';
  significance_score: number;
  tags: string[];
}

export interface NormalizedHeadline {
  title: string;
  source?: string;
  tickers?: string[];
  sentiment: 'positive' | 'negative' | 'neutral';
  significance_score: number;
  tags: string[];
}

export interface NormalizedAnalystAction {
  ticker: string;
  company?: string;
  firm: string;
  analyst?: string;
  action: 'upgrade' | 'downgrade' | 'initiate' | 'reiterate' | 'pt_change';
  fromRating?: string;
  toRating?: string;
  priceTarget?: number;
  previousTarget?: number;
  significance_score: number;
  tags: string[];
}

export interface NormalizedOptionsFlow {
  ticker: string;
  type: 'call_sweep' | 'put_sweep' | 'call_block' | 'put_block';
  strike: number;
  expiry: string;
  premium: number;
  volume: number;
  openInterest: number;
  direction: 'bullish' | 'bearish';
  tag: 'continuation' | 'reversal';
  significance_score: number;
  tags: string[];
}

export interface NormalizedSectorPerformance {
  sector: string;
  etf: string;
  performance: number;
  driver?: string;
  significance_score: number;
  tags: string[];
}

// ============================================
// WORKFLOW STATE
// ============================================

export interface WorkflowState {
  // Date info
  'state.date': string;
  'state.weekday': string;
  'state.report_mode': 'DAILY' | 'WEEKLY';
  'state.logic_summary'?: string;

  // Normalized data (from Agent 1)
  'state.normalized_futures': NormalizedFutures[];
  'state.normalized_macro': NormalizedMacro[];
  'state.normalized_macro_events': NormalizedMacro[];
  'state.normalized_calendar': NormalizedMacro[];
  'state.normalized_headlines': NormalizedHeadline[];
  'state.normalized_analyst_raw': NormalizedAnalystAction[];
  'state.normalized_uoa_raw': NormalizedOptionsFlow[];
  'state.normalized_corporate_raw': any[];
  'state.normalized_earnings_raw': any[];
  'state.normalized_sector_performance': NormalizedSectorPerformance[];
  'state.normalized_technical': any[];
  'state.normalized_extra': any[];

  // Section outputs (from Agents 2-8, 10)
  'state.global_macro_section': string;
  'state.us_market_section': string;
  'state.calendar_section': string;
  'state.analyst_section': string;
  'state.uoa_section': string;
  'state.corporate_section': string;
  'state.earnings_section': string;
  'state.technical_section': string;
  'state.extra_section': string;

  // Strategic outputs (from Agent 11)
  'state.top_5_catalysts': string[] | Catalyst[];
  'state.sector_structural_shifts': string[] | SectorShift[];
  'state.cross_asset_confirmation': string[] | CrossAssetSignal[];
  'state.geopolitical_trigger_map': string[] | GeopoliticalTrigger[];
  'state.winner_loser_map': WinnerLoserMap;
  'state.position_trading_idea': PositionTradingIdea | null;

  // Final report (from Agent 9)
  'state.full_report'?: string;
}

// ============================================
// CATALYST & STRATEGIC TYPES
// ============================================

export interface Catalyst {
  name: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  affectedAssets: string[];
  expectedReaction: string;
}

export interface SectorShift {
  from: string;
  to: string;
  driver: string;
  confidence: number;
}

export interface CrossAssetSignal {
  asset: string;
  signal: string;
  implication: string;
}

export interface GeopoliticalTrigger {
  region: string;
  risk: string;
  escalationTrigger: string;
  deescalationTrigger: string;
  affectedAssets: string[];
}

export interface WinnerLoserMap {
  winners: {
    ticker: string;
    reason: string;
    sector?: string;
  }[];
  losers: {
    ticker: string;
    reason: string;
    sector?: string;
  }[];
}

export interface PositionTradingIdea {
  asset: string;
  direction: 'long' | 'short';
  thesis: string;
  entryCriteria: string;
  riskControl: string;
  timeframe: string;
  sizing: string;
}

// ============================================
// NEWSLETTER OUTPUT TYPES
// ============================================

export interface NewsletterSection {
  id: string;
  title: string;
  content: string;
  type: 'analysis' | 'data' | 'actionable' | 'disclaimer';
  highlights?: string[];
}

export interface KeyLevels {
  spx?: LevelRange;
  ndx?: LevelRange;
  dji?: LevelRange;
  rut?: LevelRange;
  vix?: VixLevels;
  tnx?: YieldLevels;
}

export interface LevelRange {
  current: number;
  pivot: number;
  support: number[];
  resistance: number[];
}

export interface VixLevels {
  current: number;
  low: number;
  elevated: number;
  high: number;
}

export interface YieldLevels {
  current: number;
  support: number;
  resistance: number;
}

export interface TacticalScenarios {
  bullish: {
    probability: number;
    trigger?: string;
    targets?: number[];
    sectors?: string[];
    action?: string;
  };
  bearish: {
    probability: number;
    trigger?: string;
    targets?: number[];
    hedges?: string[];
    action?: string;
  };
  base: {
    probability: number;
    range?: number[];
    bias?: string;
    action?: string;
  };
}

export interface GeneratedNewsletter {
  // Core content
  subject: string;
  preheader: string;
  sections: NewsletterSection[];
  
  // Sentiment & mode
  marketSentiment: 'bullish' | 'bearish' | 'neutral' | 'cautious' | 'mixed';
  reportMode: 'DAILY' | 'WEEKLY';
  alertType?: string | null;
  
  // Market data
  analystActions: NormalizedAnalystAction[];
  unusualOptions: NormalizedOptionsFlow[];
  keyLevels: KeyLevels;
  focusStocks: any[];
  sectorPerformance: NormalizedSectorPerformance[];
  economicCalendar: NormalizedMacro[];
  
  // Strategic data
  catalysts: Catalyst[] | string[];
  sectorShifts: SectorShift[] | string[];
  crossAssetConfirmation: CrossAssetSignal[] | string[];
  geopoliticalTriggers: GeopoliticalTrigger[] | string[];
  winnerLoserMap: WinnerLoserMap;
  
  // Trading data
  tacticalScenarios: TacticalScenarios;
  topPicks: string[];
  riskLevel: 'low' | 'medium' | 'high' | 'elevated';
  marketTheme: string;
  tradingBias: string;
  
  // Metadata
  generatedAt: string;
  dataTimestamp: string;
  reportDate: string;
  marketRecapDate?: string;
  version: string;
  
  // Quality
  quality: {
    valid: boolean;
    stats: {
      sectionCount: number;
      analystCount: number;
      optionsCount: number;
    };
    attempts: number;
  };
  
  // Full report text
  fullReportText: string;
}

// ============================================
// INPUT DATA TYPES
// ============================================

export interface MarketDataInput {
  timestamp?: string;
  
  // Indices & Futures
  indices?: Array<{ symbol: string; price: number; change: number; changePercent: number }>;
  marketIndices?: Array<{ symbol: string; price: number; change: number; changePercent: number }>;
  futures?: Array<{ symbol: string; price: number; changePercent: number }>;
  
  // Global markets
  globalMarkets?: {
    asia?: Array<{ name: string; price: number; changePercent: number }>;
    europe?: Array<{ name: string; price: number; changePercent: number }>;
  };
  
  // Sectors
  sectors?: Array<{ symbol: string; name: string; changePercent: number }>;
  sectorPerformance?: Array<{ sector: string; etf: string; performance: number }>;
  
  // Fixed Income
  treasuryYields?: Array<{ name: string; yield: number; change: number }>;
  
  // Commodities & Forex
  commodities?: Array<{ name: string; price: number; changePercent: number }>;
  forex?: Array<{ pair: string; rate: number; changePercent: number }>;
  
  // Crypto
  crypto?: Array<{ symbol: string; price: number; changePercent24h: number }>;
  
  // Volatility
  volatility?: {
    vix?: { price: number; change: number } | number;
    putCallRatio?: number;
  };
  
  // Movers
  topGainers?: Array<{ symbol: string; price: number; changePercent: number; name?: string }>;
  topLosers?: Array<{ symbol: string; price: number; changePercent: number; name?: string }>;
  premarketMovers?: Array<{ symbol: string; price: number; changePercent: number; reason?: string }>;
  
  // News & Events
  news?: Array<{ headline?: string; title?: string; source?: string; tickers?: string[] }>;
  economicCalendar?: Array<{ time: string; event: string; forecast?: string; previous?: string; importance: string }>;
  
  // Analyst & Options
  analystRatings?: NormalizedAnalystAction[];
  analyst_actions?: any[];
  unusualOptions?: NormalizedOptionsFlow[];
  uoa?: any[];
  
  // Corporate
  corporateNews?: any[];
  corporate?: any[];
  earnings?: any[];
  earningsToday?: Array<{ symbol: string; company?: string; time?: string }>;
  
  // Technicals
  technicals?: any[];
  
  // Breadth
  breadth?: {
    advanceDecline?: { nyse?: number; nasdaq?: number };
    newHighsLows?: { nyseHighs?: number; nyseLows?: number; nasdaqHighs?: number; nasdaqLows?: number };
    percentAbove50MA?: number;
    percentAbove200MA?: number;
  };
}

// ============================================
// WORKFLOW CLASS TYPES
// ============================================

export interface WorkflowConfig {
  apiKey: string;
  model?: string;
  debug?: boolean;
}

export interface DateInfo {
  date: string;
  weekday: string;
  dayOfWeek: number;
  isWeeklyMode: boolean;
  timestamp: string;
}

export interface ProcessorInfo {
  version: string;
  model: string;
  type: string;
  agentCount: number;
  workflowId: string;
}

export interface QuickSummary {
  summary: string;
  sentiment: 'bullish' | 'bearish' | 'neutral' | 'cautious';
  topEvent: string;
  riskLevel: 'low' | 'medium' | 'high';
}

// ============================================
// CLASS DECLARATIONS
// ============================================

export declare class FinotaurAgentsWorkflow {
  constructor(config: WorkflowConfig);
  
  openai: any;
  model: string;
  debug: boolean;
  workflowId: string;
  
  log(message: string, data?: any): void;
  runAgent(agentConfig: AgentConfig, inputText: string, context?: string): Promise<any>;
  formatRawDataForNormalizer(data: MarketDataInput): string;
  getDateInfo(): DateInfo;
  runWorkflow(rawData: MarketDataInput): Promise<GeneratedNewsletter>;
  formatFinalOutput(state: WorkflowState, masterReport: any, dateInfo: DateInfo, reportMode: string): GeneratedNewsletter;
  generateQuickSummary(data: MarketDataInput): Promise<QuickSummary>;
}

export declare class NewsletterAIProcessor {
  constructor(config: WorkflowConfig);
  
  workflow: FinotaurAgentsWorkflow;
  model: string;
  version: string;
  
  getCurrentDateInfo(): DateInfo & { today: string; time: string; yesterday: string; isWeekend: boolean };
  generateNewsletter(data: MarketDataInput): Promise<GeneratedNewsletter>;
  extractKeyLevels(result: any): KeyLevels;
  generateQuickSummary(data: MarketDataInput): Promise<QuickSummary>;
  getInfo(): ProcessorInfo;
}

// ============================================
// FACTORY FUNCTIONS
// ============================================

export declare function createAgentsWorkflow(apiKey: string, config?: Partial<WorkflowConfig>): FinotaurAgentsWorkflow;

export declare function createAIProcessor(apiKey: string, model?: string, config?: Partial<WorkflowConfig>): NewsletterAIProcessor;

// ============================================
// CONSTANTS
// ============================================

export declare const AGENTS: AgentsMap;
export declare const WORKFLOW_ID: string;