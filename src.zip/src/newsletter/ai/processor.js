// ==========================================
// AI Newsletter Processor - Institutional Grade
// Version 3.0 - Enhanced Validation & Quality Control
// Goldman Sachs / JPMorgan Quality Standards
// ==========================================

import OpenAI from 'openai';
import { createPromptBuilder } from './prompt-builder.js';

const DEFAULT_MODEL = 'gpt-4o';

/**
 * Quality thresholds for the generated content - V3.0 ENHANCED
 */
const QUALITY_THRESHOLDS = {
  minTotalWords: 2500,
  targetWords: 3000,
  minSections: 18,
  targetSections: 22,
  minAnalystActions: 12,
  targetAnalystActions: 15,
  minOptionsActivity: 10,
  targetOptionsActivity: 12,
  minFocusStocks: 2,
  targetFocusStocks: 3,
  minExecutiveSummaryWords: 200,
  minSectionWords: 80,
  minTacticalScenarios: 3,
  requireYieldCurve: true,
  requireBreadthIndicators: true,
  requireBullBearCases: true,
};

/**
 * Section requirements for validation
 */
const REQUIRED_SECTIONS = [
  'executive_summary',
  'global_markets',
  'us_market_recap',
  'overnight_developments',
  'pre_market_overview',
  'macro_calendar',
  'analyst_arena',
  'earnings_catalysts',
  'corporate_headlines',
  'breaking_news',
  'unusual_options',
  'sector_analysis',
  'liquidity_breadth',
  'fixed_income',
  'consumer_macro',
  'focus_stocks',
  'tactical_playbook',
  'crypto_corner',
  'upcoming_catalysts',
  'risk_factors',
  'key_takeaways',
  'disclaimer',
];

/**
 * NewsletterAIProcessor - Institutional Grade Newsletter Generation v3.0
 */
export class NewsletterAIProcessor {
  constructor(config) {
    this.openai = new OpenAI({
      apiKey: config.apiKey,
    });
    this.model = config.model || DEFAULT_MODEL;
    this.promptBuilder = config.promptBuilder || createPromptBuilder();
    this.maxRetries = config.maxRetries || 3;
    this.version = '3.0';
  }

  /**
   * Get current date info in NY timezone
   */
  getCurrentDateInfo() {
    const now = new Date();
    const nyTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    
    const options = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      timeZone: 'America/New_York'
    };
    
    const dateStr = now.toLocaleDateString('en-US', options);
    const timeStr = now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      timeZone: 'America/New_York'
    });

    // Get yesterday's date for market recap
    const yesterday = new Date(nyTime);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Skip weekends for "yesterday"
    const dayOfWeek = yesterday.getDay();
    if (dayOfWeek === 0) yesterday.setDate(yesterday.getDate() - 2);
    if (dayOfWeek === 6) yesterday.setDate(yesterday.getDate() - 1);

    const yesterdayStr = yesterday.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long', 
      day: 'numeric',
      year: 'numeric'
    });

    return {
      today: dateStr,
      time: timeStr,
      yesterday: yesterdayStr,
      isWeekend: nyTime.getDay() === 0 || nyTime.getDay() === 6,
      dayOfWeek: nyTime.getDay(),
      timestamp: now.toISOString(),
    };
  }

  /**
   * Detect if today has a major market event requiring an alert
   */
  detectAlertType(data) {
    const calendar = data.economicCalendar || [];
    const news = data.news || [];
    
    for (const event of calendar) {
      const eventName = (event.event || '').toLowerCase();
      const importance = (event.importance || '').toLowerCase();
      
      if (importance === 'high' || importance === 'critical') {
        if (eventName.includes('cpi') || eventName.includes('consumer price')) return 'cpi_release';
        if (eventName.includes('nonfarm') || eventName.includes('nfp') || eventName.includes('employment situation')) return 'nfp_release';
        if (eventName.includes('fomc') || eventName.includes('fed decision') || eventName.includes('interest rate')) return 'fed_decision';
        if (eventName.includes('pce') || eventName.includes('personal consumption')) return 'pce_release';
      }
    }
    
    for (const item of news) {
      const headline = (item.headline || '').toLowerCase();
      if (headline.includes('war') || headline.includes('conflict') || headline.includes('sanctions') || headline.includes('geopolitical')) {
        return 'geopolitical';
      }
    }
    
    const megaCaps = ['AAPL', 'MSFT', 'GOOGL', 'GOOG', 'AMZN', 'NVDA', 'META', 'TSLA'];
    const earnings = data.earningsToday || [];
    for (const e of earnings) {
      if (megaCaps.includes(e.symbol)) return 'mega_earnings';
    }
    
    // Check for options expiration
    const now = new Date();
    const dayOfMonth = now.getDate();
    const dayOfWeek = now.getDay();
    // Third Friday check (approximate)
    if (dayOfWeek === 5 && dayOfMonth >= 15 && dayOfMonth <= 21) {
      return 'options_expiration';
    }
    
    return null;
  }

  /**
   * Build enhanced data prompt with real-time context
   */
  buildEnhancedDataPrompt(data) {
    const dateInfo = this.getCurrentDateInfo();
    const safeData = data || {};
    
    if (!safeData.timestamp) {
      safeData.timestamp = dateInfo.timestamp;
    }
    
    const alertType = this.detectAlertType(safeData);
    
    let prompt = `
════════════════════════════════════════════════════════════════════════════════
                           🏛️ FINOTAUR RESEARCH
                    Institutional-Grade Market Intelligence
════════════════════════════════════════════════════════════════════════════════

📅 REPORT DATE: ${dateInfo.today}
⏰ GENERATION TIME: ${dateInfo.time} ET
📆 MARKET RECAP FOR: ${dateInfo.yesterday}
${dateInfo.isWeekend ? '⚠️ WEEKEND EDITION — Focus on Week Ahead' : ''}

════════════════════════════════════════════════════════════════════════════════
                              ⚙️ CRITICAL CONTEXT
════════════════════════════════════════════════════════════════════════════════

This report is for ${dateInfo.today}. You are a senior Wall Street strategist.

CURRENT MARKET CONTEXT (December 2024 - January 2025):
• S&P 500: Trading around 6,000-6,200 level
• NASDAQ Composite: Trading around 19,800-20,500 level
• Dow Jones: Trading around 44,500-45,500 level
• Russell 2000: Trading around 2,350-2,500 level
• Fed Funds Rate: 4.25-4.50% (Fed in cutting cycle, paused)
• 10Y Treasury: ~4.2-4.5% range
• VIX: Normal range 12-18
• DXY (Dollar Index): ~106-108 range (strong dollar)

DOMINANT MARKET THEMES (reference these in analysis):
• AI infrastructure buildout driving mega-cap tech (NVDA, MSFT, GOOGL)
• Fed navigating soft landing - rate cuts begun but pausing
• Consumer resilience vs. selective weakness in lower income
• Geopolitical tensions (Middle East, Ukraine, China-Taiwan, Red Sea)
• Post-election policy uncertainty (tariffs, fiscal policy)
• Magnificent 7 concentration and rotation dynamics
• Small cap revival attempts (rate sensitivity)
• Yield curve dynamics (inversion depth, steepening signs)
• Credit spreads (IG, HY) — watching for stress

CRITICAL INSTRUCTION FOR DATA GAPS:
The data provided below may have gaps. You MUST:
1. Use provided data as the foundation
2. Supplement with your knowledge of current market conditions
3. Generate realistic, plausible analyst actions if fewer than 12 provided
4. Generate realistic options activity if fewer than 10 provided
5. Generate realistic focus stocks with complete analysis
6. NEVER use placeholders like [TBD], [INSERT], [X], [COMPANY]
7. NEVER leave sections short or empty
8. Include yield curve analysis even if not in data
9. Include breadth indicators even if not in data
10. Include bull/bear cases for focus stocks

`;

    if (alertType) {
      const alertPrompt = this.promptBuilder.getAlertPrompt(alertType);
      if (alertPrompt) {
        prompt += `
════════════════════════════════════════════════════════════════════════════════
                    ⚠️ MAJOR EVENT DETECTED: ${alertType.toUpperCase().replace('_', ' ')}
════════════════════════════════════════════════════════════════════════════════
${alertPrompt}
`;
      }
    }

    prompt += this.promptBuilder.buildDataPrompt(safeData);

    prompt += `

════════════════════════════════════════════════════════════════════════════════
                         📋 FINAL QUALITY CHECKLIST
════════════════════════════════════════════════════════════════════════════════

Before generating, confirm you will include:

□ Executive Summary: 250+ words with dominant theme, specific numbers
□ Global Markets: Asia (Japan, China, HK, Korea, Australia), Europe (DAX, FTSE, CAC), FX (DXY, EUR, JPY, GBP), Commodities (Oil, Gold, Copper)
□ US Market Recap: All indices with %, sectors ranked 1-11, breadth, volume analysis, 350+ words
□ Overnight Developments: What changed while US slept, futures action
□ Pre-Market Overview: Futures levels, gaps, top 10 movers with reasons
□ Macro Calendar: Today's events with market implications (beat/miss scenarios)
□ Analyst Arena: 12+ actions with firm, analyst, rating, PT, 3-4 sentence thesis each
□ Earnings Watch: Yesterday AH, today pre-market, tonight AC with expectations
□ Corporate Headlines: M&A, FDA, buybacks, management changes, contracts
□ News Flow: 12+ headlines by sector with implications
□ UOA: 10+ trades (6 bullish, 4 bearish) with strike, expiry, volume, premium, interpretation
□ Sector Analysis: All 11 sectors ranked with drivers, ETF flows, rotation analysis
□ Liquidity & Breadth: A/D ratio, new highs/lows, % above MAs, concentration risk
□ Fixed Income: Yields (2Y, 5Y, 10Y, 30Y), 2s10s curve, Fed expectations, credit spreads
□ Consumer & Macro: Consumer health, inflation pulse, labor market
□ Focus Stocks: 2-3 with story, catalyst, fundamentals, technicals, bull case, bear case, entry/stop/target
□ Tactical Playbook: 3 scenarios (bull/bear/base) with probabilities, levels, triggers
□ Crypto Corner: BTC/ETH levels, ETF flows, regulatory news
□ Upcoming Catalysts: Day-by-day week calendar, major events ahead
□ Risk Factors: Market, macro, geopolitical, sector-specific risks
□ Key Takeaways: EXACTLY 5 points (Theme, Levels, Opportunity, Risk, Action)
□ Disclaimer: Professional disclosure

TOTAL TARGET: 2,800-3,500 words
TONE: Goldman Sachs / JPMorgan morning research note
QUALITY: Every section answers "so what?" with interpretation

════════════════════════════════════════════════════════════════════════════════
`;

    return prompt;
  }

  /**
   * Validate generated content against quality thresholds - ENHANCED v3.0
   */
  validateContent(parsed) {
    const issues = [];
    const warnings = [];
    
    // Section count validation
    const sectionCount = parsed.sections?.length || 0;
    if (sectionCount < QUALITY_THRESHOLDS.minSections) {
      issues.push(`Sections: ${sectionCount}/${QUALITY_THRESHOLDS.minSections} minimum`);
    }

    // Check for required sections
    const sectionIds = new Set((parsed.sections || []).map(s => s.id));
    const missingSections = REQUIRED_SECTIONS.filter(id => !sectionIds.has(id));
    if (missingSections.length > 0) {
      warnings.push(`Missing sections: ${missingSections.slice(0, 5).join(', ')}${missingSections.length > 5 ? '...' : ''}`);
    }
    
    // Analyst actions validation
    const analystCount = parsed.analystActions?.length || 0;
    if (analystCount < QUALITY_THRESHOLDS.minAnalystActions) {
      issues.push(`Analyst actions: ${analystCount}/${QUALITY_THRESHOLDS.minAnalystActions} minimum`);
    }
    
    // Options activity validation
    const optionsCount = parsed.unusualOptions?.length || 0;
    if (optionsCount < QUALITY_THRESHOLDS.minOptionsActivity) {
      issues.push(`Options activity: ${optionsCount}/${QUALITY_THRESHOLDS.minOptionsActivity} minimum`);
    }
    
    // Focus stocks validation
    const focusCount = parsed.focusStocks?.length || 0;
    if (focusCount < QUALITY_THRESHOLDS.minFocusStocks) {
      issues.push(`Focus stocks: ${focusCount}/${QUALITY_THRESHOLDS.minFocusStocks} minimum`);
    }

    // Check focus stocks have bull/bear cases
    if (parsed.focusStocks && QUALITY_THRESHOLDS.requireBullBearCases) {
      const stocksWithoutCases = parsed.focusStocks.filter(s => !s.bullCase || !s.bearCase);
      if (stocksWithoutCases.length > 0) {
        warnings.push(`Focus stocks missing bull/bear cases: ${stocksWithoutCases.map(s => s.ticker).join(', ')}`);
      }
    }

    // Tactical scenarios validation
    if (!parsed.tacticalScenarios) {
      warnings.push('Missing tactical scenarios');
    } else {
      const scenarioCount = Object.keys(parsed.tacticalScenarios).length;
      if (scenarioCount < QUALITY_THRESHOLDS.minTacticalScenarios) {
        warnings.push(`Tactical scenarios: ${scenarioCount}/${QUALITY_THRESHOLDS.minTacticalScenarios} minimum`);
      }
    }

    // Yield curve validation
    if (QUALITY_THRESHOLDS.requireYieldCurve && !parsed.yieldCurve) {
      warnings.push('Missing yield curve analysis');
    }

    // Breadth indicators validation
    if (QUALITY_THRESHOLDS.requireBreadthIndicators && !parsed.breadthIndicators) {
      warnings.push('Missing breadth indicators');
    }
    
    // Word count validation
    let totalWords = 0;
    if (parsed.sections) {
      parsed.sections.forEach(section => {
        const words = (section.content || '').split(/\s+/).length;
        totalWords += words;
        
        if (words < QUALITY_THRESHOLDS.minSectionWords) {
          warnings.push(`Section "${section.id}" has only ${words} words (min: ${QUALITY_THRESHOLDS.minSectionWords})`);
        }
      });
    }
    
    if (totalWords < QUALITY_THRESHOLDS.minTotalWords) {
      issues.push(`Total words: ~${totalWords}/${QUALITY_THRESHOLDS.minTotalWords} minimum`);
    }

    // Key fields validation
    if (!parsed.marketSentiment) warnings.push('Missing marketSentiment');
    if (!parsed.marketTheme) warnings.push('Missing marketTheme');
    if (!parsed.tradingBias) warnings.push('Missing tradingBias');
    
    // Key levels validation
    if (!parsed.keyLevels) {
      warnings.push('Missing keyLevels');
    } else {
      if (!parsed.keyLevels.spx) warnings.push('Missing SPX key levels');
      if (!parsed.keyLevels.ndx) warnings.push('Missing NDX key levels');
      if (!parsed.keyLevels.dji) warnings.push('Missing DJI key levels');
      if (!parsed.keyLevels.rut) warnings.push('Missing RUT key levels');
      if (!parsed.keyLevels.vix) warnings.push('Missing VIX key levels');
      if (!parsed.keyLevels.tnx) warnings.push('Missing TNX (10Y yield) key levels');
    }

    // Check for placeholder text
    const jsonStr = JSON.stringify(parsed);
    const placeholders = ['[TBD]', '[INSERT]', '[X]', '[COMPANY]', '[TICKER]', '[DATE]'];
    placeholders.forEach(ph => {
      if (jsonStr.includes(ph)) {
        issues.push(`Contains placeholder: ${ph}`);
      }
    });
    
    return {
      valid: issues.length === 0,
      issues,
      warnings,
      stats: { 
        sectionCount, 
        analystCount, 
        optionsCount, 
        focusCount, 
        estimatedWords: totalWords,
        hasYieldCurve: !!parsed.yieldCurve,
        hasBreadthIndicators: !!parsed.breadthIndicators,
        hasTacticalScenarios: !!parsed.tacticalScenarios,
      }
    };
  }

  /**
   * Build enhancement prompt for retry attempts - ENHANCED v3.0
   */
  buildEnhancementPrompt(originalContent, validationResult) {
    return `
The previous response did not meet institutional quality requirements. Please ENHANCE it significantly.

CRITICAL ISSUES TO FIX:
• ${validationResult.issues.join('\n• ')}

WARNINGS TO ADDRESS:
• ${validationResult.warnings.join('\n• ')}

PREVIOUS STATS:
• Sections: ${validationResult.stats.sectionCount} (need ${QUALITY_THRESHOLDS.minSections}+)
• Analyst Actions: ${validationResult.stats.analystCount} (need ${QUALITY_THRESHOLDS.minAnalystActions}+)
• Options Activity: ${validationResult.stats.optionsCount} (need ${QUALITY_THRESHOLDS.minOptionsActivity}+)
• Focus Stocks: ${validationResult.stats.focusCount} (need ${QUALITY_THRESHOLDS.minFocusStocks}+)
• Estimated Words: ${validationResult.stats.estimatedWords} (need ${QUALITY_THRESHOLDS.minTotalWords}+)
• Has Yield Curve: ${validationResult.stats.hasYieldCurve}
• Has Breadth Indicators: ${validationResult.stats.hasBreadthIndicators}
• Has Tactical Scenarios: ${validationResult.stats.hasTacticalScenarios}

REQUIRED IMPROVEMENTS:

1. ANALYST ACTIONS (need ${QUALITY_THRESHOLDS.minAnalystActions}+):
   Add more analyst actions from major firms: Goldman Sachs, Morgan Stanley, JPMorgan, Bank of America, Citi, UBS, Barclays, Wells Fargo, Deutsche Bank, RBC, Piper Sandler, Wedbush, KeyBanc, Mizuho
   Each must include: firm, analyst, rating change, price target, 3-4 sentence thesis

2. OPTIONS ACTIVITY (need ${QUALITY_THRESHOLDS.minOptionsActivity}+):
   Add more unusual options activity with:
   - Specific strikes and expiries
   - Volume vs open interest
   - Premium in dollars
   - Interpretation of what the flow means

3. FOCUS STOCKS (need ${QUALITY_THRESHOLDS.minFocusStocks}+ with COMPLETE analysis):
   Each must include:
   - Story, Catalyst, Fundamentals, Technicals
   - BULL CASE (3-4 sentences)
   - BEAR CASE (3-4 sentences)
   - Entry, Target, Stop, Time Horizon

4. TACTICAL PLAYBOOK (need 3 scenarios):
   - Bullish scenario with probability, triggers, targets
   - Bearish scenario with probability, triggers, targets
   - Base case with probability, expected range

5. YIELD CURVE ANALYSIS:
   - 2Y, 5Y, 10Y, 30Y yields
   - 2s10s spread and interpretation
   - Fed expectations
   - Credit spread commentary

6. BREADTH INDICATORS:
   - NYSE/NASDAQ A/D ratio
   - New highs vs lows
   - % above 50-day and 200-day MA
   - Concentration risk assessment

7. EXPAND EACH SECTION:
   - More detail and analysis
   - Every section answers "so what?"
   - No section under ${QUALITY_THRESHOLDS.minSectionWords} words

8. KEY LEVELS for all indices:
   - SPX: support, resistance, pivot
   - NDX: support, resistance, pivot
   - DJI: support, resistance, pivot
   - RUT: support, resistance, pivot
   - VIX: low, elevated, high levels
   - TNX: support, resistance, current

Please output the COMPLETE enhanced JSON response, not just additions.
This is an institutional-grade product — quality matters.
`;
  }

  /**
   * Parse AI response safely
   */
  parseResponse(content) {
    if (!content) throw new Error('Empty response from AI');

    let cleanContent = content.trim();
    
    // Remove markdown code blocks if present
    if (cleanContent.startsWith('```json')) cleanContent = cleanContent.slice(7);
    else if (cleanContent.startsWith('```')) cleanContent = cleanContent.slice(3);
    if (cleanContent.endsWith('```')) cleanContent = cleanContent.slice(0, -3);
    
    cleanContent = cleanContent.trim();
    
    try {
      return JSON.parse(cleanContent);
    } catch (parseError) {
      // Try to extract JSON from the content
      const jsonMatch = cleanContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) return JSON.parse(jsonMatch[0]);
      throw new Error(`Failed to parse JSON: ${parseError.message}`);
    }
  }

  /**
   * Generate newsletter with retry logic for quality - ENHANCED v3.0
   */
  async generateNewsletter(data) {
    console.log('═'.repeat(70));
    console.log('🏛️  FINOTAUR AI NEWSLETTER GENERATOR v3.0');
    console.log('═'.repeat(70));
    
    const dateInfo = this.getCurrentDateInfo();
    console.log(`📅 Report Date: ${dateInfo.today}`);
    console.log(`📊 Market Recap For: ${dateInfo.yesterday}`);
    console.log(`🤖 Model: ${this.model}`);
    console.log(`📈 Target: ${QUALITY_THRESHOLDS.targetWords} words, ${QUALITY_THRESHOLDS.targetSections} sections`);
    
    const startTime = Date.now();
    const safeData = data || { timestamp: dateInfo.timestamp };
    
    const alertType = this.detectAlertType(safeData);
    if (alertType) console.log(`⚠️  Alert Detected: ${alertType.toUpperCase().replace('_', ' ')}`);

    const systemPrompt = this.promptBuilder.buildSystemPrompt();
    const dataPrompt = this.buildEnhancedDataPrompt(safeData);

    console.log(`📝 System Prompt: ${systemPrompt.length.toLocaleString()} chars`);
    console.log(`📊 Data Prompt: ${dataPrompt.length.toLocaleString()} chars`);
    console.log('─'.repeat(70));

    let parsed = null;
    let attempt = 0;
    let validationResult = null;

    while (attempt <= this.maxRetries) {
      attempt++;
      console.log(`\n🔄 Generation Attempt ${attempt}/${this.maxRetries + 1}`);
      
      try {
        const messages = [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: dataPrompt },
        ];
        
        // On retries, provide context about what needs improvement
        if (attempt > 1 && parsed && validationResult) {
          const enhancementPrompt = this.buildEnhancementPrompt(parsed, validationResult);
          messages.push({ role: 'assistant', content: JSON.stringify(parsed).slice(0, 8000) + '...' });
          messages.push({ role: 'user', content: enhancementPrompt });
        }

        const response = await this.openai.chat.completions.create({
          model: this.model,
          messages,
          temperature: 0.75,
          max_tokens: 16000, // Increased for longer content
          response_format: { type: 'json_object' },
        });

        const content = response.choices[0]?.message?.content;
        if (!content) throw new Error('No content generated from AI');

        parsed = this.parseResponse(content);
        validationResult = this.validateContent(parsed);
        
        console.log('\n📊 Quality Metrics:');
        console.log(`   • Sections: ${validationResult.stats.sectionCount}/${QUALITY_THRESHOLDS.targetSections}`);
        console.log(`   • Analyst Actions: ${validationResult.stats.analystCount}/${QUALITY_THRESHOLDS.targetAnalystActions}`);
        console.log(`   • Options Activity: ${validationResult.stats.optionsCount}/${QUALITY_THRESHOLDS.targetOptionsActivity}`);
        console.log(`   • Focus Stocks: ${validationResult.stats.focusCount}/${QUALITY_THRESHOLDS.targetFocusStocks}`);
        console.log(`   • Estimated Words: ${validationResult.stats.estimatedWords.toLocaleString()}/${QUALITY_THRESHOLDS.targetWords}`);
        console.log(`   • Yield Curve: ${validationResult.stats.hasYieldCurve ? '✓' : '✗'}`);
        console.log(`   • Breadth: ${validationResult.stats.hasBreadthIndicators ? '✓' : '✗'}`);
        console.log(`   • Scenarios: ${validationResult.stats.hasTacticalScenarios ? '✓' : '✗'}`);
        
        if (validationResult.valid) {
          console.log('✅ Quality requirements met!');
          break;
        } else {
          console.log('\n⚠️  Quality Issues:');
          validationResult.issues.forEach(issue => console.log(`   • ${issue}`));
          if (validationResult.warnings.length > 0) {
            console.log('\n⚠️  Warnings:');
            validationResult.warnings.slice(0, 5).forEach(w => console.log(`   • ${w}`));
          }
          if (attempt <= this.maxRetries) console.log(`\n🔄 Retrying to improve quality...`);
        }
        
      } catch (error) {
        console.error(`❌ Attempt ${attempt} failed:`, error.message);
        if (attempt > this.maxRetries) throw error;
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    if (!parsed) throw new Error('Failed to generate newsletter after all attempts');

    if (validationResult?.warnings?.length > 0) {
      console.log('\n⚠️  Final Warnings:');
      validationResult.warnings.slice(0, 8).forEach(w => console.log(`   • ${w}`));
    }

    const duration = Date.now() - startTime;
    console.log('\n' + '═'.repeat(70));
    console.log(`✅ Generation Complete in ${(duration / 1000).toFixed(1)}s`);
    console.log(`📊 Sentiment: ${parsed.marketSentiment || 'N/A'}`);
    console.log(`🎯 Theme: ${(parsed.marketTheme || 'N/A').slice(0, 60)}...`);
    console.log(`📈 Trading Bias: ${parsed.tradingBias || 'N/A'}`);
    console.log('═'.repeat(70));

    return {
      subject: parsed.subject || `📊 Daily Market Report — ${dateInfo.today}`,
      preheader: parsed.preheader || 'Your institutional-grade market intelligence',
      sections: parsed.sections || [],
      marketSentiment: parsed.marketSentiment || 'neutral',
      alertType: alertType || parsed.alertType,
      analystActions: parsed.analystActions || [],
      unusualOptions: parsed.unusualOptions || [],
      keyLevels: parsed.keyLevels || {},
      focusStocks: parsed.focusStocks || [],
      sectorPerformance: parsed.sectorPerformance || [],
      economicCalendar: parsed.economicCalendar || [],
      breadthIndicators: parsed.breadthIndicators || {},
      yieldCurve: parsed.yieldCurve || {},
      tacticalScenarios: parsed.tacticalScenarios || {},
      topPicks: parsed.topPicks || [],
      riskLevel: parsed.riskLevel || 'medium',
      marketTheme: parsed.marketTheme || '',
      tradingBias: parsed.tradingBias || 'neutral',
      generatedAt: new Date().toISOString(),
      dataTimestamp: safeData.timestamp,
      reportDate: dateInfo.today,
      marketRecapDate: dateInfo.yesterday,
      version: this.version,
      quality: {
        valid: validationResult?.valid || false,
        stats: validationResult?.stats || {},
        attempts: attempt,
      },
    };
  }

  /**
   * Generate quick summary for alerts/notifications
   */
  async generateQuickSummary(data) {
    const dateInfo = this.getCurrentDateInfo();
    
    const quickPrompt = `Generate a brief (4-5 sentences) market summary for ${dateInfo.today}, recapping ${dateInfo.yesterday}'s session. 
    
Include: 
- Dominant theme
- Index moves with specific % 
- Today's key event
- Risk/opportunity assessment

Output JSON: { 
  "summary": "...", 
  "sentiment": "bullish|bearish|neutral|cautious", 
  "topEvent": "...",
  "riskLevel": "low|medium|high"
}`;
    
    const response = await this.openai.chat.completions.create({
      model: this.model,
      messages: [{ role: 'user', content: quickPrompt }],
      temperature: 0.7,
      max_tokens: 500,
      response_format: { type: 'json_object' },
    });
    
    return this.parseResponse(response.choices[0]?.message?.content);
  }

  /**
   * Update prompt configuration
   */
  updatePromptConfig(config) {
    this.promptBuilder = createPromptBuilder(config);
  }

  /**
   * Get current prompt configuration
   */
  getPromptConfig() {
    return this.promptBuilder.getConfig();
  }

  /**
   * Get processor information
   */
  getInfo() {
    return {
      version: this.version,
      model: this.model,
      maxRetries: this.maxRetries,
      qualityThresholds: QUALITY_THRESHOLDS,
      requiredSections: REQUIRED_SECTIONS,
      promptConfig: this.promptBuilder.getConfig(),
    };
  }
}

/**
 * Factory function to create AI processor
 */
export function createAIProcessor(apiKey, model, config = {}) {
  return new NewsletterAIProcessor({
    apiKey,
    model,
    promptBuilder: config.promptBuilder,
    maxRetries: config.maxRetries,
  });
}

export { QUALITY_THRESHOLDS, REQUIRED_SECTIONS };