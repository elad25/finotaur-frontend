// ==========================================
// AI Processor Adapter
// Backward compatibility layer for NewsletterBuilder
// Version 5.0
// ==========================================

import { FinotaurAgentsWorkflow, MarketDataInput, GeneratedNewsletter, createAgentsWorkflow } from './agents-workflow-sdk';

export interface DateInfo {
  date: string;
  weekday: string;
  dayOfWeek: number;
  isWeeklyMode: boolean;
  timestamp: string;
  today: string;
  time: string;
  yesterday: string;
  isWeekend: boolean;
}

export interface ProcessorInfo {
  version: string;
  model: string;
  type: string;
  agentCount: number;
  workflowId: string;
}

export class NewsletterAIProcessor {
  private workflow: FinotaurAgentsWorkflow;
  private model: string;
  private version: string = '5.0';
  private workflowId: string;

  constructor(config: { apiKey?: string; model?: string; debug?: boolean } = {}) {
    // Note: apiKey is not used - @openai/agents SDK uses OPENAI_API_KEY env var
    this.model = config.model || 'gpt-4o';
    this.workflow = createAgentsWorkflow({ debug: config.debug });
    this.workflowId = `proc_${Date.now()}`;
  }

  getCurrentDateInfo(): DateInfo {
    const now = new Date();
    const nyOptions: Intl.DateTimeFormatOptions = { timeZone: 'America/New_York' };
    const nyTime = new Date(now.toLocaleString('en-US', nyOptions));
    
    const dayOfWeek = nyTime.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const isWeeklyMode = dayOfWeek === 0 || dayOfWeek === 1;

    const dateStr = now.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'America/New_York'
    });

    const weekday = now.toLocaleDateString('en-US', { weekday: 'long', timeZone: 'America/New_York' });
    
    const today = now.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      timeZone: 'America/New_York'
    });

    const time = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'America/New_York'
    });

    const yesterdayDate = new Date(nyTime);
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yesterday = yesterdayDate.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      timeZone: 'America/New_York'
    });

    return {
      date: dateStr,
      weekday,
      dayOfWeek,
      isWeeklyMode,
      timestamp: now.toISOString(),
      today,
      time,
      yesterday,
      isWeekend
    };
  }

  async generateNewsletter(data: MarketDataInput): Promise<GeneratedNewsletter> {
    console.log('\n════════════════════════════════════════════════════════');
    console.log('📧 NewsletterAIProcessor.generateNewsletter()');
    console.log('════════════════════════════════════════════════════════\n');

    try {
      const result = await this.workflow.runWorkflow(data);
      
      // Ensure all required fields exist for email template
      return this.ensureRequiredFields(result, data);
    } catch (error) {
      console.error('❌ Error in generateNewsletter:', error);
      throw error;
    }
  }

  private ensureRequiredFields(result: GeneratedNewsletter, data: MarketDataInput): GeneratedNewsletter {
    const dateInfo = this.getCurrentDateInfo();

    return {
      ...result,
      // Core content (ensure exists)
      subject: result.subject || `Finotaur Market Intelligence - ${dateInfo.today}`,
      preheader: result.preheader || 'Daily market analysis and trading insights',
      sections: result.sections || [],
      
      // Sentiment & mode
      marketSentiment: result.marketSentiment || 'neutral',
      reportMode: result.reportMode || (dateInfo.isWeeklyMode ? 'WEEKLY' : 'DAILY'),
      alertType: result.alertType || null,
      
      // Market data arrays
      analystActions: result.analystActions || [],
      unusualOptions: result.unusualOptions || [],
      keyLevels: result.keyLevels || this.extractDefaultKeyLevels(),
      focusStocks: result.focusStocks || [],
      sectorPerformance: result.sectorPerformance || [],
      economicCalendar: result.economicCalendar || [],
      
      // Strategic data
      catalysts: result.catalysts || [],
      sectorShifts: result.sectorShifts || [],
      crossAssetConfirmation: result.crossAssetConfirmation || [],
      geopoliticalTriggers: result.geopoliticalTriggers || [],
      winnerLoserMap: result.winnerLoserMap || { winners: [], losers: [] },
      
      // Trading data
      tacticalScenarios: result.tacticalScenarios || {
        bullish: { probability: 0.33 },
        bearish: { probability: 0.33 },
        base: { probability: 0.34 }
      },
      topPicks: result.topPicks || [],
      riskLevel: result.riskLevel || 'medium',
      marketTheme: result.marketTheme || 'Mixed market conditions',
      tradingBias: result.tradingBias || 'neutral',
      
      // Metadata
      generatedAt: result.generatedAt || new Date().toISOString(),
      dataTimestamp: result.dataTimestamp || data.timestamp || new Date().toISOString(),
      reportDate: result.reportDate || dateInfo.date,
      marketRecapDate: result.marketRecapDate || dateInfo.yesterday,
      version: this.version,
      
      // Quality
      quality: result.quality || {
        valid: true,
        stats: { sectionCount: result.sections?.length || 0, analystCount: 0, optionsCount: 0 },
        attempts: 1
      },
      
      // Full report
      fullReportText: result.fullReportText || '',
      
      // Charts
      chartUrls: result.chartUrls || data.chartUrls
    };
  }

  private extractDefaultKeyLevels(): any {
    return {
      spx: {
        current: 0,
        pivot: 0,
        support: [0, 0],
        resistance: [0, 0]
      },
      ndx: {
        current: 0,
        pivot: 0,
        support: [0, 0],
        resistance: [0, 0]
      },
      vix: {
        current: 0,
        low: 15,
        elevated: 20,
        high: 30
      }
    };
  }

  async generateQuickSummary(data: MarketDataInput): Promise<{ summary: string; sentiment: string; topEvent: string; riskLevel: string }> {
    return this.workflow.generateQuickSummary(data);
  }

  getInfo(): ProcessorInfo {
    return {
      version: this.version,
      model: this.model,
      type: 'openai-agents-sdk',
      agentCount: 12,
      workflowId: this.workflowId
    };
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

export function createAIProcessor(config?: { apiKey?: string; model?: string; debug?: boolean }): NewsletterAIProcessor {
  return new NewsletterAIProcessor(config);
}

// ============================================
// RE-EXPORTS
// ============================================

export { MarketDataInput, GeneratedNewsletter } from './agents-workflow-sdk';