// ==========================================
// Email Sender Service - Type Declarations
// ==========================================

import type { GeneratedNewsletter } from '../ai/processor';

export interface EmailRecipient {
  email: string;
  subscriberId?: string;
  name?: string;
}

export interface SendResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

export interface BatchSendResult {
  total: number;
  sent: number;
  failed: number;
  results: SendResult[];
  pdfGenerated?: boolean;
}

export interface PDFGenerationResult {
  path: string;
  filename: string;
  size: number;
}

export interface EmailSenderConfig {
  apiKey: string;
  fromEmail: string;
  fromName: string;
  replyTo?: string;
  usePDF?: boolean;
}

export interface SendOptions {
  usePDF?: boolean;
  batchSize?: number;
}

export interface PDFEmailConfig {
  generatePDFEmailHTML: (newsletter: GeneratedNewsletter, pdfFilename: string) => string;
  generatePDFEmailText: (newsletter: GeneratedNewsletter, pdfFilename: string) => string;
}

export declare class EmailSender {
  constructor(config: EmailSenderConfig);
  
  resend: any;
  fromEmail: string;
  fromName: string;
  replyTo?: string;
  usePDF: boolean;
  
  sendWithPDF(
    recipient: EmailRecipient,
    newsletter: GeneratedNewsletter,
    pdfPath: string
  ): Promise<SendResult>;
  
  sendToOne(
    recipient: EmailRecipient,
    newsletter: GeneratedNewsletter
  ): Promise<SendResult>;
  
  sendBatchWithPDF(
    recipients: EmailRecipient[],
    newsletter: GeneratedNewsletter,
    batchSize?: number
  ): Promise<BatchSendResult>;
  
  sendBatch(
    recipients: EmailRecipient[],
    newsletter: GeneratedNewsletter,
    batchSize?: number
  ): Promise<BatchSendResult>;
  
  sendBatchOptimized(
    recipients: EmailRecipient[],
    newsletter: GeneratedNewsletter,
    options?: SendOptions
  ): Promise<BatchSendResult>;
  
  sendTest(
    testEmail: string,
    newsletter: GeneratedNewsletter,
    options?: SendOptions
  ): Promise<SendResult>;
  
  generatePDFOnly(
    newsletter: GeneratedNewsletter,
    outputDir?: string
  ): Promise<PDFGenerationResult>;
  
  chunkArray<T>(array: T[], size: number): T[][];
}

export declare function createEmailSender(config: EmailSenderConfig): EmailSender;

export declare const PDF_EMAIL_CONFIG: PDFEmailConfig;