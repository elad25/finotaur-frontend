// ==========================================
// Newsletter Email Template - Type Declarations
// ==========================================

import type { GeneratedNewsletter } from '../ai/processor';

export interface EmailTemplateConfig {
  companyName?: string;
  companyUrl?: string;
  logoUrl?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  textPrimary?: string;
  textSecondary?: string;
  positiveColor?: string;
  negativeColor?: string;
  unsubscribeUrl?: string;
}

/**
 * Generate the complete email HTML
 */
export declare function generateEmailHTML(
  newsletter: GeneratedNewsletter,
  config?: EmailTemplateConfig
): string;

/**
 * Generate plain text version of newsletter
 */
export declare function generatePlainText(newsletter: GeneratedNewsletter): string;

/**
 * Get the full legal disclaimer
 */
export declare function getFullDisclaimer(): string;

/**
 * Get the short disclaimer
 */
export declare function getShortDisclaimer(): string;

/**
 * Full legal disclaimer text
 */
export declare const LEGAL_DISCLAIMER: string;

/**
 * Short disclaimer text for email footer
 */
export declare const SHORT_DISCLAIMER: string;