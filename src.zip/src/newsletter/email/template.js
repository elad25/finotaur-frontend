// ==========================================
// Newsletter Email Template - Institutional Grade
// Finotaur Daily Opening Market Report
// Clean & Professional Design
// ==========================================

const DEFAULT_CONFIG = {
  companyName: 'Finotaur',
  companyUrl: 'https://finotaur.com',
  logoUrl: 'https://finotaur.com/logo.png',
  primaryColor: '#C9A646',
  secondaryColor: '#0a0a0f',
  accentColor: '#111118',
  textPrimary: '#e5e5e5',
  textSecondary: '#888888',
  positiveColor: '#22c55e',
  negativeColor: '#ef4444',
  unsubscribeUrl: '{{unsubscribe_url}}',
};

const SHORT_DISCLAIMER = `This report is for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. All investments carry risk. Always conduct your own research and consult a qualified financial advisor.`;

/**
 * Generate the complete email HTML - Clean Design
 */
export function generateEmailHTML(newsletter, config = DEFAULT_CONFIG) {
  const { 
    subject, 
    preheader, 
    sections, 
    marketSentiment, 
    marketTheme,
    reportDate
  } = newsletter;
  
  const settings = { ...DEFAULT_CONFIG, ...config };
  const { primaryColor, secondaryColor, accentColor, textPrimary, textSecondary, positiveColor, negativeColor, companyUrl, unsubscribeUrl } = settings;

  // Date strings
  const now = new Date();
  const dateStr = reportDate || now.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: 'America/New_York'
  });
  const timeStr = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'America/New_York'
  });

  // Generate sections HTML
  const sectionsHtml = sections.map(section => generateSectionHTML(section, settings)).join('');

  // Sentiment indicator
  const sentimentColor = {
    bullish: positiveColor,
    bearish: negativeColor,
    neutral: '#6b7280',
    cautious: '#f59e0b'
  }[marketSentiment] || '#6b7280';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 15px;
      line-height: 1.6;
      color: ${textPrimary};
      background-color: ${secondaryColor};
    }
    .container { max-width: 680px; margin: 0 auto; background: ${secondaryColor}; }
    
    /* Header */
    .header {
      padding: 32px 24px;
      text-align: center;
      border-bottom: 1px solid rgba(201,166,70,0.2);
    }
    .logo { color: ${primaryColor}; font-size: 28px; font-weight: 700; letter-spacing: 2px; margin-bottom: 8px; }
    .subtitle { color: ${textSecondary}; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; }
    .date { color: ${textSecondary}; font-size: 12px; margin-top: 12px; }
    .sentiment-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
    
    /* Content */
    .content { padding: 24px; }
    
    /* Section */
    .section {
      margin-bottom: 28px;
      padding: 20px;
      background: ${accentColor};
      border-radius: 8px;
      border-left: 3px solid ${primaryColor};
    }
    .section-title {
      color: ${primaryColor};
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 14px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(201,166,70,0.15);
    }
    .section-content {
      color: ${textPrimary};
      font-size: 14px;
      line-height: 1.7;
    }
    .section-content p { margin-bottom: 10px; }
    
    /* Highlights */
    .positive { color: ${positiveColor}; font-weight: 500; }
    .negative { color: ${negativeColor}; font-weight: 500; }
    .ticker { color: ${primaryColor}; font-weight: 600; }
    .highlight { color: ${primaryColor}; }
    
    /* Footer */
    .footer {
      padding: 24px;
      text-align: center;
      border-top: 1px solid rgba(255,255,255,0.05);
      background: #050508;
    }
    .footer-links { margin: 12px 0; }
    .footer-links a { color: ${textSecondary}; text-decoration: none; margin: 0 10px; font-size: 12px; }
    .footer-links a:hover { color: ${primaryColor}; }
    .disclaimer { color: #666; font-size: 10px; line-height: 1.5; margin-top: 16px; }
    .copyright { color: #555; font-size: 11px; margin-top: 12px; }

    @media (max-width: 600px) {
      .content { padding: 16px; }
      .section { padding: 16px; }
      .header { padding: 24px 16px; }
    }
  </style>
</head>
<body>
  <div style="display:none;max-height:0;overflow:hidden;">${preheader || 'Your daily market intelligence'}</div>
  
  <table width="100%" cellpadding="0" cellspacing="0" style="background:${secondaryColor};">
    <tr>
      <td align="center" style="padding:16px;">
        <table class="container" width="680" cellpadding="0" cellspacing="0" style="background:${secondaryColor};border-radius:12px;overflow:hidden;box-shadow:0 2px 20px rgba(0,0,0,0.4);">
          
          <!-- Header -->
          <tr>
            <td class="header">
              <div class="logo">FINOTAUR</div>
              <div class="subtitle">Market Intelligence Report</div>
              <div class="date">
                <span class="sentiment-dot" style="background:${sentimentColor};"></span>
                ${dateStr} • ${timeStr} ET
              </div>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td class="content">
              ${sectionsHtml}
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td class="footer">
              <div class="footer-links">
                <a href="${companyUrl}">Website</a>
                <a href="${companyUrl}/app/journal">Dashboard</a>
                <a href="${unsubscribeUrl}">Unsubscribe</a>
              </div>
              <div class="disclaimer">${SHORT_DISCLAIMER}</div>
              <div class="copyright">© ${new Date().getFullYear()} Finotaur. All Rights Reserved.</div>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

/**
 * Generate section HTML
 */
function generateSectionHTML(section, config) {
  const content = formatSectionContent(section.content, config);
  
  return `
    <div class="section">
      <div class="section-title">${section.title}</div>
      <div class="section-content">${content}</div>
    </div>
  `;
}

/**
 * Format section content - FIXED to handle objects
 */
function formatSectionContent(content, config) {
  if (!content) return '<p>No data available.</p>';
  
  // Handle non-string content (objects, arrays)
  let formatted = content;
  if (typeof content !== 'string') {
    try {
      // If it's an object, stringify it nicely
      if (Array.isArray(content)) {
        formatted = content.map(item => {
          if (typeof item === 'string') return item;
          if (typeof item === 'object') return JSON.stringify(item);
          return String(item);
        }).join('\n');
      } else if (typeof content === 'object') {
        formatted = Object.entries(content)
          .map(([key, value]) => `${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}`)
          .join('\n');
      } else {
        formatted = String(content);
      }
    } catch {
      formatted = String(content);
    }
  }
  
  // Convert newlines to HTML
  formatted = formatted
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>');
  
  formatted = `<p>${formatted}</p>`;
  
  // Style percentages
  formatted = formatted.replace(/(\+[\d.]+%)/g, '<span class="positive">$1</span>');
  formatted = formatted.replace(/(-[\d.]+%)/g, '<span class="negative">$1</span>');
  
  // Style tickers (2-5 uppercase letters, not inside tags)
  formatted = formatted.replace(/\b([A-Z]{2,5})\b(?![^<]*>)/g, '<span class="ticker">$1</span>');
  
  // Style dollar amounts
  formatted = formatted.replace(/(\$[\d,]+(?:\.\d{2})?)/g, '<span class="highlight">$1</span>');
  
  return formatted;
}

/**
 * Generate plain text version
 */
export function generatePlainText(newsletter) {
  const lines = ['═'.repeat(50), '', '  FINOTAUR', '  Market Intelligence Report', ''];
  
  const dateStr = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'America/New_York'
  });
  lines.push(`  ${dateStr}`, '', '═'.repeat(50), '');

  newsletter.sections.forEach(section => {
    lines.push('─'.repeat(40), section.title, '─'.repeat(40), '');
    
    let content = section.content;
    if (typeof content !== 'string') {
      content = JSON.stringify(content, null, 2);
    }
    lines.push(content, '');
  });

  lines.push('═'.repeat(50), '', SHORT_DISCLAIMER, '', `© ${new Date().getFullYear()} Finotaur`);
  return lines.join('\n');
}

export function getShortDisclaimer() {
  return SHORT_DISCLAIMER;
}

export { SHORT_DISCLAIMER };