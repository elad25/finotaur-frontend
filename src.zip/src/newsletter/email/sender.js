// ==========================================
// Email Sender Service - With PDF, Charts & Admin Notes
// ==========================================
// v2.0.0 - Added:
//   - Admin notes support in emails
//   - Newsletter send logging to database
// ==========================================

import { Resend } from 'resend';
import { generateEmailHTML, generatePlainText } from './template.js';
import { generateNewsletterPDF, readPDFAsBase64, cleanupOldPDFs } from './pdf-generator.js';
import { readChartAsBase64 } from '../charts/index.js';
import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

const DEFAULT_BATCH_SIZE = 100;
const DELAY_BETWEEN_BATCHES = 1000;

// Initialize Supabase client for logging
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * Build chart attachments for email
 */
function buildChartAttachments(chartPaths) {
  if (!chartPaths || Object.keys(chartPaths).length === 0) {
    return [];
  }

  const attachments = [];

  for (const [name, chartPath] of Object.entries(chartPaths)) {
    try {
      const base64 = readChartAsBase64(chartPath);
      attachments.push({
        filename: `${name}.png`,
        content: base64,
        content_id: name,
      });
      console.log(`📎 Attached chart: ${name}`);
    } catch (e) {
      console.warn(`⚠️ Could not attach chart ${name}:`, e.message);
    }
  }

  return attachments;
}

/**
 * Generate admin note HTML block
 */
function generateAdminNoteHTML(adminNote) {
  if (!adminNote || adminNote.trim() === '') return '';
  
  return `
    <div style="
      background: linear-gradient(135deg, rgba(249, 115, 22, 0.15), rgba(234, 88, 12, 0.1));
      border: 1px solid rgba(249, 115, 22, 0.3);
      border-left: 4px solid #f97316;
      border-radius: 8px;
      padding: 20px;
      margin: 24px 0;
    ">
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <span style="font-size: 20px;">📝</span>
        <div>
          <p style="
            color: #f97316;
            font-weight: 600;
            font-size: 13px;
            margin: 0 0 8px 0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          ">הערה מצוות Finotaur</p>
          <p style="
            color: #ffffff;
            font-size: 15px;
            line-height: 1.6;
            margin: 0;
            white-space: pre-wrap;
            direction: rtl;
            text-align: right;
          ">${adminNote}</p>
        </div>
      </div>
    </div>
  `;
}

/**
 * Generate admin note plain text block
 */
function generateAdminNoteText(adminNote) {
  if (!adminNote || adminNote.trim() === '') return '';
  
  return `
═══════════════════════════════════════════════════════════
📝 הערה מצוות Finotaur:

${adminNote}

═══════════════════════════════════════════════════════════
`;
}

/**
 * Email configuration for PDF newsletters
 */
const PDF_EMAIL_CONFIG = {
  generatePDFEmailHTML: (newsletter, pdfFilename, adminNote = null) => {
    const date = new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'America/New_York'
    });

    const adminNoteBlock = generateAdminNoteHTML(adminNote);

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${newsletter.subject}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background-color: #0d0d18;
      color: #ffffff;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #1a1a2e;
      border-radius: 12px;
      padding: 40px;
      border: 1px solid #C9A646;
    }
    .logo {
      text-align: center;
      margin-bottom: 24px;
    }
    .logo h1 {
      color: #C9A646;
      font-size: 32px;
      margin: 0;
      letter-spacing: 2px;
    }
    .logo p {
      color: #9ca3af;
      font-size: 14px;
      margin: 8px 0 0;
    }
    .divider {
      height: 2px;
      background: linear-gradient(90deg, transparent, #C9A646, transparent);
      margin: 24px 0;
    }
    .message {
      text-align: center;
      margin: 24px 0;
    }
    .message h2 {
      color: #ffffff;
      font-size: 20px;
      margin-bottom: 12px;
    }
    .message p {
      color: #9ca3af;
      font-size: 14px;
      line-height: 1.6;
    }
    .highlight {
      background-color: rgba(201, 166, 70, 0.1);
      border-left: 4px solid #C9A646;
      padding: 16px;
      margin: 24px 0;
      border-radius: 0 8px 8px 0;
    }
    .highlight p {
      color: #ffffff;
      font-size: 14px;
      margin: 0;
      font-style: italic;
    }
    .cta {
      text-align: center;
      margin: 32px 0;
    }
    .cta a {
      display: inline-block;
      background: linear-gradient(135deg, #C9A646, #B8963F);
      color: #0d0d18 !important;
      text-decoration: none;
      padding: 14px 32px;
      border-radius: 8px;
      font-weight: bold;
      font-size: 14px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .footer {
      text-align: center;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid rgba(255,255,255,0.1);
    }
    .footer p {
      color: #6b7280;
      font-size: 11px;
      line-height: 1.5;
      margin: 8px 0;
    }
    .footer a {
      color: #C9A646;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">
      <h1>FINOTAUR</h1>
      <p>Daily Opening Market Report</p>
    </div>
    
    <div class="divider"></div>
    
    ${adminNoteBlock}
    
    <div class="message">
      <h2>📊 Your Market Report is Ready</h2>
      <p>${date}</p>
    </div>
    
    ${newsletter.marketTheme ? `
    <div class="highlight">
      <p>"${newsletter.marketTheme}"</p>
    </div>
    ` : ''}
    
    <div class="message">
      <p>
        Your institutional-grade daily market report is attached to this email as a PDF.<br>
        Open the attachment to view the complete analysis including:
      </p>
      <p style="color: #C9A646; margin-top: 16px;">
        ✓ Market Overview &nbsp;|&nbsp; ✓ Analyst Actions &nbsp;|&nbsp; ✓ Options Activity<br>
        ✓ Sector Analysis &nbsp;|&nbsp; ✓ Focus Stocks &nbsp;|&nbsp; ✓ Trading Playbook
      </p>
    </div>
    
    <div class="cta">
      <a href="https://finotaur.com/app/journal">📝 Log Your Trades</a>
    </div>
    
    <div class="footer">
      <p>
        <a href="https://finotaur.com">Website</a> &nbsp;|&nbsp;
        <a href="https://finotaur.com/app/journal">Dashboard</a> &nbsp;|&nbsp;
        <a href="https://finotaur.com/pricing">Premium</a> &nbsp;|&nbsp;
        <a href="{{unsubscribe_url}}">Unsubscribe</a>
      </p>
      <p>
        This report is for informational purposes only and does not constitute investment advice.<br>
        Past performance is not indicative of future results. All investments carry risk.
      </p>
      <p>© ${new Date().getFullYear()} Finotaur. All Rights Reserved.</p>
    </div>
  </div>
</body>
</html>
`;
  },

  generatePDFEmailText: (newsletter, pdfFilename, adminNote = null) => {
    const date = new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'America/New_York'
    });

    const adminNoteBlock = generateAdminNoteText(adminNote);

    return `
FINOTAUR
Daily Opening Market Report
${date}

${adminNoteBlock}

═══════════════════════════════════════════════════════════

📊 YOUR MARKET REPORT IS READY

${newsletter.marketTheme ? `"${newsletter.marketTheme}"\n` : ''}

Your institutional-grade daily market report is attached to this email as a PDF.

The report includes:
• Market Overview
• Analyst Actions
• Options Activity
• Sector Analysis
• Focus Stocks
• Trading Playbook

═══════════════════════════════════════════════════════════

Log your trades at: https://finotaur.com/app/journal

═══════════════════════════════════════════════════════════

DISCLAIMER: This report is for informational purposes only and does not 
constitute investment advice. Past performance is not indicative of future 
results. All investments carry risk, including potential loss of principal.

© ${new Date().getFullYear()} Finotaur. All Rights Reserved.
    `.trim();
  },
};

/**
 * Log newsletter send to database
 */
async function logNewsletterSend(sendData) {
  try {
    const { error } = await supabase.from('newsletter_send_logs').insert({
      subject: sendData.subject,
      recipient_count: sendData.recipientCount,
      segments: sendData.segments || [],
      admin_note: sendData.adminNote || null,
      sent_by: sendData.sentBy || null,
      metadata: {
        sent: sendData.sent,
        failed: sendData.failed,
        duration_ms: sendData.durationMs,
        pdf_generated: sendData.pdfGenerated || false,
        processor_info: sendData.processorInfo || null,
      }
    });

    if (error) {
      console.error('⚠️ Failed to log newsletter send:', error.message);
    } else {
      console.log('📝 Newsletter send logged to database');
    }
  } catch (err) {
    console.error('⚠️ Error logging newsletter send:', err.message);
  }
}

export class EmailSender {
  constructor(config) {
    this.resend = new Resend(config.apiKey);
    this.fromEmail = config.fromEmail;
    this.fromName = config.fromName;
    this.replyTo = config.replyTo;
    this.usePDF = config.usePDF !== false;
  }

  /**
   * Send email with PDF attachment to one recipient
   */
  async sendWithPDF(recipient, newsletter, pdfPath, adminNote = null) {
    try {
      const pdfBase64 = readPDFAsBase64(pdfPath);
      const pdfFilename = path.basename(pdfPath);

      const html = PDF_EMAIL_CONFIG.generatePDFEmailHTML(newsletter, pdfFilename, adminNote);
      const text = PDF_EMAIL_CONFIG.generatePDFEmailText(newsletter, pdfFilename, adminNote);

      const { data, error } = await this.resend.emails.send({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: recipient.email,
        subject: newsletter.subject,
        html,
        text,
        reply_to: this.replyTo,
        attachments: [
          {
            filename: pdfFilename,
            content: pdfBase64,
            content_type: 'application/pdf',
          },
        ],
        tags: [
          { name: 'type', value: 'newsletter' },
          { name: 'format', value: 'pdf' },
          { name: 'subscriber_id', value: recipient.subscriberId || 'unknown' },
        ],
      });

      if (error) {
        console.error(`❌ Failed to send to ${recipient.email}:`, error);
        return { success: false, error: error.message };
      }

      console.log(`✅ Sent PDF to ${recipient.email} (${data?.id})`);
      return { success: true, messageId: data?.id };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      console.error(`❌ Error sending to ${recipient.email}:`, message);
      return { success: false, error: message };
    }
  }

  /**
   * Send email with charts (HTML with embedded images)
   */
  async sendWithCharts(recipient, newsletter, adminNote = null) {
    try {
      // Inject admin note into newsletter for template
      const newsletterWithNote = adminNote 
        ? { ...newsletter, adminNote } 
        : newsletter;
      
      const html = generateEmailHTML(newsletterWithNote);
      const text = generatePlainText(newsletterWithNote);
      
      const attachments = buildChartAttachments(newsletter.chartPaths);

      const { data, error } = await this.resend.emails.send({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: recipient.email,
        subject: newsletter.subject,
        html,
        text,
        reply_to: this.replyTo,
        attachments,
        tags: [
          { name: 'type', value: 'newsletter' },
          { name: 'format', value: 'html_with_charts' },
          { name: 'subscriber_id', value: recipient.subscriberId || 'unknown' },
        ],
      });

      if (error) {
        console.error(`❌ Failed to send to ${recipient.email}:`, error);
        return { success: false, error: error.message };
      }

      console.log(`✅ Sent to ${recipient.email} (${data?.id})`);
      return { success: true, messageId: data?.id };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      console.error(`❌ Error sending to ${recipient.email}:`, message);
      return { success: false, error: message };
    }
  }

  /**
   * Send email without PDF (original HTML)
   */
  async sendToOne(recipient, newsletter, adminNote = null) {
    if (newsletter.chartPaths && Object.keys(newsletter.chartPaths).length > 0) {
      return this.sendWithCharts(recipient, newsletter, adminNote);
    }

    try {
      const newsletterWithNote = adminNote 
        ? { ...newsletter, adminNote } 
        : newsletter;
      
      const html = generateEmailHTML(newsletterWithNote);
      const text = generatePlainText(newsletterWithNote);

      const { data, error } = await this.resend.emails.send({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: recipient.email,
        subject: newsletter.subject,
        html,
        text,
        reply_to: this.replyTo,
        tags: [
          { name: 'type', value: 'newsletter' },
          { name: 'format', value: 'html' },
          { name: 'subscriber_id', value: recipient.subscriberId || 'unknown' },
        ],
      });

      if (error) {
        console.error(`❌ Failed to send to ${recipient.email}:`, error);
        return { success: false, error: error.message };
      }

      console.log(`✅ Sent to ${recipient.email} (${data?.id})`);
      return { success: true, messageId: data?.id };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      console.error(`❌ Error sending to ${recipient.email}:`, message);
      return { success: false, error: message };
    }
  }

  /**
   * Send batch with PDF attachment
   */
  async sendBatchWithPDF(recipients, newsletter, options = {}) {
    const { 
      batchSize = DEFAULT_BATCH_SIZE, 
      adminNote = null,
      segments = [],
      sentBy = null,
      processorInfo = null,
    } = options;

    console.log(`📨 Starting PDF batch send to ${recipients.length} recipients...`);
    if (adminNote) {
      console.log(`📝 Including admin note: "${adminNote.substring(0, 50)}${adminNote.length > 50 ? '...' : ''}"`);
    }
    
    const startTime = Date.now();

    console.log('📄 Generating PDF...');
    let pdfResult;
    try {
      pdfResult = await generateNewsletterPDF(newsletter);
      console.log(`✅ PDF generated: ${pdfResult.filename} (${(pdfResult.size / 1024).toFixed(1)} KB)`);
    } catch (error) {
      console.error('❌ PDF generation failed:', error);
      throw new Error(`PDF generation failed: ${error.message}`);
    }

    const results = [];
    let sent = 0;
    let failed = 0;

    for (let i = 0; i < recipients.length; i += batchSize) {
      const batch = recipients.slice(i, i + batchSize);
      const batchNumber = Math.floor(i / batchSize) + 1;
      const totalBatches = Math.ceil(recipients.length / batchSize);

      console.log(`📦 Processing batch ${batchNumber}/${totalBatches} (${batch.length} emails)...`);

      const batchResults = await Promise.all(
        batch.map(recipient => this.sendWithPDF(recipient, newsletter, pdfResult.path, adminNote))
      );

      batchResults.forEach(result => {
        results.push(result);
        if (result.success) {
          sent++;
        } else {
          failed++;
        }
      });

      if (i + batchSize < recipients.length) {
        await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_BATCHES));
      }
    }

    try {
      fs.unlinkSync(pdfResult.path);
      console.log('🧹 Cleaned up PDF file');
    } catch (e) {}

    const duration = Date.now() - startTime;
    console.log(`📨 Batch send complete in ${(duration / 1000).toFixed(1)}s`);
    console.log(`   ✅ Sent: ${sent}`);
    console.log(`   ❌ Failed: ${failed}`);

    // Log to database
    await logNewsletterSend({
      subject: newsletter.subject,
      recipientCount: recipients.length,
      segments,
      adminNote,
      sentBy,
      sent,
      failed,
      durationMs: duration,
      pdfGenerated: true,
      processorInfo,
    });

    return { total: recipients.length, sent, failed, results, pdfGenerated: true };
  }

  /**
   * Send batch with charts (HTML)
   */
  async sendBatchWithCharts(recipients, newsletter, options = {}) {
    const { 
      batchSize = DEFAULT_BATCH_SIZE, 
      adminNote = null,
      segments = [],
      sentBy = null,
      processorInfo = null,
    } = options;

    console.log(`📨 Starting batch send with charts to ${recipients.length} recipients...`);
    if (adminNote) {
      console.log(`📝 Including admin note: "${adminNote.substring(0, 50)}${adminNote.length > 50 ? '...' : ''}"`);
    }
    
    const startTime = Date.now();

    const newsletterWithNote = adminNote 
      ? { ...newsletter, adminNote } 
      : newsletter;

    const html = generateEmailHTML(newsletterWithNote);
    const text = generatePlainText(newsletterWithNote);
    const chartAttachments = buildChartAttachments(newsletter.chartPaths);

    console.log(`📎 Prepared ${chartAttachments.length} chart attachments`);

    const results = [];
    let sent = 0;
    let failed = 0;

    for (let i = 0; i < recipients.length; i += batchSize) {
      const batch = recipients.slice(i, i + batchSize);
      const batchNumber = Math.floor(i / batchSize) + 1;
      const totalBatches = Math.ceil(recipients.length / batchSize);

      console.log(`📦 Processing batch ${batchNumber}/${totalBatches} (${batch.length} emails)...`);

      const batchResults = await Promise.all(
        batch.map(async (recipient) => {
          try {
            const { data, error } = await this.resend.emails.send({
              from: `${this.fromName} <${this.fromEmail}>`,
              to: recipient.email,
              subject: newsletter.subject,
              html,
              text,
              reply_to: this.replyTo,
              attachments: chartAttachments,
            });

            if (error) {
              return { success: false, error: error.message };
            }
            return { success: true, messageId: data?.id };
          } catch (err) {
            return { success: false, error: err.message };
          }
        })
      );

      batchResults.forEach(result => {
        results.push(result);
        if (result.success) {
          sent++;
        } else {
          failed++;
        }
      });

      if (i + batchSize < recipients.length) {
        await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_BATCHES));
      }
    }

    const duration = Date.now() - startTime;
    console.log(`📨 Batch send complete in ${(duration / 1000).toFixed(1)}s`);
    console.log(`   ✅ Sent: ${sent}`);
    console.log(`   ❌ Failed: ${failed}`);

    // Log to database
    await logNewsletterSend({
      subject: newsletter.subject,
      recipientCount: recipients.length,
      segments,
      adminNote,
      sentBy,
      sent,
      failed,
      durationMs: duration,
      pdfGenerated: false,
      processorInfo,
    });

    return { total: recipients.length, sent, failed, results };
  }

  /**
   * Optimized batch send (auto-selects PDF or HTML with charts)
   */
  async sendBatchOptimized(recipients, newsletter, options = {}) {
    const { 
      usePDF = this.usePDF, 
      batchSize = 50,
      adminNote = null,
      segments = [],
      sentBy = null,
      processorInfo = null,
    } = options;

    // If PDF mode
    if (usePDF) {
      return this.sendBatchWithPDF(recipients, newsletter, { 
        batchSize, 
        adminNote,
        segments,
        sentBy,
        processorInfo,
      });
    }

    // If has charts, send with charts
    if (newsletter.chartPaths && Object.keys(newsletter.chartPaths).length > 0) {
      return this.sendBatchWithCharts(recipients, newsletter, { 
        batchSize, 
        adminNote,
        segments,
        sentBy,
        processorInfo,
      });
    }

    // Original HTML batch send
    console.log(`🚀 Optimized batch send to ${recipients.length} recipients...`);
    if (adminNote) {
      console.log(`📝 Including admin note: "${adminNote.substring(0, 50)}${adminNote.length > 50 ? '...' : ''}"`);
    }
    
    const startTime = Date.now();

    const newsletterWithNote = adminNote 
      ? { ...newsletter, adminNote } 
      : newsletter;

    const html = generateEmailHTML(newsletterWithNote);
    const text = generatePlainText(newsletterWithNote);

    const results = [];
    let sent = 0;
    let failed = 0;

    const chunks = this.chunkArray(recipients, 100);

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      console.log(`📦 Sending chunk ${i + 1}/${chunks.length}...`);

      const emails = chunk.map(recipient => ({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: recipient.email,
        subject: newsletter.subject,
        html,
        text,
        reply_to: this.replyTo,
      }));

      try {
        const { data, error } = await this.resend.batch.send(emails);

        if (error) {
          console.error(`❌ Batch error:`, error);
          chunk.forEach(() => {
            results.push({ success: false, error: error.message });
            failed++;
          });
        } else {
          data?.data?.forEach((result, idx) => {
            results.push({ success: true, messageId: result.id });
            sent++;
          });
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Unknown error';
        chunk.forEach(() => {
          results.push({ success: false, error: message });
          failed++;
        });
      }

      if (i < chunks.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    const duration = Date.now() - startTime;

    // Log to database
    await logNewsletterSend({
      subject: newsletter.subject,
      recipientCount: recipients.length,
      segments,
      adminNote,
      sentBy,
      sent,
      failed,
      durationMs: duration,
      pdfGenerated: false,
      processorInfo,
    });

    return { total: recipients.length, sent, failed, results };
  }

  /**
   * Send test email
   */
  async sendTest(testEmail, newsletter, options = {}) {
    const { usePDF = this.usePDF, adminNote = null } = options;

    console.log(`🧪 Sending test email to ${testEmail}...`);
    if (adminNote) {
      console.log(`📝 Including admin note in test`);
    }

    const testNewsletter = {
      ...newsletter,
      subject: `[TEST] ${newsletter.subject}`,
    };

    if (usePDF) {
      let pdfResult;
      try {
        pdfResult = await generateNewsletterPDF(testNewsletter);
        console.log(`✅ Test PDF generated: ${pdfResult.filename}`);
      } catch (error) {
        console.error('❌ PDF generation failed:', error);
        return { success: false, error: `PDF generation failed: ${error.message}` };
      }

      const result = await this.sendWithPDF(
        { email: testEmail, subscriberId: 'test' },
        testNewsletter,
        pdfResult.path,
        adminNote
      );

      try { fs.unlinkSync(pdfResult.path); } catch (e) {}

      return result;
    }

    // Send with charts if available, including admin note
    return this.sendToOne(
      { email: testEmail, subscriberId: 'test' }, 
      testNewsletter,
      adminNote
    );
  }

  /**
   * Generate PDF only (without sending)
   */
  async generatePDFOnly(newsletter, outputDir = '/tmp') {
    console.log('📄 Generating PDF preview...');
    
    try {
      const result = await generateNewsletterPDF(newsletter, outputDir);
      console.log(`✅ PDF generated: ${result.path}`);
      return result;
    } catch (error) {
      console.error('❌ PDF generation failed:', error);
      throw error;
    }
  }

  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
}

export function createEmailSender(config) {
  return new EmailSender(config);
}

export { PDF_EMAIL_CONFIG, logNewsletterSend, generateAdminNoteHTML, generateAdminNoteText };