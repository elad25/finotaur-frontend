// src/index.js — server-delta-v14 (ESM) — UNIFIED SYSTEM (No agentWorkflow)
// Finotaur Market Engine Integration
// Updated: Removed agentWorkflow, uses unified system

import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';
import { createClient } from '@supabase/supabase-js';
import newsletterCronRouter from './routes/newsletterCron.js';
import { startNewsletterCron } from './services/newsletterCron.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../.env') });

const app = express();

// ======================================================================
// SUPABASE KEEP-ALIVE MODULE (Prevents FREE tier sleep after 7 days)
// ======================================================================
const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;

let supabase = null;
let keepAliveIntervalId = null;

function getSupabaseClient() {
  if (!supabase && SUPABASE_URL && SUPABASE_KEY) {
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    console.log('[KeepAlive] Supabase client initialized');
  }
  return supabase;
}

async function pingSupabase() {
  const client = getSupabaseClient();
  if (!client) {
    console.log('[KeepAlive] ⚠️ Supabase not configured - missing URL or KEY');
    return { success: false, error: 'not_configured' };
  }

  try {
    const start = Date.now();
    
    let result = await client.from('profiles').select('id').limit(1);
    
    if (result.error) {
      result = await client.from('trades').select('id').limit(1);
    }
    
    if (result.error) {
      result = await client.from('strategies').select('id').limit(1);
    }
    
    if (result.error) {
      const authResult = await client.auth.getSession();
      if (authResult.error) {
        console.log(`[KeepAlive] ❌ Ping failed: ${authResult.error.message}`);
        return { success: false, error: authResult.error.message, latency: Date.now() - start };
      }
    }
    
    const latency = Date.now() - start;
    console.log(`[KeepAlive] ✅ Supabase alive (${latency}ms) - ${new Date().toISOString()}`);
    return { success: true, latency, timestamp: new Date().toISOString() };
    
  } catch (e) {
    console.log(`[KeepAlive] ❌ Ping error: ${e.message}`);
    return { success: false, error: e.message };
  }
}

function startKeepAlive(intervalMinutes = 5) {
  if (keepAliveIntervalId) {
    console.log('[KeepAlive] Already running');
    return;
  }

  const client = getSupabaseClient();
  if (!client) {
    console.log('[KeepAlive] ⚠️ Cannot start - Supabase not configured');
    console.log('[KeepAlive] Make sure SUPABASE_URL and SUPABASE_ANON_KEY are set');
    return;
  }

  const intervalMs = intervalMinutes * 60 * 1000;
  
  console.log('[KeepAlive] 🚀 Starting Supabase keep-alive service...');
  
  pingSupabase();
  
  keepAliveIntervalId = setInterval(() => {
    pingSupabase();
  }, intervalMs);

  console.log(`[KeepAlive] ✅ Scheduled to ping every ${intervalMinutes} minutes`);
}

function stopKeepAlive() {
  if (keepAliveIntervalId) {
    clearInterval(keepAliveIntervalId);
    keepAliveIntervalId = null;
    console.log('[KeepAlive] 🛑 Stopped');
  }
}

// -------- CORS (credentials safe) --------
const ORIGIN = process.env.CORS_ORIGIN?.split(',') || [
  'http://localhost:5173',
  'https://finotaur.com',
  'https://www.finotaur.com',
];

app.use(cors({ origin: ORIGIN, credentials: true }));
app.use((req, res, next) => { res.setHeader('Vary', 'Origin'); next(); });
app.use(express.json());

// ======================================================================
// HEALTH CHECKS - MUST BE FIRST (Railway needs these)
// ======================================================================

app.get('/health', async (_req, res) => {
  const supabaseResult = await pingSupabase();
  
  res.status(200).json({ 
    status: 'ok',
    supabase: supabaseResult.success ? 'connected' : 'error',
    supabaseError: supabaseResult.error || null,
    supabaseLatency: supabaseResult.latency || null,
    timestamp: Date.now(),
    version: 'server-delta-v14'
  });
});

app.get('/api/ping-supabase', async (_req, res) => {
  const result = await pingSupabase();
  res.json(result);
});

app.get('/api/keepalive-status', (_req, res) => {
  res.json({
    running: keepAliveIntervalId !== null,
    supabaseConfigured: !!(SUPABASE_URL && SUPABASE_KEY),
    supabaseUrl: SUPABASE_URL ? SUPABASE_URL.substring(0, 30) + '...' : null
  });
});

app.get('/', (_req, res) => {
  res.json({ 
    status: 'Finotaur API running', 
    version: 'server-delta-v14',
    system: 'unified',
    keepAlive: keepAliveIntervalId !== null ? 'active' : 'inactive',
    timestamp: new Date().toISOString()
  });
});

app.get('/api/_whoami', (_req, res) => res.json({ version: 'server-delta-v14', origin: ORIGIN }));

// -------- Helpers (kept) --------
const UA = process.env.SEC_USER_AGENT || 'Finotaur/1.0 (contact@example.com)';
async function j(url) {
  const r = await fetch(url, { headers: { 'User-Agent': UA, 'Accept': 'application/json' } });
  if (!r.ok) throw new Error(`HTTP ${r.status} ${url}`);
  return r.json();
}
const pad10 = (s) => String(s||'').padStart(10,'0');
const stableSort = (arr) => [...(arr||[])].sort((a,b)=> new Date(a?.end || a?.endDate || a?.filed || a?.fy || a?.date || 0) - new Date(b?.end || b?.endDate || b?.filed || b?.fy || b?.date || 0));
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : null; };
const latest = (arr) => { const s = stableSort(arr).slice(-1)[0]; return s ? num(s?.val ?? s?.value) : null; };
const prev = (arr) => { const s = stableSort(arr).slice(-2); return s.length>=2 ? num(s[0]?.val ?? s[0]?.value) : null; };
const strip = (s) => String(s||'').replace(/-/g, '');

// -------- SEC helpers --------
async function resolveCikBySymbol(symbol){
  const data = await j('https://www.sec.gov/files/company_tickers.json');
  const u = String(symbol||'').toUpperCase();
  for (const k in data) {
    const row = data[k];
    if ((row?.ticker||'').toUpperCase() === u) return pad10(row.cik_str);
  }
  return null;
}
const buildFilingUrl = (cik, acc, primary) => {
  const c = String(Number(cik));
  const a = strip(acc);
  return primary
    ? `https://www.sec.gov/Archives/edgar/data/${c}/${a}/${primary}`
    : `https://www.sec.gov/Archives/edgar/data/${c}/${a}/index.json`;
};
const wantedSet = (forms) => new Set(String(forms||'').split(',').map(s=>s.trim().toUpperCase()).filter(Boolean));

// -------- Inline /api/sec/filings --------
app.get('/api/sec/filings', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || '').toUpperCase();
    if (!symbol) return res.status(400).json({ error: 'symbol_required' });
    const cik = await resolveCikBySymbol(symbol);
    if (!cik) return res.status(404).json({ error: 'cik_not_found', symbol });
    const sub = await j(`https://data.sec.gov/submissions/CIK${cik}.json`);
    const rec = sub?.filings?.recent || {};
    const N = Math.min(rec.form?.length||0, rec.filingDate?.length||0, rec.accessionNumber?.length||0, rec.primaryDocument?.length||0);
    const want = wantedSet(req.query.forms||'');
    const lim  = Math.max(1, Math.min(parseInt(req.query.limit||'20',10)||20, 100));
    const out = [];
    for (let i=0;i<N;i++){
      const form = String(rec.form[i]||'').toUpperCase();
      if (want.size && !want.has(form)) continue;
      out.push({
        form,
        filingDate: rec.filingDate[i]||null,
        reportDate: rec.reportDate?.[i]||null,
        accessionNumber: rec.accessionNumber[i]||null,
        primaryDocument: rec.primaryDocument[i]||null,
        filingUrl: buildFilingUrl(cik, rec.accessionNumber[i], rec.primaryDocument[i]),
      });
      if (out.length>=lim) break;
    }
    res.json({ symbol, cik, filings: out });
  } catch (e) {
    res.status(500).json({ error: 'sec_filings_error', message: String(e?.message||e) });
  }
});

// -------- Inline /api/fundamentals --------
const POLY_KEY = process.env.POLYGON_API_KEY || '';
function gaap(facts, key){ try { return facts?.facts?.['us-gaap']?.[key] || null; } catch { return null; } }
function unitsAny(item, keys){ if(!item?.units) return []; for(const k of keys){ if(item.units[k]) return item.units[k]; } return []; }
function buildSeries(arr){ return stableSort(arr).map(p=>({ date: p.end || p.endDate || p.fy || p.date, value: num(p.val ?? p.value) })).filter(p=>p.date); }
async function polygonPrevClose(symbol){ if(!POLY_KEY) return null; try{ const u=`https://api.polygon.io/v2/aggs/ticker/${encodeURIComponent(symbol)}/prev?adjusted=true&apiKey=${POLY_KEY}`; const d=await j(u); return d?.results?.[0]?.c ?? null; } catch { return null; } }
const growth = (curr, pre) => (curr!=null && pre!=null && pre!==0) ? ((curr-pre)/pre) : null;

async function fundamentalsPayload(symbol){
  const cik = await resolveCikBySymbol(symbol);
  if(!cik) throw Object.assign(new Error('cik_not_found'), { code:404 });
  const facts = await j(`https://data.sec.gov/api/xbrl/companyfacts/CIK${cik}.json`);
  const revenueF   = gaap(facts, 'Revenues') || gaap(facts, 'RevenueFromContractWithCustomerExcludingAssessedTax');
  const netIncF    = gaap(facts, 'NetIncomeLoss');
  const epsBasicF  = gaap(facts, 'EarningsPerShareBasic');
  const epsDilF    = gaap(facts, 'EarningsPerShareDiluted');
  const grossF     = gaap(facts, 'GrossProfit');
  const opIncF     = gaap(facts, 'OperatingIncomeLoss');
  const liabF      = gaap(facts, 'Liabilities');
  const equityF    = gaap(facts, 'StockholdersEquity');
  const divF       = gaap(facts, 'CommonStockDividendsPerShareDeclared');
  const revArr = unitsAny(revenueF, ['USD','USDm','USDMillions']);
  const niArr  = unitsAny(netIncF, ['USD','USDm','USDMillions']);
  const epsArr = unitsAny(epsDilF || epsBasicF, ['USD']);
  const gpArr  = unitsAny(grossF, ['USD']);
  const opArr  = unitsAny(opIncF, ['USD']);
  const debtArr= unitsAny(liabF, ['USD']);
  const eqArr  = unitsAny(equityF, ['USD']);
  const divArr = unitsAny(divF, ['USD']);
  const revTTM = latest(revArr);
  const revPrev= prev(revArr);
  const niTTM  = latest(niArr);
  const epsTTM = latest(epsArr);
  const gpTTM  = latest(gpArr);
  const opTTM  = latest(opArr);
  const debt   = latest(debtArr);
  const equity = latest(eqArr);
  const divPS  = latest(divArr);
  const price  = await polygonPrevClose(symbol);
  const gRev = growth(revTTM, revPrev);
  const insight = (gRev!=null)
    ? `${symbol}'s revenue ${gRev>=0?'grew':'declined'} ${(Math.abs(gRev)*100).toFixed(1)}% YoY${debt!=null?' while debt remained relatively flat':''}.`
    : `${symbol} fundamentals snapshot.`;
  const series = {
    revenue: buildSeries(revArr),
    netIncome: buildSeries(niArr),
    eps: buildSeries(epsArr),
    grossMargin: buildSeries(gpArr).map(p=>({date:p.date, value:null})),
    operatingMargin: buildSeries(opArr).map(p=>({date:p.date, value:null})),
    netMargin: buildSeries(niArr).map(p=>({date:p.date, value:null})),
    debt: buildSeries(debtArr),
    equity: buildSeries(eqArr),
  };
  const rows = (()=>{
    const map = new Map();
    const add=(k,arr)=>arr.forEach(p=>{ const d=p.end||p.date; if(!d)return; const o=map.get(d)||{endDate:d}; o[k]=num(p.val??p.value); map.set(d,o); });
    add('revenue', revArr); add('netIncome', niArr); add('eps', epsArr); add('totalDebt', debtArr); add('equity', eqArr);
    return Array.from(map.values()).sort((a,b)=> new Date(a.endDate)-new Date(b.endDate));
  })();
  const snapshot = {
    symbol, price: price ?? null,
    revenueTTM: revTTM, netIncomeTTM: niTTM, epsTTM,
    grossProfitTTM: gpTTM, operatingIncomeTTM: opTTM,
    totalDebt: debt, equity, dividendPerShare: divPS,
    pe: (price!=null && epsTTM) ? Number((price/epsTTM).toFixed(2)) : null,
    roe: (niTTM!=null && equity) ? Number((niTTM/equity).toFixed(4)) : null,
    roa: null, debtToEquity: (debt!=null && equity) ? Number((debt/equity).toFixed(2)) : null,
    currentRatio: null,
  };
  return { snapshot, series, rows, insight };
}

// --- Market Data Extensions (Stock Summary) ---
try {
  const { default: marketDataExtensions } = await import('./routes/Site_routes/All_Markets/marketDataExtensions.js');
  app.use('/api/market-data', marketDataExtensions);
  console.log('✅ Market Data Extensions mounted (Stock Summary)');
} catch (e) {
  console.error('❌ Market Data Extensions failed:', e.message);
}

app.get('/api/fundamentals/all', async (req,res)=>{
  try{ const symbol = String(req.query.symbol||'').toUpperCase(); if(!symbol) return res.status(400).json({error:'symbol_required'});
    const payload = await fundamentalsPayload(symbol); res.json(payload);
  }catch(e){ res.status(e?.code===404?404:500).json({ error:'fundamentals_error', message:String(e?.message||e) }); }
});
app.get('/api/fundamentals', async (req,res)=>{
  try{ const symbol = String(req.query.symbol||'').toUpperCase(); if(!symbol) return res.status(400).json({error:'symbol_required'});
    const payload = await fundamentalsPayload(symbol); res.json(payload);
  }catch(e){ res.status(e?.code===404?404:500).json({ error:'fundamentals_error', message:String(e?.message||e) }); }
});

// ========================================================================
// EXTERNAL ROUTERS - Each route loaded ONLY ONCE
// ========================================================================

// --- Macro routes (Market Overview) ---
try {
  const { default: macroRouter } = await import('./routes/macro.js');
  app.use('/api', macroRouter);
  console.log('✅ Macro routes mounted');
} catch (e) {
  console.error('❌ Macro routes failed:', e.message);
}

// --- Rates routes (Interest Rates Dashboard) - 24h caching for all users ---
try {
  const { default: ratesRouter } = await import('./routes/rates.js');
  app.use('/api', ratesRouter);
  console.log('✅ Rates routes mounted (24h cache)');
} catch (e) {
  console.error('❌ Rates routes failed:', e.message);
}

// --- Price routes ---
try {
  const { default: priceRoutes } = await import('./routes/price.js');
  app.use('/api', priceRoutes);
  console.log('✅ Price routes mounted');
} catch (e) {
  console.log('⚠️ Price routes not available:', e.message);
}

// --- Events routes ---
try {
  const { default: eventsRoutes } = await import('./routes/events.js');
  app.use('/api', eventsRoutes);
  console.log('✅ Events routes mounted');
} catch (e) {
  console.log('⚠️ Events routes not available:', e.message);
}

// --- Profile routes ---
try {
  const { default: profileRoutes } = await import('./routes/profile.js');
  app.use('/api', profileRoutes);
  console.log('✅ Profile routes mounted');
} catch (e) {
  console.log('⚠️ Profile routes not available:', e.message);
}

// --- News routes ---
try {
  const { default: newsRoutes } = await import('./routes/news.js');
  app.use('/api', newsRoutes);
  console.log('✅ News routes mounted');
} catch (e) {
  console.log('⚠️ News routes not available:', e.message);
}

// --- Overview reference routes ---
try {
  const { default: overviewRef } = await import('./routes/overview/reference.js');
  app.use('/api', overviewRef);
  console.log('✅ Overview reference routes mounted');
} catch (e) {
  console.log('⚠️ Overview reference routes not available:', e.message);
}

// --- Overview filings routes ---
try {
  const { default: overviewFilings } = await import('./routes/overview/filings.js');
  app.use('/api', overviewFilings);
  console.log('✅ Overview filings routes mounted');
} catch (e) {
  console.log('⚠️ Overview filings routes not available:', e.message);
}

// --- Market Data routes ---
try {
  const { default: marketDataRoute } = await import('./routes/marketData.js');
  app.use('/api', marketDataRoute);
  console.log('✅ Market Data route mounted');
} catch (e) {
  console.error('❌ Market Data route failed:', e.message);
}

// --- Top Movers routes ---
try {
  const { default: topMoversRouter } = await import('./routes/Site_routes/All_Markets/top-movers.js');
  app.use('/api/top-movers', topMoversRouter);
  console.log('✅ Top Movers routes mounted');
} catch (e) {
  console.error('❌ Top Movers routes failed:', e.message);
}

// ========================================================================
// REMOVED: Agent Workflow routes (replaced by unified system in newsletter)
// ========================================================================
// NOTE: agentWorkflow.js has been removed from the system
// Report generation is now handled directly in newsletter.js using:
// - workflow.js (unified orchestrator)
// - data-service.js (unified data fetching)
// - pdf-generator.js (unified PDF generation)
// ========================================================================

// --- Economic Calendar routes ---
try {
  const { default: economicCalendarRouter } = await import('./routes/Site_routes/All_Markets/economicCalendar.js');
  app.use('/api/all-markets/calendar', economicCalendarRouter);
  console.log('✅ Economic Calendar routes mounted');
} catch (e) {
  console.error('❌ Economic Calendar routes failed:', e.message);
}

try {
  const { default: allMarketsNewsRouter } = await import('./routes/Site_routes/All_Markets/news.js');
  app.use('/api/all-markets/news', allMarketsNewsRouter);
  console.log('✅ All Markets News routes mounted');
} catch (e) {
  console.error('❌ All Markets News routes failed:', e.message);
}

// --- Overview: prefer subroutes; fallback to overview.js ---
let mountedOverview = false;
try {
  const mod = await import('./routes/overview-subroutes.js');
  const overviewSub = mod.default || mod;
  if (overviewSub) {
    app.use('/api/overview', overviewSub);
    mountedOverview = true;
    console.log('✅ Overview subroutes mounted');
  }
} catch (e) {
  console.log('⚠️ Overview subroutes not available:', e.message);
}

if (!mountedOverview) {
  try {
    const mod2 = await import('./routes/overview.js');
    const overviewRouter = mod2.default || mod2;
    if (overviewRouter) {
      app.use('/api/overview', overviewRouter);
      console.log('✅ Overview fallback routes mounted');
    }
  } catch (e) {
    console.log('⚠️ Overview fallback routes not available:', e.message);
  }
}

// --- Main overview router ---
try {
  const { default: overviewRouter } = await import('./routes/overview.js');
  app.use('/api', overviewRouter);
  console.log('✅ Main overview router mounted');
} catch (e) {
  console.log('⚠️ Main overview router not available:', e.message);
}

// --- SEC router ---
try {
  const { default: secRouter } = await import('./routes/sec.js');
  app.use('/api/sec', secRouter);
  console.log('✅ SEC router mounted');
} catch (e) {
  console.log('⚠️ SEC router not available:', e.message);
}

// --- Register routes ---
try {
  const { default: registerRoutes } = await import('./routes/register.js');
  await registerRoutes(app);
  console.log('✅ Register routes mounted');
} catch (e) {
  console.log('⚠️ Register routes not available:', e.message);
}

// --- Symbols router ---
try {
  const { default: symbolsRouter } = await import('./routes/symbols.js');
  app.use('/api/symbols', symbolsRouter);
  console.log('✅ Symbols router mounted');
} catch (e) {
  console.log('⚠️ Symbols router not available:', e.message);
}

// ========================================================================
// NEWSLETTER ROUTER (v9.0 Unified System) - FIXED PATH
// ========================================================================
// newsletter.js is in "War Zone" folder, not in "routes"
// ========================================================================
try {
  const { default: newsletterRouter } = await import('./War Zone/newsletter.js');
  app.use('/api/newsletter', newsletterRouter);
  console.log('✅ Newsletter router mounted (v9.0 Unified)');
} catch (e) {
  console.error('❌ Newsletter route failed:', e.message);
}

app.use('/api/newsletter/cron', newsletterCronRouter);
console.log('✅ Newsletter CRON routes mounted');

// --- Newsletter Report routes (for War Zone Report Viewer) ---
try {
  const { default: newsletterReportRouter } = await import('./routes/newsletterReport.js');
  app.use('/api/newsletter', newsletterReportRouter);
  console.log('✅ Newsletter Report routes mounted');
} catch (e) {
  console.error('❌ Newsletter Report routes failed:', e.message);
}

// --- ISM Report routes (TOP SECRET - 13 AI Agents) ---
try {
  const { default: ismRouter } = await import('./routes/ismRouter.js');
  app.use('/api/ism', ismRouter);
  console.log('✅ ISM routes mounted (13 AI Agents)');
} catch (e) {
  console.error('❌ ISM routes failed:', e.message);
}

// --- Company Analysis routes (23 AI Agents + OpenAI) ---
try {
  const { default: companyRouter } = await import('./routes/companyRouter.js');
  app.use('/api/company', companyRouter);
  console.log('✅ Company Analysis routes mounted (23 AI Agents + OpenAI)');
} catch (e) {
  console.error('❌ Company Analysis routes failed:', e.message);
}

// --- Crypto Analysis routes (18 AI Agents) ---
try {
  const { default: cryptoRouter } = await import('./routes/cryptoRouter.js');
  app.use('/api/crypto', cryptoRouter);
  console.log('✅ Crypto Analysis routes mounted (18 AI Agents)');
} catch (e) {
  console.error('❌ Crypto Analysis routes failed:', e.message);
}

// --- Weekly Report routes (20 AI Agents) ---
try {
  const { setupWeeklyRoutes } = await import('./TopSecret/Weekly/weekly-routes.js');
  setupWeeklyRoutes(app, getSupabaseClient());
  console.log('✅ Weekly Report routes mounted (20 AI Agents)');
} catch (e) {
  console.error('❌ Weekly Report routes failed:', e.message);
}

// ============================================
// ISM SCHEDULER STATUS & TEST ENDPOINTS
// ============================================
app.get('/api/ism/scheduler-status', (req, res) => {
  const scheduler = app.get('ismScheduler');
  
  if (!scheduler) {
    return res.json({
      enabled: false,
      message: 'ISM Scheduler not running. Set ISM_SCHEDULER_ENABLED=true'
    });
  }
  
  res.json({
    enabled: true,
    ...scheduler.getStatus()
  });
});

// Manual trigger for testing (remove in production or add auth)
app.post('/api/ism/trigger-test', async (req, res) => {
  const scheduler = app.get('ismScheduler');
  
  if (!scheduler) {
    return res.status(400).json({ error: 'Scheduler not running' });
  }
  
  try {
    const month = req.body.month || null;
    const result = await scheduler.triggerNow(month, {
      isAdminOverride: true,
      overrideReason: 'Manual test trigger',
      createNotification: true,
    });
    
    res.json({
      success: result.success,
      reportId: result.reportId,
      pdfUrl: result.pdfUrl,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
// ============================================
// ALL SCHEDULERS STATUS ENDPOINT
// ============================================
app.get('/api/schedulers/status', async (req, res) => {
  const ismScheduler = app.get('ismScheduler');
  const companyScheduler = app.get('companyScheduler');
  
  // Get Crypto scheduler status via internal fetch
  let cryptoStatus = { enabled: false };
  try {
    const { getCryptoScheduler } = await import('./TopSecret/CryptoAnalysis/init-scheduler.js');
    const cryptoScheduler = getCryptoScheduler();
    if (cryptoScheduler) {
      cryptoStatus = { enabled: true, ...cryptoScheduler.getStatus() };
    }
  } catch (e) {
    cryptoStatus = { enabled: false, error: e.message };
  }
  
  res.json({
    timestamp: new Date().toISOString(),
    schedulers: {
      ism: ismScheduler ? { enabled: true, ...ismScheduler.getStatus() } : { enabled: false },
      company: companyScheduler ? { enabled: true, ...companyScheduler.getStatus() } : { enabled: false },
      crypto: cryptoStatus,
    }
  });
});
// ============================================
// CRYPTO SCHEDULER ROUTES
// ============================================
try {
  const { addSchedulerRoutes: addCryptoSchedulerRoutes } = await import('./TopSecret/CryptoAnalysis/init-scheduler.js');
  addCryptoSchedulerRoutes(app);
  console.log('✅ Crypto Scheduler routes mounted');
} catch (e) {
  console.log('⚠️ Crypto Scheduler routes not available:', e.message);
}

// -------- 404 LAST --------
app.use((req, res) => res.status(404).json({ error: 'not_found', path: req.path }));

// ======================================================================
// START SERVER
// ======================================================================
const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, "0.0.0.0", () => {
  console.log(`[finotaur] server-delta-v14 (Unified System) on port ${PORT}`);
  console.log(`[finotaur] Health check available at /health`);
  console.log(`[finotaur] Macro snapshot at /api/macro/snapshot`);
  console.log(`[finotaur] Interest Rates at /api/rates/central-banks (24h cache)`);
  console.log(`[finotaur] Newsletter at /api/newsletter (v9.0 Unified)`);
  
  startKeepAlive(5);
  
  // AUTO START NEWSLETTER CRON
  if (process.env.NEWSLETTER_CRON_ENABLED === 'true') {
    startNewsletterCron();
  } else {
    console.log('[CRON] Newsletter cron disabled');
  }
  
  // ============================================
  // ISM REPORT SCHEDULER - Auto-generates monthly reports
  // Runs 10:30 AM ET on days 1-5 of each month
  // ============================================
  if (process.env.ISM_SCHEDULER_ENABLED === 'true') {
    import('./TopSecret/ISM/scheduler.js')
      .then(({ createISMScheduler }) => {
        const ismScheduler = createISMScheduler(getSupabaseClient(), {
          perplexityApiKey: process.env.PERPLEXITY_API_KEY,
          openaiApiKey: process.env.OPENAI_API_KEY,
          autoStart: true,
        });
        
        console.log('[ISM Scheduler] ✅ v4.2 Started - 9:00 AM ET on days 1-10 (next-day distribution)');
        
        // Store reference for status endpoint
        app.set('ismScheduler', ismScheduler);
      })
      .catch((error) => {
        console.error('[ISM Scheduler] ❌ Failed to start:', error.message);
      });
  } else {
    console.log('[ISM Scheduler] Disabled (set ISM_SCHEDULER_ENABLED=true to enable)');
  }
 // ============================================
  // CRYPTO REPORT SCHEDULER
  // Runs 18:00 UTC on 10th and 25th of each month
  // ============================================
  if (process.env.CRYPTO_SCHEDULER_ENABLED === 'true') {
    import('./TopSecret/CryptoAnalysis/init-scheduler.js')
      .then(({ startCryptoScheduler }) => {
        startCryptoScheduler();
        console.log('[Crypto Scheduler] ✅ Started - will run 18:00 UTC on 10th & 25th');
      })
      .catch((error) => {
        console.error('[Crypto Scheduler] ❌ Failed to start:', error.message);
      });
  } else {
    console.log('[Crypto Scheduler] Disabled (set CRYPTO_SCHEDULER_ENABLED=true to enable)');
  }

  // ============================================
  // COMPANY ANALYSIS SCHEDULER - ISM Integration
  // Runs on 10th and 20th at 09:00 AM Israel time
  // Generates company reports based on ISM recommendations
  // ============================================
   if (process.env.COMPANY_SCHEDULER_ENABLED === 'true') {
    import('./TopSecret/CompanyAnalysis/scheduler.js')
      .then(({ createCompanyScheduler }) => {
        const companyScheduler = createCompanyScheduler(getSupabaseClient(), {
          cronExpression: '0 8 * * 0',           // Weekly: Sundays 8 AM ET
          ismCronExpression: '0 9 10,20 * *',    // ISM: 10th & 20th at 9:00 AM ET
          earningsCronExpression: '0 9 30 * *',  // Earnings: 30th at 9:00 AM ET
          timezone: 'America/New_York',          // ✅ New York timezone
          enableIsmReports: true,
          enableEarningsReports: true,
          autoStart: true,
        });
        
        console.log('[Company Scheduler] ✅ Started - Schedule (ET):');
        console.log('[Company Scheduler]    • 10th at 9:00 AM ET - ISM Report #1');
        console.log('[Company Scheduler]    • 20th at 9:00 AM ET - ISM Report #2');
        console.log('[Company Scheduler]    • 30th at 9:00 AM ET - Earnings Report');
        
        // Store reference for status endpoint
        app.set('companyScheduler', companyScheduler);
      })
      .catch((error) => {
        console.error('[Company Scheduler] ❌ Failed to start:', error.message);
      });
  } else {
    console.log('[Company Scheduler] Disabled (set COMPANY_SCHEDULER_ENABLED=true to enable)');
  }
});