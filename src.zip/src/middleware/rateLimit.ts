// src/middleware/rateLimit.ts
import { Request, Response, NextFunction } from "express";

interface RateLimitOptions {
  windowMs?: number;
  max?: number;
}

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

const store: RateLimitStore = {};

export function rateLimit(options: RateLimitOptions = {}) {
  const windowMs = options.windowMs || 60_000;
  const max = options.max || 60;

  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();

    if (!store[ip] || now > store[ip].resetTime) {
      store[ip] = { count: 1, resetTime: now + windowMs };
      return next();
    }

    store[ip].count++;

    if (store[ip].count > max) {
      res.status(429).json({
        error: "rate_limit_exceeded",
        retryAfter: Math.ceil((store[ip].resetTime - now) / 1000),
      });
      return;
    }

    next();
  };
}