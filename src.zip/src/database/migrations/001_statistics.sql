-- ===================================================================
-- FINOTAUR STATISTICS ENHANCEMENT
-- Phase 1: MVP - Computed fields for existing trades table
-- Safe to run - only ADDS columns, doesn't change existing data
-- ===================================================================

-- Add computed columns to trades table (IF NOT EXISTS = safe)
ALTER TABLE trades 
ADD COLUMN IF NOT EXISTS direction VARCHAR(10),
ADD COLUMN IF NOT EXISTS r DECIMAL(10, 4),
ADD COLUMN IF NOT EXISTS duration_minutes INTEGER;

-- Note: session, outcome, pnl already exist in your schema ✅

-- ===================================================================
-- TRIGGER FUNCTIONS (safe to create - won't break existing)
-- ===================================================================

-- 1. Calculate Direction (LONG/SHORT from side field)
CREATE OR REPLACE FUNCTION calculate_direction()
RETURNS TRIGGER AS $$
BEGIN
  -- Use existing 'side' field
  IF NEW.side IS NOT NULL THEN
    NEW.direction = NEW.side;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Calculate R (Risk-Reward Ratio)
CREATE OR REPLACE FUNCTION calculate_r()
RETURNS TRIGGER AS $$
DECLARE
  risk_amount DECIMAL;
  actual_pnl DECIMAL;
BEGIN
  -- Only calculate if we have all required fields
  IF NEW.stop_price IS NOT NULL 
     AND NEW.entry_price IS NOT NULL 
     AND NEW.quantity IS NOT NULL 
     AND NEW.exit_price IS NOT NULL THEN
    
    -- Calculate risk amount (distance from entry to stop)
    risk_amount = ABS(NEW.entry_price - NEW.stop_price) * NEW.quantity;
    
    -- Use existing pnl field or calculate
    actual_pnl = COALESCE(NEW.pnl, (NEW.exit_price - NEW.entry_price) * NEW.quantity);
    
    -- Subtract fees if exist
    actual_pnl = actual_pnl - COALESCE(NEW.fees, 0);
    
    -- Calculate R ratio
    IF risk_amount > 0 THEN
      NEW.r = actual_pnl / risk_amount;
    ELSE
      NEW.r = 0;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. Calculate Duration (in minutes)
CREATE OR REPLACE FUNCTION calculate_duration()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.open_at IS NOT NULL AND NEW.close_at IS NOT NULL THEN
    NEW.duration_minutes = EXTRACT(EPOCH FROM (NEW.close_at - NEW.open_at)) / 60;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ===================================================================
-- ATTACH TRIGGERS (safe - checks if exists first)
-- ===================================================================

DROP TRIGGER IF EXISTS trigger_calculate_direction ON trades;
CREATE TRIGGER trigger_calculate_direction
  BEFORE INSERT OR UPDATE ON trades
  FOR EACH ROW
  EXECUTE FUNCTION calculate_direction();

DROP TRIGGER IF EXISTS trigger_calculate_r ON trades;
CREATE TRIGGER trigger_calculate_r
  BEFORE INSERT OR UPDATE ON trades
  FOR EACH ROW
  EXECUTE FUNCTION calculate_r();

DROP TRIGGER IF EXISTS trigger_calculate_duration ON trades;
CREATE TRIGGER trigger_calculate_duration
  BEFORE INSERT OR UPDATE ON trades
  FOR EACH ROW
  EXECUTE FUNCTION calculate_duration();

-- ===================================================================
-- PERFORMANCE INDEXES (safe - IF NOT EXISTS)
-- ===================================================================

CREATE INDEX IF NOT EXISTS idx_trades_close_at ON trades(close_at) WHERE close_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_user_id ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_trades_outcome ON trades(outcome);
CREATE INDEX IF NOT EXISTS idx_trades_session ON trades(session);
CREATE INDEX IF NOT EXISTS idx_trades_tags ON trades USING GIN(tags);

-- Composite indexes for statistics queries
CREATE INDEX IF NOT EXISTS idx_trades_user_close ON trades(user_id, close_at) WHERE close_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_trades_user_strategy ON trades(user_id, strategy);

-- ===================================================================
-- BACKFILL EXISTING TRADES (trigger recalculation)
-- Safe - only updates calculated fields
-- ===================================================================

-- This will trigger all the functions above to recalculate
UPDATE trades 
SET id = id 
WHERE close_at IS NOT NULL;

-- ===================================================================
-- VERIFICATION QUERIES (optional - run to check)
-- ===================================================================

-- Check if columns were added
-- SELECT column_name, data_type 
-- FROM information_schema.columns 
-- WHERE table_name = 'trades' 
-- AND column_name IN ('direction', 'r', 'duration_minutes');

-- Check if triggers are active
-- SELECT trigger_name, event_manipulation 
-- FROM information_schema.triggers 
-- WHERE event_object_table = 'trades';