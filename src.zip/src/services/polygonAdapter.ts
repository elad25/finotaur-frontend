import { withCache } from "../utils/cache";

const KEY = process.env.POLYGON_API_KEY;
const BASE = process.env.POLYGON_BASE || "https://api.polygon.io";

async function jsonFetch(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Polygon fetch ${url} -> ${r.status}`);
  return r.json();
}

export async function fetchPolygonLogoProfile(symbol: string) {
  return withCache(`poly:logo:${symbol}`, 6*60_000, async () => {
    if (!KEY) return {};
    const url = `${BASE}/v3/reference/tickers/${encodeURIComponent(symbol)}?apiKey=${KEY}`;
    try { return await jsonFetch(url); } catch { return {}; }
  });
}

// Financial statements (annual/quarterly/TTM)
export async function fetchPolygonFinancials(symbol: string, limit = 10) {
  return withCache(`poly:fin:${symbol}:${limit}`, 10*60_000, async () => {
    if (!KEY) return { results: [] };
    const url = `${BASE}/vX/reference/financials?ticker=${encodeURIComponent(symbol)}&limit=${limit}&apiKey=${KEY}`;
    try { return await jsonFetch(url); } catch { return { results: [] }; }
  });
}

// Prev close (price) — works without the snapshot entitlement
export async function fetchPolygonPrevClose(symbol: string) {
  return withCache(`poly:prev:${symbol}`, 30_000, async () => {
    if (!KEY) return {};
    const url = `${BASE}/v2/aggs/ticker/${encodeURIComponent(symbol)}/prev?adjusted=true&apiKey=${KEY}`;
    try { return await jsonFetch(url); } catch { return {}; }
  });
}