
import { withCache } from "../utils/cache";
const SEC_BASE = process.env.SEC_PROXY_URL || "";
async function jsonFetch(url: string) {
  const r = await fetch(url, { headers: { "user-agent": "Finotaur/1.0" } });
  if (!r.ok) throw new Error(`SEC fetch ${url} -> ${r.status}`);
  return r.json();
}
export async function fetchSecFundamentals(symbol: string) {
  const key = `sec:fundamentals:${symbol}`;
  return withCache(key, 5*60_000, async () => {
    if (!SEC_BASE) return { series: {}, kpis: {}, statements: {} };
    const url = `${SEC_BASE.replace(/\/$/, "")}/api/finotaur/fundamentals?symbol=${encodeURIComponent(symbol)}`;
    try { return await jsonFetch(url); } catch { return { series: {}, kpis: {}, statements: {} }; }
  });
}
