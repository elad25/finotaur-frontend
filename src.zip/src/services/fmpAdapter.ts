
import { withCache } from "../utils/cache";
const KEY = process.env.FMP_API_KEY;
const BASE = process.env.FMP_BASE || "https://financialmodelingprep.com/api";
async function jsonFetch(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`FMP fetch ${url} -> ${r.status}`);
  return r.json();
}
export async function fetchSectorAverages(symbol: string) {
  return withCache(`fmp:sector:${symbol}`, 30*60_000, async () => {
    if (!KEY) return {};
    try {
      const url = `${BASE}/v4/sector-price-earning-ratio?apikey=${KEY}`;
      return await jsonFetch(url);
    } catch { return {}; }
  });
}
