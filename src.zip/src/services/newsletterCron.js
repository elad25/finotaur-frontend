// =====================================================
// FINOTAUR NEWSLETTER CRON SERVICE - v3.2.0 JS
// =====================================================
// Location: src/services/newsletterCron.js
// =====================================================

import cron from 'node-cron';
import { supabase } from '../lib/supabaseServer.js';

// ============================================
// CRON CONFIGURATION
// ============================================

const CRON_SCHEDULE = '0 9 * * 1-5';  // 9:00 AM Mon-Fri
const CRON_TIMEZONE = 'America/New_York';

let cronJobConfig = {
  enabled: false,
  schedule: CRON_SCHEDULE,
  timezone: CRON_TIMEZONE,
  lastRun: null,
  lastStatus: null,
  lastError: null,
};

let scheduledJob = null;

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Get all eligible newsletter recipients based on DB config
 */
export async function getEligibleRecipients() {
  try {
    // Get inclusion settings from DB
    const { data: configData, error: configError } = await supabase
      .rpc('get_newsletter_inclusion_status');
    
    if (configError) {
      console.error('[CRON] Config error:', configError);
      throw configError;
    }
    
    const config = configData?.[0] || {};
    const premiumIncluded = config.premium_included || false;
    const basicIncluded = config.basic_included || false;
    
    console.log(`[CRON] Config loaded: premium=${premiumIncluded}, basic=${basicIncluded}`);
    
    // Get all users with relevant info
    const { data: users, error: usersError } = await supabase
      .from('profiles')
      .select('id, email, display_name, account_type, subscription_status, newsletter_status, newsletter_enabled')
      .not('email', 'is', null);
    
    if (usersError) {
      console.error('[CRON] Users query error:', usersError);
      throw usersError;
    }
    
    const recipients = [];
    
    for (const user of users || []) {
      // Newsletter subscribers (active + trial) always included
      if (user.newsletter_status === 'active' || user.newsletter_status === 'trial') {
        recipients.push({
          id: user.id,
          email: user.email,
          display_name: user.display_name,
          source: 'newsletter_subscriber',
        });
        continue;
      }
      
      // Premium users as perk
      if (user.account_type === 'premium' && 
          user.subscription_status === 'active' && 
          premiumIncluded &&
          user.newsletter_enabled !== false) {
        recipients.push({
          id: user.id,
          email: user.email,
          display_name: user.display_name,
          source: 'premium_perk',
        });
        continue;
      }
      
      // Basic users as perk
      if (user.account_type === 'basic' && 
          user.subscription_status === 'active' && 
          basicIncluded &&
          user.newsletter_enabled !== false) {
        recipients.push({
          id: user.id,
          email: user.email,
          display_name: user.display_name,
          source: 'basic_perk',
        });
      }
    }
    
    return recipients;
  } catch (error) {
    console.error('[CRON] Error getting eligible recipients:', error);
    throw error;
  }
}

/**
 * Log cron execution to database
 */
async function logCronExecution(status, details = {}) {
  try {
    await supabase.from('newsletter_cron_logs').insert({
      status,
      recipient_count: details.recipientCount || 0,
      sent_count: details.sentCount || 0,
      failed_count: details.failedCount || 0,
      subject: details.subject || null,
      duration_ms: details.durationMs || null,
      qa_score: details.qaScore || null,
      error_message: details.error || null,
      triggered_at: new Date().toISOString(),
      completed_at: status === 'completed' || status === 'error' ? new Date().toISOString() : null,
    });
  } catch (err) {
    console.error('[CRON] Failed to log execution:', err);
  }
}

/**
 * Check if today is a market holiday (US)
 */
async function isMarketHoliday() {
  const holidays2025 = [
    '2025-01-01', '2025-01-20', '2025-02-17', '2025-04-18',
    '2025-05-26', '2025-06-19', '2025-07-04', '2025-09-01',
    '2025-11-27', '2025-12-25',
  ];
  
  const today = new Date().toISOString().split('T')[0];
  return holidays2025.includes(today);
}

// ============================================
// MAIN CRON JOB FUNCTION
// ============================================

async function runScheduledNewsletter() {
  const startTime = Date.now();
  
  console.log('');
  console.log('═══════════════════════════════════════════════════════');
  console.log('  🚀 FINOTAUR NEWSLETTER CRON JOB STARTED');
  console.log(`  📅 ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} (New York)`);
  console.log('═══════════════════════════════════════════════════════');
  console.log('');
  
  cronJobConfig.lastRun = new Date();
  cronJobConfig.lastStatus = 'pending';
  
  try {
    await logCronExecution('started', {});
    
    // Check for holidays
    if (await isMarketHoliday()) {
      console.log('[CRON] 📅 Market holiday detected - skipping newsletter');
      cronJobConfig.lastStatus = 'skipped';
      await logCronExecution('skipped', { error: 'Market holiday' });
      return { success: true, message: 'Skipped - market holiday' };
    }
    
    // Step 1: Get eligible recipients
    console.log('[CRON] Step 1/2: Getting eligible recipients...');
    const recipients = await getEligibleRecipients();
    
    if (recipients.length === 0) {
      console.log('[CRON] ⚠️ No eligible recipients found - skipping');
      cronJobConfig.lastStatus = 'skipped';
      await logCronExecution('skipped', { error: 'No recipients' });
      return { success: true, message: 'No recipients', sent: 0 };
    }
    
    const subscriberCount = recipients.filter(r => r.source === 'newsletter_subscriber').length;
    const premiumCount = recipients.filter(r => r.source === 'premium_perk').length;
    const basicCount = recipients.filter(r => r.source === 'basic_perk').length;
    
    console.log(`[CRON] Found ${recipients.length} eligible recipients:`);
    console.log(`  - Newsletter subscribers: ${subscriberCount}`);
    console.log(`  - Premium perks: ${premiumCount}`);
    console.log(`  - Basic perks: ${basicCount}`);
    
    // Step 2: Call Edge Function
    console.log('[CRON] Step 2/2: Calling Edge Function...');
    
    const edgeFunctionUrl = `${process.env.SUPABASE_URL}/functions/v1/newsletter-cron`;
    const cronSecret = process.env.CRON_SECRET;
    
    if (!cronSecret) {
      throw new Error('CRON_SECRET not configured in environment');
    }
    
    const response = await fetch(`${edgeFunctionUrl}?secret=${cronSecret}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
      },
      body: JSON.stringify({
        trigger: 'node_cron',
        timestamp: new Date().toISOString(),
        recipientCount: recipients.length,
        recipientBreakdown: { subscriberCount, premiumCount, basicCount },
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Edge Function failed: ${response.status} - ${errorText}`);
    }
    
    const result = await response.json();
    const durationMs = Date.now() - startTime;
    
    await logCronExecution('completed', {
      recipientCount: recipients.length,
      sentCount: result.sent || 0,
      failedCount: result.failed || 0,
      subject: result.subject || null,
      qaScore: result.qaScore || null,
      durationMs,
    });
    
    cronJobConfig.lastStatus = 'success';
    cronJobConfig.lastError = null;
    
    console.log('');
    console.log('═══════════════════════════════════════════════════════');
    console.log('  ✅ NEWSLETTER CRON JOB COMPLETED SUCCESSFULLY');
    console.log(`  📬 Sent: ${result.sent || 0} | Failed: ${result.failed || 0}`);
    console.log(`  ⏱️  Duration: ${(durationMs / 1000).toFixed(1)}s`);
    if (result.subject) console.log(`  📧 Subject: ${result.subject}`);
    if (result.qaScore) console.log(`  📊 QA Score: ${result.qaScore}/100`);
    console.log('═══════════════════════════════════════════════════════');
    console.log('');
    
    return {
      success: true,
      sent: result.sent || 0,
      failed: result.failed || 0,
      subject: result.subject,
      qaScore: result.qaScore,
    };
    
  } catch (error) {
    const durationMs = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    
    cronJobConfig.lastStatus = 'error';
    cronJobConfig.lastError = errorMessage;
    
    await logCronExecution('error', { durationMs, error: errorMessage });
    
    console.error('');
    console.error('═══════════════════════════════════════════════════════');
    console.error('  ❌ NEWSLETTER CRON JOB FAILED');
    console.error(`  Error: ${errorMessage}`);
    console.error(`  ⏱️  Duration: ${(durationMs / 1000).toFixed(1)}s`);
    console.error('═══════════════════════════════════════════════════════');
    console.error('');
    
    return { success: false, error: errorMessage };
  }
}

// ============================================
// CRON JOB CONTROL
// ============================================

export function startNewsletterCron() {
  if (scheduledJob) {
    console.log('[CRON] Newsletter cron job is already running');
    return;
  }
  
  console.log('');
  console.log('╔═══════════════════════════════════════════════════════╗');
  console.log('║     FINOTAUR NEWSLETTER CRON SERVICE INITIALIZED      ║');
  console.log('╠═══════════════════════════════════════════════════════╣');
  console.log(`║  Schedule: ${CRON_SCHEDULE.padEnd(42)}║`);
  console.log(`║  Timezone: ${CRON_TIMEZONE.padEnd(42)}║`);
  console.log('║  Days: Monday - Friday                                ║');
  console.log('║  Time: 9:00 AM New York                               ║');
  console.log('╚═══════════════════════════════════════════════════════╝');
  console.log('');
  
  scheduledJob = cron.schedule(
    CRON_SCHEDULE,
    runScheduledNewsletter,
    { timezone: CRON_TIMEZONE }
  );
  
  cronJobConfig.enabled = true;
  console.log('[CRON] ✅ Newsletter cron job started successfully');
}

export function stopNewsletterCron() {
  if (scheduledJob) {
    scheduledJob.stop();
    scheduledJob = null;
    cronJobConfig.enabled = false;
    console.log('[CRON] 🛑 Newsletter cron job stopped');
  }
}

export function getCronStatus() {
  let nextRun = null;
  
  if (cronJobConfig.enabled) {
    const now = new Date();
    const next = new Date(now);
    next.setHours(9, 0, 0, 0);
    
    const nyHour = parseInt(new Date().toLocaleString('en-US', { 
      timeZone: 'America/New_York', 
      hour: 'numeric', 
      hour12: false 
    }));
    
    if (nyHour >= 9) {
      next.setDate(next.getDate() + 1);
    }
    
    while (next.getDay() === 0 || next.getDay() === 6) {
      next.setDate(next.getDate() + 1);
    }
    
    nextRun = next.toISOString();
  }
  
  return { ...cronJobConfig, nextRun };
}

export async function triggerNewsletterManually() {
  console.log('[CRON] 🔧 Manual trigger requested');
  return runScheduledNewsletter();
}

export default {
  startNewsletterCron,
  stopNewsletterCron,
  getCronStatus,
  triggerNewsletterManually,
  getEligibleRecipients,
};