export { fetchSecData as fetchKpis } from "./sec";
