export { fetchSecData as fetchTrends } from "./sec";
