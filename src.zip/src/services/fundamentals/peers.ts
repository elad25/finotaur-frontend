export const fetchPeers = async (_: string) => ({ tickers: [], metrics: {} });
