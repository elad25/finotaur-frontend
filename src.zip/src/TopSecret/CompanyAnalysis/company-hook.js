// =====================================================
// ISM + EARNINGS → COMPANY REPORTS INTEGRATION HOOK
// =====================================================
// Location: src/TopSecret/ISM/company-hook.js
//
// This hooks into ISM report generation and earnings events
// to automatically schedule company reports.
//
// v2.1 CHANGES:
// - 3 reports per month:
//   • 2 ISM-based (10th & 20th)
//   • 1 Earnings-based (30th) - companies with 5%+ moves
//
// Uses:
// - Existing ism_ticker_selections table
// - Existing ism_trade_ideas table  
// - Existing Company Scheduler (addToQueue)
// - New fetchEarningsMovers function
// =====================================================

const { fetchEarningsMovers } = require('./data-service');

/**
 * Hook to call after ISM report is successfully generated
 * Schedules 2 company reports from ISM-recommended tickers
 * 
 * @param {object} supabase - Supabase client
 * @param {string} reportMonth - Format: "2025-01"
 * @param {object} options - Optional configuration
 */
async function onIsmReportGenerated(supabase, reportMonth, options = {}) {
  const { count = 2, companyScheduler = null } = options;
  
  console.log(`\n[ISM→Company Hook] ════════════════════════════════════`);
  console.log(`[ISM→Company Hook] ISM Report completed: ${reportMonth}`);
  console.log(`[ISM→Company Hook] Scheduling ${count} company reports...`);
  console.log(`[ISM→Company Hook] ════════════════════════════════════\n`);
  
  try {
    // Call DB function to schedule company reports
    const { data: scheduled, error } = await supabase.rpc('schedule_company_reports_from_ism', {
      p_ism_report_month: reportMonth,
      p_count: count
    });
    
    if (error) {
      console.error(`[ISM→Company Hook] ❌ Schedule failed:`, error.message);
      return { success: false, error: error.message };
    }
    
    const scheduledTickers = scheduled?.filter(s => s.scheduled) || [];
    
    if (scheduledTickers.length === 0) {
      console.log(`[ISM→Company Hook] ⚠️ No new tickers to schedule (may already exist)`);
      return { success: true, scheduled: [], message: 'No new tickers to schedule' };
    }
    
    console.log(`[ISM→Company Hook] ✅ Scheduled ${scheduledTickers.length} company reports:`);
    scheduledTickers.forEach(t => {
      console.log(`  • ${t.ticker} (${t.sector})`);
    });
    
    // If we have a company scheduler instance, add to queue immediately
    if (companyScheduler) {
      for (const item of scheduledTickers) {
        try {
          await companyScheduler.addToQueue(item.ticker, {
            priority: 'high',
            requestedBy: 'ism_auto',
            scheduledFor: null, // Process immediately
          });
          console.log(`[ISM→Company Hook] Added ${item.ticker} to Company Scheduler queue`);
        } catch (err) {
          console.warn(`[ISM→Company Hook] Failed to add ${item.ticker} to queue:`, err.message);
        }
      }
    }
    
    return {
      success: true,
      scheduled: scheduledTickers,
      count: scheduledTickers.length
    };
    
  } catch (err) {
    console.error(`[ISM→Company Hook] ❌ Exception:`, err.message);
    return { success: false, error: err.message };
  }
}

/**
 * Process pending ISM-triggered company reports
 * Call this from a scheduler/cron job
 * 
 * @param {object} supabase - Supabase client
 * @param {object} companyService - Company Analysis service
 * @param {number} limit - Max reports to process
 */
async function processPendingIsmCompanyReports(supabase, companyService, limit = 2) {
  console.log(`\n[ISM→Company Processor] Checking for pending reports...`);
  
  try {
    // Get pending reports
    const { data: pending, error } = await supabase.rpc('get_pending_auto_company_reports', {
      p_limit: limit
    });
    
    if (error) {
      console.error(`[ISM→Company Processor] ❌ Error:`, error.message);
      return;
    }
    
    if (!pending || pending.length === 0) {
      // console.log(`[ISM→Company Processor] No pending reports`);
      return;
    }
    
    console.log(`[ISM→Company Processor] Found ${pending.length} pending reports`);
    
    // Process each
    for (const item of pending) {
      await generateSingleReport(supabase, companyService, item);
      
      // Wait between reports
      await new Promise(r => setTimeout(r, 5000));
    }
    
  } catch (err) {
    console.error(`[ISM→Company Processor] ❌ Exception:`, err.message);
  }
}

/**
 * Generate a single company report from ISM trigger
 */
async function generateSingleReport(supabase, companyService, item) {
  const { id, ticker, sector, ism_report_month, conviction } = item;
  
  console.log(`\n[ISM→Company] ═══════════════════════════════════════`);
  console.log(`[ISM→Company] Generating: ${ticker} (${sector})`);
  console.log(`[ISM→Company] ISM Month: ${ism_report_month}`);
  console.log(`[ISM→Company] Conviction: ${conviction}`);
  console.log(`[ISM→Company] ═══════════════════════════════════════\n`);
  
  try {
    // Update status to generating
    await supabase.rpc('update_auto_company_report_status', {
      p_id: id,
      p_status: 'generating'
    });
    
    // Get ISM context for sector (using existing function in companyRouter)
    let ismContext = null;
    try {
      const { data: ctx } = await supabase.rpc('get_ism_sector_context', {
        p_sector: sector
      });
      ismContext = ctx;
    } catch (e) {
      console.warn(`[ISM→Company] Could not get ISM context:`, e.message);
    }
    
    // Generate the report
    const reportId = `ism_auto_${ticker}_${Date.now()}`;
    
    const result = await companyService.generateReport(ticker, {
      reportType: 'auto',
      includeIsm: true,
      ismContext: ismContext,
      isIsmTriggered: true,
      convictionLevel: conviction
    });
    
    const report = result.report || result;
    
    if (!report) {
      throw new Error('No report returned');
    }
    
    // Save to company_reports with ISM flag
    const { error: saveError } = await supabase
      .from('company_reports')
      .upsert({
        id: reportId,
        ticker: ticker,
        company_name: report.company_name,
        sector: report.sector || sector,
        report_type: 'auto',
        include_ism: true,
        ism_context: ismContext,
        ism_report_month: ism_report_month,
        is_ism_triggered: true,
        ...report,
        created_at: new Date().toISOString()
      }, { onConflict: 'id' });
    
    if (saveError) {
      console.error(`[ISM→Company] Save error:`, saveError.message);
    }
    
    // Update status to completed
    await supabase.rpc('update_auto_company_report_status', {
      p_id: id,
      p_status: 'completed',
      p_company_report_id: reportId
    });
    
    console.log(`[ISM→Company] ✅ Completed: ${ticker} → ${reportId}`);
    
    // Create notification
    await createCompanyReportNotification(supabase, ticker, report.company_name, sector, reportId);
    
    return { success: true, reportId };
    
  } catch (err) {
    console.error(`[ISM→Company] ❌ Failed: ${ticker}`, err.message);
    
    await supabase.rpc('update_auto_company_report_status', {
      p_id: id,
      p_status: 'failed',
      p_error_message: err.message
    });
    
    return { success: false, error: err.message };
  }
}

/**
 * Create system notification for new company report
 */
async function createCompanyReportNotification(supabase, ticker, companyName, sector, reportId) {
  try {
    await supabase.from('system_updates').insert({
      title: `📊 New Analysis: ${ticker}`,
      content: `Fresh company analysis for ${companyName || ticker} (${sector}) based on ISM Manufacturing insights.`,
      type: 'announcement',
      target_group: 'top_secret',
      is_active: true,
      metadata: {
        report_type: 'company_analysis',
        ticker,
        company_name: companyName,
        sector,
        report_id: reportId,
        is_ism_triggered: true
      }
    });
  } catch (err) {
    console.warn(`[ISM→Company] Notification failed:`, err.message);
  }
}

/**
 * Manual trigger for admin
 */
async function manualTriggerIsmCompanyReports(supabase, companyService, reportMonth, count = 2) {
  console.log(`[ISM→Company] Manual trigger for ${reportMonth}`);
  
  // First schedule
  const scheduleResult = await onIsmReportGenerated(supabase, reportMonth, { count });
  
  if (!scheduleResult.success || scheduleResult.scheduled?.length === 0) {
    return scheduleResult;
  }
  
  // Then process immediately
  await processPendingIsmCompanyReports(supabase, companyService, count);
  
  return scheduleResult;
}

/**
 * Get status of ISM-triggered company reports
 */
async function getIsmCompanyReportsStatus(supabase, reportMonth = null) {
  let query = supabase
    .from('ism_auto_company_reports')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (reportMonth) {
    query = query.eq('ism_report_month', reportMonth);
  }
  
  const { data, error } = await query.limit(20);
  
  if (error) {
    return { success: false, error: error.message };
  }
  
  return {
    success: true,
    reports: data || [],
    pending: data?.filter(r => r.status === 'pending').length || 0,
    completed: data?.filter(r => r.status === 'completed').length || 0,
    failed: data?.filter(r => r.status === 'failed').length || 0
  };
}

// ============================================
// EARNINGS-TRIGGERED REPORTS (30th of month)
// ============================================

/**
 * Hook to find and schedule earnings-based company report
 * Looks for companies with recent earnings + 5%+ price move
 * Runs on 30th of each month
 * 
 * @param {object} supabase - Supabase client
 * @param {object} options - Configuration
 */
async function onEarningsCheck(supabase, options = {}) {
  const {
    eodhApiKey,
    polygonApiKey,
    minPriceChange = 5,
    lookbackDays = 7,
    companyScheduler = null,
  } = options;
  
  console.log(`\n[Earnings→Company Hook] ═══════════════════════════════════════════`);
  console.log(`[Earnings→Company Hook] Checking for earnings movers...`);
  console.log(`[Earnings→Company Hook] Min change: ${minPriceChange}%, Lookback: ${lookbackDays} days`);
  console.log(`[Earnings→Company Hook] Schedule: 30th of each month`);
  console.log(`[Earnings→Company Hook] ═══════════════════════════════════════════\n`);
  
  try {
    // Get recently generated to avoid duplicates
    const { data: recentReports } = await supabase
      .from('company_reports')
      .select('ticker')
      .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());
    
    const excludeTickers = recentReports?.map(r => r.ticker) || [];
    
    // Find earnings movers
    const movers = await fetchEarningsMovers({
      eodhApiKey,
      polygonApiKey,
      lookbackDays,
      minPriceChange,
      excludeTickers,
    });
    
    if (!movers || movers.length === 0) {
      console.log(`[Earnings→Company Hook] ⚠️ No qualifying earnings movers found`);
      return { success: true, scheduled: [], message: 'No qualifying movers found' };
    }
    
    // Take the top mover
    const topMover = movers[0];
    
    console.log(`[Earnings→Company Hook] ✅ Found top mover: ${topMover.ticker}`);
    console.log(`  • Company: ${topMover.companyName}`);
    console.log(`  • Earnings: ${topMover.earningsDate}`);
    console.log(`  • Price Change: ${topMover.priceChange?.toFixed(2)}%`);
    
    // Save to auto reports table
    const { error: insertError } = await supabase
      .from('earnings_auto_company_reports')
      .insert({
        ticker: topMover.ticker,
        company_name: topMover.companyName,
        earnings_date: topMover.earningsDate,
        price_change: topMover.priceChange,
        eps_surprise: topMover.epsSurprise,
        status: 'pending',
        source: topMover.source,
        created_at: new Date().toISOString(),
      });
    
    if (insertError) {
      console.warn(`[Earnings→Company Hook] Could not save to DB:`, insertError.message);
    }
    
    // If we have a company scheduler, add to queue
    if (companyScheduler) {
      try {
        await companyScheduler.addToQueue(topMover.ticker, {
          priority: 'high',
          requestedBy: 'earnings_auto',
          scheduledFor: null,
          isEarningsTriggered: true,
          earningsContext: {
            earningsDate: topMover.earningsDate,
            priceChange: topMover.priceChange,
            epsSurprise: topMover.epsSurprise,
          },
        });
        console.log(`[Earnings→Company Hook] Added ${topMover.ticker} to scheduler queue`);
      } catch (err) {
        console.warn(`[Earnings→Company Hook] Queue add failed:`, err.message);
      }
    }
    
    return {
      success: true,
      scheduled: [topMover],
      count: 1,
    };
    
  } catch (err) {
    console.error(`[Earnings→Company Hook] ❌ Exception:`, err.message);
    return { success: false, error: err.message };
  }
}

/**
 * Manual trigger for earnings-based company report
 */
async function manualTriggerEarningsCompanyReport(supabase, companyService, options = {}) {
  console.log(`[Earnings→Company] Manual trigger initiated`);
  
  const checkResult = await onEarningsCheck(supabase, options);
  
  if (!checkResult.success || checkResult.scheduled?.length === 0) {
    return checkResult;
  }
  
  // Process immediately if companyService provided
  if (companyService && checkResult.scheduled?.[0]) {
    const mover = checkResult.scheduled[0];
    
    try {
      const result = await companyService.generateReport(mover.ticker, {
        reportType: 'auto',
        isEarningsTriggered: true,
        earningsContext: {
          earningsDate: mover.earningsDate,
          priceChange: mover.priceChange,
          epsSurprise: mover.epsSurprise,
        },
      });
      
      console.log(`[Earnings→Company] ✅ Report generated for ${mover.ticker}`);
      return { ...checkResult, reportGenerated: true };
      
    } catch (err) {
      console.error(`[Earnings→Company] ❌ Generation failed:`, err.message);
      return { ...checkResult, reportGenerated: false, generationError: err.message };
    }
  }
  
  return checkResult;
}

/**
 * Get status of earnings-triggered company reports
 */
async function getEarningsCompanyReportsStatus(supabase, limit = 20) {
  const { data, error } = await supabase
    .from('earnings_auto_company_reports')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) {
    return { success: false, error: error.message };
  }
  
  return {
    success: true,
    reports: data || [],
    pending: data?.filter(r => r.status === 'pending').length || 0,
    completed: data?.filter(r => r.status === 'completed').length || 0,
    failed: data?.filter(r => r.status === 'failed').length || 0,
  };
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  onIsmReportGenerated,
  processPendingIsmCompanyReports,
  manualTriggerIsmCompanyReports,
  getIsmCompanyReportsStatus,
  onEarningsCheck,
  manualTriggerEarningsCompanyReport,
  getEarningsCompanyReportsStatus
};