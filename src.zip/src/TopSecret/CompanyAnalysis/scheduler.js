// =====================================================
// COMPANY ANALYSIS SCHEDULER v3.2 - ISM + EARNINGS INTEGRATION
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/scheduler.js
//
// v3.2 CHANGES:
// - Changed timezone to America/New_York (9:00 AM ET)
// - 3 automated reports per month:
//   1. ISM Report #1 (10th at 9 AM ET) - Company from ISM recommendations
//   2. ISM Report #2 (20th at 9 AM ET) - Company from ISM recommendations
//   3. Earnings Report (30th at 9 AM ET) - Company with recent earnings + 5%+ price move
// - Auto-selects earnings movers from S&P 500
// - Includes earnings context in reports
// =====================================================

const cron = require('node-cron');
const { CompanyAnalysisOrchestrator } = require('./orchestrator');
const { CompanyDataService, SP500_TICKERS, getRandomSP500Ticker, fetchEarningsMovers, selectRelevantFallbackCompany } = require('./data-service');
const { CompanyNotificationService } = require('./notification-service');
const { generateCompanyReportPDFBuffer } = require('./pdf-generator');

/**
 * Scheduler modes
 */
const SCHEDULE_MODES = {
  WEEKLY: 'weekly',
  MANUAL: 'manual',
  QUEUE: 'queue',
  ISM_MONTHLY: 'ism_monthly',
  EARNINGS_MONTHLY: 'earnings_monthly',
};

/**
 * Report generation queue status
 */
const QUEUE_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
};

class CompanyScheduler {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    this.orchestrator = new CompanyAnalysisOrchestrator(supabase);
    this.dataService = new CompanyDataService(supabase, options.eodhApiKey);
    this.notificationService = new CompanyNotificationService(supabase);
    
    this.options = {
      cronExpression: options.cronExpression || '0 8 * * 0',
      // ISM reports: Run on 10th and 20th at 9:00 AM ET
      ismCronExpression: options.ismCronExpression || '0 9 10,20 * *',
      // Earnings report: Run on 30th at 9:00 AM ET
      earningsCronExpression: options.earningsCronExpression || '0 9 30 * *',
      timezone: options.timezone || 'America/New_York',
      logoPath: options.logoPath || null,
      maxRetries: options.maxRetries || 3,
      retryDelayMinutes: options.retryDelayMinutes || 30,
      mode: options.mode || SCHEDULE_MODES.WEEKLY,
      companiesPerWeek: options.companiesPerWeek || 1,
      enableIsmReports: options.enableIsmReports !== false,
      enableEarningsReports: options.enableEarningsReports !== false,
      earningsMinPriceChange: options.earningsMinPriceChange || 5,
      earningsLookbackDays: options.earningsLookbackDays || 7,
      eodhApiKey: options.eodhApiKey || null,
      polygonApiKey: options.polygonApiKey || null,
      ...options,
    };
    
    this.isRunning = false;
    this.cronJob = null;
    this.ismCronJob = null;
    this.earningsCronJob = null;
    this.queueProcessor = null;
    this.retryCount = 0;
  }

  // ============================================
  // START/STOP SCHEDULER
  // ============================================

  start() {
    if (this.cronJob) {
      console.log('[CompanyScheduler] Scheduler already running');
      return;
    }

    console.log(`[CompanyScheduler] Starting with cron: ${this.options.cronExpression}`);
    
    // Weekly random S&P 500 report
    this.cronJob = cron.schedule(this.options.cronExpression, async () => {
      await this.runScheduledJob();
    }, {
      timezone: this.options.timezone,
    });

    // ═══════════════════════════════════════════════════════════════
    // ISM-based reports on 10th and 20th of each month
    // ═══════════════════════════════════════════════════════════════
    if (this.options.enableIsmReports) {
      console.log(`[CompanyScheduler] Starting ISM cron: ${this.options.ismCronExpression}`);
      
      this.ismCronJob = cron.schedule(this.options.ismCronExpression, async () => {
        await this.runIsmTriggeredJob();
      }, {
        timezone: this.options.timezone,
      });
      
      console.log('[CompanyScheduler] ✅ ISM-triggered reports enabled (10th & 20th of month)');
    }

    // ═══════════════════════════════════════════════════════════════
    // Earnings-based report on 30th of each month
    // ═══════════════════════════════════════════════════════════════
    if (this.options.enableEarningsReports) {
      console.log(`[CompanyScheduler] Starting Earnings cron: ${this.options.earningsCronExpression}`);
      
      this.earningsCronJob = cron.schedule(this.options.earningsCronExpression, async () => {
        await this.runEarningsTriggeredJob();
      }, {
        timezone: this.options.timezone,
      });
      
      console.log('[CompanyScheduler] ✅ Earnings-triggered reports enabled (30th of month)');
    }

    if (this.options.mode === SCHEDULE_MODES.QUEUE) {
      this.startQueueProcessor();
    }

    console.log('[CompanyScheduler] Scheduler started successfully');
    this.logNextRunTime();
  }

  stop() {
    if (this.cronJob) {
      this.cronJob.stop();
      this.cronJob = null;
      console.log('[CompanyScheduler] Weekly scheduler stopped');
    }

    if (this.ismCronJob) {
      this.ismCronJob.stop();
      this.ismCronJob = null;
      console.log('[CompanyScheduler] ISM scheduler stopped');
    }

    if (this.earningsCronJob) {
      this.earningsCronJob.stop();
      this.earningsCronJob = null;
      console.log('[CompanyScheduler] Earnings scheduler stopped');
    }

    if (this.queueProcessor) {
      clearInterval(this.queueProcessor);
      this.queueProcessor = null;
    }
  }

  logNextRunTime() {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const daysUntilSunday = (7 - dayOfWeek) % 7 || 7;
    
    const nextRun = new Date(now);
    nextRun.setDate(now.getDate() + daysUntilSunday);
    nextRun.setHours(8, 0, 0, 0);
    
    console.log(`[CompanyScheduler] Next weekly run: ${nextRun.toLocaleString()}`);
    
    if (this.options.enableIsmReports) {
      const dayOfMonth = now.getDate();
      let nextIsmDay = dayOfMonth < 10 ? 10 : dayOfMonth < 20 ? 20 : 10;
      let nextIsmMonth = dayOfMonth >= 20 ? now.getMonth() + 1 : now.getMonth();
      console.log(`[CompanyScheduler] Next ISM run: day ${nextIsmDay} at 9:00 AM ET`);
    }
    
    if (this.options.enableEarningsReports) {
      const dayOfMonth = now.getDate();
      let nextEarningsDay = dayOfMonth < 30 ? 30 : 30;
      let nextEarningsMonth = dayOfMonth >= 30 ? now.getMonth() + 1 : now.getMonth();
      console.log(`[CompanyScheduler] Next Earnings run: day 30 at 9:00 AM ET`);
    }
  }

  // ============================================
  // WEEKLY SCHEDULED JOB (Original)
  // ============================================

  async runScheduledJob() {
    if (this.isRunning) {
      console.log('[CompanyScheduler] Job already running, skipping');
      return;
    }

    this.isRunning = true;
    const startTime = Date.now();
    
    try {
      console.log('[CompanyScheduler] Starting weekly company report generation...');
      
      const ticker = await this.selectCompanyForReport();
      console.log(`[CompanyScheduler] Selected company: ${ticker}`);
      
      const canGenerate = await this.orchestrator.canGenerate(ticker);
      
      if (!canGenerate.canGenerate) {
        console.log(`[CompanyScheduler] Cannot generate for ${ticker}: ${canGenerate.reason}`);
        const alternativeTicker = await this.selectCompanyForReport([ticker]);
        if (alternativeTicker) {
          console.log(`[CompanyScheduler] Trying alternative: ${alternativeTicker}`);
          await this.generateAndPublish(alternativeTicker, startTime);
        }
        return;
      }
      
      await this.generateAndPublish(ticker, startTime);
      this.retryCount = 0;
      
    } catch (error) {
      console.error('[CompanyScheduler] Job failed:', error);
      await this.logJobExecution('error', null, null, Date.now() - startTime, error.message);
      
      if (this.retryCount < this.options.maxRetries) {
        this.scheduleRetry();
      }
      
    } finally {
      this.isRunning = false;
    }
  }

  // ============================================
  // ISM-TRIGGERED JOB - Runs on 10th and 20th
  // ============================================

  async runIsmTriggeredJob() {
    if (this.isRunning) {
      console.log('[CompanyScheduler] Job already running, skipping ISM job');
      return;
    }

    this.isRunning = true;
    const startTime = Date.now();
    const dayOfMonth = new Date().getDate();
    
    console.log(`\n[CompanyScheduler] ═══════════════════════════════════════════════════`);
    console.log(`[CompanyScheduler] 🏭 Starting ISM-triggered report (day ${dayOfMonth})`);
    console.log(`[CompanyScheduler] ═══════════════════════════════════════════════════\n`);
    
    try {
      const ismMonth = this.getCurrentIsmMonth();
      console.log(`[CompanyScheduler] ISM Month: ${ismMonth}`);
      
      const tickerInfo = await this.selectIsmRecommendedTicker(ismMonth);
      
      if (!tickerInfo) {
        console.log('[CompanyScheduler] No ISM-recommended tickers available, falling back to random');
        const fallbackTicker = await this.selectCompanyForReport();
        await this.generateAndPublish(fallbackTicker, startTime, { includeIsm: false });
        return;
      }
      
      console.log(`[CompanyScheduler] 📊 Selected from ISM: ${tickerInfo.ticker} (${tickerInfo.sector})`);
      console.log(`[CompanyScheduler] Conviction: ${tickerInfo.conviction}, Source: ${tickerInfo.source}`);
      
      const ismContext = await this.getIsmSectorContext(tickerInfo.sector);
      
      await this.generateAndPublishWithIsm(tickerInfo, ismMonth, ismContext, startTime);
      
      await this.logJobExecution('ism_success', tickerInfo.ticker, null, Date.now() - startTime, null, null, {
        ism_month: ismMonth,
        sector: tickerInfo.sector,
        conviction: tickerInfo.conviction,
      });
      
      console.log(`[CompanyScheduler] ✅ ISM report completed in ${((Date.now() - startTime) / 1000).toFixed(1)}s`);
      
    } catch (error) {
      console.error('[CompanyScheduler] ISM job failed:', error);
      await this.logJobExecution('ism_error', null, null, Date.now() - startTime, error.message);
      
    } finally {
      this.isRunning = false;
    }
  }

  // ============================================
  // EARNINGS-TRIGGERED JOB - Runs on 30th
  // ============================================

  async runEarningsTriggeredJob() {
    if (this.isRunning) {
      console.log('[CompanyScheduler] Job already running, skipping Earnings job');
      return;
    }

    this.isRunning = true;
    const startTime = Date.now();
    const dayOfMonth = new Date().getDate();
    
    console.log(`\n[CompanyScheduler] ═══════════════════════════════════════════════════`);
    console.log(`[CompanyScheduler] 📈 Starting Earnings-triggered report (day ${dayOfMonth})`);
    console.log(`[CompanyScheduler] ═══════════════════════════════════════════════════\n`);
    
    try {
      // Get recently generated tickers to exclude
      const { data: recentReports } = await this.supabase
        .from('company_reports')
        .select('ticker')
        .gte('created_at', this.getDateNDaysAgo(30));
      
      const excludeTickers = recentReports?.map(r => r.ticker) || [];
      
      // Find earnings movers
      const earningsMovers = await fetchEarningsMovers({
        eodhApiKey: this.options.eodhApiKey,
        polygonApiKey: this.options.polygonApiKey,
        lookbackDays: this.options.earningsLookbackDays,
        minPriceChange: this.options.earningsMinPriceChange,
        excludeTickers,
      });
      
      if (!earningsMovers || earningsMovers.length === 0) {
        console.log('[CompanyScheduler] No earnings movers found, trying smart fallback...');
        
        // Smart fallback: Find relevant company (analyst changes or trending news)
        const smartFallback = await selectRelevantFallbackCompany({
          eodhApiKey: this.options.eodhApiKey,
          polygonApiKey: this.options.polygonApiKey,
          excludeTickers,
          lookbackDays: 5,
          minNewsCount: 4,
        });
        
        if (smartFallback) {
          console.log(`[CompanyScheduler] 📰 Smart fallback selected: ${smartFallback.ticker}`);
          console.log(`[CompanyScheduler] Reason: ${smartFallback.selectionReason}`);
          console.log(`[CompanyScheduler] Type: ${smartFallback.selectionType}`);
          
          // Generate report with smart fallback context
          await this.generateAndPublishWithSmartFallback(smartFallback, startTime);
          
          await this.logJobExecution('earnings_fallback_success', smartFallback.ticker, null, Date.now() - startTime, null, null, {
            selection_type: smartFallback.selectionType,
            selection_reason: smartFallback.selectionReason,
            change_type: smartFallback.changeType,
          });
          
          return;
        }
        
        // Ultimate fallback: Random S&P 500
        console.log('[CompanyScheduler] No relevant companies found, falling back to random S&P 500');
        const fallbackTicker = await this.selectCompanyForReport();
        await this.generateAndPublish(fallbackTicker, startTime, { includeIsm: false });
        return;
      }
      
      // Select the top mover
      const selectedMover = earningsMovers[0];
      
      console.log(`[CompanyScheduler] 📊 Selected earnings mover: ${selectedMover.ticker}`);
      console.log(`[CompanyScheduler] Company: ${selectedMover.companyName}`);
      console.log(`[CompanyScheduler] Earnings Date: ${selectedMover.earningsDate}`);
      console.log(`[CompanyScheduler] Price Change: ${selectedMover.priceChange?.toFixed(2)}%`);
      if (selectedMover.epsSurprise) {
        console.log(`[CompanyScheduler] EPS Surprise: ${selectedMover.epsSurprise}`);
      }
      
      // Generate and publish with earnings context
      await this.generateAndPublishWithEarnings(selectedMover, startTime);
      
      await this.logJobExecution('earnings_success', selectedMover.ticker, null, Date.now() - startTime, null, null, {
        earnings_date: selectedMover.earningsDate,
        price_change: selectedMover.priceChange,
        eps_surprise: selectedMover.epsSurprise,
      });
      
      console.log(`[CompanyScheduler] ✅ Earnings report completed in ${((Date.now() - startTime) / 1000).toFixed(1)}s`);
      
    } catch (error) {
      console.error('[CompanyScheduler] Earnings job failed:', error);
      await this.logJobExecution('earnings_error', null, null, Date.now() - startTime, error.message);
      
    } finally {
      this.isRunning = false;
    }
  }

  async generateAndPublishWithEarnings(moverInfo, startTime) {
    const { ticker, companyName, earningsDate, priceChange, epsSurprise, epsActual, epsEstimate } = moverInfo;
    
    console.log(`[CompanyScheduler] Generating Earnings-enhanced report for ${ticker}...`);
    
    // Build earnings context
    const earningsContext = {
      earningsDate,
      priceChange,
      priceChangeDirection: priceChange > 0 ? 'positive' : 'negative',
      epsSurprise,
      epsActual,
      epsEstimate,
      reportTrigger: 'earnings_reaction',
      significantMove: Math.abs(priceChange) >= 10,
    };
    
    const result = await this.orchestrator.generate(ticker, {
      isAdminOverride: false,
      skipQA: false,
      includeIsm: false,
      isEarningsTriggered: true,
      earningsContext,
    });
    
    if (!result.success) {
      throw new Error(`Report generation failed: ${result.error}`);
    }
    
    console.log(`[CompanyScheduler] Report generated: ${result.reportId}`);
    
    // Add earnings metadata
    if (result.report) {
      result.report.earnings_context = earningsContext;
      result.report.is_earnings_triggered = true;
    }
    
    // Update report with earnings flags
    if (this.supabase) {
      await this.supabase
        .from('company_reports')
        .update({
          is_earnings_triggered: true,
          earnings_context: earningsContext,
          earnings_date: earningsDate,
          earnings_price_change: priceChange,
        })
        .eq('id', result.reportId);
    }
    
    // Generate PDF
    console.log('[CompanyScheduler] Generating PDF...');
    const pdfBuffer = await generateCompanyReportPDFBuffer(result.report, this.options.logoPath);
    await this.storePDF(result.reportId, ticker, pdfBuffer);
    
    // Publish to Update Center
    console.log('[CompanyScheduler] Publishing to Update Center...');
    const publishResult = await this.notificationService.publishReport(result.reportId, {
      category: 'earnings_analysis',
      priority: Math.abs(priceChange) >= 10 ? 'high' : 'normal',
      isEarningsTriggered: true,
    });
    
    // Create notification
    await this.createEarningsReportNotification(ticker, companyName, priceChange, result.reportId, earningsDate);
    
    console.log(`[CompanyScheduler] Published to ${publishResult.usersNotified} users`);
    
    return result;
  }

  async createEarningsReportNotification(ticker, companyName, priceChange, reportId, earningsDate) {
    const direction = priceChange > 0 ? '📈' : '📉';
    const changeStr = priceChange > 0 ? `+${priceChange.toFixed(1)}%` : `${priceChange.toFixed(1)}%`;
    
    try {
      await this.supabase.from('system_updates').insert({
        title: `${direction} Earnings Analysis: ${ticker} (${changeStr})`,
        content: `Fresh company analysis for ${companyName || ticker} following their recent earnings report. The stock moved ${changeStr} after the announcement.`,
        type: 'announcement',
        target_group: 'top_secret',
        is_active: true,
        metadata: {
          report_type: 'company_analysis',
          ticker,
          report_id: reportId,
          is_earnings_triggered: true,
          earnings_date: earningsDate,
          price_change: priceChange,
        }
      });
    } catch (err) {
      console.warn('[CompanyScheduler] Earnings notification creation failed:', err.message);
    }
  }

  /**
   * Generate and publish report for smart fallback selection (analyst changes or trending news)
   */
  async generateAndPublishWithSmartFallback(fallbackInfo, startTime) {
    const { ticker, companyName, selectionReason, selectionType, changeType, analystNews, recentHeadlines } = fallbackInfo;
    
    console.log(`[CompanyScheduler] Generating Smart Fallback report for ${ticker}...`);
    
    // Build smart fallback context
    const smartFallbackContext = {
      selectionReason,
      selectionType,
      changeType: changeType || null,
      isAnalystDriven: selectionType === 'analyst_change',
      isTrendingNews: selectionType === 'trending_news',
      relevantNews: analystNews || recentHeadlines || [],
      reportTrigger: 'smart_fallback',
    };
    
    const result = await this.orchestrator.generate(ticker, {
      isAdminOverride: false,
      skipQA: false,
      includeIsm: false,
      isSmartFallback: true,
      smartFallbackContext,
    });
    
    if (!result.success) {
      throw new Error(`Report generation failed: ${result.error}`);
    }
    
    console.log(`[CompanyScheduler] Report generated: ${result.reportId}`);
    
    // Add smart fallback metadata
    if (result.report) {
      result.report.smart_fallback_context = smartFallbackContext;
      result.report.is_smart_fallback = true;
    }
    
    // Update report with smart fallback flags
    if (this.supabase) {
      await this.supabase
        .from('company_reports')
        .update({
          is_smart_fallback: true,
          smart_fallback_context: smartFallbackContext,
          selection_type: selectionType,
          selection_reason: selectionReason,
        })
        .eq('id', result.reportId);
    }
    
    // Generate PDF
    console.log('[CompanyScheduler] Generating PDF...');
    const pdfBuffer = await generateCompanyReportPDFBuffer(result.report, this.options.logoPath);
    await this.storePDF(result.reportId, ticker, pdfBuffer);
    
    // Publish to Update Center
    console.log('[CompanyScheduler] Publishing to Update Center...');
    const publishResult = await this.notificationService.publishReport(result.reportId, {
      category: selectionType === 'analyst_change' ? 'analyst_analysis' : 'trending_analysis',
      priority: changeType === 'upgrade' || changeType === 'downgrade' ? 'high' : 'normal',
      isSmartFallback: true,
    });
    
    // Create notification
    await this.createSmartFallbackNotification(ticker, companyName, selectionType, changeType, result.reportId, selectionReason);
    
    console.log(`[CompanyScheduler] Published to ${publishResult.usersNotified} users`);
    
    return result;
  }

  async createSmartFallbackNotification(ticker, companyName, selectionType, changeType, reportId, selectionReason) {
    let emoji, title;
    
    if (selectionType === 'analyst_change') {
      if (changeType === 'upgrade') {
        emoji = '⬆️';
        title = `${emoji} Analyst Upgrade: ${ticker}`;
      } else if (changeType === 'downgrade') {
        emoji = '⬇️';
        title = `${emoji} Analyst Downgrade: ${ticker}`;
      } else {
        emoji = '🎯';
        title = `${emoji} Analyst Activity: ${ticker}`;
      }
    } else {
      emoji = '📰';
      title = `${emoji} Trending Analysis: ${ticker}`;
    }
    
    try {
      await this.supabase.from('system_updates').insert({
        title,
        content: `Fresh company analysis for ${companyName || ticker}. ${selectionReason}`,
        type: 'announcement',
        target_group: 'top_secret',
        is_active: true,
        metadata: {
          report_type: 'company_analysis',
          ticker,
          report_id: reportId,
          is_smart_fallback: true,
          selection_type: selectionType,
          change_type: changeType,
        }
      });
    } catch (err) {
      console.warn('[CompanyScheduler] Smart fallback notification creation failed:', err.message);
    }
  }

  getCurrentIsmMonth() {
    const now = new Date();
    const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return `${prevMonth.getFullYear()}-${String(prevMonth.getMonth() + 1).padStart(2, '0')}`;
  }

  async selectIsmRecommendedTicker(ismMonth) {
    try {
      // Try ism_ticker_selections first
      const { data: selections } = await this.supabase
        .from('ism_ticker_selections')
        .select('ticker, sector_name, conviction, reasoning')
        .eq('report_month', ismMonth)
        .in('selection_type', ['overweight', 'watchlist'])
        .not('ticker', 'is', null)
        .order('conviction', { ascending: false })
        .limit(10);
      
      if (selections && selections.length > 0) {
        // Get recently generated to avoid duplicates
        const { data: recentReports } = await this.supabase
          .from('company_reports')
          .select('ticker')
          .gte('created_at', this.getDateNDaysAgo(30));
        
        const recentTickers = recentReports?.map(r => r.ticker) || [];
        
        for (const sel of selections) {
          if (!recentTickers.includes(sel.ticker)) {
            return {
              ticker: sel.ticker,
              sector: sel.sector_name,
              conviction: sel.conviction || 'medium',
              source: 'ticker_selections',
              reasoning: sel.reasoning,
            };
          }
        }
        
        // If all recent, use first anyway
        return {
          ticker: selections[0].ticker,
          sector: selections[0].sector_name,
          conviction: selections[0].conviction || 'medium',
          source: 'ticker_selections',
          reasoning: selections[0].reasoning,
        };
      }
      
      // Try ism_trade_ideas as fallback
      const { data: tradeIdeas } = await this.supabase
        .from('ism_trade_ideas')
        .select('stocks, sector, conviction, thesis')
        .eq('report_month', ismMonth)
        .eq('direction', 'long')
        .not('stocks', 'is', null)
        .limit(5);
      
      if (tradeIdeas && tradeIdeas.length > 0) {
        for (const idea of tradeIdeas) {
          if (idea.stocks && idea.stocks.length > 0) {
            return {
              ticker: idea.stocks[0],
              sector: idea.sector,
              conviction: idea.conviction || 'medium',
              source: 'trade_ideas',
              reasoning: idea.thesis,
            };
          }
        }
      }
      
      return null;
      
    } catch (error) {
      console.error('[CompanyScheduler] Error selecting ISM ticker:', error.message);
      return null;
    }
  }

  async getIsmSectorContext(sector) {
    if (!sector) return null;
    
    try {
      const { data, error } = await this.supabase.rpc('get_ism_sector_context', {
        p_sector: sector
      });
      
      if (!error && data) {
        return data;
      }
      
      // Fallback: Build context from tables
      const ismMonth = this.getCurrentIsmMonth();
      
      const { data: ranking } = await this.supabase
        .from('ism_sector_rankings')
        .select('*')
        .eq('report_month', ismMonth)
        .ilike('sector', `%${sector}%`)
        .single();
      
      return {
        report_month: ismMonth,
        sector_ranking: ranking,
        relevant_quotes: [],
      };
      
    } catch (error) {
      console.warn('[CompanyScheduler] Could not get ISM context:', error.message);
      return null;
    }
  }

  async generateAndPublishWithIsm(tickerInfo, ismMonth, ismContext, startTime) {
    const { ticker, sector, conviction } = tickerInfo;
    
    console.log(`[CompanyScheduler] Generating ISM-enhanced report for ${ticker}...`);
    
    const result = await this.orchestrator.generate(ticker, {
      isAdminOverride: false,
      skipQA: false,
      includeIsm: true,
      ismContext: ismContext,
      isIsmTriggered: true,
      convictionLevel: conviction,
    });
    
    if (!result.success) {
      throw new Error(`Report generation failed: ${result.error}`);
    }
    
    console.log(`[CompanyScheduler] Report generated: ${result.reportId}`);
    
    // Add ISM metadata
    if (result.report) {
      result.report.ism_context = ismContext;
      result.report.ism_report_month = ismMonth;
      result.report.is_ism_triggered = true;
    }
    
    // Update report with ISM flags
    if (this.supabase) {
      await this.supabase
        .from('company_reports')
        .update({
          ism_report_month: ismMonth,
          is_ism_triggered: true,
          ism_context: ismContext,
        })
        .eq('id', result.reportId);
    }
    
    // Generate PDF
    console.log('[CompanyScheduler] Generating PDF...');
    const pdfBuffer = await generateCompanyReportPDFBuffer(result.report, this.options.logoPath);
    await this.storePDF(result.reportId, ticker, pdfBuffer);
    
    // Publish to Update Center
    console.log('[CompanyScheduler] Publishing to Update Center...');
    const publishResult = await this.notificationService.publishReport(result.reportId, {
      category: 'ism_analysis',
      priority: conviction === 'high' ? 'high' : 'normal',
      isIsmTriggered: true,
    });
    
    // Create notification
    await this.createIsmReportNotification(ticker, result.report?.company_name, sector, result.reportId, ismMonth);
    
    console.log(`[CompanyScheduler] Published to ${publishResult.usersNotified} users`);
    
    return result;
  }

  async createIsmReportNotification(ticker, companyName, sector, reportId, ismMonth) {
    try {
      await this.supabase.from('system_updates').insert({
        title: `📊 ISM Analysis: ${ticker}`,
        content: `Fresh company analysis for ${companyName || ticker} (${sector}) based on ${ismMonth} ISM Manufacturing insights.`,
        type: 'announcement',
        target_group: 'top_secret',
        is_active: true,
        metadata: {
          report_type: 'company_analysis',
          ticker,
          sector,
          report_id: reportId,
          is_ism_triggered: true,
          ism_month: ismMonth,
        }
      });
    } catch (err) {
      console.warn('[CompanyScheduler] Notification creation failed:', err.message);
    }
  }

  async generateAndPublish(ticker, startTime, options = {}) {
    const { includeIsm = false } = options;
    
    console.log(`[CompanyScheduler] Generating report for ${ticker}...`);
    const result = await this.orchestrator.generate(ticker, {
      isAdminOverride: false,
      skipQA: false,
      includeIsm,
    });
    
    if (!result.success) {
      throw new Error(`Report generation failed: ${result.error}`);
    }
    
    console.log(`[CompanyScheduler] Report generated: ${result.reportId}`);
    
    console.log('[CompanyScheduler] Generating PDF...');
    const pdfBuffer = await generateCompanyReportPDFBuffer(result.report, this.options.logoPath);
    await this.storePDF(result.reportId, ticker, pdfBuffer);
    
    console.log('[CompanyScheduler] Publishing to Update Center...');
    const publishResult = await this.notificationService.publishReport(result.reportId, {
      category: 'weekly_analysis',
      priority: 'normal',
    });
    
    console.log(`[CompanyScheduler] Published to ${publishResult.usersNotified} users`);
    
    await this.logJobExecution('success', ticker, result.reportId, Date.now() - startTime);
    
    console.log(`[CompanyScheduler] Job completed in ${((Date.now() - startTime) / 1000).toFixed(1)}s`);
    
    return result;
  }

  async storePDF(reportId, ticker, pdfBuffer) {
    const filename = `company_reports/${ticker}_${reportId}.pdf`;
    
    const { error } = await this.supabase.storage
      .from('reports')
      .upload(filename, pdfBuffer, {
        contentType: 'application/pdf',
        upsert: true,
      });

    if (error) {
      console.error('[CompanyScheduler] PDF storage error:', error);
    } else {
      await this.supabase
        .from('company_reports')
        .update({ pdf_path: filename })
        .eq('id', reportId);
    }
  }

  scheduleRetry() {
    this.retryCount++;
    const delayMs = this.options.retryDelayMinutes * 60 * 1000;
    
    console.log(`[CompanyScheduler] Scheduling retry ${this.retryCount}/${this.options.maxRetries} in ${this.options.retryDelayMinutes} minutes`);
    
    setTimeout(() => {
      this.runScheduledJob();
    }, delayMs);
  }

  // ============================================
  // COMPANY SELECTION
  // ============================================

  async selectCompanyForReport(excludeTickers = []) {
    const { data: recentReports } = await this.supabase
      .from('company_reports')
      .select('ticker')
      .gte('created_at', this.getDateNDaysAgo(60))
      .order('created_at', { ascending: false });

    const recentTickers = recentReports?.map(r => r.ticker) || [];
    const allExcluded = [...recentTickers, ...excludeTickers];

    let selectedTicker = null;
    let attempts = 0;
    const maxAttempts = 50;

    while (!selectedTicker && attempts < maxAttempts) {
      const candidate = getRandomSP500Ticker();
      if (!allExcluded.includes(candidate)) {
        selectedTicker = candidate;
      }
      attempts++;
    }

    if (!selectedTicker) {
      selectedTicker = getRandomSP500Ticker();
      console.log(`[CompanyScheduler] Using fallback ticker: ${selectedTicker}`);
    }

    return selectedTicker;
  }

  getDateNDaysAgo(days) {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date.toISOString();
  }

  // ============================================
  // ADMIN MANUAL TRIGGERS
  // ============================================

  async triggerIsmReport(options = {}) {
    const { ismMonth = this.getCurrentIsmMonth() } = options;
    
    console.log(`[CompanyScheduler] Manual ISM trigger for ${ismMonth}`);
    
    const startTime = Date.now();
    
    try {
      const tickerInfo = await this.selectIsmRecommendedTicker(ismMonth);
      
      if (!tickerInfo) {
        return {
          success: false,
          error: 'No ISM-recommended tickers available for this month',
        };
      }
      
      const ismContext = await this.getIsmSectorContext(tickerInfo.sector);
      const result = await this.generateAndPublishWithIsm(tickerInfo, ismMonth, ismContext, startTime);
      
      return {
        success: true,
        reportId: result.reportId,
        ticker: tickerInfo.ticker,
        sector: tickerInfo.sector,
        ismMonth,
        duration: Date.now() - startTime,
      };
      
    } catch (error) {
      console.error('[CompanyScheduler] Manual ISM trigger failed:', error);
      return { success: false, error: error.message };
    }
  }

  async triggerForTicker(ticker, options = {}) {
    const {
      adminId = null,
      overrideReason = 'Admin request',
      skipQA = false,
      priority = 'high',
      includeIsm = false,
    } = options;

    console.log(`[CompanyScheduler] Admin trigger for ${ticker} by ${adminId}`);
    
    const startTime = Date.now();

    try {
      const isValid = await this.dataService.validateTicker(ticker);
      if (!isValid.valid) {
        return { success: false, error: `Invalid ticker: ${isValid.reason}` };
      }

      let ismContext = null;
      if (includeIsm) {
        const companyInfo = await this.dataService.getCompanyInfo?.(ticker) || {};
        ismContext = await this.getIsmSectorContext(companyInfo.sector);
      }

      const result = await this.orchestrator.generate(ticker, {
        isAdminOverride: true,
        overrideReason,
        adminId,
        skipQA,
        includeIsm,
        ismContext,
      });

      if (!result.success) return result;

      const pdfBuffer = await generateCompanyReportPDFBuffer(result.report, this.options.logoPath);
      await this.storePDF(result.reportId, ticker, pdfBuffer);

      const publishResult = await this.notificationService.publishReport(result.reportId, {
        category: 'admin_generated',
        priority,
        isAdminGenerated: true,
      });

      await this.logJobExecution('admin_trigger', ticker, result.reportId, Date.now() - startTime, null, adminId);

      return {
        success: true,
        reportId: result.reportId,
        ticker,
        usersNotified: publishResult.usersNotified,
        duration: Date.now() - startTime,
      };

    } catch (error) {
      console.error(`[CompanyScheduler] Admin trigger failed for ${ticker}:`, error);
      return { success: false, error: error.message };
    }
  }

  async triggerBatch(tickers, options = {}) {
    const results = { successful: [], failed: [] };

    for (const ticker of tickers) {
      const result = await this.triggerForTicker(ticker, options);
      if (result.success) {
        results.successful.push({ ticker, reportId: result.reportId });
      } else {
        results.failed.push({ ticker, error: result.error });
      }
      await new Promise(resolve => setTimeout(resolve, 5000));
    }

    return results;
  }

  // ============================================
  // QUEUE MANAGEMENT
  // ============================================

  async addToQueue(ticker, options = {}) {
    const { priority = 'normal', requestedBy = null, scheduledFor = null, includeIsm = false } = options;

    const { data: existing } = await this.supabase
      .from('company_report_queue')
      .select('id')
      .eq('ticker', ticker)
      .eq('status', QUEUE_STATUS.PENDING)
      .single();

    if (existing) {
      return { success: false, error: 'Ticker already in queue', queueId: existing.id };
    }

    const { data, error } = await this.supabase
      .from('company_report_queue')
      .insert({
        ticker,
        priority,
        requested_by: requestedBy,
        scheduled_for: scheduledFor,
        include_ism: includeIsm,
        status: QUEUE_STATUS.PENDING,
        created_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) return { success: false, error: error.message };

    console.log(`[CompanyScheduler] Added ${ticker} to queue (ID: ${data.id})`);
    return { success: true, queueId: data.id };
  }

  startQueueProcessor() {
    this.queueProcessor = setInterval(async () => {
      await this.processQueue();
    }, 5 * 60 * 1000);
    console.log('[CompanyScheduler] Queue processor started');
  }

  async processQueue() {
    if (this.isRunning) return;

    const { data: item } = await this.supabase
      .from('company_report_queue')
      .select('*')
      .eq('status', QUEUE_STATUS.PENDING)
      .or(`scheduled_for.is.null,scheduled_for.lte.${new Date().toISOString()}`)
      .order('priority', { ascending: false })
      .order('created_at', { ascending: true })
      .limit(1)
      .single();

    if (!item) return;

    console.log(`[CompanyScheduler] Processing queue item: ${item.ticker}`);

    await this.supabase
      .from('company_report_queue')
      .update({ status: QUEUE_STATUS.PROCESSING, started_at: new Date().toISOString() })
      .eq('id', item.id);

    try {
      const result = await this.triggerForTicker(item.ticker, {
        adminId: item.requested_by,
        includeIsm: item.include_ism,
      });

      await this.supabase
        .from('company_report_queue')
        .update({
          status: result.success ? QUEUE_STATUS.COMPLETED : QUEUE_STATUS.FAILED,
          completed_at: new Date().toISOString(),
          report_id: result.reportId,
          error_message: result.error,
        })
        .eq('id', item.id);

    } catch (error) {
      await this.supabase
        .from('company_report_queue')
        .update({
          status: QUEUE_STATUS.FAILED,
          completed_at: new Date().toISOString(),
          error_message: error.message,
        })
        .eq('id', item.id);
    }
  }

  async getQueueStatus() {
    const { data: items } = await this.supabase
      .from('company_report_queue')
      .select('*')
      .in('status', [QUEUE_STATUS.PENDING, QUEUE_STATUS.PROCESSING])
      .order('created_at', { ascending: true });

    return {
      pending: items?.filter(i => i.status === QUEUE_STATUS.PENDING).length || 0,
      processing: items?.filter(i => i.status === QUEUE_STATUS.PROCESSING).length || 0,
      items: items || [],
    };
  }

  async cancelQueueItem(queueId) {
    const { error } = await this.supabase
      .from('company_report_queue')
      .update({ status: QUEUE_STATUS.CANCELLED })
      .eq('id', queueId)
      .eq('status', QUEUE_STATUS.PENDING);
    return { success: !error };
  }

  // ============================================
  // LOGGING
  // ============================================

  async logJobExecution(status, ticker, reportId, durationMs, errorMessage = null, adminId = null, metadata = {}) {
    if (!this.supabase) return;
    
    try {
      await this.supabase
        .from('company_scheduler_logs')
        .insert({
          job_type: status.startsWith('ism_') ? 'ism_generation' : 
                    status.startsWith('earnings_') ? 'earnings_generation' :
                    (adminId ? 'admin_trigger' : 'weekly_generation'),
          status: status.replace('ism_', '').replace('earnings_', ''),
          ticker,
          report_id: reportId,
          duration_ms: durationMs,
          error_message: errorMessage,
          admin_id: adminId,
          metadata,
          executed_at: new Date().toISOString(),
        });
    } catch (error) {
      console.error('[CompanyScheduler] Failed to log execution:', error);
    }
  }

  // ============================================
  // STATUS & INFO
  // ============================================

  getStatus() {
    return {
      isRunning: !!this.cronJob,
      isIsmRunning: !!this.ismCronJob,
      isEarningsRunning: !!this.earningsCronJob,
      isJobRunning: this.isRunning,
      retryCount: this.retryCount,
      maxRetries: this.options.maxRetries,
      cronExpression: this.options.cronExpression,
      ismCronExpression: this.options.ismCronExpression,
      earningsCronExpression: this.options.earningsCronExpression,
      timezone: this.options.timezone,
      mode: this.options.mode,
      enableIsmReports: this.options.enableIsmReports,
      enableEarningsReports: this.options.enableEarningsReports,
      earningsMinPriceChange: this.options.earningsMinPriceChange,
    };
  }

  async getJobHistory(limit = 20) {
    const { data } = await this.supabase
      .from('company_scheduler_logs')
      .select('*')
      .order('executed_at', { ascending: false })
      .limit(limit);
    return data || [];
  }

  async getUpcomingSchedule() {
    const queueStatus = await this.getQueueStatus();
    
    const now = new Date();
    const dayOfMonth = now.getDate();
    
    // Calculate next ISM date (9:00 AM ET)
    let nextIsmDate;
    if (dayOfMonth < 10) {
      nextIsmDate = new Date(now.getFullYear(), now.getMonth(), 10, 9, 0, 0);
    } else if (dayOfMonth < 20) {
      nextIsmDate = new Date(now.getFullYear(), now.getMonth(), 20, 9, 0, 0);
    } else {
      nextIsmDate = new Date(now.getFullYear(), now.getMonth() + 1, 10, 9, 0, 0);
    }
    
    // Calculate next Earnings date (30th at 9:00 AM ET)
    let nextEarningsDate;
    if (dayOfMonth < 30) {
      nextEarningsDate = new Date(now.getFullYear(), now.getMonth(), 30, 9, 0, 0);
    } else {
      nextEarningsDate = new Date(now.getFullYear(), now.getMonth() + 1, 30, 9, 0, 0);
    }
    
    return {
      mode: this.options.mode,
      nextScheduledRun: this.getNextScheduledRun(),
      nextIsmRun: this.options.enableIsmReports ? nextIsmDate.toISOString() : null,
      nextEarningsRun: this.options.enableEarningsReports ? nextEarningsDate.toISOString() : null,
      ismEnabled: this.options.enableIsmReports,
      earningsEnabled: this.options.enableEarningsReports,
      earningsMinPriceChange: this.options.earningsMinPriceChange,
      queue: queueStatus.items,
    };
  }

  getNextScheduledRun() {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const daysUntilSunday = (7 - dayOfWeek) % 7 || 7;
    
    const nextRun = new Date(now);
    nextRun.setDate(now.getDate() + daysUntilSunday);
    nextRun.setHours(8, 0, 0, 0);
    
    return nextRun.toISOString();
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

function createCompanyScheduler(supabase, options = {}) {
  const scheduler = new CompanyScheduler(supabase, options);
  
  if (options.autoStart !== false) {
    scheduler.start();
  }
  
  return scheduler;
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  CompanyScheduler,
  createCompanyScheduler,
  SCHEDULE_MODES,
  QUEUE_STATUS,
};