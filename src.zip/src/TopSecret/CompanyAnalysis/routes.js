// =====================================================
// COMPANY ANALYSIS ROUTER - FIXED VERSION v2.5
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/routes.js
//
// FIXES v2.5:
// 1. ISM Toggle support (includeIsm parameter)
// 2. Enhanced data transformation from database to PDF format
// 3. Checks executive_summary._sections first (contains full data)
// 4. Falls back to flat database columns
// 5. Logo path support for PDF generation
// 6. Company logo fetching for cover page
// 7. All original endpoints preserved
//
// Company Analysis system (27 AI Agents + OpenAI)
// Supports: specific ticker OR random S&P 500
// =====================================================

const express = require('express');
const path = require('path');
const fs = require('fs');

// Direct imports to avoid circular dependency
const { CompanyAnalysisOrchestrator, workflowManager } = require('./orchestrator');
const { CompanyDataService, SP500_TICKERS, getRandomSP500Ticker, isInSP500 } = require('./data-service');
const { generateCompanyReportPDFBuffer } = require('./pdf-generator');

// ============================================
// LOGO PATH FINDER
// ============================================
function findFinotaurLogo(customPath = null) {
  // If custom path provided and exists, use it
  if (customPath && fs.existsSync(customPath)) {
    return customPath;
  }
  
  // Common logo locations to check
  const possiblePaths = [
    // Your specific Docker path (PRIORITY)
    '/app/finotaur-frontend/public/logo.png',
    // Production paths
    path.join(process.cwd(), 'public', 'logo.png'),
    path.join(process.cwd(), 'public', 'assets', 'logo.png'),
    path.join(process.cwd(), 'static', 'logo.png'),
    path.join(process.cwd(), 'static', 'images', 'logo.png'),
    // Development paths
    path.join(process.cwd(), 'finotaur-frontend', 'public', 'logo.png'),
    path.join(process.cwd(), '..', 'public', 'logo.png'),
    path.join(process.cwd(), '..', 'finotaur-frontend', 'public', 'logo.png'),
    // Supabase/Edge function paths
    path.join('/app', 'public', 'logo.png'),
    // Additional common paths
    path.join(process.cwd(), 'assets', 'logo.png'),
    path.join(process.cwd(), 'images', 'logo.png'),
  ];
  
  for (const logoPath of possiblePaths) {
    if (fs.existsSync(logoPath)) {
      console.log(`[Routes] Found Finotaur logo at: ${logoPath}`);
      return logoPath;
    }
  }
  
  console.log('[Routes] Finotaur logo not found, will use text fallback');
  return null;
}

// ============================================
// DATABASE TO PDF FORMAT TRANSFORMER v2.3
// ============================================
/**
 * Transform database report format to PDF generator expected format
 * 
 * Database structure:
 * - Flat columns: business_reality, sector_competition, financial_core, etc.
 * - executive_summary._sections contains the full sections data
 * 
 * PDF expects:
 * - report.sections.businessReality, report.sections.sectorCompetition, etc.
 */
function transformDatabaseReportForPDF(dbReport) {
  if (!dbReport) {
    console.log('[Routes] No report to transform');
    return null;
  }
  
  // Check if report already has proper sections structure (from in-memory generation)
  // v6.0 format: businessReality, financialCore
  // v7.0/v7.1 format: cover, ismAnalysis, companySnapshot, incomeStatement, valuation
  
  const sections = dbReport.sections;
  
  if (sections) {
    // Check for v7.0/v7.1 format with ACTUAL content (not just empty objects)
    const hasV7Cover = sections.cover && (sections.cover.companyName || sections.cover.ticker);
    const hasV7Snapshot = sections.companySnapshot && (sections.companySnapshot.name || sections.companySnapshot.marketCap);
    const hasV7Financials = sections.incomeStatement && sections.incomeStatement.revenue;
    const hasV7Valuation = sections.valuation && (sections.valuation.currentPrice || sections.valuation.multiples);
    
    // Check for v6.0 format
    const hasV6Business = sections.businessReality && Object.keys(sections.businessReality).length > 0;
    const hasV6Financial = sections.financialCore && Object.keys(sections.financialCore).length > 0;
    
    console.log('[Routes] Sections check:');
    console.log(`  - v7.0 cover with content: ${hasV7Cover}`);
    console.log(`  - v7.0 snapshot with content: ${hasV7Snapshot}`);
    console.log(`  - v7.0 financials with content: ${hasV7Financials}`);
    console.log(`  - v7.0 valuation with content: ${hasV7Valuation}`);
    console.log(`  - v6.0 businessReality: ${hasV6Business}`);
    console.log(`  - v6.0 financialCore: ${hasV6Financial}`);
    
    // If v7.0/v7.1 format with content, pass through
    if (hasV7Cover || hasV7Snapshot || hasV7Financials || hasV7Valuation) {
      console.log('[Routes] ✅ Report already in v7.0/v7.1 sections format with content, passing through');
      return dbReport;
    }
    
    // If v6.0 format with content, pass through
    if (hasV6Business && hasV6Financial) {
      console.log('[Routes] ✅ Report already in v6.0 sections format, passing through');
      return dbReport;
    }
  }
  
  console.log('[Routes] Transforming database report to sections format...');
  console.log('[Routes] Available keys:', Object.keys(dbReport).join(', '));
  
  // PRIORITY 1: Check if executive_summary._sections has the data
  const execSummary = dbReport.executive_summary || {};
  const sectionsFromExec = execSummary._sections || {};
  
  // PRIORITY 2: Use flat database columns
  const businessReality = sectionsFromExec.businessReality || dbReport.business_reality || {};
  const sectorCompetition = sectionsFromExec.sectorCompetition || dbReport.sector_competition || {};
  const financialCore = sectionsFromExec.financialCore || dbReport.financial_core || {};
  const forwardView = sectionsFromExec.forwardView || dbReport.forward_view || {};
  const investmentDecision = sectionsFromExec.investmentDecision || dbReport.investment_decision || {};
  const filingsAnalysis = sectionsFromExec.filingsAnalysis || dbReport.filings_analysis || {};
  
  // ISM-related sections from executive_summary._sections
  const macroTrigger = sectionsFromExec.macroTrigger || {};
  const sectorFunnel = sectionsFromExec.sectorFunnel || {};
  const whyThisCompany = sectionsFromExec.whyThisCompany || {};
  const ismBridge = sectionsFromExec.ismBridge || {};
  const driverHierarchy = sectionsFromExec.driverHierarchy || businessReality.driverHierarchy || {};
  const onePageSummary = sectionsFromExec.onePageSummary || {};
  
  // Log what we found
  console.log('[Routes] Data sources found:');
  console.log(`  - executive_summary._sections: ${Object.keys(sectionsFromExec).length > 0 ? 'YES (' + Object.keys(sectionsFromExec).length + ' keys)' : 'NO'}`);
  console.log(`  - business_reality: ${Object.keys(dbReport.business_reality || {}).length > 0 ? 'YES' : 'NO'}`);
  console.log(`  - financial_core: ${Object.keys(dbReport.financial_core || {}).length > 0 ? 'YES' : 'NO'}`);
  
  // Build transformed report with proper sections structure
  const transformedReport = {
    // ====== ROOT LEVEL FIELDS ======
    ticker: dbReport.ticker,
    company_name: dbReport.company_name,
    sector: dbReport.sector || 
            sectorCompetition?.realSector?.primarySector || 
            businessReality?.identification?.sector ||
            'N/A',
    industry: dbReport.industry || 
              businessReality?.identification?.industry ||
              'N/A',
    exchange: dbReport.exchange || 
              businessReality?.identification?.exchange ||
              'N/A',
    market_cap: dbReport.market_cap || 
                businessReality?.identification?.marketCap,
    qa_score: dbReport.qa_score || 
              execSummary?.meta?.qaScore || 
              0,
    confidence_level: dbReport.confidence_level || 
                      execSummary?.confidenceLevel?.level || 
                      'medium',
    created_at: dbReport.created_at,
    
    // ====== META INFORMATION ======
    meta: {
      ticker: dbReport.ticker,
      companyName: dbReport.company_name,
      sector: dbReport.sector,
      industry: dbReport.industry,
      generatedAt: dbReport.created_at,
      qaScore: dbReport.qa_score || 0,
      version: dbReport.version || '6.0.0',
      ...(execSummary?.meta || {}),
    },
    
    // ====== COMPANY DATA ======
    companyData: {
      name: dbReport.company_name,
      ticker: dbReport.ticker,
      exchange: dbReport.exchange,
      market_cap: dbReport.market_cap,
      sector: dbReport.sector,
      industry: dbReport.industry,
    },
    
    // ====== EXECUTIVE SUMMARY ======
    executiveSummary: {
      lines: execSummary?.lines || [],
      prose: execSummary?.prose || '',
      oneLiner: execSummary?.oneLiner || execSummary?.one_liner || '',
      ismTrigger: execSummary?.ismTrigger || macroTrigger?.macroBottomLine || '',
      confidenceLevel: {
        level: dbReport.confidence_level || execSummary?.confidenceLevel?.level || 'medium',
        reasoning: execSummary?.confidenceLevel?.reasoning || '',
      },
      selectionRationale: execSummary?.selectionRationale || {},
    },
    
    // ====== SECTIONS - This is what the PDF generator expects ======
    sections: {
      // PAGE 0: MACRO TRIGGER
      macroTrigger: {
        pageTitle: macroTrigger.pageTitle || 'ISM Signal → Sector Pressure → Company-Level Opportunity',
        analystContext: macroTrigger.analystContext || {},
        macroSignalBreakdown: macroTrigger.macroSignalBreakdown || {},
        macroBottomLine: macroTrigger.macroBottomLine || '',
        regimeClassification: macroTrigger.regimeClassification || {},
        sectorImplications: macroTrigger.sectorImplications || {},
      },
      
      // PAGE 1: SECTOR FUNNEL
      sectorFunnel: {
        pageTitle: sectorFunnel.pageTitle || 'Sector Funnel: Where Macro Becomes Investable',
        ismToSectorMapping: sectorFunnel.ismToSectorMapping || {},
        sectorRegimeDefinition: sectorFunnel.sectorRegimeDefinition || {},
        capitalBehavior: sectorFunnel.capitalBehavior || {},
        whyThisSectorNow: sectorFunnel.whyThisSectorNow || {},
        sectorSelectionCriteria: sectorFunnel.sectorSelectionCriteria || {},
      },
      
      // PAGE 2: WHY THIS COMPANY
      whyThisCompany: {
        pageTitle: whyThisCompany.pageTitle || `Why This Company: ${dbReport.ticker}`,
        companySnapshot: whyThisCompany.companySnapshot || {},
        ismSensitivityLens: whyThisCompany.ismSensitivityLens || {},
        competitiveContext: whyThisCompany.competitiveContext || {},
        hypothesis: whyThisCompany.hypothesis || {},
        selectionScorecard: whyThisCompany.selectionScorecard || {},
      },
      
      // ISM BRIDGE
      ismBridge: {
        whyNotEarningsAlone: ismBridge.whyNotEarningsAlone || '',
        whyNotGuidanceAlone: ismBridge.whyNotGuidanceAlone || '',
        whyISMSpecifically: ismBridge.whyISMSpecifically || '',
        transmissionChain: ismBridge.transmissionChain || [],
        proofPoints: ismBridge.proofPoints || [],
      },
      
      // PAGE 3: BUSINESS REALITY
      businessReality: {
        identification: {
          ticker: dbReport.ticker,
          name: dbReport.company_name,
          exchange: dbReport.exchange || businessReality?.identification?.exchange || 'N/A',
          marketCap: dbReport.market_cap || businessReality?.identification?.marketCap,
          marketCapFormatted: businessReality?.identification?.marketCapFormatted || 
                              formatMarketCapSimple(dbReport.market_cap),
          sector: dbReport.sector || businessReality?.identification?.sector || 'N/A',
          industry: dbReport.industry || businessReality?.identification?.industry || 'N/A',
          employees: businessReality?.identification?.employees,
          employeesFormatted: businessReality?.identification?.employeesFormatted || 
                              (businessReality?.identification?.employees?.toLocaleString()) || 
                              'N/A',
        },
        whatTheySell: businessReality?.whatTheySell || {
          oneSentence: '',
          products: [],
          valueProposition: '',
        },
        customerProfile: businessReality?.customerProfile || {},
        revenueModel: businessReality?.revenueModel || {},
        driverHierarchy: driverHierarchy,
      },
      
      // DRIVER HIERARCHY
      driverHierarchy: {
        primary: driverHierarchy?.primary || {},
        secondary: driverHierarchy?.secondary || [],
        tertiary: driverHierarchy?.tertiary || [],
        noise: driverHierarchy?.noise || [],
      },
      
      // SECTOR COMPETITION
      sectorCompetition: {
        realSector: sectorCompetition?.realSector || {
          primarySector: dbReport.sector || 'N/A',
          gicsClassification: sectorCompetition?.realSector?.gicsClassification || '',
          valueChainPosition: sectorCompetition?.realSector?.valueChainPosition || 'N/A',
          endMarkets: sectorCompetition?.realSector?.endMarkets || [],
        },
        sectorCycle: sectorCompetition?.sectorCycle || {},
        cyclicality: sectorCompetition?.cyclicality || {
          type: sectorCompetition?.cyclicality?.type || 'N/A',
          currentPosition: sectorCompetition?.cyclicality?.currentPosition || 'N/A',
        },
        moatScores: sectorCompetition?.moatScores || {
          scores: {},
          totalScore: 0,
        },
        competitors: sectorCompetition?.competitors || {
          directCompetitors: [],
          competitiveMap: [],
        },
        counterCase: sectorCompetition?.counterCase || {},
      },
      
      // PAGE 4: FINANCIAL CORE
      financialCore: {
        revenueQuality: financialCore?.revenueQuality || {
          growth: {},
          quality: {},
          qualityGrade: {},
        },
        profitability: financialCore?.profitability || {
          margins: {},
        },
        cashFlow: financialCore?.cashFlow || {
          fcfAnalysis: {},
        },
        unitEconomics: financialCore?.unitEconomics || {},
        unitEconomicsSnapshot: financialCore?.unitEconomicsSnapshot || {},
        numbersVsInterpretation: financialCore?.numbersVsInterpretation || {},
      },
      
      // PAGE 5: FORWARD VIEW
      forwardView: {
        scenarios: forwardView?.scenarios || {
          bullCase: forwardView?.bullCase || {},
          baseCase: forwardView?.baseCase || {},
          bearCase: forwardView?.bearCase || {},
          riskReward: forwardView?.riskReward || {},
        },
        catalysts: forwardView?.catalysts || {
          nearTerm: forwardView?.nearTerm || [],
          mediumTerm: forwardView?.mediumTerm || [],
          longTerm: forwardView?.longTerm || [],
          negativeWatches: forwardView?.negativeWatches || [],
        },
      },
      
      // PAGE 6: INVESTMENT DECISION
      investmentDecision: {
        decisionFraming: investmentDecision?.decisionFraming || {},
        valuation: investmentDecision?.valuation || {},
        tradeProfile: investmentDecision?.tradeProfile || investmentDecision?.investmentProfile || {},
        riskMonitor: investmentDecision?.riskMonitor || {
          keyRisks: [],
        },
        actionChecklist: investmentDecision?.actionChecklist || {
          beforeBuying: [],
        },
      },
      
      // PAGE 7: ONE PAGE SUMMARY
      onePageSummary: onePageSummary,
      
      // Filings Analysis
      filingsAnalysis: filingsAnalysis,
    },
    
    // ====== QUALITY ASSURANCE ======
    qualityAssurance: {
      qualityScore: {
        score: dbReport.qa_score || 0,
        grade: getGradeFromScore(dbReport.qa_score || 0),
      },
      qaScore: dbReport.qa_score || 0,
      grade: getGradeFromScore(dbReport.qa_score || 0),
    },
    
    // ====== ISM DATA ======
    ismData: execSummary?._sections?.ismData || sectionsFromExec.ismData || {},
  };
  
  console.log('[Routes] Transformation complete');
  console.log(`[Routes] Sections created: ${Object.keys(transformedReport.sections).join(', ')}`);
  
  return transformedReport;
}

// Helper function to format market cap
function formatMarketCapSimple(num) {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  const absNum = Math.abs(num);
  if (absNum >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (absNum >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (absNum >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
  return `$${num.toLocaleString()}`;
}

// Helper function to get grade from score
function getGradeFromScore(score) {
  if (score >= 90) return 'A';
  if (score >= 80) return 'B';
  if (score >= 70) return 'C';
  if (score >= 60) return 'D';
  return 'F';
}

// ============================================
// COMPANY AGENTS INFO
// ============================================
const COMPANY_AGENTS = [
  { id: 'company_data_fetcher', name: 'Company Data Fetcher', icon: '📥', phase: 'DATA_ACQUISITION' },
  { id: 'financial_data_fetcher', name: 'Financial Data Fetcher', icon: '💰', phase: 'DATA_ACQUISITION' },
  { id: 'sec_filings_fetcher', name: 'SEC Filings Fetcher', icon: '📋', phase: 'DATA_ACQUISITION' },
  { id: 'news_events_fetcher', name: 'News & Events Fetcher', icon: '📰', phase: 'DATA_ACQUISITION' },
  { id: 'ism_data_fetcher', name: 'ISM Data Fetcher', icon: '📊', phase: 'DATA_ACQUISITION' },
  { id: 'macro_trigger_analyzer', name: 'Macro Trigger Analyzer', icon: '🌍', phase: 'ISM_MACRO_ANALYSIS' },
  { id: 'sector_funnel_analyzer', name: 'Sector Funnel Analyzer', icon: '🔻', phase: 'SECTOR_ANALYSIS' },
  { id: 'sector_classifier', name: 'Sector Classifier', icon: '🗺️', phase: 'SECTOR_ANALYSIS' },
  { id: 'company_selection_analyzer', name: 'Company Selection Analyzer', icon: '🎯', phase: 'COMPANY_SELECTION' },
  { id: 'competitor_mapper', name: 'Competitor Mapper', icon: '⚔️', phase: 'COMPANY_SELECTION' },
  { id: 'ism_bridge_builder', name: 'ISM Bridge Builder', icon: '🌉', phase: 'COMPANY_SELECTION' },
  { id: 'business_model_analyzer', name: 'Business Model Analyzer', icon: '🏢', phase: 'BUSINESS_ANALYSIS' },
  { id: 'revenue_driver_mapper', name: 'Revenue Driver Mapper', icon: '💵', phase: 'BUSINESS_ANALYSIS' },
  { id: 'mispricing_detector', name: 'Mispricing Detector', icon: '🔍', phase: 'BUSINESS_ANALYSIS' },
  { id: 'driver_hierarchy_builder', name: 'Driver Hierarchy Builder', icon: '📊', phase: 'BUSINESS_ANALYSIS' },
  { id: 'revenue_quality_analyzer', name: 'Revenue Quality Analyzer', icon: '📊', phase: 'FINANCIAL_ANALYSIS' },
  { id: 'profitability_analyzer', name: 'Profitability Analyzer', icon: '💹', phase: 'FINANCIAL_ANALYSIS' },
  { id: 'cash_flow_analyzer', name: 'Cash Flow Analyzer', icon: '💸', phase: 'FINANCIAL_ANALYSIS' },
  { id: 'unit_economics_calculator', name: 'Unit Economics Calculator', icon: '🔢', phase: 'FINANCIAL_ANALYSIS' },
  { id: 'unit_economics_snapshot_builder', name: 'Unit Economics Snapshot', icon: '📸', phase: 'FINANCIAL_ANALYSIS' },
  { id: 'numbers_vs_interpretation_builder', name: 'Numbers vs Interpretation', icon: '⚖️', phase: 'FINANCIAL_ANALYSIS' },
  { id: 'scenario_builder', name: 'Scenario Builder', icon: '🎯', phase: 'FORWARD_ANALYSIS' },
  { id: 'catalyst_identifier', name: 'Catalyst Identifier', icon: '⚡', phase: 'FORWARD_ANALYSIS' },
  { id: 'decision_framing_builder', name: 'Decision Framing Builder', icon: '🖼️', phase: 'INVESTMENT_SYNTHESIS' },
  { id: 'valuation_framework_builder', name: 'Valuation Framework Builder', icon: '💎', phase: 'INVESTMENT_SYNTHESIS' },
  { id: 'trade_profile_generator', name: 'Trade Profile Generator', icon: '📈', phase: 'INVESTMENT_SYNTHESIS' },
  { id: 'risk_monitor_builder', name: 'Risk Monitor Builder', icon: '⚠️', phase: 'INVESTMENT_SYNTHESIS' },
  { id: 'action_checklist_builder', name: 'Action Checklist Builder', icon: '✅', phase: 'INVESTMENT_SYNTHESIS' },
  { id: 'coherence_checker', name: 'Coherence Checker', icon: '✅', phase: 'QUALITY_ASSURANCE' },
  { id: 'executive_summary_writer', name: 'Executive Summary Writer', icon: '📝', phase: 'QUALITY_ASSURANCE' },
  { id: 'one_page_summary_builder', name: 'One Page Summary Builder', icon: '📄', phase: 'QUALITY_ASSURANCE' },
];

const PHASES = [
  { id: 'DATA_ACQUISITION', label: 'Data Acquisition', color: '#3B82F6' },
  { id: 'ISM_MACRO_ANALYSIS', label: 'ISM Macro Analysis', color: '#8B5CF6' },
  { id: 'SECTOR_ANALYSIS', label: 'Sector Analysis', color: '#06B6D4' },
  { id: 'COMPANY_SELECTION', label: 'Company Selection', color: '#14B8A6' },
  { id: 'BUSINESS_ANALYSIS', label: 'Business Analysis', color: '#F97316' },
  { id: 'FINANCIAL_ANALYSIS', label: 'Financial Analysis', color: '#EAB308' },
  { id: 'FORWARD_ANALYSIS', label: 'Forward Analysis', color: '#10B981' },
  { id: 'INVESTMENT_SYNTHESIS', label: 'Investment Synthesis', color: '#EC4899' },
  { id: 'QUALITY_ASSURANCE', label: 'Quality Assurance', color: '#6366F1' },
];

// ============================================
// IN-MEMORY PROGRESS TRACKING
// ============================================
const activeGenerations = new Map();

// Clean up old generations periodically
setInterval(() => {
  const now = Date.now();
  for (const [key, gen] of activeGenerations) {
    const age = now - new Date(gen.startedAt).getTime();
    // Remove completed after 1 hour
    if (gen.status === 'completed' && age > 60 * 60 * 1000) {
      activeGenerations.delete(key);
    }
    // Remove errors after 10 minutes
    else if (gen.status === 'error' && age > 10 * 60 * 1000) {
      activeGenerations.delete(key);
    }
    // Remove stale running (>30 min) as likely stuck
    else if (gen.status === 'running' && age > 30 * 60 * 1000) {
      gen.status = 'error';
      gen.error = 'Generation timed out after 30 minutes';
      activeGenerations.set(key, gen);
    }
  }
}, 60 * 1000); // Check every minute

// ============================================
// ROUTER FACTORY
// ============================================

/**
 * Create Company Analysis Router
 * 
 * @param {object} supabase - Supabase client
 * @param {object} options - Configuration options
 * @returns {Router} - Express router
 */
function createCompanyRouter(supabase, options = {}) {
  const router = express.Router();
  
  const {
    eodhApiKey = process.env.EODH_API_KEY,
    openaiApiKey = process.env.OPENAI_API_KEY,
    openaiModel = process.env.OPENAI_MODEL || 'gpt-4-turbo',
    logoPath = process.env.LOGO_PATH || findFinotaurLogo(),
    scheduler = null,
  } = options;

  // Log logo status
  console.log(`[Routes] LOGO_PATH env: ${process.env.LOGO_PATH || 'not set'}`);
  if (logoPath) {
    console.log(`[Routes] ✅ Using Finotaur logo: ${logoPath}`);
    // Verify file exists
    if (fs.existsSync(logoPath)) {
      console.log(`[Routes] ✅ Logo file exists at: ${logoPath}`);
    } else {
      console.log(`[Routes] ❌ Logo file NOT FOUND at: ${logoPath}`);
    }
  } else {
    console.log(`[Routes] ⚠️ No logo path configured`);
  }

  // Create data service for validation and logo fetching
  const dataService = new CompanyDataService(supabase, { 
    eodhApiKey,
    polygonApiKey: process.env.POLYGON_API_KEY,
  });

  // Service reference for backward compatibility
  let companyService = null;
  
  const getService = () => companyService;
  
  router.setService = (service) => {
    companyService = service;
  };

  // ============================================
  // AUTH MIDDLEWARE
  // ============================================
  const authMiddleware = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    
    if (authHeader && authHeader.startsWith('Bearer ') && supabase) {
      const token = authHeader.split(' ')[1];
      try {
        const { data: { user }, error } = await supabase.auth.getUser(token);
        if (!error && user) {
          req.user = user;
        }
      } catch (e) {
        // Continue without user
      }
    }
    
    next();
  };

  // ============================================
  // HEALTH & DEBUG ENDPOINTS
  // ============================================

  /**
   * GET /health - Health check with detailed status
   */
  router.get('/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'company-analysis',
      config: {
        openaiConfigured: !!openaiApiKey,
        supabaseConfigured: !!supabase,
        eodhConfigured: !!eodhApiKey,
        logoConfigured: !!logoPath,
      },
      agentCount: 27,
      version: '2.3.0-fixed',
      timestamp: new Date().toISOString(),
    });
  });

  /**
   * GET /debug - Detailed debug info
   */
  router.get('/debug', (req, res) => {
    res.json({
      serviceInitialized: true,
      supabaseCreated: !!supabase,
      logoPath: logoPath || 'not found',
      activeGenerations: activeGenerations.size,
      generations: Array.from(activeGenerations.entries()).map(([k, v]) => ({
        ticker: k,
        reportId: v.reportId,
        status: v.status,
        progress: v.progress,
        elapsedSeconds: v.elapsedSeconds,
      })),
      envVars: {
        SUPABASE_URL: process.env.SUPABASE_URL ? 'SET' : 'MISSING',
        SUPABASE_SERVICE_KEY: process.env.SUPABASE_SERVICE_KEY ? 'SET' : 'MISSING',
        OPENAI_API_KEY: openaiApiKey ? 'SET' : 'MISSING',
        EODH_API_KEY: eodhApiKey ? 'SET' : 'MISSING',
      },
    });
  });

  // ============================================
  // S&P 500 UTILITIES
  // ============================================

  /**
   * GET /sp500/random - Get random S&P 500 ticker
   */
  router.get('/sp500/random', (req, res) => {
    const ticker = getRandomSP500Ticker();
    res.json({
      success: true,
      ticker,
      inSP500: true,
    });
  });

  /**
   * GET /sp500/check/:ticker - Check if ticker is in S&P 500
   */
  router.get('/sp500/check/:ticker', (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const inSP500 = isInSP500(ticker);
    res.json({
      success: true,
      ticker,
      inSP500,
    });
  });

  /**
   * GET /sp500/list - Get all S&P 500 tickers
   */
  router.get('/sp500/list', (req, res) => {
    res.json({
      success: true,
      tickers: SP500_TICKERS,
      count: SP500_TICKERS.length,
    });
  });

  // ============================================
  // GENERATION ENDPOINTS
  // ============================================

  /**
   * POST /generate - Start company analysis generation
   */
  router.post('/generate', authMiddleware, async (req, res) => {
    let { ticker, force, includeIsm } = req.body;
    
    // ISM Toggle - default to true for backward compatibility
    const shouldIncludeIsm = includeIsm !== false;
    
    // If no ticker provided, get random S&P 500
    if (!ticker) {
      ticker = getRandomSP500Ticker();
      console.log(`[Routes] No ticker provided, using random S&P 500: ${ticker}`);
    }
    
    ticker = ticker.toUpperCase();
    console.log(`[Routes] Starting generation for ${ticker}, includeIsm: ${shouldIncludeIsm}`);
    
    // Check if already generating
    const existing = activeGenerations.get(ticker);
    if (existing && existing.status === 'running') {
      return res.status(409).json({
        success: false,
        error: `Generation already in progress for ${ticker}`,
        reportId: existing.reportId,
        progress: existing.progress,
      });
    }
    
    // Create report ID
    const reportId = `company_${ticker}_${Date.now()}`;
    
    // Initialize tracking
    activeGenerations.set(ticker, {
      reportId,
      status: 'running',
      progress: 0,
      currentPhase: 'Initializing',
      currentAgentId: null,
      completedAgents: [],
      startedAt: new Date().toISOString(),
      elapsedSeconds: 0,
      includeIsm: shouldIncludeIsm,
    });
    
    // Start generation in background
    (async () => {
      const startTime = Date.now();
      
      try {
        // Create orchestrator directly
        const orchestrator = new CompanyAnalysisOrchestrator(supabase, {
          eodhApiKey,
          openaiApiKey,
          openaiModel,
        });
        
        // Generate with progress callbacks and ISM toggle
        const result = await orchestrator.generate(ticker, {
          force,
          includeIsm: shouldIncludeIsm,
          onProgress: (progress) => {
            const gen = activeGenerations.get(ticker);
            if (gen) {
              gen.progress = progress.percent || 0;
              gen.currentPhase = progress.phase || gen.currentPhase;
              gen.currentAgentId = progress.agentId || gen.currentAgentId;
              gen.elapsedSeconds = Math.round((Date.now() - startTime) / 1000);
              
              if (progress.agentId && !gen.completedAgents.includes(progress.agentId)) {
                if (progress.status === 'completed') {
                  gen.completedAgents.push(progress.agentId);
                }
              }
              
              activeGenerations.set(ticker, gen);
            }
          },
        });
        
        // Mark as completed
        const gen = activeGenerations.get(ticker);
        if (gen) {
          gen.status = 'completed';
          gen.progress = 100;
          gen.result = result;
          gen.elapsedSeconds = Math.round((Date.now() - startTime) / 1000);
          activeGenerations.set(ticker, gen);
        }
        
        console.log(`[Routes] Generation completed for ${ticker} in ${gen?.elapsedSeconds}s`);
        
      } catch (error) {
        console.error(`[Routes] Generation failed for ${ticker}:`, error);
        
        const gen = activeGenerations.get(ticker);
        if (gen) {
          gen.status = 'error';
          gen.error = error.message;
          gen.elapsedSeconds = Math.round((Date.now() - startTime) / 1000);
          activeGenerations.set(ticker, gen);
        }
      }
    })();
    
    // Return immediately with tracking info
    res.json({
      success: true,
      message: `Generation started for ${ticker}`,
      reportId,
      ticker,
      inSP500: isInSP500(ticker),
      includeIsm: shouldIncludeIsm,
    });
  });

  /**
   * GET /generate/status/:ticker - Get generation status
   */
  router.get('/generate/status/:ticker', (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const gen = activeGenerations.get(ticker);
    
    if (!gen) {
      return res.json({
        success: true,
        status: 'not_found',
        message: `No active generation for ${ticker}`,
      });
    }
    
    res.json({
      success: true,
      ticker,
      reportId: gen.reportId,
      status: gen.status,
      progress: gen.progress,
      currentPhase: gen.currentPhase,
      currentAgentId: gen.currentAgentId,
      completedAgents: gen.completedAgents,
      elapsedSeconds: gen.elapsedSeconds,
      startedAt: gen.startedAt,
      error: gen.error,
      includeIsm: gen.includeIsm,
    });
  });

  // ============================================
  // REPORT ENDPOINTS
  // ============================================

  /**
   * GET /report/:reportId - Get report data
   */
  router.get('/report/:reportId', authMiddleware, async (req, res) => {
    const { reportId } = req.params;
    
    // Check in-memory first
    for (const [ticker, gen] of activeGenerations) {
      if (gen.reportId === reportId && gen.status === 'completed' && gen.result) {
        // FIXED: gen.result is { success, report, ... }, extract the actual report
        const actualReport = gen.result.report || gen.result;
        return res.json({
          success: true,
          data: {
            ...actualReport,
            markdown_content: actualReport.markdown || actualReport.markdown_content,
            html_content: actualReport.html || actualReport.html_content,
            created_at: gen.startedAt,
            qa_score: actualReport.qualityAssurance?.qualityScore?.score || 
                      actualReport.qa_score || 85,
          },
        });
      }
    }
    
    // Try to extract ticker from reportId format: company_TICKER_timestamp
    const match = reportId.match(/^company_([A-Z]+)_\d+$/);
    if (match) {
      const extractedTicker = match[1];
      // Check in-memory by ticker
      const gen = activeGenerations.get(extractedTicker);
      if (gen && gen.status === 'completed' && gen.result) {
        // FIXED: gen.result is { success, report, ... }, extract the actual report
        const actualReport = gen.result.report || gen.result;
        return res.json({
          success: true,
          data: {
            ...actualReport,
            markdown_content: actualReport.markdown || actualReport.markdown_content,
            html_content: actualReport.html || actualReport.html_content,
            created_at: gen.startedAt,
            qa_score: actualReport.qualityAssurance?.qualityScore?.score || 
                      actualReport.qa_score || 85,
          },
        });
      }
      
      // Check database by ticker (get most recent)
      if (supabase) {
        try {
          const { data, error } = await supabase
            .from('company_reports')
            .select('*')
            .eq('ticker', extractedTicker)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();
          
          if (data && !error) {
            return res.json({
              success: true,
              data,
            });
          }
        } catch (e) {
          // Continue
        }
      }
    }
    
    // Check database by UUID
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('company_reports')
          .select('*')
          .eq('id', reportId)
          .single();
        
        if (data && !error) {
          return res.json({
            success: true,
            data,
          });
        }
      } catch (e) {
        // Continue
      }
    }
    
    res.status(404).json({
      success: false,
      error: 'Report not found',
    });
  });

  /**
   * GET /report/:reportId/pdf - Download PDF
   */
  router.get('/report/:reportId/pdf', authMiddleware, async (req, res) => {
    const { reportId } = req.params;
    
    let report = null;
    let reportTicker = null;
    
    console.log(`\n[Routes] ===== PDF REQUEST START =====`);
    console.log(`[Routes] PDF requested for: ${reportId}`);
    
    // Check in-memory first
    for (const [ticker, gen] of activeGenerations) {
      if (gen.reportId === reportId && gen.status === 'completed' && gen.result) {
        console.log(`[Routes] Found in activeGenerations for ticker: ${ticker}`);
        console.log(`[Routes] gen.result keys: ${Object.keys(gen.result).join(', ')}`);
        console.log(`[Routes] gen.result.success: ${gen.result.success}`);
        console.log(`[Routes] gen.result.report exists: ${!!gen.result.report}`);
        
        // Extract the actual report from the result
        report = gen.result.report || gen.result;
        
        console.log(`[Routes] Extracted report.ticker: ${report?.ticker}`);
        console.log(`[Routes] Extracted report.company_name: ${report?.company_name}`);
        console.log(`[Routes] Extracted report.sections exists: ${!!report?.sections}`);
        
        if (report?.sections) {
          console.log(`[Routes] sections keys: ${Object.keys(report.sections).join(', ')}`);
          console.log(`[Routes] sections.cover exists: ${!!report.sections.cover}`);
          console.log(`[Routes] sections.cover.companyName: ${report.sections.cover?.companyName}`);
          console.log(`[Routes] sections.companySnapshot exists: ${!!report.sections.companySnapshot}`);
          console.log(`[Routes] sections.incomeStatement exists: ${!!report.sections.incomeStatement}`);
        }
        
        reportTicker = ticker;
        break;
      }
    }
    
    // Try to extract ticker from reportId format: company_TICKER_timestamp
    if (!report) {
      const match = reportId.match(/^company_([A-Z]+)_\d+$/);
      if (match) {
        const extractedTicker = match[1];
        console.log(`[Routes] Extracted ticker from reportId: ${extractedTicker}`);
        
        // Check in-memory by ticker
        const gen = activeGenerations.get(extractedTicker);
        if (gen && gen.status === 'completed' && gen.result) {
          // FIXED: gen.result is { success, report, ... }, extract the actual report
          console.log(`[Routes] DEBUG (by ticker): gen.result keys: ${Object.keys(gen.result).join(', ')}`);
          console.log(`[Routes] DEBUG (by ticker): gen.result.report exists: ${!!gen.result.report}`);
          
          report = gen.result.report || gen.result;
          
          console.log(`[Routes] DEBUG (by ticker): extracted report.ticker: ${report?.ticker}`);
          
          reportTicker = extractedTicker;
          console.log(`[Routes] Found in-memory report by ticker: ${extractedTicker}`);
        }
        
        // Check database by ticker (get most recent)
        if (!report && supabase) {
          try {
            console.log(`[Routes] Fetching from database for ticker: ${extractedTicker}`);
            const { data } = await supabase
              .from('company_reports')
              .select('*')
              .eq('ticker', extractedTicker)
              .order('created_at', { ascending: false })
              .limit(1)
              .single();
            
            if (data) {
              console.log(`[Routes] Found database report for ${extractedTicker}`);
              console.log(`[Routes] Database columns: ${Object.keys(data).join(', ')}`);
              
              // TRANSFORM DATABASE DATA TO PDF FORMAT
              report = transformDatabaseReportForPDF(data);
              reportTicker = data.ticker;
            }
          } catch (e) {
            console.error('[Routes] Error fetching from database:', e);
          }
        }
      }
    }
    
    // Check database by UUID
    if (!report && supabase) {
      try {
        console.log(`[Routes] Fetching from database by UUID: ${reportId}`);
        const { data } = await supabase
          .from('company_reports')
          .select('*')
          .eq('id', reportId)
          .single();
        
        if (data) {
          console.log(`[Routes] Found database report by UUID`);
          // TRANSFORM DATABASE DATA TO PDF FORMAT
          report = transformDatabaseReportForPDF(data);
          reportTicker = data.ticker;
        }
      } catch (e) {
        console.error('[Routes] Error fetching from database by UUID:', e);
      }
    }
    
    if (!report) {
      console.log(`[Routes] Report not found: ${reportId}`);
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }
    
    try {
      // Generate PDF with logo path
      console.log(`[Routes] Generating PDF for ${reportTicker}`);
      console.log(`[Routes] Logo path: ${logoPath || 'none'}`);
      console.log(`[Routes] Report has sections: ${report.sections ? 'YES' : 'NO'}`);
      
      // DETAILED DEBUG LOGGING
      console.log(`[Routes] ===== PDF DEBUG START =====`);
      console.log(`[Routes] report.ticker: ${report.ticker}`);
      console.log(`[Routes] report.company_name: ${report.company_name}`);
      console.log(`[Routes] report.sector: ${report.sector}`);
      console.log(`[Routes] typeof report.sections: ${typeof report.sections}`);
      
      if (report.sections) {
        console.log(`[Routes] Sections keys: ${Object.keys(report.sections).join(', ')}`);
        console.log(`[Routes] sections.cover exists: ${!!report.sections.cover}`);
        if (report.sections.cover) {
          console.log(`[Routes] cover.ticker: ${report.sections.cover.ticker}`);
          console.log(`[Routes] cover.companyName: ${report.sections.cover.companyName}`);
        }
        console.log(`[Routes] sections.companySnapshot exists: ${!!report.sections.companySnapshot}`);
        if (report.sections.companySnapshot) {
          console.log(`[Routes] snapshot.name: ${report.sections.companySnapshot.name}`);
        }
      } else {
        console.log(`[Routes] ❌ NO SECTIONS IN REPORT!`);
        console.log(`[Routes] Report keys: ${Object.keys(report).join(', ')}`);
      }
      console.log(`[Routes] ===== PDF DEBUG END =====`);
      


      // Fetch company logo for cover page
      let companyLogoBuffer = null;
      try {
        console.log(`[Routes] Fetching company logo for ${reportTicker}...`);
        companyLogoBuffer = await dataService.fetchCompanyLogo(reportTicker);
        if (companyLogoBuffer) {
          console.log(`[Routes] ✅ Company logo fetched for ${reportTicker}: ${companyLogoBuffer.length} bytes`);
        } else {
          console.log(`[Routes] ⚠️ No company logo available for ${reportTicker}`);
        }
      } catch (logoErr) {
        console.log(`[Routes] ❌ Could not fetch company logo: ${logoErr.message}`);
      }
      const pdfBuffer = await generateCompanyReportPDFBuffer(report, logoPath, companyLogoBuffer);
      
      console.log(`[Routes] PDF generated: ${pdfBuffer.length} bytes`);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="Company_Analysis_${reportTicker || 'Report'}.pdf"`);
      res.send(pdfBuffer);
    } catch (e) {
      console.error('[Routes] PDF generation failed:', e);
      // Fallback: return markdown as text file
      const markdown = report.markdown || report.markdown_content || '# Report\n\nContent unavailable';
      
      res.setHeader('Content-Type', 'text/markdown');
      res.setHeader('Content-Disposition', `attachment; filename="Company_Analysis_${reportTicker || 'Report'}.md"`);
      res.send(markdown);
    }
  });

  /**
   * GET /report/:reportId/markdown - Download markdown
   */
  router.get('/report/:reportId/markdown', authMiddleware, async (req, res) => {
    const { reportId } = req.params;
    
    let report = null;
    let reportTicker = null;
    
    // Check in-memory
    for (const [ticker, gen] of activeGenerations) {
      if (gen.reportId === reportId && gen.status === 'completed' && gen.result) {
        // FIXED: gen.result is { success, report, ... }, extract the actual report
        report = gen.result.report || gen.result;
        reportTicker = ticker;
        break;
      }
    }
    
    // Try to extract ticker from reportId format: company_TICKER_timestamp
    if (!report) {
      const match = reportId.match(/^company_([A-Z]+)_\d+$/);
      if (match) {
        const extractedTicker = match[1];
        // Check in-memory by ticker
        const gen = activeGenerations.get(extractedTicker);
        if (gen && gen.status === 'completed' && gen.result) {
          // FIXED: gen.result is { success, report, ... }, extract the actual report
          report = gen.result.report || gen.result;
          reportTicker = extractedTicker;
        }
        
        // Check database by ticker (get most recent)
        if (!report && supabase) {
          try {
            const { data } = await supabase
              .from('company_reports')
              .select('ticker, markdown_content')
              .eq('ticker', extractedTicker)
              .order('created_at', { ascending: false })
              .limit(1)
              .single();
            
            if (data) {
              report = data;
              reportTicker = data.ticker;
            }
          } catch (e) {
            // Continue
          }
        }
      }
    }
    
    // Check database by UUID
    if (!report && supabase) {
      try {
        const { data } = await supabase
          .from('company_reports')
          .select('ticker, markdown_content')
          .eq('id', reportId)
          .single();
        
        if (data) {
          report = data;
          reportTicker = data.ticker;
        }
      } catch (e) {
        // Continue
      }
    }
    
    if (!report) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }
    
    const markdown = report.markdown || report.markdown_content || '# Report\n\nContent unavailable';
    
    res.setHeader('Content-Type', 'text/markdown');
    res.setHeader('Content-Disposition', `attachment; filename="Company_Analysis_${reportTicker || 'Report'}.md"`);
    res.send(markdown);
  });

  /**
   * GET /reports - List recent reports
   */
  router.get('/reports', authMiddleware, async (req, res) => {
    if (!supabase) {
      return res.status(503).json({ success: false, error: 'Database not configured' });
    }
    
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    
    try {
      const { data, error } = await supabase
        .from('company_reports')
        .select('id, ticker, company_name, sector, confidence_level, qa_score, created_at')
        .order('created_at', { ascending: false })
        .limit(limit);
      
      if (error) throw error;
      
      res.json({
        success: true,
        reports: data || [],
        count: data?.length || 0,
      });
    } catch (e) {
      res.status(500).json({
        success: false,
        error: e.message,
      });
    }
  });

  /**
   * GET /reports/ticker/:ticker - Get reports for specific ticker
   */
  router.get('/reports/ticker/:ticker', authMiddleware, async (req, res) => {
    if (!supabase) {
      return res.status(503).json({ success: false, error: 'Database not configured' });
    }
    
    const ticker = req.params.ticker.toUpperCase();
    
    try {
      const { data, error } = await supabase
        .from('company_reports')
        .select('*')
        .eq('ticker', ticker)
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      
      res.json({
        success: true,
        ticker,
        reports: data || [],
        count: data?.length || 0,
      });
    } catch (e) {
      res.status(500).json({
        success: false,
        error: e.message,
      });
    }
  });

  // ============================================
  // UTILITY ENDPOINTS
  // ============================================

  /**
   * GET /active-generations - List all active generations
   */
  router.get('/active-generations', (req, res) => {
    const generations = [];
    
    for (const [ticker, gen] of activeGenerations) {
      generations.push({
        ticker,
        reportId: gen.reportId,
        status: gen.status,
        progress: gen.progress,
        currentPhase: gen.currentPhase,
        currentAgentId: gen.currentAgentId,
        completedAgents: gen.completedAgents?.length || 0,
        elapsedSeconds: gen.elapsedSeconds,
        startedAt: gen.startedAt,
      });
    }
    
    res.json({
      success: true,
      count: generations.length,
      generations,
    });
  });

  /**
   * GET /agents - Get agent definitions
   */
  router.get('/agents', (req, res) => {
    res.json({
      success: true,
      count: COMPANY_AGENTS.length,
      agents: COMPANY_AGENTS,
      phases: PHASES,
    });
  });

  /**
   * DELETE /generation/:ticker - Cancel/clear a generation
   */
  router.delete('/generation/:ticker', authMiddleware, (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    
    if (activeGenerations.has(ticker)) {
      const gen = activeGenerations.get(ticker);
      activeGenerations.delete(ticker);
      
      res.json({
        success: true,
        message: `Generation for ${ticker} cleared`,
        wasStatus: gen.status,
      });
    } else {
      res.json({
        success: true,
        message: `No active generation for ${ticker}`,
      });
    }
  });

  return router;
}

// ============================================
// EXPORTS
// ============================================
module.exports = {
  createCompanyRouter,
  COMPANY_AGENTS,
  PHASES,
  activeGenerations,
  transformDatabaseReportForPDF,
  formatMarketCapSimple,
  getGradeFromScore,
  findFinotaurLogo,
};