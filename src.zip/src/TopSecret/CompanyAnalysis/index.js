// =====================================================
// COMPANY ANALYSIS SERVICE - MAIN ENTRY POINT
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/index.js
//
// Usage:
// const { initCompanyAnalysisService, createCompanyRouter } = require('./TopSecret/CompanyAnalysis');
// const service = initCompanyAnalysisService(supabase, { eodhApiKey: '...' });
// app.use('/api/company', service.router);
// =====================================================

const { CompanyAnalysisOrchestrator, workflowManager } = require('./orchestrator');
const { CompanyDataService, SP500_TICKERS, getRandomSP500Ticker, isInSP500 } = require('./data-service');
const { CompanyAIService, createAIService, AI_CONFIG } = require('./ai-service');
const { createCompanyRouter } = require('./routes');
const { CompanyScheduler, createCompanyScheduler, SCHEDULE_MODES, QUEUE_STATUS } = require('./scheduler');
const { CompanyNotificationService, createNotificationService, NOTIFICATION_CATEGORIES, PRIORITY_LEVELS, ACCESS_TIERS } = require('./notification-service');
const { generateCompanyReportPDFBuffer, generateCompanyReportPDF } = require('./pdf-generator');
const { generateMarkdownReport, generateHTMLReport } = require('./report-generator');
const { ALL_AGENTS, AGENT_EXECUTORS, AGENT_DEFINITIONS } = require('./CompanyAgents');
const { 
  PHASES, 
  PHASE_INFO,
  COMPANY_TYPES,
  COMPANY_TYPE_METRICS,
  MOAT_CHECKLIST,
  REPORT_SECTIONS,
  TRADE_TYPES,
  CONFIDENCE_LEVELS,
  REPORT_CONFIG,
} = require('./config');

// ============================================
// QUICK START - Initialize Everything
// ============================================

/**
 * Initialize complete Company Analysis service
 * 
 * @param {object} supabase - Supabase client
 * @param {object} options - Configuration options
 * @returns {object} - Complete service object
 * 
 * @example
 * const service = initCompanyAnalysisService(supabase, {
 *   eodhApiKey: process.env.EODH_API_KEY,
 *   polygonApiKey: process.env.POLYGON_API_KEY,
 *   fredApiKey: process.env.FRED_API_KEY,
 *   newsApiKey: process.env.NEWS_API_KEY,
 *   logoPath: './static/logo.png',
 *   autoStartScheduler: true,
 * });
 * 
 * app.use('/api/company', service.router);
 */
function initCompanyAnalysisService(supabase, options = {}) {
  const {
    // Data APIs
    eodhApiKey = process.env.EODH_API_KEY,
    polygonApiKey = process.env.POLYGON_API_KEY,
    fredApiKey = process.env.FRED_API_KEY,
    newsApiKey = process.env.NEWS_API_KEY,
    // OpenAI Configuration
    openaiApiKey = process.env.OPENAI_API_KEY,
    openaiModel = process.env.OPENAI_MODEL || 'gpt-4-turbo',
    // General settings
    logoPath = null,
    autoStartScheduler = false,
    cronExpression = '0 8 * * 0', // 8 AM Sunday (Israel time)
    timezone = 'Asia/Jerusalem',
    companiesPerWeek = 1,
    scheduleMode = SCHEDULE_MODES.WEEKLY,
  } = options;

  // Validate API keys
  if (!openaiApiKey) {
    console.warn('[CompanyAnalysis] WARNING: OPENAI_API_KEY not set. AI analysis will fail.');
  }
  if (!polygonApiKey) {
    console.warn('[CompanyAnalysis] WARNING: POLYGON_API_KEY not set. Will use fallback data sources.');
  }
  if (!fredApiKey) {
    console.warn('[CompanyAnalysis] WARNING: FRED_API_KEY not set. ISM/macro data will be limited.');
  }

  // Create services with all API keys
  const dataService = new CompanyDataService(supabase, { 
    eodhApiKey, 
    polygonApiKey, 
    fredApiKey,
    newsApiKey,
  });
  const aiService = new CompanyAIService({ apiKey: openaiApiKey, model: openaiModel });
  const orchestrator = new CompanyAnalysisOrchestrator(supabase, { 
    openaiApiKey, 
    openaiModel,
    polygonApiKey,
    fredApiKey,
    eodhApiKey,
  });
  const notificationService = new CompanyNotificationService(supabase);
  
  // Create scheduler
  const scheduler = new CompanyScheduler(supabase, {
    eodhApiKey,
    polygonApiKey,
    fredApiKey,
    logoPath,
    cronExpression,
    timezone,
    companiesPerWeek,
    mode: scheduleMode,
    autoStart: false,
  });

  // Create the service object first (without router)
  const service = {
    // Core components (router will be added later)
    orchestrator,
    dataService,
    aiService,
    scheduler,
    notificationService,
    workflowManager,
    
    // Quick actions
    
    /**
     * Generate report for a ticker
     */
    async generateReport(ticker, opts = {}) {
      const upperTicker = ticker.toUpperCase();
      console.log(`[CompanyAnalysis] generateReport called for ${upperTicker}`);
      
      const result = await orchestrator.generate(upperTicker, opts);
      
      // Debug: Log critical fields
      if (result.success && result.report) {
        const r = result.report;
        console.log(`[CompanyAnalysis] Report generated for ${upperTicker}:`);
        console.log(`  - company_name: ${r.company_name}`);
        console.log(`  - sector: ${r.sector}`);
        console.log(`  - market_cap: ${r.market_cap}`);
        console.log(`  - valuation.currentPrice: ${r.sections?.valuation?.currentPrice}`);
        console.log(`  - valuation.multiples.pe: ${r.sections?.valuation?.multiples?.pe}`);
        console.log(`  - incomeStatement.revenue.ttm: ${r.sections?.incomeStatement?.revenue?.ttm}`);
        console.log(`  - incomeStatement.margins.gross: ${r.sections?.incomeStatement?.margins?.gross}`);
      }
      
      return result;
    },
    
    /**
     * Generate PDF buffer for a report
     */
    async generatePDF(report) {
      console.log(`[CompanyAnalysis] generatePDF called for ${report.ticker}`);
      console.log(`  - sections exists: ${!!report.sections}`);
      if (report.sections) {
        console.log(`  - valuation.currentPrice: ${report.sections.valuation?.currentPrice}`);
        console.log(`  - incomeStatement.revenue.ttm: ${report.sections.incomeStatement?.revenue?.ttm}`);
      }
      return generateCompanyReportPDFBuffer(report, logoPath);
    },
    
    /**
     * Publish report to Update Center
     */
    async publishReport(reportId, opts = {}) {
      return notificationService.publishReport(reportId, opts);
    },
    
    /**
     * Get report with user access control
     */
    async getReportForUser(reportId, userId) {
      return notificationService.getReportForUser(reportId, userId);
    },
    
    /**
     * Get user's notification feed
     */
    async getUserFeed(userId, opts = {}) {
      return notificationService.getUserFeed(userId, opts);
    },
    
    /**
     * Get generation status for a ticker
     */
    getStatus(ticker) {
      return orchestrator.getStatus(ticker.toUpperCase());
    },
    
    /**
     * Check if can generate for a ticker
     */
    canGenerate(ticker) {
      return orchestrator.canGenerate(ticker.toUpperCase());
    },
    
    /**
     * Validate a ticker
     */
    async validateTicker(ticker) {
      return dataService.validateTicker(ticker.toUpperCase());
    },
    
    /**
     * Check if ticker is in S&P 500
     */
    isInSP500(ticker) {
      return isInSP500(ticker.toUpperCase());
    },
    
    /**
     * Get random S&P 500 ticker
     */
    getRandomTicker() {
      return getRandomSP500Ticker();
    },
    
    /**
     * Get S&P 500 list
     */
    getSP500List() {
      return SP500_TICKERS;
    },
    
    // ISM/Macro Data Methods
    
    /**
     * Get ISM Manufacturing data
     */
    async getISMData() {
      return dataService.fetchISMData();
    },
    
    /**
     * Get macro economic indicators
     */
    async getMacroIndicators() {
      return dataService.fetchMacroIndicators();
    },
    
    /**
     * Get FRED series data
     */
    async getFREDSeries(seriesId, limit = 36) {
      return dataService.fetchFREDSeries(seriesId, limit);
    },
    
    /**
     * Get Polygon ticker details
     */
    async getPolygonDetails(ticker) {
      return dataService.fetchPolygonTickerDetails(ticker.toUpperCase());
    },
    
    /**
     * Get Polygon financials
     */
    async getPolygonFinancials(ticker) {
      return dataService.fetchPolygonFinancials(ticker.toUpperCase());
    },
    
    // Scheduler controls
    
    /**
     * Start the scheduler
     */
    startScheduler() {
      scheduler.start();
    },
    
    /**
     * Stop the scheduler
     */
    stopScheduler() {
      scheduler.stop();
    },
    
    /**
     * Get scheduler status
     */
    getSchedulerStatus() {
      return scheduler.getStatus();
    },
    
    /**
     * Manually trigger report for a ticker
     */
    async triggerReport(ticker, opts = {}) {
      return scheduler.triggerForTicker(ticker.toUpperCase(), opts);
    },
    
    /**
     * Add ticker to queue
     */
    async addToQueue(ticker, opts = {}) {
      return scheduler.addToQueue(ticker.toUpperCase(), opts);
    },
    
    /**
     * Get queue status
     */
    async getQueueStatus() {
      return scheduler.getQueueStatus();
    },
    
    // Report generation utilities
    
    /**
     * Generate markdown report
     */
    toMarkdown(report) {
      return generateMarkdownReport(report);
    },
    
    /**
     * Generate HTML report
     */
    toHTML(report) {
      return generateHTMLReport(report);
    },
  };
  
  // NOW create router with access to the service
  const router = createCompanyRouter(supabase, {
    eodhApiKey,
    logoPath,
    scheduler,
    // Pass a getter function so router can access service methods
    getService: () => service,
  });
  
  // Set the service on the router (alternative method)
  if (router.setService) {
    router.setService(service);
  }
  
  // Add router to service
  service.router = router;
  
  // Start scheduler if requested
  if (autoStartScheduler) {
    scheduler.start();
  }

  console.log('[CompanyAnalysis] ✅ Service initialized successfully');
  console.log('[CompanyAnalysis] 📊 30 AI Agents (v7.1) ready - Enhanced data fallbacks');

  return service;
}

// ============================================
// DATABASE SCHEMA HELPERS
// ============================================

/**
 * SQL to create required tables
 * Run this in Supabase SQL editor if tables don't exist
 */
const CREATE_TABLES_SQL = `
-- Company Reports table
CREATE TABLE IF NOT EXISTS company_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  ticker VARCHAR(10) NOT NULL,
  company_name VARCHAR(255),
  sector VARCHAR(100),
  company_type VARCHAR(50),
  
  -- Report sections (JSONB)
  sections JSONB,
  executive_summary JSONB,
  
  -- Report metadata
  confidence_level VARCHAR(20),
  qa_score INTEGER,
  
  -- Content formats
  markdown_content TEXT,
  html_content TEXT,
  pdf_path VARCHAR(255),
  
  -- Generation info
  is_admin_override BOOLEAN DEFAULT FALSE,
  override_reason TEXT,
  admin_id UUID REFERENCES auth.users(id),
  generation_duration_ms INTEGER,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  deleted_at TIMESTAMP WITH TIME ZONE,
  
  -- Indexes
  CONSTRAINT ticker_format CHECK (ticker ~ '^[A-Z]{1,5}$')
);

CREATE INDEX IF NOT EXISTS idx_company_reports_ticker ON company_reports(ticker);
CREATE INDEX IF NOT EXISTS idx_company_reports_created_at ON company_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_company_reports_sector ON company_reports(sector);

-- Company Agent Logs table
CREATE TABLE IF NOT EXISTS company_agent_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id UUID REFERENCES company_reports(id),
  agent_name VARCHAR(100) NOT NULL,
  phase VARCHAR(50),
  status VARCHAR(20),
  duration_ms INTEGER,
  input_summary TEXT,
  output_summary TEXT,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_company_agent_logs_report ON company_agent_logs(report_id);

-- Update Center Notifications table
CREATE TABLE IF NOT EXISTS update_center_notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  category VARCHAR(50),
  priority VARCHAR(20) DEFAULT 'normal',
  title VARCHAR(255) NOT NULL,
  subtitle VARCHAR(255),
  description TEXT,
  
  -- Report reference
  report_id UUID REFERENCES company_reports(id),
  ticker VARCHAR(10),
  company_name VARCHAR(255),
  sector VARCHAR(100),
  confidence_level VARCHAR(20),
  qa_score INTEGER,
  
  -- Admin info
  is_admin_generated BOOLEAN DEFAULT FALSE,
  
  -- Metadata
  metadata JSONB,
  
  -- Timestamps
  published_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_published ON update_center_notifications(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON update_center_notifications(type);

-- User Notifications (per-user entries)
CREATE TABLE IF NOT EXISTS user_notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  notification_id UUID REFERENCES update_center_notifications(id),
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  subscription_tier VARCHAR(20),
  
  -- Status
  is_read BOOLEAN DEFAULT FALSE,
  is_dismissed BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMP WITH TIME ZONE,
  
  -- Access control
  accessible_sections JSONB,
  admin_message TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_notifications_user ON user_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_user_notifications_unread ON user_notifications(user_id, is_read) WHERE NOT is_dismissed;

-- Company Report Queue
CREATE TABLE IF NOT EXISTS company_report_queue (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  ticker VARCHAR(10) NOT NULL,
  priority VARCHAR(20) DEFAULT 'normal',
  status VARCHAR(20) DEFAULT 'pending',
  
  -- Request info
  requested_by UUID REFERENCES auth.users(id),
  scheduled_for TIMESTAMP WITH TIME ZONE,
  
  -- Processing info
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  report_id UUID REFERENCES company_reports(id),
  error_message TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_queue_pending ON company_report_queue(status, created_at) WHERE status = 'pending';

-- Company Scheduler Logs
CREATE TABLE IF NOT EXISTS company_scheduler_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  job_type VARCHAR(50),
  status VARCHAR(20),
  ticker VARCHAR(10),
  report_id UUID REFERENCES company_reports(id),
  duration_ms INTEGER,
  error_message TEXT,
  admin_id UUID REFERENCES auth.users(id),
  executed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scheduler_logs_executed ON company_scheduler_logs(executed_at DESC);

-- User Subscriptions (if not exists)
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) NOT NULL UNIQUE,
  subscription_tier VARCHAR(20) DEFAULT 'FREE',
  is_active BOOLEAN DEFAULT TRUE,
  preferences JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON user_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_tier ON user_subscriptions(subscription_tier) WHERE is_active;

-- Row Level Security Policies
ALTER TABLE company_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

-- Users can read their own notifications
CREATE POLICY IF NOT EXISTS "Users read own notifications" ON user_notifications
  FOR SELECT USING (auth.uid() = user_id);

-- Users can update their own notifications
CREATE POLICY IF NOT EXISTS "Users update own notifications" ON user_notifications
  FOR UPDATE USING (auth.uid() = user_id);

-- Users can read their own subscription
CREATE POLICY IF NOT EXISTS "Users read own subscription" ON user_subscriptions
  FOR SELECT USING (auth.uid() = user_id);

-- Public can read published reports (basic info)
CREATE POLICY IF NOT EXISTS "Public read reports" ON company_reports
  FOR SELECT USING (deleted_at IS NULL);
`;

// ============================================
// EXPORTS
// ============================================

module.exports = {
  // Quick Start
  initCompanyAnalysisService,
  
  // Core Classes
  CompanyAnalysisOrchestrator,
  CompanyDataService,
  CompanyAIService,
  CompanyScheduler,
  CompanyNotificationService,
  workflowManager,
  
  // Factory Functions
  createCompanyRouter,
  createCompanyScheduler,
  createNotificationService,
  createAIService,
  
  // Agents
  ALL_AGENTS,
  AGENT_EXECUTORS,
  AGENT_DEFINITIONS,
  
  // Configuration
  PHASES,
  PHASE_INFO,
  COMPANY_TYPES,
  COMPANY_TYPE_METRICS,
  MOAT_CHECKLIST,
  REPORT_SECTIONS,
  TRADE_TYPES,
  CONFIDENCE_LEVELS,
  REPORT_CONFIG,
  AI_CONFIG,
  
  // Notification Constants
  NOTIFICATION_CATEGORIES,
  PRIORITY_LEVELS,
  ACCESS_TIERS,
  
  // Scheduler Constants
  SCHEDULE_MODES,
  QUEUE_STATUS,
  
  // S&P 500 Utilities
  SP500_TICKERS,
  getRandomSP500Ticker,
  isInSP500,
  
  // Report Generation
  generateMarkdownReport,
  generateHTMLReport,
  generateCompanyReportPDFBuffer,
  generateCompanyReportPDF,
  
  // Database Schema
  CREATE_TABLES_SQL,
};