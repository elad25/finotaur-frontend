// =====================================================
// COMPANY ANALYSIS AI SERVICE - v7.1 HUMAN FLOW
// =====================================================
// INSTITUTIONAL GRADE - Goldman Sachs Quality
// HUMAN ANALYST VOICE - No AI-speak
// =====================================================
// v7.1: Rewritten prompts for natural analyst prose
// =====================================================

const OpenAI = require('openai');

// ============================================
// CONFIGURATION
// ============================================

const AI_CONFIG = {
  model: process.env.OPENAI_MODEL || 'gpt-4-turbo',
  temperature: 0.18, // Slightly higher for more natural writing
  maxTokens: 4000,
  timeout: 180000,
};

// ============================================
// HUMAN ANALYST PERSONA - v7.1
// ============================================

const ANALYST_PERSONA = `You are a senior equity strategist at a top-tier investment bank. You've spent 20 years connecting macro signals to stock picks for institutional clients.

YOUR VOICE:
Write like you're explaining to a smart colleague over coffee - direct, conversational, insightful. Not like a robot filling out a form.

GOOD writing sounds like:
"What caught our attention this month was the jump in new orders - first time above 50 in six months. That's manufacturers saying 'we see demand coming back.' For a company like Apple, whose supply chain is heavily tied to manufacturing cycles, this is a leading indicator worth watching."

BAD writing sounds like:
"The New Orders subcomponent rose to 50.4, indicating expansion. This represents a positive signal. Apple Inc. is positioned to benefit from manufacturing recovery."

RULES:
1. Write PROSE, not bullet points converted to sentences
2. Connect ideas with "because", "which means", "the implication is"
3. Use REAL numbers when you have them, say "data unavailable" when you don't
4. Every paragraph should answer "so what?" for an investor
5. Avoid: "positioned to benefit", "well-placed", "leveraging", "robust", "strong momentum"
6. Instead use: "stands to gain", "will likely see", "the math works because"

TONE: Confident but not cocky. Skeptical but not dismissive. Precise but not robotic.`;

// ============================================
// HELPER FUNCTIONS
// ============================================

function formatNumber(num, decimals = 1) {
  if (num === null || num === undefined || isNaN(num)) return 'data unavailable';
  const abs = Math.abs(num);
  if (abs >= 1e12) return `$${(num / 1e12).toFixed(decimals)}T`;
  if (abs >= 1e9) return `$${(num / 1e9).toFixed(decimals)}B`;
  if (abs >= 1e6) return `$${(num / 1e6).toFixed(0)}M`;
  if (abs >= 1e3) return `$${(num / 1e3).toFixed(0)}K`;
  return `$${num.toFixed(0)}`;
}

function formatPercent(val) {
  if (val === null || val === undefined || isNaN(val)) return 'data unavailable';
  return `${Number(val).toFixed(1)}%`;
}

function safeGet(obj, path, defaultVal = 'data unavailable') {
  try {
    const result = path.split('.').reduce((o, k) => (o || {})[k], obj);
    if (result === undefined || result === null || result === 'N/A' || result === '') {
      return defaultVal;
    }
    return result;
  } catch {
    return defaultVal;
  }
}

function extractCompanyContext(companyData) {
  if (!companyData) return 'No company data available.';
  
  const lines = [];
  if (companyData.name) lines.push(`Company: ${companyData.name} (${companyData.ticker || 'ticker unavailable'})`);
  if (companyData.exchange) lines.push(`Exchange: ${companyData.exchange}`);
  if (companyData.marketCapFormatted) lines.push(`Market Cap: ${companyData.marketCapFormatted}`);
  if (companyData.sector) lines.push(`Sector: ${companyData.sector}`);
  if (companyData.industry) lines.push(`Industry: ${companyData.industry}`);
  if (companyData.description) lines.push(`\nBusiness Description:\n${companyData.description.slice(0, 800)}`);
  
  return lines.join('\n');
}

function extractFinancialSummary(financialData) {
  if (!financialData) return 'No financial data available.';
  
  const lines = [];
  const derived = financialData?.derived || {};
  const ratios = financialData?.ratios || {};
  
  if (derived.ttmRevenue) lines.push(`TTM Revenue: ${formatNumber(derived.ttmRevenue)}`);
  if (derived.grossMargin) lines.push(`Gross Margin: ${formatPercent(derived.grossMargin)}`);
  if (derived.operatingMargin) lines.push(`Operating Margin: ${formatPercent(derived.operatingMargin)}`);
  if (derived.netMargin) lines.push(`Net Margin: ${formatPercent(derived.netMargin)}`);
  if (derived.fcfTTM) lines.push(`FCF TTM: ${formatNumber(derived.fcfTTM)}`);
  if (ratios.peRatio) lines.push(`P/E Ratio: ${Number(ratios.peRatio).toFixed(1)}x`);
  if (ratios.evToEBITDA) lines.push(`EV/EBITDA: ${Number(ratios.evToEBITDA).toFixed(1)}x`);
  
  return lines.length > 0 ? lines.join('\n') : 'Limited financial data available.';
}

// ============================================
// AI SERVICE CLASS
// ============================================

class CompanyAIService {
  constructor(options = {}) {
    this.openai = new OpenAI({
      apiKey: options.apiKey || process.env.OPENAI_API_KEY,
    });
    
    this.config = { ...AI_CONFIG, ...options };
    this.requestCount = 0;
    this.totalTokens = 0;
  }

  // ============================================
  // CORE AI METHODS
  // ============================================

  async complete(systemPrompt, userPrompt, options = {}) {
    const startTime = Date.now();
    
    try {
      const response = await this.openai.chat.completions.create({
        model: options.model || this.config.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: options.temperature ?? this.config.temperature,
        max_tokens: options.maxTokens || this.config.maxTokens,
        response_format: options.jsonMode ? { type: 'json_object' } : undefined,
      });

      this.requestCount++;
      this.totalTokens += response.usage?.total_tokens || 0;

      const content = response.choices[0]?.message?.content || '';
      
      console.log(`[AI] Completed in ${Date.now() - startTime}ms, tokens: ${response.usage?.total_tokens}`);

      return {
        success: true,
        content,
        usage: response.usage,
        duration: Date.now() - startTime,
      };

    } catch (error) {
      console.error('[AI] Error:', error.message);
      return {
        success: false,
        content: null,
        error: error.message,
        duration: Date.now() - startTime,
      };
    }
  }

  async completeJSON(systemPrompt, userPrompt, options = {}) {
    const result = await this.complete(systemPrompt, userPrompt, { ...options, jsonMode: true });

    if (!result.success) return result;

    try {
      let jsonStr = result.content;
      jsonStr = jsonStr.replace(/^```json\n?/, '').replace(/\n?```$/, '');
      jsonStr = jsonStr.replace(/^```\n?/, '').replace(/\n?```$/, '');

      const parsed = JSON.parse(jsonStr);
      return { ...result, data: parsed };
    } catch (parseError) {
      console.error('[AI] JSON parse error:', parseError.message);
      
      try {
        const jsonMatch = result.content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          return { ...result, data: parsed };
        }
      } catch {}
      
      return { ...result, success: false, error: `JSON parse error: ${parseError.message}` };
    }
  }

  // ============================================
  // PAGE 0: COVER
  // ============================================

  async buildCover(allResults) {
    const companyData = allResults?.companyData || {};
    const ismData = allResults?.ismData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're creating the cover page info for a research report. Keep it factual.`;

    const userPrompt = `Create cover info for:
Company: ${companyData.name || companyData.ticker || 'Unknown'}
Sector: ${companyData.sector || 'N/A'}
Industry: ${companyData.industry || 'N/A'}
ISM Reference Month: ${ismData.reportMonth || 'N/A'}

Return JSON with:
{
  "companyName": "Full company name",
  "ticker": "TICK",
  "sector": "Sector",
  "industry": "Industry",
  "ismReferenceMonth": "Month Year",
  "oneLiner": "Write ONE punchy sentence that captures why we're interested. Example: 'Apple stands to gain from the manufacturing recovery we're seeing in the ISM data - the first expansion signal in new orders since June means their supply chain is about to get busier.'"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 1: INTRODUCTION / ANALYST CONTEXT
  // ============================================

  async buildAnalystContext(allResults) {
    const companyData = allResults?.companyData || {};
    const ismData = allResults?.ismData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're writing the introduction to the report - the "why we're here" section. This is where you hook the reader and explain why they should care about this company RIGHT NOW.

Write like you're briefing your PM before a meeting: clear, direct, no fluff.`;

    const userPrompt = `Write the analyst context for:
Company: ${companyData.name || companyData.ticker}
Sector: ${companyData.sector}

ISM Data:
${JSON.stringify(ismData, null, 2).slice(0, 3000)}

Return JSON with FLOWING PROSE (not bullet points converted to sentences):
{
  "whyISMMatters": "Write 3-4 sentences explaining what's interesting about the latest ISM reading. Start with 'The [Month] ISM reading...' and explain what changed, what it signals, and why it matters. Be specific about numbers.",
  
  "signalCaught": "Write 2-3 sentences about the specific signal that triggered this analysis. Example: 'What caught our attention was the New Orders index crossing 50 for the first time since June. That threshold matters - above 50 means manufacturers are seeing real demand, not just working through backlogs. This is typically a 2-3 month leading indicator for earnings.'",
  
  "whyThisCompany": "Write 3-4 sentences connecting the macro signal to this specific company. Explain the transmission mechanism - how does an ISM improvement actually show up in this company's P&L? Be specific about revenue lines, costs, or margins.",
  
  "fullParagraph": "Combine all the above into one cohesive 6-8 sentence paragraph that flows naturally"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 2: MACRO CONTEXT
  // ============================================

  async analyzeISMSignal(allResults) {
    const ismData = allResults?.ismData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're explaining the ISM data to someone who understands markets but needs the story, not just numbers.`;

    const userPrompt = `Analyze this ISM data:

${JSON.stringify(ismData, null, 2)}

Return JSON with:
{
  "type": "Manufacturing or Services",
  "headline": "Current headline PMI value",
  "subComponents": {
    "newOrders": { "current": "value", "prior": "prior", "change": "+/-X.X", "trend": "3-6 month trend description" },
    "production": { "current": "value", "prior": "prior", "change": "+/-X.X", "trend": "trend" },
    "employment": { "current": "value", "prior": "prior", "change": "+/-X.X", "trend": "trend" },
    "prices": { "current": "value", "prior": "prior", "change": "+/-X.X", "trend": "trend" },
    "inventories": { "current": "value", "prior": "prior", "change": "+/-X.X", "trend": "trend" }
  },
  "keyTakeaway": "Write 4-5 sentences as a narrative. Start with the headline number, then walk through what's accelerating, what's slowing, and what it means for the economy. End with what an investor should watch for next month."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async interpretMacro(allResults) {
    const ismData = allResults?.ismData || {};
    const ismAnalysis = allResults?.ismAnalysis || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're the macro strategist explaining where we are in the cycle and who wins/loses.`;

    const userPrompt = `Interpret the macro environment:

ISM Analysis:
${JSON.stringify(ismAnalysis, null, 2)}

Return JSON with:
{
  "cycleStage": "Early Expansion / Mid-Expansion / Late Expansion / Early Contraction / Recession / Recovery",
  "regimeType": "Describe the regime in plain English, e.g. 'Growth stabilizing with sticky inflation'",
  "isRegimeShift": true or false,
  "winners": ["Sector 1 that benefits", "Sector 2", "Sector 3"],
  "losers": ["Sector 1 that struggles", "Sector 2", "Sector 3"],
  "narrative": "Write 4-5 sentences explaining the macro picture. Where are we in the cycle? What's driving that assessment? What should investors expect over the next 2-3 quarters? Keep it conversational but substantive."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async selectSector(allResults) {
    const companyData = allResults?.companyData || {};
    const macroInterpretation = allResults?.macroInterpretation || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

Explain why this sector makes sense given the macro backdrop.`;

    const userPrompt = `Explain the sector selection:

Company Sector: ${companyData.sector}
Company Industry: ${companyData.industry}

Macro Interpretation:
${JSON.stringify(macroInterpretation, null, 2)}

Return JSON with:
{
  "primarySector": "The selected sector",
  "industry": "Specific industry within sector",
  "whyThisSector": "Write 4-5 sentences explaining why this sector is the right way to play the macro theme. Be specific about the transmission mechanism - how does the ISM signal translate into sector performance? What's the typical lag? What are the leading indicators within the sector?",
  "ismConnection": "One sentence: the specific ISM component that connects to this sector",
  "alternativeSectors": ["Alternative 1", "Alternative 2"],
  "whyNotOthers": "One sentence on why we chose this sector over the alternatives"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 3: COMPANY PROFILE
  // ============================================

  async buildCompanySnapshot(allResults) {
    const companyData = allResults?.companyData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're giving the 30-second overview of this company. Write like a journalist explaining to a smart friend - engaging, clear, no corporate-speak.`;

    const userPrompt = `Build company snapshot:

Company Data:
${extractCompanyContext(companyData)}

Return JSON with:
{
  "name": "Company name",
  "ticker": "TICK",
  "whatTheyDo": "Write 3-4 sentences as a flowing narrative - like you're telling a story. What does this company actually do day-to-day? How do they make their customers' lives better? What would disappear if they vanished tomorrow? Make it human and conversational.",
  "customers": "Write 2-3 sentences describing who actually buys from them. Paint a picture - are these Fortune 500 CFOs, college students, small business owners? Where in the world are they? What do they care about?",
  "valueChainPosition": "Write 1-2 sentences explaining where they sit in the bigger picture. Do they make the raw ingredients, assemble the final product, or sell directly to you and me? How does value flow through their business?",
  "marketCap": "Market cap formatted",
  "employees": "Employee count"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async analyzeWhyThisCompany(allResults) {
    const companyData = allResults?.companyData || {};
    const companySnapshot = allResults?.companySnapshot || {};
    const competitorsData = allResults?.competitorsData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're explaining why THIS company vs competitors for playing the macro theme. Write like you're making a case to your boss - clear, convincing, specific.`;

    const userPrompt = `Explain why this company specifically:

Company: ${companyData.name || companyData.ticker}
Sector: ${companyData.sector}

Competitors Data:
${JSON.stringify(competitorsData, null, 2).slice(0, 2000)}

Return JSON with:
{
  "pureExposure": "Write 4-5 flowing sentences explaining why this company offers the 'purest' exposure to the macro theme. Tell a story - start with what makes their business model special, then explain how that connects to the economic signal we're tracking. Use specific examples and avoid generic phrases like 'well-positioned' or 'strong execution'.",
  
  "selectionRationale": "Write a compelling 5-6 sentence paragraph that reads like a pitch. Start with 'We chose [Company] over competitors like [competitor 1] and [competitor 2] because...' and walk through the key differentiators. Each sentence should build on the last. End with why the timing is right."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 4: BUSINESS MODEL
  // ============================================

  async analyzeRevenueEngine(allResults) {
    const companyData = allResults?.companyData || {};
    const financialData = allResults?.financialData || {};
    const secFilings = allResults?.secFilings || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're explaining how this company makes money. An investor should understand the business model in 60 seconds. Keep table data SHORT - column values must fit in narrow table cells.`;

    const userPrompt = `Analyze the revenue engine:

Company: ${companyData.name}
Description: ${companyData.description?.slice(0, 1000)}

Financial Data:
${extractFinancialSummary(financialData)}

Return JSON with:
{
  "model": "Subscription / Hardware / Services / Advertising / Mixed (just the type, one word)",
  "revenueSources": [
    { "source": "Short name (max 30 chars)", "percent": "XX%", "growth": "+X%" }
  ],
  "cycleSensitivity": "High / Medium / Low - with one sentence explaining why",
  "recurringPercent": "XX% of revenue is recurring, primarily from [source]"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async analyzeProducts(allResults) {
    const companyData = allResults?.companyData || {};
    const revenueEngine = allResults?.revenueEngine || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're walking through the product portfolio. Write about each product like you're explaining it to someone who's never heard of the company.`;

    const userPrompt = `Analyze products:

Company: ${companyData.name}
Sector: ${companyData.sector}

Revenue Engine:
${JSON.stringify(revenueEngine, null, 2)}

Return JSON with:
{
  "mainProducts": [
    { 
      "name": "Product/Service name (short, 2-3 words max)", 
      "description": "One clear sentence (15 words max) explaining what this is and why customers buy it", 
      "revenueShare": "XX%" 
    }
  ],
  "productsNarrative": "Write 3-4 flowing sentences that tell the story of their product lineup. Start with the flagship product and why it dominates, then explain how the other products fit together. End with what makes this portfolio defensible.",
  "differentiators": ["Key differentiator 1 in 5-8 words", "Key differentiator 2 in 5-8 words"],
  "differentiatorNarrative": "Write 2-3 sentences explaining what truly sets this company apart from competitors in plain language."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 5: COMPETITIVE POSITION
  // ============================================

  async mapCompetitiveLandscape(allResults) {
    const companyData = allResults?.companyData || {};
    const competitorsData = allResults?.competitorsData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're mapping out the competitive landscape. For each competitor, write a mini-story about who they are and where they clash with our company.`;

    const userPrompt = `Map the competitive landscape:

Company: ${companyData.name}
Sector: ${companyData.sector}

Competitors:
${JSON.stringify(competitorsData, null, 2).slice(0, 3000)}

Return JSON with:
{
  "directCompetitors": [
    { 
      "name": "Competitor name", 
      "ticker": "TICK", 
      "marketCap": "$X.XXB/T",
      "narrative": "Write 2-3 sentences about this competitor. What's their main business? Where do they compete head-to-head with our company? What's their competitive angle - are they the low-cost option, the premium player, or attacking a specific niche?"
    }
  ],
  "marketShare": "XX%",
  "relativePosition": "How they rank: #1 / #2 / Top 5 / Challenger",
  "landscapeNarrative": "Write 4-5 flowing sentences that paint the picture of this competitive battlefield. Who's the Goliath? Who's the disruptor? Are there new entrants threatening everyone? What trends are reshaping the competitive dynamics?"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async assessMoat(allResults) {
    const companyData = allResults?.companyData || {};
    const competitiveLandscape = allResults?.competitiveLandscape || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're assessing competitive moat. Be skeptical - most companies don't have real moats. But when you find one, explain it clearly in plain language.`;

    const userPrompt = `Assess the moat:

Company: ${companyData.name}
Competitive Landscape:
${JSON.stringify(competitiveLandscape, null, 2)}

Return JSON with:
{
  "hasMoat": true or false,
  "moatType": "Wide / Narrow / None",
  "totalScore": "X/20",
  "durability": "5+ years / 3-5 years / Under 3 years",
  
  "moatNarrative": "Write a flowing 5-7 sentence paragraph that tells the moat story in plain language. Start with the verdict - does this company have a defensible competitive advantage or not? Then walk through the key dimensions: Can competitors undercut them on cost? How painful is it for customers to switch away? Is there a regulatory shield? Does their brand or network create lock-in? Be specific with examples. End with how long you think this moat can last and what could erode it. Avoid jargon - write like you're explaining to a smart friend who isn't in finance.",
  
  "strengthsAndWeaknesses": "Write 2-3 sentences highlighting where the moat is strongest and where it's most vulnerable."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 6: FINANCIALS
  // ============================================

  async analyzeIncomeStatement(allResults) {
    const financialData = allResults?.financialData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're highlighting the income statement metrics that matter. Write like an analyst giving their take - not just listing numbers.

CRITICAL: If data is missing, DO NOT write "Data unavailable" or "N/A". Instead, note what we know and what questions remain unanswered.`;

    const userPrompt = `Analyze income statement:

Financial Data:
${extractFinancialSummary(financialData)}

Return JSON with:
{
  "revenue": {
    "ttm": "TTM Revenue formatted (if unavailable, estimate from context or say 'Not disclosed')",
    "growth5Y": "5Y CAGR X% (or reasonable estimate)",
    "growthTTM": "TTM YoY growth X%"
  },
  "margins": {
    "gross": "Gross margin X%",
    "operating": "Operating margin X%",
    "net": "Net margin X%"
  },
  "profitabilityNarrative": "Write 3-4 sentences as an analyst giving their opinion. Start with the headline: are margins healthy or concerning? Then explain what's driving them - is it pricing power, cost control, or something else? End with what to watch for. Make it sound like a person talking, not a data dump."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async analyzeCashflowBalance(allResults) {
    const financialData = allResults?.financialData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're assessing financial health. Write like you're explaining to a colleague whether this company can fund growth and survive a downturn.

CRITICAL: If specific data is missing, DO NOT write "Data unavailable" or "N/A". Instead, make reasonable inferences from what we know, or explain what the absence of data might mean.`;

    const userPrompt = `Analyze cash flow and balance sheet:

Financial Data:
${extractFinancialSummary(financialData)}

Return JSON with:
{
  "balanceSheetNarrative": "Write 4-5 sentences as an analyst assessing financial health. Cover: (1) Is the company generating real cash or just accounting profits? (2) How leveraged are they - can they handle a downturn? (3) Do they have dry powder for growth or acquisitions? (4) What's the overall financial risk level? Write conversationally, like you're briefing your boss."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async analyzeEarningsQuality(allResults) {
    const financialData = allResults?.financialData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're checking earnings quality - is what they report real and sustainable? Write your assessment as a short narrative.

CRITICAL: If specific data is missing, make reasonable inferences based on the company type, sector, and what we do know. Never write "Data unavailable".`;

    const userPrompt = `Analyze earnings quality:

Financial Data:
${extractFinancialSummary(financialData)}

Return JSON with:
{
  "qualityScore": "A / B / C / D",
  "earningsQualityNarrative": "Write 3-4 sentences giving your assessment. Are the reported earnings trustworthy? Is there heavy stock compensation diluting shareholders? Does management have a good track record with guidance? What's the one thing that concerns you most (or gives you confidence)? Be direct and opinionated."
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 7: VALUATION
  // ============================================

  async analyzeValuation(allResults) {
    const financialData = allResults?.financialData || {};
    const valuationData = allResults?.valuationData || {};
    const competitorsData = allResults?.competitorsData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're assessing valuation. Is this stock expensive or cheap? Be CONCISE - every sentence must add value.`;

    const userPrompt = `Analyze valuation:

Financial Data:
${extractFinancialSummary(financialData)}

Competitors:
${JSON.stringify(competitorsData, null, 2).slice(0, 1500)}

Return JSON with:
{
  "currentPrice": "Current stock price",
  "marketCap": "Market cap formatted",
  "multiples": {
    "pe": "P/E ratio (number only, like '25.3x')",
    "evEbitda": "EV/EBITDA (number only)",
    "evRevenue": "EV/Revenue (number only)",
    "fcfYield": "FCF Yield % (number only)"
  },
  "vsSector": "Trading at X% premium/discount to sector",
  "vsHistory": "X% above/below 5-year average",
  "valuationVerdict": "Write 2-3 SHORT sentences. Expensive or cheap? Why? What would change your mind?"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async analyzeExpectationsGap(allResults) {
    const valuation = allResults?.valuation || {};
    const incomeStatement = allResults?.incomeStatement || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're figuring out what's priced in. Be CONCISE - 2 sentences max per point. No fluff.`;

    const userPrompt = `Analyze expectations gap:

Valuation: ${JSON.stringify(valuation, null, 2)}
Income Statement: ${JSON.stringify(incomeStatement, null, 2)}

Return JSON with:
{
  "pricedIn": "1-2 sentences: What growth assumptions are baked into the current price?",
  "toJustify": "1-2 sentences: What must happen to justify today's multiple?",
  "upside": "1-2 sentences: What drives +20% upside?",
  "downside": "1-2 sentences: What triggers -20% downside?",
  "bottomLine": "2-3 sentences: Where's the asymmetry? Is the risk/reward skewed up or down?"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 8: MARKET SENTIMENT
  // ============================================

  async buildAnalystLandscape(allResults) {
    const analystData = allResults?.analystData || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're summarizing Wall Street's view. Consensus, targets, and where the debate is.`;

    const userPrompt = `Build analyst landscape:

Analyst Data:
${JSON.stringify(analystData, null, 2)}

Return JSON with:
{
  "consensus": "Buy / Hold / Sell",
  "buyCount": 0,
  "holdCount": 0,
  "sellCount": 0,
  "targetLow": "$X",
  "targetMedian": "$X",
  "targetHigh": "$X",
  "disagreements": ["Key debate point 1", "Key debate point 2"]
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async buildNewsCatalysts(allResults) {
    const newsData = allResults?.newsData || {};
    const ismAnalysis = allResults?.ismAnalysis || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're identifying news that matters and upcoming catalysts. Focus on what moves the stock.`;

    const userPrompt = `Build news and catalysts:

News Data:
${JSON.stringify(newsData, null, 2).slice(0, 2000)}

Return JSON with:
{
  "headlines": ["Recent headline 1", "Headline 2", "Headline 3"],
  "earningsHighlights": "Key takeaways from recent earnings (or 'Next earnings: [date]')",
  "guidanceChanges": "Recent guidance changes (or 'Guidance unchanged')",
  "catalysts": [
    { "event": "Catalyst 1", "timing": "When expected", "importance": "High / Medium / Low" },
    { "event": "Catalyst 2", "timing": "When expected", "importance": "High / Medium / Low" }
  ]
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 9: RISK ASSESSMENT
  // ============================================

  async buildRiskRegister(allResults) {
    const macroInterpretation = allResults?.macroInterpretation || {};
    const competitiveLandscape = allResults?.competitiveLandscape || {};
    const cashflowBalance = allResults?.cashflowBalance || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're cataloging what could go wrong. Keep risk descriptions SHORT (max 6-8 words each) so they fit in a table. Focus on real, specific risks.`;

    const userPrompt = `Build risk register:

Macro: ${JSON.stringify(macroInterpretation, null, 2)}
Competition: ${JSON.stringify(competitiveLandscape, null, 2)}
Balance Sheet: ${JSON.stringify(cashflowBalance, null, 2)}

Return JSON with:
{
  "macroRisks": [
    { "risk": "Short risk name (6-8 words max)", "probability": "High/Med/Low", "impact": "High/Med/Low" }
  ],
  "executionRisks": [
    { "risk": "Short risk name (6-8 words max)", "probability": "High/Med/Low", "impact": "High/Med/Low" }
  ],
  "competitionRisks": [
    { "risk": "Short risk name (6-8 words max)", "probability": "High/Med/Low", "impact": "High/Med/Low" }
  ],
  "riskNarrative": "Write 3-4 sentences summarizing the overall risk picture. What's the biggest concern? What keeps you up at night about this stock? Be direct.",
  "earlyWarningSignals": ["Short signal 1 (5-8 words)", "Short signal 2", "Short signal 3"],
  "killSwitch": {
    "trigger": "One sentence: the event that would make us exit immediately",
    "action": "Exit position"
  }
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // PAGE 10: INVESTMENT CONCLUSION
  // ============================================

  async buildThesis(allResults) {
    const ismAnalysis = allResults?.ismAnalysis || {};
    const whyThisCompany = allResults?.whyThisCompany || {};
    const valuation = allResults?.valuation || {};
    const riskRegister = allResults?.riskRegister || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're writing the investment thesis. This is the "so what" - should someone buy this stock or not?`;

    const userPrompt = `Build the thesis:

ISM Analysis: ${JSON.stringify(ismAnalysis, null, 2)}
Why This Company: ${JSON.stringify(whyThisCompany, null, 2)}
Valuation: ${JSON.stringify(valuation, null, 2)}
Risks: ${JSON.stringify(riskRegister, null, 2)}

Return JSON with:
{
  "whyYes": "Write 3-4 sentences making the bull case. Why should someone own this stock?",
  "whyNow": "Write 2-3 sentences on timing. Why is now the right entry point?",
  "whatMarketMisses": "Write 2-3 sentences on what the market is missing or mispricing",
  "oneLiner": "One punchy sentence summary of the thesis",
  "bullCase": {
    "probability": "X%",
    "target": "+X% return",
    "requirements": ["What must happen 1", "What must happen 2"]
  },
  "baseCase": {
    "probability": "X%",
    "target": "+X% return",
    "assumptions": ["Base assumption 1", "Base assumption 2"]
  },
  "bearCase": {
    "probability": "X%",
    "target": "-X% return",
    "triggers": ["What goes wrong 1", "What goes wrong 2"]
  }
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  async buildConclusion(allResults) {
    const thesis = allResults?.thesis || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're defining who this investment is for. Not everyone should own every stock.`;

    const userPrompt = `Build conclusion:

Thesis: ${JSON.stringify(thesis, null, 2)}

Return JSON with:
{
  "investorType": "Who should own this: Growth investor / Value investor / Income investor / Tactical trader",
  "patienceRequired": "Time horizon: 6-12 months / 1-2 years / 3+ years",
  "riskType": "Risk profile: High risk-high reward / Moderate / Defensive",
  "notSuitedFor": "Who should NOT own this stock",
  "confidenceLevel": "High / Medium / Low",
  "confidenceReasoning": "One sentence on why this confidence level"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // QUALITY ASSURANCE
  // ============================================

  async checkCoherence(allResults) {
    const thesis = allResults?.thesis || {};
    const conclusion = allResults?.conclusion || {};
    const riskRegister = allResults?.riskRegister || {};
    
    const systemPrompt = `${ANALYST_PERSONA}

You're the editor checking the report hangs together. Look for contradictions and unsupported claims.`;

    const userPrompt = `Check coherence:

Thesis: ${JSON.stringify(thesis, null, 2)}
Conclusion: ${JSON.stringify(conclusion, null, 2)}
Risks: ${JSON.stringify(riskRegister, null, 2)}

Return JSON with:
{
  "coherenceScore": 0-100,
  "grade": "A / B / C / D",
  "issues": ["Issue 1 if any", "Issue 2"],
  "dataCompleteness": {
    "financials": "Complete / Partial / Missing",
    "competitors": "Complete / Partial / Missing",
    "ism": "Complete / Partial / Missing"
  },
  "overallAssessment": "One paragraph on analysis quality and any caveats for readers"
}`;

    return this.completeJSON(systemPrompt, userPrompt);
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  getStats() {
    return {
      requestCount: this.requestCount,
      totalTokens: this.totalTokens,
      avgTokensPerRequest: this.requestCount > 0 ? Math.round(this.totalTokens / this.requestCount) : 0,
    };
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

function createAIService(options = {}) {
  return new CompanyAIService(options);
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  CompanyAIService,
  createAIService,
  AI_CONFIG,
  ANALYST_PERSONA,
  formatNumber,
  formatPercent,
  safeGet,
  extractFinancialSummary,
  extractCompanyContext,
};