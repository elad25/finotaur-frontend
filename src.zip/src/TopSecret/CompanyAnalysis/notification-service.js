// =====================================================
// COMPANY ANALYSIS NOTIFICATION SERVICE
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/notification-service.js
//
// Sends company analysis reports to the Update Center
// NOT via email - users access through the platform
// =====================================================

/**
 * Update Center notification categories
 */
const NOTIFICATION_CATEGORIES = {
  COMPANY_REPORT: 'company_report',
  WEEKLY_ANALYSIS: 'weekly_analysis',
  ADMIN_GENERATED: 'admin_generated',
  SPECIAL_ALERT: 'special_alert',
};

/**
 * Notification priority levels
 */
const PRIORITY_LEVELS = {
  HIGH: 'high',      // Important/time-sensitive
  NORMAL: 'normal',  // Regular weekly reports
  LOW: 'low',        // Background updates
};

/**
 * Report access tiers
 */
const ACCESS_TIERS = {
  FREE: ['executive_summary'],
  BASIC: ['executive_summary', 'business_reality', 'financial_core'],
  PREMIUM: 'all', // Full access to all sections
};

class CompanyNotificationService {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    this.options = {
      defaultPriority: PRIORITY_LEVELS.NORMAL,
      notificationTable: 'update_center_notifications',
      reportsTable: 'company_reports',
      userSubscriptionsTable: 'user_subscriptions',
      ...options,
    };
  }

  // ============================================
  // MAIN NOTIFICATION FUNCTIONS
  // ============================================

  /**
   * Publish a company report to the Update Center
   * This makes the report available to all subscribed users
   */
  async publishReport(reportId, options = {}) {
    const {
      priority = PRIORITY_LEVELS.NORMAL,
      category = NOTIFICATION_CATEGORIES.COMPANY_REPORT,
      targetUsers = null, // null = all eligible users, or array of user IDs
      isAdminGenerated = false,
    } = options;

    try {
      // Fetch the report
      const { data: report, error: reportError } = await this.supabase
        .from(this.options.reportsTable)
        .select('*')
        .eq('id', reportId)
        .single();

      if (reportError || !report) {
        throw new Error(`Report not found: ${reportId}`);
      }

      console.log(`[CompanyNotification] Publishing report for ${report.ticker}`);

      // Create notification record
      const notification = await this.createNotificationRecord({
        report,
        priority,
        category,
        isAdminGenerated,
      });

      // Determine target users
      const users = targetUsers || await this.getEligibleUsers(report);

      // Create user-specific notification entries
      const userNotifications = await this.createUserNotifications(
        notification.id,
        users,
        report
      );

      console.log(`[CompanyNotification] Published to ${userNotifications.length} users`);

      return {
        success: true,
        notificationId: notification.id,
        reportId: report.id,
        ticker: report.ticker,
        usersNotified: userNotifications.length,
      };

    } catch (error) {
      console.error('[CompanyNotification] Publish error:', error);
      throw error;
    }
  }

  /**
   * Create the main notification record
   */
  async createNotificationRecord({ report, priority, category, isAdminGenerated }) {
    const notificationData = {
      type: 'company_report',
      category,
      priority,
      title: `${report.ticker} Analysis Report`,
      subtitle: report.company_name || report.ticker,
      description: this.generateNotificationDescription(report),
      report_id: report.id,
      ticker: report.ticker,
      company_name: report.company_name,
      sector: report.sector,
      confidence_level: report.confidence_level,
      qa_score: report.qa_score,
      is_admin_generated: isAdminGenerated,
      published_at: new Date().toISOString(),
      metadata: {
        generatedAt: report.created_at,
        companyType: report.company_type,
        sections: Object.keys(report.sections || {}),
      },
    };

    const { data, error } = await this.supabase
      .from(this.options.notificationTable)
      .insert(notificationData)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create notification: ${error.message}`);
    }

    return data;
  }

  /**
   * Generate notification description
   */
  generateNotificationDescription(report) {
    const confidence = report.confidence_level || 'Medium';
    const qaScore = report.qa_score || 'N/A';
    
    let description = `New analysis report for ${report.company_name || report.ticker}`;
    description += ` (${report.sector || 'N/A'})`;
    description += ` • Confidence: ${confidence}`;
    
    if (qaScore !== 'N/A') {
      description += ` • Quality: ${qaScore}/100`;
    }

    // Add executive summary snippet if available
    const summary = report.executive_summary?.lines?.[0] || 
                    report.executive_summary?.summary?.split('.')[0];
    if (summary) {
      description += `\n${summary}`;
    }

    return description;
  }

  /**
   * Get users eligible to receive this report
   */
  async getEligibleUsers(report) {
    // Get all active subscribers (BASIC and PREMIUM)
    const { data: users, error } = await this.supabase
      .from(this.options.userSubscriptionsTable)
      .select('user_id, subscription_tier, preferences')
      .in('subscription_tier', ['BASIC', 'PREMIUM'])
      .eq('is_active', true);

    if (error) {
      console.error('[CompanyNotification] Error fetching users:', error);
      return [];
    }

    // Filter by user preferences if they have sector/ticker preferences
    const eligibleUsers = users.filter(user => {
      const prefs = user.preferences || {};
      
      // If user has no preferences, include them
      if (!prefs.sectors && !prefs.tickers && !prefs.excludedSectors) {
        return true;
      }

      // Check sector preference
      if (prefs.sectors && prefs.sectors.length > 0) {
        if (!prefs.sectors.includes(report.sector)) {
          return false;
        }
      }

      // Check excluded sectors
      if (prefs.excludedSectors && prefs.excludedSectors.includes(report.sector)) {
        return false;
      }

      // Check specific ticker watchlist
      if (prefs.tickers && prefs.tickers.length > 0) {
        return prefs.tickers.includes(report.ticker);
      }

      return true;
    });

    return eligibleUsers;
  }

  /**
   * Create individual user notification entries
   */
  async createUserNotifications(notificationId, users, report) {
    const notifications = users.map(user => ({
      notification_id: notificationId,
      user_id: user.user_id,
      subscription_tier: user.subscription_tier,
      is_read: false,
      is_dismissed: false,
      created_at: new Date().toISOString(),
      // Determine which sections user can access
      accessible_sections: this.getAccessibleSections(user.subscription_tier),
    }));

    if (notifications.length === 0) {
      return [];
    }

    const { data, error } = await this.supabase
      .from('user_notifications')
      .insert(notifications)
      .select();

    if (error) {
      console.error('[CompanyNotification] Error creating user notifications:', error);
      return [];
    }

    return data || [];
  }

  /**
   * Get accessible sections based on subscription tier
   */
  getAccessibleSections(tier) {
    const access = ACCESS_TIERS[tier] || ACCESS_TIERS.FREE;
    return access === 'all' ? 'all' : access;
  }

  // ============================================
  // REPORT ACCESS FUNCTIONS
  // ============================================

  /**
   * Get report for a specific user with proper access control
   */
  async getReportForUser(reportId, userId) {
    // Get user's subscription tier
    const { data: subscription } = await this.supabase
      .from(this.options.userSubscriptionsTable)
      .select('subscription_tier')
      .eq('user_id', userId)
      .single();

    const tier = subscription?.subscription_tier || 'FREE';

    // Get the report
    const { data: report, error } = await this.supabase
      .from(this.options.reportsTable)
      .select('*')
      .eq('id', reportId)
      .single();

    if (error || !report) {
      return { success: false, error: 'Report not found' };
    }

    // Apply access control
    const accessibleSections = this.getAccessibleSections(tier);
    const filteredReport = this.filterReportByAccess(report, accessibleSections);

    // Mark as viewed
    await this.markAsViewed(reportId, userId);

    return {
      success: true,
      report: filteredReport,
      accessLevel: tier,
      fullAccessSections: accessibleSections,
      isFullAccess: accessibleSections === 'all',
    };
  }

  /**
   * Filter report sections based on access level
   */
  filterReportByAccess(report, accessibleSections) {
    if (accessibleSections === 'all') {
      return report;
    }

    const sectionMapping = {
      executive_summary: 'executiveSummary',
      business_reality: 'businessReality',
      sector_competition: 'sectorCompetition',
      financial_core: 'financialCore',
      filings_analysis: 'filingsAnalysis',
      forward_view: 'forwardView',
      investment_decision: 'investmentDecision',
    };

    const filteredSections = {};
    const lockedSections = [];

    for (const [snakeKey, camelKey] of Object.entries(sectionMapping)) {
      if (accessibleSections.includes(snakeKey)) {
        filteredSections[camelKey] = report.sections?.[camelKey];
      } else {
        lockedSections.push(snakeKey);
        // Provide teaser for locked sections
        filteredSections[camelKey] = {
          locked: true,
          teaser: this.getSectionTeaser(snakeKey),
          requiredTier: this.getRequiredTier(snakeKey),
        };
      }
    }

    return {
      ...report,
      sections: filteredSections,
      lockedSections,
      upgradePrompt: lockedSections.length > 0,
    };
  }

  /**
   * Get teaser text for locked sections
   */
  getSectionTeaser(sectionKey) {
    const teasers = {
      sector_competition: 'Unlock competitive analysis and moat scoring',
      financial_core: 'Unlock detailed financial metrics and unit economics',
      filings_analysis: 'Unlock SEC filing insights and management tone analysis',
      forward_view: 'Unlock bull/bear scenarios and catalyst mapping',
      investment_decision: 'Unlock actionable trade profiles and risk monitoring',
    };
    return teasers[sectionKey] || 'Upgrade to access this section';
  }

  /**
   * Get required tier for a section
   */
  getRequiredTier(sectionKey) {
    const basicSections = ['executive_summary', 'business_reality', 'financial_core'];
    return basicSections.includes(sectionKey) ? 'BASIC' : 'PREMIUM';
  }

  /**
   * Mark notification as viewed
   */
  async markAsViewed(reportId, userId) {
    await this.supabase
      .from('user_notifications')
      .update({ 
        is_read: true, 
        read_at: new Date().toISOString() 
      })
      .match({ 
        user_id: userId,
        report_id: reportId 
      });
  }

  // ============================================
  // UPDATE CENTER FEED FUNCTIONS
  // ============================================

  /**
   * Get user's notification feed
   */
  async getUserFeed(userId, options = {}) {
    const {
      limit = 20,
      offset = 0,
      unreadOnly = false,
      category = null,
    } = options;

    let query = this.supabase
      .from('user_notifications')
      .select(`
        id,
        is_read,
        is_dismissed,
        created_at,
        read_at,
        notification:notification_id (
          id,
          type,
          category,
          priority,
          title,
          subtitle,
          description,
          ticker,
          company_name,
          sector,
          confidence_level,
          qa_score,
          published_at,
          report_id
        )
      `)
      .eq('user_id', userId)
      .eq('is_dismissed', false)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (unreadOnly) {
      query = query.eq('is_read', false);
    }

    if (category) {
      query = query.eq('notification.category', category);
    }

    const { data, error } = await query;

    if (error) {
      console.error('[CompanyNotification] Feed error:', error);
      return { notifications: [], total: 0 };
    }

    // Get total count for pagination
    const { count } = await this.supabase
      .from('user_notifications')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('is_dismissed', false);

    return {
      notifications: data || [],
      total: count || 0,
      hasMore: (offset + limit) < (count || 0),
    };
  }

  /**
   * Get unread count for user
   */
  async getUnreadCount(userId) {
    const { count } = await this.supabase
      .from('user_notifications')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('is_read', false)
      .eq('is_dismissed', false);

    return count || 0;
  }

  /**
   * Mark all notifications as read
   */
  async markAllAsRead(userId) {
    const { error } = await this.supabase
      .from('user_notifications')
      .update({ is_read: true, read_at: new Date().toISOString() })
      .eq('user_id', userId)
      .eq('is_read', false);

    return { success: !error };
  }

  /**
   * Dismiss a notification
   */
  async dismissNotification(notificationId, userId) {
    const { error } = await this.supabase
      .from('user_notifications')
      .update({ is_dismissed: true })
      .match({ id: notificationId, user_id: userId });

    return { success: !error };
  }

  // ============================================
  // ADMIN FUNCTIONS
  // ============================================

  /**
   * Send notification to specific users (admin function)
   */
  async notifySpecificUsers(reportId, userIds, options = {}) {
    const {
      priority = PRIORITY_LEVELS.HIGH,
      message = null,
    } = options;

    // Get the report
    const { data: report } = await this.supabase
      .from(this.options.reportsTable)
      .select('*')
      .eq('id', reportId)
      .single();

    if (!report) {
      throw new Error('Report not found');
    }

    // Create notification with admin priority
    const notification = await this.createNotificationRecord({
      report,
      priority,
      category: NOTIFICATION_CATEGORIES.ADMIN_GENERATED,
      isAdminGenerated: true,
    });

    // Create user notifications
    const userNotifications = userIds.map(userId => ({
      notification_id: notification.id,
      user_id: userId,
      subscription_tier: 'PREMIUM', // Admin-sent = full access
      is_read: false,
      is_dismissed: false,
      created_at: new Date().toISOString(),
      accessible_sections: 'all',
      admin_message: message,
    }));

    const { data } = await this.supabase
      .from('user_notifications')
      .insert(userNotifications)
      .select();

    return {
      success: true,
      notificationId: notification.id,
      usersNotified: data?.length || 0,
    };
  }

  /**
   * Get notification stats for admin dashboard
   */
  async getNotificationStats(dateRange = {}) {
    const { startDate, endDate } = dateRange;

    let query = this.supabase
      .from(this.options.notificationTable)
      .select('id, category, published_at, ticker')
      .eq('type', 'company_report');

    if (startDate) {
      query = query.gte('published_at', startDate);
    }
    if (endDate) {
      query = query.lte('published_at', endDate);
    }

    const { data: notifications } = await query;

    // Count user engagement
    const { data: userStats } = await this.supabase
      .from('user_notifications')
      .select('is_read, notification_id');

    const stats = {
      totalReportsPublished: notifications?.length || 0,
      byCategory: {},
      byTicker: {},
      readRate: 0,
    };

    // Calculate stats
    if (notifications) {
      for (const n of notifications) {
        stats.byCategory[n.category] = (stats.byCategory[n.category] || 0) + 1;
        stats.byTicker[n.ticker] = (stats.byTicker[n.ticker] || 0) + 1;
      }
    }

    if (userStats && userStats.length > 0) {
      const readCount = userStats.filter(s => s.is_read).length;
      stats.readRate = ((readCount / userStats.length) * 100).toFixed(1);
    }

    return stats;
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

function createNotificationService(supabase, options = {}) {
  return new CompanyNotificationService(supabase, options);
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  CompanyNotificationService,
  createNotificationService,
  NOTIFICATION_CATEGORIES,
  PRIORITY_LEVELS,
  ACCESS_TIERS,
};