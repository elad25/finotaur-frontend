// =====================================================
// COMPANY ANALYSIS REPORT GENERATOR - v7.0
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/report-generator.js
//
// Clean, professional format - NO EMOJIS
// 10 Report Pages (0-9) as defined in Hebrew blueprint:
// Page 0: Cover + Analyst Context
// Page 1: ISM → Macro → Sector Funnel
// Page 2: Why This Company
// Page 3: Business Model & Products
// Page 4: Competition & Moat Analysis
// Page 5: Financials That Matter
// Page 6: Valuation & Market Expectations
// Page 7: Analysts, News & Catalysts
// Page 8: Risk Register
// Page 9: Investment Conclusion
// =====================================================

// ============================================
// HELPER FUNCTIONS
// ============================================

function formatNumber(num, decimals = 2) {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  if (typeof num === 'string') {
    if (num.includes('$') || num.includes('%')) return num;
    const parsed = parseFloat(num);
    if (isNaN(parsed)) return num;
    num = parsed;
  }
  
  const absNum = Math.abs(num);
  if (absNum >= 1e12) return `$${(num / 1e12).toFixed(decimals)}T`;
  if (absNum >= 1e9) return `$${(num / 1e9).toFixed(decimals)}B`;
  if (absNum >= 1e6) return `$${(num / 1e6).toFixed(decimals)}M`;
  if (absNum >= 1e3) return `$${(num / 1e3).toFixed(1)}K`;
  return `$${num.toFixed(decimals)}`;
}

function formatPercent(val) {
  if (val === null || val === undefined) return 'N/A';
  if (typeof val === 'string') {
    if (val.includes('%')) return val;
    const parsed = parseFloat(val);
    if (!isNaN(parsed)) return `${parsed.toFixed(1)}%`;
    return val;
  }
  if (typeof val === 'number') {
    if (val > -1 && val < 1 && val !== 0) return `${(val * 100).toFixed(1)}%`;
    return `${val.toFixed(1)}%`;
  }
  return 'N/A';
}

function getMoatLabel(score) {
  if (!score || isNaN(score)) return 'NOT SCORED';
  if (score >= 25) return 'WIDE MOAT';
  if (score >= 20) return 'STRONG MOAT';
  if (score >= 15) return 'MODERATE MOAT';
  if (score >= 10) return 'WEAK MOAT';
  return 'NO MOAT';
}

function getConfidenceLabel(level) {
  const levels = {
    high: 'HIGH CONFIDENCE',
    medium: 'MEDIUM CONFIDENCE',
    low: 'LOW CONFIDENCE',
    High: 'HIGH CONFIDENCE',
    Medium: 'MEDIUM CONFIDENCE',
    Low: 'LOW CONFIDENCE',
    HIGH: 'HIGH CONFIDENCE',
    MEDIUM: 'MEDIUM CONFIDENCE',
    LOW: 'LOW CONFIDENCE',
  };
  return levels[level] || level || 'MEDIUM CONFIDENCE';
}

function getGradeLabel(grade) {
  const grades = {
    'A': 'A - Excellent',
    'B': 'B - Good',
    'C': 'C - Average',
    'D': 'D - Below Average',
    'F': 'F - Poor',
  };
  return grades[grade] || `${grade || 'N/A'}`;
}

function getSeverityLabel(severity) {
  const labels = {
    high: 'HIGH',
    medium: 'MEDIUM',
    low: 'LOW',
    HIGH: 'HIGH',
    MEDIUM: 'MEDIUM',
    LOW: 'LOW',
  };
  return labels[severity?.toLowerCase?.()] || severity || 'MEDIUM';
}

function safeGet(obj, path, defaultVal = 'N/A') {
  try {
    const result = path.split('.').reduce((o, k) => (o || {})[k], obj);
    if (result === undefined || result === null || result === '') return defaultVal;
    return result;
  } catch {
    return defaultVal;
  }
}

function safeArray(arr) {
  return Array.isArray(arr) ? arr : [];
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  try {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

// ============================================
// MARKDOWN REPORT GENERATOR - 10 PAGES (0-9)
// ============================================

function generateMarkdownReport(report, context = {}) {
  const { meta, executiveSummary, sections, qualityAssurance } = report || {};
  const ticker = meta?.ticker || context?.ticker || 'UNKNOWN';
  const companyName = meta?.companyName || sections?.companySnapshot?.name || ticker;
  
  let md = '';

  // ========== HEADER ==========
  md += `# ${companyName} (${ticker})\n`;
  md += `## Company Analysis Report - Institutional Grade v7.0\n\n`;
  
  // Report metadata
  const qaScore = qualityAssurance?.qualityScore?.score || qualityAssurance?.qaScore || meta?.qaScore || 85;
  const grade = qualityAssurance?.qualityScore?.grade || qualityAssurance?.grade || meta?.grade || 'B';
  const confidence = executiveSummary?.confidenceLevel?.level || executiveSummary?.confidence || meta?.confidence || 'medium';
  
  md += `**Classification:** CONFIDENTIAL | **Generated:** ${formatDate(meta?.generatedAt || new Date().toISOString())} | `;
  md += `**QA Score:** ${qaScore}/100 (${getGradeLabel(grade)}) | **Confidence:** ${getConfidenceLabel(confidence)}\n\n`;
  
  md += `---\n\n`;

  // ========== PAGE 0: COVER + ANALYST CONTEXT ==========
  md += `## Page 0: Cover + Analyst Context\n`;
  md += `*Why This Report Exists Now*\n\n`;

  const cover = sections?.cover || {};
  const analystContext = sections?.analystContext || {};
  const companySnapshot = sections?.companySnapshot || {};

  // Company Header Card
  md += `### Company Overview\n\n`;
  md += `| Attribute | Value |\n`;
  md += `|-----------|-------|\n`;
  md += `| **Company** | ${companySnapshot.name || companyName} |\n`;
  md += `| **Ticker** | ${companySnapshot.ticker || ticker} |\n`;
  md += `| **Sector** | ${companySnapshot.sector || 'N/A'} |\n`;
  md += `| **Industry** | ${companySnapshot.industry || 'N/A'} |\n`;
  md += `| **Report Date** | ${formatDate(meta?.generatedAt || new Date().toISOString())} |\n`;
  md += `| **ISM Reference Month** | ${cover.ismReferenceMonth || 'N/A'} |\n\n`;

  // One-liner
  if (cover.oneLiner || executiveSummary?.oneLiner) {
    md += `### Thesis Statement\n\n`;
    md += `> **"${cover.oneLiner || executiveSummary?.oneLiner}"**\n\n`;
  }

  // Analyst Context
  if (analystContext.whyISMMatters || analystContext.signalCaught || analystContext.whyThisCompany) {
    md += `### Analyst Context\n\n`;
    if (analystContext.whyISMMatters) {
      md += `**Why the Latest ISM Matters:** ${analystContext.whyISMMatters}\n\n`;
    }
    if (analystContext.signalCaught) {
      md += `**Signal Identified:** ${analystContext.signalCaught}\n\n`;
    }
    if (analystContext.whyThisCompany) {
      md += `**Why This Company:** ${analystContext.whyThisCompany}\n\n`;
    }
  }

  md += `---\n\n`;

  // ========== PAGE 1: ISM → MACRO → SECTOR FUNNEL ==========
  md += `## Page 1: ISM → Macro → Sector Funnel\n`;
  md += `*The Heart of the Differentiation*\n\n`;

  const ismAnalysis = sections?.ismAnalysis || {};
  const macroInterpretation = sections?.macroInterpretation || {};
  const sectorSelection = sections?.sectorSelection || {};

  // 1.1 ISM Signal Breakdown
  md += `### 1.1 ISM Signal Breakdown\n\n`;
  
  if (ismAnalysis.headline) {
    md += `**Headline PMI:** ${ismAnalysis.headline}\n\n`;
  }

  if (ismAnalysis.subComponents && Object.keys(ismAnalysis.subComponents).length > 0) {
    md += `| Component | Current | Prior | Change | 3-6M Trend |\n`;
    md += `|-----------|---------|-------|--------|------------|\n`;
    
    const components = ismAnalysis.subComponents;
    if (components.newOrders) {
      md += `| **New Orders** | ${components.newOrders.current || 'N/A'} | ${components.newOrders.prior || 'N/A'} | ${components.newOrders.change || 'N/A'} | ${components.newOrders.trend || 'N/A'} |\n`;
    }
    if (components.production) {
      md += `| **Production** | ${components.production.current || 'N/A'} | ${components.production.prior || 'N/A'} | ${components.production.change || 'N/A'} | ${components.production.trend || 'N/A'} |\n`;
    }
    if (components.employment) {
      md += `| **Employment** | ${components.employment.current || 'N/A'} | ${components.employment.prior || 'N/A'} | ${components.employment.change || 'N/A'} | ${components.employment.trend || 'N/A'} |\n`;
    }
    if (components.prices) {
      md += `| **Prices** | ${components.prices.current || 'N/A'} | ${components.prices.prior || 'N/A'} | ${components.prices.change || 'N/A'} | ${components.prices.trend || 'N/A'} |\n`;
    }
    if (components.inventories) {
      md += `| **Inventories** | ${components.inventories.current || 'N/A'} | ${components.inventories.prior || 'N/A'} | ${components.inventories.change || 'N/A'} | ${components.inventories.trend || 'N/A'} |\n`;
    }
    md += '\n';
  }

  if (ismAnalysis.keyTakeaway) {
    md += `**Key Takeaway:** ${ismAnalysis.keyTakeaway}\n\n`;
  }

  // 1.2 Macro Interpretation
  md += `### 1.2 Macro Interpretation\n\n`;
  
  if (macroInterpretation.cycleStage) {
    md += `**Economic Cycle Stage:** ${macroInterpretation.cycleStage}\n\n`;
  }
  if (macroInterpretation.regimeType) {
    md += `**Regime Type:** ${macroInterpretation.regimeType} (${macroInterpretation.isRegimeShift ? 'REGIME SHIFT' : 'Continuation'})\n\n`;
  }
  if (macroInterpretation.winners && macroInterpretation.winners.length > 0) {
    md += `**Who Benefits:** ${macroInterpretation.winners.join(', ')}\n\n`;
  }
  if (macroInterpretation.losers && macroInterpretation.losers.length > 0) {
    md += `**Who Suffers:** ${macroInterpretation.losers.join(', ')}\n\n`;
  }

  // 1.3 Sector Selection
  md += `### 1.3 Sector Selection\n\n`;
  
  if (sectorSelection.chosenSector) {
    md += `**Selected Sector:** ${sectorSelection.chosenSector}\n\n`;
  }
  if (sectorSelection.rationale) {
    md += `**Why This Sector:** ${sectorSelection.rationale}\n\n`;
  }
  if (sectorSelection.ismTransmission) {
    md += `**ISM Transmission:** ${sectorSelection.ismTransmission}\n\n`;
  }
  if (sectorSelection.alternatives && sectorSelection.alternatives.length > 0) {
    md += `**Alternative Sectors Considered:**\n`;
    sectorSelection.alternatives.forEach((alt, i) => {
      md += `${i + 1}. **${alt.sector}** - ${alt.reason || 'N/A'}\n`;
    });
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 2: WHY THIS COMPANY ==========
  md += `## Page 2: Why This Company\n`;
  md += `*From Sector to Specific Stock*\n\n`;

  const whyThisCompany = sections?.whyThisCompany || {};

  // 2.1 Company Snapshot
  md += `### 2.1 Company Snapshot\n\n`;
  
  if (whyThisCompany.whatTheyDo) {
    md += `**What They Actually Do:** ${whyThisCompany.whatTheyDo}\n\n`;
  }
  if (whyThisCompany.customers) {
    md += `**Customer Base:** ${whyThisCompany.customers}\n\n`;
  }
  if (whyThisCompany.valueChainPosition) {
    md += `**Value Chain Position:** ${whyThisCompany.valueChainPosition}\n\n`;
  }

  // 2.2 Why This Company
  md += `### 2.2 Why This Company (Not a Competitor)\n\n`;
  
  if (whyThisCompany.pureExposure) {
    md += `**Purest Macro Exposure:** ${whyThisCompany.pureExposure}\n\n`;
  }
  
  if (whyThisCompany.competitiveAdvantages) {
    md += `**Relative Advantages:**\n\n`;
    md += `| Factor | Advantage |\n`;
    md += `|--------|----------|\n`;
    const adv = whyThisCompany.competitiveAdvantages;
    if (adv.scale) md += `| **Scale** | ${adv.scale} |\n`;
    if (adv.pricingPower) md += `| **Pricing Power** | ${adv.pricingPower} |\n`;
    if (adv.timing) md += `| **Timing** | ${adv.timing} |\n`;
    if (adv.balanceSheet) md += `| **Balance Sheet** | ${adv.balanceSheet} |\n`;
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 3: BUSINESS MODEL & PRODUCTS ==========
  md += `## Page 3: Business Model & Products\n`;
  md += `*How They Make Money*\n\n`;

  const businessModel = sections?.businessModel || {};

  // 3.1 Revenue Engine
  md += `### 3.1 Revenue Engine\n\n`;
  
  if (businessModel.revenueSources && businessModel.revenueSources.length > 0) {
    md += `**Revenue Sources:**\n\n`;
    md += `| Source | % of Revenue | Description |\n`;
    md += `|--------|-------------|-------------|\n`;
    businessModel.revenueSources.forEach(src => {
      md += `| ${src.name || 'N/A'} | ${src.percentage || 'N/A'} | ${src.description || 'N/A'} |\n`;
    });
    md += '\n';
  }

  if (businessModel.growthDrivers) {
    md += `**Growth Drivers:**\n`;
    if (businessModel.growthDrivers.volume) md += `- **Volume:** ${businessModel.growthDrivers.volume}\n`;
    if (businessModel.growthDrivers.price) md += `- **Price:** ${businessModel.growthDrivers.price}\n`;
    if (businessModel.growthDrivers.mix) md += `- **Mix:** ${businessModel.growthDrivers.mix}\n`;
    md += '\n';
  }

  if (businessModel.cycleSensitivity) {
    md += `**Economic Cycle Sensitivity:** ${businessModel.cycleSensitivity}\n\n`;
  }

  // 3.2 Products / Services
  md += `### 3.2 Products / Services\n\n`;
  
  if (businessModel.products && businessModel.products.length > 0) {
    businessModel.products.forEach((prod, i) => {
      md += `**${i + 1}. ${prod.name || 'Product'}**\n`;
      if (prod.description) md += `${prod.description}\n`;
      if (prod.differentiator) md += `*Differentiator:* ${prod.differentiator}\n`;
      md += '\n';
    });
  }

  if (businessModel.externalDependencies && businessModel.externalDependencies.length > 0) {
    md += `**External Dependencies:**\n`;
    businessModel.externalDependencies.forEach(dep => {
      md += `- ${dep}\n`;
    });
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 4: COMPETITION & MOAT ANALYSIS ==========
  md += `## Page 4: Competition & Moat Analysis\n`;
  md += `*Competitive Positioning*\n\n`;

  const competition = sections?.competition || {};
  const moat = sections?.moat || {};

  // 4.1 Competitive Landscape
  md += `### 4.1 Competitive Landscape\n\n`;
  
  if (competition.directCompetitors && competition.directCompetitors.length > 0) {
    md += `**Direct Competitors:**\n\n`;
    md += `| Competitor | Market Share | Positioning |\n`;
    md += `|------------|-------------|-------------|\n`;
    competition.directCompetitors.forEach(comp => {
      md += `| ${comp.name || 'N/A'} | ${comp.marketShare || 'N/A'} | ${comp.positioning || 'N/A'} |\n`;
    });
    md += '\n';
  }

  if (competition.relativePosition) {
    md += `**Relative Position:** ${competition.relativePosition}\n\n`;
  }

  // 4.2 Moat Assessment
  md += `### 4.2 Moat Assessment\n\n`;
  
  if (moat.overallScore) {
    md += `**Overall Moat:** ${getMoatLabel(moat.overallScore)} (Score: ${moat.overallScore}/30)\n\n`;
  }

  if (moat.components) {
    md += `| Moat Component | Strength | Notes |\n`;
    md += `|----------------|----------|-------|\n`;
    const comp = moat.components;
    if (comp.costAdvantage) md += `| **Cost Advantage** | ${comp.costAdvantage.strength || 'N/A'} | ${comp.costAdvantage.notes || ''} |\n`;
    if (comp.switchingCosts) md += `| **Switching Costs** | ${comp.switchingCosts.strength || 'N/A'} | ${comp.switchingCosts.notes || ''} |\n`;
    if (comp.regulation) md += `| **Regulation** | ${comp.regulation.strength || 'N/A'} | ${comp.regulation.notes || ''} |\n`;
    if (comp.networkBrand) md += `| **Network/Brand** | ${comp.networkBrand.strength || 'N/A'} | ${comp.networkBrand.notes || ''} |\n`;
    md += '\n';
  }

  if (moat.strongAreas && moat.strongAreas.length > 0) {
    md += `**Strong Areas:** ${moat.strongAreas.join(', ')}\n\n`;
  }
  if (moat.weakAreas && moat.weakAreas.length > 0) {
    md += `**Weak/Eroding Areas:** ${moat.weakAreas.join(', ')}\n\n`;
  }

  md += `---\n\n`;

  // ========== PAGE 5: FINANCIALS THAT MATTER ==========
  md += `## Page 5: Financials That Matter\n`;
  md += `*No Noise*\n\n`;

  const financials = sections?.financials || {};

  // 5.1 Income Statement Highlights
  md += `### 5.1 Income Statement Highlights\n\n`;
  
  if (financials.incomeStatement) {
    const is = financials.incomeStatement;
    md += `| Metric | Value | Commentary |\n`;
    md += `|--------|-------|------------|\n`;
    if (is.revenue5Y) md += `| **Revenue Growth (5Y CAGR)** | ${formatPercent(is.revenue5Y)} | ${is.revenue5YNote || ''} |\n`;
    if (is.revenueTTM) md += `| **Revenue (TTM)** | ${formatNumber(is.revenueTTM)} | ${is.revenueTTMNote || ''} |\n`;
    if (is.grossMargin) md += `| **Gross Margin** | ${formatPercent(is.grossMargin)} | ${is.grossMarginNote || ''} |\n`;
    if (is.opexRatio) md += `| **OpEx Ratio** | ${formatPercent(is.opexRatio)} | ${is.opexNote || ''} |\n`;
    if (is.operatingMargin) md += `| **Operating Margin** | ${formatPercent(is.operatingMargin)} | ${is.operatingMarginNote || ''} |\n`;
    md += '\n';
  }

  if (financials.operatingLeverage) {
    md += `**Operating Leverage:** ${financials.operatingLeverage}\n\n`;
  }

  // 5.2 Cash Flow & Balance Sheet
  md += `### 5.2 Cash Flow & Balance Sheet\n\n`;
  
  if (financials.cashFlow) {
    const cf = financials.cashFlow;
    md += `| Metric | Value |\n`;
    md += `|--------|-------|\n`;
    if (cf.fcf) md += `| **Free Cash Flow (TTM)** | ${formatNumber(cf.fcf)} |\n`;
    if (cf.fcfMargin) md += `| **FCF Margin** | ${formatPercent(cf.fcfMargin)} |\n`;
    if (cf.fcfConversion) md += `| **FCF Conversion** | ${formatPercent(cf.fcfConversion)} |\n`;
    md += '\n';
  }

  if (financials.balanceSheet) {
    const bs = financials.balanceSheet;
    md += `| Metric | Value |\n`;
    md += `|--------|-------|\n`;
    if (bs.totalDebt) md += `| **Total Debt** | ${formatNumber(bs.totalDebt)} |\n`;
    if (bs.netDebt) md += `| **Net Debt** | ${formatNumber(bs.netDebt)} |\n`;
    if (bs.debtToEBITDA) md += `| **Debt/EBITDA** | ${bs.debtToEBITDA}x |\n`;
    if (bs.currentRatio) md += `| **Current Ratio** | ${bs.currentRatio}x |\n`;
    md += '\n';
  }

  if (financials.stressTest) {
    md += `**Stress Test:** ${financials.stressTest}\n\n`;
  }

  // 5.3 Earnings Quality
  md += `### 5.3 Earnings Quality\n\n`;
  
  if (financials.earningsQuality) {
    const eq = financials.earningsQuality;
    md += `| Factor | Assessment |\n`;
    md += `|--------|------------|\n`;
    if (eq.sbcImpact) md += `| **SBC Impact** | ${eq.sbcImpact} |\n`;
    if (eq.oneOffs) md += `| **One-offs** | ${eq.oneOffs} |\n`;
    if (eq.guidanceConsistency) md += `| **Guidance Consistency** | ${eq.guidanceConsistency} |\n`;
    if (eq.accrualQuality) md += `| **Accrual Quality** | ${eq.accrualQuality} |\n`;
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 6: VALUATION & MARKET EXPECTATIONS ==========
  md += `## Page 6: Valuation & Market Expectations\n`;
  md += `*What's Priced In*\n\n`;

  const valuation = sections?.valuation || {};

  // 6.1 Current Valuation
  md += `### 6.1 Current Valuation\n\n`;
  
  if (valuation.multiples) {
    md += `| Multiple | Current | Sector Avg | vs Sector |\n`;
    md += `|----------|---------|------------|----------|\n`;
    const m = valuation.multiples;
    if (m.peRatio) md += `| **P/E** | ${m.peRatio.current}x | ${m.peRatio.sectorAvg}x | ${m.peRatio.vsAvg || ''} |\n`;
    if (m.evEbitda) md += `| **EV/EBITDA** | ${m.evEbitda.current}x | ${m.evEbitda.sectorAvg}x | ${m.evEbitda.vsAvg || ''} |\n`;
    if (m.evRevenue) md += `| **EV/Revenue** | ${m.evRevenue.current}x | ${m.evRevenue.sectorAvg}x | ${m.evRevenue.vsAvg || ''} |\n`;
    if (m.fcfYield) md += `| **FCF Yield** | ${formatPercent(m.fcfYield.current)} | ${formatPercent(m.fcfYield.sectorAvg)} | ${m.fcfYield.vsAvg || ''} |\n`;
    md += '\n';
  }

  if (valuation.valuationVerdict) {
    md += `**Verdict:** ${valuation.valuationVerdict}\n\n`;
  }

  // 6.2 Expectations Gap
  md += `### 6.2 Expectations Gap\n\n`;
  
  if (valuation.expectations) {
    const exp = valuation.expectations;
    if (exp.whatMarketPrices) {
      md += `**What the Market is Pricing:** ${exp.whatMarketPrices}\n\n`;
    }
    
    md += `| Scenario | What Needs to Happen |\n`;
    md += `|----------|---------------------|\n`;
    if (exp.toJustifyPrice) md += `| **Justify Current Price** | ${exp.toJustifyPrice} |\n`;
    if (exp.forUpside) md += `| **Generate Upside** | ${exp.forUpside} |\n`;
    if (exp.forDownside) md += `| **Risk Downside** | ${exp.forDownside} |\n`;
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 7: ANALYSTS, NEWS & CATALYSTS ==========
  md += `## Page 7: Analysts, News & Catalysts\n`;
  md += `*External View + Forward Events*\n\n`;

  const analysts = sections?.analysts || {};
  const news = sections?.news || {};
  const catalysts = sections?.catalysts || {};

  // 7.1 Analyst Landscape
  md += `### 7.1 Analyst Landscape\n\n`;
  
  if (analysts.consensus) {
    md += `| Metric | Value |\n`;
    md += `|--------|-------|\n`;
    md += `| **Consensus Rating** | ${analysts.consensus.rating || 'N/A'} |\n`;
    md += `| **Buy/Hold/Sell** | ${analysts.consensus.distribution || 'N/A'} |\n`;
    md += `| **Price Target Range** | ${analysts.consensus.targetLow || 'N/A'} - ${analysts.consensus.targetHigh || 'N/A'} |\n`;
    md += `| **Mean Target** | ${analysts.consensus.targetMean || 'N/A'} |\n`;
    md += `| **Implied Upside** | ${formatPercent(analysts.consensus.impliedUpside) || 'N/A'} |\n`;
    md += '\n';
  }

  if (analysts.disagreement) {
    md += `**Key Disagreements:** ${analysts.disagreement}\n\n`;
  }

  // 7.2 Recent News & Events
  md += `### 7.2 Recent News & Events (90-180 Days)\n\n`;
  
  if (news.significant && news.significant.length > 0) {
    news.significant.forEach((item, i) => {
      md += `**${i + 1}. ${item.headline || 'News Item'}** (${item.date || 'N/A'})\n`;
      if (item.summary) md += `${item.summary}\n`;
      if (item.impact) md += `*Impact:* ${item.impact}\n`;
      md += '\n';
    });
  } else {
    md += `No significant news in the past 90-180 days.\n\n`;
  }

  // 7.3 Forward Catalysts
  md += `### 7.3 Forward Catalysts\n\n`;
  
  if (catalysts.events && catalysts.events.length > 0) {
    md += `| Catalyst | Timing | Importance | ISM Connection |\n`;
    md += `|----------|--------|------------|----------------|\n`;
    catalysts.events.forEach(cat => {
      md += `| ${cat.event || 'N/A'} | ${cat.timing || 'N/A'} | ${cat.importance || 'N/A'} | ${cat.ismConnection || 'N/A'} |\n`;
    });
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 8: RISK REGISTER ==========
  md += `## Page 8: Risk Register\n`;
  md += `*What Can Break the Thesis*\n\n`;

  const risks = sections?.risks || {};

  if (risks.register && risks.register.length > 0) {
    md += `| Risk | Category | Severity | Early Warning |\n`;
    md += `|------|----------|----------|---------------|\n`;
    risks.register.forEach(risk => {
      md += `| ${risk.risk || 'N/A'} | ${risk.category || 'N/A'} | ${getSeverityLabel(risk.severity)} | ${risk.earlyWarning || 'N/A'} |\n`;
    });
    md += '\n';
  }

  if (risks.macroRisk) {
    md += `**Macro Risk:** ${risks.macroRisk}\n\n`;
  }
  if (risks.executionRisk) {
    md += `**Execution Risk:** ${risks.executionRisk}\n\n`;
  }
  if (risks.competitionRisk) {
    md += `**Competition Risk:** ${risks.competitionRisk}\n\n`;
  }
  if (risks.balanceSheetRisk) {
    md += `**Balance Sheet Risk:** ${risks.balanceSheetRisk}\n\n`;
  }

  if (risks.earlyWarnings && risks.earlyWarnings.length > 0) {
    md += `### Early Warning Checklist\n\n`;
    risks.earlyWarnings.forEach((warning, i) => {
      md += `${i + 1}. ${warning}\n`;
    });
    md += '\n';
  }

  md += `---\n\n`;

  // ========== PAGE 9: INVESTMENT CONCLUSION ==========
  md += `## Page 9: Investment Conclusion\n`;
  md += `*Decision Page*\n\n`;

  const conclusion = sections?.conclusion || {};

  // 9.1 The Thesis
  md += `### 9.1 The Thesis\n\n`;
  
  if (conclusion.whyYes) {
    md += `**Why Yes:** ${conclusion.whyYes}\n\n`;
  }
  if (conclusion.whyNow) {
    md += `**Why Now:** ${conclusion.whyNow}\n\n`;
  }
  if (conclusion.whatMarketMisses) {
    md += `**What the Market Misses:** ${conclusion.whatMarketMisses}\n\n`;
  }

  // 9.2 Scenario Table
  md += `### 9.2 Scenario Table\n\n`;
  
  if (conclusion.scenarios) {
    md += `| Scenario | Probability | Return | What Needs to Happen |\n`;
    md += `|----------|-------------|--------|---------------------|\n`;
    const scen = conclusion.scenarios;
    if (scen.bull) {
      md += `| **Bull** | ${scen.bull.probability || 'N/A'} | ${scen.bull.return || 'N/A'} | ${scen.bull.trigger || 'N/A'} |\n`;
    }
    if (scen.base) {
      md += `| **Base** | ${scen.base.probability || 'N/A'} | ${scen.base.return || 'N/A'} | ${scen.base.trigger || 'N/A'} |\n`;
    }
    if (scen.bear) {
      md += `| **Bear** | ${scen.bear.probability || 'N/A'} | ${scen.bear.return || 'N/A'} | ${scen.bear.trigger || 'N/A'} |\n`;
    }
    md += '\n';

    if (scen.expectedValue) {
      md += `**Expected Value:** ${scen.expectedValue}\n\n`;
    }
  }

  // 9.3 Who This Is For
  md += `### 9.3 Who This Is For\n\n`;
  
  if (conclusion.investorProfile) {
    const profile = conclusion.investorProfile;
    md += `| Attribute | Description |\n`;
    md += `|-----------|-------------|\n`;
    if (profile.type) md += `| **Investor Type** | ${profile.type} |\n`;
    if (profile.patience) md += `| **Patience Required** | ${profile.patience} |\n`;
    if (profile.riskTolerance) md += `| **Risk Profile** | ${profile.riskTolerance} |\n`;
    if (profile.notFor) md += `| **NOT For** | ${profile.notFor} |\n`;
    md += '\n';
  }

  // Final Verdict
  if (conclusion.finalVerdict || executiveSummary?.oneLiner) {
    md += `### Final Verdict\n\n`;
    md += `> **${conclusion.finalVerdict || executiveSummary?.oneLiner}**\n\n`;
  }

  md += `---\n\n`;
  md += `*Report generated by Finotaur Company Analysis System v7.0 | 30 AI Agents | 10 Pages | QA Score: ${qaScore}/100*\n`;
  md += `*Generated: ${formatDate(meta?.generatedAt || new Date().toISOString())}*\n`;

  return md;
}

// ============================================
// HTML REPORT GENERATOR
// ============================================

function generateHTMLReport(report, options = {}) {
  const markdownContent = generateMarkdownReport(report);
  
  // Convert markdown to HTML
  let html = markdownContent
    // Headers
    .replace(/^#### (.*$)/gim, '<h4>$1</h4>')
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    // Bold
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    // Code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // Blockquotes
    .replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>')
    // Horizontal rules
    .replace(/^---$/gim, '<hr>')
    // Tables
    .replace(/\|([^\n]+)\|/g, (match) => {
      const cells = match.split('|').filter(c => c.trim());
      if (cells.every(c => c.trim().match(/^[-:]+$/))) return '';
      const isHeader = cells[0] && cells[0].trim().startsWith('**');
      const tag = isHeader ? 'th' : 'td';
      return '<tr>' + cells.map(c => `<${tag}>${c.trim().replace(/\*\*/g, '')}</${tag}>`).join('') + '</tr>';
    })
    // Line breaks
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>');

  // Wrap tables
  html = html.replace(/<tr>/g, '<table class="report-table"><tbody><tr>');
  html = html.replace(/<\/tr>/g, '</tr></tbody></table>');
  
  // Clean up consecutive tables
  html = html.replace(/<\/table><table class="report-table"><tbody>/g, '');
  
  const { meta } = report || {};
  const ticker = meta?.ticker || 'Report';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ticker} - Company Analysis Report v7.0</title>
  <style>
    :root {
      --bg-primary: #0f172a;
      --bg-secondary: #1e293b;
      --bg-tertiary: #334155;
      --text-primary: #f8fafc;
      --text-secondary: #cbd5e1;
      --text-muted: #94a3b8;
      --accent-blue: #3b82f6;
      --accent-green: #22c55e;
      --accent-red: #ef4444;
      --accent-yellow: #eab308;
      --border-color: #475569;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: var(--bg-primary);
      color: var(--text-primary);
      line-height: 1.6;
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }
    
    h1 {
      font-size: 2.5rem;
      margin-bottom: 0.5rem;
      color: var(--text-primary);
    }
    
    h2 {
      font-size: 1.75rem;
      margin-top: 2rem;
      margin-bottom: 1rem;
      color: var(--accent-blue);
      border-bottom: 2px solid var(--accent-blue);
      padding-bottom: 0.5rem;
    }
    
    h3 {
      font-size: 1.25rem;
      margin-top: 1.5rem;
      margin-bottom: 0.75rem;
      color: var(--text-secondary);
    }
    
    h4 {
      font-size: 1.1rem;
      margin-top: 1.25rem;
      margin-bottom: 0.5rem;
      color: var(--accent-green);
    }
    
    p {
      margin-bottom: 1rem;
      color: var(--text-secondary);
    }
    
    strong {
      color: var(--text-primary);
    }
    
    blockquote {
      background: var(--bg-secondary);
      border-left: 4px solid var(--accent-blue);
      padding: 1rem;
      margin: 1rem 0;
      color: var(--text-secondary);
      font-size: 1.1rem;
    }
    
    table.report-table {
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0;
      background: var(--bg-secondary);
      border-radius: 8px;
      overflow: hidden;
    }
    
    table.report-table th,
    table.report-table td {
      padding: 0.75rem 1rem;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
    }
    
    table.report-table th {
      background: var(--bg-tertiary);
      color: var(--text-primary);
      font-weight: 600;
    }
    
    table.report-table tr:last-child td {
      border-bottom: none;
    }
    
    table.report-table tr:hover {
      background: var(--bg-tertiary);
    }
    
    hr {
      border: none;
      border-top: 1px solid var(--border-color);
      margin: 2rem 0;
    }
    
    code {
      background: var(--bg-tertiary);
      padding: 0.2rem 0.4rem;
      border-radius: 4px;
      font-size: 0.9em;
    }
    
    em {
      color: var(--text-muted);
      font-style: italic;
    }
    
    .header-meta {
      color: var(--text-muted);
      font-size: 0.9rem;
      margin-bottom: 1.5rem;
    }
    
    .green { color: var(--accent-green); }
    .red { color: var(--accent-red); }
    .yellow { color: var(--accent-yellow); }
    
    @media print {
      body {
        background: white;
        color: black;
      }
      
      h2 {
        color: #1e40af;
      }
      
      h4 {
        color: #166534;
      }
      
      table.report-table {
        background: #f8fafc;
      }
      
      blockquote {
        background: #f1f5f9;
      }
    }
  </style>
</head>
<body>
  <article class="report">
    ${html}
  </article>
</body>
</html>`;
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  generateMarkdownReport,
  generateHTMLReport,
  // Helper functions
  formatNumber,
  formatPercent,
  getMoatLabel,
  getConfidenceLabel,
  getGradeLabel,
  getSeverityLabel,
  safeGet,
  safeArray,
  formatDate,
};