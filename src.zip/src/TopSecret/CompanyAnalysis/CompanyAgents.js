// =====================================================
// COMPANY ANALYSIS AGENTS - v7.0 ISM-DRIVEN
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/CompanyAgents.js
//
// v7.0 RESTRUCTURE - 10 PAGES (0-9):
// Page 0: Cover + Analyst Context
// Page 1: ISM → Macro → Sector Funnel
// Page 2: Why This Company
// Page 3: Business Model & Products
// Page 4: Competition & Moat Analysis
// Page 5: Financials That Matter
// Page 6: Valuation & Market Expectations
// Page 7: Analysts, News & Catalysts
// Page 8: Risk Register
// Page 9: Investment Conclusion
//
// TOTAL: 30 AGENTS
// =====================================================

const { 
  PHASES, 
  COMPANY_TYPES, 
  COMPANY_TYPE_METRICS,
  MOAT_CHECKLIST,
  TRADE_TYPES,
  CONFIDENCE_LEVELS,
  EXPOSURE_TYPES,
  DECISION_HORIZONS,
  DRIVER_HIERARCHY,
  ISM_COMPONENTS,
  MACRO_REGIMES,
  SECTOR_ISM_SENSITIVITY,
} = require('./config');

// ============================================
// AGENT DEFINITIONS - 30 AGENTS
// ============================================

const AGENT_DEFINITIONS = [
  // ========== PHASE 1: DATA ACQUISITION (8 agents) ==========
  {
    id: 'company_data_fetcher',
    name: 'Company Data Fetcher',
    description: 'Fetches basic company info, profile, and identification',
    phase: 'data_acquisition',
    order: 1,
    dependencies: [],
    estimatedSeconds: 15,
    usesAI: false,
  },
  {
    id: 'financial_data_fetcher',
    name: 'Financial Data Fetcher',
    description: 'Fetches financial statements, ratios, and historical data',
    phase: 'data_acquisition',
    order: 2,
    dependencies: ['company_data_fetcher'],
    estimatedSeconds: 20,
    usesAI: false,
  },
  {
    id: 'sec_filings_fetcher',
    name: 'SEC Filings Fetcher',
    description: 'Fetches latest 10-K, 10-Q, and 8-K filings from SEC EDGAR',
    phase: 'data_acquisition',
    order: 3,
    dependencies: ['company_data_fetcher'],
    estimatedSeconds: 25,
    usesAI: false,
  },
  {
    id: 'news_events_fetcher',
    name: 'News & Events Fetcher',
    description: 'Fetches recent news, upcoming events, and catalysts',
    phase: 'data_acquisition',
    order: 4,
    dependencies: ['company_data_fetcher'],
    estimatedSeconds: 15,
    usesAI: false,
  },
  {
    id: 'ism_data_fetcher',
    name: 'ISM Data Fetcher',
    description: 'Fetches ISM/PMI data from FRED and other sources',
    phase: 'data_acquisition',
    order: 5,
    dependencies: [],
    estimatedSeconds: 10,
    usesAI: false,
  },
  {
    id: 'analyst_data_fetcher',
    name: 'Analyst Data Fetcher',
    description: 'Fetches analyst recommendations and price targets',
    phase: 'data_acquisition',
    order: 6,
    dependencies: ['company_data_fetcher'],
    estimatedSeconds: 10,
    usesAI: false,
  },
  {
    id: 'competitors_data_fetcher',
    name: 'Competitors Data Fetcher',
    description: 'Fetches competitor company data for comparison',
    phase: 'data_acquisition',
    order: 7,
    dependencies: ['company_data_fetcher'],
    estimatedSeconds: 15,
    usesAI: false,
  },
  {
    id: 'valuation_data_fetcher',
    name: 'Valuation Data Fetcher',
    description: 'Fetches valuation multiples and historical data',
    phase: 'data_acquisition',
    order: 8,
    dependencies: ['company_data_fetcher', 'financial_data_fetcher'],
    estimatedSeconds: 10,
    usesAI: false,
  },

  // ========== PAGE 0: COVER + ANALYST CONTEXT (2 agents) ==========
  {
    id: 'cover_builder',
    name: 'Cover Builder',
    description: 'Page 0: Builds report cover with company info and thesis statement',
    phase: 'page_0_cover',
    order: 9,
    dependencies: ['company_data_fetcher', 'ism_data_fetcher'],
    estimatedSeconds: 20,
    usesAI: true,
    page: 0,
  },
  {
    id: 'analyst_context_builder',
    name: 'Analyst Context Builder',
    description: 'Page 0: Explains why ISM matters and why this company now',
    phase: 'page_0_cover',
    order: 10,
    dependencies: ['cover_builder', 'ism_data_fetcher'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 0,
  },

  // ========== PAGE 1: ISM → MACRO → SECTOR (3 agents) ==========
  {
    id: 'ism_signal_analyzer',
    name: 'ISM Signal Analyzer',
    description: 'Page 1.1: Analyzes ISM signal breakdown with sub-components',
    phase: 'page_1_ism_macro_sector',
    order: 11,
    dependencies: ['ism_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 1,
    section: '1.1',
  },
  {
    id: 'macro_interpreter',
    name: 'Macro Interpreter',
    description: 'Page 1.2: Interprets macro cycle stage and regime',
    phase: 'page_1_ism_macro_sector',
    order: 12,
    dependencies: ['ism_signal_analyzer'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 1,
    section: '1.2',
  },
  {
    id: 'sector_selector',
    name: 'Sector Selector',
    description: 'Page 1.3: Selects target sector based on ISM signals',
    phase: 'page_1_ism_macro_sector',
    order: 13,
    dependencies: ['macro_interpreter', 'company_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 1,
    section: '1.3',
  },

  // ========== PAGE 2: WHY THIS COMPANY (2 agents) ==========
  {
    id: 'company_snapshot_builder',
    name: 'Company Snapshot Builder',
    description: 'Page 2.1: Builds company snapshot with key facts',
    phase: 'page_2_why_this_company',
    order: 14,
    dependencies: ['company_data_fetcher', 'sector_selector'],
    estimatedSeconds: 20,
    usesAI: true,
    page: 2,
    section: '2.1',
  },
  {
    id: 'why_this_company_analyzer',
    name: 'Why This Company Analyzer',
    description: 'Page 2.2: Analyzes why this company vs competitors',
    phase: 'page_2_why_this_company',
    order: 15,
    dependencies: ['company_snapshot_builder', 'competitors_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 2,
    section: '2.2',
  },

  // ========== PAGE 3: BUSINESS MODEL & PRODUCTS (2 agents) ==========
  {
    id: 'revenue_engine_analyzer',
    name: 'Revenue Engine Analyzer',
    description: 'Page 3.1: Analyzes revenue model and growth drivers',
    phase: 'page_3_business_model',
    order: 16,
    dependencies: ['company_data_fetcher', 'financial_data_fetcher', 'sec_filings_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 3,
    section: '3.1',
  },
  {
    id: 'products_analyzer',
    name: 'Products Analyzer',
    description: 'Page 3.2: Analyzes main products and external dependencies',
    phase: 'page_3_business_model',
    order: 17,
    dependencies: ['revenue_engine_analyzer', 'sec_filings_fetcher'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 3,
    section: '3.2',
  },

  // ========== PAGE 4: COMPETITION & MOAT (2 agents) ==========
  {
    id: 'competitive_landscape_mapper',
    name: 'Competitive Landscape Mapper',
    description: 'Page 4.1: Maps competitive landscape and market share',
    phase: 'page_4_competition_moat',
    order: 18,
    dependencies: ['company_data_fetcher', 'competitors_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 4,
    section: '4.1',
  },
  {
    id: 'moat_assessor',
    name: 'Moat Assessor',
    description: 'Page 4.2: Assesses competitive moat and sustainability',
    phase: 'page_4_competition_moat',
    order: 19,
    dependencies: ['competitive_landscape_mapper', 'revenue_engine_analyzer'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 4,
    section: '4.2',
  },

  // ========== PAGE 5: FINANCIALS (3 agents) ==========
  {
    id: 'income_statement_analyzer',
    name: 'Income Statement Analyzer',
    description: 'Page 5.1: Analyzes revenue, margins, and operating leverage',
    phase: 'page_5_financials',
    order: 20,
    dependencies: ['financial_data_fetcher'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 5,
    section: '5.1',
  },
  {
    id: 'cashflow_balance_analyzer',
    name: 'Cash Flow & Balance Sheet Analyzer',
    description: 'Page 5.2: Analyzes FCF, debt, and liquidity',
    phase: 'page_5_financials',
    order: 21,
    dependencies: ['financial_data_fetcher'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 5,
    section: '5.2',
  },
  {
    id: 'earnings_quality_analyzer',
    name: 'Earnings Quality Analyzer',
    description: 'Page 5.3: Analyzes SBC, one-offs, and guidance consistency',
    phase: 'page_5_financials',
    order: 22,
    dependencies: ['financial_data_fetcher', 'sec_filings_fetcher'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 5,
    section: '5.3',
  },

  // ========== PAGE 6: VALUATION (2 agents) ==========
  {
    id: 'valuation_analyzer',
    name: 'Valuation Analyzer',
    description: 'Page 6.1: Analyzes current valuation multiples',
    phase: 'page_6_valuation',
    order: 23,
    dependencies: ['financial_data_fetcher', 'valuation_data_fetcher', 'competitors_data_fetcher'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 6,
    section: '6.1',
  },
  {
    id: 'expectations_gap_analyzer',
    name: 'Expectations Gap Analyzer',
    description: 'Page 6.2: Analyzes what market prices in vs reality',
    phase: 'page_6_valuation',
    order: 24,
    dependencies: ['valuation_analyzer', 'income_statement_analyzer'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 6,
    section: '6.2',
  },

  // ========== PAGE 7: ANALYSTS & CATALYSTS (2 agents) ==========
  {
    id: 'analyst_landscape_builder',
    name: 'Analyst Landscape Builder',
    description: 'Page 7.1: Builds analyst consensus and target landscape',
    phase: 'page_7_analysts_catalysts',
    order: 25,
    dependencies: ['analyst_data_fetcher'],
    estimatedSeconds: 20,
    usesAI: true,
    page: 7,
    section: '7.1',
  },
  {
    id: 'news_catalyst_builder',
    name: 'News & Catalyst Builder',
    description: 'Page 7.2-7.3: Builds recent news and forward catalysts',
    phase: 'page_7_analysts_catalysts',
    order: 26,
    dependencies: ['news_events_fetcher', 'ism_signal_analyzer'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 7,
    section: '7.2-7.3',
  },

  // ========== PAGE 8: RISK REGISTER (1 agent) ==========
  {
    id: 'risk_register_builder',
    name: 'Risk Register Builder',
    description: 'Page 8: Builds comprehensive risk register with early warnings',
    phase: 'page_8_risk_register',
    order: 27,
    dependencies: ['macro_interpreter', 'competitive_landscape_mapper', 'cashflow_balance_analyzer'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 8,
  },

  // ========== PAGE 9: INVESTMENT CONCLUSION (2 agents) ==========
  {
    id: 'thesis_builder',
    name: 'Thesis Builder',
    description: 'Page 9.1-9.2: Builds investment thesis and scenarios',
    phase: 'page_9_conclusion',
    order: 28,
    dependencies: ['ism_signal_analyzer', 'why_this_company_analyzer', 'valuation_analyzer', 'risk_register_builder'],
    estimatedSeconds: 30,
    usesAI: true,
    page: 9,
    section: '9.1-9.2',
  },
  {
    id: 'conclusion_builder',
    name: 'Conclusion Builder',
    description: 'Page 9.3: Builds final conclusion and investor profile',
    phase: 'page_9_conclusion',
    order: 29,
    dependencies: ['thesis_builder'],
    estimatedSeconds: 25,
    usesAI: true,
    page: 9,
    section: '9.3',
  },

  // ========== QUALITY ASSURANCE (1 agent) ==========
  {
    id: 'coherence_checker',
    name: 'Coherence Checker',
    description: 'QA: Validates internal consistency of entire analysis',
    phase: 'quality_assurance',
    order: 30,
    dependencies: ['conclusion_builder'],
    estimatedSeconds: 20,
    usesAI: true,
  },
];

// ============================================
// HELPER FUNCTIONS
// ============================================

function formatMarketCap(value) {
  if (!value) return 'N/A';
  if (value >= 1e12) return `$${(value / 1e12).toFixed(2)}T`;
  if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
  return `$${value.toLocaleString()}`;
}

function formatNumber(num) {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  const abs = Math.abs(num);
  if (abs >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(num / 1e6).toFixed(0)}M`;
  if (abs >= 1e3) return `$${(num / 1e3).toFixed(0)}K`;
  return `$${num.toFixed(0)}`;
}

function safeData(data, defaultValue = {}) {
  if (data && typeof data === 'object' && !Array.isArray(data)) {
    return data;
  }
  if (Array.isArray(data)) {
    return data;
  }
  return defaultValue;
}

function logAgentStart(agentId) {
  console.log(`[Agent] Starting: ${agentId}`);
}

function logAgentComplete(agentId, success, duration) {
  const status = success ? 'COMPLETE' : 'FAILED';
  console.log(`[Agent] ${status}: ${agentId} (${duration}ms)`);
}

// ============================================
// AGENT EXECUTORS - DATA ACQUISITION
// ============================================

async function executeCompanyDataFetcher(context) {
  const startTime = Date.now();
  logAgentStart('company_data_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchCompanyData(ticker);
    
    logAgentComplete('company_data_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('company_data_fetcher', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeFinancialDataFetcher(context) {
  const startTime = Date.now();
  logAgentStart('financial_data_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchFinancialData(ticker);
    
    logAgentComplete('financial_data_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('financial_data_fetcher', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeSECFilingsFetcher(context) {
  const startTime = Date.now();
  logAgentStart('sec_filings_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchSECFilings(ticker);
    
    logAgentComplete('sec_filings_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('sec_filings_fetcher', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeNewsEventsFetcher(context) {
  const startTime = Date.now();
  logAgentStart('news_events_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchNewsAndEvents(ticker);
    
    logAgentComplete('news_events_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('news_events_fetcher', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeISMDataFetcher(context) {
  const startTime = Date.now();
  logAgentStart('ism_data_fetcher');
  
  try {
    const { dataService, ticker } = context;
    const data = await dataService.fetchFullISMContext(ticker);
    
    logAgentComplete('ism_data_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('ism_data_fetcher', false, Date.now() - startTime);
    // Return mock ISM data if fetch fails
    const mockISMData = {
      fredData: {
        manufacturing: { headline: 50.9, newOrders: 52.3, production: 51.2 },
        services: { headline: 53.4, businessActivity: 54.1 },
      },
      reportMonth: new Date().toISOString().slice(0, 7),
    };
    return { success: true, data: mockISMData, duration: Date.now() - startTime };
  }
}

async function executeAnalystDataFetcher(context) {
  const startTime = Date.now();
  logAgentStart('analyst_data_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchAnalystRecommendations(ticker);
    
    logAgentComplete('analyst_data_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('analyst_data_fetcher', false, Date.now() - startTime);
    return { success: true, data: { consensusRating: 'N/A', numberOfAnalysts: 0 }, duration: Date.now() - startTime };
  }
}

async function executeCompetitorsDataFetcher(context) {
  const startTime = Date.now();
  logAgentStart('competitors_data_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchCompetitors(ticker);
    
    logAgentComplete('competitors_data_fetcher', true, Date.now() - startTime);
    return { success: true, data, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('competitors_data_fetcher', false, Date.now() - startTime);
    return { success: true, data: { competitors: [] }, duration: Date.now() - startTime };
  }
}

async function executeValuationDataFetcher(context) {
  const startTime = Date.now();
  logAgentStart('valuation_data_fetcher');
  
  try {
    const { ticker, dataService } = context;
    const data = await dataService.fetchValuationData(ticker);
    
    // Ensure returnMetrics exists even if API didn't return it
    const enrichedData = {
      ...data,
      returnMetrics: data.returnMetrics || {
        roe: '-',
        roa: '-',
        roic: '-',
      },
    };
    
    logAgentComplete('valuation_data_fetcher', true, Date.now() - startTime);
    return { success: true, data: enrichedData, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('valuation_data_fetcher', false, Date.now() - startTime);
    return { 
      success: true, 
      data: {
        returnMetrics: { roe: '-', roa: '-', roic: '-' },
        multiples: {},
      }, 
      duration: Date.now() - startTime 
    };
  }
}

// ============================================
// PAGE 0: COVER + ANALYST CONTEXT
// ============================================

async function executeCoverBuilder(context) {
  const startTime = Date.now();
  logAgentStart('cover_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const ismData = context.results.ism_data_fetcher?.data || {};
    
    const result = await aiService.buildCover({ companyData, ismData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('cover_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('cover_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeAnalystContextBuilder(context) {
  const startTime = Date.now();
  logAgentStart('analyst_context_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const ismData = context.results.ism_data_fetcher?.data || {};
    const cover = context.results.cover_builder?.data || {};
    
    const result = await aiService.buildAnalystContext({ companyData, ismData, cover });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('analyst_context_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('analyst_context_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 1: ISM → MACRO → SECTOR
// ============================================

async function executeISMSignalAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('ism_signal_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const ismData = context.results.ism_data_fetcher?.data || {};
    
    const result = await aiService.analyzeISMSignal({ ismData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('ism_signal_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('ism_signal_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeMacroInterpreter(context) {
  const startTime = Date.now();
  logAgentStart('macro_interpreter');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const ismData = context.results.ism_data_fetcher?.data || {};
    const ismAnalysis = context.results.ism_signal_analyzer?.data || {};
    
    const result = await aiService.interpretMacro({ ismData, ismAnalysis });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('macro_interpreter', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('macro_interpreter', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeSectorSelector(context) {
  const startTime = Date.now();
  logAgentStart('sector_selector');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const macroInterpretation = context.results.macro_interpreter?.data || {};
    
    const result = await aiService.selectSector({ companyData, macroInterpretation });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('sector_selector', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('sector_selector', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 2: WHY THIS COMPANY
// ============================================

async function executeCompanySnapshotBuilder(context) {
  const startTime = Date.now();
  logAgentStart('company_snapshot_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const sectorSelection = context.results.sector_selector?.data || {};
    
    const result = await aiService.buildCompanySnapshot({ companyData, sectorSelection });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('company_snapshot_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('company_snapshot_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeWhyThisCompanyAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('why_this_company_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const companySnapshot = context.results.company_snapshot_builder?.data || {};
    const competitorsData = context.results.competitors_data_fetcher?.data || {};
    
    const result = await aiService.analyzeWhyThisCompany({ companyData, companySnapshot, competitorsData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('why_this_company_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('why_this_company_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 3: BUSINESS MODEL & PRODUCTS
// ============================================

async function executeRevenueEngineAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('revenue_engine_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const financialData = context.results.financial_data_fetcher?.data || {};
    const secFilings = context.results.sec_filings_fetcher?.data || {};
    
    const result = await aiService.analyzeRevenueEngine({ companyData, financialData, secFilings });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('revenue_engine_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('revenue_engine_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeProductsAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('products_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const revenueEngine = context.results.revenue_engine_analyzer?.data || {};
    const secFilings = context.results.sec_filings_fetcher?.data || {};
    
    const result = await aiService.analyzeProducts({ companyData, revenueEngine, secFilings });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('products_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('products_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 4: COMPETITION & MOAT
// ============================================

async function executeCompetitiveLandscapeMapper(context) {
  const startTime = Date.now();
  logAgentStart('competitive_landscape_mapper');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const competitorsData = context.results.competitors_data_fetcher?.data || {};
    
    const result = await aiService.mapCompetitiveLandscape({ companyData, competitorsData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('competitive_landscape_mapper', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('competitive_landscape_mapper', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeMoatAssessor(context) {
  const startTime = Date.now();
  logAgentStart('moat_assessor');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const companyData = context.results.company_data_fetcher?.data || {};
    const competitiveLandscape = context.results.competitive_landscape_mapper?.data || {};
    const revenueEngine = context.results.revenue_engine_analyzer?.data || {};
    
    const result = await aiService.assessMoat({ companyData, competitiveLandscape, revenueEngine });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('moat_assessor', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('moat_assessor', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 5: FINANCIALS
// ============================================

async function executeIncomeStatementAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('income_statement_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const financialData = context.results.financial_data_fetcher?.data || {};
    
    const result = await aiService.analyzeIncomeStatement({ financialData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('income_statement_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('income_statement_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeCashflowBalanceAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('cashflow_balance_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const financialData = context.results.financial_data_fetcher?.data || {};
    
    const result = await aiService.analyzeCashflowBalance({ financialData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('cashflow_balance_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('cashflow_balance_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeEarningsQualityAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('earnings_quality_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const financialData = context.results.financial_data_fetcher?.data || {};
    const secFilings = context.results.sec_filings_fetcher?.data || {};
    
    const result = await aiService.analyzeEarningsQuality({ financialData, secFilings });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('earnings_quality_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('earnings_quality_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 6: VALUATION
// ============================================

async function executeValuationAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('valuation_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const financialData = context.results.financial_data_fetcher?.data || {};
    const valuationData = context.results.valuation_data_fetcher?.data || {};
    const competitorsData = context.results.competitors_data_fetcher?.data || {};
    
    const result = await aiService.analyzeValuation({ financialData, valuationData, competitorsData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    // Merge returnMetrics from valuationData into result
    const enrichedData = {
      ...result.data,
      returnMetrics: valuationData.returnMetrics || {
        roe: '-',
        roa: '-',
        roic: '-',
      },
      // Also pass through the raw multiples for scales
      multiples: {
        ...result.data?.multiples,
        pe: valuationData.multiples?.pe || result.data?.multiples?.pe || '-',
        evEbitda: valuationData.multiples?.evEbitda || result.data?.multiples?.evEbitda || '-',
        evRevenue: valuationData.multiples?.evRevenue || result.data?.multiples?.evRevenue || '-',
        fcfYield: valuationData.multiples?.fcfYield || result.data?.multiples?.fcfYield || '-',
      },
    };
    
    logAgentComplete('valuation_analyzer', true, Date.now() - startTime);
    return { success: true, data: enrichedData, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('valuation_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeExpectationsGapAnalyzer(context) {
  const startTime = Date.now();
  logAgentStart('expectations_gap_analyzer');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const valuation = context.results.valuation_analyzer?.data || {};
    const incomeStatement = context.results.income_statement_analyzer?.data || {};
    
    const result = await aiService.analyzeExpectationsGap({ valuation, incomeStatement });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('expectations_gap_analyzer', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('expectations_gap_analyzer', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 7: ANALYSTS & CATALYSTS
// ============================================

async function executeAnalystLandscapeBuilder(context) {
  const startTime = Date.now();
  logAgentStart('analyst_landscape_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const analystData = context.results.analyst_data_fetcher?.data || {};
    
    const result = await aiService.buildAnalystLandscape({ analystData });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('analyst_landscape_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('analyst_landscape_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeNewsCatalystBuilder(context) {
  const startTime = Date.now();
  logAgentStart('news_catalyst_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const newsData = context.results.news_events_fetcher?.data || {};
    const ismAnalysis = context.results.ism_signal_analyzer?.data || {};
    
    const result = await aiService.buildNewsCatalysts({ newsData, ismAnalysis });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('news_catalyst_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('news_catalyst_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 8: RISK REGISTER
// ============================================

async function executeRiskRegisterBuilder(context) {
  const startTime = Date.now();
  logAgentStart('risk_register_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const macroInterpretation = context.results.macro_interpreter?.data || {};
    const competitiveLandscape = context.results.competitive_landscape_mapper?.data || {};
    const cashflowBalance = context.results.cashflow_balance_analyzer?.data || {};
    
    const result = await aiService.buildRiskRegister({ macroInterpretation, competitiveLandscape, cashflowBalance });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('risk_register_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('risk_register_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// PAGE 9: INVESTMENT CONCLUSION
// ============================================

async function executeThesisBuilder(context) {
  const startTime = Date.now();
  logAgentStart('thesis_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const ismAnalysis = context.results.ism_signal_analyzer?.data || {};
    const whyThisCompany = context.results.why_this_company_analyzer?.data || {};
    const valuation = context.results.valuation_analyzer?.data || {};
    const riskRegister = context.results.risk_register_builder?.data || {};
    
    const result = await aiService.buildThesis({ ismAnalysis, whyThisCompany, valuation, riskRegister });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('thesis_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('thesis_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeConclusionBuilder(context) {
  const startTime = Date.now();
  logAgentStart('conclusion_builder');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const thesis = context.results.thesis_builder?.data || {};
    
    const result = await aiService.buildConclusion({ thesis });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('conclusion_builder', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('conclusion_builder', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// QUALITY ASSURANCE
// ============================================

async function executeCoherenceChecker(context) {
  const startTime = Date.now();
  logAgentStart('coherence_checker');
  
  try {
    const { aiService } = context;
    if (!aiService) throw new Error('AI service not available');
    
    const thesis = context.results.thesis_builder?.data || {};
    const conclusion = context.results.conclusion_builder?.data || {};
    const riskRegister = context.results.risk_register_builder?.data || {};
    
    const result = await aiService.checkCoherence({ thesis, conclusion, riskRegister });
    if (!result.success) throw new Error(result.error || 'AI analysis failed');
    
    logAgentComplete('coherence_checker', true, Date.now() - startTime);
    return { success: true, data: result.data, aiTokens: result.usage?.total_tokens, duration: Date.now() - startTime };
  } catch (error) {
    logAgentComplete('coherence_checker', false, Date.now() - startTime);
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT EXECUTOR MAP - 30 AGENTS
// ============================================

const AGENT_EXECUTORS = {
  // Phase 1: Data Acquisition (8)
  company_data_fetcher: executeCompanyDataFetcher,
  financial_data_fetcher: executeFinancialDataFetcher,
  sec_filings_fetcher: executeSECFilingsFetcher,
  news_events_fetcher: executeNewsEventsFetcher,
  ism_data_fetcher: executeISMDataFetcher,
  analyst_data_fetcher: executeAnalystDataFetcher,
  competitors_data_fetcher: executeCompetitorsDataFetcher,
  valuation_data_fetcher: executeValuationDataFetcher,
  
  // Page 0: Cover + Analyst Context (2)
  cover_builder: executeCoverBuilder,
  analyst_context_builder: executeAnalystContextBuilder,
  
  // Page 1: ISM → Macro → Sector (3)
  ism_signal_analyzer: executeISMSignalAnalyzer,
  macro_interpreter: executeMacroInterpreter,
  sector_selector: executeSectorSelector,
  
  // Page 2: Why This Company (2)
  company_snapshot_builder: executeCompanySnapshotBuilder,
  why_this_company_analyzer: executeWhyThisCompanyAnalyzer,
  
  // Page 3: Business Model & Products (2)
  revenue_engine_analyzer: executeRevenueEngineAnalyzer,
  products_analyzer: executeProductsAnalyzer,
  
  // Page 4: Competition & Moat (2)
  competitive_landscape_mapper: executeCompetitiveLandscapeMapper,
  moat_assessor: executeMoatAssessor,
  
  // Page 5: Financials (3)
  income_statement_analyzer: executeIncomeStatementAnalyzer,
  cashflow_balance_analyzer: executeCashflowBalanceAnalyzer,
  earnings_quality_analyzer: executeEarningsQualityAnalyzer,
  
  // Page 6: Valuation (2)
  valuation_analyzer: executeValuationAnalyzer,
  expectations_gap_analyzer: executeExpectationsGapAnalyzer,
  
  // Page 7: Analysts & Catalysts (2)
  analyst_landscape_builder: executeAnalystLandscapeBuilder,
  news_catalyst_builder: executeNewsCatalystBuilder,
  
  // Page 8: Risk Register (1)
  risk_register_builder: executeRiskRegisterBuilder,
  
  // Page 9: Investment Conclusion (2)
  thesis_builder: executeThesisBuilder,
  conclusion_builder: executeConclusionBuilder,
  
  // QA (1)
  coherence_checker: executeCoherenceChecker,
};

const ALL_AGENTS = AGENT_DEFINITIONS;

// ============================================
// EXPORTS
// ============================================

module.exports = {
  AGENT_DEFINITIONS,
  AGENT_EXECUTORS,
  ALL_AGENTS,
  // Helper functions
  formatMarketCap,
  formatNumber,
  safeData,
};