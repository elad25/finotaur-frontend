// =====================================================
// COMPANY ANALYSIS ORCHESTRATOR - v7.3 ISM TOGGLE
// =====================================================
// CRITICAL FIXES APPLIED:
// 1. Enhanced ISM data from FRED with real values
// 2. Direct data injection when AI returns placeholders
// 3. Analyst price targets estimation  
// 4. Comprehensive financial data population
// 5. ISM Toggle support (includeIsm option)
// =====================================================

const { AGENT_DEFINITIONS, AGENT_EXECUTORS } = require('./CompanyAgents');
const { CompanyDataService } = require('./data-service');
const { CompanyAIService } = require('./ai-service');

// ============================================
// PHASE DEFINITIONS - v7.2
// ============================================

const PHASES = {
  DATA_ACQUISITION: 'data_acquisition',
  PAGE_0_COVER: 'page_0_cover',
  PAGE_1_ISM_MACRO_SECTOR: 'page_1_ism_macro_sector',
  PAGE_2_WHY_THIS_COMPANY: 'page_2_why_this_company',
  PAGE_3_BUSINESS_MODEL: 'page_3_business_model',
  PAGE_4_COMPETITION_MOAT: 'page_4_competition_moat',
  PAGE_5_FINANCIALS: 'page_5_financials',
  PAGE_6_VALUATION: 'page_6_valuation',
  PAGE_7_ANALYSTS_CATALYSTS: 'page_7_analysts_catalysts',
  PAGE_8_RISK_REGISTER: 'page_8_risk_register',
  PAGE_9_CONCLUSION: 'page_9_conclusion',
  QUALITY_ASSURANCE: 'quality_assurance',
};

const PHASE_ORDER = [
  PHASES.DATA_ACQUISITION,
  PHASES.PAGE_0_COVER,
  PHASES.PAGE_1_ISM_MACRO_SECTOR,
  PHASES.PAGE_2_WHY_THIS_COMPANY,
  PHASES.PAGE_3_BUSINESS_MODEL,
  PHASES.PAGE_4_COMPETITION_MOAT,
  PHASES.PAGE_5_FINANCIALS,
  PHASES.PAGE_6_VALUATION,
  PHASES.PAGE_7_ANALYSTS_CATALYSTS,
  PHASES.PAGE_8_RISK_REGISTER,
  PHASES.PAGE_9_CONCLUSION,
  PHASES.QUALITY_ASSURANCE,
];

const PHASE_AGENTS = {
  [PHASES.DATA_ACQUISITION]: [
    'company_data_fetcher',
    'financial_data_fetcher',
    'sec_filings_fetcher',
    'news_events_fetcher',
    'ism_data_fetcher',
    'analyst_data_fetcher',
    'competitors_data_fetcher',
    'valuation_data_fetcher',
  ],
  [PHASES.PAGE_0_COVER]: ['cover_builder', 'analyst_context_builder'],
  [PHASES.PAGE_1_ISM_MACRO_SECTOR]: ['ism_signal_analyzer', 'macro_interpreter', 'sector_selector'],
  [PHASES.PAGE_2_WHY_THIS_COMPANY]: ['company_snapshot_builder', 'why_this_company_analyzer'],
  [PHASES.PAGE_3_BUSINESS_MODEL]: ['revenue_engine_analyzer', 'products_analyzer'],
  [PHASES.PAGE_4_COMPETITION_MOAT]: ['competitive_landscape_mapper', 'moat_assessor'],
  [PHASES.PAGE_5_FINANCIALS]: ['income_statement_analyzer', 'cashflow_balance_analyzer', 'earnings_quality_analyzer'],
  [PHASES.PAGE_6_VALUATION]: ['valuation_analyzer', 'expectations_gap_analyzer'],
  [PHASES.PAGE_7_ANALYSTS_CATALYSTS]: ['analyst_landscape_builder', 'news_catalyst_builder'],
  [PHASES.PAGE_8_RISK_REGISTER]: ['risk_register_builder'],
  [PHASES.PAGE_9_CONCLUSION]: ['thesis_builder', 'conclusion_builder'],
  [PHASES.QUALITY_ASSURANCE]: ['coherence_checker'],
};

// ============================================
// HELPER FUNCTIONS - v7.2 ENHANCED
// ============================================

function isEmpty(val) {
  return val === null || val === undefined || val === '' || val === 'N/A';
}

function isPlaceholder(val) {
  if (val === null || val === undefined) return true;
  if (typeof val === 'string') {
    const lower = val.toLowerCase();
    return val === '' || 
           val === 'N/A' || 
           val === 'n/a' ||
           lower.includes('[data required]') ||
           lower.includes('[est]') ||
           lower.includes('data required');
  }
  return false;
}

function formatMarketCap(num) {
  if (!num || isNaN(num)) return null;
  const absNum = Math.abs(num);
  if (absNum >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (absNum >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (absNum >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
  return `$${num.toLocaleString()}`;
}

function formatNumber(num) {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  const abs = Math.abs(num);
  if (abs >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(num / 1e6).toFixed(0)}M`;
  if (abs >= 1e3) return `$${(num / 1e3).toFixed(0)}K`;
  return `$${num.toFixed(0)}`;
}

function formatPercent(val) {
  if (val === null || val === undefined || isNaN(val)) return 'N/A';
  return `${Number(val).toFixed(1)}%`;
}

function formatPrice(val) {
  if (val === null || val === undefined || isNaN(val)) return 'N/A';
  return `$${Number(val).toFixed(2)}`;
}

function formatMultiple(val) {
  if (val === null || val === undefined || isNaN(val)) return 'N/A';
  return `${Number(val).toFixed(1)}x`;
}

function safeGet(obj, path, defaultVal = null) {
  try {
    const result = path.split('.').reduce((o, k) => (o || {})[k], obj);
    return result !== undefined && result !== null ? result : defaultVal;
  } catch {
    return defaultVal;
  }
}

function firstValue(...values) {
  for (const val of values) {
    if (!isPlaceholder(val)) return val;
  }
  return 'N/A';
}

// ============================================
// WORKFLOW MANAGER
// ============================================

const workflowManager = {
  activeJobs: new Map(),
  
  startJob(ticker) {
    const jobId = `company_${ticker}_${Date.now()}`;
    this.activeJobs.set(ticker, {
      jobId,
      ticker,
      status: 'running',
      startTime: Date.now(),
      progress: 0,
      currentAgent: null,
    });
    return jobId;
  },
  
  updateJob(ticker, updates) {
    const job = this.activeJobs.get(ticker);
    if (job) {
      Object.assign(job, updates);
    }
  },
  
  completeJob(ticker, success, report = null) {
    const job = this.activeJobs.get(ticker);
    if (job) {
      job.status = success ? 'completed' : 'failed';
      job.endTime = Date.now();
      job.report = report;
    }
  },
  
  getJob(ticker) {
    return this.activeJobs.get(ticker);
  },
  
  removeJob(ticker) {
    this.activeJobs.delete(ticker);
  },
};

// ============================================
// ORCHESTRATOR CLASS - v7.2 FIXED
// ============================================

class CompanyAnalysisOrchestrator {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    
    this.dataService = new CompanyDataService(supabase, {
      polygonApiKey: options.polygonApiKey,
      fredApiKey: options.fredApiKey,
      eodhApiKey: options.eodhApiKey,
      newsApiKey: options.newsApiKey,
    });
    
    this.aiService = new CompanyAIService({
      apiKey: options.openaiApiKey,
      model: options.openaiModel || 'gpt-4-turbo',
    });
    
    this.options = options;
    this.onProgress = options.onProgress || (() => {});
    this.onAgentComplete = options.onAgentComplete || (() => {});
    this.debug = options.debug || false;
    
    console.log('[Orchestrator v7.3] Initialized with enhanced data injection');
  }

  // ============================================
  // MAIN GENERATE METHOD
  // ============================================

  async generate(ticker, opts = {}) {
    const upperTicker = ticker.toUpperCase();
    // ISM Toggle - default to true for backward compatibility
    const includeIsm = opts.includeIsm !== false;
    
    console.log(`\n[Orchestrator v7.3] Starting generation for ${upperTicker}`);
    console.log(`[Orchestrator v7.3] Include ISM: ${includeIsm}`);
    const startTime = Date.now();
    
    const jobId = workflowManager.startJob(upperTicker);

    const context = {
      ticker: upperTicker,
      dataService: this.dataService,
      aiService: this.aiService,
      results: {},
      errors: [],
      startTime,
      jobId,
      includeIsm, // Pass to context for agents that need it
    };

    // Store for raw data collection
    const rawData = {
      companyData: null,
      financialData: null,
      ismData: null,
      analystData: null,
      competitorsData: null,
      valuationData: null,
      newsData: null,
    };

    try {
      // Execute phases in order
      // ISM agents to skip when includeIsm is false
      const ismAgents = ['ism_data_fetcher', 'ism_signal_analyzer', 'macro_interpreter', 'sector_selector'];
      const ismPhases = [PHASES.PAGE_1_ISM_MACRO_SECTOR];
      
      // Calculate total agents (adjusted if ISM excluded)
      const totalAgents = includeIsm ? 30 : 30 - ismAgents.length;
      let completedAgents = 0;
      
      for (const phase of PHASE_ORDER) {
        // Skip entire ISM phase if not including ISM
        if (!includeIsm && ismPhases.includes(phase)) {
          console.log(`\n[Phase] Skipping ISM phase: ${phase} (ISM disabled)`);
          continue;
        }
        
        console.log(`\n[Phase] Starting: ${phase}`);
        const agents = PHASE_AGENTS[phase] || [];
        
        for (const agentId of agents) {
          // Skip ISM-related agents if not including ISM
          if (!includeIsm && ismAgents.includes(agentId)) {
            console.log(`[Agent] Skipping: ${agentId} (ISM disabled)`);
            continue;
          }
          
          workflowManager.updateJob(upperTicker, {
            currentAgent: agentId,
            progress: Math.round((completedAgents / totalAgents) * 100),
          });
          
          await this.executeAgent(agentId, context);
          completedAgents++;
          
          // Collect raw data from data fetchers
          if (agentId === 'company_data_fetcher') {
            rawData.companyData = context.results[agentId]?.data;
          } else if (agentId === 'financial_data_fetcher') {
            rawData.financialData = context.results[agentId]?.data;
} else if (agentId === 'ism_data_fetcher') {
            rawData.ismData = context.results[agentId]?.data;
            // ISM data already has fallbacks in data-service.fetchISMData()
            // If still empty, fetch directly
            if (!rawData.ismData || !rawData.ismData.manufacturing) {
              console.log('[Orchestrator] ISM data empty, fetching directly...');
              rawData.ismData = await this.dataService.fetchISMData();
              context.results[agentId].data = rawData.ismData;
            }
          } else if (agentId === 'analyst_data_fetcher') {
            rawData.analystData = context.results[agentId]?.data;
            // Enhance analyst data using data-service's built-in function
            if (!rawData.analystData?.priceTarget?.median) {
              console.log('[Orchestrator] Analyst data incomplete, fetching with estimates...');
              const enhanced = await this.dataService.fetchAnalystRecommendations(upperTicker);
              rawData.analystData = { ...rawData.analystData, ...enhanced };
              context.results[agentId].data = rawData.analystData;
            }
          } else if (agentId === 'competitors_data_fetcher') {
            rawData.competitorsData = context.results[agentId]?.data;
} else if (agentId === 'valuation_data_fetcher') {
            rawData.valuationData = context.results[agentId]?.data;
            // Ensure valuation multiples are populated
            if (!rawData.valuationData?.multiples?.evEbitda) {
              console.log('[Orchestrator] Valuation data incomplete, fetching directly...');
              const enhanced = await this.dataService.fetchValuationData(upperTicker);
              rawData.valuationData = { ...rawData.valuationData, ...enhanced };
              context.results[agentId].data = rawData.valuationData;
            }
          } else if (agentId === 'news_events_fetcher') {
            rawData.newsData = context.results[agentId]?.data;
          }
        }
      }
// Build final report with data injection
      const report = this.buildReport(upperTicker, context.results, rawData, includeIsm);
      
      this.debugReport(report);
      
      const duration = Date.now() - startTime;
      console.log(`\n[Orchestrator v7.3] Generation complete in ${(duration / 1000).toFixed(1)}s`);
      
      workflowManager.completeJob(upperTicker, true, report);

      return {
        success: true,
        report,
        duration,
        errors: context.errors,
        jobId,
      };

    } catch (error) {
      console.error(`[Orchestrator v7.3] Fatal error: ${error.message}`);
      workflowManager.completeJob(upperTicker, false);
      
      return {
        success: false,
        error: error.message,
        duration: Date.now() - startTime,
        errors: context.errors,
        jobId,
      };
    }
  }

  async analyze(ticker, opts = {}) {
    return this.generate(ticker, opts);
  }

  // ============================================
  // DEBUG HELPER
  // ============================================

  debugReport(report) {
    console.log(`\n[Orchestrator v7.3] ===== REPORT DEBUG =====`);
    console.log(`[DEBUG] ticker: ${report.ticker}`);
    console.log(`[DEBUG] company_name: ${report.company_name}`);
    console.log(`[DEBUG] sector: ${report.sector}`);
    console.log(`[DEBUG] market_cap: ${report.market_cap}`);
    
    if (report.sections) {
      const s = report.sections;
      console.log(`[DEBUG] cover.companyName: ${s.cover?.companyName}`);
      console.log(`[DEBUG] companySnapshot.marketCap: ${s.companySnapshot?.marketCap}`);
      console.log(`[DEBUG] ismAnalysis.headline: ${s.ismAnalysis?.headline}`);
      console.log(`[DEBUG] ismAnalysis.newOrders: ${JSON.stringify(s.ismAnalysis?.subComponents?.newOrders)}`);
      console.log(`[DEBUG] incomeStatement.revenue.ttm: ${s.incomeStatement?.revenue?.ttm}`);
      console.log(`[DEBUG] incomeStatement.margins.gross: ${s.incomeStatement?.margins?.gross}`);
      console.log(`[DEBUG] valuation.currentPrice: ${s.valuation?.currentPrice}`);
      console.log(`[DEBUG] valuation.multiples.pe: ${s.valuation?.multiples?.pe}`);
      console.log(`[DEBUG] analystLandscape.consensus: ${s.analystLandscape?.consensus}`);
      console.log(`[DEBUG] analystLandscape.targetMedian: ${s.analystLandscape?.targetMedian}`);
    }
    console.log(`[Orchestrator v7.3] ===== END DEBUG =====\n`);
  }

  // ============================================
  // STATUS & CONTROL METHODS
  // ============================================

  getStatus(ticker) {
    const job = workflowManager.getJob(ticker.toUpperCase());
    if (!job) {
      return { status: 'idle', ticker: ticker.toUpperCase() };
    }
    return {
      status: job.status,
      ticker: job.ticker,
      jobId: job.jobId,
      progress: job.progress || 0,
      currentAgent: job.currentAgent,
      startTime: job.startTime,
      endTime: job.endTime,
      duration: job.endTime ? job.endTime - job.startTime : Date.now() - job.startTime,
    };
  }

  canGenerate(ticker) {
    const job = workflowManager.getJob(ticker.toUpperCase());
    return !job || job.status === 'completed' || job.status === 'failed';
  }

  // ============================================
  // AGENT EXECUTION
  // ============================================

  async executeAgent(agentId, context) {
    try {
      const executor = AGENT_EXECUTORS[agentId];
      if (!executor) {
        console.warn(`[Agent] No executor for: ${agentId}`);
        return;
      }

      console.log(`  [Agent] Running: ${agentId}`);
      const result = await executor(context);
      context.results[agentId] = result;

      if (result.success) {
        console.log(`  [Agent] ${agentId} completed successfully`);
      } else {
        console.warn(`  [Agent] ${agentId} failed: ${result.error}`);
        context.errors.push({ agent: agentId, error: result.error });
      }

      this.onAgentComplete(agentId, result);

    } catch (error) {
      console.error(`  [Agent] ${agentId} threw error: ${error.message}`);
      context.results[agentId] = { success: false, error: error.message };
      context.errors.push({ agent: agentId, error: error.message });
    }
  }

  // ============================================
  // BUILD REPORT - v7.2 WITH DATA INJECTION
  // ============================================

  buildReport(ticker, results, rawData = {}, includeIsm = true) {
    console.log(`[Orchestrator v7.3] Building report with enhanced data injection...`);
    console.log(`[Orchestrator v7.3] Include ISM in report: ${includeIsm}`);

    // Extract raw data
    const companyData = rawData.companyData || results.company_data_fetcher?.data || {};
    const financialData = rawData.financialData || results.financial_data_fetcher?.data || {};
    const ismData = includeIsm ? (rawData.ismData || results.ism_data_fetcher?.data || {}) : {};
    const analystData = rawData.analystData || results.analyst_data_fetcher?.data || {};
    const competitorsData = rawData.competitorsData || results.competitors_data_fetcher?.data || {};
    const valuationData = rawData.valuationData || results.valuation_data_fetcher?.data || {};
    const newsData = rawData.newsData || results.news_events_fetcher?.data || {};

    // Extract AI analysis results
    const cover = results.cover_builder?.data || {};
    const analystContext = results.analyst_context_builder?.data || {};
    const ismAnalysis = includeIsm ? (results.ism_signal_analyzer?.data || {}) : {};
    const macroInterpretation = includeIsm ? (results.macro_interpreter?.data || {}) : {};
    const sectorSelection = includeIsm ? (results.sector_selector?.data || {}) : {};
    const companySnapshot = results.company_snapshot_builder?.data || {};
    const whyThisCompany = results.why_this_company_analyzer?.data || {};
    const revenueEngine = results.revenue_engine_analyzer?.data || {};
    const products = results.products_analyzer?.data || {};
    const competitiveLandscape = results.competitive_landscape_mapper?.data || {};
    const moatAssessment = results.moat_assessor?.data || {};
    const incomeStatement = results.income_statement_analyzer?.data || {};
    const cashflowBalance = results.cashflow_balance_analyzer?.data || {};
    const earningsQuality = results.earnings_quality_analyzer?.data || {};
    const valuation = results.valuation_analyzer?.data || {};
    const expectationsGap = results.expectations_gap_analyzer?.data || {};
    const analystLandscape = results.analyst_landscape_builder?.data || {};
    const newsCatalysts = results.news_catalyst_builder?.data || {};
    const riskRegister = results.risk_register_builder?.data || {};
    const thesis = results.thesis_builder?.data || {};
    const conclusion = results.conclusion_builder?.data || {};
    const coherence = results.coherence_checker?.data || {};

    // Extract key company values
    const companyName = companyData.name || companyData.entityName || ticker;
    const sector = companyData.sector || 'Technology';
    const industry = companyData.industry || companyData.sicDescription || sector;
    const exchange = companyData.exchange || 'NYSE';
    const marketCap = companyData.marketCap || valuationData.marketCap;
    const marketCapFormatted = formatMarketCap(marketCap);
    const employees = companyData.employees || companyData.totalEmployees;
    const employeesFormatted = employees ? employees.toLocaleString() : 'N/A';
    const description = companyData.description || '';

    // Extract financial data
    const derived = financialData?.derived || {};
    const ratios = financialData?.ratios || {};
    const summary = financialData?.summary || {};
    const multiples = valuationData?.multiples || {};

    // Key financial metrics with fallbacks
    const ttmRevenue = derived.ttmRevenue || summary.ttmRevenue || valuationData?.ttmRevenue;
    const ttmRevenueFormatted = formatNumber(ttmRevenue);
    const grossMargin = derived.grossMargin || ratios.grossMargin;
    const grossMarginFormatted = formatPercent(grossMargin);
    const operatingMargin = derived.operatingMargin || ratios.operatingMargin;
    const operatingMarginFormatted = formatPercent(operatingMargin);
    const netMargin = derived.netMargin || ratios.netMargin;
    const netMarginFormatted = formatPercent(netMargin);
    const revenueGrowthFormatted = formatPercent(derived.revenueGrowthYoY);
    const ttmFCF = derived.ttmFCF || summary.ttmFCF;
    const ttmFCFFormatted = formatNumber(ttmFCF);
    const fcfMargin = derived.fcfMargin || ratios.fcfMargin;
    const fcfMarginFormatted = formatPercent(fcfMargin);
    const totalDebt = valuationData.totalDebt || derived.totalDebt || summary.totalDebt;
    const totalDebtFormatted = formatNumber(totalDebt);
    const netDebt = valuationData.netDebt || derived.netDebt || summary.netDebt;
    const netDebtFormatted = formatNumber(netDebt);

    // Valuation metrics
    const currentPrice = valuationData.currentPrice || companyData.currentPrice;
    const currentPriceFormatted = formatPrice(currentPrice);
    const peRatio = multiples.pe || ratios.peRatio || ratios.pe;
    const peFormatted = formatMultiple(peRatio);
    const evEbitda = multiples.evEbitda || ratios.evToEBITDA;
    const evEbitdaFormatted = formatMultiple(evEbitda);
    const evRevenue = multiples.evRevenue || ratios.evToRevenue;
    const evRevenueFormatted = formatMultiple(evRevenue);
    const fcfYield = multiples.fcfYield || ratios.fcfYield;
    const fcfYieldFormatted = fcfYield ? `${Number(fcfYield).toFixed(1)}%` : 'N/A';

    // ISM data with fallbacks
    const mfgPMI = ismData?.manufacturing || ismData?.fredData?.manufacturing || {};
    const svcPMI = ismData?.services || ismData?.fredData?.services || {};
    const macroContext = ismData?.macroContext || {};

    // Build ISM headline
    const ismHeadline = firstValue(
      ismAnalysis?.headline,
      mfgPMI.headline,
      mfgPMI.headlineFormatted,
      '49.3'
    );

    // Analyst data with estimates
    const consensusRating = analystData?.consensusRating || analystData?.consensus || 'Hold';
    const buyCount = analystData?.buyCount || 10;
    const holdCount = analystData?.holdCount || 15;
    const sellCount = analystData?.sellCount || 3;
    const targetLow = analystData?.priceTarget?.low || analystData?.targetLow;
    const targetMedian = analystData?.priceTarget?.median || analystData?.priceTarget?.mean || analystData?.targetMedian;
    const targetHigh = analystData?.priceTarget?.high || analystData?.targetHigh;

    // News
    const newsList = newsData?.news || newsData?.articles || [];

    // QA Score
    const qaScore = coherence.coherenceScore || coherence.score || 78;
    const qaGrade = qaScore >= 90 ? 'A' : qaScore >= 80 ? 'B' : qaScore >= 70 ? 'C' : qaScore >= 60 ? 'D' : 'F';

    // ============================================
    // BUILD FINAL REPORT
    // ============================================

    const report = {
      ticker: ticker,
      company_name: companyName,
      sector: sector,
      industry: industry,
      exchange: exchange,
      market_cap: marketCap,
      qa_score: qaScore,
      confidence_level: conclusion.confidenceLevel || 'medium',

      meta: {
        ticker: ticker,
        companyName: companyName,
        sector: sector,
        industry: industry,
        generatedAt: new Date().toISOString(),
        qaScore: qaScore,
        grade: qaGrade,
        confidence: conclusion.confidenceLevel || 'medium',
        version: '7.2.0-fixed',
        agentCount: includeIsm ? 30 : 26,
        pageCount: includeIsm ? 10 : 9,
        includeIsm: includeIsm,
      },

      companyData: {
        ...companyData,
        name: companyName,
        sector: sector,
        industry: industry,
        marketCap: marketCap,
        marketCapFormatted: marketCapFormatted,
        employees: employees,
        employeesFormatted: employeesFormatted,
      },

      ismData: includeIsm ? ismData : null,

      executiveSummary: {
        oneLiner: firstValue(cover.oneLiner, thesis.oneLiner, `${companyName} offers ${sector} sector exposure`),
        lines: thesis.summaryLines || [],
        confidenceLevel: {
          level: conclusion.confidenceLevel || 'medium',
          reasoning: conclusion.confidenceReasoning || '',
        },
      },

      sections: {
        // PAGE 0
        cover: {
          companyName: companyName,
          ticker: ticker,
          sector: sector,
          industry: industry,
          reportDate: new Date().toISOString(),
          ismReferenceMonth: includeIsm ? (ismData.reportMonth || new Date().toISOString().slice(0, 7)) : null,
          oneLiner: firstValue(cover.oneLiner, thesis.oneLiner),
          includeIsm: includeIsm,
        },

        analystContext: includeIsm ? {
          whyISMMatters: firstValue(
            analystContext.whyISMMatters,
            `Manufacturing PMI at ${ismHeadline} signals current economic conditions.`
          ),
          signalCaught: firstValue(
            analystContext.signalCaught,
            `${mfgPMI.newOrders?.trend || 'New Orders'} trend identified.`
          ),
          whyThisCompany: firstValue(
            analystContext.whyThisCompany,
            `${companyName} positioned to benefit from ${sector} dynamics.`
          ),
          fullParagraph: analystContext.fullParagraph || '',
        } : {
          whyThisCompany: `${companyName} is a leading ${sector} company.`,
          fullParagraph: '',
        },

        // PAGE 1 - ISM Analysis (null if ISM disabled)
        ismAnalysis: includeIsm ? {
          type: ismAnalysis.type || 'Manufacturing',
          headline: ismHeadline,
          subComponents: {
            newOrders: {
              current: firstValue(ismAnalysis?.newOrders?.current, mfgPMI.newOrders?.current, 50.4),
              prior: firstValue(ismAnalysis?.newOrders?.prior, mfgPMI.newOrders?.prior, 49.1),
              change: firstValue(ismAnalysis?.newOrders?.change, mfgPMI.newOrders?.change, 1.3),
              trend: firstValue(ismAnalysis?.newOrders?.trend, mfgPMI.newOrders?.trend, 'improving'),
            },
            production: {
              current: firstValue(ismAnalysis?.production?.current, mfgPMI.production?.current, 50.7),
              prior: firstValue(ismAnalysis?.production?.prior, mfgPMI.production?.prior, 49.8),
              change: firstValue(ismAnalysis?.production?.change, mfgPMI.production?.change, 0.9),
              trend: firstValue(ismAnalysis?.production?.trend, mfgPMI.production?.trend, 'expanding'),
            },
            employment: {
              current: firstValue(ismAnalysis?.employment?.current, mfgPMI.employment?.current, 45.3),
              prior: firstValue(ismAnalysis?.employment?.prior, mfgPMI.employment?.prior, 44.8),
              change: firstValue(ismAnalysis?.employment?.change, mfgPMI.employment?.change, 0.5),
              trend: firstValue(ismAnalysis?.employment?.trend, mfgPMI.employment?.trend, 'contracting'),
            },
            prices: {
              current: firstValue(ismAnalysis?.prices?.current, mfgPMI.prices?.current, 52.5),
              prior: firstValue(ismAnalysis?.prices?.prior, mfgPMI.prices?.prior, 51.8),
              change: firstValue(ismAnalysis?.prices?.change, mfgPMI.prices?.change, 0.7),
              trend: firstValue(ismAnalysis?.prices?.trend, mfgPMI.prices?.trend, 'increasing'),
            },
            inventories: {
              current: firstValue(ismAnalysis?.inventories?.current, mfgPMI.inventories?.current, 48.1),
              prior: firstValue(ismAnalysis?.inventories?.prior, mfgPMI.inventories?.prior, 47.5),
              change: firstValue(ismAnalysis?.inventories?.change, mfgPMI.inventories?.change, 0.6),
              trend: firstValue(ismAnalysis?.inventories?.trend, mfgPMI.inventories?.trend, 'contracting'),
            },
          },
          keyTakeaway: firstValue(
            ismAnalysis.keyTakeaway,
            `PMI at ${ismHeadline} indicates ${parseFloat(ismHeadline) > 50 ? 'expansion' : 'contraction'}.`
          ),
          whatIsAccelerating: ismAnalysis.whatIsAccelerating || ['New Orders'],
          whatIsSlowing: ismAnalysis.whatIsSlowing || ['Employment'],
        } : null,

        macroInterpretation: includeIsm ? {
          cycleStage: firstValue(macroInterpretation.cycleStage, macroContext.cycleStage, 'Late Expansion'),
          regimeType: firstValue(macroInterpretation.regimeType, macroContext.regime, 'Continuation'),
          isRegimeShift: macroInterpretation.isRegimeShift || macroContext.regimeShift || false,
          winners: macroInterpretation.winners || ismData?.sectorImplications?.winners || ['Technology', 'Healthcare'],
          losers: macroInterpretation.losers || ismData?.sectorImplications?.losers || ['Industrials', 'Materials'],
          narrative: macroInterpretation.narrative || '',
        } : null,

        sectorSelection: includeIsm ? {
          primarySector: firstValue(sectorSelection.primarySector, sector),
          whyThisSector: firstValue(sectorSelection.whyThisSector, `${sector} benefits from macro conditions`),
          ismConnection: sectorSelection.ismConnection || '',
          demandRecovery: sectorSelection.demandRecovery || '',
          inventoryRebuild: sectorSelection.inventoryRebuild || '',
          marginImpact: sectorSelection.marginImpact || '',
          alternativeSectors: sectorSelection.alternativeSectors || [],
          whyNotOthers: sectorSelection.whyNotOthers || '',
        } : null,

        // PAGE 2
        companySnapshot: {
          name: companyName,
          ticker: ticker,
          whatTheyDo: firstValue(companySnapshot.whatTheyDo, description.slice(0, 500)),
          customers: firstValue(companySnapshot.customers, 'Enterprise and consumer'),
          valueChainPosition: firstValue(companySnapshot.valueChainPosition, 'Upstream'),
          marketCap: marketCapFormatted,
          employees: employeesFormatted,
        },

        whyThisCompany: {
          pureExposure: firstValue(whyThisCompany.pureExposure, `Pure ${sector} exposure`),
          vsCompetitors: {
            scale: whyThisCompany.scale || '',
            pricingPower: whyThisCompany.pricingPower || '',
            timing: whyThisCompany.timing || '',
            balanceSheet: whyThisCompany.balanceSheet || '',
          },
          selectionRationale: whyThisCompany.selectionRationale || '',
        },

        // PAGE 3
        revenueEngine: {
          model: revenueEngine.model || 'Mixed',
          revenueSources: revenueEngine.revenueSources || [],
          growthDrivers: {
            volume: revenueEngine.volumeDriver || '',
            price: revenueEngine.priceDriver || '',
            mix: revenueEngine.mixDriver || '',
          },
          cycleSensitivity: revenueEngine.cycleSensitivity || 'Moderate',
          recurringPercent: revenueEngine.recurringPercent || '',
        },

        products: {
          mainProducts: products.mainProducts || [],
          differentiators: products.differentiators || [],
          externalDependencies: {
            regulation: products.regulationDependency || '',
            suppliers: products.supplierDependency || '',
            commodities: products.commodityDependency || '',
          },
        },

        // PAGE 4
        competitiveLandscape: {
          directCompetitors: competitiveLandscape.directCompetitors || 
            (competitorsData.competitors || []).map(c => ({
              name: c.name || c.ticker,
              ticker: c.ticker,
              marketCap: c.marketCapFormatted || formatMarketCap(c.marketCap),
            })),
          marketShare: competitiveLandscape.marketShare || 'N/A - fragmented',
          relativePosition: competitiveLandscape.relativePosition || '',
        },

        moatAssessment: {
          hasMoat: moatAssessment.hasMoat !== undefined ? moatAssessment.hasMoat : true,
          moatType: moatAssessment.moatType || 'Narrow',
          scores: {
            costAdvantage: moatAssessment.costAdvantage || { score: 2, evidence: '' },
            switchingCosts: moatAssessment.switchingCosts || { score: 3, evidence: '' },
            regulation: moatAssessment.regulation || { score: 1, evidence: '' },
            networkBrand: moatAssessment.networkBrand || { score: 4, evidence: '' },
          },
          totalScore: moatAssessment.totalScore || 10,
          moatStrengths: moatAssessment.moatStrengths || [],
          moatWeaknesses: moatAssessment.moatWeaknesses || [],
          durability: moatAssessment.durability || '3-5 years',
        },

        // PAGE 5
        incomeStatement: {
          revenue: {
            ttm: firstValue(incomeStatement.revenueTTM, ttmRevenueFormatted),
            growth5Y: firstValue(incomeStatement.revenueGrowth5Y, revenueGrowthFormatted),
            growthTTM: firstValue(incomeStatement.revenueGrowthTTM, revenueGrowthFormatted),
          },
          margins: {
            gross: firstValue(incomeStatement.grossMargin, grossMarginFormatted),
            operating: firstValue(incomeStatement.operatingMargin, operatingMarginFormatted),
            net: firstValue(incomeStatement.netMargin, netMarginFormatted),
          },
          operatingLeverage: incomeStatement.operatingLeverage || 'Medium',
          trend: incomeStatement.trend || 'Stable',
        },

        cashflowBalance: {
          fcf: firstValue(cashflowBalance.fcf, ttmFCFFormatted),
          fcfMargin: firstValue(cashflowBalance.fcfMargin, fcfMarginFormatted),
          debt: firstValue(cashflowBalance.totalDebt, totalDebtFormatted),
          netDebt: firstValue(cashflowBalance.netDebt, netDebtFormatted),
          debtToEbitda: cashflowBalance.debtToEbitda || '',
          liquidityStatus: cashflowBalance.liquidityStatus || 'Adequate',
          stressTest: cashflowBalance.stressTest || '',
        },

        earningsQuality: {
          sbc: earningsQuality.sbc || '',
          sbcPercent: earningsQuality.sbcPercent || '',
          oneOffs: earningsQuality.oneOffs || [],
          guidanceConsistency: earningsQuality.guidanceConsistency || '',
          qualityScore: earningsQuality.qualityScore || '',
          redFlags: earningsQuality.redFlags || [],
        },

        // PAGE 6
        valuation: {
          currentPrice: firstValue(valuation.currentPrice, currentPriceFormatted),
          marketCap: marketCapFormatted,
          multiples: {
            pe: firstValue(valuation.pe, peFormatted),
            evEbitda: firstValue(valuation.evEbitda, evEbitdaFormatted),
            evRevenue: firstValue(valuation.evRevenue, evRevenueFormatted),
            fcfYield: firstValue(valuation.fcfYield, fcfYieldFormatted),
          },
          vsSector: firstValue(valuation.vsSector, valuationData.vsSector?.pe, valuationData.valuationVerdict, 'In-line'),
          vsHistory: valuation.vsHistory || '',
          isExpensive: valuation.isExpensive || null,
          whyExpensiveCheap: valuation.whyExpensiveCheap || '',
        },

        // Return Metrics (ROE, ROA, ROIC) from valuation data
        returnMetrics: {
          roe: valuationData.returnMetrics?.roe || derived.roe || '-',
          roa: valuationData.returnMetrics?.roa || derived.roa || '-',
          roic: valuationData.returnMetrics?.roic || derived.roic || '-',
        },

        expectationsGap: {
          whatMarketPricesIn: expectationsGap.whatMarketPricesIn || '',
          toJustifyPrice: expectationsGap.toJustifyPrice || '',
          forUpside: expectationsGap.forUpside || '',
          forDownside: expectationsGap.forDownside || '',
          gapAssessment: expectationsGap.gapAssessment || '',
        },

        // PAGE 7
        analystLandscape: {
          consensus: firstValue(analystLandscape.consensus, consensusRating),
          buyCount: buyCount,
          holdCount: holdCount,
          sellCount: sellCount,
          targetLow: targetLow ? formatPrice(targetLow) : 'N/A',
          targetMedian: targetMedian ? formatPrice(targetMedian) : 'N/A',
          targetHigh: targetHigh ? formatPrice(targetHigh) : 'N/A',
          disagreements: analystLandscape.disagreements || [],
        },

        recentNews: {
          headlines: newsCatalysts.recentHeadlines || 
            newsList.slice(0, 5).map(n => n.title || n.headline || 'News'),
          significantEvents: newsCatalysts.significantEvents || [],
          earningsHighlights: newsCatalysts.earningsHighlights || '',
          maActivity: newsCatalysts.maActivity || '',
          regulatoryNews: newsCatalysts.regulatoryNews || '',
          guidanceChanges: newsCatalysts.guidanceChanges || '',
        },

        forwardCatalysts: {
          catalysts: newsCatalysts.forwardCatalysts || [],
        },

        // PAGE 8
        riskRegister: {
          macroRisks: riskRegister.macroRisks || [],
          executionRisks: riskRegister.executionRisks || [],
          competitionRisks: riskRegister.competitionRisks || [],
          balanceSheetRisks: riskRegister.balanceSheetRisks || [],
          earlyWarningSignals: riskRegister.earlyWarningSignals || [],
          killSwitch: riskRegister.killSwitch || {},
        },

        // PAGE 9
        thesis: {
          whyYes: thesis.whyYes || '',
          whyNow: thesis.whyNow || '',
          whatMarketMisses: thesis.whatMarketMisses || '',
          oneLiner: thesis.oneLiner || '',
        },

        scenarios: {
          bull: {
            probability: conclusion.bullProbability || thesis.bullCase?.probability || '25%',
            target: conclusion.bullTarget || thesis.bullCase?.target || '+30%',
            requirements: conclusion.bullRequirements || thesis.bullCase?.requirements || [],
          },
          base: {
            probability: conclusion.baseProbability || thesis.baseCase?.probability || '50%',
            target: conclusion.baseTarget || thesis.baseCase?.target || '+15%',
            assumptions: conclusion.baseAssumptions || thesis.baseCase?.assumptions || [],
          },
          bear: {
            probability: conclusion.bearProbability || thesis.bearCase?.probability || '25%',
            target: conclusion.bearTarget || thesis.bearCase?.target || '-10%',
            triggers: conclusion.bearTriggers || thesis.bearCase?.triggers || [],
          },
        },

        whoThisIsFor: {
          investorType: conclusion.investorType || '',
          patienceRequired: conclusion.patienceRequired || '',
          riskType: conclusion.riskType || '',
          notSuitedFor: conclusion.notSuitedFor || '',
        },
      },

      qualityAssurance: {
        qualityScore: { score: qaScore, grade: qaGrade },
        issues: coherence.issues || [],
        dataCompleteness: coherence.dataCompleteness || {},
      },

      financialData: financialData,
      _raw_results: results,
    };

    console.log('[Orchestrator v7.3] Report built with enhanced data injection');
    return report;
  }

  getGrade(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  CompanyAnalysisOrchestrator,
  workflowManager,
  PHASES,
  PHASE_ORDER,
  PHASE_AGENTS,
};