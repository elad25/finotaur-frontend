// =====================================================
// COMPANY ANALYSIS DATA SERVICE - ENHANCED SEC EDGAR v3.0
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/data-service.js
//
// IMPROVEMENTS:
// 1. Full SEC EDGAR integration with text extraction
// 2. Multiple fallback data sources
// 3. Automatic retry with exponential backoff
// 4. Comprehensive XBRL concept mapping
// 5. MD&A, Risk Factors, Business Description extraction
// =====================================================

const axios = require('axios');

// ============================================
// S&P 500 COMPANIES LIST
// ============================================

const SP500_TICKERS = [
  'AAPL', 'MSFT', 'AMZN', 'NVDA', 'GOOGL', 'META', 'TSLA', 'BRK.B', 'UNH', 'XOM',
  'JNJ', 'JPM', 'V', 'PG', 'MA', 'HD', 'CVX', 'MRK', 'ABBV', 'LLY',
  'PEP', 'KO', 'COST', 'AVGO', 'TMO', 'MCD', 'WMT', 'CSCO', 'ABT', 'CRM',
  'ACN', 'DHR', 'LIN', 'NEE', 'TXN', 'BMY', 'NKE', 'UPS', 'PM', 'ORCL',
  'RTX', 'AMD', 'QCOM', 'HON', 'UNP', 'MS', 'LOW', 'SPGI', 'T', 'ELV',
  'INTC', 'GS', 'CAT', 'BA', 'DE', 'PLD', 'BLK', 'AMAT', 'INTU', 'AXP',
  'GILD', 'ADI', 'MDLZ', 'SYK', 'ISRG', 'BKNG', 'VRTX', 'AMT', 'LMT', 'CVS',
  'AMGN', 'ADP', 'TJX', 'REGN', 'CI', 'NOW', 'ZTS', 'PNC', 'SO', 'CB',
  'SCHW', 'DUK', 'PYPL', 'MO', 'TMUS', 'USB', 'CME', 'CL', 'EOG', 'ITW',
  'COP', 'MMC', 'MMM', 'BDX', 'EQIX', 'ICE', 'AON', 'NOC', 'EMR', 'SHW',
  'GD', 'FCX', 'NSC', 'HUM', 'MCK', 'WM', 'APD', 'PXD', 'ETN', 'PSX',
  'DIS', 'F', 'GM', 'NFLX', 'ADBE', 'SBUX', 'IBM', 'GE', 'VZ', 'WFC',
];

// ============================================
// EXPANDED XBRL CONCEPT MAPPINGS
// ============================================

const XBRL_CONCEPTS = {
  // Income Statement - Primary
  revenue: [
    'RevenueFromContractWithCustomerExcludingAssessedTax',
    'Revenues',
    'SalesRevenueNet',
    'TotalRevenuesAndOtherIncome',
    'RevenueFromContractWithCustomerIncludingAssessedTax',
    'SalesRevenueGoodsNet',
    'SalesRevenueServicesNet',
    'InterestAndDividendIncomeOperating', // Banks
    'PremiumsEarnedNet', // Insurance
  ],
  costOfRevenue: [
    'CostOfRevenue',
    'CostOfGoodsAndServicesSold',
    'CostOfGoodsSold',
    'CostOfServices',
  ],
  grossProfit: [
    'GrossProfit',
  ],
  researchDevelopment: [
    'ResearchAndDevelopmentExpense',
    'ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost',
  ],
  sellingGeneralAdmin: [
    'SellingGeneralAndAdministrativeExpense',
    'GeneralAndAdministrativeExpense',
    'SellingAndMarketingExpense',
  ],
  operatingExpenses: [
    'OperatingExpenses',
    'CostsAndExpenses',
    'OperatingCostsAndExpenses',
  ],
  operatingIncome: [
    'OperatingIncomeLoss',
    'IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest',
    'IncomeLossFromContinuingOperationsBeforeInterestExpenseInterestIncomeIncomeTaxesExtraordinaryItemsNoncontrollingInterestsNet',
  ],
  interestExpense: [
    'InterestExpense',
    'InterestAndDebtExpense',
    'InterestExpenseDebt',
  ],
  incomeBeforeTax: [
    'IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments',
    'IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest',
  ],
  incomeTax: [
    'IncomeTaxExpenseBenefit',
    'IncomeTaxesPaidNet',
  ],
  netIncome: [
    'NetIncomeLoss',
    'ProfitLoss',
    'NetIncomeLossAvailableToCommonStockholdersBasic',
    'NetIncomeLossAttributableToParent',
  ],
  eps: [
    'EarningsPerShareBasic',
  ],
  epsDiluted: [
    'EarningsPerShareDiluted',
  ],
  
  // Balance Sheet - Assets
  totalAssets: [
    'Assets',
  ],
  currentAssets: [
    'AssetsCurrent',
  ],
  cash: [
    'CashAndCashEquivalentsAtCarryingValue',
    'CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents',
    'Cash',
  ],
  shortTermInvestments: [
    'ShortTermInvestments',
    'MarketableSecuritiesCurrent',
    'AvailableForSaleSecuritiesDebtSecuritiesCurrent',
  ],
  accountsReceivable: [
    'AccountsReceivableNetCurrent',
    'ReceivablesNetCurrent',
    'AccountsReceivableNet',
  ],
  inventory: [
    'InventoryNet',
    'InventoryFinishedGoodsNetOfReserves',
  ],
  propertyPlantEquipment: [
    'PropertyPlantAndEquipmentNet',
    'PropertyPlantAndEquipmentAndFinanceLeaseRightOfUseAssetAfterAccumulatedDepreciationAndAmortization',
  ],
  goodwill: [
    'Goodwill',
  ],
  intangibleAssets: [
    'IntangibleAssetsNetExcludingGoodwill',
    'FiniteLivedIntangibleAssetsNet',
  ],
  
  // Balance Sheet - Liabilities
  totalLiabilities: [
    'Liabilities',
  ],
  currentLiabilities: [
    'LiabilitiesCurrent',
  ],
  accountsPayable: [
    'AccountsPayableCurrent',
    'AccountsPayableAndAccruedLiabilitiesCurrent',
  ],
  shortTermDebt: [
    'ShortTermBorrowings',
    'DebtCurrent',
    'LongTermDebtCurrent',
    'CommercialPaper',
  ],
  longTermDebt: [
    'LongTermDebt',
    'LongTermDebtNoncurrent',
    'LongTermDebtAndCapitalLeaseObligations',
  ],
  totalDebt: [
    'DebtLongtermAndShorttermCombinedAmount',
    'LongTermDebt',
    'LongTermDebtAndCapitalLeaseObligations',
  ],
  deferredRevenue: [
    'DeferredRevenue',
    'ContractWithCustomerLiability',
    'DeferredRevenueAndCredits',
  ],
  
  // Equity
  totalEquity: [
    'StockholdersEquity',
    'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest',
  ],
  retainedEarnings: [
    'RetainedEarningsAccumulatedDeficit',
  ],
  treasuryStock: [
    'TreasuryStockValue',
  ],
  
  // Cash Flow
  operatingCashFlow: [
    'NetCashProvidedByUsedInOperatingActivities',
    'CashFlowsFromUsedInOperatingActivities',
  ],
  investingCashFlow: [
    'NetCashProvidedByUsedInInvestingActivities',
  ],
  financingCashFlow: [
    'NetCashProvidedByUsedInFinancingActivities',
  ],
  capex: [
    'PaymentsToAcquirePropertyPlantAndEquipment',
    'PaymentsToAcquireProductiveAssets',
    'PaymentsForCapitalImprovements',
  ],
  depreciation: [
    'DepreciationDepletionAndAmortization',
    'DepreciationAndAmortization',
    'Depreciation',
  ],
  stockBasedComp: [
    'ShareBasedCompensation',
    'AllocatedShareBasedCompensationExpense',
  ],
  dividendsPaid: [
    'PaymentsOfDividendsCommonStock',
    'PaymentsOfDividends',
    'Dividends',
  ],
  shareRepurchases: [
    'PaymentsForRepurchaseOfCommonStock',
    'PaymentsForRepurchaseOfEquity',
  ],
  
  // Shares
  sharesOutstanding: [
    'CommonStockSharesOutstanding',
    'WeightedAverageNumberOfSharesOutstandingBasic',
  ],
  sharesDiluted: [
    'WeightedAverageNumberOfDilutedSharesOutstanding',
  ],
  
  // Segment Data
  segmentRevenue: [
    'RevenueFromContractWithCustomerExcludingAssessedTax',
    'Revenues',
  ],
  segmentOperatingIncome: [
    'OperatingIncomeLoss',
  ],
};

// ============================================
// RETRY UTILITY
// ============================================

async function retryWithBackoff(fn, maxRetries = 3, baseDelay = 1000) {
  let lastError;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (attempt < maxRetries - 1) {
        const delay = baseDelay * Math.pow(2, attempt);
        console.log(`[Retry] Attempt ${attempt + 1} failed, retrying in ${delay}ms...`);
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }
  throw lastError;
}

// ============================================
// DATA SERVICE CLASS
// ============================================

class CompanyDataService {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    this.options = {
      eodhApiKey: options.eodhApiKey || process.env.EODH_API_KEY,
      newsApiKey: options.newsApiKey || process.env.NEWS_API_KEY,
      polygonApiKey: options.polygonApiKey || process.env.POLYGON_API_KEY,
      fredApiKey: options.fredApiKey || process.env.FRED_API_KEY,
      cacheEnabled: options.cacheEnabled !== false,
      cacheTTL: options.cacheTTL || 3600,
      ...options,
    };
    
    this.cache = new Map();
    this.cikCache = new Map();
    this.companyTickerMap = new Map(); // For CIK lookup
    this.sp500List = SP500_TICKERS;
    
// SEC API headers - REQUIRED by SEC
    this.secHeaders = {
      'User-Agent': process.env.SEC_USER_AGENT || 'Finotaur/1.0 (mailto:dev@finotaur.com)',
      'Accept': 'application/json',
      'Accept-Encoding': 'gzip, deflate',
    };
    
// SEC API base URL (use proxy if configured)
    this.secBaseUrl = process.env.SEC_PROXY_URL || 'https://data.sec.gov';
    this.secFilesUrl = process.env.SEC_PROXY_URL ? `${process.env.SEC_PROXY_URL}/files` : 'https://www.sec.gov/files';
  }
  // ============================================
  // POLYGON.IO API - Real-time Market Data
  // ============================================

  async fetchPolygonTickerDetails(ticker) {
    if (!this.options.polygonApiKey) return null;
    
    const cacheKey = `polygon_details_${ticker}`;
    if (this.options.cacheEnabled) {
      const cached = this.cacheGet(cacheKey);
      if (cached) return cached;
    }
    
   try {
      const response = await retryWithBackoff(async () => {
        return axios.get(
          `https://api.polygon.io/v3/reference/tickers/${ticker.toUpperCase()}`,
          {
            params: { apiKey: this.options.polygonApiKey },
            timeout: 10000,
          }
        );
      });
      
      const data = response.data?.results;
      if (!data) return null;
      
      const result = {
        ticker: data.ticker,
        name: data.name,
        market: data.market,
        locale: data.locale,
        primaryExchange: data.primary_exchange,
        type: data.type,
        active: data.active,
        currency: data.currency_name,
        marketCap: data.market_cap,
        sharesOutstanding: data.share_class_shares_outstanding,
        weightedSharesOutstanding: data.weighted_shares_outstanding,
        description: data.description,
        sicCode: data.sic_code,
        sicDescription: data.sic_description,
        sector: data.sic_description,
        homepageUrl: data.homepage_url,
        totalEmployees: data.total_employees,
        listDate: data.list_date,
        phoneNumber: data.phone_number,
        address: data.address,
        branding: {
          logoUrl: data.branding?.logo_url,
          iconUrl: data.branding?.icon_url,
        },
      };
      
      this.cacheSet(cacheKey, result);
      return result;
    } catch (error) {
      console.warn(`[CompanyData] Polygon ticker details failed for ${ticker}:`, error.message);
      return null;
    }
  }

  async fetchPolygonPreviousClose(ticker) {
    if (!this.options.polygonApiKey) return null;
    
    try {
      const response = await axios.get(
        `https://api.polygon.io/v2/aggs/ticker/${ticker.toUpperCase()}/prev`,
        {
          params: { apiKey: this.options.polygonApiKey },
          timeout: 10000,
        }
      );
      
      const data = response.data?.results?.[0];
      if (!data) return null;
      
      return {
        close: data.c,
        open: data.o,
        high: data.h,
        low: data.l,
        volume: data.v,
        vwap: data.vw,
        timestamp: data.t,
        numberOfTrades: data.n,
      };
    } catch (error) {
      console.warn(`[CompanyData] Polygon prev close failed for ${ticker}:`, error.message);
      return null;
    }
  }

  async fetchPolygonFinancials(ticker) {
    if (!this.options.polygonApiKey) return null;
    
    const cacheKey = `polygon_financials_${ticker}`;
    if (this.options.cacheEnabled) {
      const cached = this.cacheGet(cacheKey);
      if (cached) return cached;
    }
    
    try {
      const response = await retryWithBackoff(async () => {
        return axios.get(
          `https://api.polygon.io/vX/reference/financials`,
          {
            params: {
              ticker: ticker.toUpperCase(),
              apiKey: this.options.polygonApiKey,
              limit: 20,
              sort: 'filing_date',
              order: 'desc',
            },
            timeout: 15000,
          }
        );
      });
      
      const results = response.data?.results || [];
      if (results.length === 0) return null;
      
      // Transform Polygon financials to standard format
      const quarterly = results
        .filter(r => r.fiscal_period === 'Q1' || r.fiscal_period === 'Q2' || r.fiscal_period === 'Q3' || r.fiscal_period === 'Q4')
        .slice(0, 8)
        .map(r => ({
          date: r.fiscal_period + ' ' + r.fiscal_year,
          period: r.fiscal_period,
          year: r.fiscal_year,
          filingDate: r.filing_date,
          revenue: r.financials?.income_statement?.revenues?.value,
          costOfRevenue: r.financials?.income_statement?.cost_of_revenue?.value,
          grossProfit: r.financials?.income_statement?.gross_profit?.value,
          operatingIncome: r.financials?.income_statement?.operating_income_loss?.value,
          netIncome: r.financials?.income_statement?.net_income_loss?.value,
          eps: r.financials?.income_statement?.basic_earnings_per_share?.value,
          totalAssets: r.financials?.balance_sheet?.assets?.value,
          totalLiabilities: r.financials?.balance_sheet?.liabilities?.value,
          equity: r.financials?.balance_sheet?.equity?.value,
          cash: r.financials?.balance_sheet?.current_assets?.value,
          operatingCashFlow: r.financials?.cash_flow_statement?.net_cash_flow_from_operating_activities?.value,
          capex: r.financials?.cash_flow_statement?.net_cash_flow_from_investing_activities_continuing?.value ||
                 r.financials?.cash_flow_statement?.payments_to_acquire_property_plant_and_equipment?.value,
          investingCashFlow: r.financials?.cash_flow_statement?.net_cash_flow_from_investing_activities?.value,
          financingCashFlow: r.financials?.cash_flow_statement?.net_cash_flow_from_financing_activities?.value,
        }));
      
      const annual = results
        .filter(r => r.fiscal_period === 'FY')
        .slice(0, 5)
        .map(r => ({
          date: r.fiscal_year,
          year: r.fiscal_year,
          filingDate: r.filing_date,
          revenue: r.financials?.income_statement?.revenues?.value,
          costOfRevenue: r.financials?.income_statement?.cost_of_revenue?.value,
          grossProfit: r.financials?.income_statement?.gross_profit?.value,
          operatingIncome: r.financials?.income_statement?.operating_income_loss?.value,
          netIncome: r.financials?.income_statement?.net_income_loss?.value,
          eps: r.financials?.income_statement?.basic_earnings_per_share?.value,
          totalAssets: r.financials?.balance_sheet?.assets?.value,
          totalLiabilities: r.financials?.balance_sheet?.liabilities?.value,
          equity: r.financials?.balance_sheet?.equity?.value,
          operatingCashFlow: r.financials?.cash_flow_statement?.net_cash_flow_from_operating_activities?.value,
          capex: r.financials?.cash_flow_statement?.net_cash_flow_from_investing_activities_continuing?.value ||
                 r.financials?.cash_flow_statement?.payments_to_acquire_property_plant_and_equipment?.value,
        }));
      
      const result = { quarterly, annual };
      this.cacheSet(cacheKey, result);
      return result;
    } catch (error) {
      console.warn(`[CompanyData] Polygon financials failed for ${ticker}:`, error.message);
      return null;
    }
  }

  // ============================================
  // FRED API - Economic/ISM Data
  // ============================================

  async fetchFREDSeries(seriesId, limit = 36) {
    if (!this.options.fredApiKey) return null;
    
    const cacheKey = `fred_${seriesId}`;
    if (this.options.cacheEnabled) {
      const cached = this.cacheGet(cacheKey);
      if (cached) return cached;
    }
    
    try {
      const response = await axios.get(
        'https://api.stlouisfed.org/fred/series/observations',
        {
          params: {
            series_id: seriesId,
            api_key: this.options.fredApiKey,
            file_type: 'json',
            sort_order: 'desc',
            limit: limit,
          },
          timeout: 10000,
        }
      );
      
      const observations = response.data?.observations || [];
      const result = observations.map(o => ({
        date: o.date,
        value: o.value === '.' ? null : parseFloat(o.value),
      })).filter(o => o.value !== null);
      
      this.cacheSet(cacheKey, result);
      return result;
    } catch (error) {
      console.warn(`[CompanyData] FRED fetch failed for ${seriesId}:`, error.message);
      return null;
    }
  }

async fetchISMData() {
  console.log('[DataService] Fetching ISM data...');
  
  try {
    // Try Supabase first
    const [latestReport, sectorRankings] = await Promise.all([
      this.fetchLatestISMReport(),
      this.fetchLatestSectorRankings(),
    ]);
    
    // If we have Supabase data, use it
    if (latestReport?.data?.macro_snapshot) {
      console.log('[DataService] Using Supabase ISM data');
      return {
        ...latestReport.data,
        sectorRankings: sectorRankings?.data || [],
        source: 'supabase',
      };
    }
    
    // Return estimated ISM data when Supabase is empty
    console.log('[DataService] Using estimated ISM data (Supabase empty)');
    const currentMonth = new Date().toISOString().slice(0, 7);
    
    return {
      reportMonth: currentMonth,
      source: 'estimated',
      
      manufacturing: {
        headline: 49.3,
        newOrders: { current: 50.4, prior: 49.1, change: 1.3, trend: 'improving' },
        production: { current: 50.7, prior: 49.8, change: 0.9, trend: 'expanding' },
        employment: { current: 45.3, prior: 44.8, change: 0.5, trend: 'contracting' },
        supplierDeliveries: { current: 48.7, prior: 49.2, change: -0.5, trend: 'faster' },
        inventories: { current: 48.1, prior: 47.5, change: 0.6, trend: 'contracting' },
        prices: { current: 52.5, prior: 51.8, change: 0.7, trend: 'increasing' },
        trend: 'contracting_stabilizing',
        priorMonth: 48.4,
        change: 0.9,
      },
      
      services: {
        headline: 52.1,
        businessActivity: { current: 53.7, prior: 53.1, change: 0.6, trend: 'expanding' },
        newOrders: { current: 53.0, prior: 52.4, change: 0.6, trend: 'expanding' },
        employment: { current: 51.4, prior: 50.9, change: 0.5, trend: 'expanding' },
        prices: { current: 58.2, prior: 57.8, change: 0.4, trend: 'increasing' },
        trend: 'expanding_moderating',
        priorMonth: 52.7,
        change: -0.6,
      },
      
      composite: {
        headline: 51.2,
        interpretation: 'Modest expansion with manufacturing weakness offset by services strength',
      },
      
      macroContext: {
        cycleStage: 'Late Expansion',
        regime: 'Continuation',
        regimeShift: false,
        fedPolicy: 'Restrictive - watching for rate cuts',
        inflationTrend: 'Moderating toward target',
        laborMarket: 'Cooling but resilient',
      },
      
      sectorImplications: {
        winners: ['Technology', 'Healthcare', 'Consumer Staples'],
        losers: ['Industrials', 'Materials', 'Energy'],
        neutral: ['Financials', 'Utilities', 'Real Estate'],
      },
      
      sectorRankings: sectorRankings?.data || [],
      lastUpdated: new Date().toISOString(),
    };
    
  } catch (error) {
    console.warn('[DataService] ISM data fetch error:', error.message);
    return {
      reportMonth: new Date().toISOString().slice(0, 7),
      source: 'fallback',
      manufacturing: { 
        headline: 49.0, 
        newOrders: { current: 50.0, prior: 49.0, change: 1.0, trend: 'improving' },
        production: { current: 50.0, prior: 49.0, change: 1.0, trend: 'expanding' },
        employment: { current: 45.0, prior: 45.0, change: 0.0, trend: 'contracting' },
        prices: { current: 52.0, prior: 51.0, change: 1.0, trend: 'increasing' },
        inventories: { current: 48.0, prior: 48.0, change: 0.0, trend: 'contracting' },
      },
      services: { 
        headline: 52.0, 
        businessActivity: { current: 53.0, prior: 52.0, change: 1.0, trend: 'expanding' },
        newOrders: { current: 52.0, prior: 51.0, change: 1.0, trend: 'expanding' },
      },
      macroContext: {
        cycleStage: 'Late Expansion',
        regime: 'Continuation',
      },
    };
  }
}
  // ============================================
  // ISM SECTOR & TICKER CONTEXT (from Supabase)
  // ============================================

  /**
   * Fetch latest sector rankings from ISM report
   * Uses v_sector_rankings_latest view
   */
  async fetchLatestSectorRankings() {
    try {
      const { data, error } = await this.supabase
        .from('v_sector_rankings_latest')
        .select('*')
        .order('rank', { ascending: true });
      
      if (error) throw error;
      
      return {
        success: true,
        data: data || [],
        reportMonth: data?.[0]?.report_month || null,
        reportId: data?.[0]?.report_id || null,
      };
    } catch (error) {
      console.warn('[DataService] Failed to fetch sector rankings:', error.message);
      return { success: false, data: [], error: error.message };
    }
  }

  /**
   * Fetch latest ticker selections from ISM report
   * Uses v_ticker_selections_latest view
   */
  async fetchLatestTickerSelections() {
    try {
      const { data, error } = await this.supabase
        .from('v_ticker_selections_latest')
        .select('*');
      
      if (error) throw error;
      
      // Group by selection type
      const grouped = {
        overweight: [],
        underweight: [],
        avoid: [],
        watchlist: [],
      };
      
      for (const ticker of (data || [])) {
        if (grouped[ticker.selection_type]) {
          grouped[ticker.selection_type].push(ticker);
        }
      }
      
      return {
        success: true,
        data: data || [],
        grouped,
        reportMonth: data?.[0]?.report_month || null,
        reportId: data?.[0]?.report_id || null,
      };
    } catch (error) {
      console.warn('[DataService] Failed to fetch ticker selections:', error.message);
      return { success: false, data: [], grouped: {}, error: error.message };
    }
  }

  /**
   * Get ISM context for a specific ticker
   * Returns if ticker was in any selection list and why
   */
  async fetchTickerISMContext(ticker) {
    try {
      const upperTicker = ticker.toUpperCase();
      
      // First get latest ticker selections
      const { data, error } = await this.supabase
        .from('v_ticker_selections_latest')
        .select('*')
        .eq('ticker', upperTicker)
        .maybeSingle();
      
      if (error) throw error;
      
      if (data) {
        return {
          success: true,
          inISMReport: true,
          selection: {
            type: data.selection_type,
            conviction: data.conviction,
            reasoning: data.reasoning,
            archetype: data.archetype,
            sectorId: data.sector_id,
            sectorName: data.sector_name,
          },
          reportMonth: data.report_month,
          reportId: data.report_id,
        };
      }
      
      // Ticker not in selection list
      return {
        success: true,
        inISMReport: false,
        selection: null,
        note: 'Ticker not in latest ISM report selections',
      };
    } catch (error) {
      console.warn(`[DataService] Failed to fetch ISM context for ${ticker}:`, error.message);
      return { success: false, inISMReport: false, error: error.message };
    }
  }

  /**
   * Get ISM context for a specific sector
   * Returns sector ranking and analysis from latest report
   */
  async fetchSectorISMContext(sectorId) {
    try {
      const { data, error } = await this.supabase
        .from('v_sector_rankings_latest')
        .select('*')
        .eq('sector_id', sectorId)
        .maybeSingle();
      
      if (error) throw error;
      
      if (data) {
        return {
          success: true,
          found: true,
          ranking: {
            rank: data.rank,
            sectorName: data.sector_name,
            etfSymbol: data.etf_symbol,
            impactScore: data.impact_score,
            direction: data.direction,
            ismSignal: data.ism_signal,
            trend: data.trend,
            reasoning: data.reasoning,
            keyDriver: data.key_driver,
            keyDriverValue: data.key_driver_value,
          },
          reportMonth: data.report_month,
          reportId: data.report_id,
        };
      }
      
      return {
        success: true,
        found: false,
        note: `Sector ${sectorId} not found in latest ISM rankings`,
      };
    } catch (error) {
      console.warn(`[DataService] Failed to fetch sector context for ${sectorId}:`, error.message);
      return { success: false, found: false, error: error.message };
    }
  }

  /**
   * Comprehensive ISM context - combines FRED data with Supabase data
   * This is the main method to use for company analysis
   */
  async fetchFullISMContext(ticker = null, sectorId = null) {
    const [fredData, sectorRankings, tickerSelections] = await Promise.all([
      this.fetchISMData(),
      this.fetchLatestSectorRankings(),
      this.fetchLatestTickerSelections(),
    ]);
    
    // Get ticker-specific context if provided
    let tickerContext = null;
    if (ticker) {
      tickerContext = await this.fetchTickerISMContext(ticker);
    }
    
    // Get sector-specific context if provided
    let sectorContext = null;
    if (sectorId) {
      sectorContext = await this.fetchSectorISMContext(sectorId);
    }
    
    // Find sector from ticker if sectorId not provided but ticker is
    if (ticker && !sectorId && tickerContext?.selection?.sectorId) {
      sectorContext = await this.fetchSectorISMContext(tickerContext.selection.sectorId);
    }
    
    return {
      fredData,
      sectorRankings: sectorRankings.data,
      tickerSelections: tickerSelections.grouped,
      allTickers: tickerSelections.data,
      tickerContext,
      sectorContext,
      reportMonth: sectorRankings.reportMonth || tickerSelections.reportMonth,
      reportId: sectorRankings.reportId || tickerSelections.reportId,
      lastUpdated: new Date().toISOString(),
    };
  }

  /**
   * Get the latest ISM report summary
   */
  async fetchLatestISMReport() {
    try {
      const { data, error } = await this.supabase
        .from('ism_reports')
        .select('id, report_month, report_title, executive_summary, five_line_summary, macro_snapshot, created_at')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      
      return {
        success: true,
        data,
      };
    } catch (error) {
      console.warn('[DataService] Failed to fetch latest ISM report:', error.message);
      return { success: false, data: null, error: error.message };
    }
  }

  async fetchMacroIndicators() {
    const [
      gdp,
      unemployment,
      inflation,
      fedFundsRate,
      yieldCurve,
      retailSales,
    ] = await Promise.all([
      this.fetchFREDSeries('GDP', 12),
      this.fetchFREDSeries('UNRATE', 24),
      this.fetchFREDSeries('CPIAUCSL', 24),
      this.fetchFREDSeries('FEDFUNDS', 24),
      this.fetchFREDSeries('T10Y2Y', 24),
      this.fetchFREDSeries('RSXFS', 24),
    ]);
    
    return {
      gdp,
      unemployment,
      inflation,
      fedFundsRate,
      yieldCurve,
      retailSales,
      lastUpdated: new Date().toISOString(),
    };
  }

  // ============================================
  // S&P 500 UTILITIES
  // ============================================

  getSP500List() {
    return [...this.sp500List];
  }

  isInSP500(ticker) {
    return this.sp500List.includes(ticker.toUpperCase());
  }

  getRandomSP500Ticker() {
    const randomIndex = Math.floor(Math.random() * this.sp500List.length);
    return this.sp500List[randomIndex];
  }

  // ============================================
  // SEC EDGAR - CIK LOOKUP
  // ============================================

  async getCIK(ticker) {
    const upperTicker = ticker.toUpperCase();
    
    if (this.cikCache.has(upperTicker)) {
      return this.cikCache.get(upperTicker);
    }
    
    try {
      const response = await retryWithBackoff(async () => {
        return axios.get(`${this.secFilesUrl}/company_tickers.json`, {
          headers: this.secHeaders,
          timeout: 15000,
        });
      });

// Build full map for future lookups
      const companies = Object.values(response.data);
      for (const c of companies) {
        // SEC format: cik_str is the CIK number
        const cikValue = c.cik_str ? String(c.cik_str) : String(c.cik);
        this.companyTickerMap.set(c.ticker.toUpperCase(), {
          cik: cikValue,
          title: c.title,
        });
      }
      
      const match = this.companyTickerMap.get(upperTicker);
      if (match) {
        this.cikCache.set(upperTicker, match.cik);
        return match.cik;
      }
      
      return null;
    } catch (error) {
      console.error(`[CompanyData] Failed to get CIK for ${ticker}:`, error.message);
      return null;
    }
  }

  // ============================================
  // SEC EDGAR - COMPANY FACTS (XBRL)
  // ============================================

  async fetchSECCompanyFacts(ticker) {
    const cacheKey = `sec_facts_${ticker}`;
    
    if (this.options.cacheEnabled) {
      const cached = this.cacheGet(cacheKey);
      if (cached) return cached;
    }
    
    try {
      const cik = await this.getCIK(ticker);
      if (!cik) {
        console.warn(`[CompanyData] No CIK found for ${ticker}`);
        return null;
      }
      
      const paddedCIK = cik.padStart(10, '0');
const response = await retryWithBackoff(async () => {
        return axios.get(
          `${this.secBaseUrl}/api/xbrl/companyfacts/CIK${paddedCIK}.json`,
          { headers: this.secHeaders, timeout: 30000 }
        );
      });
      
      this.cacheSet(cacheKey, response.data);
      return response.data;
    } catch (error) {
      console.error(`[CompanyData] Failed to fetch SEC facts for ${ticker}:`, error.message);
      return null;
    }
  }

  // ============================================
  // SEC EDGAR - SUBMISSIONS (Filings List)
  // ============================================

  async fetchSECSubmissions(ticker) {
    const cacheKey = `sec_submissions_${ticker}`;
    
    if (this.options.cacheEnabled) {
      const cached = this.cacheGet(cacheKey);
      if (cached) return cached;
    }
    
    try {
      const cik = await this.getCIK(ticker);
      if (!cik) return null;
      
      const paddedCIK = cik.padStart(10, '0');
const response = await retryWithBackoff(async () => {
        return axios.get(
          `${this.secBaseUrl}/submissions/CIK${paddedCIK}.json`,
          { headers: this.secHeaders, timeout: 20000 }
        );
      });
      
      this.cacheSet(cacheKey, response.data);
      return response.data;
    } catch (error) {
      console.error(`[CompanyData] Failed to fetch SEC submissions for ${ticker}:`, error.message);
      return null;
    }
  }

  // ============================================
  // XBRL VALUE EXTRACTION
  // ============================================

  extractXBRLValue(facts, conceptKeys, options = {}) {
    const { 
      period = 'annual',
      limit = 5,
      unit = 'USD',
    } = options;
    
    if (!facts?.facts) return [];
    
    // Try us-gaap first, then dei
    const namespaces = ['us-gaap', 'dei', 'ifrs-full'];
    
    for (const ns of namespaces) {
      if (!facts.facts[ns]) continue;
      
      const nsData = facts.facts[ns];
      
      for (const concept of conceptKeys) {
        if (!nsData[concept]?.units) continue;
        
        // Try USD first, then shares, then pure
        const unitTypes = [unit, 'shares', 'pure'];
        
        for (const u of unitTypes) {
          if (!nsData[concept].units[u]) continue;
          
          let values = nsData[concept].units[u];
          
          // Filter by period type
          if (period === 'annual') {
            values = values.filter(v => 
              v.fp === 'FY' && 
              (v.form === '10-K' || v.form === '20-F')
            );
          } else if (period === 'quarterly') {
            values = values.filter(v => 
              ['Q1', 'Q2', 'Q3', 'Q4'].includes(v.fp) && 
              v.form === '10-Q'
            );
          }
          
          if (values.length === 0) continue;
          
          // Sort by date descending
          values.sort((a, b) => new Date(b.end) - new Date(a.end));
          
          // Return limited results
          return values.slice(0, limit).map(v => ({
            date: v.end,
            value: v.val,
            fiscalYear: v.fy,
            fiscalPeriod: v.fp,
            form: v.form,
            filed: v.filed,
            frame: v.frame,
          }));
        }
      }
    }
    
    return [];
  }

  // ============================================
  // COMPREHENSIVE FINANCIAL DATA
  // ============================================

  async fetchComprehensiveFinancials(ticker) {
    const facts = await this.fetchSECCompanyFacts(ticker);
    if (!facts) return null;
    
    const extract = (keys, opts = {}) => ({
      annual: this.extractXBRLValue(facts, keys, { period: 'annual', limit: 5, ...opts }),
      quarterly: this.extractXBRLValue(facts, keys, { period: 'quarterly', limit: 8, ...opts }),
    });
    
    const extractShares = (keys) => ({
      annual: this.extractXBRLValue(facts, keys, { period: 'annual', limit: 5, unit: 'shares' }),
      quarterly: this.extractXBRLValue(facts, keys, { period: 'quarterly', limit: 8, unit: 'shares' }),
    });
    
    const financials = {
      entityName: facts.entityName,
      cik: facts.cik,
      
      // Income Statement
      revenue: extract(XBRL_CONCEPTS.revenue),
      costOfRevenue: extract(XBRL_CONCEPTS.costOfRevenue),
      grossProfit: extract(XBRL_CONCEPTS.grossProfit),
      researchDevelopment: extract(XBRL_CONCEPTS.researchDevelopment),
      sellingGeneralAdmin: extract(XBRL_CONCEPTS.sellingGeneralAdmin),
      operatingExpenses: extract(XBRL_CONCEPTS.operatingExpenses),
      operatingIncome: extract(XBRL_CONCEPTS.operatingIncome),
      interestExpense: extract(XBRL_CONCEPTS.interestExpense),
      netIncome: extract(XBRL_CONCEPTS.netIncome),
      eps: extract(XBRL_CONCEPTS.eps),
      epsDiluted: extract(XBRL_CONCEPTS.epsDiluted),
      
      // Balance Sheet
      totalAssets: extract(XBRL_CONCEPTS.totalAssets),
      currentAssets: extract(XBRL_CONCEPTS.currentAssets),
      cash: extract(XBRL_CONCEPTS.cash),
      shortTermInvestments: extract(XBRL_CONCEPTS.shortTermInvestments),
      accountsReceivable: extract(XBRL_CONCEPTS.accountsReceivable),
      inventory: extract(XBRL_CONCEPTS.inventory),
      propertyPlantEquipment: extract(XBRL_CONCEPTS.propertyPlantEquipment),
      goodwill: extract(XBRL_CONCEPTS.goodwill),
      intangibleAssets: extract(XBRL_CONCEPTS.intangibleAssets),
      totalLiabilities: extract(XBRL_CONCEPTS.totalLiabilities),
      currentLiabilities: extract(XBRL_CONCEPTS.currentLiabilities),
      accountsPayable: extract(XBRL_CONCEPTS.accountsPayable),
      shortTermDebt: extract(XBRL_CONCEPTS.shortTermDebt),
      longTermDebt: extract(XBRL_CONCEPTS.longTermDebt),
      deferredRevenue: extract(XBRL_CONCEPTS.deferredRevenue),
      totalEquity: extract(XBRL_CONCEPTS.totalEquity),
      retainedEarnings: extract(XBRL_CONCEPTS.retainedEarnings),
      
      // Cash Flow
      operatingCashFlow: extract(XBRL_CONCEPTS.operatingCashFlow),
      investingCashFlow: extract(XBRL_CONCEPTS.investingCashFlow),
      financingCashFlow: extract(XBRL_CONCEPTS.financingCashFlow),
      capex: extract(XBRL_CONCEPTS.capex),
      depreciation: extract(XBRL_CONCEPTS.depreciation),
      stockBasedComp: extract(XBRL_CONCEPTS.stockBasedComp),
      dividendsPaid: extract(XBRL_CONCEPTS.dividendsPaid),
      shareRepurchases: extract(XBRL_CONCEPTS.shareRepurchases),
      
      // Shares
      sharesOutstanding: extractShares(XBRL_CONCEPTS.sharesOutstanding),
      sharesDiluted: extractShares(XBRL_CONCEPTS.sharesDiluted),
    };
    
    // Calculate derived metrics
    financials.derived = this.calculateDerivedMetrics(financials);
    
    return financials;
  }

  calculateDerivedMetrics(financials) {
    const getLatest = (data, period = 'annual') => {
      const arr = data?.[period] || [];
      return arr[0]?.value || null;
    };
    
    const getTTM = (data) => {
      const quarterly = data?.quarterly || [];
      if (quarterly.length < 4) return null;
      return quarterly.slice(0, 4).reduce((sum, q) => sum + (q?.value || 0), 0);
    };
    
    const getYoYGrowth = (data, period = 'annual') => {
      const arr = data?.[period] || [];
      if (arr.length < 2) return null;
      const current = arr[0]?.value;
      const prior = arr[1]?.value;
      if (!current || !prior || prior === 0) return null;
      return ((current - prior) / Math.abs(prior)) * 100;
    };
    
    // TTM calculations
    const ttmRevenue = getTTM(financials.revenue);
    const ttmNetIncome = getTTM(financials.netIncome);
    const ttmOperatingCashFlow = getTTM(financials.operatingCashFlow);
    const ttmCapex = getTTM(financials.capex);
    const ttmFCF = ttmOperatingCashFlow && ttmCapex 
      ? ttmOperatingCashFlow - Math.abs(ttmCapex) 
      : null;
    
    // Latest balance sheet
    const latestCash = getLatest(financials.cash, 'quarterly') || getLatest(financials.cash);
    const latestDebt = getLatest(financials.longTermDebt, 'quarterly') || getLatest(financials.longTermDebt);
    const latestEquity = getLatest(financials.totalEquity, 'quarterly') || getLatest(financials.totalEquity);
    const latestAssets = getLatest(financials.totalAssets, 'quarterly') || getLatest(financials.totalAssets);
    
    // Margins
    const latestRevenue = getLatest(financials.revenue);
    const latestGrossProfit = getLatest(financials.grossProfit);
    const latestOperatingIncome = getLatest(financials.operatingIncome);
    const latestNetIncome = getLatest(financials.netIncome);
    
    return {
      // TTM values
      ttmRevenue,
      ttmNetIncome,
      ttmOperatingCashFlow,
      ttmCapex,
      ttmFCF,
      
      // Growth rates
      revenueGrowthYoY: getYoYGrowth(financials.revenue),
      netIncomeGrowthYoY: getYoYGrowth(financials.netIncome),
      revenueGrowthQoQ: getYoYGrowth(financials.revenue, 'quarterly'),
      
      // Margins (annual)
      grossMargin: latestRevenue && latestGrossProfit 
        ? (latestGrossProfit / latestRevenue * 100) : null,
      operatingMargin: latestRevenue && latestOperatingIncome 
        ? (latestOperatingIncome / latestRevenue * 100) : null,
      netMargin: latestRevenue && latestNetIncome 
        ? (latestNetIncome / latestRevenue * 100) : null,
      fcfMargin: ttmRevenue && ttmFCF 
        ? (ttmFCF / ttmRevenue * 100) : null,
      
      // Balance sheet metrics
      netDebt: latestDebt && latestCash ? latestDebt - latestCash : null,
      debtToEquity: latestEquity && latestDebt 
        ? (latestDebt / latestEquity) : null,
roe: latestEquity && latestNetIncome 
        ? (latestNetIncome / latestEquity * 100) : null,
      roa: latestAssets && latestNetIncome 
        ? (latestNetIncome / latestAssets * 100) : null,
      // ROIC = Operating Income * (1 - Tax Rate) / Invested Capital
      // Invested Capital = Total Equity + Total Debt - Cash
      roic: (() => {
        const investedCapital = (latestEquity || 0) + (latestDebt || 0) - (latestCash || 0);
        const operatingIncome = getLatest(financials.operatingIncome);
        const taxRate = 0.21; // Assume 21% corporate tax rate
        const nopat = operatingIncome ? operatingIncome * (1 - taxRate) : null;
        return investedCapital > 0 && nopat ? (nopat / investedCapital * 100) : null;
      })(),
      
      // FCF conversion
      fcfConversion: ttmNetIncome && ttmFCF 
        ? (ttmFCF / ttmNetIncome * 100) : null,
    };
  }

  // ============================================
  // COMPANY PROFILE
  // ============================================

  async fetchCompanyProfile(ticker) {
    const cacheKey = `profile_${ticker}`;
    
    if (this.options.cacheEnabled) {
      const cached = this.cacheGet(cacheKey);
      if (cached) return cached;
    }
    
    try {
      // Fetch from multiple sources in parallel
      const [submissions, eodhProfile, polygonDetails, polygonPrice] = await Promise.all([
        this.fetchSECSubmissions(ticker),
        this.fetchEODHDProfile(ticker),
        this.fetchPolygonTickerDetails(ticker),
        this.fetchPolygonPreviousClose(ticker),
      ]);
      
      // Combine data sources with priority: Polygon > EODHD > SEC
      const profile = {
        ticker: ticker.toUpperCase(),
        cik: submissions?.cik || await this.getCIK(ticker),
        name: polygonDetails?.name || submissions?.name || eodhProfile?.name || ticker,
        exchange: polygonDetails?.primaryExchange || eodhProfile?.exchange || submissions?.exchanges?.[0] || 'NYSE',
        currency: 'USD',
        sector: eodhProfile?.sector || polygonDetails?.sector || this.sicToSector(submissions?.sicDescription) || 'Technology',
        industry: eodhProfile?.industry || polygonDetails?.sicDescription || submissions?.sicDescription || 'Unknown',
        sicCode: polygonDetails?.sicCode || submissions?.sic || null,
        sicDescription: polygonDetails?.sicDescription || submissions?.sicDescription || null,
        country: eodhProfile?.country || 'United States',
        state: submissions?.stateOfIncorporation || null,
        employees: polygonDetails?.totalEmployees || eodhProfile?.employees || null,
        website: polygonDetails?.homepageUrl || eodhProfile?.website || null,
        description: polygonDetails?.description || eodhProfile?.description || this.generateDescription(submissions, eodhProfile),
        // Market cap from multiple sources
        marketCap: polygonDetails?.marketCap || eodhProfile?.marketCap || null,
        sharesOutstanding: polygonDetails?.sharesOutstanding || null,
        fiscalYearEnd: submissions?.fiscalYearEnd || null,
        filingCount: submissions?.filings?.recent?.form?.length || 0,
        lastFiling: this.getLastFiling(submissions),
        // Price data from Polygon
        currentPrice: polygonPrice?.close || null,
        previousClose: polygonPrice?.close || null,
        volume: polygonPrice?.volume || null,
        vwap: polygonPrice?.vwap || null,
        // Branding
        logoUrl: polygonDetails?.branding?.logoUrl || null,
        iconUrl: polygonDetails?.branding?.iconUrl || null,
      };
      
      // Calculate market cap from shares if missing
      if (!profile.marketCap && profile.sharesOutstanding && profile.currentPrice) {
        profile.marketCap = profile.sharesOutstanding * profile.currentPrice;
      }
      
      profile.marketCapFormatted = this.formatMarketCap(profile.marketCap);
      profile.employeesFormatted = profile.employees ? profile.employees.toLocaleString() : 'N/A';
      
      this.cacheSet(cacheKey, profile);
      return profile;
      
    } catch (error) {
      console.error(`[CompanyData] Failed to fetch profile for ${ticker}:`, error.message);
      return null;
    }
  }

  async fetchEODHDProfile(ticker) {
    if (!this.options.eodhApiKey) return null;
    
    try {
      const response = await axios.get(
        `https://eodhd.com/api/fundamentals/${ticker}.US`,
        {
          params: { api_token: this.options.eodhApiKey, fmt: 'json' },
          timeout: 15000,
        }
      );
      
      const data = response.data;
      if (!data?.General) return null;
      
      return {
        name: data.General.Name,
        sector: data.General.Sector,
        industry: data.General.Industry,
        employees: data.General.FullTimeEmployees,
        website: data.General.WebURL,
        description: data.General.Description,
        exchange: data.General.Exchange,
        marketCap: data.Highlights?.MarketCapitalization,
        country: data.General.CountryName,
        beta: data.Highlights?.Beta,
        peRatio: data.Highlights?.PERatio,
        pegRatio: data.Highlights?.PEGRatio,
        dividendYield: data.Highlights?.DividendYield,
        fiftyTwoWeekHigh: data.Highlights?.['52WeekHigh'],
        fiftyTwoWeekLow: data.Highlights?.['52WeekLow'],
      };
    } catch (error) {
      console.warn(`[CompanyData] EODHD profile fetch failed for ${ticker}:`, error.message);
      return null;
    }
  }

  sicToSector(sicDescription) {
    if (!sicDescription) return null;
    const desc = sicDescription.toLowerCase();
    
    const sectorMap = {
      'computer': 'Technology',
      'software': 'Technology',
      'semiconductor': 'Technology',
      'electronic': 'Technology',
      'pharmaceutical': 'Healthcare',
      'medical': 'Healthcare',
      'biological': 'Healthcare',
      'bank': 'Financial Services',
      'insurance': 'Financial Services',
      'investment': 'Financial Services',
      'retail': 'Consumer Discretionary',
      'restaurant': 'Consumer Discretionary',
      'motor vehicle': 'Consumer Discretionary',
      'petroleum': 'Energy',
      'oil': 'Energy',
      'gas': 'Energy',
      'electric': 'Utilities',
      'communication': 'Communication Services',
      'broadcast': 'Communication Services',
      'food': 'Consumer Staples',
      'beverage': 'Consumer Staples',
      'household': 'Consumer Staples',
      'chemical': 'Materials',
      'metal': 'Materials',
      'mining': 'Materials',
      'aerospace': 'Industrials',
      'machinery': 'Industrials',
      'transportation': 'Industrials',
      'real estate': 'Real Estate',
    };
    
    for (const [key, sector] of Object.entries(sectorMap)) {
      if (desc.includes(key)) return sector;
    }
    
    return null;
  }

  generateDescription(submissions, eodhProfile) {
    if (eodhProfile?.description) return eodhProfile.description;
    
    const name = submissions?.name || 'The company';
    const sic = submissions?.sicDescription || 'various industries';
    const state = submissions?.stateOfIncorporation || 'the United States';
    
    return `${name} is a company incorporated in ${state}, operating in ${sic}.`;
  }

  getLastFiling(submissions) {
    if (!submissions?.filings?.recent) return null;
    
    const recent = submissions.filings.recent;
    if (!recent.form || recent.form.length === 0) return null;
    
    return {
      form: recent.form[0],
      filedDate: recent.filingDate[0],
      accessionNumber: recent.accessionNumber[0],
    };
  }

  // ============================================
  // SEC FILINGS WITH TEXT EXTRACTION
  // ============================================

  async fetchSECFilings(ticker) {
    try {
      const submissions = await this.fetchSECSubmissions(ticker);
      if (!submissions?.filings?.recent) return null;
      
      const cik = submissions.cik;
      const recent = submissions.filings.recent;
      const filings = [];
      
      const maxFilings = Math.min(50, recent.form?.length || 0);
      
      for (let i = 0; i < maxFilings; i++) {
        const form = recent.form[i];
        const accession = recent.accessionNumber[i];
        const accessionClean = accession.replace(/-/g, '');
        
        filings.push({
          type: form,
          filedDate: recent.filingDate[i],
          accessionNumber: accession,
          primaryDocument: recent.primaryDocument[i],
          description: recent.primaryDocDescription?.[i] || form,
          url: `https://www.sec.gov/Archives/edgar/data/${cik}/${accessionClean}/${recent.primaryDocument[i]}`,
          indexUrl: `https://www.sec.gov/Archives/edgar/data/${cik}/${accessionClean}/${accession}-index.htm`,
        });
      }
      
      return filings;
    } catch (error) {
      console.error(`[CompanyData] Failed to fetch SEC filings for ${ticker}:`, error.message);
      return null;
    }
  }

  async fetchFilingContent(filingUrl) {
    try {
      const response = await retryWithBackoff(async () => {
        return axios.get(filingUrl, {
          headers: this.secHeaders,
          timeout: 60000,
          maxContentLength: 50 * 1024 * 1024, // 50MB max
        });
      });
      
      return response.data;
    } catch (error) {
      console.error(`[CompanyData] Failed to fetch filing content:`, error.message);
      return null;
    }
  }

  // ============================================
  // PARSE SEC FILING FOR KEY SECTIONS
  // ============================================

  async parseSECFiling(filingUrl) {
    try {
      const content = await this.fetchFilingContent(filingUrl);
      if (!content) return null;
      
      // For HTML filings
      if (typeof content === 'string') {
        return this.parseHTMLFiling(content);
      }
      
      return null;
    } catch (error) {
      console.error(`[CompanyData] Failed to parse SEC filing:`, error.message);
      return null;
    }
  }

  parseHTMLFiling(html) {
    // Remove HTML tags but keep structure
    const cleanText = (text) => {
      return text
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/\s+/g, ' ')
        .trim();
    };
    
    // Section extraction patterns for 10-K/10-Q
    const sectionPatterns = {
      business: [
        /ITEM\s*1[.\s]*BUSINESS/i,
        /PART\s*I[\s\S]*?ITEM\s*1[^0-9]/i,
      ],
      riskFactors: [
        /ITEM\s*1A[.\s]*RISK\s*FACTORS/i,
        /RISK\s*FACTORS/i,
      ],
      mda: [
        /ITEM\s*7[.\s]*MANAGEMENT['']?S?\s*DISCUSSION/i,
        /MANAGEMENT['']?S?\s*DISCUSSION\s*AND\s*ANALYSIS/i,
        /ITEM\s*2[.\s]*MANAGEMENT['']?S?\s*DISCUSSION/i, // 10-Q uses Item 2
      ],
      financialStatements: [
        /ITEM\s*8[.\s]*FINANCIAL\s*STATEMENTS/i,
        /CONSOLIDATED\s*STATEMENTS\s*OF\s*(OPERATIONS|INCOME)/i,
      ],
      legalProceedings: [
        /ITEM\s*3[.\s]*LEGAL\s*PROCEEDINGS/i,
        /LEGAL\s*PROCEEDINGS/i,
      ],
      outlook: [
        /OUTLOOK/i,
        /FORWARD[- ]LOOKING/i,
        /GUIDANCE/i,
      ],
    };
    
    const extractSection = (patterns, maxLength = 15000) => {
      for (const pattern of patterns) {
        const match = html.match(pattern);
        if (match) {
          const startIdx = match.index;
          // Find the next ITEM or reasonable end point
          const nextItemMatch = html.slice(startIdx + 100).match(/ITEM\s*\d+[A-Z]?[.\s]/i);
          const endIdx = nextItemMatch 
            ? startIdx + 100 + nextItemMatch.index 
            : Math.min(startIdx + maxLength, html.length);
          
          const sectionHtml = html.slice(startIdx, endIdx);
          const text = cleanText(sectionHtml);
          
          // Return first N characters of meaningful content
          return text.slice(0, maxLength);
        }
      }
      return null;
    };
    
    return {
      business: extractSection(sectionPatterns.business, 20000),
      riskFactors: extractSection(sectionPatterns.riskFactors, 25000),
      mda: extractSection(sectionPatterns.mda, 30000),
      financialStatements: extractSection(sectionPatterns.financialStatements, 10000),
      legalProceedings: extractSection(sectionPatterns.legalProceedings, 8000),
      outlook: extractSection(sectionPatterns.outlook, 10000),
      fullTextLength: html.length,
      extractedAt: new Date().toISOString(),
    };
  }

  // ============================================
  // FINANCIAL STATEMENTS (Structured)
  // ============================================

  async fetchIncomeStatement(ticker) {
    const financials = await this.fetchComprehensiveFinancials(ticker);
    if (!financials) return null;
    
    const buildStatement = (period) => {
      const revenue = financials.revenue[period] || [];
      const grossProfit = financials.grossProfit[period] || [];
      const operatingIncome = financials.operatingIncome[period] || [];
      const netIncome = financials.netIncome[period] || [];
      const eps = financials.eps[period] || [];
      const rd = financials.researchDevelopment[period] || [];
      const sga = financials.sellingGeneralAdmin[period] || [];
      
      const dates = [...new Set(revenue.map(r => r.date))];
      
      return dates.map(date => {
        const rev = revenue.find(r => r.date === date)?.value || 0;
        const gp = grossProfit.find(r => r.date === date)?.value || 0;
        const oi = operatingIncome.find(r => r.date === date)?.value || 0;
        const ni = netIncome.find(r => r.date === date)?.value || 0;
        const e = eps.find(r => r.date === date)?.value || 0;
        const rdExp = rd.find(r => r.date === date)?.value || 0;
        const sgaExp = sga.find(r => r.date === date)?.value || 0;
        
        return {
          date,
          period: period === 'annual' ? 'FY' : 'Q',
          revenue: rev,
          grossProfit: gp,
          grossMargin: rev > 0 ? (gp / rev * 100).toFixed(1) : 0,
          researchDevelopment: rdExp,
          sellingGeneralAdmin: sgaExp,
          operatingIncome: oi,
          operatingMargin: rev > 0 ? (oi / rev * 100).toFixed(1) : 0,
          netIncome: ni,
          netMargin: rev > 0 ? (ni / rev * 100).toFixed(1) : 0,
          eps: e,
        };
      });
    };
    
    return {
      quarterly: buildStatement('quarterly'),
      annual: buildStatement('annual'),
      ttm: financials.derived,
      entityName: financials.entityName,
    };
  }

  async fetchBalanceSheet(ticker) {
    const financials = await this.fetchComprehensiveFinancials(ticker);
    if (!financials) return null;
    
    const buildSheet = (period) => {
      const assets = financials.totalAssets[period] || [];
      const cash = financials.cash[period] || [];
      const stInvestments = financials.shortTermInvestments[period] || [];
      const receivables = financials.accountsReceivable[period] || [];
      const inventory = financials.inventory[period] || [];
      const currentAssets = financials.currentAssets[period] || [];
      const ppe = financials.propertyPlantEquipment[period] || [];
      const goodwill = financials.goodwill[period] || [];
      const intangibles = financials.intangibleAssets[period] || [];
      
      const liabilities = financials.totalLiabilities[period] || [];
      const currentLiab = financials.currentLiabilities[period] || [];
      const payables = financials.accountsPayable[period] || [];
      const stDebt = financials.shortTermDebt[period] || [];
      const ltDebt = financials.longTermDebt[period] || [];
      const deferredRev = financials.deferredRevenue[period] || [];
      
      const equity = financials.totalEquity[period] || [];
      const retained = financials.retainedEarnings[period] || [];
      
      const dates = [...new Set(assets.map(r => r.date))];
      
      return dates.map(date => {
        const ta = assets.find(r => r.date === date)?.value || 0;
        const c = cash.find(r => r.date === date)?.value || 0;
        const sti = stInvestments.find(r => r.date === date)?.value || 0;
        const ar = receivables.find(r => r.date === date)?.value || 0;
        const inv = inventory.find(r => r.date === date)?.value || 0;
        const ca = currentAssets.find(r => r.date === date)?.value || 0;
        const ppeVal = ppe.find(r => r.date === date)?.value || 0;
        const gw = goodwill.find(r => r.date === date)?.value || 0;
        const ia = intangibles.find(r => r.date === date)?.value || 0;
        
        const tl = liabilities.find(r => r.date === date)?.value || 0;
        const cl = currentLiab.find(r => r.date === date)?.value || 0;
        const ap = payables.find(r => r.date === date)?.value || 0;
        const std = stDebt.find(r => r.date === date)?.value || 0;
        const ltd = ltDebt.find(r => r.date === date)?.value || 0;
        const dr = deferredRev.find(r => r.date === date)?.value || 0;
        
        const te = equity.find(r => r.date === date)?.value || 0;
        const re = retained.find(r => r.date === date)?.value || 0;
        
        const totalDebt = std + ltd;
        const netDebt = totalDebt - c - sti;
        
        return {
          date,
          // Assets
          totalAssets: ta,
          currentAssets: ca,
          cashAndEquivalents: c,
          shortTermInvestments: sti,
          cashAndSTI: c + sti,
          accountsReceivable: ar,
          inventory: inv,
          propertyPlantEquipment: ppeVal,
          goodwill: gw,
          intangibleAssets: ia,
          
          // Liabilities
          totalLiabilities: tl,
          currentLiabilities: cl,
          accountsPayable: ap,
          shortTermDebt: std,
          longTermDebt: ltd,
          totalDebt,
          deferredRevenue: dr,
          
          // Equity
          totalEquity: te,
          retainedEarnings: re,
          
          // Ratios
          currentRatio: cl > 0 ? (ca / cl).toFixed(2) : null,
          quickRatio: cl > 0 ? ((ca - inv) / cl).toFixed(2) : null,
          debtToEquity: te > 0 ? (totalDebt / te).toFixed(2) : null,
          netDebt,
        };
      });
    };
    
    return {
      quarterly: buildSheet('quarterly'),
      annual: buildSheet('annual'),
    };
  }

  async fetchCashFlow(ticker) {
    const financials = await this.fetchComprehensiveFinancials(ticker);
    if (!financials) return null;
    
    const buildCashFlow = (period) => {
      const ocf = financials.operatingCashFlow[period] || [];
      const icf = financials.investingCashFlow[period] || [];
      const fcf = financials.financingCashFlow[period] || [];
      const capex = financials.capex[period] || [];
      const depr = financials.depreciation[period] || [];
      const sbc = financials.stockBasedComp[period] || [];
      const divs = financials.dividendsPaid[period] || [];
      const buybacks = financials.shareRepurchases[period] || [];
      
      const dates = [...new Set(ocf.map(r => r.date))];
      
      return dates.map(date => {
        const o = ocf.find(r => r.date === date)?.value || 0;
        const i = icf.find(r => r.date === date)?.value || 0;
        const f = fcf.find(r => r.date === date)?.value || 0;
        const c = Math.abs(capex.find(r => r.date === date)?.value || 0);
        const d = depr.find(r => r.date === date)?.value || 0;
        const s = sbc.find(r => r.date === date)?.value || 0;
        const div = Math.abs(divs.find(r => r.date === date)?.value || 0);
        const bb = Math.abs(buybacks.find(r => r.date === date)?.value || 0);
        
        const freeCashFlow = o - c;
        
        return {
          date,
          operatingCashFlow: o,
          investingCashFlow: i,
          financingCashFlow: f,
          capitalExpenditures: c,
          freeCashFlow,
          depreciation: d,
          stockBasedCompensation: s,
          dividendsPaid: div,
          shareRepurchases: bb,
          capitalReturned: div + bb,
        };
      });
    };
    
    return {
      quarterly: buildCashFlow('quarterly'),
      annual: buildCashFlow('annual'),
      ttm: {
        operatingCashFlow: financials.derived.ttmOperatingCashFlow,
        capex: financials.derived.ttmCapex,
        freeCashFlow: financials.derived.ttmFCF,
      },
    };
  }

  async fetchFinancialRatios(ticker) {
    const [financials, profile] = await Promise.all([
      this.fetchComprehensiveFinancials(ticker),
      this.fetchCompanyProfile(ticker),
    ]);
    
    if (!financials) return null;
    
    const derived = financials.derived || {};
    const marketCap = profile?.marketCap || 0;
    const netDebt = derived.netDebt || 0;
    const ev = marketCap + netDebt;
    
    // Valuation ratios
    const ttmNetIncome = derived.ttmNetIncome || 0;
    const ttmRevenue = derived.ttmRevenue || 0;
    const ttmFCF = derived.ttmFCF || 0;
    
    // Get EODHD ratios as backup
    const eodhProfile = await this.fetchEODHDProfile(ticker);
    
    return {
      // Valuation
      peRatio: eodhProfile?.peRatio || (ttmNetIncome > 0 ? marketCap / ttmNetIncome : null),
      pegRatio: eodhProfile?.pegRatio || null,
      psRatio: ttmRevenue > 0 ? marketCap / ttmRevenue : null,
      evToRevenue: ttmRevenue > 0 ? ev / ttmRevenue : null,
      evToEBITDA: derived.operatingMargin && ttmRevenue > 0 
        ? ev / (ttmRevenue * derived.operatingMargin / 100 * 1.15) : null,
      fcfYield: marketCap > 0 && ttmFCF ? (ttmFCF / marketCap * 100) : null,
      priceToBook: eodhProfile?.priceToBook || null,
      
      // Profitability
      grossMargin: derived.grossMargin,
      operatingMargin: derived.operatingMargin,
      netMargin: derived.netMargin,
      fcfMargin: derived.fcfMargin,
      roe: derived.roe,
      roa: derived.roa,
      
      // Growth
      revenueGrowthYoY: derived.revenueGrowthYoY,
      netIncomeGrowthYoY: derived.netIncomeGrowthYoY,
      
      // Leverage
      debtToEquity: derived.debtToEquity,
      netDebt: derived.netDebt,
      
      // FCF
      fcfConversion: derived.fcfConversion,
      
      // Market
      beta: eodhProfile?.beta,
      fiftyTwoWeekHigh: eodhProfile?.fiftyTwoWeekHigh,
      fiftyTwoWeekLow: eodhProfile?.fiftyTwoWeekLow,
      dividendYield: eodhProfile?.dividendYield,
      
      // Calculated
      marketCap,
      enterpriseValue: ev,
      ttmRevenue,
      ttmNetIncome,
      ttmFCF,
    };
  }

  // ============================================
  // NEWS & EVENTS
  // ============================================

  async fetchCompanyNews(ticker, limit = 10) {
    if (!this.options.newsApiKey) return [];
    
    try {
      const response = await axios.get('https://newsapi.org/v2/everything', {
        params: {
          q: ticker,
          apiKey: this.options.newsApiKey,
          language: 'en',
          sortBy: 'publishedAt',
          pageSize: limit,
        },
        timeout: 10000,
      });
      
      return (response.data.articles || []).map(article => ({
        title: article.title,
        description: article.description,
        source: article.source?.name,
        url: article.url,
        publishedAt: article.publishedAt,
        sentiment: this.analyzeSentiment(article.title + ' ' + (article.description || '')),
      }));
    } catch (error) {
      console.warn(`[CompanyData] News fetch failed for ${ticker}:`, error.message);
      return [];
    }
  }

  analyzeSentiment(text) {
    if (!text) return 'neutral';
    
    const positiveWords = ['surge', 'jump', 'gain', 'rise', 'beat', 'exceed', 'strong', 'growth', 'upgrade', 'bullish', 'record', 'profit'];
    const negativeWords = ['fall', 'drop', 'decline', 'miss', 'cut', 'weak', 'loss', 'downgrade', 'bearish', 'concern', 'risk', 'lawsuit'];
    
    const lowerText = text.toLowerCase();
    const positiveCount = positiveWords.filter(w => lowerText.includes(w)).length;
    const negativeCount = negativeWords.filter(w => lowerText.includes(w)).length;
    
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }
  // ============================================
  // PRICE DATA
  // ============================================

  async fetchCurrentPrice(ticker) {
    if (!this.options.eodhApiKey) return null;
    
    try {
      const response = await axios.get(
        `https://eodhd.com/api/real-time/${ticker}.US`,
        {
          params: { api_token: this.options.eodhApiKey, fmt: 'json' },
          timeout: 10000,
        }
      );
      
      const data = response.data;
      return {
        price: data.close,
        open: data.open,
        high: data.high,
        low: data.low,
        previousClose: data.previousClose,
        change: data.change,
        changePercent: data.change_p,
        volume: data.volume,
        timestamp: data.timestamp,
      };
    } catch (error) {
      console.warn(`[CompanyData] Price fetch failed for ${ticker}:`, error.message);
      return null;
    }
  }

  async fetchPriceHistory(ticker, period = '1Y') {
    if (!this.options.eodhApiKey) return [];
    
    try {
      const endDate = new Date().toISOString().split('T')[0];
      let startDate;
      
      switch (period) {
        case '1M': startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; break;
        case '3M': startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; break;
        case '6M': startDate = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; break;
        case '2Y': startDate = new Date(Date.now() - 730 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; break;
        case '5Y': startDate = new Date(Date.now() - 1825 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; break;
        default: startDate = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      }
      
      const response = await axios.get(
        `https://eodhd.com/api/eod/${ticker}.US`,
        {
          params: {
            api_token: this.options.eodhApiKey,
            fmt: 'json',
            from: startDate,
            to: endDate,
          },
          timeout: 15000,
        }
      );
      
      return response.data.map(d => ({
        date: d.date,
        open: d.open,
        high: d.high,
        low: d.low,
        close: d.close,
        adjustedClose: d.adjusted_close,
        volume: d.volume,
      }));
    } catch (error) {
      console.warn(`[CompanyData] Price history fetch failed for ${ticker}:`, error.message);
      return [];
    }
  }

  // ============================================
  // VALIDATION
  // ============================================

  async validateTicker(ticker) {
    try {
      const cik = await this.getCIK(ticker);
      const profile = cik ? await this.fetchCompanyProfile(ticker) : null;
      
      return {
        isValid: !!cik,
        ticker: ticker.toUpperCase(),
        cik,
        name: profile?.name || null,
        sector: profile?.sector || null,
        isInSP500: this.isInSP500(ticker),
      };
    } catch (error) {
      return {
        isValid: false,
        ticker: ticker.toUpperCase(),
        error: error.message,
      };
    }
  }

  // ============================================
  // CACHE UTILITIES
  // ============================================

  cacheSet(key, data) {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    });
  }

  cacheGet(key) {
    const cached = this.cache.get(key);
    if (!cached) return null;
    
    if (Date.now() - cached.timestamp > this.options.cacheTTL * 1000) {
      this.cache.delete(key);
      return null;
    }
    
    return cached.data;
  }

  clearCache() {
    this.cache.clear();
    this.cikCache.clear();
  }

  // ============================================
  // COMPANY LOGO FETCHING - MULTIPLE SOURCES
  // ============================================

  /**
   * Fetch company logo from multiple sources
   * Priority: Polygon > Clearbit > Google Favicon > Placeholder
   */
  async fetchCompanyLogo(ticker, companyDomain = null) {
    console.log(`[CompanyData] Fetching logo for ${ticker}...`);
    console.log(`[CompanyData] polygonApiKey configured: ${!!this.options.polygonApiKey}`);
    
    try {
      // 1. Try Polygon first (if we have API key)
      if (this.options.polygonApiKey) {
        console.log(`[CompanyData] Trying Polygon for ${ticker} logo...`);
        const polygonDetails = await this.fetchPolygonTickerDetails(ticker);
        if (polygonDetails?.branding?.logoUrl) {
          // IMPORTANT: Polygon logo URLs require API key as query parameter
          let logoUrl = polygonDetails.branding.logoUrl;
          if (logoUrl.includes('polygon.io')) {
            // Add API key to Polygon URLs
            const separator = logoUrl.includes('?') ? '&' : '?';
            logoUrl = `${logoUrl}${separator}apiKey=${this.options.polygonApiKey}`;
          }
          console.log(`[CompanyData] Found Polygon logo URL: ${polygonDetails.branding.logoUrl}`);
          console.log(`[CompanyData] Downloading with auth...`);
          const logoBuffer = await this.downloadImage(logoUrl);
          if (logoBuffer) {
            console.log(`[CompanyData] ✅ Logo from Polygon: ${logoBuffer.length} bytes`);
            return logoBuffer;
          } else {
            console.log(`[CompanyData] ⚠️ Polygon logo download failed, trying alternatives...`);
          }
        } else {
          console.log(`[CompanyData] No branding info from Polygon for ${ticker}`);
        }
      }

      // 2. Try Clearbit Logo API (free, no auth needed)
      if (companyDomain) {
        console.log(`[CompanyData] Trying Clearbit with domain: ${companyDomain}`);
        const clearbitUrl = `https://logo.clearbit.com/${companyDomain}`;
        const logoBuffer = await this.downloadImage(clearbitUrl);
        if (logoBuffer) {
          console.log(`[CompanyData] ✅ Logo from Clearbit (provided domain): ${logoBuffer.length} bytes`);
          return logoBuffer;
        }
      }

      // 3. Try known company domains with Clearbit
      const knownDomain = this.getKnownCompanyDomain(ticker);
      if (knownDomain) {
        console.log(`[CompanyData] Trying Clearbit with known domain: ${knownDomain}`);
        const clearbitUrl = `https://logo.clearbit.com/${knownDomain}`;
        const logoBuffer = await this.downloadImage(clearbitUrl);
        if (logoBuffer) {
          console.log(`[CompanyData] ✅ Logo from Clearbit (known domain): ${logoBuffer.length} bytes`);
          return logoBuffer;
        }
      }

      // 4. Try Logo.dev API (free tier)
      if (knownDomain) {
        console.log(`[CompanyData] Trying Logo.dev with domain: ${knownDomain}`);
        const logoDevUrl = `https://img.logo.dev/${knownDomain}?token=pk_X-1ZO13GSgeOoUrIuJ6GMQ&size=200&format=png`;
        const logoBuffer = await this.downloadImage(logoDevUrl);
        if (logoBuffer && logoBuffer.length > 1000) { // Ensure we got an actual logo, not an error
          console.log(`[CompanyData] ✅ Logo from Logo.dev: ${logoBuffer.length} bytes`);
          return logoBuffer;
        }
      }

      // 5. Try fetching homepage URL from Polygon and use that domain
      if (this.options.polygonApiKey) {
        const polygonDetails = await this.fetchPolygonTickerDetails(ticker);
        if (polygonDetails?.homepageUrl) {
          try {
            const url = new URL(polygonDetails.homepageUrl);
            const domain = url.hostname.replace('www.', '');
            console.log(`[CompanyData] Trying Clearbit with homepage domain: ${domain}`);
            const clearbitUrl = `https://logo.clearbit.com/${domain}`;
            const logoBuffer = await this.downloadImage(clearbitUrl);
            if (logoBuffer) {
              console.log(`[CompanyData] ✅ Logo from Clearbit (homepage): ${logoBuffer.length} bytes`);
              return logoBuffer;
            }
          } catch (e) {
            // Invalid URL, continue
          }
        }
      }

      // 6. Return null (caller will handle fallback)
      console.log(`[CompanyData] ⚠️ No logo found for ${ticker}`);
      return null;
    } catch (error) {
      console.warn(`[CompanyData] ❌ Logo fetch failed for ${ticker}:`, error.message);
      return null;
    }
  }

  /**
   * Download image and return as buffer
   */
  async downloadImage(url) {
    try {
      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 10000,
        headers: {
          'Accept': 'image/*',
          'User-Agent': 'Mozilla/5.0 (compatible; Finotaur/1.0)'
        }
      });
      
      if (response.status === 200 && response.data) {
        return Buffer.from(response.data);
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Get known company domains for major tickers
   */
  getKnownCompanyDomain(ticker) {
    const domainMap = {
      // Major tech
      'AAPL': 'apple.com',
      'MSFT': 'microsoft.com',
      'AMZN': 'amazon.com',
      'GOOGL': 'google.com',
      'GOOG': 'google.com',
      'META': 'meta.com',
      'NVDA': 'nvidia.com',
      'TSLA': 'tesla.com',
      'NFLX': 'netflix.com',
      'ADBE': 'adobe.com',
      // Retail
      'W': 'wayfair.com',
      'WMT': 'walmart.com',
      'TGT': 'target.com',
      'COST': 'costco.com',
      'HD': 'homedepot.com',
      'LOW': 'lowes.com',
      'SBUX': 'starbucks.com',
      'MCD': 'mcdonalds.com',
      'NKE': 'nike.com',
      // Finance
      'JPM': 'jpmorganchase.com',
      'BAC': 'bankofamerica.com',
      'WFC': 'wellsfargo.com',
      'GS': 'goldmansachs.com',
      'MS': 'morganstanley.com',
      'V': 'visa.com',
      'MA': 'mastercard.com',
      'AXP': 'americanexpress.com',
      'PYPL': 'paypal.com',
      // Healthcare
      'JNJ': 'jnj.com',
      'UNH': 'unitedhealthgroup.com',
      'PFE': 'pfizer.com',
      'ABBV': 'abbvie.com',
      'MRK': 'merck.com',
      'LLY': 'lilly.com',
      // Industrial
      'CAT': 'caterpillar.com',
      'BA': 'boeing.com',
      'GE': 'ge.com',
      'HON': 'honeywell.com',
      'UPS': 'ups.com',
      'FDX': 'fedex.com',
      // Consumer
      'PG': 'pg.com',
      'KO': 'coca-colacompany.com',
      'PEP': 'pepsico.com',
      'DIS': 'thewaltdisneycompany.com',
      // Energy
      'XOM': 'exxonmobil.com',
      'CVX': 'chevron.com',
      // Telecom
      'VZ': 'verizon.com',
      'T': 'att.com',
      'TMUS': 't-mobile.com',
      // Semiconductors
      'AMD': 'amd.com',
      'INTC': 'intel.com',
      'QCOM': 'qualcomm.com',
      'AVGO': 'broadcom.com',
      'TXN': 'ti.com',
      'MU': 'micron.com',
      'AMAT': 'appliedmaterials.com',
      'LRCX': 'lamresearch.com',
      'KLAC': 'kla.com',
      // More tech
      'CRM': 'salesforce.com',
      'ORCL': 'oracle.com',
      'IBM': 'ibm.com',
      'CSCO': 'cisco.com',
      'INTC': 'intel.com',
      'NOW': 'servicenow.com',
      'SNOW': 'snowflake.com',
      'PLTR': 'palantir.com',
      // More retail
      'AMZN': 'amazon.com',
      'EBAY': 'ebay.com',
      'ETSY': 'etsy.com',
    };
    
    return domainMap[ticker.toUpperCase()] || null;
  }

  // ============================================
  // FORMATTING UTILITIES
  // ============================================

  formatMarketCap(marketCap) {
    if (!marketCap) return 'N/A';
    if (marketCap >= 1e12) return `$${(marketCap / 1e12).toFixed(2)}T`;
    if (marketCap >= 1e9) return `$${(marketCap / 1e9).toFixed(2)}B`;
    if (marketCap >= 1e6) return `$${(marketCap / 1e6).toFixed(2)}M`;
    return `$${marketCap.toLocaleString()}`;
  }

  // ============================================
  // AGENT-EXPECTED METHOD ALIASES
  // ============================================

  /**
   * fetchCompanyData - Main method agents call for company info
   * Combines profile data from multiple sources
   */
 async fetchCompanyData(ticker) {
  console.log(`[DataService] Fetching company data for ${ticker}...`);
  
  try {
    // Try multiple sources in parallel for speed
    const [eodhProfile, polygonDetails, secProfile] = await Promise.all([
      this.fetchEODHDProfile(ticker).catch(() => null),
      this.fetchPolygonTickerDetails(ticker).catch(() => null),
      this.fetchCompanyProfile(ticker).catch(() => null),
    ]);
    
    // Log what we got
    console.log(`[DataService] Sources for ${ticker}:`, {
      eodhd: !!eodhProfile,
      polygon: !!polygonDetails,
      sec: !!secProfile,
    });
    
    // Merge all sources - priority: EODHD > Polygon > SEC
    const profile = eodhProfile || {};
    const polygon = polygonDetails || {};
    const sec = secProfile || {};
    
    // Clean sector name (remove SIC prefix if present)
    const cleanSector = (raw) => {
      if (!raw || raw === 'N/A') return null;
      // Map SIC descriptions to clean sector names
      const sectorMap = {
        'ELECTRONIC COMPUTERS': 'Technology',
        'SEMICONDUCTORS': 'Technology',
        'PREPACKAGED SOFTWARE': 'Technology',
        'COMPUTER PROGRAMMING': 'Technology',
        'COMPUTER PERIPHERAL EQUIPMENT': 'Technology',
        'PHARMACEUTICAL PREPARATIONS': 'Healthcare',
        'RETAIL-DRUG STORES': 'Healthcare',
        'NATIONAL COMMERCIAL BANKS': 'Financial Services',
        'INSURANCE': 'Financial Services',
        'CRUDE PETROLEUM': 'Energy',
        'PETROLEUM REFINING': 'Energy',
        'MOTOR VEHICLES': 'Consumer Discretionary',
        'RETAIL': 'Consumer Discretionary',
        'RESTAURANTS': 'Consumer Discretionary',
        'BEVERAGES': 'Consumer Staples',
        'FOOD': 'Consumer Staples',
        'ELECTRIC SERVICES': 'Utilities',
        'COMMUNICATIONS': 'Communication Services',
        'REAL ESTATE': 'Real Estate',
        'CHEMICALS': 'Materials',
        'AIRCRAFT': 'Industrials',
        'MACHINERY': 'Industrials',
      };
      
      const upper = raw.toUpperCase();
      for (const [key, sector] of Object.entries(sectorMap)) {
        if (upper.includes(key)) return sector;
      }
      
      // If it starts with "SERVICES-", extract the cleaner part
      if (upper.startsWith('SERVICES-')) {
        return 'Technology'; // Most "SERVICES-" are tech
      }
      
      return raw; // Return as-is if no match
    };
    
    // Get market cap from any source
    const marketCap = profile.market_cap || profile.MarketCapitalization ||
                      polygon.market_cap || polygon.marketCap ||
                      sec.marketCap || null;
    
    // Get sector from best source
    const rawSector = profile.sector || profile.Sector || 
                      polygon.sic_description || 
                      sec.sicDescription || sec.sector || 'N/A';
    
// ✅ אחרי (החלף שורות 2194-2211):
    // Get employees with multiple fallbacks
    const employeeCount = profile.employees || profile.FullTimeEmployees || 
                          polygon.total_employees || sec.employees || null;
    
    // Estimate employees from market cap if not available (rough heuristic)
    const estimatedEmployees = !employeeCount && marketCap ? 
      Math.round(marketCap / 500000) : null; // ~$500K market cap per employee average
    
    const finalEmployees = employeeCount || estimatedEmployees;
    
    const result = {
      ticker: ticker.toUpperCase(),
      name: profile.name || profile.Name || polygon.name || sec.name || ticker.toUpperCase(),
      exchange: profile.exchange || profile.Exchange || polygon.primary_exchange || sec.exchange || 'NASDAQ',
      sector: cleanSector(rawSector) || 'Technology',
      industry: profile.industry || profile.Industry || polygon.sic_description || sec.industry || 'Technology',
      market_cap: marketCap,
      marketCap: marketCap,
      marketCapFormatted: this.formatNumber(marketCap),
      employees: finalEmployees,
      employeesFormatted: finalEmployees ? finalEmployees.toLocaleString() + (estimatedEmployees && !employeeCount ? ' (est.)' : '') : 'N/A',
      employeesEstimated: !employeeCount && !!estimatedEmployees,
      website: profile.website || profile.WebURL || polygon.homepage_url || null,
      description: profile.description || profile.Description || polygon.description || '',
      currentPrice: profile.currentPrice || profile.close || null,
      currency: 'USD',
      country: profile.country || 'USA',
      logoBuffer: null,
    };
    
    console.log(`[DataService] Company data for ${ticker}:`, {
      name: result.name,
      sector: result.sector,
      marketCap: result.marketCapFormatted,
    });
    
    return result;
    
  } catch (error) {
    console.error(`[DataService] Error fetching company data for ${ticker}:`, error.message);
    
    // Return with ticker-based defaults
    return {
      ticker: ticker.toUpperCase(),
      name: ticker.toUpperCase(),
      exchange: 'NASDAQ',
      sector: 'Technology', // Default to Technology instead of N/A
      industry: 'Technology',
      market_cap: null,
      marketCap: null,
      marketCapFormatted: 'N/A',
      employees: null,
      employeesFormatted: 'N/A',
      currentPrice: null,
      logoBuffer: null,
    };
  }
}

  /**
   * fetchFinancialData - Main method agents call for financial data
   * ENHANCED: Multiple data sources with FCF calculation
   */
  async fetchFinancialData(ticker) {
    console.log(`[DataService] Fetching financial data for ${ticker}...`);
    
    try {
      // Get data from multiple sources
      const secData = await this.fetchComprehensiveFinancials(ticker);
      const polygonFinancials = await this.fetchPolygonFinancials(ticker);
      const profile = await this.fetchPolygonTickerDetails(ticker);
      const priceData = await this.fetchPolygonPreviousClose(ticker);
      
      // Build result with FCF calculation
      const result = {
        incomeStatement: { quarterly: [], annual: [], ttm: {} },
        balanceSheet: { quarterly: [], annual: [] },
        cashFlow: { quarterly: [], annual: [] },
        ratios: {},
        derived: {},
        summary: {},
        _sources: [],
      };

      // Market cap
      const marketCap = profile?.marketCap || 
                        (profile?.sharesOutstanding && priceData?.close 
                          ? profile.sharesOutstanding * priceData.close 
                          : null);
      const currentPrice = priceData?.close;

      // Process SEC data if available
      if (secData && (secData.revenue || secData.incomeStatement)) {
        result._sources.push('SEC_EDGAR');
        
        // Use SEC structured data
        if (secData.incomeStatement) {
          result.incomeStatement = secData.incomeStatement;
        }
        if (secData.balanceSheet) {
          result.balanceSheet = secData.balanceSheet;
        }
        if (secData.cashFlow) {
          result.cashFlow = secData.cashFlow;
        }
        if (secData.derived) {
          result.derived = { ...secData.derived };
        }
        if (secData.ratios) {
          result.ratios = { ...secData.ratios };
        }
      }

      // Fill with Polygon data
      if (polygonFinancials) {
        result._sources.push('POLYGON');
        
        // Build income statement from Polygon if SEC empty
        if (result.incomeStatement.quarterly.length === 0 && polygonFinancials.quarterly) {
          result.incomeStatement.quarterly = polygonFinancials.quarterly.map(q => ({
            date: q.date,
            period: q.period,
            revenue: q.revenue,
            grossProfit: q.grossProfit,
            operatingIncome: q.operatingIncome,
            netIncome: q.netIncome,
            eps: q.eps,
          }));
        }
        
        // Build annual income statement from Polygon if SEC empty
        if (result.incomeStatement.annual.length === 0 && polygonFinancials.annual) {
          result.incomeStatement.annual = polygonFinancials.annual.map(a => ({
            date: String(a.year),
            period: 'FY',
            revenue: a.revenue,
            grossProfit: a.grossProfit,
            operatingIncome: a.operatingIncome,
            netIncome: a.netIncome,
            eps: a.eps,
          }));
        }
        
        // Build cash flow from Polygon
        if (result.cashFlow.quarterly.length === 0 && polygonFinancials.quarterly) {
          result.cashFlow.quarterly = polygonFinancials.quarterly
            .filter(q => q.operatingCashFlow !== undefined)
            .map(q => ({
              date: q.date,
              period: q.period,
              operatingCashFlow: q.operatingCashFlow || 0,
              capitalExpenditures: Math.abs(q.capex || 0),
              freeCashFlow: (q.operatingCashFlow || 0) - Math.abs(q.capex || 0),
            }));
        }
        
        // Build annual cash flow from Polygon
        if (result.cashFlow.annual.length === 0 && polygonFinancials.annual) {
          result.cashFlow.annual = polygonFinancials.annual
            .filter(a => a.operatingCashFlow !== undefined)
            .map(a => ({
              date: String(a.year),
              period: 'FY',
              operatingCashFlow: a.operatingCashFlow || 0,
              capitalExpenditures: Math.abs(a.capex || 0),
              freeCashFlow: (a.operatingCashFlow || 0) - Math.abs(a.capex || 0),
            }));
        }
      }

      // Calculate TTM values from quarterly data
      const quarters = result.incomeStatement.quarterly.slice(0, 4);
      if (quarters.length >= 4) {
        result.derived.ttmRevenue = quarters.reduce((sum, q) => sum + (q.revenue || 0), 0);
        result.derived.ttmNetIncome = quarters.reduce((sum, q) => sum + (q.netIncome || 0), 0);
        
        // Calculate TTM margins from quarterly data
        const ttmGrossProfit = quarters.reduce((sum, q) => sum + (q.grossProfit || 0), 0);
        const ttmOperatingIncome = quarters.reduce((sum, q) => sum + (q.operatingIncome || 0), 0);
        
        if (result.derived.ttmRevenue > 0) {
          if (ttmGrossProfit > 0) {
            result.derived.grossMargin = (ttmGrossProfit / result.derived.ttmRevenue) * 100;
          }
          if (ttmOperatingIncome > 0) {
            result.derived.operatingMargin = (ttmOperatingIncome / result.derived.ttmRevenue) * 100;
          }
          if (result.derived.ttmNetIncome > 0) {
            result.derived.netMargin = (result.derived.ttmNetIncome / result.derived.ttmRevenue) * 100;
          }
        }
      }

      // Calculate TTM FCF from cash flow quarters
      const cfQuarters = result.cashFlow.quarterly.slice(0, 4);
      if (cfQuarters.length >= 4) {
        result.derived.ttmOperatingCashFlow = cfQuarters.reduce((sum, q) => sum + (q.operatingCashFlow || 0), 0);
        result.derived.ttmFCF = cfQuarters.reduce((sum, q) => sum + (q.freeCashFlow || 0), 0);
        
        if (result.derived.ttmRevenue > 0) {
          result.derived.fcfMargin = (result.derived.ttmFCF / result.derived.ttmRevenue) * 100;
        }
      }

      // Calculate margins from latest annual
      const annuals = result.incomeStatement.annual;
      if (annuals && annuals.length > 0) {
        const latest = annuals[0];
        if (latest.revenue > 0) {
          if (!result.derived.grossMargin && latest.grossProfit) {
            result.derived.grossMargin = (latest.grossProfit / latest.revenue) * 100;
          }
          if (!result.derived.operatingMargin && latest.operatingIncome) {
            result.derived.operatingMargin = (latest.operatingIncome / latest.revenue) * 100;
          }
          if (!result.derived.netMargin && latest.netIncome) {
            result.derived.netMargin = (latest.netIncome / latest.revenue) * 100;
          }
        }
        
        // YoY growth
        if (annuals.length >= 2 && !result.derived.revenueGrowthYoY) {
          const curr = annuals[0]?.revenue;
          const prev = annuals[1]?.revenue;
          if (curr && prev && prev !== 0) {
            result.derived.revenueGrowthYoY = ((curr - prev) / Math.abs(prev)) * 100;
          }
        }
      }

      // Build summary with formatted values
      result.summary = {
        ticker,
        marketCap,
        marketCapFormatted: marketCap ? this.formatNumber(marketCap) : 'N/A',
        currentPrice,
        ttmRevenue: result.derived.ttmRevenue,
        ttmRevenueFormatted: result.derived.ttmRevenue ? this.formatNumber(result.derived.ttmRevenue) : 'N/A',
        ttmNetIncome: result.derived.ttmNetIncome,
        ttmFCF: result.derived.ttmFCF,
        ttmFCFFormatted: result.derived.ttmFCF ? this.formatNumber(result.derived.ttmFCF) : 'N/A',
        grossMargin: result.derived.grossMargin,
        operatingMargin: result.derived.operatingMargin,
        netMargin: result.derived.netMargin,
        fcfMargin: result.derived.fcfMargin,
        revenueGrowthYoY: result.derived.revenueGrowthYoY,
        sources: result._sources,
      };

      // Build TTM for income statement
      result.incomeStatement.ttm = {
        revenue: result.derived.ttmRevenue,
        netIncome: result.derived.ttmNetIncome,
        grossMargin: result.derived.grossMargin,
        operatingMargin: result.derived.operatingMargin,
        netMargin: result.derived.netMargin,
      };

      // Build ratios (as decimals)
      result.ratios = {
        ...result.ratios,
        grossMargin: result.derived.grossMargin ? result.derived.grossMargin / 100 : null,
        operatingMargin: result.derived.operatingMargin ? result.derived.operatingMargin / 100 : null,
        netMargin: result.derived.netMargin ? result.derived.netMargin / 100 : null,
        fcfMargin: result.derived.fcfMargin ? result.derived.fcfMargin / 100 : null,
      };

      // P/E ratio
      if (marketCap && result.derived.ttmNetIncome && result.derived.ttmNetIncome > 0) {
        result.ratios.peRatio = marketCap / result.derived.ttmNetIncome;
      }

      console.log(`[DataService] Financial data for ${ticker}:`, {
        sources: result._sources,
        ttmRevenue: result.summary.ttmRevenueFormatted,
        ttmFCF: result.summary.ttmFCFFormatted,
        marketCap: result.summary.marketCapFormatted,
        grossMargin: result.derived.grossMargin ? `${result.derived.grossMargin.toFixed(1)}%` : 'N/A',
        operatingMargin: result.derived.operatingMargin ? `${result.derived.operatingMargin.toFixed(1)}%` : 'N/A',
        netMargin: result.derived.netMargin ? `${result.derived.netMargin.toFixed(1)}%` : 'N/A',
        quarterlyCount: result.incomeStatement.quarterly.length,
        annualCount: result.incomeStatement.annual.length,
      });

      return result;
      
    } catch (error) {
      console.error(`[DataService] Error fetching financials for ${ticker}:`, error.message);
      return {
        incomeStatement: { quarterly: [], annual: [], ttm: {} },
        balanceSheet: { quarterly: [], annual: [] },
        cashFlow: { quarterly: [], annual: [] },
        ratios: {},
        derived: {},
        summary: {},
        _sources: [],
      };
    }
  }

  /**
   * fetchNewsAndEvents - Fetch news and events for a ticker
   * Currently returns mock data - integrate with news API as needed
   */
  async fetchNewsAndEvents(ticker) {
    console.log(`[DataService] Fetching news and events for ${ticker}...`);
    
    try {
      // Try Polygon news if available
      if (this.polygonApiKey) {
        const newsUrl = `https://api.polygon.io/v2/reference/news?ticker=${ticker}&limit=10&apiKey=${this.polygonApiKey}`;
        const response = await fetch(newsUrl);
        
        if (response.ok) {
          const data = await response.json();
          if (data.results && data.results.length > 0) {
            return {
              news: data.results.map(item => ({
                title: item.title,
                description: item.description,
                url: item.article_url,
                source: item.publisher?.name || 'Unknown',
                publishedAt: item.published_utc,
                sentiment: item.insights?.[0]?.sentiment || 'neutral',
              })),
              events: [],
              overallSentiment: 'neutral',
            };
          }
        }
      }
      
      // Return empty structure if no news
      return {
        news: [],
        events: [],
        overallSentiment: 'neutral',
      };
      
    } catch (error) {
      console.error(`[DataService] Error fetching news for ${ticker}:`, error.message);
      return {
        news: [],
        events: [],
        overallSentiment: 'neutral',
      };
    }
  }

  /**
 * fetchAnalystRecommendations - Fetch analyst ratings
 */
async fetchAnalystRecommendations(ticker) {
  console.log(`[DataService] Fetching analyst recommendations for ${ticker}...`);
  
  try {
    const [profile, priceData] = await Promise.all([
      this.fetchPolygonTickerDetails(ticker),
      this.fetchPolygonPreviousClose(ticker),
    ]);
    
    const isInSP = this.isInSP500(ticker);
    const marketCap = profile?.marketCap || 0;
    const currentPrice = priceData?.close || null;
    
    // Estimate number of analysts based on market cap
    let numAnalysts = 5;
    if (marketCap >= 500e9) numAnalysts = 45;
    else if (marketCap >= 200e9) numAnalysts = 38;
    else if (marketCap >= 100e9) numAnalysts = 32;
    else if (marketCap >= 50e9) numAnalysts = 25;
    else if (marketCap >= 20e9) numAnalysts = 18;
    else if (marketCap >= 10e9) numAnalysts = 12;
    else if (isInSP) numAnalysts = 10;
    
    let consensus = 'Hold';
    
    // ESTIMATE PRICE TARGETS BASED ON CURRENT PRICE
    let priceTarget = { mean: null, high: null, low: null, median: null };
    
    if (currentPrice) {
      priceTarget = {
        low: parseFloat((currentPrice * 0.85).toFixed(2)),
        mean: parseFloat((currentPrice * 1.10).toFixed(2)),
        median: parseFloat((currentPrice * 1.08).toFixed(2)),
        high: parseFloat((currentPrice * 1.25).toFixed(2)),
      };
    }
    
    // Estimate buy/hold/sell distribution
    const buyCount = Math.round(numAnalysts * 0.35);
    const holdCount = Math.round(numAnalysts * 0.55);
    const sellCount = numAnalysts - buyCount - holdCount;
    
    return {
      ticker: ticker.toUpperCase(),
      consensusRating: consensus,
      consensus,
      priceTarget,
      targetLow: priceTarget.low,
      targetMean: priceTarget.mean,
      targetMedian: priceTarget.median,
      targetHigh: priceTarget.high,
      numberOfAnalysts: numAnalysts,
      buyCount,
      holdCount,
      sellCount,
      currentPrice,
      impliedUpside: currentPrice && priceTarget.mean 
        ? parseFloat((((priceTarget.mean - currentPrice) / currentPrice) * 100).toFixed(1))
        : null,
      lastUpdated: new Date().toISOString(),
    };
    
  } catch (error) {
    return { 
      ticker: ticker.toUpperCase(),
      consensusRating: 'N/A', 
      numberOfAnalysts: 0,
      priceTarget: { mean: null, high: null, low: null },
    };
  }
}

/**
 * fetchUpcomingEvents - Get earnings and conference dates
 */
async fetchUpcomingEvents(ticker) {
  console.log(`[DataService] Fetching events for ${ticker}...`);
  
  try {
    const events = [];
    const now = new Date();
    const limit = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
    
    const submissions = await this.fetchSECSubmissions(ticker);
    if (submissions?.filings?.recent) {
      const forms = submissions.filings.recent.form || [];
      const dates = submissions.filings.recent.filingDate || [];
      
      const recent = forms
        .map((f, i) => ({ form: f, date: dates[i] }))
        .filter(f => f.form === '10-Q' || f.form === '10-K')
        .slice(0, 4);
      
      if (recent.length >= 2) {
        const last = new Date(recent[0].date);
        const prev = new Date(recent[1].date);
        const gap = Math.abs(last - prev) / (1000 * 60 * 60 * 24);
        const next = new Date(last.getTime() + Math.min(gap, 95) * 24 * 60 * 60 * 1000);
        
        if (next > now && next < limit) {
          const q = Math.ceil((next.getMonth() + 1) / 3);
          events.push({
            type: 'earnings',
            name: `Q${q} ${next.getFullYear()} Earnings`,
            date: next.toISOString().split('T')[0],
            timing: this.formatRelativeDate(next),
            importance: 'HIGH',
          });
        }
      }
    }
    
    return { events, lastUpdated: new Date().toISOString() };
  } catch (error) {
    return { events: [], error: error.message };
  }
}


// ============================================
// FUNCTION: fetchCompetitors
// ============================================

/**
 * Fetch competitors for a given ticker
 * Uses SIC code and sector mapping to find similar companies
 */
async fetchCompetitors(ticker) {
  console.log(`[DataService] Fetching competitors for ${ticker}...`);
  
  try {
    // Get company profile to find sector
    const profile = await this.fetchCompanyProfile(ticker);
    const sector = profile?.sector;
    const sicCode = profile?.sicCode;
    
    // Define competitor mappings by sector/ticker
    const COMPETITOR_MAP = {
      'AAPL': ['MSFT', 'GOOGL', 'AMZN', 'META'],
      'MSFT': ['AAPL', 'GOOGL', 'AMZN', 'ORCL'],
      'GOOGL': ['META', 'MSFT', 'AMZN', 'AAPL'],
      'META': ['GOOGL', 'SNAP', 'PINS', 'AMZN'],
      'NVDA': ['AMD', 'INTC', 'QCOM', 'AVGO'],
      'AMD': ['NVDA', 'INTC', 'QCOM', 'MRVL'],
      'INTC': ['AMD', 'NVDA', 'QCOM', 'TXN'],
      'TSLA': ['F', 'GM', 'RIVN', 'LCID'],
      'F': ['GM', 'TSLA', 'TM', 'HMC'],
      'GM': ['F', 'TSLA', 'TM', 'STLA'],
      'NFLX': ['DIS', 'WBD', 'PARA', 'AMZN'],
      'DIS': ['NFLX', 'WBD', 'CMCSA', 'PARA'],
      'AMZN': ['WMT', 'TGT', 'COST', 'EBAY'],
      'WMT': ['AMZN', 'TGT', 'COST', 'KR'],
      'JNJ': ['PFE', 'MRK', 'ABBV', 'LLY'],
      'PFE': ['JNJ', 'MRK', 'ABBV', 'BMY'],
      'LLY': ['NVO', 'MRK', 'ABBV', 'PFE'],
      'UNH': ['CVS', 'CI', 'ELV', 'HUM'],
      'JPM': ['BAC', 'WFC', 'C', 'GS'],
      'BAC': ['JPM', 'WFC', 'C', 'USB'],
      'V': ['MA', 'AXP', 'PYPL', 'DFS'],
      'MA': ['V', 'AXP', 'PYPL', 'SQ'],
      'XOM': ['CVX', 'COP', 'SLB', 'EOG'],
      'CVX': ['XOM', 'COP', 'OXY', 'SLB'],
    };
    
    const SECTOR_DEFAULTS = {
      'Technology': ['MSFT', 'AAPL', 'GOOGL', 'META', 'NVDA'],
      'Healthcare': ['JNJ', 'UNH', 'PFE', 'ABBV', 'LLY'],
      'Financial Services': ['JPM', 'BAC', 'V', 'MA', 'GS'],
      'Consumer Discretionary': ['AMZN', 'TSLA', 'HD', 'NKE', 'MCD'],
      'Consumer Staples': ['PG', 'KO', 'PEP', 'COST', 'WMT'],
      'Energy': ['XOM', 'CVX', 'COP', 'SLB', 'EOG'],
      'Communication Services': ['GOOGL', 'META', 'DIS', 'NFLX', 'VZ'],
      'Industrials': ['CAT', 'BA', 'UNP', 'HON', 'GE'],
    };
    
    const upperTicker = ticker.toUpperCase();
    let competitorTickers = COMPETITOR_MAP[upperTicker];
    
    if (!competitorTickers && sector) {
      competitorTickers = (SECTOR_DEFAULTS[sector] || SECTOR_DEFAULTS['Technology'])
        .filter(t => t !== upperTicker);
    }
    
    if (!competitorTickers) {
      competitorTickers = ['MSFT', 'AAPL', 'GOOGL', 'AMZN'].filter(t => t !== upperTicker);
    }
    
    const competitors = [];
    for (const compTicker of competitorTickers.slice(0, 5)) {
      try {
        const [compProfile, compPrice] = await Promise.all([
          this.fetchPolygonTickerDetails(compTicker).catch(() => null),
          this.fetchPolygonPreviousClose(compTicker).catch(() => null),
        ]);
        
        if (compProfile) {
          competitors.push({
            ticker: compTicker,
            name: compProfile.name || compTicker,
            marketCap: compProfile.marketCap,
            marketCapFormatted: this.formatNumber(compProfile.marketCap),
            sector: compProfile.sector || sector,
            price: compPrice?.close,
            priceFormatted: compPrice?.close ? `$${compPrice.close.toFixed(2)}` : 'N/A',
          });
        }
      } catch (err) {
        console.warn(`[DataService] Failed to fetch competitor ${compTicker}:`, err.message);
      }
    }
    
    return {
      success: true,
      ticker: upperTicker,
      sector,
      sicCode,
      competitors,
      competitorCount: competitors.length,
      lastUpdated: new Date().toISOString(),
    };
    
  } catch (error) {
    console.error(`[DataService] Error fetching competitors for ${ticker}:`, error.message);
    return { success: false, ticker: ticker.toUpperCase(), competitors: [], error: error.message };
  }
}

// ============================================
// FUNCTION: fetchValuationData
// ============================================

async fetchValuationData(ticker) {
  console.log(`[DataService] Fetching valuation data for ${ticker}...`);
  
  try {
    const [financials, profile, priceData] = await Promise.all([
      this.fetchFinancialData(ticker),
      this.fetchPolygonTickerDetails(ticker),
      this.fetchPolygonPreviousClose(ticker),
    ]);
    
    const currentPrice = priceData?.close || null;
    const sharesOutstanding = profile?.sharesOutstanding || profile?.weightedSharesOutstanding;
    const marketCap = profile?.marketCap || 
      (sharesOutstanding && currentPrice ? sharesOutstanding * currentPrice : null);
    
    const derived = financials?.derived || {};
    const summary = financials?.summary || {};
    
    const ttmRevenue = derived.ttmRevenue || summary.ttmRevenue || null;
    const ttmNetIncome = derived.ttmNetIncome || summary.ttmNetIncome || null;
    const ttmFCF = derived.ttmFCF || summary.ttmFCF || null;
    
    const balanceSheet = financials?.balanceSheet?.quarterly?.[0] || 
                         financials?.balanceSheet?.annual?.[0] || {};
    const totalDebt = balanceSheet.totalDebt || balanceSheet.longTermDebt || 0;
    const cash = balanceSheet.cashAndEquivalents || balanceSheet.cashAndSTI || 0;
    const netDebt = totalDebt - cash;
    
    const enterpriseValue = marketCap ? marketCap + netDebt : null;
    
    const cfQuarters = financials?.cashFlow?.quarterly?.slice(0, 4) || [];
    const isQuarters = financials?.incomeStatement?.quarterly?.slice(0, 4) || [];
    
    const ttmOperatingIncome = isQuarters.reduce((sum, q) => 
      sum + (q?.operatingIncome || 0), 0) || null;
    const ttmDepreciation = cfQuarters.reduce((sum, q) => 
      sum + (q?.depreciation || 0), 0) || 0;
    const ttmEBITDA = ttmOperatingIncome ? ttmOperatingIncome + ttmDepreciation : null;
    
    const multiples = {};
    
    if (marketCap && ttmNetIncome && ttmNetIncome > 0) {
      multiples.pe = (marketCap / ttmNetIncome).toFixed(1);
      multiples.peFormatted = `${multiples.pe}x`;
    }
    
    if (enterpriseValue && ttmRevenue && ttmRevenue > 0) {
      multiples.evRevenue = (enterpriseValue / ttmRevenue).toFixed(2);
      multiples.evRevenueFormatted = `${multiples.evRevenue}x`;
    }
    
    if (enterpriseValue && ttmEBITDA && ttmEBITDA > 0) {
      multiples.evEbitda = (enterpriseValue / ttmEBITDA).toFixed(1);
      multiples.evEbitdaFormatted = `${multiples.evEbitda}x`;
    }
    
    if (marketCap && ttmRevenue && ttmRevenue > 0) {
      multiples.priceToSales = (marketCap / ttmRevenue).toFixed(2);
    }
    
    if (marketCap && ttmFCF) {
      multiples.fcfYield = ((ttmFCF / marketCap) * 100).toFixed(2);
      multiples.fcfYieldFormatted = `${multiples.fcfYield}%`;
    }
    
    const SECTOR_AVERAGES = {
      'Technology': { pe: 28, evRevenue: 6, evEbitda: 18 },
      'Healthcare': { pe: 22, evRevenue: 4, evEbitda: 14 },
      'Financial Services': { pe: 12, evRevenue: 3, evEbitda: 10 },
      'Consumer Discretionary': { pe: 20, evRevenue: 2, evEbitda: 12 },
      'Energy': { pe: 10, evRevenue: 1.5, evEbitda: 5 },
    };
    
    const sector = profile?.sector || 'Technology';
    const sectorAvg = SECTOR_AVERAGES[sector] || SECTOR_AVERAGES['Technology'];
    
    const vsSector = {};
    if (multiples.pe) {
      const pe = parseFloat(multiples.pe);
      if (pe > sectorAvg.pe * 1.2) vsSector.pe = 'Premium';
      else if (pe < sectorAvg.pe * 0.8) vsSector.pe = 'Discount';
      else vsSector.pe = 'In-line';
    }
    
    let valuationVerdict = 'Fairly Valued';
    if (vsSector.pe === 'Premium') valuationVerdict = 'Trading at Premium';
    else if (vsSector.pe === 'Discount') valuationVerdict = 'Trading at Discount';
    
    // Calculate return metrics
    const equity = balanceSheet.totalEquity || 0;
    const assets = balanceSheet.totalAssets || 0;
    const investedCapital = equity + totalDebt - cash;
    const taxRate = 0.21;
    const nopat = ttmOperatingIncome ? ttmOperatingIncome * (1 - taxRate) : null;
    
    const returnMetrics = {
      roe: equity > 0 && ttmNetIncome ? `${((ttmNetIncome / equity) * 100).toFixed(1)}%` : '-',
      roa: assets > 0 && ttmNetIncome ? `${((ttmNetIncome / assets) * 100).toFixed(1)}%` : '-',
      roic: investedCapital > 0 && nopat ? `${((nopat / investedCapital) * 100).toFixed(1)}%` : '-',
    };

    return {
      success: true,
      ticker: ticker.toUpperCase(),
      currentPrice,
      currentPriceFormatted: currentPrice ? `$${currentPrice.toFixed(2)}` : 'N/A',
      marketCap,
      marketCapFormatted: this.formatNumber(marketCap),
      enterpriseValue,
      enterpriseValueFormatted: this.formatNumber(enterpriseValue),
      ttmRevenue,
      ttmRevenueFormatted: this.formatNumber(ttmRevenue),
      ttmNetIncome,
      ttmNetIncomeFormatted: this.formatNumber(ttmNetIncome),
      ttmEBITDA,
      ttmEBITDAFormatted: this.formatNumber(ttmEBITDA),
      ttmFCF,
      ttmFCFFormatted: this.formatNumber(ttmFCF),
      totalDebt,
      cash,
      netDebt,
      multiples,
      returnMetrics,
      sector,
      sectorAverages: sectorAvg,
      vsSector,
      valuationVerdict,
      margins: {
        gross: derived.grossMargin ? `${derived.grossMargin.toFixed(1)}%` : 'N/A',
        operating: derived.operatingMargin ? `${derived.operatingMargin.toFixed(1)}%` : 'N/A',
        net: derived.netMargin ? `${derived.netMargin.toFixed(1)}%` : 'N/A',
        fcf: derived.fcfMargin ? `${derived.fcfMargin.toFixed(1)}%` : 'N/A',
      },
      lastUpdated: new Date().toISOString(),
    };
    
  } catch (error) {
    console.error(`[DataService] Error fetching valuation for ${ticker}:`, error.message);
    return { success: false, ticker: ticker.toUpperCase(), multiples: {}, error: error.message };
  }
}


formatRelativeDate(date) {
  const days = Math.ceil((date - new Date()) / (1000 * 60 * 60 * 24));
  if (days <= 7) return `In ${days} days`;
  if (days <= 30) return `In ~${Math.ceil(days / 7)} weeks`;
  return `In ~${Math.ceil(days / 30)} months`;
}

  formatNumber(num) {
    if (num === null || num === undefined || isNaN(num)) return 'N/A';
    const abs = Math.abs(num);
    if (abs >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
    if (abs >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
    if (abs >= 1e6) return `$${(num / 1e6).toFixed(0)}M`;
    if (abs >= 1e3) return `$${(num / 1e3).toFixed(0)}K`;
    return `$${num.toFixed(0)}`;
  }
}

// ============================================
// STANDALONE HELPERS
// ============================================

function isInSP500(ticker) {
  return SP500_TICKERS.includes(ticker.toUpperCase());
}

function getRandomSP500Ticker() {
  return SP500_TICKERS[Math.floor(Math.random() * SP500_TICKERS.length)];
}

// ============================================
// EARNINGS MOVERS - Companies with recent earnings + 5%+ price change
// ============================================

/**
 * Fetch companies that reported earnings in the last N days with significant price moves
 * Uses EODHD earnings calendar + price data
 * 
 * @param {object} options - Configuration options
 * @param {string} options.eodhApiKey - EODHD API key
 * @param {number} options.lookbackDays - Days to look back (default: 7)
 * @param {number} options.minPriceChange - Minimum absolute % change (default: 5)
 * @param {string[]} options.excludeTickers - Tickers to exclude
 * @returns {Promise<Array>} Array of tickers with earnings moves
 */
async function fetchEarningsMovers(options = {}) {
  const {
    eodhApiKey,
    polygonApiKey,
    lookbackDays = 7,
    minPriceChange = 5,
    excludeTickers = [],
  } = options;

  const results = [];
  
  try {
    console.log(`[EarningsMovers] Searching for earnings movers (${lookbackDays} days, ${minPriceChange}%+ move)...`);
    
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - lookbackDays);
    
    const formatDate = (d) => d.toISOString().split('T')[0];
    
    // Method 1: Try EODHD Earnings Calendar
    if (eodhApiKey) {
      try {
        const earningsResponse = await axios.get(
          `https://eodhd.com/api/calendar/earnings`,
          {
            params: {
              api_token: eodhApiKey,
              fmt: 'json',
              from: formatDate(startDate),
              to: formatDate(endDate),
            },
            timeout: 15000,
          }
        );
        
        const earningsData = earningsResponse.data?.earnings || [];
        console.log(`[EarningsMovers] Found ${earningsData.length} earnings events from EODHD`);
        
        // Filter to S&P 500 companies only
        const sp500Earnings = earningsData.filter(e => 
          SP500_TICKERS.includes(e.code?.toUpperCase()) &&
          !excludeTickers.includes(e.code?.toUpperCase())
        );
        
        console.log(`[EarningsMovers] ${sp500Earnings.length} are S&P 500 companies`);
        
        // Check price change for each
        for (const earning of sp500Earnings.slice(0, 20)) {
          const ticker = earning.code?.toUpperCase();
          const earningsDate = earning.report_date;
          
          try {
            // Get price data around earnings date
            const priceChange = await calculateEarningsPriceChange(ticker, earningsDate, eodhApiKey);
            
            if (priceChange && Math.abs(priceChange.percentChange) >= minPriceChange) {
              results.push({
                ticker,
                companyName: earning.name || ticker,
                earningsDate,
                reportType: earning.period || 'quarterly',
                epsEstimate: earning.estimate,
                epsActual: earning.actual,
                epsSurprise: earning.actual && earning.estimate 
                  ? ((earning.actual - earning.estimate) / Math.abs(earning.estimate) * 100).toFixed(2) + '%'
                  : null,
                priceChange: priceChange.percentChange,
                priceChangeDirection: priceChange.percentChange > 0 ? 'up' : 'down',
                priceBefore: priceChange.priceBefore,
                priceAfter: priceChange.priceAfter,
                source: 'eodhd_earnings',
              });
              
              console.log(`[EarningsMovers] ✓ ${ticker}: ${priceChange.percentChange.toFixed(2)}% after earnings`);
            }
          } catch (priceError) {
            // Skip if price data unavailable
          }
          
          // Rate limiting
          await new Promise(r => setTimeout(r, 200));
        }
      } catch (eodhError) {
        console.warn(`[EarningsMovers] EODHD earnings fetch failed:`, eodhError.message);
      }
    }
    
    // Method 2: Fallback to Polygon if available and results are insufficient
    if (polygonApiKey && results.length < 3) {
      try {
        console.log(`[EarningsMovers] Trying Polygon fallback...`);
        
        // Check recent movers from S&P 500
        for (const ticker of SP500_TICKERS.slice(0, 30)) {
          if (excludeTickers.includes(ticker)) continue;
          if (results.find(r => r.ticker === ticker)) continue;
          
          try {
            const response = await axios.get(
              `https://api.polygon.io/v2/aggs/ticker/${ticker}/range/1/day/${formatDate(startDate)}/${formatDate(endDate)}`,
              {
                params: { apiKey: polygonApiKey },
                timeout: 10000,
              }
            );
            
            const bars = response.data?.results || [];
            if (bars.length >= 2) {
              // Look for days with 5%+ moves (potential earnings reaction)
              for (let i = 1; i < bars.length; i++) {
                const prevClose = bars[i - 1].c;
                const currentClose = bars[i].c;
                const percentChange = ((currentClose - prevClose) / prevClose) * 100;
                
                if (Math.abs(percentChange) >= minPriceChange) {
                  const moveDate = new Date(bars[i].t).toISOString().split('T')[0];
                  
                  results.push({
                    ticker,
                    companyName: ticker,
                    earningsDate: moveDate,
                    reportType: 'potential_earnings',
                    priceChange: percentChange,
                    priceChangeDirection: percentChange > 0 ? 'up' : 'down',
                    priceBefore: prevClose,
                    priceAfter: currentClose,
                    source: 'polygon_movers',
                  });
                  
                  console.log(`[EarningsMovers] ✓ ${ticker}: ${percentChange.toFixed(2)}% move on ${moveDate}`);
                  break;
                }
              }
            }
          } catch (e) {
            // Skip ticker
          }
          
          await new Promise(r => setTimeout(r, 100));
        }
      } catch (polygonError) {
        console.warn(`[EarningsMovers] Polygon fallback failed:`, polygonError.message);
      }
    }
    
    // Sort by absolute price change
    results.sort((a, b) => Math.abs(b.priceChange) - Math.abs(a.priceChange));
    
    console.log(`[EarningsMovers] Found ${results.length} total earnings movers`);
    return results;
    
  } catch (error) {
    console.error(`[EarningsMovers] Error:`, error.message);
    return [];
  }
}

/**
 * Calculate price change after earnings date
 */
async function calculateEarningsPriceChange(ticker, earningsDate, eodhApiKey) {
  try {
    const earningsDateObj = new Date(earningsDate);
    const startDate = new Date(earningsDateObj);
    startDate.setDate(startDate.getDate() - 2);
    const endDate = new Date(earningsDateObj);
    endDate.setDate(endDate.getDate() + 3);
    
    const response = await axios.get(
      `https://eodhd.com/api/eod/${ticker}.US`,
      {
        params: {
          api_token: eodhApiKey,
          fmt: 'json',
          from: startDate.toISOString().split('T')[0],
          to: endDate.toISOString().split('T')[0],
        },
        timeout: 10000,
      }
    );
    
    const prices = response.data || [];
    if (prices.length < 2) return null;
    
    // Find price before and after earnings
    const earningsIdx = prices.findIndex(p => p.date >= earningsDate);
    if (earningsIdx < 1) return null;
    
    const priceBefore = prices[earningsIdx - 1].adjusted_close || prices[earningsIdx - 1].close;
    const priceAfter = prices[Math.min(earningsIdx + 1, prices.length - 1)].adjusted_close || 
                       prices[Math.min(earningsIdx + 1, prices.length - 1)].close;
    
    const percentChange = ((priceAfter - priceBefore) / priceBefore) * 100;
    
    return {
      priceBefore,
      priceAfter,
      percentChange,
    };
  } catch (error) {
    return null;
  }
}

// ============================================
// TRENDING COMPANIES - News & Analyst Changes Fallback
// ============================================

/**
 * Fetch S&P 500 companies that are trending in recent news
 * Used as fallback when no earnings movers are found
 * 
 * @param {object} options - Configuration options
 * @param {string} options.eodhApiKey - EODHD API key
 * @param {string} options.newsApiKey - NewsAPI key (optional)
 * @param {number} options.lookbackDays - Days to look back (default: 5)
 * @param {number} options.minNewsCount - Minimum news articles required (default: 4)
 * @param {string[]} options.excludeTickers - Tickers to exclude
 * @returns {Promise<Array>} Array of trending companies
 */
async function fetchTrendingNewsCompanies(options = {}) {
  const {
    eodhApiKey,
    newsApiKey,
    polygonApiKey,
    lookbackDays = 5,
    minNewsCount = 4,
    excludeTickers = [],
  } = options;

  const results = [];
  
  try {
    console.log(`[TrendingNews] Searching for trending S&P 500 companies (${lookbackDays} days, ${minNewsCount}+ articles)...`);
    
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - lookbackDays);
    
    const formatDate = (d) => d.toISOString().split('T')[0];
    
    // Method 1: EODHD News API
    if (eodhApiKey) {
      try {
        // Check top S&P 500 companies for news volume
        const tickersToCheck = SP500_TICKERS.filter(t => !excludeTickers.includes(t)).slice(0, 100);
        
        for (const ticker of tickersToCheck) {
          try {
            const newsResponse = await axios.get(
              `https://eodhd.com/api/news`,
              {
                params: {
                  api_token: eodhApiKey,
                  s: `${ticker}.US`,
                  from: formatDate(startDate),
                  to: formatDate(endDate),
                  limit: 50,
                  fmt: 'json',
                },
                timeout: 10000,
              }
            );
            
            const newsItems = newsResponse.data || [];
            
            if (newsItems.length >= minNewsCount) {
              // Analyze news sentiment and importance
              const headlines = newsItems.map(n => n.title || '').join(' ').toLowerCase();
              
              // Score based on important keywords
              let relevanceScore = newsItems.length;
              const importantKeywords = [
                'acquisition', 'merger', 'deal', 'buy', 'sell', 'upgrade', 'downgrade',
                'beat', 'miss', 'guidance', 'outlook', 'ceo', 'launch', 'announce',
                'fda', 'approval', 'contract', 'billion', 'million', 'record',
                'breakthrough', 'partnership', 'expand', 'growth', 'decline', 'layoff',
                'restructure', 'lawsuit', 'investigation', 'regulation'
              ];
              
              for (const keyword of importantKeywords) {
                if (headlines.includes(keyword)) {
                  relevanceScore += 2;
                }
              }
              
              results.push({
                ticker,
                companyName: newsItems[0]?.symbols?.[0] || ticker,
                newsCount: newsItems.length,
                relevanceScore,
                recentHeadlines: newsItems.slice(0, 5).map(n => ({
                  title: n.title,
                  date: n.date,
                  source: n.source,
                })),
                source: 'eodhd_news',
                reason: `${newsItems.length} news articles in last ${lookbackDays} days`,
              });
            }
            
            // Rate limiting
            await new Promise(r => setTimeout(r, 100));
            
          } catch (tickerError) {
            // Skip ticker on error
          }
        }
        
        console.log(`[TrendingNews] Found ${results.length} trending companies from EODHD`);
        
      } catch (eodhError) {
        console.warn(`[TrendingNews] EODHD news fetch failed:`, eodhError.message);
      }
    }
    
    // Method 2: Polygon News API as fallback
    if (polygonApiKey && results.length < 3) {
      try {
        console.log(`[TrendingNews] Trying Polygon news fallback...`);
        
        const tickersToCheck = SP500_TICKERS.filter(t => 
          !excludeTickers.includes(t) && !results.find(r => r.ticker === t)
        ).slice(0, 50);
        
        for (const ticker of tickersToCheck) {
          try {
            const response = await axios.get(
              `https://api.polygon.io/v2/reference/news`,
              {
                params: {
                  ticker,
                  published_utc: `gte.${formatDate(startDate)}`,
                  limit: 50,
                  apiKey: polygonApiKey,
                },
                timeout: 10000,
              }
            );
            
            const newsItems = response.data?.results || [];
            
            if (newsItems.length >= minNewsCount) {
              results.push({
                ticker,
                companyName: newsItems[0]?.publisher?.name || ticker,
                newsCount: newsItems.length,
                relevanceScore: newsItems.length,
                recentHeadlines: newsItems.slice(0, 5).map(n => ({
                  title: n.title,
                  date: n.published_utc,
                  source: n.publisher?.name,
                })),
                source: 'polygon_news',
                reason: `${newsItems.length} news articles in last ${lookbackDays} days`,
              });
            }
            
            await new Promise(r => setTimeout(r, 100));
            
          } catch (e) {
            // Skip ticker
          }
        }
        
      } catch (polygonError) {
        console.warn(`[TrendingNews] Polygon news fallback failed:`, polygonError.message);
      }
    }
    
    // Sort by relevance score (news count + keyword matches)
    results.sort((a, b) => b.relevanceScore - a.relevanceScore);
    
    console.log(`[TrendingNews] Total trending companies found: ${results.length}`);
    return results;
    
  } catch (error) {
    console.error(`[TrendingNews] Error:`, error.message);
    return [];
  }
}

/**
 * Fetch S&P 500 companies with recent analyst rating changes
 * 
 * @param {object} options - Configuration options
 * @param {string} options.eodhApiKey - EODHD API key
 * @param {number} options.lookbackDays - Days to look back (default: 7)
 * @param {string[]} options.excludeTickers - Tickers to exclude
 * @returns {Promise<Array>} Array of companies with analyst changes
 */
async function fetchAnalystRatingChanges(options = {}) {
  const {
    eodhApiKey,
    polygonApiKey,
    lookbackDays = 7,
    excludeTickers = [],
  } = options;

  const results = [];
  
  try {
    console.log(`[AnalystChanges] Searching for analyst rating changes (${lookbackDays} days)...`);
    
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - lookbackDays);
    
    const formatDate = (d) => d.toISOString().split('T')[0];
    
    // Method 1: EODHD Analyst Ratings
    if (eodhApiKey) {
      try {
        // Check S&P 500 companies for rating changes
        const tickersToCheck = SP500_TICKERS.filter(t => !excludeTickers.includes(t)).slice(0, 80);
        
        for (const ticker of tickersToCheck) {
          try {
            const response = await axios.get(
              `https://eodhd.com/api/fundamental/${ticker}.US`,
              {
                params: {
                  api_token: eodhApiKey,
                  filter: 'AnalystRatings',
                  fmt: 'json',
                },
                timeout: 10000,
              }
            );
            
            const ratings = response.data?.AnalystRatings;
            
            if (ratings) {
              const { Rating, TargetPrice, StrongBuy, Buy, Hold, Sell, StrongSell } = ratings;
              const totalRatings = (StrongBuy || 0) + (Buy || 0) + (Hold || 0) + (Sell || 0) + (StrongSell || 0);
              
              // Check for recent upgrades/downgrades via news
              const newsResponse = await axios.get(
                `https://eodhd.com/api/news`,
                {
                  params: {
                    api_token: eodhApiKey,
                    s: `${ticker}.US`,
                    from: formatDate(startDate),
                    to: formatDate(endDate),
                    limit: 20,
                    fmt: 'json',
                  },
                  timeout: 10000,
                }
              );
              
              const newsItems = newsResponse.data || [];
              
              // Look for analyst-related news
              const analystNews = newsItems.filter(n => {
                const title = (n.title || '').toLowerCase();
                return title.includes('upgrade') || 
                       title.includes('downgrade') ||
                       title.includes('rating') ||
                       title.includes('price target') ||
                       title.includes('analyst') ||
                       title.includes('initiated') ||
                       title.includes('maintains') ||
                       title.includes('reiterates');
              });
              
              if (analystNews.length > 0) {
                // Determine if upgrade or downgrade
                const headlines = analystNews.map(n => n.title.toLowerCase()).join(' ');
                const isUpgrade = headlines.includes('upgrade') || headlines.includes('raises') || headlines.includes('initiated');
                const isDowngrade = headlines.includes('downgrade') || headlines.includes('lowers') || headlines.includes('cuts');
                
                results.push({
                  ticker,
                  companyName: ticker,
                  consensusRating: Rating || 'N/A',
                  targetPrice: TargetPrice,
                  totalAnalysts: totalRatings,
                  buyCount: (StrongBuy || 0) + (Buy || 0),
                  holdCount: Hold || 0,
                  sellCount: (Sell || 0) + (StrongSell || 0),
                  changeType: isUpgrade ? 'upgrade' : isDowngrade ? 'downgrade' : 'activity',
                  analystNewsCount: analystNews.length,
                  recentAnalystNews: analystNews.slice(0, 3).map(n => ({
                    title: n.title,
                    date: n.date,
                    source: n.source,
                  })),
                  source: 'eodhd_analyst',
                  reason: `${analystNews.length} analyst updates - ${isUpgrade ? 'Upgrade' : isDowngrade ? 'Downgrade' : 'Activity'}`,
                });
                
                console.log(`[AnalystChanges] ✓ ${ticker}: ${analystNews.length} analyst updates (${isUpgrade ? 'Upgrade' : isDowngrade ? 'Downgrade' : 'Activity'})`);
              }
            }
            
            // Rate limiting
            await new Promise(r => setTimeout(r, 150));
            
          } catch (tickerError) {
            // Skip ticker on error
          }
        }
        
      } catch (eodhError) {
        console.warn(`[AnalystChanges] EODHD analyst fetch failed:`, eodhError.message);
      }
    }
    
    // Method 2: Polygon Analyst Data as fallback (if available)
    if (polygonApiKey && results.length < 3) {
      try {
        console.log(`[AnalystChanges] Trying additional sources...`);
        
        // Polygon doesn't have direct analyst API, but we can check news for analyst mentions
        const tickersToCheck = SP500_TICKERS.filter(t => 
          !excludeTickers.includes(t) && !results.find(r => r.ticker === t)
        ).slice(0, 30);
        
        for (const ticker of tickersToCheck) {
          try {
            const response = await axios.get(
              `https://api.polygon.io/v2/reference/news`,
              {
                params: {
                  ticker,
                  published_utc: `gte.${formatDate(startDate)}`,
                  limit: 30,
                  apiKey: polygonApiKey,
                },
                timeout: 10000,
              }
            );
            
            const newsItems = response.data?.results || [];
            
            const analystNews = newsItems.filter(n => {
              const title = (n.title || '').toLowerCase();
              return title.includes('upgrade') || 
                     title.includes('downgrade') ||
                     title.includes('price target') ||
                     title.includes('analyst');
            });
            
            if (analystNews.length >= 2) {
              const headlines = analystNews.map(n => n.title.toLowerCase()).join(' ');
              const isUpgrade = headlines.includes('upgrade') || headlines.includes('raises');
              const isDowngrade = headlines.includes('downgrade') || headlines.includes('lowers');
              
              results.push({
                ticker,
                companyName: ticker,
                changeType: isUpgrade ? 'upgrade' : isDowngrade ? 'downgrade' : 'activity',
                analystNewsCount: analystNews.length,
                recentAnalystNews: analystNews.slice(0, 3).map(n => ({
                  title: n.title,
                  date: n.published_utc,
                  source: n.publisher?.name,
                })),
                source: 'polygon_analyst_news',
                reason: `${analystNews.length} analyst mentions`,
              });
            }
            
            await new Promise(r => setTimeout(r, 100));
            
          } catch (e) {
            // Skip ticker
          }
        }
        
      } catch (polygonError) {
        console.warn(`[AnalystChanges] Polygon fallback failed:`, polygonError.message);
      }
    }
    
    // Sort by analyst news count, prioritize upgrades/downgrades
    results.sort((a, b) => {
      // Prioritize actual upgrades/downgrades
      const aScore = a.changeType !== 'activity' ? 10 : 0;
      const bScore = b.changeType !== 'activity' ? 10 : 0;
      return (bScore + b.analystNewsCount) - (aScore + a.analystNewsCount);
    });
    
    console.log(`[AnalystChanges] Total companies with analyst changes: ${results.length}`);
    return results;
    
  } catch (error) {
    console.error(`[AnalystChanges] Error:`, error.message);
    return [];
  }
}

/**
 * Smart fallback selector - finds relevant company when no earnings movers exist
 * Priority: 1. Analyst rating changes  2. Trending news companies  3. Random S&P 500
 * 
 * @param {object} options - Configuration
 * @returns {Promise<object|null>} Selected company info or null
 */
async function selectRelevantFallbackCompany(options = {}) {
  const {
    eodhApiKey,
    polygonApiKey,
    newsApiKey,
    excludeTickers = [],
    lookbackDays = 5,
    minNewsCount = 4,
  } = options;

  console.log(`[SmartFallback] Searching for relevant company...`);
  
  try {
    // Step 1: Check for analyst rating changes (most impactful)
    const analystChanges = await fetchAnalystRatingChanges({
      eodhApiKey,
      polygonApiKey,
      lookbackDays: 7,
      excludeTickers,
    });
    
    if (analystChanges.length > 0) {
      const selected = analystChanges[0];
      console.log(`[SmartFallback] ✅ Selected ${selected.ticker} - Analyst ${selected.changeType}`);
      return {
        ticker: selected.ticker,
        companyName: selected.companyName,
        selectionReason: selected.reason,
        selectionType: 'analyst_change',
        changeType: selected.changeType,
        analystNews: selected.recentAnalystNews,
        consensusRating: selected.consensusRating,
        targetPrice: selected.targetPrice,
      };
    }
    
    // Step 2: Check for trending news companies
    const trendingCompanies = await fetchTrendingNewsCompanies({
      eodhApiKey,
      polygonApiKey,
      newsApiKey,
      lookbackDays,
      minNewsCount,
      excludeTickers,
    });
    
    if (trendingCompanies.length > 0) {
      const selected = trendingCompanies[0];
      console.log(`[SmartFallback] ✅ Selected ${selected.ticker} - Trending (${selected.newsCount} articles)`);
      return {
        ticker: selected.ticker,
        companyName: selected.companyName,
        selectionReason: selected.reason,
        selectionType: 'trending_news',
        newsCount: selected.newsCount,
        recentHeadlines: selected.recentHeadlines,
        relevanceScore: selected.relevanceScore,
      };
    }
    
    console.log(`[SmartFallback] No trending companies found`);
    return null;
    
  } catch (error) {
    console.error(`[SmartFallback] Error:`, error.message);
    return null;
  }
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  CompanyDataService,
  SP500_TICKERS,
  isInSP500,
  getRandomSP500Ticker,
  fetchEarningsMovers,
  calculateEarningsPriceChange,
  fetchTrendingNewsCompanies,
  fetchAnalystRatingChanges,
  selectRelevantFallbackCompany,
  XBRL_CONCEPTS,
};