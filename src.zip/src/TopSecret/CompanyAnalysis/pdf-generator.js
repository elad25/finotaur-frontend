// =====================================================
// COMPANY ANALYSIS PDF GENERATOR - v7.5 ISM TOGGLE
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/pdf-generator.js
//
// v7.5 CHANGES:
// - ISM Toggle Support: Skips pages 1-2 when includeIsm is false
// - Dynamic page numbering based on ISM inclusion
// - 10 pages WITH ISM, 8 pages WITHOUT ISM
//
// v7.4 CHANGES:
// - Page 5: Removed "Durable Moat" metrics box completely
// - Page 6: Complete redesign for cleaner aesthetics
//   - Monochrome waterfall (gold, gray, dark gray, green accent)
//   - NEW: Return on Capital section (ROE, ROA, ROIC) with visual scales
//   - NEW: Valuation Multiples with visual scales showing good/bad ranges
//   - Simplified Market View section
// - Less colors overall, more professional look
//
// WITH ISM (10 PAGES):
// Page 0: Cover (Dark branded page + company logo)
// Page 1: Introduction - The Investment Story
// Page 2: Macro Context - Reading the Economic Signals
// Page 3: Company Profile - Understanding the Business
// Page 4: How They Make Money - Business Model + Profitability Analysis
// Page 5: Competitive Position - Market Standing + Pie Chart
// Page 6: Financial Health & Valuation - Clean design with scales
// Page 7: Valuation - Wall Street View (compact)
// Page 8: Risk Assessment - What Could Go Wrong
// Page 9: Investment Conclusion - The Bottom Line
//
// WITHOUT ISM (8 PAGES):
// Page 0: Cover
// Page 1: Company Profile - Understanding the Business
// Page 2: How They Make Money - Business Model + Profitability Analysis
// Page 3: Competitive Position - Market Standing + Pie Chart
// Page 4: Financial Health & Valuation
// Page 5: Valuation - Wall Street View
// Page 6: Risk Assessment - What Could Go Wrong
// Page 7: Investment Conclusion - The Bottom Line
// =====================================================

const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

// ============ COLORS (professional gold/dark theme) ============
const COLORS = {
  gold: '#C9A646',
  black: '#000000',
  darkBg: '#0a0a12',
  darkText: '#1A1A1A',
  mediumGray: '#555555',
  lightGray: '#888888',
  veryLightGray: '#CCCCCC',
  ultraLightGray: '#EEEEEE',
  white: '#FFFFFF',
  green: '#16A34A',
  red: '#DC2626',
  blue: '#3B82F6',
  yellow: '#F59E0B',
};

// ============ TYPOGRAPHY ============
const FONT_DIR = path.join(process.cwd(), 'static', 'fonts');
const INTER_REGULAR = path.join(FONT_DIR, 'Inter_18pt-Regular.ttf');
const INTER_BOLD = path.join(FONT_DIR, 'Inter_18pt-Bold.ttf');

const hasInterFont = fs.existsSync(INTER_REGULAR) && fs.existsSync(INTER_BOLD);

const FONTS = {
  title: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  heading: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  body: hasInterFont ? 'Inter-Regular' : 'Helvetica',
  bold: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
};

function registerFonts(doc) {
  if (hasInterFont) {
    doc.registerFont('Inter-Regular', INTER_REGULAR);
    doc.registerFont('Inter-Bold', INTER_BOLD);
    console.log('[PDF] Using Inter font');
  }
}

const SIZES = {
  coverBadge: 14,
  coverTicker: 56,
  coverCompany: 18,
  coverSubtitle: 12,
  pageTitle: 18,
  sectionTitle: 14,
  subSection: 12,
  body: 10,
  small: 9,
  footer: 8,
};

// ============ PAGE LAYOUT ============
const PAGE = {
  width: 612,
  height: 792,
  marginLeft: 50,
  marginRight: 50,
  marginTop: 60,
  marginBottom: 50,
  
  get contentWidth() { return this.width - this.marginLeft - this.marginRight; },
  get contentTop() { return this.marginTop + 25; },
  get footerY() { return this.height - 30; },
  get safeBottom() { return this.footerY - 40; },
};

const COPYRIGHT = '© 2025 FINOTAUR';

// ============ HELPER FUNCTIONS ============
function safeGet(obj, path, defaultVal = 'N/A') {
  try {
    const result = path.split('.').reduce((o, k) => (o || {})[k], obj);
    if (result === undefined || result === null || result === '') return defaultVal;
    return result;
  } catch {
    return defaultVal;
  }
}

function formatNumber(num) {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  if (typeof num === 'string') return num;
  const abs = Math.abs(num);
  if (abs >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(num / 1e6).toFixed(0)}M`;
  return `$${num.toLocaleString()}`;
}

function formatPercent(val) {
  if (val === null || val === undefined) return 'N/A';
  if (typeof val === 'string' && val.includes('%')) return val;
  return `${Number(val).toFixed(1)}%`;
}

function needsPageBreak(y, space) {
  return y + space > PAGE.safeBottom;
}

// ============ DRAW HELPERS ============
function drawPageHeader(doc, ticker, companyName, pageNum) {
  // Gold accent bar
  doc.rect(PAGE.marginLeft, 40, 3, 20).fill(COLORS.gold);
  
  // FINOTAUR brand
  doc.font(FONTS.bold).fontSize(10).fillColor(COLORS.gold);
  doc.text('FINOTAUR', PAGE.marginLeft + 10, 43);
  
  // Ticker and company
  doc.font(FONTS.body).fontSize(9).fillColor(COLORS.lightGray);
  doc.text(`${ticker} | ${companyName}`, PAGE.marginLeft + 80, 43);
  
  // Page number
  doc.text(`Page ${pageNum}`, PAGE.width - PAGE.marginRight - 50, 43, { width: 50, align: 'right' });
  
  // Separator line
  doc.strokeColor(COLORS.veryLightGray).lineWidth(0.5);
  doc.moveTo(PAGE.marginLeft, 65).lineTo(PAGE.width - PAGE.marginRight, 65).stroke();
}

function drawFooter(doc, pageNum) {
  doc.strokeColor(COLORS.veryLightGray).lineWidth(0.3);
  doc.moveTo(PAGE.marginLeft, PAGE.footerY - 8).lineTo(PAGE.width - PAGE.marginRight, PAGE.footerY - 8).stroke();
  
  doc.font(FONTS.body).fontSize(SIZES.footer).fillColor(COLORS.lightGray);
  doc.text(COPYRIGHT, PAGE.marginLeft, PAGE.footerY);
  doc.text('Institutional Research | Confidential', PAGE.width / 2 - 80, PAGE.footerY, { width: 160, align: 'center' });
  doc.text(`${pageNum}`, PAGE.width - PAGE.marginRight - 20, PAGE.footerY, { width: 20, align: 'right' });
}

// HUMAN-READABLE SECTION TITLE (no numbering like 1.1, just text)
function drawSectionTitle(doc, title, y) {
  doc.font(FONTS.bold).fontSize(SIZES.pageTitle).fillColor(COLORS.darkText);
  doc.text(title, PAGE.marginLeft, y);
  return y + 28;
}

// HUMAN SUBHEADING (golden, flowing)
function drawSubHeading(doc, title, y) {
  doc.font(FONTS.bold).fontSize(SIZES.sectionTitle).fillColor(COLORS.gold);
  doc.text(title, PAGE.marginLeft, y);
  return y + 20;
}

function drawParagraph(doc, text, y, options = {}) {
  if (!text || text === 'N/A') return y;
  doc.font(options.bold ? FONTS.bold : FONTS.body)
     .fontSize(options.size || SIZES.body)
     .fillColor(options.color || COLORS.darkText);
  doc.text(text, PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 3 });
  return doc.y + 10;
}

function drawKeyValue(doc, key, value, y) {
  doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.mediumGray);
  doc.text(`${key}: `, PAGE.marginLeft, y, { continued: true });
  doc.font(FONTS.body).fillColor(COLORS.darkText);
  doc.text(String(value || 'N/A'));
  return doc.y + 5;
}

function drawTable(doc, headers, rows, y) {
  const colWidth = PAGE.contentWidth / headers.length;
  
  // Header
  doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.white);
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 20).fill(COLORS.gold);
  headers.forEach((h, i) => {
    doc.text(h, PAGE.marginLeft + i * colWidth + 5, y + 5, { width: colWidth - 10 });
  });
  y += 20;
  
  // Rows
  doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.darkText);
  rows.forEach((row, rowIdx) => {
    const bgColor = rowIdx % 2 === 0 ? COLORS.ultraLightGray : COLORS.white;
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 18).fill(bgColor);
    row.forEach((cell, i) => {
      doc.fillColor(COLORS.darkText);
      doc.text(String(cell || 'N/A'), PAGE.marginLeft + i * colWidth + 5, y + 4, { width: colWidth - 10 });
    });
    y += 18;
  });
  
  return y + 10;
}

function drawBulletList(doc, items, y) {
  if (!items || !Array.isArray(items) || items.length === 0) return y;
  
  doc.font(FONTS.body).fontSize(SIZES.body).fillColor(COLORS.darkText);
  items.forEach(item => {
    if (item && item !== 'N/A') {
      doc.text(`• ${item}`, PAGE.marginLeft + 10, y, { width: PAGE.contentWidth - 20 });
      y = doc.y + 3;
    }
  });
  return y + 5;
}

// ============ PAGE 0: COVER (v7.5 - FINOTAUR FIRST, THEN TICKER) ============
function drawPage0(doc, report, companyLogoBuffer = null, finotaurLogoBuffer = null) {
  console.log('[PDF Cover] === COVER PAGE DEBUG ===');
  console.log('[PDF Cover] finotaurLogoBuffer received:', !!finotaurLogoBuffer, finotaurLogoBuffer?.length || 0, 'bytes');
  console.log('[PDF Cover] companyLogoBuffer received:', !!companyLogoBuffer, companyLogoBuffer?.length || 0, 'bytes');
  
  const sections = report.sections || {};
  const cover = sections.cover || {};
  const ticker = report.ticker || cover.ticker || 'N/A';
  const companyName = report.company_name || cover.companyName || 'N/A';
  
  console.log('[PDF Cover] ticker:', ticker);
  console.log('[PDF Cover] companyName:', companyName);
  
  // Dark background
  doc.rect(0, 0, PAGE.width, PAGE.height).fill(COLORS.darkBg);
  doc.rect(0, 0, PAGE.width, 4).fill(COLORS.gold);
  
  const centerX = PAGE.width / 2;
  let y = 60;
  
  // ═══════════════════════════════════════════════════════════════════
  // 1. FINOTAUR TEXT (gold, large) - FIRST
  // ═══════════════════════════════════════════════════════════════════
  doc.font(FONTS.bold).fontSize(32).fillColor(COLORS.gold);
  doc.text('FINOTAUR', 0, y, { width: PAGE.width, align: 'center' });
  y += 45;
  
  // Gold underline
  doc.strokeColor(COLORS.gold)
     .lineWidth(2)
     .moveTo(centerX - 90, y)
     .lineTo(centerX + 90, y)
     .stroke();
  y += 20;
  
  // ═══════════════════════════════════════════════════════════════════
  // 2. FINOTAUR LOGO (if available)
  // ═══════════════════════════════════════════════════════════════════
  if (finotaurLogoBuffer) {
    try {
      console.log('[PDF Cover] Embedding Finotaur logo...');
      const finotaurLogoWidth = 200; // Bigger logo (was 140)
      const finotaurLogoX = centerX - finotaurLogoWidth / 2;
      doc.image(finotaurLogoBuffer, finotaurLogoX, y, { width: finotaurLogoWidth });
      y += 170; // Adjusted spacing after bigger logo
      console.log('[PDF Cover] ✅ Finotaur logo embedded');
    } catch (e) {
      console.log('[PDF Cover] ❌ Could not embed Finotaur logo:', e.message);
      y += 40;
    }
  } else {
    console.log('[PDF Cover] ⚠️ No Finotaur logo buffer - skipping');
    y += 40;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // 3. TICKER (large white) + COMPANY LOGO on LEFT
  // ═══════════════════════════════════════════════════════════════════
  const tickerY = y;
  const companyLogoSize = 65; // Bigger company logo (was 50)
  
  // Calculate ticker width for centering with logo
  doc.font(FONTS.bold).fontSize(SIZES.coverTicker);
  const tickerWidth = doc.widthOfString(ticker);
  const tickerTotalWidth = tickerWidth + (companyLogoBuffer ? companyLogoSize + 15 : 0);
  const tickerStartX = centerX - tickerTotalWidth / 2;
  
  if (companyLogoBuffer) {
    console.log('[PDF Cover] Embedding company logo...');
    try {
      // Company logo LEFT of ticker
      doc.image(companyLogoBuffer, tickerStartX, tickerY - 5, { 
        width: companyLogoSize, 
        height: companyLogoSize,
        fit: [companyLogoSize, companyLogoSize]
      });
      // Ticker after logo
      doc.font(FONTS.bold).fontSize(SIZES.coverTicker).fillColor(COLORS.white);
      doc.text(ticker, tickerStartX + companyLogoSize + 15, tickerY, { lineBreak: false });
      console.log('[PDF Cover] ✅ Company logo embedded');
    } catch (e) {
      console.log('[PDF Cover] ❌ Could not embed company logo:', e.message);
      // Fallback: centered without logo
      doc.font(FONTS.bold).fontSize(SIZES.coverTicker).fillColor(COLORS.white);
      doc.text(ticker, 0, tickerY, { width: PAGE.width, align: 'center' });
    }
  } else {
    console.log('[PDF Cover] ⚠️ No company logo buffer - ticker centered');
    // No logo - centered ticker
    doc.font(FONTS.bold).fontSize(SIZES.coverTicker).fillColor(COLORS.white);
    doc.text(ticker, 0, tickerY, { width: PAGE.width, align: 'center' });
  }
  y += 80;
  
  // ═══════════════════════════════════════════════════════════════════
  // 4. COMPANY NAME (white/gray)
  // ═══════════════════════════════════════════════════════════════════
  doc.font(FONTS.body).fontSize(SIZES.coverCompany).fillColor(COLORS.veryLightGray);
  doc.text(companyName, 0, y, { width: PAGE.width, align: 'center' });
  y += 40;
  
  // ═══════════════════════════════════════════════════════════════════
  // 5. SECTOR | INDUSTRY (gray)
  // ═══════════════════════════════════════════════════════════════════
  const sector = safeGet(report, 'sector', cover.sector || 'N/A');
  const industry = safeGet(report, 'industry', cover.industry || 'N/A');
  doc.font(FONTS.body).fontSize(SIZES.coverSubtitle).fillColor(COLORS.lightGray);
  doc.text(`${sector} | ${industry.toUpperCase()}`, 0, y, { width: PAGE.width, align: 'center' });
  y += 50;
  
  // ═══════════════════════════════════════════════════════════════════
  // 6. ANALYSIS PERIOD (gold) - Only show if ISM is included
  // ═══════════════════════════════════════════════════════════════════
  const includeIsm = report.meta?.includeIsm !== false && report.include_ism !== false;
  if (includeIsm) {
    const ismMonth = cover.ismReferenceMonth || report.report_month || 'N/A';
    doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.gold);
    doc.text(`Analysis Period: ${ismMonth}`, 0, y, { width: PAGE.width, align: 'center' });
  } else {
    // Show different text when ISM is disabled
    doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.gold);
    doc.text('Company Analysis Report', 0, y, { width: PAGE.width, align: 'center' });
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // FOOTER
  // ═══════════════════════════════════════════════════════════════════
  doc.rect(0, PAGE.height - 4, PAGE.width, 4).fill(COLORS.gold);
  
  doc.font(FONTS.body).fontSize(SIZES.footer).fillColor(COLORS.lightGray);
  doc.text('Institutional-Grade Research | © 2025 FINOTAUR', 0, PAGE.height - 30, { width: PAGE.width, align: 'center' });
}

// ============ PAGE 1: INTRODUCTION - THE INVESTMENT STORY (ISM ONLY) ============
function drawPage1_Introduction(doc, report, pageNum) {
  const sections = report.sections || {};
  const cover = sections.cover || {};
  const analystContext = sections.analystContext || {};
  const ismAnalysis = sections.ismAnalysis || {};
  const ticker = report.ticker || 'N/A';
  const companyName = report.company_name || 'N/A';
  
  drawPageHeader(doc, ticker, companyName, pageNum);
  let y = PAGE.contentTop;
  
  // Main title - Human readable
  y = drawSectionTitle(doc, 'The Investment Story', y);
  
  // Thesis quote box
  const oneLiner = cover.oneLiner || sections.thesis?.oneLiner || '';
  if (oneLiner) {
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 50).fill(COLORS.ultraLightGray);
    doc.font(FONTS.body).fontSize(11).fillColor(COLORS.darkText);
    doc.text(`"${oneLiner}"`, PAGE.marginLeft + 15, y + 15, { width: PAGE.contentWidth - 30, align: 'center' });
    y += 65;
  }
  
  // The narrative opening
  y = drawSubHeading(doc, 'Why We\'re Looking at This Company', y);
  
  // Write flowing narrative paragraphs
  if (analystContext.whyISMMatters) {
    y = drawParagraph(doc, analystContext.whyISMMatters, y);
  }
  
  y += 10;
  y = drawSubHeading(doc, 'The Signal We Identified', y);
  
  if (analystContext.signalCaught) {
    y = drawParagraph(doc, analystContext.signalCaught, y);
  }
  
  y += 10;
  y = drawSubHeading(doc, 'Why This Company Specifically', y);
  
  if (analystContext.whyThisCompany) {
    y = drawParagraph(doc, analystContext.whyThisCompany, y);
  }
  
  // How to read this report
  y += 15;
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 80).fill('#f8f8f0');
  y += 10;
  doc.font(FONTS.bold).fontSize(SIZES.subSection).fillColor(COLORS.gold);
  doc.text('How to Read This Report', PAGE.marginLeft + 15, y);
  y += 18;
  doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.mediumGray);
  doc.text('This analysis flows from macro to micro: we start with the economic signals that triggered our interest, move through sector dynamics, then examine why this particular company is best positioned to benefit. The financial analysis and valuation follow, culminating in our investment thesis and risk assessment.', PAGE.marginLeft + 15, y, { width: PAGE.contentWidth - 30, lineGap: 3 });
  
  drawFooter(doc, pageNum);
}

// ============ PAGE 2: MACRO CONTEXT (ISM ONLY) ============
function drawPage2_MacroContext(doc, report, pageNum) {
  const sections = report.sections || {};
  const ismAnalysis = sections.ismAnalysis || {};
  const macroInterpretation = sections.macroInterpretation || {};
  const sectorSelection = sections.sectorSelection || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'Reading the Economic Signals', y);
  
  // ISM Signal
  y = drawSubHeading(doc, 'Manufacturing Pulse Check', y);
  
  if (ismAnalysis.headline) {
    y = drawKeyValue(doc, 'Headline PMI', ismAnalysis.headline, y);
  }
  
  // ISM Components Table
  const subComponents = ismAnalysis.subComponents || {};
  if (Object.keys(subComponents).length > 0) {
    const rows = [];
    if (subComponents.newOrders) rows.push(['New Orders', subComponents.newOrders.current, subComponents.newOrders.prior, subComponents.newOrders.change, subComponents.newOrders.trend]);
    if (subComponents.production) rows.push(['Production', subComponents.production.current, subComponents.production.prior, subComponents.production.change, subComponents.production.trend]);
    if (subComponents.employment) rows.push(['Employment', subComponents.employment.current, subComponents.employment.prior, subComponents.employment.change, subComponents.employment.trend]);
    if (subComponents.prices) rows.push(['Prices', subComponents.prices.current, subComponents.prices.prior, subComponents.prices.change, subComponents.prices.trend]);
    if (subComponents.inventories) rows.push(['Inventories', subComponents.inventories.current, subComponents.inventories.prior, subComponents.inventories.change, subComponents.inventories.trend]);
    
    if (rows.length > 0) {
      y = drawTable(doc, ['Component', 'Current', 'Prior', 'Change', 'Trend'], rows, y);
    }
  }
  
  if (ismAnalysis.keyTakeaway) {
    y = drawParagraph(doc, ismAnalysis.keyTakeaway, y);
  }
  
  // Macro Interpretation
  y += 10;
  y = drawSubHeading(doc, 'What This Means for Markets', y);
  y = drawKeyValue(doc, 'Economic Cycle Stage', macroInterpretation.cycleStage, y);
  y = drawKeyValue(doc, 'Market Regime', `${macroInterpretation.regimeType || 'N/A'} (${macroInterpretation.isRegimeShift ? 'Shift underway' : 'Continuation'})`, y);
  
  if (macroInterpretation.winners?.length > 0) {
    y = drawKeyValue(doc, 'Sectors to Favor', macroInterpretation.winners.join(', '), y);
  }
  if (macroInterpretation.losers?.length > 0) {
    y = drawKeyValue(doc, 'Sectors to Avoid', macroInterpretation.losers.join(', '), y);
  }
  
  // Sector Selection
  y += 10;
  y = drawSubHeading(doc, 'Our Sector Focus', y);
  y = drawKeyValue(doc, 'Target Sector', sectorSelection.primarySector, y);
  y = drawParagraph(doc, sectorSelection.whyThisSector, y);
  
  if (sectorSelection.alternativeSectors?.length > 0) {
    y = drawKeyValue(doc, 'Also Considered', sectorSelection.alternativeSectors.join(', '), y);
  }
  
  drawFooter(doc, pageNum);
}

// ============ PAGE 3: COMPANY PROFILE ============
function drawPage3_CompanyProfile(doc, report, pageNum) {
  const sections = report.sections || {};
  const companySnapshot = sections.companySnapshot || {};
  const whyThisCompany = sections.whyThisCompany || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'Understanding the Business', y);
  
  // Company Overview - now as flowing text
  y = drawSubHeading(doc, 'Company at a Glance', y);
  
  // Basic info line
  const companyName = companySnapshot.name || report.company_name || 'N/A';
  const ticker = companySnapshot.ticker || report.ticker || 'N/A';
  const marketCap = companySnapshot.marketCap || 'N/A';
  const employees = companySnapshot.employees || 'N/A';
  
  doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
  doc.text(`${companyName} (${ticker})`, PAGE.marginLeft, y);
  y = doc.y + 3;
  doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.mediumGray);
  doc.text(`Market Cap: ${marketCap} | Employees: ${employees}`, PAGE.marginLeft, y);
  y = doc.y + 12;
  
  // What They Do - as narrative
  if (companySnapshot.whatTheyDo && companySnapshot.whatTheyDo !== 'N/A') {
    y = drawParagraph(doc, companySnapshot.whatTheyDo, y);
  }
  
  // Customers - as narrative
  if (companySnapshot.customers && companySnapshot.customers !== 'N/A') {
    y = drawParagraph(doc, companySnapshot.customers, y);
  }
  
  // Value Chain Position - as narrative
  if (companySnapshot.valueChainPosition && companySnapshot.valueChainPosition !== 'N/A') {
    y = drawParagraph(doc, companySnapshot.valueChainPosition, y);
  }
  
  // Why This Company
  y += 15;
  y = drawSubHeading(doc, 'Why This Company Stands Out', y);
  
  if (whyThisCompany.pureExposure) {
    y = drawParagraph(doc, whyThisCompany.pureExposure, y);
  }
  
  if (whyThisCompany.selectionRationale) {
    y += 8;
    y = drawParagraph(doc, whyThisCompany.selectionRationale, y);
  }
  
  drawFooter(doc, pageNum);
}

// ============ PAGE 4: BUSINESS MODEL ============
function drawPage4_BusinessModel(doc, report, pageNum) {
  const sections = report.sections || {};
  const revenueEngine = sections.revenueEngine || {};
  const products = sections.products || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'How They Make Money', y);
  
  // Revenue Model - as compact intro
  y = drawSubHeading(doc, 'The Revenue Engine', y);
  
  const model = revenueEngine.model || 'Mixed';
  const recurring = revenueEngine.recurringPercent || 'N/A';
  const sensitivity = revenueEngine.cycleSensitivity || 'Medium';
  
  doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
  doc.text(`Business Model: `, PAGE.marginLeft, y, { continued: true });
  doc.font(FONTS.body).text(model);
  y = doc.y + 3;
  
  doc.font(FONTS.bold).text(`Recurring Revenue: `, PAGE.marginLeft, y, { continued: true });
  doc.font(FONTS.body).text(recurring);
  y = doc.y + 3;
  
  doc.font(FONTS.bold).text(`Economic Sensitivity: `, PAGE.marginLeft, y, { continued: true });
  doc.font(FONTS.body).text(sensitivity);
  y = doc.y + 12;
  
  // Revenue Sources with PIE CHART
  const revenueSources = revenueEngine.revenueSources || [];
  
  if (revenueSources.length > 0) {
    // ============ REVENUE BREAKDOWN PIE CHART ============
    y = drawSubHeading(doc, 'Revenue Breakdown', y);
    
    // Pie chart colors - professional palette
    const pieColors = ['#C9A646', '#4A90A4', '#7B8794', '#5C6E7B', '#8FA3B0', '#6B7280', '#9CA3AF'];
    
    // Build pie data from revenue sources
    const pieData = revenueSources.map((s, idx) => {
      const percentStr = String(s.percent || '0').replace('%', '');
      const value = parseFloat(percentStr) || 0;
      return {
        label: s.source || `Segment ${idx + 1}`,
        value: value,
        growth: s.growth || 'N/A',
        margin: s.marginProfile || 'N/A',
        color: pieColors[idx % pieColors.length]
      };
    }).filter(d => d.value > 0);
    
    // Draw pie chart if we have valid data
    if (pieData.length > 0 && pieData.some(d => d.value > 0)) {
      const chartRadius = 55;
      const chartCenterX = PAGE.marginLeft + chartRadius + 15;
      const chartCenterY = y + chartRadius + 5;
      
      // Draw the pie chart
      drawRevenuePieChart(doc, pieData, chartCenterX, chartCenterY, chartRadius);
      
      // Draw legend on the right side with more details
      const legendX = PAGE.marginLeft + chartRadius * 2 + 50;
      const legendY = y + 5;
      drawRevenueLegend(doc, pieData, legendX, legendY);
      
      y = chartCenterY + chartRadius + 20;
    }
    
    // ============ MOST PROFITABLE SEGMENT ANALYSIS ============
    y = drawSubHeading(doc, 'Profitability Analysis', y);
    
    // Find the most profitable segment
    const highMarginSources = revenueSources.filter(s => {
      const margin = String(s.marginProfile || '').toLowerCase();
      return margin.includes('high') || margin.includes('very high') || margin.includes('excellent');
    });
    
    const highestRevenueSource = revenueSources.reduce((max, s) => {
      const share = parseFloat(String(s.percent || '0').replace('%', '')) || 0;
      const maxShare = parseFloat(String(max?.percent || '0').replace('%', '')) || 0;
      return share > maxShare ? s : max;
    }, revenueSources[0]);
    
    // Build profitability narrative
    let profitNarrative = '';
    
    // Primary revenue driver
    if (highestRevenueSource) {
      const share = String(highestRevenueSource.percent || '').replace('%', '');
      profitNarrative += `The primary revenue driver is ${highestRevenueSource.source}, contributing ${share}% of total revenue. `;
    }
    
    // High margin segment highlight (like AWS for Amazon)
    if (highMarginSources.length > 0) {
      const profitChamp = highMarginSources[0];
      const champShare = String(profitChamp.percent || '').replace('%', '');
      const champMargin = profitChamp.marginProfile || 'high';
      
      // Check if this is different from the highest revenue source
      if (highMarginSources[0].source !== highestRevenueSource?.source) {
        profitNarrative += `\n\nKey Profit Driver: ${profitChamp.source} stands out as the profit engine - despite representing only ${champShare}% of revenue, its ${champMargin} margins make it disproportionately important to the bottom line. `;
        
        // Add comparison like AWS vs Amazon's retail
        const lowMarginSource = revenueSources.find(s => {
          const margin = String(s.marginProfile || '').toLowerCase();
          return margin.includes('low') || margin.includes('thin');
        });
        
        if (lowMarginSource) {
          profitNarrative += `This contrasts with ${lowMarginSource.source}, which has ${lowMarginSource.marginProfile} margins despite its larger revenue contribution.`;
        }
      } else {
        profitNarrative += `This segment also enjoys ${champMargin} profit margins, making it both the revenue and profit leader.`;
      }
    }
    
    // Check for services vs products dynamic
    const serviceSegments = revenueSources.filter(s => {
      const name = String(s.source || '').toLowerCase();
      return name.includes('service') || name.includes('subscription') || name.includes('cloud') || name.includes('software');
    });
    
    if (serviceSegments.length > 0 && !profitNarrative.includes('service')) {
      const serviceTotal = serviceSegments.reduce((sum, s) => {
        return sum + (parseFloat(String(s.percent || '0').replace('%', '')) || 0);
      }, 0);
      
      if (serviceTotal > 0) {
        profitNarrative += `\n\nServices & recurring revenue streams account for ${serviceTotal.toFixed(0)}% of the business, typically offering higher margins and more predictable cash flows.`;
      }
    }
    
    if (profitNarrative) {
      doc.font(FONTS.body).fontSize(SIZES.body).fillColor(COLORS.darkText);
      doc.text(profitNarrative.trim(), PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 3 });
      y = doc.y + 10;
    }
  }
  
  // Core Products & Services - Table
  y += 5;
  y = drawSubHeading(doc, 'Core Products & Services', y);
  
  // Products - improved table with profitability
  const mainProducts = products.mainProducts || [];
  if (mainProducts.length > 0) {
    // Check if ANY product has profitability data
    const hasAnyProfitability = mainProducts.some(p => p.profitability || p.margin);
    
    // Adjust columns based on whether we have profitability data
    const colWidths = hasAnyProfitability 
      ? [PAGE.contentWidth * 0.20, PAGE.contentWidth * 0.45, PAGE.contentWidth * 0.15, PAGE.contentWidth * 0.20]
      : [PAGE.contentWidth * 0.22, PAGE.contentWidth * 0.58, PAGE.contentWidth * 0.20]; // No profitability column
    
    // Header
    doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.white);
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 22).fill(COLORS.gold);
    doc.text('Product', PAGE.marginLeft + 8, y + 6, { width: colWidths[0] - 10 });
    doc.text('Description', PAGE.marginLeft + colWidths[0] + 5, y + 6, { width: colWidths[1] - 10 });
    doc.text('Revenue', PAGE.marginLeft + colWidths[0] + colWidths[1] + 5, y + 6, { width: colWidths[2] - 10 });
    if (hasAnyProfitability) {
      doc.text('Margin', PAGE.marginLeft + colWidths[0] + colWidths[1] + colWidths[2] + 5, y + 6, { width: colWidths[3] - 10 });
    }
    y += 22;
    
    // Rows - with text wrapping support
    doc.font(FONTS.body).fontSize(SIZES.small);
    mainProducts.forEach((p, idx) => {
      // Calculate row height based on description length
      const description = p.description || '—';
      const descHeight = doc.heightOfString(description, { width: colWidths[1] - 16 });
      const rowHeight = Math.max(24, descHeight + 10);
      
      const bgColor = idx % 2 === 0 ? COLORS.ultraLightGray : COLORS.white;
      doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, rowHeight).fill(bgColor);
      doc.fillColor(COLORS.darkText);
      doc.text(p.name || '—', PAGE.marginLeft + 8, y + 5, { width: colWidths[0] - 16 });
      doc.text(description, PAGE.marginLeft + colWidths[0] + 5, y + 5, { width: colWidths[1] - 16 });
      doc.text(p.revenueShare || '—', PAGE.marginLeft + colWidths[0] + colWidths[1] + 5, y + 5, { width: colWidths[2] - 10 });
      if (hasAnyProfitability) {
        doc.text(p.profitability || p.margin || '—', PAGE.marginLeft + colWidths[0] + colWidths[1] + colWidths[2] + 5, y + 5, { width: colWidths[3] - 10 });
      }
      y += rowHeight;
    });
    y += 8;
  }
  
  // Differentiators as narrative
  if (products.differentiators?.length > 0) {
    y += 5;
    doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
    doc.text('Key Differentiators: ', PAGE.marginLeft, y, { continued: true });
    doc.font(FONTS.body).text(products.differentiators.join(', '));
    y = doc.y + 8;
  }
  
  if (products.differentiatorNarrative) {
    y = drawParagraph(doc, products.differentiatorNarrative, y);
  }
  
  drawFooter(doc, pageNum);
}

// ============ HELPER: PARSE MARKET CAP ============
function parseMarketCap(mcStr) {
  if (!mcStr || mcStr === 'N/A') return 0;
  const str = String(mcStr).replace(/[$,]/g, '').trim();
  const match = str.match(/([\d.]+)\s*([BTMK])?/i);
  if (!match) return 0;
  const num = parseFloat(match[1]) || 0;
  const suffix = (match[2] || '').toUpperCase();
  if (suffix === 'T') return num * 1000;
  if (suffix === 'B') return num;
  if (suffix === 'M') return num / 1000;
  if (suffix === 'K') return num / 1000000;
  return num;
}

// ============ HELPER: DRAW PIE CHART ============
function drawPieChart(doc, data, centerX, centerY, radius) {
  const total = data.reduce((sum, d) => sum + (d.value || 0), 0);
  if (total === 0) return;
  
  let currentAngle = -Math.PI / 2; // Start from top
  
  data.forEach((d) => {
    if (!d.value || d.value <= 0) return;
    
    const sliceAngle = (d.value / total) * 2 * Math.PI;
    const endAngle = currentAngle + sliceAngle;
    
    // Draw slice as filled path
    doc.save();
    doc.fillColor(d.color || COLORS.gold);
    
    // Create pie slice path
    const startX = centerX + radius * Math.cos(currentAngle);
    const startY = centerY + radius * Math.sin(currentAngle);
    
    doc.moveTo(centerX, centerY)
       .lineTo(startX, startY);
    
    // Draw arc using small line segments
    const steps = Math.max(20, Math.floor(Math.abs(sliceAngle) * 20));
    for (let i = 1; i <= steps; i++) {
      const angle = currentAngle + (sliceAngle * i / steps);
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      doc.lineTo(x, y);
    }
    
    doc.lineTo(centerX, centerY)
       .fill();
    doc.restore();
    
    // Draw percentage label inside slice (if big enough)
    const percent = (d.value / total * 100).toFixed(0);
    if (parseFloat(percent) >= 8) {
      const midAngle = currentAngle + sliceAngle / 2;
      const labelX = centerX + (radius * 0.6) * Math.cos(midAngle);
      const labelY = centerY + (radius * 0.6) * Math.sin(midAngle);
      doc.font(FONTS.bold).fontSize(8).fillColor(COLORS.white);
      doc.text(`${percent}%`, labelX - 12, labelY - 4, { width: 24, align: 'center' });
    }
    
    currentAngle = endAngle;
  });
}

// ============ HELPER: DRAW LEGEND ============
function drawChartLegend(doc, data, x, y) {
  const boxSize = 10;
  const itemHeight = 18;
  
  data.forEach((d, idx) => {
    const itemY = y + idx * itemHeight;
    
    // Color box
    doc.rect(x, itemY, boxSize, boxSize).fill(d.color || COLORS.gold);
    
    // Label with market cap
    doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.darkText);
    const label = d.marketCap ? `${d.label} - ${d.marketCap}` : d.label;
    doc.text(label, x + boxSize + 8, itemY, { width: 250 });
  });
  
  return y + data.length * itemHeight + 5;
}

// ============ HELPER: DRAW REVENUE PIE CHART ============
function drawRevenuePieChart(doc, data, centerX, centerY, radius) {
  const total = data.reduce((sum, d) => sum + (d.value || 0), 0);
  if (total === 0) return;
  
  let currentAngle = -Math.PI / 2; // Start from top
  
  data.forEach((d) => {
    if (!d.value || d.value <= 0) return;
    
    const sliceAngle = (d.value / total) * 2 * Math.PI;
    const endAngle = currentAngle + sliceAngle;
    
    // Draw slice as filled path
    doc.save();
    doc.fillColor(d.color || COLORS.gold);
    
    // Create pie slice path
    const startX = centerX + radius * Math.cos(currentAngle);
    const startY = centerY + radius * Math.sin(currentAngle);
    
    doc.moveTo(centerX, centerY)
       .lineTo(startX, startY);
    
    // Draw arc using small line segments
    const steps = Math.max(20, Math.floor(Math.abs(sliceAngle) * 20));
    for (let i = 1; i <= steps; i++) {
      const angle = currentAngle + (sliceAngle * i / steps);
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      doc.lineTo(x, y);
    }
    
    doc.lineTo(centerX, centerY)
       .fill();
    doc.restore();
    
    // Draw percentage label inside slice (if big enough)
    const percent = (d.value / total * 100).toFixed(0);
    if (parseFloat(percent) >= 10) {
      const midAngle = currentAngle + sliceAngle / 2;
      const labelX = centerX + (radius * 0.65) * Math.cos(midAngle);
      const labelY = centerY + (radius * 0.65) * Math.sin(midAngle);
      doc.font(FONTS.bold).fontSize(9).fillColor(COLORS.white);
      doc.text(`${percent}%`, labelX - 14, labelY - 5, { width: 28, align: 'center' });
    }
    
    currentAngle = endAngle;
  });
}

// ============ HELPER: DRAW REVENUE LEGEND WITH DETAILS ============
function drawRevenueLegend(doc, data, x, y) {
  const boxSize = 10;
  const itemHeight = 22;
  
  // Title
  doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.darkText);
  doc.text('Revenue Segments', x, y);
  y += 16;
  
  data.forEach((d, idx) => {
    const itemY = y + idx * itemHeight;
    
    // Color box
    doc.rect(x, itemY + 2, boxSize, boxSize).fill(d.color || COLORS.gold);
    
    // Label with percentage
    doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.darkText);
    doc.text(`${d.label}`, x + boxSize + 8, itemY, { width: 150 });
    
    // Growth and margin info
    doc.font(FONTS.body).fontSize(7).fillColor(COLORS.mediumGray);
    const details = [];
    if (d.value) details.push(`${d.value.toFixed(0)}%`);
    if (d.growth && d.growth !== 'N/A') details.push(`Growth: ${d.growth}`);
    if (d.margin && d.margin !== 'N/A') details.push(`${d.margin} margin`);
    
    if (details.length > 0) {
      doc.text(details.join(' | '), x + boxSize + 8, itemY + 11, { width: 160 });
    }
  });
  
  return y + data.length * itemHeight + 5;
}

// ============ PAGE 5: COMPETITIVE POSITION ============
function drawPage5_Competition(doc, report, pageNum) {
  const sections = report.sections || {};
  const competitiveLandscape = sections.competitiveLandscape || {};
  const moatAssessment = sections.moatAssessment || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'Competitive Position', y);
  
  // Market Position - compact header
  y = drawSubHeading(doc, 'Market Standing', y);
  
  const marketShare = competitiveLandscape.marketShare || '';
  const position = competitiveLandscape.relativePosition || '';
  
  if (marketShare || position) {
    doc.font(FONTS.body).fontSize(SIZES.body).fillColor(COLORS.darkText);
    let positionText = '';
    if (marketShare) positionText += `Market Share: ${marketShare}`;
    if (position) positionText += positionText ? ` | Position: ${position}` : `Position: ${position}`;
    doc.text(positionText, PAGE.marginLeft, y);
    y = doc.y + 12;
  }
  
  // Get competitors
  const competitors = competitiveLandscape.directCompetitors || [];
  const companyMarketCap = sections.companySnapshot?.marketCap || report.marketCap || 'N/A';
  
  // Competitors with narratives FIRST - FIXED: proper text width to prevent cutoff
  if (competitors.length > 0) {
    competitors.forEach((c) => {
      // Competitor header - use full width with proper formatting
      doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.gold);
      const competitorName = c.name || 'Competitor';
      const competitorTicker = c.ticker || 'N/A';
      const competitorMC = c.marketCap || '';
      
      // Build full header text
      let headerText = `${competitorName} (${competitorTicker})`;
      if (competitorMC) headerText += ` - ${competitorMC}`;
      
      // Draw with proper width constraint
      doc.text(headerText, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      y = doc.y + 4;
      
      // Competitor narrative
      if (c.narrative) {
        doc.font(FONTS.body).fontSize(SIZES.body).fillColor(COLORS.darkText);
        doc.text(c.narrative, PAGE.marginLeft, y, { width: PAGE.contentWidth, lineGap: 2 });
        y = doc.y + 10;
      }
    });
  }
  
  // PIE CHART - Now at BOTTOM and LARGER (about 1/3 of page)
  y += 15;
  
  // Colors for pie chart (gold for company, different colors for competitors)
  const pieColors = [COLORS.gold, '#4A90A4', '#7B8794', '#5C6E7B', '#8FA3B0'];
  
  // Build pie data
  const pieData = [];
  
  // Add company first
  const companyMcValue = parseMarketCap(companyMarketCap);
  pieData.push({
    label: report.company_name || 'Company',
    value: companyMcValue,
    marketCap: companyMarketCap,
    color: pieColors[0]
  });
  
  // Add competitors
  competitors.slice(0, 4).forEach((c, idx) => {
    const mcValue = parseMarketCap(c.marketCap);
    pieData.push({
      label: c.name || c.ticker || `Competitor ${idx + 1}`,
      value: mcValue,
      marketCap: c.marketCap || 'N/A',
      color: pieColors[(idx + 1) % pieColors.length]
    });
  });
  
  // Draw pie chart if we have valid data - LARGER SIZE
  if (pieData.length > 1 && pieData.some(d => d.value > 0)) {
    // Title for chart section
    y = drawSubHeading(doc, 'Market Cap Distribution', y);
    
    const chartRadius = 70; // Larger radius
    const chartCenterX = PAGE.marginLeft + chartRadius + 20;
    const chartCenterY = y + chartRadius + 10;
    
    // Draw the pie chart
    drawPieChart(doc, pieData, chartCenterX, chartCenterY, chartRadius);
    
    // Draw legend on the right side
    const legendX = PAGE.marginLeft + chartRadius * 2 + 60;
    const legendY = y + 20;
    drawChartLegend(doc, pieData, legendX, legendY);
    
    y = chartCenterY + chartRadius + 15;
  }
  
  drawFooter(doc, pageNum);
}

// ============ HELPER: DRAW WATERFALL CHART ============
function drawWaterfallChart(doc, data, x, y, width, maxHeight) {
  // Minimal monochrome waterfall with gold accent
  if (!data || data.length === 0) return y;
  
  const barHeight = 18;
  const labelWidth = 95;
  const chartWidth = width - labelWidth - 50;
  const startX = x + labelWidth;
  
  // Minimal color palette
  const COLORS_CHART = {
    revenue: COLORS.gold,           // Gold for revenue
    expense: '#9CA3AF',             // Gray for expenses
    profit: '#4B5563',              // Dark gray for profits
    profitGood: '#059669'           // Green accent for final profit
  };
  
  // Draw title
  doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.mediumGray);
  doc.text('Revenue to Profit Flow (% of Revenue)', x, y, { width: width, align: 'center' });
  y += 16;
  
  const maxValue = 100;
  
  data.forEach((item, idx) => {
    const itemY = y + idx * (barHeight + 3);
    
    // Label
    doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.darkText);
    const labelIndent = item.isExpense ? 8 : 0;
    doc.text(item.label, x + labelIndent, itemY + 3, { width: labelWidth - 10 - labelIndent });
    
    // Calculate bar width
    const barWidth = Math.max(2, (Math.abs(item.value) / maxValue) * chartWidth);
    
    // Determine color - minimal palette
    let barColor = COLORS_CHART.expense;
    if (item.label === 'Revenue') barColor = COLORS_CHART.revenue;
    else if (item.isTotal && item.label !== 'Net Profit') barColor = COLORS_CHART.profit;
    else if (item.label === 'Net Profit') barColor = COLORS_CHART.profitGood;
    
    // Draw bar
    doc.roundedRect(startX, itemY, barWidth, barHeight, 2).fill(barColor);
    
    // Value text
    doc.font(FONTS.bold).fontSize(8);
    const valueText = `${Math.abs(item.value).toFixed(1)}%`;
    
    if (barWidth > 40) {
      doc.fillColor(COLORS.white);
      doc.text(valueText, startX + 8, itemY + 4, { width: barWidth - 16 });
    } else {
      doc.fillColor(COLORS.darkText);
      doc.text(valueText, startX + barWidth + 5, itemY + 4, { width: 45 });
    }
  });
  
  return y + data.length * (barHeight + 3) + 8;
}

// ============ HELPER: DRAW METRIC WITH SCALE ============
function drawMetricWithScale(doc, label, value, min, max, goodMin, goodMax, x, y, width) {
  // Draws a metric with a horizontal scale showing good/bad ranges
  const barHeight = 8;
  const labelWidth = 70;
  const scaleWidth = width - labelWidth - 60;
  const scaleX = x + labelWidth;
  
  // Parse value
  const numValue = parseFloat(String(value).replace(/[%x]/g, '')) || 0;
  
  // Label
  doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.darkText);
  doc.text(label, x, y, { width: labelWidth - 5 });
  
  // Scale background (light gray)
  doc.rect(scaleX, y, scaleWidth, barHeight).fill('#E5E7EB');
  
  // Good range (subtle green zone)
  const goodStartPct = Math.max(0, (goodMin - min) / (max - min));
  const goodEndPct = Math.min(1, (goodMax - min) / (max - min));
  const goodStartX = scaleX + goodStartPct * scaleWidth;
  const goodWidth = (goodEndPct - goodStartPct) * scaleWidth;
  doc.rect(goodStartX, y, goodWidth, barHeight).fill('#D1FAE5'); // Light green
  
  // Current value marker
  const valuePct = Math.max(0, Math.min(1, (numValue - min) / (max - min)));
  const markerX = scaleX + valuePct * scaleWidth;
  
  // Draw marker (gold diamond)
  doc.save();
  doc.fillColor(COLORS.gold);
  doc.moveTo(markerX, y - 2)
     .lineTo(markerX + 4, y + barHeight / 2)
     .lineTo(markerX, y + barHeight + 2)
     .lineTo(markerX - 4, y + barHeight / 2)
     .fill();
  doc.restore();
  
  // Value text
  doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.darkText);
  doc.text(String(value || '-'), scaleX + scaleWidth + 8, y, { width: 50 });
  
  return y + barHeight + 12;
}

// ============ PAGE 6: FINANCIAL HEALTH - CLEAN DESIGN ============
function drawPage6_Financials(doc, report, pageNum) {
  const sections = report.sections || {};
  const incomeStatement = sections.incomeStatement || {};
  const cashFlow = sections.cashFlow || {};
  const valuation = sections.valuation || {};
  const analystLandscape = sections.analystLandscape || {};
  const returnMetrics = sections.returnMetrics || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'Financial Health & Valuation', y);
  
  // ========== SECTION 1: Revenue & Profitability ==========
  y = drawSubHeading(doc, 'Revenue & Profitability', y);
  
  const revenue = incomeStatement.revenue || {};
  const margins = incomeStatement.margins || {};
  
  // Revenue metrics in a single line
  doc.font(FONTS.body).fontSize(SIZES.body).fillColor(COLORS.darkText);
  const revenueText = `Revenue: ${revenue.ttm || 'N/A'} | 5Y CAGR: ${revenue.growth5Y || 'N/A'} | Recent Growth: ${revenue.growthTTM || 'N/A'}`;
  doc.text(revenueText, PAGE.marginLeft, y, { width: PAGE.contentWidth });
  y = doc.y + 10;
  
  // Margins table - GOLD header
  if (margins.gross || margins.operating || margins.net) {
    const colWidth = PAGE.contentWidth / 3;
    
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 18).fill(COLORS.gold);
    doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.white);
    doc.text('Gross Margin', PAGE.marginLeft + 5, y + 4, { width: colWidth - 10 });
    doc.text('Operating Margin', PAGE.marginLeft + colWidth + 5, y + 4, { width: colWidth - 10 });
    doc.text('Net Margin', PAGE.marginLeft + colWidth * 2 + 5, y + 4, { width: colWidth - 10 });
    y += 18;
    
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 22).fill(COLORS.ultraLightGray);
    doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
    doc.text(margins.gross || '-', PAGE.marginLeft + 5, y + 5, { width: colWidth - 10 });
    doc.text(margins.operating || '-', PAGE.marginLeft + colWidth + 5, y + 5, { width: colWidth - 10 });
    doc.text(margins.net || '-', PAGE.marginLeft + colWidth * 2 + 5, y + 5, { width: colWidth - 10 });
    y += 28;
  }
  
  // ========== SECTION 2: Simplified Waterfall ==========
  const parsePercent = (val) => {
    if (!val || val === 'N/A' || val === '-') return 0;
    return parseFloat(String(val).replace('%', '')) || 0;
  };
  
  const grossMargin = parsePercent(margins.gross);
  const operatingMargin = parsePercent(margins.operating);
  const netMargin = parsePercent(margins.net);
  
  if (grossMargin > 0 || netMargin > 0) {
    const cogs = 100 - grossMargin;
    const opex = grossMargin - operatingMargin;
    const otherExp = operatingMargin - netMargin;
    
    const waterfallData = [
      { label: 'Revenue', value: 100, isTotal: false },
      { label: 'COGS', value: cogs > 0 ? cogs : 0, isExpense: true },
      { label: 'Gross Profit', value: grossMargin, isTotal: true },
      { label: 'OpEx', value: opex > 0 ? opex : 0, isExpense: true },
      { label: 'Operating Income', value: operatingMargin, isTotal: true },
      { label: 'Tax & Other', value: otherExp > 0 ? otherExp : 0, isExpense: true },
      { label: 'Net Profit', value: netMargin, isTotal: true },
    ];
    
    y = drawWaterfallChart(doc, waterfallData, PAGE.marginLeft, y, PAGE.contentWidth, 180);
  }
  
  // ========== SECTION 3: Return on Capital Metrics with Scales ==========
  y += 5;
  doc.font(FONTS.bold).fontSize(SIZES.sectionTitle).fillColor(COLORS.darkText);
  doc.text('Return on Capital', PAGE.marginLeft, y);
  y += 18;
  
  // Scale legend
  doc.font(FONTS.body).fontSize(7).fillColor(COLORS.lightGray);
  doc.text('Green zone = Good range for sector', PAGE.marginLeft + 150, y - 14);
  
  // ROE - Return on Equity (good range: 15-25%)
  const roe = returnMetrics.roe || valuation.multiples?.roe || '-';
  y = drawMetricWithScale(doc, 'ROE', roe, 0, 50, 15, 30, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // ROA - Return on Assets (good range: 5-15%)
  const roa = returnMetrics.roa || valuation.multiples?.roa || '-';
  y = drawMetricWithScale(doc, 'ROA', roa, 0, 30, 5, 15, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // ROIC - Return on Invested Capital (good range: 10-20%)
  const roic = returnMetrics.roic || valuation.multiples?.roic || '-';
  y = drawMetricWithScale(doc, 'ROIC', roic, 0, 40, 10, 25, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // ========== SECTION 4: Valuation Multiples with Scales ==========
  y += 8;
  doc.font(FONTS.bold).fontSize(SIZES.sectionTitle).fillColor(COLORS.darkText);
  doc.text('Valuation Multiples', PAGE.marginLeft, y);
  y += 18;
  
  const multiples = valuation.multiples || {};
  
  // P/E Ratio (good range varies by sector, using 15-25 as general)
  const pe = multiples.pe || '-';
  y = drawMetricWithScale(doc, 'P/E', pe, 0, 100, 10, 25, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // EV/EBITDA (good range: 8-15)
  const evEbitda = multiples.evEbitda || '-';
  y = drawMetricWithScale(doc, 'EV/EBITDA', evEbitda, 0, 50, 8, 18, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // EV/Revenue (good range: 1-5)
  const evRevenue = multiples.evRevenue || '-';
  y = drawMetricWithScale(doc, 'EV/Revenue', evRevenue, 0, 30, 1, 8, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // FCF Yield (good range: 4-8%)
  const fcfYield = multiples.fcfYield || '-';
  y = drawMetricWithScale(doc, 'FCF Yield', fcfYield, 0, 15, 3, 10, PAGE.marginLeft, y, PAGE.contentWidth);
  
  // ========== SECTION 5: Quick Summary ==========
  y += 8;
  doc.font(FONTS.bold).fontSize(SIZES.sectionTitle).fillColor(COLORS.darkText);
  doc.text('Market View', PAGE.marginLeft, y);
  y += 16;
  
  // Price and Market Cap
  doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
  doc.text(`${valuation.currentPrice || 'N/A'}`, PAGE.marginLeft, y, { continued: true });
  doc.font(FONTS.body).fillColor(COLORS.mediumGray);
  doc.text(` | Market Cap: ${valuation.marketCap || 'N/A'}`);
  y = doc.y + 8;
  
  // Analyst view
  if (analystLandscape.consensus) {
    doc.font(FONTS.body).fontSize(SIZES.small).fillColor(COLORS.darkText);
    const analystText = `Analyst Consensus: ${analystLandscape.consensus} | Target: ${analystLandscape.targetMedian || 'N/A'} (${analystLandscape.targetLow || '-'} - ${analystLandscape.targetHigh || '-'})`;
    doc.text(analystText, PAGE.marginLeft, y, { width: PAGE.contentWidth });
  }
  
  drawFooter(doc, pageNum);
}

// ============ PAGE 7: VALUATION & MARKET VIEW (Combined) ============
function drawPage7_Valuation(doc, report, pageNum) {
  const sections = report.sections || {};
  const valuation = sections.valuation || {};
  const expectationsGap = sections.expectationsGap || {};
  const analystLandscape = sections.analystLandscape || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'Valuation & Market View', y);
  
  // Current Valuation - compact header
  y = drawSubHeading(doc, 'Current Valuation', y);
  
  // Price and Market Cap in single line
  doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
  doc.text(`${valuation.currentPrice || 'N/A'}`, PAGE.marginLeft, y, { continued: true });
  doc.font(FONTS.body).fillColor(COLORS.mediumGray);
  doc.text(` | Market Cap: ${valuation.marketCap || 'N/A'}`);
  y = doc.y + 8;
  
  // Multiples table - 4 columns horizontal
  const multiples = valuation.multiples || {};
  const colWidth = PAGE.contentWidth / 4;
  
  // Header row
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 18).fill(COLORS.gold);
  doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.white);
  doc.text('P/E', PAGE.marginLeft + 5, y + 4, { width: colWidth - 10 });
  doc.text('EV/EBITDA', PAGE.marginLeft + colWidth + 5, y + 4, { width: colWidth - 10 });
  doc.text('EV/Revenue', PAGE.marginLeft + colWidth * 2 + 5, y + 4, { width: colWidth - 10 });
  doc.text('FCF Yield', PAGE.marginLeft + colWidth * 3 + 5, y + 4, { width: colWidth - 10 });
  y += 18;
  
  // Values row
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 20).fill(COLORS.ultraLightGray);
  doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
  doc.text(multiples.pe || '-', PAGE.marginLeft + 5, y + 4, { width: colWidth - 10 });
  doc.text(multiples.evEbitda || '-', PAGE.marginLeft + colWidth + 5, y + 4, { width: colWidth - 10 });
  doc.text(multiples.evRevenue || '-', PAGE.marginLeft + colWidth * 2 + 5, y + 4, { width: colWidth - 10 });
  doc.text(multiples.fcfYield || '-', PAGE.marginLeft + colWidth * 3 + 5, y + 4, { width: colWidth - 10 });
  y += 28;
  
  // Wall Street View - single header only
  y = drawSubHeading(doc, 'Wall Street View', y);
  
  // All analyst info in flowing text
  const consensus = analystLandscape.consensus || 'N/A';
  const buyCount = analystLandscape.buyCount || 0;
  const holdCount = analystLandscape.holdCount || 0;
  const sellCount = analystLandscape.sellCount || 0;
  const targetLow = analystLandscape.targetLow || 'N/A';
  const targetHigh = analystLandscape.targetHigh || 'N/A';
  const targetMedian = analystLandscape.targetMedian || 'N/A';
  
  const analystText = `Wall Street's consensus is ${consensus} with ${buyCount} analysts rating Buy, ${holdCount} Hold, and ${sellCount} Sell. Price targets range from ${targetLow} to ${targetHigh}, with a median target of ${targetMedian}.`;
  y = drawParagraph(doc, analystText, y);
  
  // Key debates if any
  if (analystLandscape.disagreements?.length > 0) {
    y += 5;
    const debatesText = `Key debates: ${analystLandscape.disagreements.join('; ')}.`;
    y = drawParagraph(doc, debatesText, y);
  }
  
  drawFooter(doc, pageNum);
}

// ============ PAGE 8: RISK ASSESSMENT ============
function drawPage8_Risks(doc, report, pageNum) {
  const sections = report.sections || {};
  const riskRegister = sections.riskRegister || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'What Could Go Wrong', y);
  
  // Risk narrative first
  if (riskRegister.riskNarrative) {
    y = drawParagraph(doc, riskRegister.riskNarrative, y);
    y += 8;
  }
  
  // Combined risk table with fixed column widths
  const allRisks = [];
  
  const macroRisks = riskRegister.macroRisks || [];
  macroRisks.forEach(r => allRisks.push({ ...r, category: 'Macro' }));
  
  const execRisks = riskRegister.executionRisks || [];
  execRisks.forEach(r => allRisks.push({ ...r, category: 'Execution' }));
  
  const compRisks = riskRegister.competitionRisks || [];
  compRisks.forEach(r => allRisks.push({ ...r, category: 'Competition' }));
  
  if (allRisks.length > 0) {
    // Fixed column widths
    const colWidths = [PAGE.contentWidth * 0.18, PAGE.contentWidth * 0.52, PAGE.contentWidth * 0.15, PAGE.contentWidth * 0.15];
    
    // Header
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 20).fill(COLORS.gold);
    doc.font(FONTS.bold).fontSize(SIZES.small).fillColor(COLORS.white);
    doc.text('Category', PAGE.marginLeft + 5, y + 5, { width: colWidths[0] - 10 });
    doc.text('Risk Factor', PAGE.marginLeft + colWidths[0] + 5, y + 5, { width: colWidths[1] - 10 });
    doc.text('Likelihood', PAGE.marginLeft + colWidths[0] + colWidths[1] + 5, y + 5, { width: colWidths[2] - 10 });
    doc.text('Impact', PAGE.marginLeft + colWidths[0] + colWidths[1] + colWidths[2] + 5, y + 5, { width: colWidths[3] - 10 });
    y += 20;
    
    // Rows - no colors, clean
    doc.font(FONTS.body).fontSize(SIZES.small);
    allRisks.slice(0, 8).forEach((r, idx) => {
      const bgColor = idx % 2 === 0 ? COLORS.ultraLightGray : COLORS.white;
      const rowHeight = 22;
      
      doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, rowHeight).fill(bgColor);
      doc.fillColor(COLORS.mediumGray);
      doc.text(r.category || '', PAGE.marginLeft + 5, y + 5, { width: colWidths[0] - 10 });
      doc.fillColor(COLORS.darkText);
      doc.text(r.risk || '', PAGE.marginLeft + colWidths[0] + 5, y + 5, { width: colWidths[1] - 10 });
      doc.text(r.probability || '', PAGE.marginLeft + colWidths[0] + colWidths[1] + 5, y + 5, { width: colWidths[2] - 10 });
      doc.text(r.impact || '', PAGE.marginLeft + colWidths[0] + colWidths[1] + colWidths[2] + 5, y + 5, { width: colWidths[3] - 10 });
      
      y += rowHeight;
    });
    y += 10;
  }
  
  // Early Warning Signals - as paragraph
  const warnings = riskRegister.earlyWarningSignals || [];
  if (warnings.length > 0) {
    y = drawSubHeading(doc, 'What to Watch', y);
    const warningsText = warnings.join('. ') + '.';
    y = drawParagraph(doc, warningsText, y);
  }
  
  // Kill Switch - simple gray box, no red
  const killSwitch = riskRegister.killSwitch || {};
  if (killSwitch.trigger) {
    y += 8;
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 40).fill(COLORS.ultraLightGray);
    y += 10;
    doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
    doc.text('Exit Trigger: ', PAGE.marginLeft + 10, y, { continued: true });
    doc.font(FONTS.body);
    doc.text(killSwitch.trigger, { width: PAGE.contentWidth - 30 });
    y = doc.y + 15;
  }
  
  drawFooter(doc, pageNum);
}

// ============ PAGE 9: INVESTMENT CONCLUSION ============
function drawPage9_Conclusion(doc, report, pageNum) {
  const sections = report.sections || {};
  const thesis = sections.thesis || {};
  const scenarios = sections.scenarios || {};
  const whoThisIsFor = sections.whoThisIsFor || {};
  
  drawPageHeader(doc, report.ticker, report.company_name, pageNum);
  let y = PAGE.contentTop;
  
  y = drawSectionTitle(doc, 'The Bottom Line', y);
  
  // The Thesis - as quote box
  if (thesis.oneLiner) {
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 36).fill(COLORS.ultraLightGray);
    doc.font(FONTS.bold).fontSize(SIZES.body).fillColor(COLORS.darkText);
    doc.text(`"${thesis.oneLiner}"`, PAGE.marginLeft + 10, y + 10, { width: PAGE.contentWidth - 20, align: 'center' });
    y += 46;
  }
  
  // The Case - as flowing paragraphs, no "Key: Value" format
  y = drawSubHeading(doc, 'Our Investment Thesis', y);
  
  // Combine thesis points into narrative
  let thesisNarrative = '';
  if (thesis.whyYes) thesisNarrative += thesis.whyYes + ' ';
  if (thesis.whyNow) thesisNarrative += thesis.whyNow + ' ';
  if (thesis.whatMarketMisses) thesisNarrative += thesis.whatMarketMisses;
  
  if (thesisNarrative.trim()) {
    y = drawParagraph(doc, thesisNarrative.trim(), y);
  }
  
  // Scenario Analysis - as flowing text, no colors
  y += 10;
  y = drawSubHeading(doc, 'Scenario Analysis', y);
  
  const bull = scenarios.bull || {};
  const base = scenarios.base || {};
  const bear = scenarios.bear || {};
  
  // Build scenario narrative
  let scenarioText = '';
  
  if (bull.target) {
    scenarioText += `In an optimistic scenario (${bull.probability || '70%'} probability), we see ${bull.target} upside`;
    if (bull.requirements?.length > 0) {
      scenarioText += ` if ${bull.requirements.join(' and ').toLowerCase()}`;
    }
    scenarioText += '. ';
  }
  
  if (base.target) {
    scenarioText += `Our base case (${base.probability || '20%'} probability) targets ${base.target}`;
    if (base.assumptions?.length > 0) {
      scenarioText += ` assuming ${base.assumptions.join(' and ').toLowerCase()}`;
    }
    scenarioText += '. ';
  }
  
  if (bear.target) {
    scenarioText += `The downside case (${bear.probability || '10%'} probability) is ${bear.target}`;
    if (bear.triggers?.length > 0) {
      scenarioText += ` if ${bear.triggers.join(' or ').toLowerCase()}`;
    }
    scenarioText += '.';
  }
  
  if (scenarioText.trim()) {
    y = drawParagraph(doc, scenarioText.trim(), y);
  }
  
  // Who This Is For - as flowing text
  y += 10;
  y = drawSubHeading(doc, 'Who Should Own This Stock', y);
  
  let suitabilityText = '';
  if (whoThisIsFor.investorType) {
    suitabilityText += `This stock is best suited for ${whoThisIsFor.investorType.toLowerCase()} investors`;
  }
  if (whoThisIsFor.patienceRequired) {
    suitabilityText += ` with a ${whoThisIsFor.patienceRequired.toLowerCase()} time horizon`;
  }
  if (whoThisIsFor.riskType) {
    suitabilityText += ` and ${whoThisIsFor.riskType.toLowerCase()} risk tolerance`;
  }
  suitabilityText += '.';
  
  if (whoThisIsFor.notSuitedFor) {
    suitabilityText += ` Not recommended for ${whoThisIsFor.notSuitedFor.toLowerCase()}.`;
  }
  
  if (suitabilityText.trim()) {
    y = drawParagraph(doc, suitabilityText.trim(), y);
  }
  
  drawFooter(doc, pageNum);
}

// ============ DISCLAIMER PAGE (v7.5 - ISM Style with Gold Frame) ============
function drawDisclaimerPage(doc, finotaurLogoBuffer = null) {
  doc.addPage();
  
  // BLACK BACKGROUND
  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  
  const frameMargin = 25;
  const frameWidth = PAGE.width - (frameMargin * 2);
  const frameHeight = PAGE.height - (frameMargin * 2);
  
  // OUTER GOLD BORDER (thick)
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .rect(frameMargin, frameMargin, frameWidth, frameHeight)
     .stroke();
  
  // INNER GOLD BORDER (thin - creates double frame effect)
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .rect(frameMargin + 8, frameMargin + 8, frameWidth - 16, frameHeight - 16)
     .stroke();
  
  let y = frameMargin + 35;
  const centerX = PAGE.width / 2;
  const contentMargin = frameMargin + 35;
  const contentWidth = frameWidth - 70;
  
  // ═══════════════════════════════════════════════════════════════════
  // FINOTAUR TEXT
  // ═══════════════════════════════════════════════════════════════════
  doc.fillColor(COLORS.gold)
     .fontSize(28)
     .font(FONTS.bold)
     .text('FINOTAUR', 0, y, { align: 'center', width: PAGE.width });
  
  y += 40;
  
  // LOGO under FINOTAUR text
  if (finotaurLogoBuffer) {
    try {
      const logoWidth = 120;
      const logoX = (PAGE.width - logoWidth) / 2;
      doc.image(finotaurLogoBuffer, logoX, y, { width: logoWidth });
      y += 70;
    } catch (e) {
      y += 10;
    }
  } else {
    y += 10;
  }
  
  // Gold decorative line
  doc.strokeColor(COLORS.gold)
     .lineWidth(1.5)
     .moveTo(centerX - 80, y)
     .lineTo(centerX + 80, y)
     .stroke();
  
  y += 25;
  
  // ═══════════════════════════════════════════════════════════════════
  // IMPORTANT DISCLAIMER TITLE
  // ═══════════════════════════════════════════════════════════════════
  doc.fillColor(COLORS.gold)
     .fontSize(18)
     .font(FONTS.bold)
     .text('IMPORTANT DISCLAIMER', 0, y, { align: 'center', width: PAGE.width });
  
  y += 30;
  
  // Gold line under title
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .moveTo(centerX - 100, y)
     .lineTo(centerX + 100, y)
     .stroke();
  
  y += 25;
  
  // ═══════════════════════════════════════════════════════════════════
  // DISCLAIMER SECTIONS
  // ═══════════════════════════════════════════════════════════════════
  const disclaimerSections = [
    {
      title: 'GENERAL INFORMATION ONLY',
      content: 'This report is produced by Finotaur for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.'
    },
    {
      title: 'NOT INVESTMENT ADVICE',
      content: 'This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. Finotaur is NOT a registered investment adviser or broker-dealer.'
    },
    {
      title: 'RISK DISCLOSURE',
      content: 'Trading and investing involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital.'
    },
    {
      title: 'NO GUARANTEES',
      content: 'Finotaur makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.'
    },
    {
      title: 'YOUR RESPONSIBILITY',
      content: 'You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.'
    },
    {
      title: 'LIMITATION OF LIABILITY',
      content: 'Finotaur shall NOT be liable for any damages arising from your use of or reliance on this report.'
    }
  ];
  
  for (const section of disclaimerSections) {
    if (y > PAGE.height - 200) break;
    
    // Section title in GOLD with line underneath
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(9)
       .text(section.title, contentMargin, y);
    
    y += 12;
    
    // Small gold line under section title
    doc.strokeColor(COLORS.gold)
       .lineWidth(0.5)
       .moveTo(contentMargin, y)
       .lineTo(contentMargin + 120, y)
       .stroke();
    
    y += 8;
    
    // Section content in WHITE
    doc.fillColor('#FFFFFF')
       .font(FONTS.body)
       .fontSize(8.5)
       .text(section.content, contentMargin, y, { width: contentWidth, align: 'justify' });
    
    y += doc.heightOfString(section.content, { width: contentWidth }) + 12;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // COPYRIGHT WARNING - RED BOX
  // ═══════════════════════════════════════════════════════════════════
  
  y = PAGE.height - frameMargin - 135;
  
  // Red warning box
  const warningBoxX = contentMargin - 8;
  const warningBoxWidth = contentWidth + 16;
  const warningBoxHeight = 75;
  
  // Dark red background
  doc.rect(warningBoxX, y, warningBoxWidth, warningBoxHeight)
     .fill('#330000');
  
  // Red border
  doc.strokeColor('#CC0000')
     .lineWidth(2)
     .rect(warningBoxX, y, warningBoxWidth, warningBoxHeight)
     .stroke();
  
  y += 10;
  
  // Warning title in RED
  doc.fillColor('#FF3333')
     .font(FONTS.bold)
     .fontSize(10)
     .text('⚠ COPYRIGHT WARNING', contentMargin, y, { width: contentWidth, align: 'center' });
  
  y += 16;
  
  // Warning text in lighter red
  const copyrightWarning = 'This report is the exclusive intellectual property of FINOTAUR. Unauthorized reproduction, distribution, transmission, display, or publication of this report, in whole or in part, without the prior written consent of FINOTAUR is strictly prohibited and constitutes a violation of copyright law. Violators will be subject to legal action and may be liable for statutory damages.';
  
  doc.fillColor('#FF6666')
     .font(FONTS.body)
     .fontSize(7.5)
     .text(copyrightWarning, contentMargin, y, { width: contentWidth, align: 'justify' });
  
  // ═══════════════════════════════════════════════════════════════════
  // BOTTOM - Copyright and acknowledgment
  // ═══════════════════════════════════════════════════════════════════
  
  y = PAGE.height - frameMargin - 40;
  
  // Thin gold line
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .moveTo(contentMargin, y)
     .lineTo(contentMargin + contentWidth, y)
     .stroke();
  
  y += 12;
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.body)
     .fontSize(8)
     .text(`© ${new Date().getFullYear()} Finotaur. All Rights Reserved.`, 
           contentMargin, y, { width: contentWidth, align: 'center' });
  
  y += 12;
  
  doc.fillColor('#888888')
     .font(FONTS.body)
     .fontSize(7)
     .text('By reading this report, you acknowledge and agree to the terms above.', 
           contentMargin, y, { width: contentWidth, align: 'center' });
}

// ============ MAIN EXPORT ============
async function generateCompanyReportPDFBuffer(report, logoPath = null, companyLogoBuffer = null) {
  return new Promise((resolve, reject) => {
    try {
      // ═══════════════════════════════════════════════════════════════════
      // v7.5: CHECK IF ISM IS INCLUDED
      // ═══════════════════════════════════════════════════════════════════
      const includeIsm = report.meta?.includeIsm !== false && report.include_ism !== false;
      
      console.log('\n[PDF v7.5] Starting generation...');
      console.log('[PDF v7.5] Include ISM:', includeIsm);
      console.log('[PDF v7.5] Pages:', includeIsm ? '10 (with ISM)' : '8 (without ISM)');
      
      // DEBUG: Log what we received
      console.log('[PDF] === LOGO DEBUG ===');
      console.log('[PDF] logoPath type:', typeof logoPath);
      console.log('[PDF] logoPath value:', logoPath);
      console.log('[PDF] companyLogoBuffer type:', typeof companyLogoBuffer);
      console.log('[PDF] companyLogoBuffer is Buffer:', Buffer.isBuffer(companyLogoBuffer));
      console.log('[PDF] companyLogoBuffer length:', companyLogoBuffer?.length || 0);
      
      // Load Finotaur logo with FALLBACK paths
      let finotaurLogoBuffer = null;
      
      // Try provided path first
      if (logoPath) {
        try {
          if (Buffer.isBuffer(logoPath)) {
            finotaurLogoBuffer = logoPath;
            console.log('[PDF] ✅ Finotaur logo provided as Buffer:', logoPath.length, 'bytes');
          } else if (typeof logoPath === 'string' && fs.existsSync(logoPath)) {
            finotaurLogoBuffer = fs.readFileSync(logoPath);
            console.log('[PDF] ✅ Finotaur logo loaded from provided path:', logoPath, finotaurLogoBuffer.length, 'bytes');
          } else {
            console.log('[PDF] ⚠️ Provided logoPath does not exist:', logoPath);
          }
        } catch (e) {
          console.log('[PDF] ⚠️ Could not load from provided path:', e.message);
        }
      }
      
      // FALLBACK: Try multiple paths if not loaded yet
      if (!finotaurLogoBuffer) {
        const fallbackPaths = [
          // Docker/Production paths
          '/app/finotaur-frontend/public/logo.png',
          '/app/public/logo.png',
          '/app/assets/logo.png',
          // Process-relative paths
          path.join(process.cwd(), 'public', 'logo.png'),
          path.join(process.cwd(), 'finotaur-frontend', 'public', 'logo.png'),
          path.join(process.cwd(), 'assets', 'logo.png'),
          // Parent directory paths
          path.join(process.cwd(), '..', 'public', 'logo.png'),
          path.join(process.cwd(), '..', 'finotaur-frontend', 'public', 'logo.png'),
        ];
        
        console.log('[PDF] Trying fallback paths...');
        for (const fallbackPath of fallbackPaths) {
          try {
            if (fs.existsSync(fallbackPath)) {
              finotaurLogoBuffer = fs.readFileSync(fallbackPath);
              console.log('[PDF] ✅ Finotaur logo loaded from FALLBACK:', fallbackPath, finotaurLogoBuffer.length, 'bytes');
              break;
            }
          } catch (e) {
            // Continue to next path
          }
        }
        
        if (!finotaurLogoBuffer) {
          console.log('[PDF] ⚠️ Finotaur logo not found in any fallback path');
          console.log('[PDF] Searched paths:', fallbackPaths.join(', '));
        }
      }
      
      // Summary
      console.log('[PDF] === LOGO SUMMARY ===');
      console.log('[PDF] finotaurLogoBuffer ready:', !!finotaurLogoBuffer, finotaurLogoBuffer?.length || 0, 'bytes');
      console.log('[PDF] companyLogoBuffer ready:', !!companyLogoBuffer, companyLogoBuffer?.length || 0, 'bytes');
      
      const chunks = [];
      const doc = new PDFDocument({ 
        size: 'LETTER',
        margin: 0,
        autoFirstPage: false,
        bufferPages: true,
      });
      
      registerFonts(doc);
      
      doc.on('data', chunk => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);
      
      // ═══════════════════════════════════════════════════════════════════
      // v7.5: DYNAMIC PAGE GENERATION BASED ON ISM FLAG
      // ═══════════════════════════════════════════════════════════════════
      
      let pageNum = 0;
      
      // ========== PAGE 0: COVER (ALWAYS) ==========
      doc.addPage();
      drawPage0(doc, report, companyLogoBuffer, finotaurLogoBuffer);
      
      if (includeIsm) {
        // ═══════════════════════════════════════════════════════════════════
        // WITH ISM: 10 pages (0-9)
        // ═══════════════════════════════════════════════════════════════════
        
        // PAGE 1: INTRODUCTION (ISM ONLY)
        doc.addPage();
        drawPage1_Introduction(doc, report, 1);
        
        // PAGE 2: MACRO CONTEXT (ISM ONLY)
        doc.addPage();
        drawPage2_MacroContext(doc, report, 2);
        
        // PAGE 3: COMPANY PROFILE
        doc.addPage();
        drawPage3_CompanyProfile(doc, report, 3);
        
        // PAGE 4: BUSINESS MODEL
        doc.addPage();
        drawPage4_BusinessModel(doc, report, 4);
        
        // PAGE 5: COMPETITIVE POSITION
        doc.addPage();
        drawPage5_Competition(doc, report, 5);
        
        // PAGE 6: FINANCIAL HEALTH
        doc.addPage();
        drawPage6_Financials(doc, report, 6);
        
        // PAGE 7: VALUATION & MARKET VIEW
        doc.addPage();
        drawPage7_Valuation(doc, report, 7);
        
        // PAGE 8: RISK ASSESSMENT
        doc.addPage();
        drawPage8_Risks(doc, report, 8);
        
        // PAGE 9: CONCLUSION
        doc.addPage();
        drawPage9_Conclusion(doc, report, 9);
        
        console.log('[PDF v7.5] Generated: 10 pages (0-9) WITH ISM + disclaimer');
        
      } else {
        // ═══════════════════════════════════════════════════════════════════
        // WITHOUT ISM: 8 pages (0-7) - SKIP pages 1 and 2
        // ═══════════════════════════════════════════════════════════════════
        
        // PAGE 1: COMPANY PROFILE (was page 3)
        doc.addPage();
        drawPage3_CompanyProfile(doc, report, 1);
        
        // PAGE 2: BUSINESS MODEL (was page 4)
        doc.addPage();
        drawPage4_BusinessModel(doc, report, 2);
        
        // PAGE 3: COMPETITIVE POSITION (was page 5)
        doc.addPage();
        drawPage5_Competition(doc, report, 3);
        
        // PAGE 4: FINANCIAL HEALTH (was page 6)
        doc.addPage();
        drawPage6_Financials(doc, report, 4);
        
        // PAGE 5: VALUATION & MARKET VIEW (was page 7)
        doc.addPage();
        drawPage7_Valuation(doc, report, 5);
        
        // PAGE 6: RISK ASSESSMENT (was page 8)
        doc.addPage();
        drawPage8_Risks(doc, report, 6);
        
        // PAGE 7: CONCLUSION (was page 9)
        doc.addPage();
        drawPage9_Conclusion(doc, report, 7);
        
        console.log('[PDF v7.5] Generated: 8 pages (0-7) WITHOUT ISM + disclaimer');
      }
      
      // ========== DISCLAIMER (ALWAYS) ==========
      drawDisclaimerPage(doc, finotaurLogoBuffer);
      
      doc.end();
      
    } catch (error) {
      console.error('[PDF] Error:', error);
      reject(error);
    }
  });
}

// File-based generation
async function generateCompanyReportPDF(report, outputPath, logoPath = null, companyLogoBuffer = null) {
  const buffer = await generateCompanyReportPDFBuffer(report, logoPath, companyLogoBuffer);
  fs.writeFileSync(outputPath, buffer);
  return outputPath;
}

// ============ EXPORTS ============
module.exports = {
  generateCompanyReportPDFBuffer,
  generateCompanyReportPDF,
};