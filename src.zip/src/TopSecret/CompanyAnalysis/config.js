// =====================================================
// COMPANY ANALYSIS REPORT CONFIGURATION - v6.0
// =====================================================
// Location: src/TopSecret/CompanyAnalysis/config.js
// 
// v6.0 RESTRUCTURE: ISM-DRIVEN COMPANY DEEP DIVE
// Based on Institutional Research Framework (5-6 Pages)
//
// NEW PAGE STRUCTURE:
// Page 0: Cover + Macro Trigger - "Why this report exists now"
// Page 1: Sector Funnel - "Where macro pressure becomes investable"
// Page 2: Why This Company - "From sector thesis to specific exposure"
// Page 3: Business Reality + Driver Hierarchy
// Page 4: Financial Core + Unit Economics
// Page 5: Forward View - Scenarios + Catalysts
// Page 6: Investment Decision + Action Checklist
// Page 7: One-Page Recall Summary
//
// KEY CHANGE: ISM analysis FIRST, then sectors, then company
// =====================================================

/**
 * Report Generation Phases - REORDERED for ISM-first flow
 */
const PHASES = {
  DATA_ACQUISITION: 'DATA_ACQUISITION',
  ISM_MACRO_ANALYSIS: 'ISM_MACRO_ANALYSIS',      // NEW: ISM comes first
  SECTOR_ANALYSIS: 'SECTOR_ANALYSIS',             // NEW: Sector funnel
  COMPANY_SELECTION: 'COMPANY_SELECTION',         // NEW: Why this company
  BUSINESS_ANALYSIS: 'BUSINESS_ANALYSIS',
  FINANCIAL_ANALYSIS: 'FINANCIAL_ANALYSIS',
  FORWARD_ANALYSIS: 'FORWARD_ANALYSIS',
  INVESTMENT_SYNTHESIS: 'INVESTMENT_SYNTHESIS',
  QUALITY_ASSURANCE: 'QUALITY_ASSURANCE',
};

/**
 * Phase display information
 */
const PHASE_INFO = {
  [PHASES.DATA_ACQUISITION]: {
    label: 'Data Acquisition',
    color: '#3B82F6',
    order: 1,
  },
  [PHASES.ISM_MACRO_ANALYSIS]: {
    label: 'ISM Macro Analysis',
    color: '#DC2626',
    order: 2,
  },
  [PHASES.SECTOR_ANALYSIS]: {
    label: 'Sector Analysis',
    color: '#F97316',
    order: 3,
  },
  [PHASES.COMPANY_SELECTION]: {
    label: 'Company Selection',
    color: '#8B5CF6',
    order: 4,
  },
  [PHASES.BUSINESS_ANALYSIS]: {
    label: 'Business Analysis',
    color: '#06B6D4',
    order: 5,
  },
  [PHASES.FINANCIAL_ANALYSIS]: {
    label: 'Financial Analysis',
    color: '#10B981',
    order: 6,
  },
  [PHASES.FORWARD_ANALYSIS]: {
    label: 'Forward Analysis',
    color: '#EAB308',
    order: 7,
  },
  [PHASES.INVESTMENT_SYNTHESIS]: {
    label: 'Investment Synthesis',
    color: '#EC4899',
    order: 8,
  },
  [PHASES.QUALITY_ASSURANCE]: {
    label: 'Quality Assurance',
    color: '#6366F1',
    order: 9,
  },
};

// =====================================================
// PAGE 0: MACRO TRIGGER CONFIGURATION
// =====================================================

/**
 * ISM Sub-components for Macro Trigger analysis
 */
const ISM_COMPONENTS = {
  NEW_ORDERS: {
    id: 'new_orders',
    name: 'ISM New Orders',
    leadIndicator: true,
    description: 'Leading indicator of demand - most predictive of future activity',
    thresholds: { expansion: 52, contraction: 48, neutral: 50 },
  },
  PRODUCTION: {
    id: 'production',
    name: 'ISM Production',
    leadIndicator: false,
    description: 'Current output levels - coincident indicator',
    thresholds: { expansion: 52, contraction: 48, neutral: 50 },
  },
  EMPLOYMENT: {
    id: 'employment',
    name: 'ISM Employment',
    leadIndicator: false,
    description: 'Labor market conditions in manufacturing',
    thresholds: { expansion: 52, contraction: 48, neutral: 50 },
  },
  INVENTORIES: {
    id: 'inventories',
    name: 'ISM Inventories',
    leadIndicator: true,
    description: 'Inventory levels - inverse signal (low = bullish)',
    thresholds: { high: 52, low: 45, neutral: 48 },
  },
  PRICES_PAID: {
    id: 'prices_paid',
    name: 'ISM Prices Paid',
    leadIndicator: true,
    description: 'Input cost inflation - margin pressure signal',
    thresholds: { inflation: 60, deflation: 45, neutral: 52 },
  },
  SUPPLIER_DELIVERIES: {
    id: 'supplier_deliveries',
    name: 'ISM Supplier Deliveries',
    leadIndicator: false,
    description: 'Supply chain conditions - higher = slower deliveries',
    thresholds: { constrained: 55, unconstrained: 48, neutral: 50 },
  },
  NEW_EXPORT_ORDERS: {
    id: 'new_export_orders',
    name: 'ISM New Export Orders',
    leadIndicator: true,
    description: 'International demand signal',
    thresholds: { expansion: 52, contraction: 48, neutral: 50 },
  },
  BACKLOG: {
    id: 'backlog',
    name: 'ISM Backlog of Orders',
    leadIndicator: true,
    description: 'Demand queue - high backlog = capacity constraint',
    thresholds: { high: 52, low: 45, neutral: 48 },
  },
};

/**
 * Macro regime classifications
 */
const MACRO_REGIMES = {
  EXPANSION: {
    id: 'expansion',
    label: 'Expansion',
    description: 'Strong demand, rising orders, healthy margins',
    ismSignature: 'New Orders > 52, Prices Paid moderate',
    winners: ['Cyclicals', 'Industrials', 'Materials'],
    losers: ['Defensives', 'Utilities', 'Bonds'],
  },
  EARLY_SLOWDOWN: {
    id: 'early_slowdown',
    label: 'Early Slowdown',
    description: 'Orders softening but production still elevated',
    ismSignature: 'New Orders declining, Production still high',
    winners: ['Quality Growth', 'Cash-rich'],
    losers: ['Leveraged cyclicals', 'Inventory-heavy'],
  },
  CONTRACTION: {
    id: 'contraction',
    label: 'Contraction',
    description: 'Declining demand, inventory build, margin pressure',
    ismSignature: 'New Orders < 48, Inventories rising',
    winners: ['Defensives', 'Dividend payers'],
    losers: ['Cyclicals', 'High-beta'],
  },
  RECOVERY: {
    id: 'recovery',
    label: 'Recovery',
    description: 'Orders rebounding from trough, lean inventories',
    ismSignature: 'New Orders rising from <48, Inventories low',
    winners: ['Early cyclicals', 'Operating leverage plays'],
    losers: ['Defensives', 'Low-beta'],
  },
  STAGFLATION_RISK: {
    id: 'stagflation_risk',
    label: 'Stagflation Risk',
    description: 'Weak demand but elevated input costs',
    ismSignature: 'New Orders < 50, Prices Paid > 55',
    winners: ['Pricing power', 'Real assets'],
    losers: ['Cost-sensitive', 'Low margin'],
  },
  REACCELERATION: {
    id: 'reacceleration',
    label: 'Re-acceleration',
    description: 'Second leg up after mid-cycle pause',
    ismSignature: 'New Orders inflecting higher after dip',
    winners: ['Momentum cyclicals', 'Volume-sensitive'],
    losers: ['Defensives', 'Gold'],
  },
};

// =====================================================
// PAGE 1: SECTOR FUNNEL CONFIGURATION
// =====================================================

/**
 * Sector sensitivity to ISM components
 */
const SECTOR_ISM_SENSITIVITY = {
  INDUSTRIALS: {
    primaryDriver: 'NEW_ORDERS',
    secondaryDrivers: ['PRODUCTION', 'BACKLOG'],
    sensitivity: 'HIGH',
    lagMonths: 1,
    transmission: 'Direct order flow to revenue',
  },
  MATERIALS: {
    primaryDriver: 'PRODUCTION',
    secondaryDrivers: ['NEW_ORDERS', 'INVENTORIES'],
    sensitivity: 'HIGH',
    lagMonths: 0,
    transmission: 'Volume-driven, commodity price leverage',
  },
  CONSUMER_DISCRETIONARY: {
    primaryDriver: 'EMPLOYMENT',
    secondaryDrivers: ['NEW_ORDERS'],
    sensitivity: 'MEDIUM',
    lagMonths: 2,
    transmission: 'Consumer confidence → spending',
  },
  TECHNOLOGY: {
    primaryDriver: 'NEW_ORDERS',
    secondaryDrivers: ['BACKLOG'],
    sensitivity: 'MEDIUM',
    lagMonths: 3,
    transmission: 'CapEx cycle, enterprise spending',
  },
  FINANCIALS: {
    primaryDriver: 'NEW_ORDERS',
    secondaryDrivers: ['EMPLOYMENT'],
    sensitivity: 'MEDIUM',
    lagMonths: 2,
    transmission: 'Credit demand, loan growth',
  },
  ENERGY: {
    primaryDriver: 'PRODUCTION',
    secondaryDrivers: ['NEW_ORDERS'],
    sensitivity: 'HIGH',
    lagMonths: 0,
    transmission: 'Activity drives demand',
  },
  HEALTHCARE: {
    primaryDriver: null,
    secondaryDrivers: [],
    sensitivity: 'LOW',
    lagMonths: null,
    transmission: 'Defensive, non-cyclical',
  },
  UTILITIES: {
    primaryDriver: null,
    secondaryDrivers: ['PRODUCTION'],
    sensitivity: 'LOW',
    lagMonths: null,
    transmission: 'Defensive, rate-sensitive',
  },
  CONSUMER_STAPLES: {
    primaryDriver: null,
    secondaryDrivers: ['PRICES_PAID'],
    sensitivity: 'LOW',
    lagMonths: null,
    transmission: 'Cost pass-through only',
  },
  REAL_ESTATE: {
    primaryDriver: 'EMPLOYMENT',
    secondaryDrivers: ['NEW_ORDERS'],
    sensitivity: 'MEDIUM',
    lagMonths: 4,
    transmission: 'Job growth → occupancy',
  },
  COMMUNICATION_SERVICES: {
    primaryDriver: 'EMPLOYMENT',
    secondaryDrivers: [],
    sensitivity: 'LOW',
    lagMonths: 3,
    transmission: 'Ad spending tied to confidence',
  },
};

/**
 * Sector cycle positions
 */
const SECTOR_CYCLE_POSITIONS = {
  EARLY_CYCLE: {
    id: 'early_cycle',
    label: 'Early Cycle',
    description: 'First to benefit from recovery',
    sectors: ['Financials', 'Consumer Discretionary', 'Real Estate'],
  },
  MID_CYCLE: {
    id: 'mid_cycle',
    label: 'Mid Cycle',
    description: 'Expansion beneficiaries',
    sectors: ['Technology', 'Industrials', 'Materials'],
  },
  LATE_CYCLE: {
    id: 'late_cycle',
    label: 'Late Cycle',
    description: 'Last to peak, pricing power matters',
    sectors: ['Energy', 'Materials', 'Industrials'],
  },
  DEFENSIVE: {
    id: 'defensive',
    label: 'Defensive',
    description: 'Outperform in downturns',
    sectors: ['Healthcare', 'Utilities', 'Consumer Staples'],
  },
};

// =====================================================
// PAGE 2: COMPANY SELECTION CONFIGURATION
// =====================================================

/**
 * Company selection criteria from sector thesis
 */
const COMPANY_SELECTION_CRITERIA = {
  ISM_SENSITIVITY: {
    id: 'ism_sensitivity',
    label: 'ISM Sensitivity',
    description: 'How directly ISM changes flow to company P&L',
    weight: 30,
  },
  OPERATING_LEVERAGE: {
    id: 'operating_leverage',
    label: 'Operating Leverage',
    description: 'Margin expansion potential from volume',
    weight: 20,
  },
  MARKET_MISPRICING: {
    id: 'market_mispricing',
    label: 'Market Mispricing',
    description: 'Gap between ISM signal and current valuation',
    weight: 25,
  },
  COMPETITIVE_POSITION: {
    id: 'competitive_position',
    label: 'Competitive Position',
    description: 'Ability to capture sector tailwind',
    weight: 15,
  },
  CATALYST_TIMING: {
    id: 'catalyst_timing',
    label: 'Catalyst Timing',
    description: 'When ISM signal should hit earnings',
    weight: 10,
  },
};

/**
 * Exposure type classifications
 */
const EXPOSURE_TYPES = {
  CYCLICAL: {
    id: 'cyclical',
    label: 'Cyclical',
    description: 'Earnings highly correlated with economic cycles',
    characteristics: ['High ISM sensitivity', 'Operating leverage', 'Inventory cycles'],
    examples: ['Industrials', 'Autos', 'Semiconductors', 'Capital goods'],
  },
  COMPOUNDER: {
    id: 'compounder',
    label: 'Compounder',
    description: 'Steady earnings growth with reinvestment',
    characteristics: ['High ROIC', 'Reinvestment opportunity', 'Secular growth'],
    examples: ['Quality software', 'Consumer staples leaders', 'Healthcare franchises'],
  },
  REGIME_TRADE: {
    id: 'regime_trade',
    label: 'Regime Trade',
    description: 'Benefits from specific macro regime shifts',
    characteristics: ['Macro catalyst dependent', 'Positioning matters', 'Timing critical'],
    examples: ['Banks in rising rates', 'Energy in supply squeeze', 'EM exposure plays'],
  },
  DEFENSIVE: {
    id: 'defensive',
    label: 'Defensive',
    description: 'Stable earnings regardless of economic conditions',
    characteristics: ['Low beta', 'Stable margins', 'Dividend focus'],
    examples: ['Utilities', 'Healthcare', 'Consumer staples', 'REITs'],
  },
  TURNAROUND: {
    id: 'turnaround',
    label: 'Turnaround',
    description: 'Restructuring or operational improvement story',
    characteristics: ['Execution risk', 'New management', 'Asset value'],
    examples: ['Post-bankruptcy', 'Activist situations', 'Spin-offs'],
  },
};

/**
 * Decision horizon classifications
 */
const DECISION_HORIZONS = {
  TRADE: {
    id: 'trade',
    label: 'Trade',
    timeframe: '1-4 weeks',
    description: 'Event-driven or tactical',
    characteristics: ['Catalyst-driven', 'Technical setup', 'Risk/reward focused'],
  },
  POSITION: {
    id: 'position',
    label: 'Position',
    timeframe: '1-6 months',
    description: 'Medium-term thesis',
    characteristics: ['Earnings cycle', 'Sector rotation', 'Valuation gap'],
  },
  INVESTMENT: {
    id: 'investment',
    label: 'Investment',
    timeframe: '6+ months',
    description: 'Long-term fundamental',
    characteristics: ['Secular growth', 'Compounding value', 'Business quality'],
  },
};

/**
 * Driver hierarchy attention allocation
 */
const DRIVER_HIERARCHY = {
  PRIMARY: {
    id: 'primary',
    label: 'PRIMARY',
    attention: '100%',
    description: 'The ONE thing - if this changes, exit or enter',
    rule: 'Maximum 1 driver',
  },
  SECONDARY: {
    id: 'secondary',
    label: 'SECONDARY',
    attention: '30%',
    description: 'Important but not thesis-defining - affects sizing',
    rule: 'Maximum 3 drivers',
  },
  TERTIARY: {
    id: 'tertiary',
    label: 'TERTIARY',
    attention: '10%',
    description: 'Fine-tuning only',
    rule: 'Maximum 3 drivers',
  },
  NOISE: {
    id: 'noise',
    label: 'NOISE',
    attention: '0%',
    description: 'Ignore - wastes attention',
    rule: 'List common distractions to avoid',
  },
};

// =====================================================
// REPORT SECTIONS - v6.0 ISM-DRIVEN STRUCTURE
// =====================================================

/**
 * Report sections - ISM-driven flow
 */
const REPORT_SECTIONS = [
  {
    id: 'macro_trigger',
    number: 0,
    title: 'Cover + Macro Trigger',
    subtitle: 'למה הדוח הזה קיים עכשיו',
    titleEn: 'Why This Report Exists Now',
    description: 'ISM signal that triggered this analysis',
    requiredElements: [
      'Clear title (not marketing)',
      'Analyst Context (personal opening, 6-8 lines)',
      'Macro Signal Breakdown (narrative, no unnecessary tables)',
      'Macro Bottom Line (one summary sentence)',
    ],
    keyQuestion: 'What ISM signal triggered this analysis?',
    banList: ['Investment Opportunity', 'Top Stock Pick', 'generic market commentary'],
  },
  {
    id: 'sector_funnel',
    number: 1,
    title: 'Sector Funnel',
    subtitle: 'איפה הלחץ המאקרו הופך להשקעה',
    titleEn: 'Where Macro Pressure Becomes Investable',
    description: 'Funnel from macro to specific sectors',
    requiredElements: [
      'ISM → Sector Mapping (narrative paragraph)',
      'Sector Regime Definition (which cycle phase)',
      'Capital Behavior (is money entering/leaving)',
      'Why This Sector Matters NOW (timing justification)',
    ],
    keyQuestion: 'Which sectors benefit/suffer from this ISM regime?',
    banList: ['all sectors benefit', 'diversified approach', 'balanced exposure'],
  },
  {
    id: 'why_this_company',
    number: 2,
    title: 'Why This Company',
    subtitle: 'מהתזה הסקטוריאלית לחשיפה ספציפית',
    titleEn: 'From Sector Thesis to Specific Exposure',
    description: 'Justification for this specific company choice',
    requiredElements: [
      'Company Snapshot (dry facts only)',
      'ISM Sensitivity Lens (which ISM component hits this P&L)',
      'Competitive Context (vs direct competitors)',
      'Hypothesis (one sentence: what we are testing)',
    ],
    keyQuestion: 'Why this company specifically vs peers?',
    banList: ['well-positioned', 'industry leader', 'strong management'],
  },
  {
    id: 'business_reality',
    number: 3,
    title: 'Business Reality + Driver Hierarchy',
    subtitle: 'מה החברה באמת עושה + מה לעקוב',
    titleEn: 'What They Actually Do + What to Watch',
    description: 'Business model and driver prioritization',
    requiredElements: [
      'What They Actually Sell (one sentence)',
      'Revenue Model (how money flows)',
      'Customer Profile (who pays)',
      'Driver Hierarchy: Primary/Secondary/Tertiary/Noise',
    ],
    keyQuestion: 'What single driver should I watch?',
    banList: ['multiple growth levers', 'diversified revenue', 'broad market opportunity'],
  },
  {
    id: 'financial_core',
    number: 4,
    title: 'Financial Core + Unit Economics',
    subtitle: 'המספרים + יחידת הערך',
    titleEn: 'Key Numbers + Unit Economics',
    description: 'Financial analysis with unit economics',
    requiredElements: [
      'Unit Economics Snapshot: What is the unit, What scales, What breaks',
      'Section A: What the Numbers Say (facts only)',
      'Section B: What the Market Does With It (interpretation)',
      'Margin Bridge (where profit comes from)',
    ],
    keyQuestion: 'What drives margins up or down?',
    banList: ['strong financials', 'solid balance sheet', 'healthy margins'],
  },
  {
    id: 'forward_view',
    number: 5,
    title: 'Forward View',
    subtitle: 'תרחישים + קטליזטורים',
    titleEn: 'Scenarios + Catalysts',
    description: 'What needs to happen for bull/bear case',
    requiredElements: [
      'Bull case requirements (3 specific things)',
      'Bear case triggers (3 specific things)',
      'Near-term catalysts (0-3 months)',
      'ISM checkpoints (what to watch each month)',
    ],
    keyQuestion: 'What proves or disproves the thesis?',
    banList: ['could go either way', 'wait and see', 'monitor closely'],
  },
  {
    id: 'investment_decision',
    number: 6,
    title: 'Investment Decision + Action Checklist',
    subtitle: 'החלטת השקעה + צ\'ק ליסט פעולות',
    titleEn: 'Practical Decision + Action Playbook',
    description: 'Actionable conclusion with checklist',
    requiredElements: [
      'Selection rationale (3-5 reasons)',
      'Valuation framework',
      'Kill switch with hard threshold',
      'Action Checklist: Before ISM, On surprise, If weakens',
    ],
    keyQuestion: 'What specific actions should I take?',
    banList: ['monitor the situation', 'maintain exposure', 'watch for developments'],
  },
  {
    id: 'one_page_summary',
    number: 7,
    title: 'One-Page Recall Summary',
    subtitle: 'סיכום מהיר לחזרה',
    titleEn: 'Quick Reference Page',
    description: 'Everything on one page for quick recall',
    requiredElements: [
      'Thesis (3 bullets, 10 words max each)',
      'ISM trigger (one line)',
      'Driver hierarchy table',
      'Key risks (3 items, 5 words each)',
      'Invalidation triggers (2)',
      'Next review date',
    ],
    keyQuestion: 'Can I recall this thesis in 30 seconds?',
    banList: ['detailed analysis', 'comprehensive overview', 'thorough examination'],
  },
];

/**
 * Company Types for Unit Economics
 */
const COMPANY_TYPES = {
  SAAS: 'saas',
  CONSUMER: 'consumer',
  INDUSTRIAL: 'industrial',
  SEMICONDUCTOR: 'semiconductor',
  FINANCIAL: 'financial',
  HEALTHCARE: 'healthcare',
  ENERGY: 'energy',
  RETAIL: 'retail',
  REAL_ESTATE: 'real_estate',
  TELECOM: 'telecom',
  HOMEBUILDER: 'homebuilder',
};

/**
 * Company type specific metrics
 */
const COMPANY_TYPE_METRICS = {
  [COMPANY_TYPES.SAAS]: {
    label: 'SaaS / Software',
    keyMetrics: ['ARR', 'NRR', 'Gross_Churn', 'CAC_Payback', 'Rule_of_40'],
    ismSensitivity: 'MEDIUM',
    primaryISMDriver: 'NEW_ORDERS',
    unitDefinition: {
      unit: 'Customer/Seat',
      scales: 'Revenue per seat expansion',
      breaks: 'Churn acceleration',
    },
  },
  [COMPANY_TYPES.INDUSTRIAL]: {
    label: 'Industrial',
    keyMetrics: ['Book_to_Bill', 'Backlog', 'Capacity_Util', 'Price_Cost'],
    ismSensitivity: 'HIGH',
    primaryISMDriver: 'NEW_ORDERS',
    unitDefinition: {
      unit: 'Order/Unit',
      scales: 'Volume leverage on fixed costs',
      breaks: 'Order cancellations',
    },
  },
  [COMPANY_TYPES.SEMICONDUCTOR]: {
    label: 'Semiconductor',
    keyMetrics: ['Book_to_Bill', 'Utilization', 'ASP_Trend', 'Inventory_Days'],
    ismSensitivity: 'HIGH',
    primaryISMDriver: 'NEW_ORDERS',
    unitDefinition: {
      unit: 'Wafer/Die',
      scales: 'Utilization above breakeven',
      breaks: 'Inventory correction',
    },
  },
  [COMPANY_TYPES.CONSUMER]: {
    label: 'Consumer',
    keyMetrics: ['Same_Store_Sales', 'Traffic', 'Basket_Size', 'Brand_Health'],
    ismSensitivity: 'MEDIUM',
    primaryISMDriver: 'EMPLOYMENT',
    unitDefinition: {
      unit: 'Store/Customer',
      scales: 'Traffic × conversion × basket',
      breaks: 'Consumer pullback',
    },
  },
  [COMPANY_TYPES.FINANCIAL]: {
    label: 'Financial',
    keyMetrics: ['NIM', 'Credit_Quality', 'Loan_Growth', 'ROE'],
    ismSensitivity: 'MEDIUM',
    primaryISMDriver: 'NEW_ORDERS',
    unitDefinition: {
      unit: 'Loan/Account',
      scales: 'Spread expansion, volume growth',
      breaks: 'Credit losses spike',
    },
  },
  [COMPANY_TYPES.HEALTHCARE]: {
    label: 'Healthcare',
    keyMetrics: ['Volume', 'Price', 'Pipeline', 'Patent_Cliff'],
    ismSensitivity: 'LOW',
    primaryISMDriver: null,
    unitDefinition: {
      unit: 'Procedure/Script',
      scales: 'New indications, geographic expansion',
      breaks: 'Generic competition',
    },
  },
  [COMPANY_TYPES.ENERGY]: {
    label: 'Energy',
    keyMetrics: ['Production', 'Reserves', 'Breakeven', 'FCF_Yield'],
    ismSensitivity: 'HIGH',
    primaryISMDriver: 'PRODUCTION',
    unitDefinition: {
      unit: 'Barrel/MCF',
      scales: 'Price × volume',
      breaks: 'Commodity collapse',
    },
  },
  [COMPANY_TYPES.RETAIL]: {
    label: 'Retail',
    keyMetrics: ['Comps', 'Traffic', 'E_Commerce_Mix', 'Inventory_Turn'],
    ismSensitivity: 'MEDIUM',
    primaryISMDriver: 'EMPLOYMENT',
    unitDefinition: {
      unit: 'Store/Square Foot',
      scales: 'Traffic × conversion × ASP',
      breaks: 'Traffic collapse',
    },
  },
  [COMPANY_TYPES.REAL_ESTATE]: {
    label: 'Real Estate',
    keyMetrics: ['Occupancy', 'Rent_Growth', 'NOI', 'FFO'],
    ismSensitivity: 'MEDIUM',
    primaryISMDriver: 'EMPLOYMENT',
    unitDefinition: {
      unit: 'Square Foot',
      scales: 'Rent escalators, occupancy fill',
      breaks: 'Vacancy spike',
    },
  },
  [COMPANY_TYPES.HOMEBUILDER]: {
    label: 'Homebuilder',
    keyMetrics: ['Orders', 'Backlog', 'Cancellations', 'Gross_Margin'],
    ismSensitivity: 'HIGH',
    primaryISMDriver: 'NEW_ORDERS',
    unitDefinition: {
      unit: 'Home',
      scales: 'Volume × ASP × margin',
      breaks: 'Rate shock, cancellations',
    },
  },
};

/**
 * Moat assessment checklist
 */
const MOAT_CHECKLIST = {
  SWITCHING_COSTS: {
    id: 'switching_costs',
    label: 'Switching Costs',
    maxScore: 5,
    questions: [
      'Would customers lose data/integration by switching?',
      'Is there a learning curve for alternatives?',
      'Are there contractual lock-ins?',
    ],
  },
  NETWORK_EFFECTS: {
    id: 'network_effects',
    label: 'Network Effects',
    maxScore: 5,
    questions: [
      'Does the product become more valuable with more users?',
      'Are there two-sided market dynamics?',
      'Is there a critical mass threshold?',
    ],
  },
  BRAND_TRUST: {
    id: 'brand_trust',
    label: 'Brand/Trust',
    maxScore: 5,
    questions: [
      'Would customers pay premium for this brand?',
      'Is there emotional attachment?',
      'Does brand represent quality assurance?',
    ],
  },
  COST_ADVANTAGE: {
    id: 'cost_advantage',
    label: 'Cost Advantage',
    maxScore: 5,
    questions: [
      'Can they produce at lower cost than competitors?',
      'Is there scale advantage?',
      'Are there structural cost advantages (location, process)?',
    ],
  },
  DISTRIBUTION: {
    id: 'distribution',
    label: 'Distribution',
    maxScore: 5,
    questions: [
      'Do they have exclusive distribution channels?',
      'Is the distribution network hard to replicate?',
      'Are there regulatory barriers to distribution?',
    ],
  },
  DATA_IP: {
    id: 'data_ip',
    label: 'Data/IP',
    maxScore: 5,
    questions: [
      'Do they have proprietary data that improves with use?',
      'Are there patents or trade secrets?',
      'Is the IP defensible?',
    ],
  },
};

/**
 * Trade types
 */
const TRADE_TYPES = {
  INVESTMENT: {
    id: 'investment',
    label: 'Investment',
    timeframe: '12+ months',
    description: 'Long-term fundamental position',
  },
  POSITION: {
    id: 'position',
    label: 'Position',
    timeframe: '1-6 months',
    description: 'Medium-term thesis play',
  },
  SWING: {
    id: 'swing',
    label: 'Swing Trade',
    timeframe: '1-3 months',
    description: 'Medium-term catalyst-driven',
  },
  TACTICAL: {
    id: 'tactical',
    label: 'Tactical',
    timeframe: '1-4 weeks',
    description: 'Short-term event-driven',
  },
};

/**
 * Confidence levels
 */
const CONFIDENCE_LEVELS = {
  HIGH: {
    id: 'high',
    label: 'High',
    description: 'Strong cash flow, clean balance sheet, visible earnings',
  },
  MEDIUM: {
    id: 'medium',
    label: 'Medium',
    description: 'Some uncertainty in numbers or visibility',
  },
  LOW: {
    id: 'low',
    label: 'Low',
    description: 'Questionable quality of numbers',
  },
};

/**
 * S&P 500 Sectors (GICS)
 */
const SP500_SECTORS = {
  INFORMATION_TECHNOLOGY: 'Information Technology',
  HEALTH_CARE: 'Health Care',
  FINANCIALS: 'Financials',
  CONSUMER_DISCRETIONARY: 'Consumer Discretionary',
  COMMUNICATION_SERVICES: 'Communication Services',
  INDUSTRIALS: 'Industrials',
  CONSUMER_STAPLES: 'Consumer Staples',
  ENERGY: 'Energy',
  UTILITIES: 'Utilities',
  REAL_ESTATE: 'Real Estate',
  MATERIALS: 'Materials',
};

/**
 * Generation schedule configuration
 */
const SCHEDULE_CONFIG = {
  weeklyRandomCron: '0 9 * * 1',
  adminTriggerEnabled: true,
  dataRefreshHours: 24,
  timezone: 'America/New_York',
};

/**
 * External data sources
 */
const DATA_SOURCES = {
  FINANCIAL_DATA: {
    primary: 'EODHD',
    fallback: 'Yahoo Finance',
  },
  SEC_FILINGS: {
    primary: 'SEC EDGAR',
  },
  NEWS: {
    primary: 'NewsAPI',
    fallback: 'Web Search',
  },
  COMPANY_INFO: {
    primary: 'Yahoo Finance',
  },
  ISM_DATA: {
    primary: 'FRED',
    fallback: 'ISM Website',
  },
};

/**
 * Main report configuration - v6.0
 */
const REPORT_CONFIG = {
  version: '6.0.0',
  name: 'ISM-Driven Company Deep Dive - Institutional Grade',
  agentCount: 27,
  estimatedDurationSeconds: 480,
  outputFormats: ['markdown', 'html', 'json', 'pdf'],
  language: 'en',
  maxPages: 8,
  structure: 'ISM → Sector → Company',
  keyPrinciple: 'Every report starts with WHY NOW (macro trigger)',
};

/**
 * Notification types for update center
 */
const NOTIFICATION_TYPES = {
  NEW_REPORT: 'new_company_report',
  WEEKLY_PICK: 'weekly_sp500_pick',
  ADMIN_REPORT: 'admin_requested_report',
  ISM_ALERT: 'ism_regime_change',
};

module.exports = {
  PHASES,
  PHASE_INFO,
  // ISM Configuration
  ISM_COMPONENTS,
  MACRO_REGIMES,
  // Sector Configuration
  SECTOR_ISM_SENSITIVITY,
  SECTOR_CYCLE_POSITIONS,
  // Company Selection
  COMPANY_SELECTION_CRITERIA,
  EXPOSURE_TYPES,
  DECISION_HORIZONS,
  DRIVER_HIERARCHY,
  // Company Analysis
  COMPANY_TYPES,
  COMPANY_TYPE_METRICS,
  MOAT_CHECKLIST,
  REPORT_SECTIONS,
  TRADE_TYPES,
  CONFIDENCE_LEVELS,
  SP500_SECTORS,
  SCHEDULE_CONFIG,
  DATA_SOURCES,
  REPORT_CONFIG,
  NOTIFICATION_TYPES,
};