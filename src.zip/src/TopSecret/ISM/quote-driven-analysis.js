// =====================================================
// QUOTE-DRIVEN ANALYSIS v1.0
// =====================================================
// Location: src/TopSecret/ISM/quote-driven-analysis.js
//
// This module REVERSES the traditional flow:
// BEFORE: ISM numbers → Sectors → Find supporting quotes
// AFTER:  Quotes → Theme Analysis → Sector Implications → Trade Ideas
//
// The quotes DRIVE everything - they are the source of truth
// for what's actually happening on the ground.
// =====================================================

import OpenAI from 'openai';
import { INDUSTRY_TO_SECTOR_MAP, SECTOR_TO_INDUSTRIES } from './quote-storage.js';

// ============================================
// INDUSTRY → SECTOR MAPPING (Enhanced)
// ============================================

const ENHANCED_INDUSTRY_SECTOR_MAP = {
  // Technology
  'Computer & Electronic Products': {
    sector: 'Technology',
    etf: 'XLK',
    keyStocks: ['NVDA', 'AMD', 'AVGO', 'ANET', 'INTC', 'AAPL', 'MSFT'],
    ismSensitivity: 'medium',
    themes: ['AI demand', 'data center', 'semiconductor', 'capex'],
  },
  'Electrical Equipment, Appliances & Components': {
    sector: 'Industrials/Electrical',
    etf: 'XLI',
    keyStocks: ['ETN', 'EMR', 'ROK', 'AME', 'PH'],
    ismSensitivity: 'high',
    themes: ['automation', 'infrastructure', 'electrification'],
  },
  
  // Industrials
  'Machinery': {
    sector: 'Industrials',
    etf: 'XLI',
    keyStocks: ['CAT', 'DE', 'PCAR', 'CMI', 'EMR', 'HON'],
    ismSensitivity: 'high',
    themes: ['capex', 'construction', 'agriculture', 'mining'],
  },
  'Transportation Equipment': {
    sector: 'Industrials/Transport',
    etf: 'IYT',
    keyStocks: ['BA', 'LMT', 'GD', 'RTX', 'NOC', 'UNP', 'FDX'],
    ismSensitivity: 'high',
    themes: ['aerospace', 'defense', 'logistics', 'trade'],
  },
  'Fabricated Metal Products': {
    sector: 'Industrials/Materials',
    etf: 'XLI',
    keyStocks: ['NUE', 'STLD', 'CLF', 'X'],
    ismSensitivity: 'high',
    themes: ['construction', 'infrastructure', 'manufacturing'],
  },
  
  // Materials
  'Chemical Products': {
    sector: 'Materials',
    etf: 'XLB',
    keyStocks: ['LIN', 'APD', 'DD', 'DOW', 'ECL'],
    ismSensitivity: 'high',
    themes: ['industrial demand', 'agriculture', 'specialty chemicals'],
  },
  'Primary Metals': {
    sector: 'Materials',
    etf: 'XLB',
    keyStocks: ['NUE', 'STLD', 'CLF', 'FCX', 'AA'],
    ismSensitivity: 'very_high',
    themes: ['commodity prices', 'steel demand', 'construction'],
  },
  'Plastics & Rubber Products': {
    sector: 'Materials',
    etf: 'XLB',
    keyStocks: ['DOW', 'LYB', 'CE', 'EMN'],
    ismSensitivity: 'high',
    themes: ['auto production', 'packaging', 'construction'],
  },
  'Wood Products': {
    sector: 'Materials',
    etf: 'XLB',
    keyStocks: ['WY', 'RYN', 'PCH', 'LPX'],
    ismSensitivity: 'high',
    themes: ['housing', 'construction', 'lumber prices'],
  },
  'Paper Products': {
    sector: 'Materials',
    etf: 'XLB',
    keyStocks: ['IP', 'PKG', 'WRK'],
    ismSensitivity: 'medium',
    themes: ['packaging demand', 'e-commerce'],
  },
  
  // Consumer Staples
  'Food, Beverage & Tobacco Products': {
    sector: 'Consumer Staples',
    etf: 'XLP',
    keyStocks: ['PG', 'KO', 'PEP', 'GIS', 'COST', 'WMT'],
    ismSensitivity: 'low',
    themes: ['consumer demand', 'pricing power', 'input costs'],
  },
  
  // Consumer Discretionary
  'Furniture & Related Products': {
    sector: 'Consumer Discretionary',
    etf: 'XLY',
    keyStocks: ['HD', 'LOW', 'WHR'],
    ismSensitivity: 'medium',
    themes: ['housing', 'consumer spending'],
  },
  'Apparel, Leather & Allied Products': {
    sector: 'Consumer Discretionary',
    etf: 'XLY',
    keyStocks: ['NKE', 'VFC', 'PVH', 'RL'],
    ismSensitivity: 'medium',
    themes: ['consumer spending', 'retail'],
  },
  'Textile Mills': {
    sector: 'Consumer Discretionary',
    etf: 'XLY',
    keyStocks: ['NKE', 'VFC'],
    ismSensitivity: 'medium',
    themes: ['consumer spending', 'manufacturing'],
  },
  'Miscellaneous Manufacturing': {
    sector: 'Industrials',
    etf: 'XLI',
    keyStocks: ['MMM', 'ITW', 'PH', 'GE'],
    ismSensitivity: 'medium',
    themes: ['diversified', 'general manufacturing'],
  },
  
  // Energy
  'Petroleum & Coal Products': {
    sector: 'Energy',
    etf: 'XLE',
    keyStocks: ['XOM', 'CVX', 'COP', 'PSX', 'VLO'],
    ismSensitivity: 'medium',
    themes: ['energy prices', 'refining margins', 'capex'],
  },
};

// ============================================
// THEME DETECTION PATTERNS
// ============================================

const THEME_PATTERNS = {
  tariffs: {
    patterns: [/tariff/i, /trade war/i, /import dut/i, /export restrict/i, /trade policy/i, /customs/i],
    sentiment_bias: 'negative',
    affected_sectors: ['Industrials', 'Materials', 'Technology'],
  },
  supply_chain: {
    patterns: [/supply chain/i, /supplier/i, /lead time/i, /delivery/i, /shortage/i, /backlog/i],
    sentiment_bias: 'neutral',
    affected_sectors: ['Industrials', 'Technology', 'Materials'],
  },
  demand_weakness: {
    patterns: [/weak demand/i, /soft demand/i, /order.*(cancel|declin|slow)/i, /customer.*(cut|reduc)/i],
    sentiment_bias: 'negative',
    affected_sectors: ['Industrials', 'Materials', 'Consumer Discretionary'],
  },
  demand_strength: {
    patterns: [/strong demand/i, /order.*(increas|grow)/i, /customer.*(request|want)/i, /backlog.*(grow|build)/i],
    sentiment_bias: 'positive',
    affected_sectors: ['Industrials', 'Technology', 'Materials'],
  },
  pricing_pressure: {
    patterns: [/price.*(increas|up|rising)/i, /cost.*(increas|up|rising)/i, /margin.*(pressur|squeez)/i, /inflation/i],
    sentiment_bias: 'negative',
    affected_sectors: ['Consumer Staples', 'Consumer Discretionary', 'Industrials'],
  },
  pricing_power: {
    patterns: [/pass.*(through|on).*(cost|price)/i, /price.*(increas|adjustment)/i, /pricing power/i],
    sentiment_bias: 'positive',
    affected_sectors: ['Consumer Staples', 'Materials'],
  },
  labor: {
    patterns: [/employ/i, /layoff/i, /hiring/i, /staff/i, /workforce/i, /labor/i, /severance/i, /headcount/i],
    sentiment_bias: 'negative',
    affected_sectors: ['Industrials', 'Transportation'],
  },
  uncertainty: {
    patterns: [/uncertain/i, /volatil/i, /unpredict/i, /confus/i, /unclear/i, /difficult.*(plan|forecast)/i],
    sentiment_bias: 'negative',
    affected_sectors: ['Industrials', 'Financials', 'Consumer Discretionary'],
  },
  capex: {
    patterns: [/capital.*(expenditure|investment|project)/i, /expansion.*(plan|project)/i, /investment/i, /capex/i],
    sentiment_bias: 'neutral',
    affected_sectors: ['Industrials', 'Technology', 'Materials'],
  },
  inventory: {
    patterns: [/inventor/i, /stock/i, /restock/i, /destock/i, /warehoous/i],
    sentiment_bias: 'neutral',
    affected_sectors: ['Materials', 'Industrials', 'Consumer Staples'],
  },
  government: {
    patterns: [/government/i, /policy/i, /regulation/i, /shutdown/i, /federal/i, /administration/i],
    sentiment_bias: 'negative',
    affected_sectors: ['All'],
  },
  ai_tech: {
    patterns: [/artificial intelligence/i, /\bai\b/i, /data center/i, /semiconductor/i, /chip/i],
    sentiment_bias: 'positive',
    affected_sectors: ['Technology'],
  },
};

// ============================================
// SENTIMENT SCORING WEIGHTS
// ============================================

const SENTIMENT_WEIGHTS = {
  strongly_negative: -2,
  negative: -1,
  slightly_negative: -0.5,
  neutral: 0,
  slightly_positive: 0.5,
  positive: 1,
  strongly_positive: 2,
};

// ============================================
// MAIN QUOTE-DRIVEN ANALYZER CLASS
// ============================================

class QuoteDrivenAnalyzer {
  constructor(options = {}) {
    this.openaiApiKey = options.openaiApiKey || process.env.OPENAI_API_KEY;
    this.openai = this.openaiApiKey ? new OpenAI({ apiKey: this.openaiApiKey }) : null;
    
    console.log('[QuoteDrivenAnalyzer] Initialized', {
      hasOpenAI: !!this.openai,
    });
  }

  // ============================================
  // MAIN ANALYSIS METHOD
  // ============================================

  async analyzeQuotesAndDeriveSectors(quotes, ismData) {
    console.log(`\n[QuoteDrivenAnalyzer] ========================================`);
    console.log(`[QuoteDrivenAnalyzer] Analyzing ${quotes.length} quotes to derive sectors`);
    console.log(`[QuoteDrivenAnalyzer] ========================================\n`);

    if (!quotes || quotes.length === 0) {
      console.warn('[QuoteDrivenAnalyzer] No quotes provided - falling back to ISM-only analysis');
      return this.generateFallbackAnalysis(ismData);
    }

    // Step 1: Deep quote analysis
    const quoteAnalysis = this.performDeepQuoteAnalysis(quotes);
    
    // Step 2: Derive sector implications from quotes
    const sectorImplications = this.deriveSectorImplicationsFromQuotes(quoteAnalysis, ismData);
    
    // Step 3: Generate trade ideas from quote themes
    const tradeIdeas = await this.generateQuoteDrivenTradeIdeas(quoteAnalysis, sectorImplications, ismData);
    
    // Step 4: Compile final analysis
    const result = {
      // Quote analysis
      quoteAnalysis: {
        totalQuotes: quotes.length,
        analyzedQuotes: quoteAnalysis.processedQuotes.length,
        dominantThemes: quoteAnalysis.dominantThemes,
        overallSentiment: quoteAnalysis.overallSentiment,
        sentimentScore: quoteAnalysis.sentimentScore,
        keyInsights: quoteAnalysis.keyInsights,
        themeBreakdown: quoteAnalysis.themeBreakdown,
      },
      
      // Sector rankings derived FROM quotes
      sectorRankings: sectorImplications.rankings,
      sectorDetails: sectorImplications.details,
      topSector: sectorImplications.topSector,
      bottomSector: sectorImplications.bottomSector,
      
      // Trade ideas driven BY quotes
      tradeIdeas: tradeIdeas,
      
      // Mapping for reference
      quoteToSectorMapping: quoteAnalysis.quoteToSectorMap,
      
      // Meta
      analysisMethod: 'quote-driven',
      derivedAt: new Date().toISOString(),
    };

    console.log(`[QuoteDrivenAnalyzer] Analysis complete:`);
    console.log(`  - Themes: ${quoteAnalysis.dominantThemes.join(', ')}`);
    console.log(`  - Sentiment: ${quoteAnalysis.overallSentiment} (${quoteAnalysis.sentimentScore.toFixed(2)})`);
    console.log(`  - Top Sector: ${sectorImplications.topSector?.sector}`);
    console.log(`  - Trade Ideas: ${tradeIdeas.length}`);

    return result;
  }

  // ============================================
  // STEP 1: DEEP QUOTE ANALYSIS
  // ============================================

  performDeepQuoteAnalysis(quotes) {
    const processedQuotes = [];
    const themeAccumulator = {};
    const sectorSentiments = {};
    const quoteToSectorMap = [];
    let totalSentimentScore = 0;

    for (const quote of quotes) {
      const comment = quote.comment || quote.text || quote.originalQuote || '';
      const industry = quote.industry || 'Unknown';
      
      if (!comment || comment.length < 20) continue;

      // Get sector mapping
      const sectorInfo = ENHANCED_INDUSTRY_SECTOR_MAP[industry] || 
                         this.findClosestIndustryMatch(industry);
      const sector = sectorInfo?.sector || 'Other';

      // Detect themes in this quote
      const detectedThemes = this.detectThemesInQuote(comment);
      
      // Score sentiment
      const sentimentResult = this.scoreSentiment(comment);
      
      // Accumulate theme counts
      for (const theme of detectedThemes) {
        themeAccumulator[theme] = (themeAccumulator[theme] || 0) + 1;
      }

      // Accumulate sector sentiments
      if (!sectorSentiments[sector]) {
        sectorSentiments[sector] = { scores: [], quotes: [], themes: new Set() };
      }
      sectorSentiments[sector].scores.push(sentimentResult.score);
      sectorSentiments[sector].quotes.push({
        industry,
        comment: comment.substring(0, 200),
        sentiment: sentimentResult.sentiment,
        themes: detectedThemes,
      });
      detectedThemes.forEach(t => sectorSentiments[sector].themes.add(t));

      // Track total sentiment
      totalSentimentScore += sentimentResult.score;

      // Build processed quote
      processedQuotes.push({
        industry,
        sector,
        comment,
        themes: detectedThemes,
        sentiment: sentimentResult.sentiment,
        sentimentScore: sentimentResult.score,
        keyPhrases: sentimentResult.keyPhrases,
        sectorInfo,
      });

      // Build mapping
      quoteToSectorMap.push({
        industry,
        sector,
        etf: sectorInfo?.etf,
        keyStocks: sectorInfo?.keyStocks?.slice(0, 5),
        quoteExcerpt: comment.substring(0, 100),
        sentiment: sentimentResult.sentiment,
        themes: detectedThemes,
      });
    }

    // Calculate dominant themes (top 5)
    const dominantThemes = Object.entries(themeAccumulator)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([theme, count]) => theme);

    // Calculate overall sentiment
    const avgSentiment = processedQuotes.length > 0 
      ? totalSentimentScore / processedQuotes.length 
      : 0;
    
    let overallSentiment = 'neutral';
    if (avgSentiment <= -1) overallSentiment = 'strongly_negative';
    else if (avgSentiment < -0.3) overallSentiment = 'negative';
    else if (avgSentiment < 0) overallSentiment = 'slightly_negative';
    else if (avgSentiment > 1) overallSentiment = 'strongly_positive';
    else if (avgSentiment > 0.3) overallSentiment = 'positive';
    else if (avgSentiment > 0) overallSentiment = 'slightly_positive';

    // Generate key insights from themes
    const keyInsights = this.generateKeyInsightsFromThemes(dominantThemes, sectorSentiments);

    return {
      processedQuotes,
      dominantThemes,
      overallSentiment,
      sentimentScore: avgSentiment,
      themeBreakdown: themeAccumulator,
      sectorSentiments,
      keyInsights,
      quoteToSectorMap,
    };
  }

  // ============================================
  // STEP 2: DERIVE SECTOR IMPLICATIONS
  // ============================================

  deriveSectorImplicationsFromQuotes(quoteAnalysis, ismData) {
    const { sectorSentiments, dominantThemes, processedQuotes } = quoteAnalysis;
    const mfg = ismData?.manufacturing || {};
    
    const sectorScores = {};
    
    // Calculate sector scores based on quote sentiment + ISM data
    for (const [sector, data] of Object.entries(sectorSentiments)) {
      const avgSentiment = data.scores.reduce((a, b) => a + b, 0) / data.scores.length;
      const quoteCount = data.quotes.length;
      const themes = Array.from(data.themes);
      
      // Weight: more quotes = more confidence
      const confidenceMultiplier = Math.min(quoteCount / 3, 1.5);
      
      // Base score from sentiment (-2 to +2 range)
      let score = avgSentiment * 3 + 5; // Convert to 1-10 scale with 5 as neutral
      
      // Apply theme adjustments
      if (themes.includes('tariffs')) score -= 0.5;
      if (themes.includes('demand_weakness')) score -= 0.7;
      if (themes.includes('demand_strength')) score += 0.7;
      if (themes.includes('pricing_power')) score += 0.3;
      if (themes.includes('uncertainty')) score -= 0.4;
      if (themes.includes('ai_tech') && sector === 'Technology') score += 1.0;
      
      // Apply ISM data adjustments
      if (mfg.pmi < 50) {
        // In contraction, boost defensive sectors
        if (['Consumer Staples', 'Healthcare'].includes(sector)) {
          score += 0.5;
        }
        // Penalize cyclicals more
        if (['Industrials', 'Materials'].includes(sector)) {
          score -= 0.3;
        }
      }
      
      // Clamp score
      score = Math.max(1, Math.min(10, score * confidenceMultiplier));
      
      // Get best supporting quote
      const bestQuote = data.quotes.sort((a, b) => 
        Math.abs(b.sentiment === 'negative' ? -1 : b.sentiment === 'positive' ? 1 : 0) -
        Math.abs(a.sentiment === 'negative' ? -1 : a.sentiment === 'positive' ? 1 : 0)
      )[0];
      
      sectorScores[sector] = {
        sector,
        score: parseFloat(score.toFixed(1)),
        direction: score >= 6 ? 'positive' : score <= 4 ? 'negative' : 'neutral',
        quoteCount,
        avgSentiment: parseFloat(avgSentiment.toFixed(2)),
        themes,
        supportingQuote: bestQuote?.comment || null,
        supportingQuoteIndustry: bestQuote?.industry || null,
        confidence: quoteCount >= 3 ? 'high' : quoteCount >= 2 ? 'medium' : 'low',
      };
    }
    
    // Add sectors without quotes but with ISM relevance
    this.addMissingSectors(sectorScores, mfg);
    
    // Sort by score descending
    const rankings = Object.values(sectorScores)
      .sort((a, b) => b.score - a.score)
      .map((s, i) => ({ ...s, rank: i + 1 }));
    
    // Add ETF and stocks
    for (const ranking of rankings) {
      const sectorInfo = this.getSectorInfo(ranking.sector);
      ranking.etf = sectorInfo?.etf || 'SPY';
      ranking.keyStocks = sectorInfo?.keyStocks || [];
    }
    
    return {
      rankings,
      details: sectorScores,
      topSector: rankings[0],
      bottomSector: rankings[rankings.length - 1],
    };
  }

  // ============================================
  // STEP 3: GENERATE TRADE IDEAS FROM QUOTES
  // ============================================

  async generateQuoteDrivenTradeIdeas(quoteAnalysis, sectorImplications, ismData) {
    const { processedQuotes, dominantThemes, overallSentiment } = quoteAnalysis;
    const { rankings, topSector, bottomSector } = sectorImplications;
    const mfg = ismData?.manufacturing || {};
    
    const ideas = [];
    
    // Idea 1: Top sector LONG based on positive quotes
    if (topSector && topSector.score >= 6) {
      const supportingQuotes = processedQuotes
        .filter(q => q.sector === topSector.sector && q.sentimentScore > 0)
        .slice(0, 2);
      
      ideas.push({
        direction: 'long',
        sector: topSector.sector,
        title: `LONG: ${topSector.sector} (${topSector.etf})`,
        ticker: topSector.etf,
        alternativeStocks: topSector.keyStocks?.slice(0, 5) || [],
        
        // Quote-driven thesis
        thesis: this.buildQuoteDrivenThesis(topSector, supportingQuotes, mfg, 'long'),
        
        // Executive quote support
        executiveQuote: topSector.supportingQuote,
        executiveQuoteIndustry: topSector.supportingQuoteIndustry,
        
        // Direct impact on stocks
        directImpact: this.explainStockImpact(topSector, supportingQuotes),
        
        conviction: topSector.confidence === 'high' ? 'high' : 'medium',
        invalidation: this.generateInvalidation(topSector, 'long'),
        risks: this.generateRisks(topSector, dominantThemes),
        
        // Meta
        quotesDriving: supportingQuotes.map(q => ({
          industry: q.industry,
          excerpt: q.comment.substring(0, 100),
          sentiment: q.sentiment,
        })),
      });
    }
    
    // Idea 2: Bottom sector SHORT based on negative quotes
    if (bottomSector && bottomSector.score <= 4) {
      const supportingQuotes = processedQuotes
        .filter(q => q.sector === bottomSector.sector && q.sentimentScore < 0)
        .slice(0, 2);
      
      ideas.push({
        direction: 'short',
        sector: bottomSector.sector,
        title: `SHORT: ${bottomSector.sector} (${bottomSector.etf})`,
        ticker: bottomSector.etf,
        alternativeStocks: bottomSector.keyStocks?.slice(0, 5) || [],
        
        thesis: this.buildQuoteDrivenThesis(bottomSector, supportingQuotes, mfg, 'short'),
        
        executiveQuote: bottomSector.supportingQuote,
        executiveQuoteIndustry: bottomSector.supportingQuoteIndustry,
        
        directImpact: this.explainStockImpact(bottomSector, supportingQuotes),
        
        conviction: bottomSector.confidence === 'high' ? 'high' : 'medium',
        invalidation: this.generateInvalidation(bottomSector, 'short'),
        risks: this.generateRisks(bottomSector, dominantThemes),
        
        quotesDriving: supportingQuotes.map(q => ({
          industry: q.industry,
          excerpt: q.comment.substring(0, 100),
          sentiment: q.sentiment,
        })),
      });
    }
    
    // Idea 3: Theme-based trade (if dominant theme is strong)
    const themeIdea = this.generateThemeBasedIdea(dominantThemes, processedQuotes, mfg);
    if (themeIdea) {
      ideas.push(themeIdea);
    }
    
    // Idea 4: Defensive play if overall sentiment is negative
    if (overallSentiment.includes('negative') && !ideas.find(i => i.sector === 'Consumer Staples')) {
      ideas.push(this.generateDefensiveIdea(processedQuotes, mfg));
    }
    
    return ideas.filter(i => i !== null);
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  detectThemesInQuote(text) {
    const detectedThemes = [];
    const lower = text.toLowerCase();
    
    for (const [theme, config] of Object.entries(THEME_PATTERNS)) {
      for (const pattern of config.patterns) {
        if (pattern.test(lower)) {
          detectedThemes.push(theme);
          break;
        }
      }
    }
    
    return detectedThemes;
  }

  scoreSentiment(text) {
    const lower = text.toLowerCase();
    let score = 0;
    const keyPhrases = [];
    
    // Negative indicators
    const negativePatterns = [
      { pattern: /struggl/i, weight: -1, phrase: 'struggling' },
      { pattern: /difficult/i, weight: -0.7, phrase: 'difficult' },
      { pattern: /weak/i, weight: -0.8, phrase: 'weak' },
      { pattern: /declin/i, weight: -0.9, phrase: 'declining' },
      { pattern: /uncertain/i, weight: -0.6, phrase: 'uncertain' },
      { pattern: /concern/i, weight: -0.5, phrase: 'concern' },
      { pattern: /layoff/i, weight: -1.2, phrase: 'layoffs' },
      { pattern: /reduct/i, weight: -0.7, phrase: 'reduction' },
      { pattern: /cancel/i, weight: -0.9, phrase: 'cancellation' },
      { pattern: /slow(ing|er|down)?/i, weight: -0.6, phrase: 'slowing' },
      { pattern: /volatil/i, weight: -0.5, phrase: 'volatile' },
      { pattern: /confus/i, weight: -0.4, phrase: 'confusion' },
      { pattern: /lackluster/i, weight: -0.8, phrase: 'lackluster' },
      { pattern: /pressure/i, weight: -0.5, phrase: 'pressure' },
    ];
    
    // Positive indicators
    const positivePatterns = [
      { pattern: /strong/i, weight: 0.9, phrase: 'strong' },
      { pattern: /growth|growing/i, weight: 0.8, phrase: 'growth' },
      { pattern: /increas/i, weight: 0.7, phrase: 'increasing' },
      { pattern: /improv/i, weight: 0.8, phrase: 'improving' },
      { pattern: /optimis/i, weight: 0.7, phrase: 'optimistic' },
      { pattern: /recover/i, weight: 0.6, phrase: 'recovering' },
      { pattern: /expand/i, weight: 0.7, phrase: 'expanding' },
      { pattern: /stable/i, weight: 0.4, phrase: 'stable' },
      { pattern: /solid/i, weight: 0.6, phrase: 'solid' },
      { pattern: /confident/i, weight: 0.5, phrase: 'confident' },
    ];
    
    for (const p of negativePatterns) {
      if (p.pattern.test(lower)) {
        score += p.weight;
        keyPhrases.push(p.phrase);
      }
    }
    
    for (const p of positivePatterns) {
      if (p.pattern.test(lower)) {
        score += p.weight;
        keyPhrases.push(p.phrase);
      }
    }
    
    // Determine sentiment label
    let sentiment = 'neutral';
    if (score <= -1.5) sentiment = 'strongly_negative';
    else if (score < -0.5) sentiment = 'negative';
    else if (score < 0) sentiment = 'slightly_negative';
    else if (score >= 1.5) sentiment = 'strongly_positive';
    else if (score > 0.5) sentiment = 'positive';
    else if (score > 0) sentiment = 'slightly_positive';
    
    return { score, sentiment, keyPhrases };
  }

  findClosestIndustryMatch(industry) {
    const lower = industry.toLowerCase();
    
    for (const [key, value] of Object.entries(ENHANCED_INDUSTRY_SECTOR_MAP)) {
      if (key.toLowerCase().includes(lower.split(',')[0].trim()) ||
          lower.includes(key.toLowerCase().split(' ')[0])) {
        return value;
      }
    }
    
    // Default fallback
    return {
      sector: 'Industrials',
      etf: 'XLI',
      keyStocks: ['HON', 'MMM', 'GE'],
      ismSensitivity: 'medium',
      themes: ['general manufacturing'],
    };
  }

  getSectorInfo(sectorName) {
    const sectorEtfMap = {
      'Technology': { etf: 'XLK', keyStocks: ['NVDA', 'AMD', 'AVGO', 'MSFT', 'AAPL'] },
      'Industrials': { etf: 'XLI', keyStocks: ['CAT', 'DE', 'HON', 'UNP', 'GE'] },
      'Industrials/Electrical': { etf: 'XLI', keyStocks: ['ETN', 'EMR', 'ROK', 'AME'] },
      'Industrials/Transport': { etf: 'IYT', keyStocks: ['UNP', 'FDX', 'DAL', 'UPS'] },
      'Industrials/Materials': { etf: 'XLI', keyStocks: ['NUE', 'STLD', 'CLF'] },
      'Materials': { etf: 'XLB', keyStocks: ['LIN', 'APD', 'FCX', 'DOW', 'NEM'] },
      'Consumer Staples': { etf: 'XLP', keyStocks: ['PG', 'KO', 'PEP', 'COST', 'WMT'] },
      'Consumer Discretionary': { etf: 'XLY', keyStocks: ['AMZN', 'HD', 'MCD', 'NKE'] },
      'Energy': { etf: 'XLE', keyStocks: ['XOM', 'CVX', 'COP', 'SLB'] },
      'Healthcare': { etf: 'XLV', keyStocks: ['UNH', 'JNJ', 'LLY', 'PFE'] },
      'Financials': { etf: 'XLF', keyStocks: ['JPM', 'BAC', 'WFC', 'GS'] },
    };
    
    return sectorEtfMap[sectorName] || { etf: 'SPY', keyStocks: [] };
  }

  addMissingSectors(sectorScores, mfg) {
    const baseSectors = ['Consumer Staples', 'Healthcare', 'Technology', 'Materials', 'Industrials', 'Energy'];
    
    for (const sector of baseSectors) {
      if (!sectorScores[sector]) {
        // Default score based on ISM regime
        let defaultScore = 5;
        if (mfg.pmi < 50) {
          if (['Consumer Staples', 'Healthcare'].includes(sector)) defaultScore = 6;
          if (['Materials', 'Industrials'].includes(sector)) defaultScore = 4;
        } else {
          if (['Materials', 'Industrials'].includes(sector)) defaultScore = 6;
          if (['Consumer Staples'].includes(sector)) defaultScore = 5;
        }
        
        const sectorInfo = this.getSectorInfo(sector);
        sectorScores[sector] = {
          sector,
          score: defaultScore,
          direction: defaultScore >= 6 ? 'positive' : defaultScore <= 4 ? 'negative' : 'neutral',
          quoteCount: 0,
          avgSentiment: 0,
          themes: [],
          supportingQuote: null,
          supportingQuoteIndustry: null,
          confidence: 'low',
          etf: sectorInfo.etf,
          keyStocks: sectorInfo.keyStocks,
          note: 'No direct quote support - derived from ISM data',
        };
      }
    }
  }

  generateKeyInsightsFromThemes(themes, sectorSentiments) {
    const insights = [];
    
    if (themes.includes('tariffs')) {
      insights.push('Tariff concerns dominate executive commentary - suggests ongoing margin pressure for import-dependent manufacturers.');
    }
    if (themes.includes('demand_weakness')) {
      insights.push('Demand weakness is evident across multiple industries - confirms ISM New Orders signal.');
    }
    if (themes.includes('uncertainty')) {
      insights.push('Uncertainty is hampering capital planning - watch for capex deferrals in next quarter.');
    }
    if (themes.includes('supply_chain')) {
      insights.push('Supply chain concerns persist - lead time normalization incomplete.');
    }
    if (themes.includes('labor')) {
      insights.push('Labor adjustments (layoffs/hiring freezes) are accelerating - confirms Employment weakness.');
    }
    if (themes.includes('ai_tech')) {
      insights.push('AI/data center demand provides secular support for Technology despite cycle weakness.');
    }
    
    return insights.slice(0, 4);
  }

  buildQuoteDrivenThesis(sectorData, quotes, mfg, direction) {
    const { sector, themes, avgSentiment } = sectorData;
    
    let thesis = '';
    
    if (direction === 'long') {
      thesis = `Executive commentary from ${sector} shows ${avgSentiment > 0 ? 'constructive' : 'stabilizing'} tone. `;
      if (themes.includes('demand_strength')) {
        thesis += 'Order activity and customer demand mentioned positively. ';
      }
      thesis += `This matters because ground-level feedback often leads official data by 2-4 weeks.`;
    } else {
      thesis = `Executive commentary from ${sector} reveals persistent challenges. `;
      if (themes.includes('demand_weakness')) {
        thesis += 'Weak demand and order cancellations mentioned explicitly. ';
      }
      if (themes.includes('uncertainty')) {
        thesis += 'Planning uncertainty is hampering investment decisions. ';
      }
      thesis += `This matters because these pressures typically flow through to earnings within 1-2 quarters.`;
    }
    
    return thesis;
  }

  explainStockImpact(sectorData, quotes) {
    const { keyStocks = [], themes = [] } = sectorData;
    
    if (keyStocks.length === 0) return 'Broad sector exposure via ETF recommended.';
    
    let impact = `${keyStocks.slice(0, 3).join(', ')} `;
    
    if (themes.includes('tariffs')) {
      impact += 'face direct tariff exposure. ';
    }
    if (themes.includes('demand_weakness')) {
      impact += 'likely to see order book deterioration. ';
    }
    if (themes.includes('demand_strength')) {
      impact += 'positioned to benefit from demand recovery. ';
    }
    if (themes.includes('labor')) {
      impact += 'may announce workforce adjustments. ';
    }
    
    return impact.trim() || 'Direct exposure to ISM-tracked manufacturing conditions.';
  }

  generateInvalidation(sectorData, direction) {
    const invalidations = [];
    
    if (direction === 'long') {
      invalidations.push('Quote sentiment turns negative in next ISM');
      invalidations.push('PMI drops below 47 with acceleration');
      if (sectorData.themes.includes('demand_strength')) {
        invalidations.push('New Orders reverses below 48');
      }
    } else {
      invalidations.push('Quote sentiment improves in next ISM');
      invalidations.push('PMI rebounds above 50');
      if (sectorData.themes.includes('demand_weakness')) {
        invalidations.push('New Orders surprises above 52');
      }
    }
    
    return invalidations.slice(0, 3);
  }

  generateRisks(sectorData, dominantThemes) {
    const risks = ['Broader market selloff could overwhelm sector-specific signals'];
    
    if (dominantThemes.includes('tariffs')) {
      risks.push('Trade policy changes could shift dynamics rapidly');
    }
    if (dominantThemes.includes('uncertainty')) {
      risks.push('Elevated uncertainty may delay expected catalysts');
    }
    
    return risks.slice(0, 3);
  }

  generateThemeBasedIdea(themes, quotes, mfg) {
    if (themes.includes('tariffs') && themes.length > 0) {
      const tariffQuotes = quotes.filter(q => q.themes.includes('tariffs'));
      if (tariffQuotes.length >= 2) {
        return {
          direction: 'short',
          sector: 'Import-Dependent Industrials',
          title: 'SHORT: Tariff-Exposed Manufacturing (XLI underweight)',
          ticker: 'XLI',
          alternativeStocks: ['CAT', 'DE', 'HON'],
          thesis: `${tariffQuotes.length} executives explicitly mentioned tariff pressure. This matters because tariff costs flow directly to margins or require price increases that risk demand destruction.`,
          executiveQuote: tariffQuotes[0]?.comment?.substring(0, 200),
          executiveQuoteIndustry: tariffQuotes[0]?.industry,
          directImpact: 'Companies with high import content (CAT, DE) face margin compression. HON has more domestic sourcing.',
          conviction: 'medium',
          invalidation: ['Tariff exemptions announced', 'Price pass-through successful'],
          risks: ['Policy reversal possible', 'Customer demand absorbs price increases'],
          quotesDriving: tariffQuotes.slice(0, 2).map(q => ({
            industry: q.industry,
            excerpt: q.comment?.substring(0, 100),
          })),
        };
      }
    }
    
    return null;
  }

  generateDefensiveIdea(quotes, mfg) {
    const staplesInfo = this.getSectorInfo('Consumer Staples');
    const staplesQuotes = quotes.filter(q => 
      q.sector === 'Consumer Staples' || 
      q.industry?.toLowerCase().includes('food') ||
      q.industry?.toLowerCase().includes('beverage')
    );
    
    return {
      direction: 'long',
      sector: 'Consumer Staples',
      title: 'LONG: Defensive Quality (XLP)',
      ticker: 'XLP',
      alternativeStocks: staplesInfo.keyStocks.slice(0, 5),
      thesis: `Overall sentiment across ISM respondents is negative. This matters because defensive positioning is warranted when manufacturing executives are broadly pessimistic. Consumer Staples offers pricing power and demand stability.`,
      executiveQuote: staplesQuotes[0]?.comment?.substring(0, 200) || 'Broad negative sentiment across manufacturing sectors.',
      executiveQuoteIndustry: staplesQuotes[0]?.industry || 'Multiple Industries',
      directImpact: 'PG, KO, PEP have demonstrated pricing power. COST benefits from trade-down behavior.',
      conviction: 'medium',
      invalidation: ['Sentiment turns positive', 'PMI rebounds above 50'],
      risks: ['Consumer trade-down to private label', 'Commodity cost spikes'],
    };
  }

  generateFallbackAnalysis(ismData) {
    const mfg = ismData?.manufacturing || {};
    const isContraction = mfg.pmi < 50;
    
    return {
      quoteAnalysis: {
        totalQuotes: 0,
        analyzedQuotes: 0,
        dominantThemes: [],
        overallSentiment: 'unavailable',
        sentimentScore: 0,
        keyInsights: ['No executive quotes available for this period'],
        themeBreakdown: {},
      },
      sectorRankings: isContraction ? [
        { rank: 1, sector: 'Consumer Staples', score: 7.5, direction: 'positive', etf: 'XLP' },
        { rank: 2, sector: 'Healthcare', score: 7.0, direction: 'positive', etf: 'XLV' },
        { rank: 3, sector: 'Technology', score: 6.0, direction: 'neutral', etf: 'XLK' },
        { rank: 4, sector: 'Industrials', score: 4.0, direction: 'negative', etf: 'XLI' },
        { rank: 5, sector: 'Materials', score: 3.5, direction: 'negative', etf: 'XLB' },
      ] : [
        { rank: 1, sector: 'Industrials', score: 7.5, direction: 'positive', etf: 'XLI' },
        { rank: 2, sector: 'Materials', score: 7.0, direction: 'positive', etf: 'XLB' },
        { rank: 3, sector: 'Technology', score: 6.5, direction: 'positive', etf: 'XLK' },
        { rank: 4, sector: 'Consumer Staples', score: 5.0, direction: 'neutral', etf: 'XLP' },
        { rank: 5, sector: 'Healthcare', score: 5.0, direction: 'neutral', etf: 'XLV' },
      ],
      tradeIdeas: [],
      analysisMethod: 'ism-only-fallback',
      derivedAt: new Date().toISOString(),
    };
  }
}

// ============================================
// EXPORTS
// ============================================

export {
  QuoteDrivenAnalyzer,
  ENHANCED_INDUSTRY_SECTOR_MAP,
  THEME_PATTERNS,
};