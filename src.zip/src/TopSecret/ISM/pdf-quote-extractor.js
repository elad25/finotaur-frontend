// =====================================================
// ISM QUOTE EXTRACTOR v3.0 - DYNAMIC WEB SCRAPING
// =====================================================
// Location: src/TopSecret/ISM/quote-extractor.js
//
// Extracts quotes DYNAMICALLY from:
// 1. PRNewswire HTML (primary - most reliable)
// 2. ISM Website HTML (secondary)
// 3. Perplexity API (fallback - mark as unverified)
//
// NO HARDCODED DATA - everything fetched live!
// =====================================================

import * as cheerio from 'cheerio';

class ISMQuoteExtractor {
  constructor(options = {}) {
    this.timeout = options.timeout || 30000;
    this.perplexityApiKey = options.perplexityApiKey;
    
    // Known ISM industries for validation
    this.validIndustries = new Set([
      'Machinery',
      'Transportation Equipment',
      'Chemical Products',
      'Computer & Electronic Products',
      'Food, Beverage & Tobacco Products',
      'Fabricated Metal Products',
      'Electrical Equipment, Appliances & Components',
      'Miscellaneous Manufacturing',
      'Primary Metals',
      'Paper Products',
      'Plastics & Rubber Products',
      'Textile Mills',
      'Furniture & Related Products',
      'Petroleum & Coal Products',
      'Nonmetallic Mineral Products',
      'Wood Products',
      'Printing & Related Support Activities',
      'Apparel, Leather & Allied Products',
    ]);

    // Summary patterns to REJECT
    this.summaryPatterns = [
      /survey respondents/i,
      /respondents continue/i,
      /respondents in several/i,
      /respondents are expecting/i,
      /continue to report/i,
      /reported growth/i,
      /reported contraction/i,
      /reported expansion/i,
      /manufacturing activity/i,
      /pmi registered/i,
      /percent reported/i,
      /diffusion index/i,
      /panelists reported/i,
      /industries reported/i,
    ];

    console.log('[ISMQuoteExtractor v3.0] Initialized - Dynamic extraction');
  }

  // ============================================
  // MAIN ENTRY POINT
  // ============================================

  async fetchQuotes(month) {
    const [year, monthNum] = month.split('-');
    const monthNames = [
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december'
    ];
    const monthName = monthNames[parseInt(monthNum) - 1];
    const fullMonthName = monthName.charAt(0).toUpperCase() + monthName.slice(1);
    
    console.log(`\n[QuoteExtractor v3.0] ========================================`);
    console.log(`[QuoteExtractor v3.0] Extracting quotes for ${fullMonthName} ${year}`);
    console.log(`[QuoteExtractor v3.0] ========================================\n`);
    
    const extractionAttempts = [];
    let quotes = null;

    // ═══════════════════════════════════════════════════════════════
    // TIER 1: PRNewswire Direct HTML Scraping (MOST RELIABLE)
    // ═══════════════════════════════════════════════════════════════
    console.log('[QuoteExtractor v3.0] TIER 1: PRNewswire Direct HTML...');
    
    try {
      quotes = await this.fetchFromPRNewswire(monthName, year);
      extractionAttempts.push({
        tier: 1,
        source: 'PRNewswire HTML',
        success: !!quotes && quotes.length >= 5,
        count: quotes?.length || 0,
      });
      
      if (quotes && quotes.length >= 5) {
        console.log(`[QuoteExtractor v3.0] ✓ TIER 1 SUCCESS: ${quotes.length} verified quotes`);
        return this.finalizeQuotes(quotes, 'PRNewswire HTML Direct', extractionAttempts, true);
      }
      console.log(`[QuoteExtractor v3.0] TIER 1: Only ${quotes?.length || 0} quotes found`);
    } catch (error) {
      console.error(`[QuoteExtractor v3.0] TIER 1 Error: ${error.message}`);
      extractionAttempts.push({ tier: 1, source: 'PRNewswire HTML', success: false, error: error.message });
    }

    // ═══════════════════════════════════════════════════════════════
    // TIER 2: ISM Website Direct HTML Scraping
    // ═══════════════════════════════════════════════════════════════
    console.log('[QuoteExtractor v3.0] TIER 2: ISM Website Direct HTML...');
    
    try {
      quotes = await this.fetchFromISMWebsite(monthName, year);
      extractionAttempts.push({
        tier: 2,
        source: 'ISM Website HTML',
        success: !!quotes && quotes.length >= 5,
        count: quotes?.length || 0,
      });
      
      if (quotes && quotes.length >= 5) {
        console.log(`[QuoteExtractor v3.0] ✓ TIER 2 SUCCESS: ${quotes.length} verified quotes`);
        return this.finalizeQuotes(quotes, 'ISM Website Direct', extractionAttempts, true);
      }
      console.log(`[QuoteExtractor v3.0] TIER 2: Only ${quotes?.length || 0} quotes found`);
    } catch (error) {
      console.error(`[QuoteExtractor v3.0] TIER 2 Error: ${error.message}`);
      extractionAttempts.push({ tier: 2, source: 'ISM Website HTML', success: false, error: error.message });
    }

    // ═══════════════════════════════════════════════════════════════
    // TIER 3: Perplexity API with strict instructions (FALLBACK)
    // ═══════════════════════════════════════════════════════════════
    if (this.perplexityApiKey) {
      console.log('[QuoteExtractor v3.0] ⚠️ TIER 3: Perplexity API (UNVERIFIED)...');
      
      try {
        quotes = await this.fetchFromPerplexity(fullMonthName, year);
        extractionAttempts.push({
          tier: 3,
          source: 'Perplexity API',
          success: !!quotes && quotes.length >= 3,
          count: quotes?.length || 0,
        });
        
        if (quotes && quotes.length >= 3) {
          console.log(`[QuoteExtractor v3.0] ⚠️ TIER 3: ${quotes.length} quotes (UNVERIFIED - needs review)`);
          return this.finalizeQuotes(quotes, 'Perplexity (Unverified)', extractionAttempts, false);
        }
      } catch (error) {
        console.error(`[QuoteExtractor v3.0] TIER 3 Error: ${error.message}`);
        extractionAttempts.push({ tier: 3, source: 'Perplexity API', success: false, error: error.message });
      }
    }

    // ═══════════════════════════════════════════════════════════════
    // ALL TIERS FAILED
    // ═══════════════════════════════════════════════════════════════
    console.log('[QuoteExtractor v3.0] ❌ ALL TIERS FAILED - No verified quotes available');
    console.log('[QuoteExtractor v3.0] Attempts:', JSON.stringify(extractionAttempts, null, 2));
    
    return this.finalizeQuotes([], 'None Available', extractionAttempts, false);
  }

  // ============================================
  // TIER 1: PRNewswire Direct Scraping
  // ============================================

  async fetchFromPRNewswire(monthName, year) {
    // Step 1: Find the article URL
    const articleUrl = await this.findPRNewswireArticleURL(monthName, year);
    
    if (!articleUrl) {
      console.log('[PRNewswire] Could not find article URL');
      return null;
    }
    
    console.log(`[PRNewswire] Found article: ${articleUrl}`);
    
    // Step 2: Fetch and parse the article
    return await this.scrapePRNewswirePage(articleUrl);
  }

  async findPRNewswireArticleURL(monthName, year) {
    // PRNewswire URL pattern: manufacturing-pmi-at-XX-X-MONTH-YEAR-ism-manufacturing-pmi-report-XXXXXX.html
    // We need to search for it
    
    const searchUrls = [
      // Direct search on PRNewswire
      `https://www.prnewswire.com/search/news/?keyword=ISM+Manufacturing+PMI+${monthName}+${year}&page=1&pagesize=10`,
      // Alternative: Google site search
    ];
    
    try {
      // Try to construct likely URL directly
      // PRNewswire URLs follow predictable patterns
      const response = await fetch(`https://www.prnewswire.com/news-releases/`, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        // Try alternative approach: use ISM's own link
        return await this.findArticleViaISM(monthName, year);
      }

      const html = await response.text();
      const $ = cheerio.load(html);
      
      // Look for ISM Manufacturing link
      let foundUrl = null;
      $('a').each((_, el) => {
        const href = $(el).attr('href') || '';
        const text = $(el).text().toLowerCase();
        
        if (href.includes('manufacturing-pmi') && 
            href.includes(monthName.toLowerCase()) && 
            href.includes(year)) {
          foundUrl = href.startsWith('http') ? href : `https://www.prnewswire.com${href}`;
          return false;
        }
      });

      return foundUrl;

    } catch (error) {
      console.error(`[PRNewswire] Search error: ${error.message}`);
      // Fallback: try ISM website for PRNewswire link
      return await this.findArticleViaISM(monthName, year);
    }
  }

  async findArticleViaISM(monthName, year) {
    // ISM website often links to PRNewswire
    try {
      const ismUrl = `https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/${monthName}/`;
      
      const response = await fetch(ismUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) return null;

      const html = await response.text();
      const $ = cheerio.load(html);
      
      // Look for PRNewswire link
      let prUrl = null;
      $('a').each((_, el) => {
        const href = $(el).attr('href') || '';
        if (href.includes('prnewswire.com') && href.includes('manufacturing-pmi')) {
          prUrl = href;
          return false;
        }
      });

      return prUrl;

    } catch (error) {
      console.error(`[ISM->PRNewswire] Error: ${error.message}`);
      return null;
    }
  }

  async scrapePRNewswirePage(url) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        console.log(`[PRNewswire] Page fetch failed: HTTP ${response.status}`);
        return null;
      }

      const html = await response.text();
      return this.extractQuotesFromHTML(html, url, 'PRNewswire');

    } catch (error) {
      console.error(`[PRNewswire] Scrape error: ${error.message}`);
      return null;
    }
  }

  // ============================================
  // TIER 2: ISM Website Direct Scraping
  // ============================================

  async fetchFromISMWebsite(monthName, year) {
    const url = `https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/${monthName}/`;
    
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        console.log(`[ISM Website] Fetch failed: HTTP ${response.status}`);
        return null;
      }

      const html = await response.text();
      return this.extractQuotesFromHTML(html, url, 'ISM Website');

    } catch (error) {
      console.error(`[ISM Website] Error: ${error.message}`);
      return null;
    }
  }

  // ============================================
  // TIER 3: Perplexity API (Fallback)
  // ============================================

  async fetchFromPerplexity(fullMonthName, year) {
    if (!this.perplexityApiKey) return null;

    try {
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [{
            role: 'user',
            content: `Find the "WHAT RESPONDENTS ARE SAYING" section from the ISM Manufacturing PMI Report for ${fullMonthName} ${year} on prnewswire.com.

CRITICAL RULES:
1. ONLY return REAL executive quotes with (Industry Name) at the end
2. Each quote must be 50+ characters
3. Each quote must have first-person language like "we", "our", "I", "customers"

DO NOT RETURN:
- "Survey respondents continue to report..."
- "Respondents in several industries..."
- "Manufacturing activity contracted..."
- Any text that sounds like a report summary

RETURN FORMAT:
1. "[exact quote text]" (Industry Name)
2. "[exact quote text]" (Industry Name)

Return QUOTES_NOT_FOUND if you cannot find real executive quotes.`
          }],
          temperature: 0,
          max_tokens: 4000,
          return_citations: true,
          search_recency_filter: 'month',
        }),
      });

      if (!response.ok) {
        console.log(`[Perplexity] API error: HTTP ${response.status}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      
      if (content.includes('QUOTES_NOT_FOUND')) {
        console.log('[Perplexity] No quotes found');
        return null;
      }

      return this.parsePerplexityResponse(content);

    } catch (error) {
      console.error(`[Perplexity] Error: ${error.message}`);
      return null;
    }
  }

  parsePerplexityResponse(content) {
    const quotes = [];
    const seen = new Set();

    // Pattern: Number. "quote" (Industry)
    const patterns = [
      /\d+\.\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
      /\d+\.\s*\[([^\]]{40,800})\]\s*\(([^)]+)\)/g,
      /[-•*]\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
    ];

    for (const pattern of patterns) {
      pattern.lastIndex = 0;
      let match;
      
      while ((match = pattern.exec(content)) !== null) {
        const comment = this.cleanQuoteText(match[1]);
        const industry = this.cleanIndustryName(match[2]);

        const key = comment.substring(0, 50).toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);

        // Validate it's a real quote, not summary
        if (this.isSummaryText(comment)) {
          console.log(`[Perplexity] Rejected summary: "${comment.substring(0, 40)}..."`);
          continue;
        }

        if (!this.hasFirstPersonLanguage(comment)) {
          console.log(`[Perplexity] Rejected (no first-person): "${comment.substring(0, 40)}..."`);
          continue;
        }

        quotes.push({
          industry: this.normalizeIndustryName(industry),
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment),
        });
      }
    }

    return quotes.length >= 3 ? quotes : null;
  }

  // ============================================
  // HTML QUOTE EXTRACTION (Shared)
  // ============================================

  extractQuotesFromHTML(html, sourceUrl, sourceName) {
    const quotes = [];
    
    // Find "WHAT RESPONDENTS ARE SAYING" section
    const sectionMarkers = [
      'WHAT RESPONDENTS ARE SAYING',
      'What Respondents Are Saying',
      'WHAT RESPONDENTS ARE SAYING</strong>',
    ];
    
    let sectionStart = -1;
    for (const marker of sectionMarkers) {
      sectionStart = html.indexOf(marker);
      if (sectionStart !== -1) break;
    }
    
    if (sectionStart === -1) {
      console.log(`[${sourceName}] Could not find respondents section`);
      return null;
    }
    
    // Find section end
    const endMarkers = ['MANUFACTURING AT A GLANCE', '<table', '|  |', 'Manufacturing PMI®'];
    let sectionEnd = html.length;
    
    for (const marker of endMarkers) {
      const idx = html.indexOf(marker, sectionStart + 100);
      if (idx !== -1 && idx < sectionEnd) {
        sectionEnd = idx;
      }
    }
    
    const section = html.substring(sectionStart, sectionEnd);
    console.log(`[${sourceName}] Found section (${section.length} chars)`);

    // Extract quotes with multiple patterns
    const quotePatterns = [
      // Pattern 1: * "Quote text" (Industry)
      /[*•]\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
      
      // Pattern 2: "Quote text" (Industry) without bullet
      /"([^"]{40,800})"\s*\(([^)]+)\)/g,
      
      // Pattern 3: Smart quotes
      /[""]([^""]{40,800})[""]\s*\(([^)]+)\)/g,
      
      // Pattern 4: HTML entities
      /&quot;([^&]{40,800})&quot;\s*\(([^)]+)\)/g,
    ];

    const seen = new Set();

    for (const pattern of quotePatterns) {
      pattern.lastIndex = 0;
      let match;

      while ((match = pattern.exec(section)) !== null) {
        const comment = this.cleanQuoteText(match[1]);
        const industry = this.cleanIndustryName(match[2]);

        // Skip duplicates
        const key = comment.substring(0, 50).toLowerCase().replace(/\s+/g, ' ');
        if (seen.has(key)) continue;
        seen.add(key);

        // Skip summaries
        if (this.isSummaryText(comment)) {
          console.log(`[${sourceName}] Rejected summary: "${comment.substring(0, 40)}..."`);
          continue;
        }

        // Validate industry
        if (!this.isValidIndustry(industry)) {
          console.log(`[${sourceName}] Unknown industry: ${industry}`);
          continue;
        }

        // Score authenticity
        const score = this.scoreQuoteAuthenticity(comment);
        if (score < 0.3) {
          console.log(`[${sourceName}] Low score (${score.toFixed(2)}): "${comment.substring(0, 40)}..."`);
          continue;
        }

        quotes.push({
          industry: this.normalizeIndustryName(industry),
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment),
          authenticityScore: score,
        });

        console.log(`[${sourceName}] ✓ Extracted: [${industry}] "${comment.substring(0, 50)}..."`);
      }
    }

    // Sort by authenticity
    quotes.sort((a, b) => (b.authenticityScore || 0) - (a.authenticityScore || 0));

    console.log(`[${sourceName}] Total: ${quotes.length} verified quotes`);
    return quotes.length >= 3 ? quotes : null;
  }

  // ============================================
  // VALIDATION & SCORING
  // ============================================

  isSummaryText(text) {
    const lower = text.toLowerCase();
    return this.summaryPatterns.some(pattern => pattern.test(lower));
  }

  hasFirstPersonLanguage(text) {
    const lower = text.toLowerCase();
    const firstPersonPatterns = [
      /\b(we|our|us|we've|we're)\b/,
      /\b(i|my|i've|i'm|i have|i am)\b/,
      /\bcustomer/,
      /\bsupplier/,
    ];
    return firstPersonPatterns.some(p => p.test(lower));
  }

  isValidIndustry(industry) {
    const lower = industry.toLowerCase().trim();
    
    for (const valid of this.validIndustries) {
      if (valid.toLowerCase() === lower) return true;
    }
    
    // Partial match
    const firstWord = lower.split(/[,\s&]/)[0].trim();
    if (firstWord.length < 3) return false;
    
    for (const valid of this.validIndustries) {
      if (valid.toLowerCase().includes(firstWord)) return true;
    }
    
    return false;
  }

  scoreQuoteAuthenticity(text) {
    const lower = text.toLowerCase();
    let score = 0.5;
    
    // Positive indicators
    const positive = [
      [/\b(we|our|us)\b/, 0.15],
      [/\b(my|i have|i am)\b/, 0.15],
      [/\bcustomer/, 0.1],
      [/\bsuppli/, 0.1],
      [/\border/, 0.08],
      [/\bdemand\b/, 0.08],
      [/\binventor/, 0.08],
      [/\blead time/, 0.1],
      [/\bpric/, 0.08],
      [/\btariff/, 0.1],
    ];
    
    // Negative indicators
    const negative = [
      [/manufacturing (activity|sector)/, -0.3],
      [/pmi (registered|recorded)/, -0.3],
      [/percent (reported|of respondents)/, -0.3],
      [/survey respondents/, -0.4],
      [/respondents continue/, -0.4],
    ];
    
    for (const [pattern, delta] of positive) {
      if (pattern.test(lower)) score += delta;
    }
    
    for (const [pattern, delta] of negative) {
      if (pattern.test(lower)) score += delta;
    }
    
    return Math.max(0, Math.min(1, score));
  }

  // ============================================
  // TEXT UTILITIES
  // ============================================

  cleanQuoteText(text) {
    return text
      .trim()
      .replace(/^[""\u201C\u201D]+|[""\u201C\u201D]+$/g, '')
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  cleanIndustryName(industry) {
    return industry.trim().replace(/\s+/g, ' ').replace(/&amp;/g, '&');
  }

  normalizeIndustryName(industry) {
    const lower = industry.toLowerCase().trim();
    
    for (const valid of this.validIndustries) {
      if (valid.toLowerCase() === lower) return valid;
      if (valid.toLowerCase().includes(lower.split(',')[0].trim())) return valid;
    }
    
    return industry.split(' ')
      .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
  }

  detectSentiment(text) {
    const lower = text.toLowerCase();
    
    const negative = ['struggle', 'difficult', 'weak', 'decline', 'uncertain', 'soft', 
      'concern', 'challenge', 'contraction', 'reduction', 'layoff', 'cut', 'slow',
      'lackluster', 'volatile', 'confusion'];
    const positive = ['growth', 'strong', 'increase', 'improve', 'optimis', 'recover', 
      'expand', 'better', 'stable', 'solid', 'good', 'confident'];

    const negCount = negative.filter(w => lower.includes(w)).length;
    const posCount = positive.filter(w => lower.includes(w)).length;

    if (negCount > posCount + 1) return 'negative';
    if (posCount > negCount + 1) return 'positive';
    if (negCount > posCount) return 'slightly_negative';
    if (posCount > negCount) return 'slightly_positive';
    return 'neutral';
  }

  detectTheme(text) {
    const lower = text.toLowerCase();
    
    if (lower.includes('tariff')) return 'tariffs';
    if (lower.includes('supply chain') || lower.includes('supplier')) return 'supply_chain';
    if (lower.includes('demand') || lower.includes('order')) return 'demand';
    if (lower.includes('price') || lower.includes('cost')) return 'costs';
    if (lower.includes('employ') || lower.includes('staff')) return 'employment';
    if (lower.includes('uncertain')) return 'uncertainty';
    if (lower.includes('inventory')) return 'inventory';
    if (lower.includes('lead time') || lower.includes('delivery')) return 'lead_times';
    if (lower.includes('government') || lower.includes('shutdown')) return 'government';
    if (lower.includes('trade') || lower.includes('export')) return 'trade';
    
    return 'general';
  }

  // ============================================
  // FINALIZE QUOTES
  // ============================================

  finalizeQuotes(quotes, source, attempts, isVerified) {
    return quotes.map((q, index) => ({
      ...q,
      source,
      isVerified,
      needsManualReview: !isVerified,
      extractedAt: new Date().toISOString(),
      position: index + 1,
      extractionMeta: {
        tiersAttempted: attempts.length,
        successfulTier: attempts.find(a => a.success)?.tier || null,
        allAttempts: attempts,
      },
    }));
  }
}

export { ISMQuoteExtractor };