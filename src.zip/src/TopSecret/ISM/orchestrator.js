// =====================================================
// ISM REPORT ORCHESTRATOR v3.1 - COMPLETE DATA FLOW
// =====================================================
// Location: src/TopSecret/ISM/orchestrator.js
//
// CHANGES from v3.0:
// - FIXED: buildQuotesAnalysis now properly handles quote objects
// - Quote objects have {industry, comment} format from data-service
// - Added debug logging for quotes flow
// - Quotes now properly pass industry names to PDF
// - Increased quote limit from 5 to 8
// =====================================================

import { ALL_AGENTS, AGENT_DEFINITIONS, AGENT_EXECUTORS } from './IsmAgents.js';
import { ISMDataService } from './data-service.js';
import { PHASES, PHASE_ORDER, VERSION } from './config.js';
import { generateMarkdownReport, generateHTMLReport } from './report-generator.js';

// ============================================
// WORKFLOW STATE MANAGER
// In-memory storage for active workflows
// ============================================

class WorkflowStateManager {
  constructor() {
    this.workflows = new Map();
  }

  create(reportId) {
    const state = {
      reportId,
      status: 'running',
      currentPhase: null,
      currentAgentId: null,
      currentAgentName: null,
      completedAgents: [],
      failedAgents: [],
      progress: 0,
      startedAt: new Date().toISOString(),
      elapsedSeconds: 0,
      logs: [],
      error: null,
      results: {},
    };
    this.workflows.set(reportId, state);
    return state;
  }

  get(reportId) {
    return this.workflows.get(reportId) || null;
  }

  update(reportId, updates) {
    const current = this.workflows.get(reportId);
    if (current) {
      Object.assign(current, updates);
      current.elapsedSeconds = Math.round((Date.now() - new Date(current.startedAt).getTime()) / 1000);
      this.workflows.set(reportId, current);
    }
    return current;
  }

  addLog(reportId, log) {
    const current = this.workflows.get(reportId);
    if (current) {
      current.logs.push({
        ...log,
        timestamp: new Date().toISOString(),
      });
    }
  }

  delete(reportId) {
    this.workflows.delete(reportId);
  }

  cleanup() {
    const oneHourAgo = Date.now() - 60 * 60 * 1000;
    for (const [id, workflow] of this.workflows) {
      if (new Date(workflow.startedAt).getTime() < oneHourAgo) {
        this.workflows.delete(id);
      }
    }
  }
}

// Global workflow manager
const workflowManager = new WorkflowStateManager();

// Cleanup old workflows every 10 minutes
setInterval(() => workflowManager.cleanup(), 10 * 60 * 1000);

// ============================================
// ORCHESTRATOR CLASS
// ============================================

class ISMOrchestrator {
  constructor(dataService, options = {}) {
    // Support both patterns: new ISMOrchestrator(dataService, options) and new ISMOrchestrator(supabase, options)
    if (dataService && typeof dataService.fetchISMData === 'function') {
      // dataService is already a ISMDataService instance
      this.dataService = dataService;
      this.supabase = options.supabase;
    } else {
      // dataService is actually supabase
      this.supabase = dataService;
      this.dataService = new ISMDataService(dataService, {
        perplexityApiKey: options.perplexityApiKey || process.env.PERPLEXITY_API_KEY,
        openaiApiKey: options.openaiApiKey || process.env.OPENAI_API_KEY,
        fredApiKey: options.fredApiKey || process.env.FRED_API_KEY,
      });
    }
    
    this.onProgress = options.onProgress || (() => {});
    this.onAgentComplete = options.onAgentComplete || (() => {});
    this.onError = options.onError || console.error;
    
    // Build agent map
    this.agents = {};
    ALL_AGENTS.forEach(agent => {
      this.agents[agent.id] = agent;
    });
    
    console.log(`[Orchestrator v3] Initialized with ${ALL_AGENTS.length} agents`);
    console.log('[Orchestrator v3] API keys:', {
      hasPerplexity: !!(options.perplexityApiKey || process.env.PERPLEXITY_API_KEY),
      hasOpenAI: !!(options.openaiApiKey || process.env.OPENAI_API_KEY),
      hasFRED: !!(options.fredApiKey || process.env.FRED_API_KEY),
    });
  }

  // ============================================
  // PRE-GENERATION CHECKS
  // ============================================

  async canGenerate(month) {
    const availability = this.dataService.checkISMAvailability(month);
    
    if (this.supabase) {
      const { data: existing } = await this.supabase
        .from('ism_report_tracking')
        .select('status, report_id')
        .eq('report_month', month)
        .single();

      if (existing?.status === 'report_generated') {
        return {
          canGenerate: false,
          reason: 'Report already generated for this month. Use admin override to regenerate.',
          existingReportId: existing.report_id,
        };
      }
    }

    if (!availability.isAvailable) {
      return {
        canGenerate: false,
        reason: availability.reason,
      };
    }

    return {
      canGenerate: true,
    };
  }

  async getStatus(month) {
    const canGen = await this.canGenerate(month);
    
    const status = {
      month,
      canGenerate: canGen.canGenerate,
      reason: canGen.reason,
      existingReportId: canGen.existingReportId || null,
      apiStatus: {
        perplexity: !!process.env.PERPLEXITY_API_KEY,
        openai: !!process.env.OPENAI_API_KEY,
        fred: !!process.env.FRED_API_KEY,
      },
    };

    return status;
  }

  generateReportId() {
    return `ism_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  }

  // ============================================
  // MAIN GENERATION FLOW
  // ============================================

  async generate(reportMonth, options = {}) {
    const {
      reportId: providedReportId,
      isAdminOverride = false,
      overrideReason = null,
      adminId = null,
      skipQA = false,
    } = options;

    const startTime = Date.now();
    const reportId = providedReportId || this.generateReportId();
    const workflow = workflowManager.create(reportId);

    console.log(`\n[Orchestrator v3] ========================================`);
    console.log(`[Orchestrator v3] Starting report generation for ${reportMonth}`);
    console.log(`[Orchestrator v3] Report ID: ${reportId}`);
    console.log(`[Orchestrator v3] ========================================\n`);

    // Initialize context
    const context = {
      reportId,
      reportMonth,
      startTime,
      dataService: this.dataService,
      supabase: this.supabase,
      results: {},
      errors: [],
      completedAgents: [],
      currentPhase: null,
      currentAgent: null,
      config: {
        isAdminOverride,
        overrideReason,
        adminId,
        skipQA,
      },
    };

    const totalAgents = ALL_AGENTS.length;
    let completedCount = 0;

    try {
      // Update tracking status
      await this.updateTrackingStatus(reportMonth, 'generating', {
        is_admin_override: isAdminOverride,
        admin_id: adminId,
        override_reason: overrideReason,
      });

      workflowManager.addLog(reportId, {
        phase: 'INIT',
        agentId: 'orchestrator',
        agentName: 'Orchestrator',
        message: `Starting ISM report generation for ${reportMonth}`,
        type: 'info',
      });

      // Get agents to run (optionally skip QA)
      const sortedAgents = [...AGENT_DEFINITIONS].sort((a, b) => a.order - b.order);
      const agentsToRun = skipQA
        ? sortedAgents.filter(a => a.phase !== PHASES.QUALITY_ASSURANCE)
        : sortedAgents;

      // Execute agents in order
      for (let i = 0; i < agentsToRun.length; i++) {
        const agentDef = agentsToRun[i];
        const agent = this.agents[agentDef.id];

        if (!agent || !agent.execute) {
          console.warn(`[Orchestrator v3] Agent ${agentDef.id} has no execute function`);
          continue;
        }

        // Check dependencies
        const missingDeps = this.checkDependencies(agentDef, context);
        if (missingDeps.length > 0) {
          console.warn(`[Orchestrator v3] Skipping ${agentDef.id} - dependencies not ready: ${missingDeps.join(', ')}`);
          workflowManager.addLog(reportId, {
            phase: agentDef.phase,
            agentId: agentDef.id,
            agentName: agentDef.name,
            message: `Skipped - dependencies not ready: ${missingDeps.join(', ')}`,
            type: 'warning',
          });
          continue;
        }

        context.currentPhase = agentDef.phase;
        context.currentAgent = agentDef.id;

        // Report progress
        const progress = Math.round((i / agentsToRun.length) * 100);
        
        workflowManager.update(reportId, {
          currentPhase: agentDef.phase,
          currentAgentId: agentDef.id,
          currentAgentName: agentDef.name,
          progress,
        });

        this.onProgress({
          reportId,
          status: 'running',
          progress,
          currentPhase: agentDef.phase,
          currentAgentId: agentDef.id,
          currentAgentName: agentDef.name,
          completedAgents: [...context.completedAgents],
          totalAgents,
          elapsedSeconds: Math.round((Date.now() - startTime) / 1000),
        });

        workflowManager.addLog(reportId, {
          phase: agentDef.phase,
          agentId: agentDef.id,
          agentName: agentDef.name,
          message: 'Started execution',
          type: 'info',
        });

        console.log(`[Orchestrator v3] Executing: ${agentDef.name} (${agentDef.id})`);

        try {
          // Execute agent
          const result = await agent.execute(context);

          if (result.success) {
            context.results[agentDef.id] = result.data;
            context.completedAgents.push(agentDef.id);
            completedCount++;

            console.log(`[Orchestrator v3] ✅ ${agentDef.name} completed in ${result.duration}ms`);

            workflowManager.update(reportId, {
              completedAgents: [...context.completedAgents],
            });

            workflowManager.addLog(reportId, {
              phase: agentDef.phase,
              agentId: agentDef.id,
              agentName: agentDef.name,
              message: `Completed in ${result.duration}ms`,
              type: 'success',
            });

            this.onAgentComplete({
              agentId: agentDef.id,
              agentName: agentDef.name,
              success: true,
              duration: result.duration,
            });

            // Log to database
            await this.logAgentExecution(reportId, reportMonth, agentDef, result);

          } else {
            console.error(`[Orchestrator v3] ❌ ${agentDef.name} failed: ${result.error}`);

            context.errors.push({
              agentId: agentDef.id,
              error: result.error,
            });

            workflow.failedAgents.push(agentDef.id);

            workflowManager.addLog(reportId, {
              phase: agentDef.phase,
              agentId: agentDef.id,
              agentName: agentDef.name,
              message: `Failed: ${result.error}`,
              type: 'error',
            });

            this.onAgentComplete({
              agentId: agentDef.id,
              agentName: agentDef.name,
              success: false,
              error: result.error,
            });

            // Critical failure for data fetcher
            if (agentDef.id === 'ism_data_fetcher') {
              throw new Error(`Critical agent ${agentDef.id} failed: ${result.error}`);
            }
          }
        } catch (error) {
          console.error(`[Orchestrator v3] Agent ${agentDef.id} threw error:`, error.message);
          
          context.errors.push({
            agentId: agentDef.id,
            error: error.message,
          });

          workflowManager.addLog(reportId, {
            phase: agentDef.phase,
            agentId: agentDef.id,
            agentName: agentDef.name,
            message: `Error: ${error.message}`,
            type: 'error',
          });

          if (agentDef.id === 'ism_data_fetcher') {
            throw error;
          }
        }
      }

      // Compile final report
      console.log(`\n[Orchestrator v3] Compiling final report...`);
      const report = this.compileReport(context);

      // Generate outputs
      const markdown = generateMarkdownReport(report, context);
      const html = generateHTMLReport(report, context);

      const totalDuration = Date.now() - startTime;

      console.log(`[Orchestrator v3] ✅ Report generation complete in ${totalDuration}ms`);
      console.log(`[Orchestrator v3] Completed ${completedCount}/${totalAgents} agents`);
      if (context.errors.length > 0) {
        console.log(`[Orchestrator v3] ⚠️ ${context.errors.length} agents had errors`);
      }

      // Save to database
      const savedReport = await this.saveReport(reportId, reportMonth, context, {
        structured: report,
        markdown,
        html,
      }, options);

      // Update tracking status
      await this.updateTrackingStatus(reportMonth, 'report_generated', {
        report_id: reportId,
        report_generated_at: new Date().toISOString(),
      });

      // Final progress update
      workflowManager.update(reportId, {
        status: 'completed',
        progress: 100,
        currentAgentId: null,
        currentAgentName: null,
      });

      workflowManager.addLog(reportId, {
        phase: 'COMPLETE',
        agentId: 'orchestrator',
        agentName: 'Orchestrator',
        message: 'Report generation completed successfully',
        type: 'success',
      });

      this.onProgress({
        reportId,
        status: 'completed',
        progress: 100,
        currentPhase: 'COMPLETE',
        completedAgents: context.completedAgents,
        totalAgents,
        elapsedSeconds: Math.round(totalDuration / 1000),
      });

      return {
        success: true,
        reportId,
        report,
        markdown,
        html,
        context,
        meta: {
          reportMonth,
          generatedAt: new Date().toISOString(),
          durationMs: totalDuration,
          agentsCompleted: completedCount,
          agentsTotal: totalAgents,
          errorsCount: context.errors.length,
          version: VERSION,
        },
      };

    } catch (error) {
      console.error(`[Orchestrator v3] ❌ Report generation failed:`, error.message);

      workflowManager.update(reportId, {
        status: 'error',
        error: error.message,
      });

      workflowManager.addLog(reportId, {
        phase: 'ERROR',
        agentId: 'orchestrator',
        agentName: 'Orchestrator',
        message: `Generation failed: ${error.message}`,
        type: 'error',
      });

      this.onProgress({
        reportId,
        status: 'error',
        progress: Math.round((completedCount / totalAgents) * 100),
        error: error.message,
        completedAgents: context.completedAgents,
        totalAgents,
        elapsedSeconds: Math.round((Date.now() - startTime) / 1000),
      });

      await this.updateTrackingStatus(reportMonth, 'error', {
        error_message: error.message,
      });

      this.onError(error);

      return {
        success: false,
        reportId,
        error: error.message,
        context,
        meta: {
          reportMonth,
          generatedAt: new Date().toISOString(),
          durationMs: Date.now() - startTime,
          agentsCompleted: completedCount,
          agentsTotal: totalAgents,
        },
      };
    }
  }

  // ============================================
  // DEPENDENCY CHECKING
  // ============================================

  checkDependencies(agentDef, context) {
    const missing = [];
    for (const dep of agentDef.dependencies || []) {
      if (!context.results[dep]) {
        missing.push(dep);
      }
    }
    return missing;
  }

  // ============================================
  // REPORT COMPILATION - v3.0 ENHANCED
  // ============================================

  compileReport(context) {
    const { results, reportMonth, errors = [] } = context;

    // Helper function to properly extract agent data
    // Agent results have format: { success: boolean, data: any, duration: number, error?: string }
    const getAgentData = (agentResult) => {
      if (!agentResult) return null;
      
      // Check if this is an agent result wrapper (has success property)
      if (typeof agentResult === 'object' && 'success' in agentResult) {
        if (agentResult.success === true && agentResult.data !== null && agentResult.data !== undefined) {
          return agentResult.data;
        }
        // Agent failed or data is null
        if (agentResult.error) {
          console.warn('[Orchestrator] Agent failed:', agentResult.error);
        }
        return null;
      }
      
      // Not a wrapper, return as-is (raw data)
      return agentResult;
    };

    // Extract agent results using the helper
    const ismData = getAgentData(results.ism_data_fetcher);
    const historical = getAgentData(results.historical_context_builder);
    const regime = getAgentData(results.macro_regime_detector);
    const gaps = getAgentData(results.gap_analyzer);
    const narrative = getAgentData(results.narrative_architect);
    const trends = getAgentData(results.persistent_trend_scanner);
    const pressures = getAgentData(results.structural_pressure_mapper);
    const sectors = getAgentData(results.sector_impact_scorer);
    const quotes = getAgentData(results.quote_analyzer) || getAgentData(results.quote_extractor);
    const equity = getAgentData(results.equity_criteria_builder);
    const trades = getAgentData(results.trade_idea_generator);
    const qa = getAgentData(results.coherence_checker);
    const summary = getAgentData(results.executive_summary_writer);
    
    // NEW: Get results from new agents if available
    const fedEarnings = getAgentData(results.fed_earnings_analyzer);
    const stockImplications = getAgentData(results.stock_implications_generator);
    const practicalPos = getAgentData(results.practical_positioning_builder);

    // DEBUG: Log what we extracted
    console.log('[Orchestrator] ISM Data extracted:', {
      hasIsmData: !!ismData,
      hasManufacturing: !!ismData?.manufacturing,
      pmi: ismData?.manufacturing?.pmi
    });

    // Get manufacturing data
    const mfg = ismData?.manufacturing || {};
    const priorMonth = ismData?.priorMonth || historical?.priorMonth || {};

    // DEBUG: Log what data we have
    console.log('[Orchestrator] Manufacturing data:', {
      hasMfg: Object.keys(mfg).length > 0,
      pmi: mfg.pmi,
      hasPriorMonth: Object.keys(priorMonth).length > 0,
      priorPmi: priorMonth.pmi
    });

    // ============================================
    // CALCULATE MOM CHANGES - CRITICAL FOR PDF
    // ============================================
    const momChanges = this.calculateMoMChanges(mfg, priorMonth);
    
    // ============================================
    // BUILD WHAT CHANGED SECTION - CRITICAL FOR PDF
    // ============================================
    const whatChanged = this.buildWhatChangedSection(mfg, priorMonth, momChanges, regime);

    // ============================================
    // BUILD QUOTES ANALYSIS SECTION
    // ============================================
    console.log('[Orchestrator] Building quotes analysis...');
    console.log('[Orchestrator] quotes from quote_analyzer:', quotes ? 'yes' : 'no');
    console.log('[Orchestrator] respondentComments from ismData:', ismData?.respondentComments?.length || 0);
    
    const quotesAnalysis = this.buildQuotesAnalysis(quotes, ismData?.respondentComments);
    
    console.log('[Orchestrator] quotesAnalysis result:', quotesAnalysis ? `${quotesAnalysis.quotes?.length} quotes` : 'null');

    // ============================================
    // BUILD PRACTICAL POSITIONING
    // ============================================
    const positioning = practicalPos || this.buildPracticalPositioning(sectors, trades, regime);

    // Build comprehensive report structure
    const report = {
      // Required by PDF generator at root level
      report_month: reportMonth,
      
      // MoM changes - CRITICAL for What Changed table
      mom_changes: momChanges,
      
      // What Changed section - CRITICAL for PDF
      what_changed: whatChanged,
      
      // ISM data at root for PDF access
      ism_data: ismData,
      
      // Quotes Analysis - NEW
      quotes_analysis: quotesAnalysis,
      industry_quotes: quotesAnalysis,
      
      // CRITICAL: respondentComments at root level for PDF/Markdown access
      respondentComments: ismData?.respondentComments || [],
      quotes: quotesAnalysis?.quotes || ismData?.respondentComments || [],
      
      // Practical Positioning - NEW
      practical_positioning: positioning,
      
      // Stock Implications - NEW
      stock_implications: stockImplications,

      meta: {
        reportId: context.reportId,
        month: reportMonth,
        reportMonth,
        generatedAt: new Date().toISOString(),
        dataSource: ismData?.dataSource || 'Unknown',
        version: VERSION,
        agentsCompleted: context.completedAgents?.length || Object.keys(results).length,
        errorsCount: errors.length || 0,
      },

      // Executive Summary (5 lines)
      executive_summary: summary || null,
      executiveSummary: summary?.summary || null,
      fiveLineSummary: summary?.fiveLines || null,
      oneLiner: summary?.oneLiner || '',

      // Analyst Context for opening
      analyst_context: {
        opening: narrative?.opening || this.generateOpeningContext(regime, mfg),
      },

      // Macro Snapshot - primary section
      macro_snapshot: {
        regime: regime?.regimeCode,
        regimeLabel: regime?.regimeLabel,
        confidence: regime?.confidence,
        cyclePosition: regime?.cyclePosition,
        direction: regime?.direction,
        riskLevel: regime?.riskLevel || narrative?.riskLevel,
        reasoning: regime?.reasoning,
        keyFactors: regime?.keyFactors,
        keyDrivers: regime?.keyDrivers || regime?.keyFactors,
        
        // ISM values - PDF generator uses these (CURRENT MONTH)
        pmi: mfg.pmi,
        pmiValue: mfg.pmi,
        newOrders: mfg.newOrders,
        production: mfg.production,
        employment: mfg.employment,
        prices: mfg.prices,
        backlog: mfg.backlog,
        inventories: mfg.inventories,
        supplierDeliveries: mfg.supplierDeliveries,
        newExportOrders: mfg.newExportOrders,
        imports: mfg.imports,
        customersInventories: mfg.customersInventories,
        
        // PRIOR MONTH values - CRITICAL for What Changed table
        previousPmi: priorMonth.pmi || mfg.previousPmi,
        previousNewOrders: priorMonth.newOrders,
        previousProduction: priorMonth.production,
        previousEmployment: priorMonth.employment,
        previousPrices: priorMonth.prices,
        previousBacklog: priorMonth.backlog,
        previousInventories: priorMonth.inventories,
        
        isContraction: regime?.isContraction,
        isExpansion: regime?.isExpansion,
        consecutiveMonths: regime?.consecutiveMonths || historical?.consecutiveContractionMonths,
        
        narrative: narrative?.narrative,
        headline: narrative?.headline,
        keyInsight: narrative?.keyInsight,
        marketImplication: narrative?.marketImplication,
        topRisk: narrative?.topRisk,
        topOpportunity: narrative?.topOpportunity,
        timeHorizons: narrative?.timeHorizons || { shortTerm: null, mediumTerm: null, longTerm: null },
        criticalGaps: gaps?.gaps || narrative?.criticalGaps || [],
        hasSignificantGaps: gaps?.hasSignificantGaps || false,
      },

      // Sector Impacts
      sector_impacts: {
        sectors: sectors?.sectors || [],
        leading: sectors?.leading || sectors?.sectors?.filter(s => s.impactScore >= 6) || [],
        lagging: sectors?.lagging || sectors?.sectors?.filter(s => s.impactScore <= 4) || [],
        underPressure: sectors?.underPressure || [],
        inflectionPoints: sectors?.inflectionPoints || [],
        recentInflections: sectors?.recentInflections || [],
        topPick: sectors?.topPick,
        bottomPick: sectors?.bottomPick,
        sectorCount: sectors?.sectorCount || sectors?.sectors?.length || 0,
        spread: sectors?.spread,
        recommendation: sectors?.recommendation,
      },
      
      // Also as sector_rotation for compatibility
      sector_rotation: {
        sectors: sectors?.sectors || [],
        leading: sectors?.leading || [],
        underPressure: sectors?.underPressure || sectors?.lagging || [],
        rankings: sectors?.sectors || [],
      },

      // Equity Selection Logic
      equity_logic: {
        introduction: equity?.introduction,
        favorable: equity?.favorable || [],
        unfavorable: equity?.unfavorable || [],
        criteria: equity?.criteria || equity?.favorable || [],
        avoid: equity?.avoid || equity?.unfavorable || [],
        avoidCharacteristics: equity?.avoidCharacteristics || [],
        ismToEquityMapping: equity?.ismToEquityMapping || [],
      },

      // Trade Ideas
      trade_ideas: {
        ideas: trades?.ideas || [],
        themes: trades?.themes || trades?.ideas || [],
        highConviction: trades?.highConviction || [],
        longIdeas: trades?.longIdeas || 0,
        shortIdeas: trades?.shortIdeas || 0,
        ideaCount: trades?.ideaCount || trades?.ideas?.length || 0,
        disclaimer: trades?.disclaimer || 'Trade ideas are for educational purposes only. Not investment advice.',
      },

      // Stock picks (from stock_implications or sectors)
      stock_picks: stockImplications?.outperformCandidates || this.extractStockPicks(sectors),

      // Fed & Earnings Link - NEW
      fed_earnings: fedEarnings || null,

      // Supplementary sections
      supplementary: {
        quotes: {
          quotes: quotes?.quotes || [],
          analyzed: quotes?.analyzed || [],
          sectorQuotes: quotes?.sectorQuotes || {},
          highlightQuote: quotes?.highlightQuote,
          quoteCount: quotes?.quoteCount || 0,
        },
        qa: {
          qaScore: qa?.qaScore || 0,
          qaPassed: qa?.qaPassed || false,
          grade: qa?.grade || 'N/A',
          checks: qa?.checks || [],
          issues: qa?.issues || [],
          summary: qa?.summary,
        },
        historical: {
          monthsAnalyzed: historical?.monthsAnalyzed || 0,
          averagePMI: historical?.averagePMI,
          pmiRange: historical?.pmiRange,
          trends: historical?.trends,
          consecutiveContractionMonths: historical?.consecutiveContractionMonths || 0,
          consecutiveExpansionMonths: historical?.consecutiveExpansionMonths || 0,
        },
        analytics: ismData?.analytics || null,
        divergences: ismData?.divergences || [],
        trends: {
          trends: trends?.trends || [],
          persistentTrendCount: trends?.persistentTrendCount || 0,
          criticalTrend: trends?.criticalTrend,
          summary: trends?.summary,
          redFlags: trends?.redFlags || [],
        },
        pressures: {
          pressures: pressures?.pressures || [],
          tailwinds: pressures?.tailwinds || [],
          netAssessment: pressures?.netAssessment,
        },
      },

      // Additional required sections
      invalidation_scenarios: this.generateInvalidationScenarios(context),
      invalidationScenarios: this.generateInvalidationScenarios(context),
      next_month_indicators: this.generateNextMonthIndicators(context),
      nextMonthIndicators: this.generateNextMonthIndicators(context),

      // Synthesis section - NEW
      synthesis: this.buildSynthesis(regime, trades, gaps, mfg),
      mispricing: this.buildMispricingItems(regime, mfg, sectors),

      // Raw data for reference
      rawData: {
        ismData: mfg,
        priorMonth: priorMonth,
        historicalData: historical?.historical,
        respondentComments: ismData?.respondentComments,
      },
    };

    console.log(`[Orchestrator v3] Report compiled with MoM data:`, {
      hasMomChanges: !!report.mom_changes,
      hasWhatChanged: !!report.what_changed,
      hasQuotesAnalysis: !!report.quotes_analysis,
      hasPracticalPositioning: !!report.practical_positioning,
      pmiCurrent: mfg.pmi,
      pmiPrior: priorMonth.pmi,
    });

    return report;
  }

  // ============================================
  // MOM CHANGES CALCULATOR
  // ============================================

  calculateMoMChanges(current, prior) {
    const calc = (curr, prev) => {
      if (curr === null || curr === undefined || prev === null || prev === undefined) {
        return { current: curr, prior: prev, delta: null };
      }
      return {
        current: parseFloat(curr),
        prior: parseFloat(prev),
        delta: parseFloat((curr - prev).toFixed(1)),
      };
    };

    return {
      pmi: calc(current.pmi, prior.pmi),
      newOrders: calc(current.newOrders, prior.newOrders),
      production: calc(current.production, prior.production),
      employment: calc(current.employment, prior.employment),
      prices: calc(current.prices, prior.prices),
      backlog: calc(current.backlog, prior.backlog),
      inventories: calc(current.inventories, prior.inventories),
      supplierDeliveries: calc(current.supplierDeliveries, prior.supplierDeliveries),
      newExportOrders: calc(current.newExportOrders, prior.newExportOrders),
      imports: calc(current.imports, prior.imports),
    };
  }

  // ============================================
  // WHAT CHANGED SECTION BUILDER
  // ============================================

  buildWhatChangedSection(current, prior, momChanges, regime) {
    const changes = [
      {
        component: 'PMI',
        prior: momChanges.pmi.prior,
        current: momChanges.pmi.current,
        delta: momChanges.pmi.delta,
        threshold: 50,
      },
      {
        component: 'New Orders',
        prior: momChanges.newOrders.prior,
        current: momChanges.newOrders.current,
        delta: momChanges.newOrders.delta,
        threshold: 50,
      },
      {
        component: 'Employment',
        prior: momChanges.employment.prior,
        current: momChanges.employment.current,
        delta: momChanges.employment.delta,
        threshold: 50,
      },
      {
        component: 'Prices',
        prior: momChanges.prices.prior,
        current: momChanges.prices.current,
        delta: momChanges.prices.delta,
        threshold: 50,
      },
      {
        component: 'Backlog',
        prior: momChanges.backlog.prior,
        current: momChanges.backlog.current,
        delta: momChanges.backlog.delta,
        threshold: 50,
      },
      {
        component: 'Production',
        prior: momChanges.production.prior,
        current: momChanges.production.current,
        delta: momChanges.production.delta,
        threshold: 50,
      },
    ];

    // Generate narrative
    let narrative = 'This matters because ';
    const pmi = current.pmi || 0;
    const prices = current.prices || 0;
    const employment = current.employment || 0;
    const newOrders = current.newOrders || 0;

    if (pmi < 50 && prices > 55) {
      narrative += `the mix tells the story better than the headline: demand remains weak while cost pressure persists at ${prices.toFixed(1)}. This combination creates the worst margin environment for manufacturers — falling volumes with elevated input costs. `;
      if (employment < 50) {
        narrative += `The employment reading at ${employment.toFixed(1)} suggests companies are already in protection mode, cutting costs rather than investing for growth.`;
      }
    } else if (pmi < 50) {
      narrative += `manufacturing remains below the expansion threshold at ${pmi.toFixed(1)}, but the composition of weakness matters. `;
      if (newOrders < 48) {
        narrative += `The New Orders reading at ${newOrders.toFixed(1)} indicates demand softness is not yet stabilizing — this is a leading indicator worth monitoring closely.`;
      } else {
        narrative += `The balance of evidence suggests we are in a mature contraction rather than an accelerating one.`;
      }
    } else {
      narrative += `the headline expansion at ${pmi.toFixed(1)} masks some nuance beneath the surface. `;
      if (prices > 55) {
        narrative += `Prices at ${prices.toFixed(1)} suggest cost pressures remain elevated even as activity improves — watch for margin implications.`;
      } else {
        narrative += `The sustainability of this reading depends on whether New Orders can maintain momentum in coming months.`;
      }
    }

    return {
      changes,
      narrative,
      takeaway: narrative,
    };
  }

  // ============================================
  // QUOTES ANALYSIS BUILDER
  // ============================================

  buildQuotesAnalysis(quotesResult, respondentComments) {
    // v11: PRIORITIZE raw respondentComments from data-service (real ISM quotes)
    // These come directly from Perplexity web search of ismworld.org
    
    // First check if we have verified raw quotes from data-service
    if (respondentComments && respondentComments.length > 0) {
      console.log('[Orchestrator] Using RAW quotes from data-service (real ISM website)');
      console.log('[Orchestrator] Quote count:', respondentComments.length);
      console.log('[Orchestrator] Industries:', respondentComments.map(q => q.industry).join(', '));
      
      const analyzed = respondentComments.slice(0, 10).map((item, idx) => {
        // Handle both object format {industry, comment} and string format
        const industry = item.industry || item.sector || 'Manufacturing';
        const commentText = item.comment || item.quote || item.text || (typeof item === 'string' ? item : '');
        
        const lowerText = commentText.toLowerCase();
        const isLeading = lowerText.includes('order') || 
                         lowerText.includes('demand') ||
                         lowerText.includes('customer') ||
                         lowerText.includes('backlog');
        
        return {
          industry: industry,
          sector: industry,
          quote: commentText,           // VERBATIM from ISM
          text: commentText,            // VERBATIM from ISM
          comment: commentText,         // VERBATIM from ISM
          originalQuote: commentText,   // VERBATIM from ISM
          classification: isLeading ? 'leading' : 'lagging',
          type: isLeading ? 'leading' : 'lagging',
          sentiment: item.sentiment || 'neutral',
          keyTheme: item.keyTheme || 'general',
          implication: 'Real quote from ISM respondent',
          meaning: 'Real quote from ISM respondent',
          isVerifiedFromISM: true,      // Flag this is real
        };
      });

      console.log('[Orchestrator] Processed RAW quotes:', analyzed.map(q => `${q.industry}: "${q.quote.substring(0, 50)}..."`));

      return {
        quotes: analyzed,
        analyzed: analyzed,
        summary: 'Real industry quotes from ISM Manufacturing Report respondents.',
        insight: 'Real industry quotes from ISM Manufacturing Report respondents.',
        leadingCount: analyzed.filter(q => q.classification === 'leading').length,
        laggingCount: analyzed.filter(q => q.classification === 'lagging').length,
        isVerifiedFromISM: true,
        dataSource: 'ISM Website - What Respondents Are Saying',
      };
    }
    
    // Fallback to quote_analyzer results (but these should also have raw quotes)
    const quotes = quotesResult?.analyzed || quotesResult?.quotes || [];
    
    if (quotes.length > 0) {
      console.log('[Orchestrator] Using quotes from quote_analyzer');
      return {
        quotes: quotes,
        analyzed: quotes,
        summary: quotesResult?.summary || quotesResult?.insight || 'Industry executives signal caution amid uncertain demand.',
        insight: quotesResult?.insight,
        leadingCount: quotesResult?.leadingCount || quotes.filter(q => q.classification === 'leading').length,
        laggingCount: quotesResult?.laggingCount || quotes.filter(q => q.classification === 'lagging').length,
        isVerifiedFromISM: quotesResult?.isVerifiedFromISM || false,
      };
    }

    console.log('[Orchestrator] WARNING: No quotes available from any source');
    console.log('[Orchestrator] Check Perplexity API - should return citations from ismworld.org');
    return null;
  }

  // ============================================
  // PRACTICAL POSITIONING BUILDER
  // ============================================

  buildPracticalPositioning(sectors, trades, regime) {
    const sectorList = sectors?.sectors || [];
    const ideas = trades?.ideas || [];
    const isContraction = regime?.isContraction;

    // Build overweight list
    const overweight = sectorList
      .filter(s => s.impactScore >= 6 || s.bias?.includes('avorable'))
      .slice(0, 4)
      .map(s => ({
        sector: s.sector,
        rationale: s.reasoning || s.whyNow || 'Favorable ISM conditions',
        stocks: s.keyStocks || [],
      }));

    // Build underweight list
    const underweight = sectorList
      .filter(s => s.impactScore <= 4 || s.bias?.includes('nfavorable'))
      .slice(0, 4)
      .map(s => ({
        sector: s.sector,
        rationale: s.reasoning || s.risk || 'Challenging ISM conditions',
        stocks: s.keyStocks || [],
      }));

    // Build avoid list
    const avoid = [];
    if (isContraction) {
      avoid.push({ characteristic: 'High operating leverage with fixed cost base' });
      avoid.push({ characteristic: 'Companies with >50% revenue tied to capital goods' });
      avoid.push({ characteristic: 'Stocks pricing in cycle acceleration' });
    } else {
      avoid.push({ characteristic: 'Companies with margin sensitivity to input costs' });
      avoid.push({ characteristic: 'Late-cycle consumer discretionary plays' });
    }

    // Build watch for longs
    let watchForLongs = '';
    if (isContraction) {
      watchForLongs = 'New Orders crosses above 50 for 2 consecutive months, or Employment stabilizes above 48';
    } else {
      watchForLongs = 'Prices moderate below 55 while New Orders maintain above 52';
    }

    // Summary action
    const summaryAction = isContraction
      ? 'Defensive positioning with quality bias. Favor pricing power over volume growth.'
      : 'Maintain cyclical exposure but hedge against late-cycle margin pressure.';

    return {
      overweight,
      underweight,
      avoid,
      watchForLongs,
      summaryAction,
    };
  }

  // ============================================
  // SYNTHESIS BUILDER
  // ============================================

  buildSynthesis(regime, trades, gaps, mfg) {
    const keyQuestion = regime?.isContraction
      ? 'The key unresolved question is whether pricing pressure fades before demand stabilizes — or whether margins remain the shock absorber into earnings season.'
      : 'The key unresolved question is whether the expansion can maintain momentum without reigniting cost pressures.';

    const whatFlipsNarrative = regime?.isContraction
      ? 'PMI crossing 50 with New Orders above 52 for two consecutive months would signal regime change.'
      : 'New Orders falling below 48 with Employment contracting would signal late-cycle exhaustion.';

    return {
      keyQuestion,
      whatFlipsNarrative,
      criticalGaps: gaps?.gaps || [],
    };
  }

  // ============================================
  // MISPRICING ITEMS BUILDER
  // ============================================

  buildMispricingItems(regime, mfg, sectors) {
    const items = [];

    if (regime?.isContraction && mfg.prices > 55) {
      items.push('Persistence of cost pressure despite demand weakness');
    }

    if (mfg.employment < 47) {
      items.push('Earnings sensitivity to accelerating labor cuts');
    }

    if (mfg.newOrders < 48 && mfg.production > 50) {
      items.push('Backlog depletion masking true demand weakness');
    }

    if (mfg.customersInventories === 'too_low') {
      items.push('Restocking potential not fully reflected in cyclical valuations');
    }

    if (items.length === 0) {
      items.push('Current positioning appears aligned with ISM signals');
    }

    return items;
  }

  // ============================================
  // OPENING CONTEXT GENERATOR
  // ============================================

  generateOpeningContext(regime, mfg) {
    const pmi = mfg.pmi || 0;
    
    let context = `We are approaching this ISM print at a fragile point in the cycle — where inflation persistence, earnings sensitivity, and labor fatigue are colliding. `;
    context += `This report is not about whether the PMI is above or below 50. It is about where pressure is accumulating — and where it is quietly easing. `;
    
    if (pmi < 50) {
      context += `With the headline at ${pmi.toFixed(1)}, manufacturing remains in contraction, but the composition of that weakness tells us far more than the headline. `;
    } else {
      context += `With the headline at ${pmi.toFixed(1)}, manufacturing shows expansion, but the underlying mix of components reveals where the cycle is truly headed. `;
    }
    
    context += `Our goal here is not to restate the numbers. It is to translate them into what matters for positioning.`;
    
    return context;
  }

  // ============================================
  // STOCK PICKS EXTRACTOR
  // ============================================

  extractStockPicks(sectors) {
    if (!sectors?.sectors) return [];
    
    return sectors.sectors
      .filter(s => s.keyStocks && s.keyStocks.length > 0)
      .slice(0, 4)
      .map(s => ({
        sector: s.sector,
        direction: s.impactScore >= 6 ? 'positive' : 'negative',
        stocks: s.keyStocks,
        reasoning: s.reasoning,
        etf: s.etf,
      }));
  }

  // ============================================
  // INVALIDATION SCENARIOS
  // ============================================

  generateInvalidationScenarios(context) {
    const { results } = context;
    
    // Use the same helper function pattern
    const getAgentData = (agentResult) => {
      if (!agentResult) return null;
      if (typeof agentResult === 'object' && 'success' in agentResult) {
        return agentResult.success === true ? agentResult.data : null;
      }
      return agentResult;
    };
    
    const regime = getAgentData(results.macro_regime_detector);
    const ismData = getAgentData(results.ism_data_fetcher);
    const trades = getAgentData(results.trade_idea_generator);
    const mfg = ismData?.manufacturing || {};

    const scenarios = [];

    if (regime?.isContraction) {
      scenarios.push(`PMI rises above 50 for 2+ consecutive months (currently ${mfg.pmi?.toFixed(1) || 'N/A'})`);
      scenarios.push(`New Orders sustain above 52 (currently ${mfg.newOrders?.toFixed(1) || 'N/A'})`);
      scenarios.push(`Employment stabilizes above 48 (currently ${mfg.employment?.toFixed(1) || 'N/A'})`);
    } else {
      scenarios.push(`PMI falls below 48 for 2+ consecutive months (currently ${mfg.pmi?.toFixed(1) || 'N/A'})`);
      scenarios.push(`New Orders collapse below 45 (currently ${mfg.newOrders?.toFixed(1) || 'N/A'})`);
      scenarios.push('Prices spike above 60 triggering margin pressure');
    }

    scenarios.push('Federal Reserve policy pivot (major rate change or QE announcement)');
    scenarios.push('Geopolitical shock (major conflict, trade war escalation)');

    if (trades?.ideas) {
      trades.ideas.forEach(idea => {
        if (idea.invalidation && idea.invalidation.length > 0) {
          scenarios.push(idea.invalidation[0]);
        }
      });
    }

    return [...new Set(scenarios)].slice(0, 6);
  }

  // ============================================
  // NEXT MONTH INDICATORS
  // ============================================

generateNextMonthIndicators(context) {
    const { results } = context;
    
    // Use the same helper function pattern
    const getAgentData = (agentResult) => {
      if (!agentResult) return null;
      if (typeof agentResult === 'object' && 'success' in agentResult) {
        return agentResult.success === true ? agentResult.data : null;
      }
      return agentResult;
    };
    
    const ismData = getAgentData(results.ism_data_fetcher);
    const mfg = ismData?.manufacturing || {};

    const indicators = [];

    // Helper to safely format numbers (handles null/undefined)
    const safeFormat = (val) => (val != null ? val.toFixed(1) : 'N/A');

    if (mfg.newOrders != null) {
      if (mfg.newOrders < 50) {
        indicators.push(`New Orders ${mfg.newOrders > 48 ? 'crossing' : 'approaching'} 50 threshold (currently ${safeFormat(mfg.newOrders)})`);
      } else {
        indicators.push(`New Orders maintaining above 50 (currently ${safeFormat(mfg.newOrders)})`);
      }
    }

    if (mfg.employment != null) {
      if (mfg.employment < 45) {
        indicators.push(`Employment recovery above 45 (currently ${safeFormat(mfg.employment)} - severe weakness)`);
      } else if (mfg.employment < 48) {
        indicators.push(`Employment stabilization above 48 (currently ${safeFormat(mfg.employment)})`);
      } else {
        indicators.push(`Employment trend direction (currently ${safeFormat(mfg.employment)})`);
      }
    }

    if (mfg.prices != null) {
      if (mfg.prices > 58) {
        indicators.push(`Prices moderation below 55 (currently ${safeFormat(mfg.prices)} - elevated)`);
      } else if (mfg.prices > 55) {
        indicators.push(`Prices moderation below 55 (currently ${safeFormat(mfg.prices)})`);
      } else {
        indicators.push(`Prices stability (currently ${safeFormat(mfg.prices)})`);
      }
    }

    if (mfg.backlog != null && mfg.backlog < 46) {
      indicators.push(`Backlog recovery above 48 (currently ${safeFormat(mfg.backlog)} - poor visibility)`);
    }

    if (mfg.customersInventories === 'too_low') {
      indicators.push('Customer inventory normalization (currently "too low" - restocking potential)');
    }

    indicators.push('Regional Fed manufacturing surveys (Empire State, Philly Fed)');
    indicators.push('Corporate earnings guidance for manufacturing exposure');

    return indicators.slice(0, 7);
  }

  // ============================================
  // DATABASE OPERATIONS
  // ============================================

  async updateTrackingStatus(month, status, additionalData = {}) {
    if (!this.supabase) return;

    try {
      await this.supabase
        .from('ism_report_tracking')
        .upsert({
          report_month: month,
          status,
          updated_at: new Date().toISOString(),
          ...additionalData,
        }, { onConflict: 'report_month' });
    } catch (error) {
      console.error('[Orchestrator v3] Failed to update tracking:', error.message);
    }
  }

  async logAgentExecution(reportId, reportMonth, agentDef, result) {
    if (!this.supabase) return;

    try {
      await this.supabase
        .from('ism_agent_logs')
        .insert({
          report_id: reportId,
          report_month: reportMonth,
          agent_id: agentDef.id,
          agent_name: agentDef.name,
          phase: agentDef.phase,
          success: result.success,
          duration_ms: result.duration,
          error: result.error || null,
          created_at: new Date().toISOString(),
        });
    } catch (error) {
      console.error('[Orchestrator v3] Failed to log agent execution:', error.message);
    }
  }

  async saveReport(reportId, reportMonth, context, outputs, options = {}) {
    if (!this.supabase) {
      return { reportId, saved: false };
    }

    try {
      const { structured, markdown, html } = outputs;

      await this.supabase
        .from('ism_reports')
        .upsert({
          id: reportId,
          report_month: reportMonth,
          status: 'generated',
          structured_report: structured,
          markdown_content: markdown,
          html_content: html,
          is_admin_override: options.isAdminOverride || false,
          admin_id: options.adminId || null,
          override_reason: options.overrideReason || null,
          agents_completed: context.completedAgents?.length || 0,
          errors: context.errors || [],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }, { onConflict: 'id' });

      return { reportId, saved: true };
    } catch (error) {
      console.error('[Orchestrator v3] Failed to save report:', error.message);
      return { reportId, saved: false, error: error.message };
    }
  }
}

// ============================================
// EXPORTS
// ============================================

export {
  ISMOrchestrator,
  workflowManager,
  WorkflowStateManager,
};

export default ISMOrchestrator;