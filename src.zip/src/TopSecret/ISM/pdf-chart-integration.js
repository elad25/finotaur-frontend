// =====================================================
// ISM PDF GENERATOR - CHART INTEGRATION v1.0
// =====================================================
// Location: src/TopSecret/ISM/pdf-chart-integration.js
//
// This file contains the updates needed to integrate
// charts into the existing pdf-generator.js
//
// HOW TO USE:
// 1. Add the import at the top of pdf-generator.js
// 2. Add the new functions below
// 3. Call drawChartTriad() and drawTradeIdeaCharts() in the main flow
// =====================================================

// ============================================
// STEP 1: ADD THIS IMPORT AT TOP OF pdf-generator.js
// ============================================

/*
import {
  generateAllReportCharts,
  generatePMIContextChart,
  generateTensionChart,
  generateSectorImpactChart,
  generateComponentsChart,
  generateConsumerStaplesChart,
  generateSemiconductorChart,
  generateIndustrialsChart,
  generateMaterialsChart,
  fetchChartBuffer,
} from './chart-generator.js';
*/

// ============================================
// STEP 2: ADD THESE FUNCTIONS TO pdf-generator.js
// ============================================

/**
 * Draw a chart image in the PDF
 * @param {PDFDocument} doc - PDFKit document
 * @param {Buffer} chartBuffer - PNG image buffer
 * @param {number} x - X position
 * @param {number} y - Y position
 * @param {number} width - Image width
 * @param {number} height - Image height
 * @returns {number} - New Y position after image
 */
function drawChartImage(doc, chartBuffer, x, y, width, height) {
  if (!chartBuffer) {
    console.warn('[PDF] No chart buffer provided');
    return y;
  }
  
  try {
    doc.image(chartBuffer, x, y, { 
      width: width,
      height: height,
    });
    return y + height + 15;
  } catch (error) {
    console.error('[PDF] Error drawing chart:', error.message);
    return y;
  }
}

// ============================================
// CHART TRIAD SECTION - Add after "Our View" section
// ============================================

/**
 * Draw the Chart Triad section
 * 1. Context - Where are we in the cycle
 * 2. Tension - The internal conflict
 * 3. Implications - Who wins/loses
 */
async function drawChartTriad(doc, report, charts, startY, onPageBreak) {
  console.log('[PDF] Drawing Chart Triad section...');
  
  // Always start on a new page for charts
  let y = onPageBreak();
  
  // Section header
  doc.fillColor('#C9A646') // COLORS.gold
     .font('Helvetica-Bold')
     .fontSize(16)
     .text('Visual Analysis', 50, y);
  y += 8;
  
  doc.strokeColor('#C9A646')
     .lineWidth(2)
     .moveTo(50, y)
     .lineTo(200, y)
     .stroke();
  y += 5;
  
  doc.fillColor('#666666')
     .font('Helvetica')
     .fontSize(10)
     .text('Three Charts That Tell The Story', 50, y);
  y += 25;
  
  // ════════════════════════════════════════════════════════════
  // CHART 1: CONTEXT - Where are we in the cycle
  // ════════════════════════════════════════════════════════════
  
  if (charts?.context) {
    doc.fillColor('#1A1A1A')
       .font('Helvetica-Bold')
       .fontSize(12)
       .text('1. Cycle Position', 50, y);
    y += 5;
    
    doc.fillColor('#666666')
       .font('Helvetica')
       .fontSize(9)
       .text('Where manufacturing stands in the expansion/contraction cycle', 50, y);
    y += 15;
    
    y = drawChartImage(doc, charts.context, 50, y, 500, 250);
    y += 10;
  }
  
  // Check if we need a new page
  if (y > 500) {
    y = onPageBreak();
  }
  
  // ════════════════════════════════════════════════════════════
  // CHART 2: TENSION - The internal conflict
  // ════════════════════════════════════════════════════════════
  
  if (charts?.tension) {
    doc.fillColor('#1A1A1A')
       .font('Helvetica-Bold')
       .fontSize(12)
       .text('2. The Tension', 50, y);
    y += 5;
    
    doc.fillColor('#666666')
       .font('Helvetica')
       .fontSize(9)
       .text('Activity vs costs - the stagflation warning', 50, y);
    y += 15;
    
    y = drawChartImage(doc, charts.tension, 50, y, 500, 250);
    y += 10;
  }
  
  // New page for third chart
  y = onPageBreak();
  
  // ════════════════════════════════════════════════════════════
  // CHART 3: IMPLICATIONS - Who wins/loses
  // ════════════════════════════════════════════════════════════
  
  if (charts?.sectorImpact) {
    doc.fillColor('#1A1A1A')
       .font('Helvetica-Bold')
       .fontSize(12)
       .text('3. Sector Implications', 50, y);
    y += 5;
    
    doc.fillColor('#666666')
       .font('Helvetica')
       .fontSize(9)
       .text('Impact ranking - who benefits, who suffers', 50, y);
    y += 15;
    
    y = drawChartImage(doc, charts.sectorImpact, 50, y, 480, 300);
    y += 10;
  }
  
  // Optional: Component breakdown
  if (charts?.components) {
    if (y > 450) {
      y = onPageBreak();
    }
    
    doc.fillColor('#1A1A1A')
       .font('Helvetica-Bold')
       .fontSize(12)
       .text('ISM Component Breakdown', 50, y);
    y += 15;
    
    y = drawChartImage(doc, charts.components, 60, y, 480, 250);
  }
  
  return y;
}

// ============================================
// TRADE IDEA CHARTS - Add within drawStockPicks function
// ============================================

/**
 * Draw chart for a specific trade idea
 * Call this inside the trade idea loop in drawStockPicks()
 */
async function drawTradeIdeaChart(doc, chartBuffer, sectorName, y, onPageBreak) {
  if (!chartBuffer) return y;
  
  // Check if we need page break
  if (y > 550) {
    y = onPageBreak();
  }
  
  // Add small chart
  y = drawChartImage(doc, chartBuffer, 70, y, 400, 200);
  
  return y;
}

// ============================================
// STEP 3: UPDATE generateISMReportPDFBuffer FUNCTION
// ============================================

/*
Replace the current generateISMReportPDFBuffer function with this updated version.
Key changes:
1. Generate charts at the start
2. Add Chart Triad section after "Our View"
3. Add charts to each trade idea
*/

async function generateISMReportPDFBuffer_UPDATED(report, logoData = null) {
  return new Promise(async (resolve, reject) => {
    try {
      const reportMonth = report.report_month || report.meta?.month || 'Unknown';
      const monthDisplay = formatMonthDisplay(reportMonth);

      console.log(`[ISM PDF] Starting - With Charts`);

      // ★★★ GENERATE CHARTS FIRST ★★★
      console.log('[ISM PDF] Generating charts...');
      
      const currentData = {
        manufacturing: report.ism_data?.manufacturing || report.ism_manufacturing || {
          pmi: report.macro_snapshot?.pmi || 48.2,
          newOrders: report.macro_snapshot?.newOrders || 47.4,
          production: report.macro_snapshot?.production || 51.4,
          employment: report.macro_snapshot?.employment || 44,
          prices: report.macro_snapshot?.prices || 58.5,
          backlog: report.macro_snapshot?.backlog || 44,
        },
        month: reportMonth,
      };
      
      const historicalData = report.supplementary?.historical?.data || [];
      const sectorData = report.sector_impacts || report.sector_rotation || null;
      
      // Fetch all charts
      const charts = await generateAllReportCharts(currentData, historicalData, sectorData);
      console.log('[ISM PDF] Charts generated:', Object.keys(charts).filter(k => charts[k]).length);

      // Create PDF document
      const doc = new PDFDocument({
        size: 'letter',
        margin: 0,
        autoFirstPage: false,
        info: {
          Title: `Finotaur ISM Manufacturing Report - ${monthDisplay}`,
          Author: 'Finotaur Research',
          Subject: 'ISM Manufacturing Analysis with Charts',
          Creator: 'Finotaur v6.0 (Charts)',
        },
      });

      registerFonts(doc);

      const chunks = [];
      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(chunks);
        console.log(`[ISM PDF] Complete: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      const logo = findLogo(logoData);

      let currentPageNumber = 0;
      
      const addContentPage = () => {
        doc.addPage();
        currentPageNumber++;
        drawPageHeader(doc, monthDisplay);
        return PAGE.contentTop;
      };

      const drawFooter = (pageNum) => {
        doc.strokeColor(COLORS.veryLightGray)
           .lineWidth(0.3)
           .moveTo(PAGE.marginLeft, PAGE.footerY - 8)
           .lineTo(PAGE.width - PAGE.marginRight, PAGE.footerY - 8)
           .stroke();

        doc.font(FONTS.body).fontSize(SIZES.footer).fillColor(COLORS.lightGray);
        doc.text(COPYRIGHT, PAGE.marginLeft, PAGE.footerY, { lineBreak: false });
        doc.text('For educational purposes only. Not investment advice.', 
          PAGE.width / 2 - 100, PAGE.footerY, { width: 200, align: 'center', lineBreak: false });
        doc.text(`${pageNum}`, PAGE.width - PAGE.marginRight - 20, PAGE.footerY, { 
          width: 20, align: 'right', lineBreak: false 
        });
      };

      // ========== COVER PAGE ==========
      doc.addPage();
      drawCoverPage(doc, monthDisplay, logo);

      // ========== CONTENT PAGES ==========
      let currentY = addContentPage();
      let contentPageNum = 1;

      // 1. ANALYST CONTEXT (Human opening)
      if (report.analyst_context || report.macro_snapshot) {
        currentY = drawAnalystContext(doc, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 20;
      }

      // 2. WHAT CHANGED THIS MONTH
      if (report.what_changed || report.macro_snapshot || report.ism_data) {
        if (needsPageBreak(currentY, 180)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawWhatChanged(doc, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 20;
      }

      // ★★★ NEW: CHART TRIAD SECTION ★★★
      if (charts.context || charts.tension || charts.sectorImpact) {
        drawFooter(contentPageNum);
        currentY = await drawChartTriad(doc, report, charts, currentY, () => {
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
      }

      // 3. EXECUTIVE SUMMARY
      if (report.executive_summary) {
        if (needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawExecutiveSummaryProse(doc, report.executive_summary, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // ... Continue with rest of existing sections ...
      // (Keep all existing section drawing code)

      // 10. TRADE IDEAS - NOW WITH CHARTS
      if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
        drawFooter(contentPageNum);
        currentY = addContentPage();
        contentPageNum++;
      }
      currentY = await drawStockPicksWithCharts(doc, report, charts, currentY, () => {
        drawFooter(contentPageNum);
        const newY = addContentPage();
        contentPageNum++;
        return newY;
      });
      currentY += 25;

      // ... Rest of existing sections ...

      // DISCLAIMER
      generateDisclaimerSection(doc);

      doc.end();

    } catch (error) {
      console.error('[ISM PDF] Error:', error);
      reject(error);
    }
  });
}

// ============================================
// UPDATED TRADE IDEAS WITH CHARTS
// ============================================

async function drawStockPicksWithCharts(doc, report, charts, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Trade Ideas', 'Derived From Executive Commentary', startY);
  
  const ism = report.ism_manufacturing || report.ism_data?.manufacturing || {};
  const quoteAnalysis = report.quotes_analysis || {};
  
  // Get quotes from multiple sources
  let quotes = quoteAnalysis.quotes || [];
  if (quotes.length === 0) quotes = report.respondentComments || [];
  if (quotes.length === 0) quotes = ism.respondentQuotes || ism.respondentComments || [];
  
  // Get ISM data
  const pmi = ism.pmi || report.macro_snapshot?.pmi || 48;
  const prices = ism.prices || report.macro_snapshot?.prices || 55;
  const employment = ism.employment || report.macro_snapshot?.employment || 44;
  const newOrders = ism.newOrders || report.macro_snapshot?.newOrders || 47;
  const backlog = ism.backlog || 44;
  const production = ism.production || 51;
  
  // Generate trade ideas
  let tradeIdeas = generateQuoteDrivenDefaults(
    quotes, 
    { pmi, prices, employment, newOrders, backlog, production },
    ENHANCED_SECTOR_STOCKS
  );
  
  // Intro text
  doc.fillColor(COLORS.mediumGray)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(`Each trade idea below connects ISM data signals to specific sector positioning. The analysis is driven by executive commentary and supported by the underlying numbers.`, PAGE.marginLeft, y, { width: PAGE.contentWidth });
  y += doc.heightOfString(`Each trade idea below...`, { width: PAGE.contentWidth }) + 25;
  
  // Map of sector to chart
  const sectorChartMap = {
    'Consumer Staples': charts.consumerStaples,
    'AI Infrastructure / Semiconductors': charts.semiconductors,
    'Cyclical Industrials / Machinery': charts.industrials,
    'Materials / Industrial Gases': charts.materials,
  };
  
  // Draw each trade idea with charts
  for (let i = 0; i < Math.min(tradeIdeas.length, 4); i++) {
    const idea = tradeIdeas[i];
    
    // Check for page break
    if (needsPageBreak(y, 400) && onPageBreak) {
      y = onPageBreak();
    }
    
    const isLong = (idea.direction || 'long').toLowerCase() === 'long';
    const sectorName = idea.sector || idea.executiveQuoteIndustry || 'Manufacturing';
    const sectorData = getEnhancedStocksForIndustry(sectorName);
    const etf = idea.ticker || sectorData.etf;
    const stocks = idea.alternativeStocks || sectorData.stocks;
    
    // Header
    doc.rect(PAGE.marginLeft, y, 3, 16)
       .fill(COLORS.gold);
    
    const directionText = isLong ? 'LONG' : 'SHORT';
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.stockTicker)
       .text(`${directionText}: ${sectorName}`, PAGE.marginLeft + 10, y);
    y += 20;
    
    // Tickers
    if (stocks && stocks.length > 0) {
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(`Sector ETF: ${etf}  |  Tickers: ${stocks.slice(0, 5).join(', ')}`, PAGE.marginLeft + 10, y);
      y += 20;
    }
    
    // ★★★ ADD SECTOR CHART ★★★
    const sectorChart = sectorChartMap[sectorName];
    if (sectorChart) {
      y = drawChartImage(doc, sectorChart, PAGE.marginLeft + 30, y, 400, 180);
    }
    
    // Executive quote
    const execQuote = idea.executiveQuote || '';
    const quoteIndustry = idea.executiveQuoteIndustry || sectorName;
    
    if (execQuote && execQuote.length > 30) {
      const quoteText = cleanText(execQuote);
      const quoteHeight = doc.heightOfString(`"${quoteText}"`, { width: PAGE.contentWidth - 40 });
      const boxHeight = quoteHeight + 25;
      
      doc.rect(PAGE.marginLeft + 10, y, PAGE.contentWidth - 20, boxHeight)
         .fill('#F5F5F5');
      
      doc.fillColor('#555555')
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(`"${quoteText}"`, PAGE.marginLeft + 20, y + 10, {
           width: PAGE.contentWidth - 40,
           lineGap: 2
         });
      
      doc.fillColor('#888888')
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text(`— ${quoteIndustry}`, PAGE.marginLeft + 20, y + boxHeight - 12);
      
      y += boxHeight + 15;
    }
    
    // Analysis
    const quoteDecoded = idea.quoteDecoded || idea.thesis || '';
    const directImpact = idea.directImpact || '';
    const conviction = (idea.conviction || 'medium').toLowerCase();
    const risks = idea.risks || ['Market conditions change'];
    const riskText = Array.isArray(risks) ? risks[0] : risks;
    
    let analysisText = '';
    
    if (quoteDecoded) {
      analysisText += cleanText(quoteDecoded) + ' ';
    }
    
    if (directImpact) {
      analysisText += cleanText(directImpact) + ' ';
    }
    
    if (conviction === 'high') {
      analysisText += 'This is a high conviction idea based on the current data. ';
    }
    
    if (riskText) {
      analysisText += `Key risk: ${cleanText(riskText).toLowerCase()}.`;
    }
    
    if (analysisText) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(analysisText.trim(), PAGE.marginLeft + 10, y, { 
           width: PAGE.contentWidth - 20,
           lineGap: 3
         });
      y += doc.heightOfString(analysisText, { width: PAGE.contentWidth - 20 }) + 35;
    }
  }
  
  // Disclaimer
  if (needsPageBreak(y, 40) && onPageBreak) {
    y = onPageBreak();
  }
  
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.small - 1)
     .text('These are analytical frameworks, not trade recommendations. Conduct your own due diligence before any investment decision.', 
           PAGE.marginLeft, y, { width: PAGE.contentWidth });
  y += 25;

  return y;
}

// ============================================
// EXPORTS
// ============================================

export {
  drawChartImage,
  drawChartTriad,
  drawTradeIdeaChart,
  drawStockPicksWithCharts,
  generateISMReportPDFBuffer_UPDATED,
};