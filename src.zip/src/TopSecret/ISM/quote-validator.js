// =====================================================
// ISM QUOTE VALIDATOR v1.0
// =====================================================
// Location: src/TopSecret/ISM/quote-validator.js
//
// Validates quotes to ensure they are REAL executive
// quotes from ISM respondents, not AI summaries
// =====================================================

class QuoteValidator {
  constructor() {
    // Official ISM industries (18 manufacturing industries tracked)
    this.validIndustries = new Map([
      ['machinery', 'Machinery'],
      ['transportation equipment', 'Transportation Equipment'],
      ['chemical products', 'Chemical Products'],
      ['computer & electronic products', 'Computer & Electronic Products'],
      ['computer and electronic products', 'Computer & Electronic Products'],
      ['food, beverage & tobacco products', 'Food, Beverage & Tobacco Products'],
      ['food beverage & tobacco', 'Food, Beverage & Tobacco Products'],
      ['fabricated metal products', 'Fabricated Metal Products'],
      ['electrical equipment, appliances & components', 'Electrical Equipment, Appliances & Components'],
      ['electrical equipment', 'Electrical Equipment, Appliances & Components'],
      ['miscellaneous manufacturing', 'Miscellaneous Manufacturing'],
      ['primary metals', 'Primary Metals'],
      ['paper products', 'Paper Products'],
      ['plastics & rubber products', 'Plastics & Rubber Products'],
      ['plastics and rubber products', 'Plastics & Rubber Products'],
      ['textile mills', 'Textile Mills'],
      ['furniture & related products', 'Furniture & Related Products'],
      ['furniture', 'Furniture & Related Products'],
      ['petroleum & coal products', 'Petroleum & Coal Products'],
      ['nonmetallic mineral products', 'Nonmetallic Mineral Products'],
      ['wood products', 'Wood Products'],
      ['printing & related support activities', 'Printing & Related Support Activities'],
      ['printing', 'Printing & Related Support Activities'],
      ['apparel, leather & allied products', 'Apparel, Leather & Allied Products'],
      ['apparel', 'Apparel, Leather & Allied Products'],
    ]);

    // Patterns that indicate REAL executive quotes
    this.realQuoteIndicators = {
      firstPersonPlural: /\b(we|our|us|we've|we're|our company)\b/gi,
      firstPersonSingular: /\b(i|my|i've|i'm|i have|i am)\b/gi,
      operationalTerms: /\b(customer[s]?|suppli(er|es|ed|y)|order[s]?|demand|inventory|lead time[s]?|backlog|shipment[s]?|delivery|production|plant|facility|team|staff)\b/gi,
      businessActions: /\b(looking|trying|seeing|working|expecting|experiencing|dealing|facing|managing|implementing)\b/gi,
      timeReferences: /\b(this (month|quarter|year)|last (month|quarter)|recently|currently|now|soon|going forward)\b/gi,
    };

    // Patterns that indicate SUMMARY (not real quote)
// Patterns that indicate SUMMARY (not real quote)
    this.summaryIndicators = {
      reportLanguage: /\b(pmi (registered|recorded|came in|was)|index (stood|registered)|percent (reported|of respondents)|diffusion index|seasonally adjusted)\b/gi,
      thirdPerson: /\b(manufacturers|industries|companies|firms|panelists|respondents) (reported|noted|said|indicated|commented)\b/gi,
      statisticalLanguage: /\b(the (\d+|ten|six|five) (largest|manufacturing|subindexes)|manufacturing (activity|sector)|economic (activity|conditions)|consecutive month)\b/gi,
      ismBranding: /\b(ism®|pmi®|institute for supply management)\b/gi,
      multipleIndustries: /\([^)]*;[^)]*\)/g,
      // ★★★ NEW: Catches Susan Spence style summaries ★★★
      susanSpenceStyle: /\b(survey respondents|respondents continue|respondents in several|respondents are expecting)\b/gi,
      continueToReport: /\bcontinue to report\b/gi,
      expectingChanges: /\b(expecting to see|larger changes to|substantial struggles)\b/gi,
      impedimentLanguage: /\b(some respondents|several industries|cited the lack|impediment to planning)\b/gi,
    };

    console.log('[QuoteValidator] Initialized with', this.validIndustries.size, 'known industries');
  }

  // ============================================
  // MAIN VALIDATION METHOD
  // ============================================

  validateQuote(quote) {
    const result = {
      isValid: true,
      confidence: 'high',
      errors: [],
      warnings: [],
      scores: {},
      normalizedIndustry: null,
    };

    const comment = quote.comment || quote.text || '';
    const industry = quote.industry || '';

    // 1. Basic validation
    if (!comment || comment.length < 20) {
      result.errors.push('Quote too short (minimum 20 characters)');
      result.isValid = false;
    }

    if (!industry) {
      result.errors.push('Missing industry attribution');
      result.isValid = false;
    }

    // 2. Industry validation
    const normalizedIndustry = this.normalizeIndustry(industry);
    if (normalizedIndustry) {
      result.normalizedIndustry = normalizedIndustry;
    } else {
      result.warnings.push(`Unknown industry: "${industry}" - may be valid but not in standard ISM list`);
    }

    // 3. Real quote score
    const realScore = this.calculateRealQuoteScore(comment);
    result.scores.realQuote = realScore;
if (realScore < 0.3) {
      result.errors.push(`Low authenticity score (${realScore.toFixed(2)}) - likely a summary, not a real quote`);
      result.isValid = false;
    }else if (realScore < 0.5) {
      result.warnings.push(`Medium authenticity score (${realScore.toFixed(2)}) - may need verification`);
      result.confidence = 'medium';
    }

    // 4. Summary detection
    const summaryScore = this.calculateSummaryScore(comment);
    result.scores.summary = summaryScore;

    if (summaryScore > 0.5) {
      result.errors.push(`High summary score (${summaryScore.toFixed(2)}) - appears to be report text, not executive quote`);
      result.isValid = false;
    } else if (summaryScore > 0.3) {
      result.warnings.push(`Some summary indicators detected (${summaryScore.toFixed(2)})`);
      result.confidence = result.confidence === 'medium' ? 'low' : 'medium';
    }

    // 5. Length check
    if (comment.length > 800) {
      result.warnings.push('Quote unusually long - verify it is a single quote');
    }

    // 6. Multiple industries check
    if (this.summaryIndicators.multipleIndustries.test(comment)) {
      result.errors.push('Contains multiple industry attributions - this is a summary');
      result.isValid = false;
    }

    // Set final confidence
    if (!result.isValid) {
      result.confidence = 'invalid';
    }

    return result;
  }

  // ============================================
  // SCORING METHODS
  // ============================================

  calculateRealQuoteScore(text) {
    let score = 0;
    let maxScore = 0;

    const checks = [
      { pattern: this.realQuoteIndicators.firstPersonPlural, weight: 3 },
      { pattern: this.realQuoteIndicators.firstPersonSingular, weight: 2 },
      { pattern: this.realQuoteIndicators.operationalTerms, weight: 2 },
      { pattern: this.realQuoteIndicators.businessActions, weight: 1 },
      { pattern: this.realQuoteIndicators.timeReferences, weight: 1 },
    ];

    for (const check of checks) {
      maxScore += check.weight;
      const matches = text.match(check.pattern);
if (matches && matches.length > 0) {
        // If ANY match found, give FULL weight for that category
        score += check.weight;
      }
    }

    return maxScore > 0 ? score / maxScore : 0;
  }

  calculateSummaryScore(text) {
    let score = 0;
    const maxScore = Object.keys(this.summaryIndicators).length;

    for (const [name, pattern] of Object.entries(this.summaryIndicators)) {
      pattern.lastIndex = 0; // Reset regex
      if (pattern.test(text)) {
        score += 1;
      }
    }

    return maxScore > 0 ? score / maxScore : 0;
  }

  // ============================================
  // INDUSTRY NORMALIZATION
  // ============================================

  normalizeIndustry(industry) {
    if (!industry) return null;

    const lower = industry.toLowerCase().trim();
    
    // Exact match
    if (this.validIndustries.has(lower)) {
      return this.validIndustries.get(lower);
    }

    // Partial match - check if any key is contained
    for (const [key, value] of this.validIndustries) {
      if (lower.includes(key) || key.includes(lower.split(',')[0].trim())) {
        return value;
      }
    }

    // Check first word match
    const firstWord = lower.split(/[\s,&]/)[0].trim();
    if (firstWord.length >= 4) {
      for (const [key, value] of this.validIndustries) {
        if (key.startsWith(firstWord)) {
          return value;
        }
      }
    }

    return null;
  }

  // ============================================
  // BATCH VALIDATION
  // ============================================

  validateAllQuotes(quotes) {
    const results = {
      valid: [],
      invalid: [],
      summary: {
        total: quotes.length,
        passed: 0,
        failed: 0,
        warnings: 0,
        byConfidence: { high: 0, medium: 0, low: 0 },
        byError: {},
      },
    };

    for (const quote of quotes) {
      const validation = this.validateQuote(quote);

      if (validation.isValid) {
        results.valid.push({
          ...quote,
          industry: validation.normalizedIndustry || quote.industry,
          validation: {
            confidence: validation.confidence,
            scores: validation.scores,
            warnings: validation.warnings,
          },
        });
        
        results.summary.passed++;
        results.summary.byConfidence[validation.confidence]++;
        
        if (validation.warnings.length > 0) {
          results.summary.warnings++;
        }
      } else {
        results.invalid.push({
          quote: quote.comment?.substring(0, 100) + '...',
          industry: quote.industry,
          errors: validation.errors,
          scores: validation.scores,
        });
        
        results.summary.failed++;
        
        // Track error types
        for (const error of validation.errors) {
          const errorType = error.split(' ')[0];
          results.summary.byError[errorType] = (results.summary.byError[errorType] || 0) + 1;
        }
      }
    }

    // Log summary
    console.log(`[QuoteValidator] Validation complete:`);
    console.log(`  - Total: ${results.summary.total}`);
    console.log(`  - Passed: ${results.summary.passed} (${Math.round(results.summary.passed/results.summary.total*100)}%)`);
    console.log(`  - Failed: ${results.summary.failed}`);
    console.log(`  - With warnings: ${results.summary.warnings}`);
    console.log(`  - Confidence: High=${results.summary.byConfidence.high}, Medium=${results.summary.byConfidence.medium}, Low=${results.summary.byConfidence.low}`);

    return results;
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  /**
   * Quick check if a quote looks valid (for filtering)
   */
  quickCheck(quote) {
    const comment = quote.comment || quote.text || '';
    
    // Must have some first-person language
    if (!this.realQuoteIndicators.firstPersonPlural.test(comment) &&
        !this.realQuoteIndicators.firstPersonSingular.test(comment)) {
      return false;
    }
    
    // Must not have obvious summary language
    if (this.summaryIndicators.reportLanguage.test(comment)) {
      return false;
    }
    
    return true;
  }

  /**
   * Filter quotes to only keep high-confidence ones
   */
  filterHighConfidence(quotes) {
    return quotes.filter(quote => {
      const validation = this.validateQuote(quote);
      return validation.isValid && validation.confidence === 'high';
    });
  }

  /**
   * Get detailed analysis of a single quote
   */
  analyzeQuote(quote) {
    const comment = quote.comment || quote.text || '';
    
    return {
      validation: this.validateQuote(quote),
      indicators: {
        firstPersonPlural: (comment.match(this.realQuoteIndicators.firstPersonPlural) || []).length,
        firstPersonSingular: (comment.match(this.realQuoteIndicators.firstPersonSingular) || []).length,
        operationalTerms: (comment.match(this.realQuoteIndicators.operationalTerms) || []).length,
        businessActions: (comment.match(this.realQuoteIndicators.businessActions) || []).length,
        timeReferences: (comment.match(this.realQuoteIndicators.timeReferences) || []).length,
      },
      summaryIndicators: {
        reportLanguage: this.summaryIndicators.reportLanguage.test(comment),
        thirdPerson: this.summaryIndicators.thirdPerson.test(comment),
        statisticalLanguage: this.summaryIndicators.statisticalLanguage.test(comment),
        ismBranding: this.summaryIndicators.ismBranding.test(comment),
        multipleIndustries: this.summaryIndicators.multipleIndustries.test(comment),
      },
    };
  }
}

// ============================================
// STANDALONE VALIDATION FUNCTION
// ============================================

function validateQuotes(quotes) {
  const validator = new QuoteValidator();
  return validator.validateAllQuotes(quotes);
}

function isRealQuote(quote) {
  const validator = new QuoteValidator();
  return validator.quickCheck(quote);
}

export {
  QuoteValidator,
  validateQuotes,
  isRealQuote,
};