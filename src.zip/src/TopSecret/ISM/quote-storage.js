// =====================================================
// ISM QUOTE STORAGE SERVICE v1.0
// =====================================================
// Location: src/TopSecret/ISM/quote-storage.js
//
// Stores and retrieves ISM respondent quotes from database
// Maps ISM industries to stock market sectors
// =====================================================

import { createClient } from '@supabase/supabase-js';

// ============================================
// INDUSTRY TO SECTOR MAPPING
// ============================================
// Maps ISM Manufacturing industries to stock market sectors

const INDUSTRY_TO_SECTOR_MAP = {
  // Technology / Electronics
  'Computer & Electronic Products': 'Technology',
  'Computer and Electronic Products': 'Technology',
  'Electrical Equipment, Appliances & Components': 'Technology',
  'Electrical Equipment': 'Technology',
  
  // Industrials / Machinery
  'Machinery': 'Industrials',
  'Fabricated Metal Products': 'Industrials',
  'Transportation Equipment': 'Industrials',
  'Primary Metals': 'Materials',
  
  // Materials / Chemicals
  'Chemical Products': 'Materials',
  'Plastics & Rubber Products': 'Materials',
  'Plastics and Rubber Products': 'Materials',
  'Nonmetallic Mineral Products': 'Materials',
  'Wood Products': 'Materials',
  'Paper Products': 'Materials',
  
  // Consumer Staples
  'Food, Beverage & Tobacco Products': 'Consumer Staples',
  'Food Beverage & Tobacco': 'Consumer Staples',
  
  // Consumer Discretionary
  'Furniture & Related Products': 'Consumer Discretionary',
  'Furniture': 'Consumer Discretionary',
  'Apparel, Leather & Allied Products': 'Consumer Discretionary',
  'Apparel': 'Consumer Discretionary',
  'Textile Mills': 'Consumer Discretionary',
  'Miscellaneous Manufacturing': 'Consumer Discretionary',
  
  // Energy
  'Petroleum & Coal Products': 'Energy',
  
  // Other
  'Printing & Related Support Activities': 'Industrials',
  'Printing': 'Industrials',
};

// Reverse mapping: Sector -> Industries
const SECTOR_TO_INDUSTRIES = {
  'Technology': [
    'Computer & Electronic Products',
    'Computer and Electronic Products',
    'Electrical Equipment, Appliances & Components',
    'Electrical Equipment',
  ],
  'Industrials': [
    'Machinery',
    'Fabricated Metal Products',
    'Transportation Equipment',
    'Printing & Related Support Activities',
    'Printing',
  ],
  'Materials': [
    'Chemical Products',
    'Plastics & Rubber Products',
    'Plastics and Rubber Products',
    'Primary Metals',
    'Nonmetallic Mineral Products',
    'Wood Products',
    'Paper Products',
  ],
  'Consumer Staples': [
    'Food, Beverage & Tobacco Products',
    'Food Beverage & Tobacco',
  ],
  'Consumer Discretionary': [
    'Furniture & Related Products',
    'Furniture',
    'Apparel, Leather & Allied Products',
    'Apparel',
    'Textile Mills',
    'Miscellaneous Manufacturing',
  ],
  'Energy': [
    'Petroleum & Coal Products',
  ],
  'Healthcare': [],
  'Financials': [],
  'Utilities': [],
  'Real Estate': [],
  'Communication Services': [],
};

// ============================================
// ISM QUOTE STORAGE CLASS
// ============================================

class ISMQuoteStorage {
  constructor(supabaseUrl, supabaseKey) {
    this.supabase = null;
    
    if (supabaseUrl && supabaseKey) {
      try {
        this.supabase = createClient(supabaseUrl, supabaseKey);
        console.log('[QuoteStorage] Initialized with Supabase');
      } catch (error) {
        console.warn('[QuoteStorage] Failed to initialize Supabase:', error.message);
      }
    } else {
      console.warn('[QuoteStorage] No Supabase credentials provided - running in offline mode');
    }
  }

  // ============================================
  // SAVE QUOTES
  // ============================================

  async saveQuotes(reportId, reportMonth, quotes) {
    if (!this.supabase || !quotes || quotes.length === 0) {
      return { success: false, error: 'No supabase or quotes' };
    }

    console.log(`[QuoteStorage] Saving ${quotes.length} quotes for ${reportMonth}`);

    try {
      const quoteRecords = quotes.map((quote, index) => ({
        report_id: reportId,
        report_month: reportMonth,
        industry: quote.industry || 'Unknown',
        sector: this.mapIndustryToSector(quote.industry),
        comment: quote.comment || quote.quote || quote.text || '',
        sentiment: quote.sentiment || 'neutral',
        key_theme: quote.keyTheme || null,
        is_verified: quote.isVerified !== false,
        source: quote.source || 'ISM Report',
        display_order: index + 1,
      }));

      const { data, error } = await this.supabase
        .from('ism_quotes')
        .upsert(quoteRecords, { onConflict: 'report_id,industry,display_order' })
        .select();

      if (error) {
        console.error('[QuoteStorage] Error saving quotes:', error);
        return { success: false, error: error.message };
      }

      console.log(`[QuoteStorage] Saved ${data?.length || 0} quotes`);
      return { success: true, count: data?.length || 0 };

    } catch (error) {
      console.error('[QuoteStorage] Exception:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // SAVE SECTOR RANKINGS WITH QUOTE SUPPORT
  // ============================================

  async saveSectorRankings(reportId, reportMonth, sectors) {
    if (!this.supabase || !sectors || sectors.length === 0) {
      return { success: false, error: 'No supabase or sectors' };
    }

    console.log(`[QuoteStorage] Saving ${sectors.length} sector rankings for ${reportMonth}`);

    try {
      const sectorRecords = sectors.map(sector => ({
        report_id: reportId,
        report_month: reportMonth,
        sector_name: sector.sector || sector.name,
        sector_etf: sector.etf || null,
        rank: sector.rank || 0,
        impact_score: parseFloat(sector.impactScore) || 5.0,
        direction: sector.direction || 'neutral',
        reasoning: sector.reasoning || null,
        quote_support: sector.quoteSupport || null,
        quote_support_industry: sector.quoteSupportIndustry || null,
        change_vs_last_month: sector.changeVsLastMonth || null,
        why_now: sector.whyNow || null,
        key_stocks: sector.keyStocks || [],
      }));

      const { data, error } = await this.supabase
        .from('ism_sector_rankings')
        .upsert(sectorRecords, { onConflict: 'report_id,sector_name' })
        .select();

      if (error) {
        console.error('[QuoteStorage] Error saving sector rankings:', error);
        return { success: false, error: error.message };
      }

      console.log(`[QuoteStorage] Saved ${data?.length || 0} sector rankings`);
      return { success: true, count: data?.length || 0 };

    } catch (error) {
      console.error('[QuoteStorage] Exception:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // SAVE TRADE IDEAS WITH EXECUTIVE QUOTES
  // ============================================

  async saveTradeIdeas(reportId, reportMonth, ideas) {
    if (!this.supabase || !ideas || ideas.length === 0) {
      return { success: false, error: 'No supabase or ideas' };
    }

    console.log(`[QuoteStorage] Saving ${ideas.length} trade ideas for ${reportMonth}`);

    try {
      const ideaRecords = ideas.map((idea, index) => ({
        report_id: reportId,
        report_month: reportMonth,
        direction: idea.direction || 'long',
        sector: idea.sector || null,
        title: idea.title || '',
        etf: idea.ticker || idea.etf || null,
        stocks: idea.alternativeStocks || idea.stocks || [],
        thesis: idea.thesis?.ismConnection || idea.thesis || null,
        executive_quote: idea.executiveQuote || null,
        executive_quote_industry: idea.executiveQuoteIndustry || null,
        direct_impact: idea.directImpact || null,
        conviction: idea.conviction || idea.confidence || 'medium',
        invalidation: idea.invalidation || [],
        risks: idea.risks || [],
        display_order: index + 1,
      }));

      const { data, error } = await this.supabase
        .from('ism_trade_ideas')
        .upsert(ideaRecords, { onConflict: 'report_id,title' })
        .select();

      if (error) {
        console.error('[QuoteStorage] Error saving trade ideas:', error);
        return { success: false, error: error.message };
      }

      console.log(`[QuoteStorage] Saved ${data?.length || 0} trade ideas`);
      return { success: true, count: data?.length || 0 };

    } catch (error) {
      console.error('[QuoteStorage] Exception:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // GET DATA FOR PDF GENERATION
  // ============================================

  async getDataForPDFGeneration(month) {
    if (!this.supabase) {
      console.warn('[QuoteStorage] No Supabase - returning empty data');
      return {
        quotes: [],
        sectorRankings: [],
        tradeIdeas: [],
        meta: { quoteCount: 0, sectorCount: 0, tradeIdeaCount: 0 },
      };
    }

    console.log(`[QuoteStorage] Loading data for PDF generation: ${month}`);

    try {
      // Fetch quotes
      const { data: quotes, error: quotesError } = await this.supabase
        .from('ism_quotes')
        .select('*')
        .eq('report_month', month)
        .order('display_order', { ascending: true });

      if (quotesError) {
        console.warn('[QuoteStorage] Error fetching quotes:', quotesError.message);
      }

      // Fetch sector rankings
      const { data: sectorRankings, error: sectorsError } = await this.supabase
        .from('ism_sector_rankings')
        .select('*')
        .eq('report_month', month)
        .order('rank', { ascending: true });

      if (sectorsError) {
        console.warn('[QuoteStorage] Error fetching sectors:', sectorsError.message);
      }

      // Fetch trade ideas
      const { data: tradeIdeas, error: ideasError } = await this.supabase
        .from('ism_trade_ideas')
        .select('*')
        .eq('report_month', month)
        .order('display_order', { ascending: true });

      if (ideasError) {
        console.warn('[QuoteStorage] Error fetching trade ideas:', ideasError.message);
      }

      const result = {
        quotes: quotes || [],
        sectorRankings: sectorRankings || [],
        tradeIdeas: tradeIdeas || [],
        meta: {
          quoteCount: quotes?.length || 0,
          sectorCount: sectorRankings?.length || 0,
          tradeIdeaCount: tradeIdeas?.length || 0,
        },
      };

      console.log(`[QuoteStorage] Loaded: ${result.meta.quoteCount} quotes, ${result.meta.sectorCount} sectors, ${result.meta.tradeIdeaCount} trades`);

      return result;

    } catch (error) {
      console.error('[QuoteStorage] Exception in getDataForPDFGeneration:', error);
      return {
        quotes: [],
        sectorRankings: [],
        tradeIdeas: [],
        meta: { quoteCount: 0, sectorCount: 0, tradeIdeaCount: 0 },
      };
    }
  }

  // ============================================
  // GET QUOTES FOR MONTH
  // ============================================

  async getQuotesForMonth(month) {
    if (!this.supabase) return [];

    const { data, error } = await this.supabase
      .from('ism_quotes')
      .select('*')
      .eq('report_month', month)
      .order('display_order', { ascending: true });

    if (error) {
      console.error('[QuoteStorage] Error fetching quotes:', error);
      return [];
    }

    return data || [];
  }

  // ============================================
  // GET QUOTES BY SECTOR
  // ============================================

  async getQuotesBySector(month, sector) {
    if (!this.supabase) return [];

    const industries = SECTOR_TO_INDUSTRIES[sector] || [];
    
    if (industries.length === 0) {
      return [];
    }

    const { data, error } = await this.supabase
      .from('ism_quotes')
      .select('*')
      .eq('report_month', month)
      .in('industry', industries)
      .order('display_order', { ascending: true });

    if (error) {
      console.error('[QuoteStorage] Error fetching quotes by sector:', error);
      return [];
    }

    return data || [];
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  mapIndustryToSector(industry) {
    if (!industry) return 'Other';
    return INDUSTRY_TO_SECTOR_MAP[industry] || 'Other';
  }

  getSectorIndustries(sector) {
    return SECTOR_TO_INDUSTRIES[sector] || [];
  }

  // ============================================
  // CLEANUP OLD DATA
  // ============================================

  async cleanupOldData(monthsToKeep = 12) {
    if (!this.supabase) return { success: false, error: 'No supabase' };

    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - monthsToKeep);
    const cutoffMonth = `${cutoffDate.getFullYear()}-${String(cutoffDate.getMonth() + 1).padStart(2, '0')}`;

    console.log(`[QuoteStorage] Cleaning up data older than ${cutoffMonth}`);

    try {
      // Delete old quotes
      await this.supabase
        .from('ism_quotes')
        .delete()
        .lt('report_month', cutoffMonth);

      // Delete old sector rankings
      await this.supabase
        .from('ism_sector_rankings')
        .delete()
        .lt('report_month', cutoffMonth);

      // Delete old trade ideas
      await this.supabase
        .from('ism_trade_ideas')
        .delete()
        .lt('report_month', cutoffMonth);

      console.log(`[QuoteStorage] Cleanup complete`);
      return { success: true };

    } catch (error) {
      console.error('[QuoteStorage] Cleanup error:', error);
      return { success: false, error: error.message };
    }
  }
}

// ============================================
// STANDALONE FUNCTIONS
// ============================================

function mapIndustryToSector(industry) {
  if (!industry) return 'Other';
  return INDUSTRY_TO_SECTOR_MAP[industry] || 'Other';
}

function getSectorIndustries(sector) {
  return SECTOR_TO_INDUSTRIES[sector] || [];
}

// ============================================
// EXPORTS
// ============================================

export {
  ISMQuoteStorage,
  INDUSTRY_TO_SECTOR_MAP,
  SECTOR_TO_INDUSTRIES,
  mapIndustryToSector,
  getSectorIndustries,
};