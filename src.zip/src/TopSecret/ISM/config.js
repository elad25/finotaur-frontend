// =====================================================
// ISM REPORT CONFIGURATION v8.0 - ES MODULE
// =====================================================
// Location: src/TopSecret/ISM/config.js
// 
// CHANGES from v7.0:
// - PAGE 3: Sector-Level Impact (Who Feels It First)
//   - 3.1 Sector Mapping: Beneficiaries / At Risk / Neutral
//   - 3.2 Industry-Level Focus (who feels it first/last)
// - PAGE 4: Voices from the Field (Executive Commentary)
//   - 4.1 Key Executive Quotes (selective)
//   - 4.2 Analyst Interpretation (what they say vs don't say)
// - PAGE 5: Sector in Focus (The Funnel Tip)
//   - 5.1 Chosen Sector (ONE only) with ISM/cycle/asymmetry
//   - 5.2 Selected Companies (2-4 tickers) thinking scenarios
// 
// STRUCTURE:
// - PAGE 0: Analyst Context & Why This Report Matters (½ page)
// - PAGE 1: ISM Macro Snapshot (The Big Picture)
// - PAGE 2: Under-the-Surface Signals
// - PAGE 3: Sector-Level Impact
// - PAGE 4: Voices from the Field
// - PAGE 5: Sector in Focus
// - PAGE 6-7: Positioning & Watchlist
// =====================================================

// Workflow Phases - UPDATED for new structure
export const PHASES = {
  DATA_ACQUISITION: 'DATA_ACQUISITION',
  ANALYST_CONTEXT: 'ANALYST_CONTEXT',
  MACRO_ANALYSIS: 'MACRO_ANALYSIS',
  SUBSURFACE_ANALYSIS: 'SUBSURFACE_ANALYSIS',
  SECTOR_ANALYSIS: 'SECTOR_ANALYSIS',
  VOICE_ANALYSIS: 'VOICE_ANALYSIS',
  FOCUS_SECTOR: 'FOCUS_SECTOR',
  GLOBAL_OVERLAY: 'GLOBAL_OVERLAY',
  SYNTHESIS: 'SYNTHESIS',
  QUALITY_ASSURANCE: 'QUALITY_ASSURANCE',
};

export const PHASE_ORDER = [
  PHASES.DATA_ACQUISITION,
  PHASES.ANALYST_CONTEXT,
  PHASES.MACRO_ANALYSIS,
  PHASES.SUBSURFACE_ANALYSIS,
  PHASES.SECTOR_ANALYSIS,
  PHASES.VOICE_ANALYSIS,
  PHASES.FOCUS_SECTOR,
  PHASES.GLOBAL_OVERLAY,
  PHASES.SYNTHESIS,
  PHASES.QUALITY_ASSURANCE,
];

export const PHASE_LABELS = {
  [PHASES.DATA_ACQUISITION]: 'Data Acquisition',
  [PHASES.ANALYST_CONTEXT]: 'Analyst Context',
  [PHASES.MACRO_ANALYSIS]: 'Macro Analysis',
  [PHASES.SUBSURFACE_ANALYSIS]: 'Under-the-Surface Analysis',
  [PHASES.SECTOR_ANALYSIS]: 'Sector Impact Analysis',
  [PHASES.VOICE_ANALYSIS]: 'Industry Voices',
  [PHASES.FOCUS_SECTOR]: 'Sector Focus',
  [PHASES.GLOBAL_OVERLAY]: 'Global Overlay',
  [PHASES.SYNTHESIS]: 'Synthesis & Takeaways',
  [PHASES.QUALITY_ASSURANCE]: 'Quality Assurance',
};

// Macro Regimes - UPDATED with cleaner labels
export const MACRO_REGIMES = {
  EXPANSION: 'expansion',
  SLOWDOWN: 'slowdown',
  TRANSITION: 'transition',
  CONTRACTION: 'contraction',
  EXPANSION_ACCELERATING: 'expansion_accelerating',
  EXPANSION_DECELERATING: 'expansion_decelerating',
  CONTRACTION_RECOVERING: 'contraction_recovering',
  CONTRACTION_DEEPENING: 'contraction_deepening',
  LATE_CYCLE_WEAKNESS: 'late_cycle_weakness',
  STAGFLATION_RISK: 'stagflation_risk',
  EARLY_CYCLE_RECOVERY: 'early_cycle_recovery',
  GOLDILOCKS: 'goldilocks',
};

export const REGIME_LABELS = {
  [MACRO_REGIMES.EXPANSION]: 'Expansion',
  [MACRO_REGIMES.SLOWDOWN]: 'Slowdown',
  [MACRO_REGIMES.TRANSITION]: 'Transition',
  [MACRO_REGIMES.CONTRACTION]: 'Contraction',
  [MACRO_REGIMES.EXPANSION_ACCELERATING]: 'Expansion Accelerating',
  [MACRO_REGIMES.EXPANSION_DECELERATING]: 'Expansion Decelerating',
  [MACRO_REGIMES.CONTRACTION_RECOVERING]: 'Contraction - Early Recovery Signs',
  [MACRO_REGIMES.CONTRACTION_DEEPENING]: 'Contraction Deepening',
  [MACRO_REGIMES.LATE_CYCLE_WEAKNESS]: 'Late Cycle Manufacturing Weakness',
  [MACRO_REGIMES.STAGFLATION_RISK]: 'Stagflation Risk',
  [MACRO_REGIMES.EARLY_CYCLE_RECOVERY]: 'Early Cycle Recovery',
  [MACRO_REGIMES.GOLDILOCKS]: 'Goldilocks - Balanced Growth',
};

export const REGIME_DESCRIPTIONS = {
  [MACRO_REGIMES.EXPANSION]: 'Manufacturing expanding. New Orders and Production above 50.',
  [MACRO_REGIMES.SLOWDOWN]: 'Manufacturing still growing but losing momentum. Watch for rollover.',
  [MACRO_REGIMES.TRANSITION]: 'Critical inflection point. PMI near 50 with conflicting signals.',
  [MACRO_REGIMES.CONTRACTION]: 'Manufacturing contracting. PMI below 50.',
  [MACRO_REGIMES.EXPANSION_ACCELERATING]: 'Manufacturing expanding with improving momentum. New Orders leading PMI higher.',
  [MACRO_REGIMES.EXPANSION_DECELERATING]: 'Manufacturing still expanding but losing momentum. Watch for rollover.',
  [MACRO_REGIMES.CONTRACTION_RECOVERING]: 'Manufacturing contracting but showing early stabilization signs.',
  [MACRO_REGIMES.CONTRACTION_DEEPENING]: 'Manufacturing contraction intensifying. Employment and orders weakening.',
  [MACRO_REGIMES.LATE_CYCLE_WEAKNESS]: 'Late cycle dynamics with mixed signals. PMI near 50 threshold.',
  [MACRO_REGIMES.STAGFLATION_RISK]: 'Dangerous combination: contracting activity with elevated prices. Worst margin environment.',
  [MACRO_REGIMES.EARLY_CYCLE_RECOVERY]: 'Fresh expansion after contraction period. New Orders leading recovery.',
  [MACRO_REGIMES.GOLDILOCKS]: 'Optimal conditions: moderate growth, controlled inflation, stable employment.',
};

// Confidence Levels for Regime Assessment
export const CONFIDENCE_LEVELS = {
  HIGH: 'High',
  MEDIUM: 'Medium',
  LOW: 'Low',
};

// Key Sectors for Analysis - EXPANDED
export const KEY_SECTORS = {
  TECHNOLOGY: {
    id: 'technology',
    name: 'Computer & Electronic Products',
    shortName: 'Technology',
    etf: 'XLK',
    characteristics: ['CapEx sensitive', 'Data center demand', 'AI exposure'],
    ismDrivers: ['newOrders', 'production'],
    keyStocks: ['NVDA', 'MSFT', 'AAPL', 'AMD', 'AVGO'],
    ismSensitivity: 'medium',
  },
  CONSUMER_STAPLES: {
    id: 'consumer_staples',
    name: 'Food, Beverage & Tobacco Products',
    shortName: 'Consumer Staples',
    etf: 'XLP',
    characteristics: ['Defensive', 'Stable demand', 'Pricing power'],
    ismDrivers: ['prices', 'customersInventories'],
    keyStocks: ['PG', 'KO', 'PEP', 'COST', 'WMT'],
    ismSensitivity: 'low',
  },
  MACHINERY: {
    id: 'machinery',
    name: 'Machinery',
    shortName: 'Industrials/Machinery',
    etf: 'XLI',
    characteristics: ['CapEx dependent', 'Backlog driven', 'Cyclical'],
    ismDrivers: ['backlog', 'newOrders', 'employment'],
    keyStocks: ['CAT', 'DE', 'HON', 'EMR', 'ROK'],
    ismSensitivity: 'high',
  },
  TRANSPORTATION: {
    id: 'transportation',
    name: 'Transportation Equipment',
    shortName: 'Transportation',
    etf: 'IYT',
    characteristics: ['Highly cyclical', 'Labor intensive', 'Supply chain dependent'],
    ismDrivers: ['employment', 'supplierDeliveries', 'production'],
    keyStocks: ['UNP', 'FDX', 'DAL', 'UPS', 'CSX'],
    ismSensitivity: 'high',
  },
  MATERIALS: {
    id: 'materials',
    name: 'Basic Materials',
    shortName: 'Materials',
    etf: 'XLB',
    characteristics: ['Commodity exposure', 'Infrastructure play', 'Cyclical'],
    ismDrivers: ['prices', 'newOrders', 'customersInventories'],
    keyStocks: ['LIN', 'APD', 'FCX', 'NEM', 'DOW'],
    ismSensitivity: 'high',
  },
  HEALTHCARE: {
    id: 'healthcare',
    name: 'Healthcare & Pharma',
    shortName: 'Healthcare',
    etf: 'XLV',
    characteristics: ['Defensive', 'Demographics', 'Innovation'],
    ismDrivers: ['employment'],
    keyStocks: ['UNH', 'JNJ', 'LLY', 'PFE', 'ABBV'],
    ismSensitivity: 'low',
  },
  ENERGY: {
    id: 'energy',
    name: 'Petroleum & Coal Products',
    shortName: 'Energy',
    etf: 'XLE',
    characteristics: ['Commodity linked', 'CapEx intensive', 'Cyclical'],
    ismDrivers: ['prices', 'newOrders'],
    keyStocks: ['XOM', 'CVX', 'COP', 'SLB', 'EOG'],
    ismSensitivity: 'medium',
  },
  FINANCIALS: {
    id: 'financials',
    name: 'Financial Services',
    shortName: 'Financials',
    etf: 'XLF',
    characteristics: ['Rate sensitive', 'Economic proxy', 'Credit cycle'],
    ismDrivers: ['pmi', 'newOrders'],
    keyStocks: ['JPM', 'BAC', 'WFC', 'GS', 'MS'],
    ismSensitivity: 'medium',
  },
};

// =====================================================
// REPORT SECTIONS - v7.0 STRUCTURE
// ISM Monthly Macro & Sector Intelligence Report
// Frequency: Monthly
// Audience: Investors, traders, analysts (not beginners)
// Tone: Human, sharp, analytical - not academic or marketing
// Goal: Understand what changed, why it matters, and where money will be affected
// =====================================================

export const REPORT_SECTIONS = {
  // =====================================================
  // PAGE 0 — Analyst Context & Why This Report Matters (½ page)
  // =====================================================
  // Purpose: Get the reader into macro analyst mindset
  PAGE_0_ANALYST_CONTEXT: {
    id: 'analystContext',
    page: 0,
    title: 'Analyst Context & Why This Report Matters',
    pageAllocation: 0.5,
    required: true,
    structure: {
      // Personal opening paragraph
      OPENING: {
        id: 'opening',
        description: 'Personal opening paragraph',
        questions: [
          'Why is this month\'s report different from last month?',
          'Are we at an inflection point, escalation, or continuation?',
        ],
      },
      // Key statement - MUST appear
      KEY_STATEMENT: {
        id: 'keyStatement',
        text: 'This report is not about what ISM printed — it is about what changed underneath.',
        required: true,
      },
      // Brief ISM reminder (2-3 lines only)
      ISM_REMINDER: {
        id: 'ismReminder',
        description: 'Brief reminder (2-3 lines)',
        mustInclude: [
          'What ISM measures',
          'Why it is a Leading Indicator (not news in hindsight)',
        ],
      },
    },
    tone: 'Human, sharp, analytical - not academic or marketing',
  },

  // =====================================================
  // PAGE 1 — ISM Macro Snapshot (The Big Picture)
  // =====================================================
  PAGE_1_MACRO_SNAPSHOT: {
    id: 'macroSnapshot',
    page: 1,
    title: 'ISM Macro Snapshot',
    subtitle: 'The Big Picture',
    pageAllocation: 1.0,
    required: true,
    sections: {
      // 1.1 Headline Numbers (without flooding)
      HEADLINE_NUMBERS: {
        id: 'headlineNumbers',
        title: '1.1 Headline Numbers',
        format: 'concise',
        mustInclude: [
          'ISM Manufacturing / Services headline',
          'Change vs prior month',
          'One line per metric: what actually changed (not just restating the number)',
        ],
        warning: 'Do NOT flood with numbers. One line insight per metric.',
      },
      // 1.2 Macro Regime Assessment - MUST BE SHARP
      MACRO_REGIME: {
        id: 'macroRegime',
        title: '1.2 Macro Regime Assessment',
        format: 'fixed_structure',
        mustInclude: [
          'Macro Regime: Expansion / Slowdown / Transition / Contraction',
          'Confidence Level: Low / Medium / High',
          'What changed vs last month:',
          '  - Demand dynamics',
          '  - Pricing dynamics',
          '  - Employment dynamics',
          '  - Supply chain dynamics',
        ],
        warning: 'Be sharp. Don\'t say "the number dropped" - say "the dynamic between X and Y changed"',
      },
    },
  },

  // =====================================================
  // PAGE 2 — Under-the-Surface Signals (The part people pay for)
  // =====================================================
  PAGE_2_SUBSURFACE: {
    id: 'subsurfaceSignals',
    page: 2,
    title: 'Under-the-Surface Signals',
    subtitle: 'What The Data Really Shows',
    pageAllocation: 1.25,
    required: true,
    sections: {
      // 2.1 Internal ISM Tensions
      ISM_TENSIONS: {
        id: 'ismTensions',
        title: '2.1 Internal ISM Tensions',
        description: 'Connect the dots between components',
        tensions: [
          {
            name: 'New Orders vs Production',
            description: 'Demand vs current output gap',
          },
          {
            name: 'Prices vs Demand',
            description: 'Pricing power vs volume trade-off',
          },
          {
            name: 'Inventories vs Deliveries',
            description: 'Supply chain health and stocking behavior',
          },
        ],
        formatPerTension: {
          whatWereSeeing: 'Description of current state',
          whyThisTensionMatters: 'Business and market implications',
          whatTypicallyFollows: 'Historical pattern (no made-up numbers)',
        },
      },
      // 2.2 Trend Shift Detection
      TREND_DETECTION: {
        id: 'trendDetection',
        title: '2.2 Trend Shift Detection',
        description: 'Show you are not chasing returns - you are analyzing cyclicality',
        categories: [
          {
            id: 'weakening',
            name: 'Weakening Trends',
            description: 'Late-cycle behavior signals',
          },
          {
            id: 'emerging',
            name: 'Emerging Trends',
            description: 'Early formation signals',
          },
          {
            id: 'crumbling',
            name: 'Deceptive Trends',
            description: 'Trends that look strong but are crumbling inside',
          },
        ],
        purpose: 'Prove you are not mid-trend - you analyze cyclicality',
      },
    },
  },

  // =====================================================
  // PAGE 3-7 - PRESERVED FOR FUTURE UPDATES
  // =====================================================
  
  // PAGE 3 — Sector-Level Impact (Who Feels It First)
  PAGE_3_SECTOR_IMPACT: {
    id: 'sectorImpact',
    page: 3,
    title: 'Sector-Level Impact',
    subtitle: 'Who Feels It First',
    pageAllocation: 1.25,
    required: true,
    sections: {
      SECTOR_MAPPING: {
        id: 'sectorMapping',
        title: '3.1 Sector Mapping',
        mustInclude: [
          'Beneficiaries list with reasoning',
          'At Risk sectors with reasoning',
          'Neutral / Transitional sectors',
          'For each: What ISM tells us, Is this new or continuation, Why smart money is positioning',
        ],
      },
      INDUSTRY_FOCUS: {
        id: 'industryFocus',
        title: '3.2 Industry-Level Focus',
        mustInclude: [
          'Which industries within sectors feel it strongest',
          'Who gets hit first, who last',
          'Where is risk priced and where is it not',
        ],
      },
    },
  },

  // PAGE 4 — Voices from the Field (Executive Commentary)
  PAGE_4_VOICES: {
    id: 'voicesFromField',
    page: 4,
    title: 'Voices from the Field',
    subtitle: 'Executive Commentary',
    pageAllocation: 1.0,
    required: true,
    sections: {
      KEY_QUOTES: {
        id: 'keyQuotes',
        title: '4.1 Key Executive Quotes',
        mustInclude: [
          'Selective quotes from CEO / CFO / Purchasing Managers',
          'Not a quote collection - curated selection',
        ],
      },
      ANALYST_INTERPRETATION: {
        id: 'quoteInterpretation',
        title: '4.2 Analyst Interpretation',
        mustInclude: [
          'What they are saying in words',
          'What they are NOT saying',
          'How this connects to ISM',
          'Which sectors/industries this strengthens or weakens',
        ],
        note: 'This is where you prove you are not just "reading news"',
      },
    },
  },

  // PAGE 5 — Practical Focus: Sector in Focus (The Funnel Tip)
  PAGE_5_FOCUS_SECTOR: {
    id: 'focusSector',
    page: 5,
    title: 'Sector in Focus',
    subtitle: 'The Funnel Tip',
    pageAllocation: 1.0,
    required: true,
    sections: {
      CHOSEN_SECTOR: {
        id: 'chosenSector',
        title: '5.1 Chosen Sector',
        mustInclude: [
          'ONE sector only',
          'Why we chose it: Direct ISM connection, Clear cycle stage, Interesting asymmetry',
        ],
      },
      SELECTED_COMPANIES: {
        id: 'selectedCompanies',
        title: '5.2 Selected Companies',
        mustInclude: [
          '2-4 companies maximum',
          'For each: What they actually do (one sentence), How macro change affects them, Where is the leverage (operational/demand/pricing), Main thesis risk',
        ],
        warning: 'NOT a recommendation. A thinking scenario.',
      },
    },
  },

  // PAGE 6 — Global Macro Overlay (if relevant)
  PAGE_6_GLOBAL: {
    id: 'globalOverlay',
    page: 6,
    title: 'Global Macro Overlay',
    subtitle: 'International Implications',
    pageAllocation: 0.75,
    required: false,
    conditional: 'Include if current change has global implications',
    mustInclude: [
      'Which countries are sensitive to current change',
      'Possible impact on: Trade, Currency, Export industries',
      'Does this strengthen or weaken the sectoral thesis',
    ],
  },

  // PAGE 7 — Key Takeaways & What to Monitor Next Month
  PAGE_7_TAKEAWAYS: {
    id: 'keyTakeaways',
    page: 7,
    title: 'Key Takeaways & What to Monitor',
    subtitle: 'Analyst Conclusions',
    pageAllocation: 0.75,
    required: true,
    sections: {
      CONCLUSIONS: {
        id: 'conclusions',
        title: '7.1 Analyst Conclusions',
        mustInclude: [
          '3-5 sharp conclusions',
          'Each conclusion answers: So what?',
        ],
      },
      MONITORING: {
        id: 'monitoring',
        title: '7.2 What We Are Watching',
        mustInclude: [
          'Which ISM sub-indices matter for next month',
          'What would signal we were wrong',
          'What would signal the trend is strengthening',
        ],
      },
    },
  },
};

// Additional sections that may be included
export const ADDITIONAL_SECTIONS = {
  SIGNAL_HIERARCHY: {
    id: 'signalHierarchy',
    title: 'Signal Hierarchy',
    description: 'Not all signals are equal. How we weight this month\'s data.',
    required: false,
  },
  MISPRICING_CALL: {
    id: 'mispricingCall',
    title: 'The Edge',
    description: 'Where the market is wrong and how to exploit it.',
    required: false,
  },
  COUNTER_THESIS: {
    id: 'counterThesis',
    title: 'Alternative Interpretation',
    description: 'What if we are wrong?',
    required: false,
  },
};

// Calculate total pages
export const ESTIMATED_PAGES = Object.values(REPORT_SECTIONS)
  .reduce((sum, section) => sum + (section.pageAllocation || 0.5), 0);

// ISM Thresholds
export const ISM_THRESHOLDS = {
  PMI: {
    EXPANSION: 50,
    STRONG_EXPANSION: 55,
    RECESSION_SIGNAL: 42.3,
    CONTRACTION: 50,
    DEEP_CONTRACTION: 45,
  },
  PRICES: {
    INFLATION: 55,
    HIGH_INFLATION: 60,
    DISINFLATION: 50,
  },
  EMPLOYMENT: {
    GROWING: 50,
    STABLE: 48,
    WEAKNESS: 45,
    SEVERE_WEAKNESS: 42,
  },
  NEW_ORDERS: {
    GROWTH: 50,
    STRONG_GROWTH: 55,
    WEAKNESS: 48,
  },
  BACKLOG: {
    BUILDING: 50,
    DEPLETING: 48,
    CRITICAL: 44,
  },
};

// Report Quality Thresholds
export const QA_THRESHOLDS = {
  PASS: 70,
  GOOD: 80,
  EXCELLENT: 90,
};

// Default Invalidation Scenarios
export const DEFAULT_INVALIDATION_SCENARIOS = [
  'PMI crosses the 50 threshold and sustains for 2+ consecutive months',
  'New Orders rebounds above 52, signaling demand recovery',
  'Federal Reserve materially shifts policy stance',
  'Geopolitical shock affecting supply chains or energy prices',
  'Prices index normalizes below 52, changing margin narrative',
  'Employment stabilizes above 50, signaling business confidence',
];

// Default Next Month Indicators
export const DEFAULT_NEXT_MONTH_INDICATORS = [
  'New Orders direction - leading indicator of PMI',
  'Employment trajectory - confirms or denies weakness',
  'Prices trend - inflation persistence check',
  'Backlog stabilization - visibility metric',
  'Customer inventory normalization',
  'Regional Fed manufacturing surveys (Empire State, Philly Fed)',
  'ISM Services PMI - broader economy health check',
];

// Email Configuration
export const EMAIL_CONFIG = {
  FROM_NAME: 'Finotaur Research',
  FROM_EMAIL: 'reports@finotaur.com',
  SUBJECT_PREFIX: 'ISM Manufacturing Report',
  REPLY_TO: 'support@finotaur.com',
};

// Scheduler Configuration
export const SCHEDULER_CONFIG = {
  ISM_RELEASE_HOUR_EST: 10,
  ISM_RELEASE_MINUTE: 0,
  REPORT_DELAY_HOURS: 2,
  MAX_RETRIES: 3,
  RETRY_DELAY_MINUTES: 15,
};

// OpenAI Configuration
export const OPENAI_CONFIG = {
  DEFAULT_MODEL: 'gpt-4o',
  FALLBACK_MODEL: 'gpt-4o-mini',
  MAX_TOKENS: {
    ANALYST_CONTEXT: 1500,
    MACRO_SNAPSHOT: 2500,
    SUBSURFACE: 3000,
    SECTOR_IMPACT: 3000,
    VOICES: 2500,
    FOCUS_SECTOR: 2500,
    GLOBAL_OVERLAY: 2000,
    TAKEAWAYS: 1500,
    SUMMARY: 1000,
  },
  TEMPERATURE: {
    ANALYTICAL: 0.2,
    CREATIVE: 0.4,
    BALANCED: 0.3,
  },
};

// Cache Configuration
export const CACHE_CONFIG = {
  ISM_DATA_TTL_HOURS: 6,
  REPORT_TTL_HOURS: 24 * 7,
  HISTORICAL_DATA_TTL_HOURS: 24 * 30,
};

// PDF Configuration
export const PDF_CONFIG = {
  PAGE_SIZE: 'A4',
  MARGINS: { top: 50, bottom: 50, left: 50, right: 50 },
  FONTS: { HEADER: 'Helvetica-Bold', BODY: 'Helvetica', MONO: 'Courier' },
  COLORS: {
    PRIMARY: '#C9A646',
    BACKGROUND: '#FFFFFF',
    TEXT: '#1A1A1A',
    POSITIVE: '#16A34A',
    NEGATIVE: '#DC2626',
    NEUTRAL: '#888888',
    MUTED: '#555555',
  },
  LOGO_PATHS: [
    'public/logo-text.png',
    'public/logo.png',
    'static/logo-text.png',
    'static/logo.png',
    'assets/logo-text.png',
    'src/assets/logo-text.png',
    '/app/public/logo-text.png',
  ],
};

// =====================================================
// WRITING STYLE GUIDE - v7.0
// Core philosophy: Human, sharp, analytical
// NOT academic. NOT marketing.
// =====================================================

export const WRITING_STYLE = {
  VOICE: 'we',
  TONE: 'human_sharp_analytical',
  STRUCTURE: 'prose',
  NUMBERS: 'integrated',
  
  // Core philosophy
  PHILOSOPHY: [
    'Not academic, not marketing',
    'Focus on WHAT CHANGED, not what the number is',
    'Every insight must answer: So what?',
    'Be opinionated - clients pay for views, not summaries',
    'Show cyclicality analysis, not trend chasing',
    'Human tone - like a sharp analyst briefing a peer',
  ],
  
  // REQUIRED phrases - MUST appear in report
  PHRASES_MUST_USE: [
    'This matters because',
    'The risk here is not X, but Y',
    'If this persists into the next ISM, the implication is',
    'The question for positioning is',
    'What the market may be missing',
  ],
  
  // Phrases to use frequently
  PHRASES_TO_USE: [
    'The balance of evidence suggests',
    'We are watching X because',
    'What matters here is',
    'If this persists',
    'What would change our view is',
    'We favor X over Y because',
    'This is actionable because',
    'The dynamic between X and Y has shifted',
    'Not about what ISM printed — about what changed underneath',
  ],
  
  // BANNED phrases - NEVER use
  PHRASES_TO_AVOID: [
    'SITUATION:',
    'TREND:',
    'ACTION:',
    'might potentially',
    'could possibly',
    'Let me analyze',
    'TOP SECRET',
    'EXCLUSIVE',
    'Watch for',
    'may indicate',
    'could suggest',
    'the number dropped',
    'the index fell',
    'we saw',
    'data shows',
  ],
  
  // BANNED elements
  BANNED: [
    'Emojis of any kind',
    'Markdown tables (| |)',
    'Exclamation marks in analytical content',
    'First person singular (I think, I analyze)',
    'Entry/Stop/Target price levels',
    'Marketing-speak and hype',
    'Academic jargon without practical meaning',
  ],
};

// Stock Archetypes for Positioning
export const STOCK_ARCHETYPES = {
  QUALITY_DEFENSIVES: {
    description: 'High ROE, consistent margins, pricing power',
    examples: ['JNJ', 'PG', 'MSFT'],
    favored_when: 'PMI < 48 and Employment < 48',
  },
  CYCLICAL_LEADERS: {
    description: 'Operating leverage, tied to manufacturing',
    examples: ['CAT', 'DE', 'HON'],
    favored_when: 'PMI > 52 and New Orders accelerating',
  },
  RESTOCKING_BENEFICIARIES: {
    description: 'Materials tied to inventory rebuild',
    examples: ['LIN', 'FCX', 'DOW'],
    favored_when: 'Customer Inventories "too low" and New Orders > 50',
  },
  MARGIN_PROTECTED: {
    description: 'Pricing power in inflationary environment',
    examples: ['COST', 'WMT', 'KO'],
    favored_when: 'Prices > 55 and PMI < 50',
  },
  HIGH_OPERATING_LEVERAGE: {
    description: 'Fixed cost heavy, earnings volatile',
    examples: ['X', 'NUE', 'AA'],
    avoid_when: 'PMI < 48 or Employment deteriorating',
  },
};

// Validation function for report sections
export function validateReportSections(report) {
  const issues = [];
  
  // Check for required pages
  const requiredPages = Object.values(REPORT_SECTIONS).filter(s => s.required);
  
  for (const section of requiredPages) {
    const reportSection = report[section.id];
    
    if (!reportSection) {
      issues.push(`Missing required section: ${section.title} (Page ${section.page})`);
    }
  }
  
  return {
    valid: issues.length === 0,
    issues,
  };
}

// Version
export const VERSION = '7.0.0';
export const BUILD_DATE = '2025-01';