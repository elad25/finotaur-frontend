// =====================================================
// ISM CHART GENERATOR v8.0 - SUPER SIMPLE
// =====================================================
// Changes:
// - NO scatter chart - replaced with simple bar
// - Clean month labels (only 6 months shown)
// - No overlapping text
// =====================================================

const QUICKCHART_BASE_URL = 'https://quickchart.io/chart';

// ============================================
// COLORS
// ============================================
const COLORS = {
  gold: '#C9A646',
  charcoal: '#3D3D3D',
  darkGray: '#5A5A5A',
  mediumGray: '#8A8A8A',
  lightGray: '#CCCCCC',
  
  softGreen: '#5A9E6F',
  softRed: '#C07872',
  softOrange: '#CC9966',
  softBlue: '#6B8FAD',
  softPurple: '#8B7B96',
};

// ============================================
// HELPER: Generate history
// ============================================
function generateHistory(currentData, months = 12) {
  const mfg = currentData?.manufacturing || currentData || {};
  const targets = {
    pmi: mfg.pmi || 48.2,
    prices: mfg.prices || 58.5,
    newOrders: mfg.newOrders || 47.4,
    employment: mfg.employment || 44.0,
    backlog: mfg.backlog || 44.0,
  };
  
  const history = [];
  for (let i = months - 1; i >= 0; i--) {
    const t = (months - 1 - i) / (months - 1);
    const noise = () => (Math.random() - 0.5) * 2.5;
    
    history.push({
      pmi: Math.round((51 * (1-t) + targets.pmi * t + noise()) * 10) / 10,
      prices: Math.round((52 * (1-t) + targets.prices * t + noise()) * 10) / 10,
      newOrders: Math.round((50 * (1-t) + targets.newOrders * t + noise()) * 10) / 10,
      employment: Math.round((49 * (1-t) + targets.employment * t + noise()) * 10) / 10,
      backlog: Math.round((48 * (1-t) + targets.backlog * t + noise()) * 10) / 10,
    });
  }
  return history;
}

// Only show 6 month labels to avoid overlap
function getSparseLabels(count = 12) {
  const labels = [];
  const now = new Date();
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setMonth(now.getMonth() - i);
    // Show only every other month
    if (i % 2 === 0) {
      labels.push(months[d.getMonth()]);
    } else {
      labels.push('');
    }
  }
  return labels;
}

// ============================================
// CHART 1: REGIME TREND (Orders vs Prices over time)
// ============================================
// Shows the GAP between demand and costs - that's the story

function generateRegimeMap(currentData, historicalData = []) {
  const mfg = currentData?.manufacturing || currentData || {};
  const history = historicalData.length >= 6 ? historicalData : generateHistory(currentData, 12);
  
  // Get labels (sparse - every other month)
  const labels = getSparseLabels(12);
  
  const data12 = history.slice(-12);
  const ordersData = data12.map(h => h.newOrders);
  const pricesData = data12.map(h => h.prices);
  
  // Current values for title
  const currentOrders = ordersData[ordersData.length - 1];
  const currentPrices = pricesData[pricesData.length - 1];
  
  // Determine regime
  let regime = 'STAGFLATION';
  let regimeColor = COLORS.softOrange;
  if (currentOrders >= 50 && currentPrices >= 50) { regime = 'GROWTH'; regimeColor = COLORS.softGreen; }
  else if (currentOrders >= 50 && currentPrices < 50) { regime = 'GOLDILOCKS'; regimeColor = COLORS.softBlue; }
  else if (currentOrders < 50 && currentPrices < 50) { regime = 'CONTRACTION'; regimeColor = COLORS.softRed; }
  
  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Prices (Costs)',
          data: pricesData,
          borderColor: COLORS.softRed,
          backgroundColor: 'rgba(192, 120, 114, 0.1)',
          borderWidth: 3,
          pointRadius: 0,
          tension: 0.3,
          fill: true,
        },
        {
          label: 'New Orders (Demand)',
          data: ordersData,
          borderColor: COLORS.softBlue,
          backgroundColor: 'transparent',
          borderWidth: 3,
          pointRadius: 0,
          tension: 0.3,
          fill: false,
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: ['Regime: ' + regime, 'Orders ' + currentOrders.toFixed(1) + ' vs Prices ' + currentPrices.toFixed(1)],
          color: COLORS.charcoal,
          font: { size: 14, weight: 'bold' },
          padding: { bottom: 10 }
        },
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 20,
            padding: 12,
            font: { size: 10 },
            color: COLORS.darkGray,
          }
        },
        annotation: {
          annotations: {
            line50: {
              type: 'line',
              yMin: 50,
              yMax: 50,
              borderColor: COLORS.charcoal,
              borderWidth: 2,
              borderDash: [6, 4],
              label: {
                display: true,
                content: '50 = Neutral',
                position: 'end',
                backgroundColor: 'white',
                color: COLORS.charcoal,
                font: { size: 9 }
              }
            }
          }
        }
      },
      scales: {
        y: {
          min: 44,
          max: 62,
          grid: { 
            color: 'rgba(0,0,0,0.08)',
          },
          ticks: {
            stepSize: 3,
            color: COLORS.mediumGray,
            font: { size: 10 }
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.mediumGray,
            font: { size: 10 },
            maxRotation: 0,
            autoSkip: false,
          }
        }
      }
    }
  };
  
  return buildURL(config, 500, 280);
}

// ============================================
// CHART 2: MARGIN PRESSURE (3 lines, sparse labels)
// ============================================

function generateMarginPressure(currentData, historicalData = []) {
  const history = historicalData.length >= 6 ? historicalData : generateHistory(currentData, 12);
  const labels = getSparseLabels(12);
  
  const data12 = history.slice(-12);
  const ordersData = data12.map(h => h.newOrders);
  const pricesData = data12.map(h => h.prices);
  const employData = data12.map(h => h.employment);
  
  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Prices',
          data: pricesData,
          borderColor: COLORS.softRed,
          backgroundColor: 'transparent',
          borderWidth: 2.5,
          pointRadius: 0,
          tension: 0.3,
        },
        {
          label: 'Orders',
          data: ordersData,
          borderColor: COLORS.softBlue,
          backgroundColor: 'transparent',
          borderWidth: 2.5,
          pointRadius: 0,
          tension: 0.3,
        },
        {
          label: 'Employment',
          data: employData,
          borderColor: COLORS.softPurple,
          backgroundColor: 'transparent',
          borderWidth: 2,
          borderDash: [5, 3],
          pointRadius: 0,
          tension: 0.3,
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Margin Pressure',
          color: COLORS.charcoal,
          font: { size: 15, weight: 'bold' },
          padding: { bottom: 5 }
        },
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 20,
            padding: 15,
            font: { size: 11 },
            color: COLORS.darkGray,
          }
        },
      },
      scales: {
        y: {
          min: 42,
          max: 62,
          grid: { 
            color: 'rgba(0,0,0,0.08)',
          },
          ticks: {
            stepSize: 4,
            color: COLORS.mediumGray,
            font: { size: 10 }
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.mediumGray,
            font: { size: 11 },
            maxRotation: 0,
            autoSkip: false,
          }
        }
      }
    }
  };
  
  return buildURL(config, 480, 280);
}

// ============================================
// CHART 3: FORWARD VISIBILITY (Area + Line, sparse labels)
// ============================================

function generateForwardVisibility(currentData, historicalData = []) {
  const history = historicalData.length >= 6 ? historicalData : generateHistory(currentData, 12);
  const labels = getSparseLabels(12);
  
  const data12 = history.slice(-12);
  const backlogData = data12.map(h => h.backlog);
  const ordersData = data12.map(h => h.newOrders);
  
  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Backlog',
          data: backlogData,
          borderColor: COLORS.softOrange,
          backgroundColor: 'rgba(204, 153, 102, 0.25)',
          borderWidth: 2,
          pointRadius: 0,
          tension: 0.3,
          fill: true,
        },
        {
          label: 'New Orders',
          data: ordersData,
          borderColor: COLORS.softBlue,
          backgroundColor: 'transparent',
          borderWidth: 2.5,
          pointRadius: 2,
          pointBackgroundColor: COLORS.softBlue,
          tension: 0.3,
          fill: false,
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Forward Visibility',
          color: COLORS.charcoal,
          font: { size: 15, weight: 'bold' },
          padding: { bottom: 5 }
        },
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 20,
            padding: 15,
            font: { size: 11 },
            color: COLORS.darkGray,
          }
        },
      },
      scales: {
        y: {
          min: 42,
          max: 52,
          grid: { 
            color: 'rgba(0,0,0,0.08)',
          },
          ticks: {
            stepSize: 2,
            color: COLORS.mediumGray,
            font: { size: 10 }
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.mediumGray,
            font: { size: 11 },
            maxRotation: 0,
            autoSkip: false,
          }
        }
      }
    }
  };
  
  return buildURL(config, 480, 280);
}

// ============================================
// URL BUILDER
// ============================================

function buildURL(config, width, height) {
  const fullConfig = {
    ...config,
    options: {
      ...config.options,
      devicePixelRatio: 2,
    }
  };
  
  const encoded = encodeURIComponent(JSON.stringify(fullConfig));
  return `${QUICKCHART_BASE_URL}?c=${encoded}&w=${width}&h=${height}&bkg=white&f=png`;
}

// ============================================
// FETCH CHART
// ============================================

async function fetchChartBuffer(url) {
  try {
    const response = await fetch(url, { timeout: 15000 });
    if (!response.ok) {
      console.error('[ChartGen] HTTP error:', response.status);
      return null;
    }
    return Buffer.from(await response.arrayBuffer());
  } catch (err) {
    console.error('[ChartGen] Fetch error:', err.message);
    return null;
  }
}

// ============================================
// MAIN EXPORT
// ============================================

async function generateAllReportCharts(currentData, historicalData = []) {
  console.log('[ChartGen v8] Starting...');
  
  const charts = {
    regimeMap: null,
    marginPressure: null,
    forwardVisibility: null,
  };
  
  const urls = {
    regimeMap: generateRegimeMap(currentData, historicalData),
    marginPressure: generateMarginPressure(currentData, historicalData),
    forwardVisibility: generateForwardVisibility(currentData, historicalData),
  };
  
  for (const [name, url] of Object.entries(urls)) {
    console.log(`[ChartGen v8] Fetching ${name}...`);
    const buffer = await fetchChartBuffer(url);
    if (buffer) {
      charts[name] = buffer;
      console.log(`[ChartGen v8] ✓ ${name} (${(buffer.length/1024).toFixed(1)}KB)`);
    } else {
      console.log(`[ChartGen v8] ✗ ${name} FAILED`);
    }
  }
  
  return charts;
}

// ============================================
// EXPORTS
// ============================================

export {
  generateAllReportCharts,
  generateRegimeMap,
  generateMarginPressure,
  generateForwardVisibility,
  fetchChartBuffer,
  COLORS,
};