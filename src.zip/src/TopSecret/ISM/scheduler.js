// =====================================================
// ISM REPORT SCHEDULER v4.4 - FULLY DYNAMIC
// =====================================================
// Location: src/TopSecret/ISM/scheduler.js
//
// 🔄 CHANGES FROM v4.3:
// - REMOVED all hardcoded dates
// - Fully dynamic ISM release date calculation
// - Smart holiday detection including observed holidays
// - "Full business week" rule for post-holiday releases
//
// 📅 ISM RELEASE RULES:
// 1. First business day of the month at 10:00 AM ET
// 2. After major holidays (New Year's, July 4th):
//    - If first business day is Friday → wait for Monday
//    - ISM prefers releasing at start of full business week
// 3. Never releases on weekends or federal holidays
//
// =====================================================

import cron from 'node-cron';
import { ISMOrchestrator } from './orchestrator.js';
import { ISMDataService } from './data-service.js';
import { generateISMReportPDFBuffer } from './pdf-generator.js';

class ISMScheduler {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    
    // API Keys
    this.perplexityApiKey = options.perplexityApiKey || process.env.PERPLEXITY_API_KEY;
    this.openaiApiKey = options.openaiApiKey || process.env.OPENAI_API_KEY;
    
    if (!this.perplexityApiKey) {
      throw new Error('Perplexity API key is required for ISM data fetching');
    }
    
    // Create services
    this.dataService = new ISMDataService(supabase, {
      perplexityApiKey: this.perplexityApiKey,
      openaiApiKey: this.openaiApiKey,
    });
    
    this.orchestrator = new ISMOrchestrator(this.dataService, {
      supabase,
      openaiApiKey: this.openaiApiKey,
    });
    
    // =====================================================
    // CONFIGURATION
    // =====================================================
    this.options = {
      cronExpression: options.cronExpression || '0 9 1-10 * *',
      timezone: options.timezone || 'America/New_York',
      logoPath: options.logoPath || null,
      reportPageUrl: options.reportPageUrl || '/app/top-secret/reports/ism',
      ...options,
    };
    
    this.isRunning = false;
    this.cronJob = null;
    
    console.log('[ISMScheduler v4.4] Initialized:', {
      cron: this.options.cronExpression,
      timezone: this.options.timezone,
      mode: 'Fully dynamic release date calculation',
      hasPerplexity: !!this.perplexityApiKey,
      hasOpenAI: !!this.openaiApiKey,
    });
  }

  // ============================================
  // US FEDERAL HOLIDAYS - DYNAMIC CALCULATION
  // ============================================

  /**
   * Get all US federal holidays for a given year
   * These are the holidays that affect ISM release dates
   */
  getUSHolidays(year) {
    const holidays = [];
    
    // ===== FIXED DATE HOLIDAYS =====
    
    // New Year's Day - January 1
    holidays.push({
      date: new Date(year, 0, 1),
      name: "New Year's Day",
      observed: this.getObservedDate(new Date(year, 0, 1)),
      affectsISM: true, // ISM waits for full business week after this
    });
    
    // Independence Day - July 4
    holidays.push({
      date: new Date(year, 6, 4),
      name: 'Independence Day',
      observed: this.getObservedDate(new Date(year, 6, 4)),
      affectsISM: true,
    });
    
    // Veterans Day - November 11 (markets open, but some gov offices closed)
    holidays.push({
      date: new Date(year, 10, 11),
      name: 'Veterans Day',
      observed: this.getObservedDate(new Date(year, 10, 11)),
      affectsISM: false,
    });
    
    // Christmas Day - December 25
    holidays.push({
      date: new Date(year, 11, 25),
      name: 'Christmas Day',
      observed: this.getObservedDate(new Date(year, 11, 25)),
      affectsISM: false, // Doesn't affect ISM (released in early month)
    });
    
    // ===== FLOATING HOLIDAYS =====
    
    // MLK Day - 3rd Monday of January
    holidays.push({
      date: this.getNthWeekdayOfMonth(year, 0, 1, 3),
      name: 'Martin Luther King Jr. Day',
      affectsISM: false,
    });
    
    // Presidents Day - 3rd Monday of February
    holidays.push({
      date: this.getNthWeekdayOfMonth(year, 1, 1, 3),
      name: "Presidents' Day",
      affectsISM: false,
    });
    
    // Memorial Day - Last Monday of May
    holidays.push({
      date: this.getLastWeekdayOfMonth(year, 4, 1),
      name: 'Memorial Day',
      affectsISM: false,
    });
    
    // Labor Day - 1st Monday of September
    holidays.push({
      date: this.getNthWeekdayOfMonth(year, 8, 1, 1),
      name: 'Labor Day',
      affectsISM: true, // Can affect early September release
    });
    
    // Columbus Day - 2nd Monday of October
    holidays.push({
      date: this.getNthWeekdayOfMonth(year, 9, 1, 2),
      name: 'Columbus Day',
      affectsISM: false,
    });
    
    // Thanksgiving - 4th Thursday of November
    holidays.push({
      date: this.getNthWeekdayOfMonth(year, 10, 4, 4),
      name: 'Thanksgiving',
      affectsISM: false,
    });
    
    return holidays;
  }

  /**
   * Get the observed date for a holiday (handles weekend adjustments)
   * If holiday falls on Saturday → observed Friday
   * If holiday falls on Sunday → observed Monday
   */
  getObservedDate(holidayDate) {
    const dayOfWeek = holidayDate.getDay();
    
    if (dayOfWeek === 6) { // Saturday → Friday
      return new Date(holidayDate.getFullYear(), holidayDate.getMonth(), holidayDate.getDate() - 1);
    } else if (dayOfWeek === 0) { // Sunday → Monday
      return new Date(holidayDate.getFullYear(), holidayDate.getMonth(), holidayDate.getDate() + 1);
    }
    
    return holidayDate;
  }

  /**
   * Get the nth weekday of a month
   * weekday: 0=Sunday, 1=Monday, ..., 6=Saturday
   */
  getNthWeekdayOfMonth(year, month, weekday, n) {
    const firstDay = new Date(year, month, 1);
    const firstWeekday = firstDay.getDay();
    
    let dayOffset = weekday - firstWeekday;
    if (dayOffset < 0) dayOffset += 7;
    
    const date = 1 + dayOffset + (n - 1) * 7;
    return new Date(year, month, date);
  }

  /**
   * Get the last weekday of a month
   */
  getLastWeekdayOfMonth(year, month, weekday) {
    // Start from the last day of the month
    const lastDay = new Date(year, month + 1, 0);
    
    while (lastDay.getDay() !== weekday) {
      lastDay.setDate(lastDay.getDate() - 1);
    }
    
    return lastDay;
  }

  /**
   * Check if a specific date is a holiday (or observed holiday)
   */
  isHoliday(date, holidays = null) {
    if (!holidays) {
      holidays = this.getUSHolidays(date.getFullYear());
    }
    
    const dateStr = date.toISOString().split('T')[0];
    
    return holidays.some(h => {
      const holidayStr = h.date.toISOString().split('T')[0];
      const observedStr = h.observed ? h.observed.toISOString().split('T')[0] : holidayStr;
      
      return dateStr === holidayStr || dateStr === observedStr;
    });
  }

  /**
   * Check if there's a major holiday in the first few days of the month
   * that would cause ISM to delay release
   */
  hasEarlyMonthHoliday(year, month) {
    const holidays = this.getUSHolidays(year);
    
    // Check days 1-3 of the month for holidays that affect ISM
    for (let day = 1; day <= 3; day++) {
      const checkDate = new Date(year, month, day);
      
      for (const holiday of holidays) {
        if (!holiday.affectsISM) continue;
        
        const holidayDate = holiday.observed || holiday.date;
        
        if (
          holidayDate.getFullYear() === checkDate.getFullYear() &&
          holidayDate.getMonth() === checkDate.getMonth() &&
          holidayDate.getDate() === checkDate.getDate()
        ) {
          return {
            hasHoliday: true,
            holiday: holiday.name,
            date: holidayDate,
          };
        }
      }
    }
    
    return { hasHoliday: false };
  }

  // ============================================
  // ISM RELEASE DATE CALCULATOR - FULLY DYNAMIC
  // ============================================

  /**
   * Calculate the expected ISM release date for a given month
   * 
   * ISM RULES:
   * 1. Release on first business day of the month at 10:00 AM ET
   * 2. Business day = not weekend, not federal holiday
   * 3. SPECIAL: After major holidays (New Year's, July 4th, Labor Day):
   *    - If first business day is Friday → wait for Monday
   *    - This is the "full business week" preference
   */
  getExpectedISMReleaseDate(year, month) {
    const holidays = this.getUSHolidays(year);
    
    // Start with the 1st of the month
    let releaseDate = new Date(year, month, 1);
    
    // Step 1: Skip weekends
    while (releaseDate.getDay() === 0 || releaseDate.getDay() === 6) {
      releaseDate.setDate(releaseDate.getDate() + 1);
    }
    
    // Step 2: Skip holidays
    while (this.isHoliday(releaseDate, holidays)) {
      releaseDate.setDate(releaseDate.getDate() + 1);
      
      // Also skip weekends after holidays
      while (releaseDate.getDay() === 0 || releaseDate.getDay() === 6) {
        releaseDate.setDate(releaseDate.getDate() + 1);
      }
    }
    
    // Step 3: Check for "full business week" rule
    // If there's a major holiday in early month and first business day is Friday,
    // ISM waits for Monday
    const earlyHoliday = this.hasEarlyMonthHoliday(year, month);
    
    if (earlyHoliday.hasHoliday) {
      // Check if the calculated release date is a Friday
      if (releaseDate.getDay() === 5) { // Friday
        console.log(`[ISMScheduler] ${earlyHoliday.holiday} detected - Friday release → waiting for Monday`);
        
        // Move to next Monday
        releaseDate.setDate(releaseDate.getDate() + 3);
      }
      
      // Also check if it's the day right after a Thursday/Friday holiday
      // ISM prefers not to release the day after a major holiday
      const dayAfterHoliday = new Date(earlyHoliday.date);
      dayAfterHoliday.setDate(dayAfterHoliday.getDate() + 1);
      
      if (
        releaseDate.toISOString().split('T')[0] === dayAfterHoliday.toISOString().split('T')[0] &&
        (earlyHoliday.date.getDay() === 4 || earlyHoliday.date.getDay() === 5) // Thursday or Friday
      ) {
        console.log(`[ISMScheduler] Release would be day after ${earlyHoliday.holiday} (${earlyHoliday.date.toDateString()}) → waiting for Monday`);
        
        // Find next Monday
        while (releaseDate.getDay() !== 1) {
          releaseDate.setDate(releaseDate.getDate() + 1);
        }
      }
    }
    
    // Final validation: ensure it's a business day
    while (
      releaseDate.getDay() === 0 || 
      releaseDate.getDay() === 6 || 
      this.isHoliday(releaseDate, holidays)
    ) {
      releaseDate.setDate(releaseDate.getDate() + 1);
    }
    
    console.log(`[ISMScheduler] Calculated ISM release for ${year}-${String(month + 1).padStart(2, '0')}: ${releaseDate.toDateString()}`);
    
    return releaseDate;
  }

  /**
   * Check if ISM was released YESTERDAY
   */
  wasISMReleasedYesterday() {
    const now = new Date();
    // Convert to ET
    const etNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    
    // Get yesterday's date
    const yesterday = new Date(etNow);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Get the expected release date for THIS month's report
    const expectedRelease = this.getExpectedISMReleaseDate(etNow.getFullYear(), etNow.getMonth());
    
    // Compare dates (ignoring time)
    const releasedYesterday = 
      expectedRelease.getFullYear() === yesterday.getFullYear() &&
      expectedRelease.getMonth() === yesterday.getMonth() &&
      expectedRelease.getDate() === yesterday.getDate();
    
    console.log(`[ISMScheduler] 📅 Date Analysis (v4.4 Dynamic):`);
    console.log(`[ISMScheduler]    Today (ET): ${etNow.toDateString()}`);
    console.log(`[ISMScheduler]    Yesterday: ${yesterday.toDateString()}`);
    console.log(`[ISMScheduler]    Expected ISM Release: ${expectedRelease.toDateString()}`);
    console.log(`[ISMScheduler]    Was released yesterday: ${releasedYesterday ? '✅ YES' : '❌ NO'}`);
    
    return {
      releasedYesterday,
      expectedReleaseDate: expectedRelease,
      yesterday,
      today: etNow,
    };
  }

  // ============================================
  // DEBUG: GET FULL YEAR CALENDAR
  // ============================================

  /**
   * Generate ISM release calendar for debugging
   */
  getISMCalendar(year) {
    const calendar = [];
    
    for (let month = 0; month < 12; month++) {
      const releaseDate = this.getExpectedISMReleaseDate(year, month);
      const dataMonth = month === 0 
        ? `${year - 1}-12` 
        : `${year}-${String(month).padStart(2, '0')}`;
      
      // Check if there's a holiday affecting this month
      const earlyHoliday = this.hasEarlyMonthHoliday(year, month);
      
      calendar.push({
        releaseMonth: `${year}-${String(month + 1).padStart(2, '0')}`,
        releaseDate: releaseDate.toISOString().split('T')[0],
        releaseDateFormatted: releaseDate.toLocaleDateString('en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
        }),
        releaseDay: releaseDate.toLocaleDateString('en-US', { weekday: 'long' }),
        dataMonth,
        dataMonthName: new Date(parseInt(dataMonth.split('-')[0]), parseInt(dataMonth.split('-')[1]) - 1)
          .toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        distributionDate: new Date(releaseDate.getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        holidayAffected: earlyHoliday.hasHoliday ? earlyHoliday.holiday : null,
      });
    }
    
    return calendar;
  }

  // ============================================
  // START/STOP SCHEDULER
  // ============================================

  start() {
    if (this.cronJob) {
      console.log('[ISMScheduler] Already running');
      return;
    }

    console.log(`\n╔═══════════════════════════════════════════════════════╗`);
    console.log(`║     ISM AUTO-DISTRIBUTION SCHEDULER v4.4             ║`);
    console.log(`╠═══════════════════════════════════════════════════════╣`);
    console.log(`║  Schedule: ${this.options.cronExpression.padEnd(40)}║`);
    console.log(`║  Timezone: ${this.options.timezone.padEnd(40)}║`);
    console.log(`║  Active Days: 1st - 10th of each month               ║`);
    console.log(`║  Time: 9:00 AM Eastern                                ║`);
    console.log(`║  Mode: Fully dynamic (no hardcoded dates)            ║`);
    console.log(`╚═══════════════════════════════════════════════════════╝\n`);
    
    this.cronJob = cron.schedule(this.options.cronExpression, async () => {
      await this.runScheduledJob();
    }, {
      timezone: this.options.timezone,
    });

    console.log('[ISMScheduler] ✅ Scheduler started');
    this.logNextRunTime();
  }

  stop() {
    if (this.cronJob) {
      this.cronJob.stop();
      this.cronJob = null;
      console.log('[ISMScheduler] ⏹️ Scheduler stopped');
    }
  }

  logNextRunTime() {
    const now = new Date();
    const etNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const day = etNow.getDate();
    const hour = etNow.getHours();
    
    let nextRun;
    
    if (day <= 10 && hour < 9) {
      nextRun = new Date(etNow.getFullYear(), etNow.getMonth(), day, 9, 0, 0);
    } else if (day < 10) {
      nextRun = new Date(etNow.getFullYear(), etNow.getMonth(), day + 1, 9, 0, 0);
    } else {
      nextRun = new Date(etNow.getFullYear(), etNow.getMonth() + 1, 1, 9, 0, 0);
    }
    
    // Get next expected ISM release
    let nextISMRelease = this.getExpectedISMReleaseDate(etNow.getFullYear(), etNow.getMonth());
    if (etNow > nextISMRelease) {
      nextISMRelease = this.getExpectedISMReleaseDate(
        etNow.getMonth() === 11 ? etNow.getFullYear() + 1 : etNow.getFullYear(),
        (etNow.getMonth() + 1) % 12
      );
    }
    
    console.log(`[ISMScheduler] ⏰ Next scheduler run: ${nextRun.toLocaleDateString('en-US')} at 9:00 AM ET`);
    console.log(`[ISMScheduler] 📅 Next ISM release: ${nextISMRelease.toLocaleDateString('en-US')} at 10:00 AM ET`);
  }

  // ============================================
  // MAIN JOB EXECUTION
  // ============================================

  async runScheduledJob() {
    if (this.isRunning) {
      console.log('[ISMScheduler] ⏭️ Job already running, skipping');
      return;
    }

    this.isRunning = true;
    const startTime = Date.now();
    
    try {
      console.log('\n' + '='.repeat(60));
      console.log('[ISMScheduler] 🚀 Daily ISM Check Started (v4.4 Dynamic)');
      console.log(`[ISMScheduler] ⏰ Time: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET`);
      console.log('='.repeat(60));
      
      // STEP 1: Check if ISM was released YESTERDAY
      const releaseCheck = this.wasISMReleasedYesterday();
      
      if (!releaseCheck.releasedYesterday) {
        console.log('[ISMScheduler] ℹ️ ISM was NOT released yesterday');
        console.log(`[ISMScheduler] Expected release: ${releaseCheck.expectedReleaseDate.toDateString()}`);
        console.log('[ISMScheduler] Will check again tomorrow at 9:00 AM ET');
        
        await this.logJobExecution('skipped', this.dataService.getCurrentDataMonth(), null, Date.now() - startTime, 'ISM not released yesterday');
        return;
      }
      
      console.log('[ISMScheduler] 🎉 ISM was released YESTERDAY! Starting report generation...');
      
      const dataMonth = this.dataService.getCurrentDataMonth();
      console.log(`[ISMScheduler] 📅 Data month: ${dataMonth}`);
      
      // STEP 2: Check if report already exists
      const existingReport = await this.checkExistingReport(dataMonth);
      
      if (existingReport.exists) {
        console.log('[ISMScheduler] ✅ Report already exists for this month');
        console.log(`[ISMScheduler] Report ID: ${existingReport.reportId}`);
        console.log('[ISMScheduler] Skipping - no action needed');
        return;
      }
      
      // STEP 3: Verify ISM data is available
      console.log('[ISMScheduler] 🔍 Verifying ISM data availability...');
      
      const availability = await this.verifyISMDataAvailable(dataMonth);
      
      if (!availability.available) {
        console.log('[ISMScheduler] ⚠️ ISM data not yet indexed by search engines');
        console.log('[ISMScheduler] Will retry tomorrow');
        
        await this.logJobExecution('retry', dataMonth, null, Date.now() - startTime, 'Data not indexed yet');
        return;
      }
      
      console.log('[ISMScheduler] ✅ ISM data confirmed available!');
      console.log(`[ISMScheduler] PMI Value: ${availability.pmiValue}`);
      
      // STEP 4: Generate the report
      console.log('[ISMScheduler] 📊 Generating ISM report...');
      
      const result = await this.orchestrator.generate(dataMonth, {
        isAdminOverride: false,
        skipQA: false,
      });
      
      if (!result.success) {
        throw new Error(`Report generation failed: ${result.error}`);
      }
      
      console.log(`[ISMScheduler] ✅ Report generated: ${result.reportId}`);
      
      // STEP 5: Generate and upload PDF
      console.log('[ISMScheduler] 📄 Generating PDF...');
      
      const pdfBuffer = await generateISMReportPDFBuffer(result.report, this.options.logoPath);
      const pdfUrl = await this.uploadPDF(pdfBuffer, dataMonth);
      
      console.log(`[ISMScheduler] ✅ PDF uploaded: ${pdfUrl}`);
      
      // STEP 6: Create notification
      console.log('[ISMScheduler] 🔔 Creating notification for TOP SECRET users...');
      
      await this.createSystemUpdate({
        dataMonth,
        pmiValue: availability.pmiValue || 
                  result.report?.ism_data?.manufacturing?.pmi ||
                  result.report?.macro_snapshot?.pmi,
        pmiChange: this.calculatePMIChange(availability.pmiValue, result.report),
        reportId: result.reportId,
        pdfUrl,
      });
      
      console.log('[ISMScheduler] ✅ Notification sent to widget!');
      
      // STEP 7: Log success
      await this.logJobExecution('success', dataMonth, result.reportId, Date.now() - startTime);
      
      const duration = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log('\n' + '='.repeat(60));
      console.log(`[ISMScheduler] ✅ JOB COMPLETED in ${duration}s`);
      console.log(`[ISMScheduler] 📊 Report ID: ${result.reportId}`);
      console.log(`[ISMScheduler] 📄 PDF: ${pdfUrl}`);
      console.log('='.repeat(60) + '\n');
      
    } catch (error) {
      console.error('[ISMScheduler] ❌ Job failed:', error);
      
      await this.logJobExecution(
        'error', 
        this.dataService.getCurrentDataMonth(), 
        null, 
        Date.now() - startTime, 
        error.message
      );
      
    } finally {
      this.isRunning = false;
    }
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  async verifyISMDataAvailable(dataMonth) {
    try {
      console.log('[ISMScheduler] Fetching ISM data via ISMDataService...');
      
      const ismData = await this.dataService.fetchISMData(dataMonth);
      
      if (ismData && ismData.manufacturing?.pmi) {
        console.log('[ISMScheduler] ✅ Data fetched successfully');
        return {
          available: true,
          pmiValue: ismData.manufacturing.pmi,
          source: ismData.dataSource,
        };
      }
      
      return { available: false };
      
    } catch (error) {
      console.error('[ISMScheduler] Error verifying ISM data:', error.message);
      return { available: false };
    }
  }

  async checkExistingReport(dataMonth) {
    try {
      const { data } = await this.supabase
        .from('ism_reports')
        .select('id, created_at')
        .eq('report_month', dataMonth)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      
      if (!data) {
        return { exists: false };
      }
      
      return {
        exists: true,
        reportId: data.id,
        createdAt: data.created_at,
      };
      
    } catch (error) {
      return { exists: false };
    }
  }

  async uploadPDF(pdfBuffer, dataMonth) {
    const fileName = `ism-report-${dataMonth}.pdf`;
    const filePath = `ism-reports/${fileName}`;
    
    try {
      const { error: uploadError } = await this.supabase.storage
        .from('reports')
        .upload(filePath, pdfBuffer, {
          contentType: 'application/pdf',
          upsert: true,
        });
      
      if (uploadError) {
        console.error('[ISMScheduler] PDF upload error:', uploadError);
        throw uploadError;
      }
      
      const { data } = this.supabase.storage
        .from('reports')
        .getPublicUrl(filePath);
      
      return data.publicUrl;
      
    } catch (error) {
      console.error('[ISMScheduler] Failed to upload PDF:', error);
      return `${this.options.reportPageUrl}?month=${dataMonth}`;
    }
  }

  async createSystemUpdate({ dataMonth, pmiValue, pmiChange, reportId, pdfUrl }) {
    const [year, month] = dataMonth.split('-');
    const monthName = new Date(parseInt(year), parseInt(month) - 1, 1)
      .toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    let pmiDirection = '';
    let emoji = '📊';
    
    if (pmiChange > 0) {
      pmiDirection = `up ${Math.abs(pmiChange).toFixed(1)} points`;
      emoji = '📈';
    } else if (pmiChange < 0) {
      pmiDirection = `down ${Math.abs(pmiChange).toFixed(1)} points`;
      emoji = '📉';
    }
    
    const isExpansion = pmiValue >= 50;
    const context = isExpansion 
      ? 'Manufacturing is expanding' 
      : 'Manufacturing remains in contraction territory';
    
    const title = `${emoji} ISM Report Ready — ${monthName}`;
    
    const content = `The ${monthName} ISM Manufacturing report is now available. ` +
      `PMI came in at ${pmiValue}${pmiChange ? `, ${pmiDirection} from last month` : ''}. ` +
      `${context}. ` +
      `Full analysis with sector rankings and trade ideas inside.`;
    
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);
    
    try {
      await this.unpinOldISMUpdates();
      
      const { error } = await this.supabase
        .from('system_updates')
        .insert({
          title,
          content,
          type: 'announcement',
          target_group: 'top_secret',
          is_active: true,
          is_pinned: true,
          expires_at: expiresAt.toISOString(),
          metadata: {
            report_type: 'ism',
            report_month: dataMonth,
            report_id: reportId,
            pdf_url: pdfUrl,
            pmi_value: pmiValue,
            pmi_change: pmiChange,
          },
        });
      
      if (error) {
        console.error('[ISMScheduler] Failed to create system_update:', error);
        throw error;
      }
      
      console.log('[ISMScheduler] ✅ System update created for TOP SECRET users');
      
    } catch (error) {
      console.error('[ISMScheduler] Error creating notification:', error);
      throw error;
    }
  }

  async unpinOldISMUpdates() {
    try {
      await this.supabase
        .from('system_updates')
        .update({ is_pinned: false })
        .eq('is_pinned', true)
        .eq('target_group', 'top_secret')
        .ilike('title', '%ISM Report%');
        
    } catch (error) {
      console.error('[ISMScheduler] Error unpinning old updates:', error);
    }
  }

  calculatePMIChange(currentPMI, report) {
    const previousPMI = report?.rawData?.priorMonth?.pmi || 
                        report?.macro_snapshot?.previousPmi ||
                        report?.ism_data?.priorMonth?.pmi ||
                        null;
    
    if (currentPMI && previousPMI) {
      return parseFloat((currentPMI - previousPMI).toFixed(1));
    }
    
    return null;
  }

  async triggerNow(month = null, options = {}) {
    const dataMonth = month || this.dataService.getCurrentDataMonth();
    
    console.log(`[ISMScheduler] 🔧 Manual trigger for: ${dataMonth}`);
    
    const originalRunning = this.isRunning;
    this.isRunning = false;
    
    try {
      const result = await this.orchestrator.generate(dataMonth, {
        isAdminOverride: options.isAdminOverride || true,
        overrideReason: options.overrideReason || 'Manual admin trigger',
        adminId: options.adminId,
        skipQA: options.skipQA || false,
      });
      
      if (!result.success) {
        return result;
      }
      
      const pdfBuffer = await generateISMReportPDFBuffer(result.report, this.options.logoPath);
      const pdfUrl = await this.uploadPDF(pdfBuffer, dataMonth);
      
      if (options.createNotification !== false) {
        const pmiValue = result.report?.ism_data?.manufacturing?.pmi || 
                         result.report?.macro_snapshot?.pmi ||
                         result.report?.rawData?.ismData?.pmi;
        
        await this.createSystemUpdate({
          dataMonth,
          pmiValue,
          pmiChange: this.calculatePMIChange(pmiValue, result.report),
          reportId: result.reportId,
          pdfUrl,
        });
      }
      
      return {
        ...result,
        pdfBuffer,
        pdfUrl,
      };
      
    } finally {
      this.isRunning = originalRunning;
    }
  }

  async logJobExecution(status, dataMonth, reportId, durationMs, errorMessage = null) {
    if (!this.supabase) return;
    
    try {
      await this.supabase
        .from('ism_scheduler_logs')
        .insert({
          job_type: 'monthly_generation',
          status,
          data_month: dataMonth,
          report_id: reportId,
          duration_ms: durationMs,
          error_message: errorMessage,
          executed_at: new Date().toISOString(),
        });
    } catch (error) {
      console.error('[ISMScheduler] Failed to log execution:', error);
    }
  }

  // ============================================
  // STATUS
  // ============================================

  getStatus() {
    const now = new Date();
    const etNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    
    // Get next ISM release
    let nextISMRelease = this.getExpectedISMReleaseDate(etNow.getFullYear(), etNow.getMonth());
    if (etNow > nextISMRelease) {
      nextISMRelease = this.getExpectedISMReleaseDate(
        etNow.getMonth() === 11 ? etNow.getFullYear() + 1 : etNow.getFullYear(),
        (etNow.getMonth() + 1) % 12
      );
    }
    
    const releaseCheck = this.wasISMReleasedYesterday();
    const earlyHoliday = this.hasEarlyMonthHoliday(etNow.getFullYear(), etNow.getMonth());
    
    return {
      version: '4.4',
      mode: 'Fully dynamic (no hardcoded dates)',
      isRunning: !!this.cronJob,
      isJobRunning: this.isRunning,
      cronExpression: this.options.cronExpression,
      timezone: this.options.timezone,
      schedule: 'Daily at 9:00 AM ET (days 1-10 of month)',
      hasPerplexity: !!this.perplexityApiKey,
      hasOpenAI: !!this.openaiApiKey,
      nextISMRelease: nextISMRelease.toISOString(),
      nextISMReleaseFormatted: nextISMRelease.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }),
      wasReleasedYesterday: releaseCheck.releasedYesterday,
      currentDataMonth: this.dataService.getCurrentDataMonth(),
      holidayAffectingThisMonth: earlyHoliday.hasHoliday ? earlyHoliday.holiday : null,
      features: {
        systemUpdates: true,
        pdfGeneration: true,
        autoNotification: true,
        nextDayDistribution: true,
        holidayAware: true,
        fullyDynamic: true,
      },
    };
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

function createISMScheduler(supabase, options = {}) {
  const scheduler = new ISMScheduler(supabase, options);
  
  if (options.autoStart !== false) {
    scheduler.start();
  }
  
  return scheduler;
}

export {
  ISMScheduler,
  createISMScheduler,
};