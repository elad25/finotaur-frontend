// =====================================================
// ISM DATA SERVICE - ENHANCED LIVE DATA v10.4
// =====================================================
// CHANGES from v10.3:
// 1. Added Strategy 4: Direct PRNewswire URL fetch (2-step approach)
// 2. Enhanced quote validation with real quote indicators
// 3. Better parsing patterns for bullet points and numbered lists
// 4. Improved fallback logic - Strategy 4 runs before 2&3
// 5. Added getPRNewswireSearchURL helper
// 6. Enhanced sentiment/theme detection with more keywords
// =====================================================

import * as cheerio from 'cheerio';
import { QuoteValidator, validateQuotes } from './quote-validator.js';

class ISMDataService {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    this.perplexityApiKey = options.perplexityApiKey || process.env.PERPLEXITY_API_KEY;
    this.openaiApiKey = options.openaiApiKey || process.env.OPENAI_API_KEY;
    
    if (!this.perplexityApiKey) {
      console.error('[ISMData] CRITICAL: No Perplexity API key - cannot fetch live data');
      throw new Error('Perplexity API key is required for live ISM data');
    }
    
    console.log('[ISMData] Perplexity API configured for live data fetching');
    console.log('[ISMData] Will target ISM official website: ismworld.org');
    console.log('[ISMData] PRNewswire fallback enabled for quotes');
  }

  // ============================================
  // ISM URL BUILDER
  // ============================================

  getISMReportURL(month) {
    // month format: "2024-11" -> URL needs "november"
    const [year, monthNum] = month.split('-').map(Number);
    const monthNames = [
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december'
    ];
    const monthName = monthNames[monthNum - 1];
    
    // ISM URL format: https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/november/
    return `https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/${monthName}/`;
  }

  getISMArchiveURL(month) {
    // For historical data, ISM sometimes uses archive URLs
    const [year, monthNum] = month.split('-').map(Number);
    const monthNames = [
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december'
    ];
    const monthName = monthNames[monthNum - 1];
    
    return `https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/${monthName}-${year}/`;
  }

  // ============================================
  // PRNewswire URL Builder - NEW in v10.4
  // ============================================
  getPRNewswireSearchURL(month) {
    const [year, monthNum] = month.split('-').map(Number);
    const monthNames = [
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december'
    ];
    const monthName = monthNames[monthNum - 1];
    return `site:prnewswire.com "manufacturing-pmi" "${monthName}-${year}" "ism-manufacturing-pmi-report"`;
  }

  // ============================================
  // DIRECT ISM SCRAPING - Strategy 0 (Most Reliable)
  // ============================================

  async scrapeISMQuotesDirect(month) {
    const ismURL = this.getISMReportURL(month);
    console.log(`[ISM Scraper] Attempting direct scrape of: ${ismURL}`);
    
    try {
      const response = await fetch(ismURL, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
        },
        timeout: 15000,
      });

      if (!response.ok) {
        console.log(`[ISM Scraper] HTTP ${response.status} - cannot access ISM directly`);
        return null;
      }

      const html = await response.text();
      console.log(`[ISM Scraper] Got HTML (${html.length} chars)`);
      
      // Parse with cheerio
      const $ = cheerio.load(html);
      const quotes = [];
      
      // ISM website structure: Look for "What Respondents Are Saying" section
      // The quotes are typically in a section with industry names in parentheses
      
      // Strategy A: Look for blockquotes or quote-styled elements
      $('blockquote, .quote, .respondent-quote, .pmi-quote').each((i, el) => {
        const text = $(el).text().trim();
        if (text.length > 30) {
          const industryMatch = text.match(/\(([^)]+)\)\s*$/);
          if (industryMatch) {
            quotes.push({
              industry: industryMatch[1].trim(),
              comment: text.replace(/\s*\([^)]+\)\s*$/, '').replace(/^[""]|[""]$/g, '').trim(),
              source: 'ISM Direct Scrape',
              isVerified: true,
            });
          }
        }
      });
      
      // Strategy B: Look for list items with industry attribution
      if (quotes.length < 3) {
        $('li, p').each((i, el) => {
          const text = $(el).text().trim();
          // Match pattern: "Quote text" (Industry Name) or Quote text. (Industry Name)
          const quoteMatch = text.match(/^[""]?(.{30,500})[""]?\s*\(([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)\)\s*$/);
          if (quoteMatch) {
            quotes.push({
              industry: quoteMatch[2].trim(),
              comment: quoteMatch[1].replace(/^[""]|[""]$/g, '').trim(),
              source: 'ISM Direct Scrape',
              isVerified: true,
            });
          }
        });
      }
      
      // Strategy C: Search entire page for quote patterns
      if (quotes.length < 3) {
        const pageText = $('body').text();
        // Match quotes followed by industry in parentheses
        const quoteRegex = /[""]([^""]{30,400})[""]?\s*\(([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)\)/g;
        let match;
        while ((match = quoteRegex.exec(pageText)) !== null) {
          quotes.push({
            industry: match[2].trim(),
            comment: match[1].trim(),
            source: 'ISM Direct Scrape',
            isVerified: true,
          });
        }
      }
      
      // Deduplicate
      const uniqueQuotes = quotes.filter((q, i, arr) => 
        arr.findIndex(x => x.comment.substring(0, 50) === q.comment.substring(0, 50)) === i
      );
      
      console.log(`[ISM Scraper] Found ${uniqueQuotes.length} verified quotes from ISM website`);
      
      if (uniqueQuotes.length >= 3) {
        return uniqueQuotes.slice(0, 12);
      }
      
      return null; // Fall back to Perplexity
      
    } catch (error) {
      console.log(`[ISM Scraper] Direct scrape failed: ${error.message}`);
      return null;
    }
  }

  // ============================================
  // Strategy DIRECT: Fetch HTML directly from PRNewswire
  // This is the MOST RELIABLE method - 100% real quotes
  // ============================================
  async fetchQuotesDirectPRNewswire(month) {
  try {
    const [year, monthNum] = month.split('-');
    const monthNames = ['january', 'february', 'march', 'april', 'may', 'june',
                        'july', 'august', 'september', 'october', 'november', 'december'];
    const fullMonthName = monthNames[parseInt(monthNum) - 1];
    const capitalizedMonth = fullMonthName.charAt(0).toUpperCase() + fullMonthName.slice(1);
    
    console.log(`[PRNewswire Direct] Searching for ${capitalizedMonth} ${year} ISM report...`);
    
    let prnURL = null;
    
    // ★★★ NEW: Try ISM website first to find PRNewswire link ★★★
    try {
      const ismUrl = `https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/${fullMonthName}/`;
      console.log(`[PRNewswire Direct] Checking ISM website: ${ismUrl}`);
      
      const ismResponse = await fetch(ismUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
      });
      
      if (ismResponse.ok) {
        const ismHtml = await ismResponse.text();
        
        // Look for PRNewswire link in ISM page
        const prMatch = ismHtml.match(/href="(https:\/\/www\.prnewswire\.com[^"]*manufacturing-pmi[^"]*)"/i);
        if (prMatch) {
          prnURL = prMatch[1];
          console.log(`[PRNewswire Direct] ✓ Found PRNewswire URL via ISM: ${prnURL}`);
        }
      }
    } catch (ismError) {
      console.log(`[PRNewswire Direct] ISM check failed: ${ismError.message}`);
    }
    
    // ★★★ Fallback to Perplexity if ISM didn't have the link ★★★
    if (!prnURL) {
      console.log(`[PRNewswire Direct] Falling back to Perplexity search...`);
      
// Step 1: Use Perplexity to find the exact PRNewswire URL
      const urlResponse = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',  // ★ UPGRADED to sonar-pro for better search
          messages: [{
            role: 'user',
            content: `Search prnewswire.com for: "Manufacturing PMI" "${capitalizedMonth} ${year}" "ISM Manufacturing PMI Report"

Find the official ISM press release URL. The URL contains "manufacturing-pmi" and "ism-manufacturing-pmi-report".

Return ONLY the prnewswire.com URL, nothing else.`
          }],
          temperature: 0,
          max_tokens: 500,
          search_recency_filter: 'month',
          return_citations: true,
        }),
      });

      if (!urlResponse.ok) {
        console.error('[PRNewswire Direct] Failed to search for URL');
        return null;
      }

const urlData = await urlResponse.json();
      const citations = urlData.citations || [];
      const content = urlData.choices?.[0]?.message?.content || '';
      
      // Check citations first (most reliable)
      for (const citation of citations) {
        const url = typeof citation === 'string' ? citation : citation?.url;
        if (url && url.includes('prnewswire.com') && url.includes('manufacturing-pmi')) {
          prnURL = url;
          console.log(`[PRNewswire Direct] Found URL in citations: ${prnURL}`);
          break;
        }
      }
      
      // Try to extract from response content if not in citations
      if (!prnURL) {
        const urlMatch = content.match(/(https?:\/\/www\.prnewswire\.com\/news-releases\/[^\s"'<>]+manufacturing-pmi[^\s"'<>]+\.html)/i);
        if (urlMatch) {
          prnURL = urlMatch[1].replace(/[.,;:!?\)]+$/, '');
          console.log(`[PRNewswire Direct] Found URL in content: ${prnURL}`);
        }
      }
      
if (!prnURL) {
        const urlMatch = content.match(/(https?:\/\/www\.prnewswire\.com\/news-releases\/[^\s"'<>]+manufacturing-pmi[^\s"'<>]+\.html)/i);
        if (urlMatch) {
          prnURL = urlMatch[1].replace(/[.,;:!?\)]+$/, '');
          console.log(`[PRNewswire Direct] Found URL in content: ${prnURL}`);
        }
      }
    } // ★ Close the Perplexity fallback block
    
    if (!prnURL) {
      console.log('[PRNewswire Direct] Could not find PRNewswire URL');
      return null;
    }
    
    // Step 2: Fetch the actual HTML page
      console.log(`[PRNewswire Direct] Fetching HTML from: ${prnURL}`);
      
      const pageResponse = await fetch(prnURL, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
        },
      });
      
      if (!pageResponse.ok) {
        console.error(`[PRNewswire Direct] Failed to fetch page: HTTP ${pageResponse.status}`);
        return null;
      }
      
      const html = await pageResponse.text();
      console.log(`[PRNewswire Direct] Got HTML (${html.length} chars)`);
      
      // Step 3: Parse quotes from HTML
      const quotes = this.parseQuotesFromPRNewswireHTML(html);
      
      if (quotes.length >= 5) {
        console.log(`[PRNewswire Direct] ✓ SUCCESS: Extracted ${quotes.length} REAL quotes`);
        return quotes;
      }
      
      console.log(`[PRNewswire Direct] Only found ${quotes.length} quotes`);
      return quotes.length > 0 ? quotes : null;
      
    } catch (error) {
      console.error('[PRNewswire Direct] Error:', error.message);
      return null;
    }
  }

  // ============================================
  // Strategy DIRECT-ISM: Fetch from ISM website directly
  // Backup when PRNewswire fails
  // ============================================
  async fetchQuotesDirectISM(month) {
    try {
      const ismURL = this.getISMReportURL(month);
      console.log(`[ISM Direct] Fetching from: ${ismURL}`);
      
      const response = await fetch(ismURL, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'text/html,application/xhtml+xml',
        },
        timeout: 15000,
      });
      
      if (!response.ok) {
        console.log(`[ISM Direct] HTTP ${response.status}`);
        return null;
      }
      
      const html = await response.text();
      console.log(`[ISM Direct] Got HTML (${html.length} chars)`);
      
      // Use same parser as PRNewswire
      return this.parseQuotesFromPRNewswireHTML(html);
      
    } catch (error) {
      console.error(`[ISM Direct] Error: ${error.message}`);
      return null;
    }
  }
  // ============================================
  // Parse quotes directly from PRNewswire HTML
  // ============================================
parseQuotesFromPRNewswireHTML(html) {
    const quotes = [];
    
    console.log(`[PRNewswire Parser] Parsing HTML (${html.length} chars)`);
    
    // ★★★ IMPROVED: Multiple section markers ★★★
    const sectionMarkers = [
      'WHAT RESPONDENTS ARE SAYING',
      'What Respondents Are Saying',
      'WHAT RESPONDENTS ARE SAYING</strong>',
      'WHAT RESPONDENTS ARE SAYING</b>',
      'WHAT RESPONDENTS ARE SAYING</p>',
    ];
    
    let sectionStart = -1;
    let foundMarker = '';
    for (const marker of sectionMarkers) {
      sectionStart = html.indexOf(marker);
      if (sectionStart !== -1) {
        foundMarker = marker;
        console.log(`[PRNewswire Parser] Found section with marker: "${marker}"`);
        break;
      }
    }
    
    // ★★★ IMPROVED: Better section end detection ★★★
    const endMarkers = [
      'MANUFACTURING AT A GLANCE',
      'Manufacturing AT A GLANCE',
      'COMMODITIES REPORTED',
      'Commodities Reported',
      'The 10 manufacturing industries',
      'The 11 manufacturing industries',
      'The four manufacturing industries',
      'The five manufacturing industries',
      'The six manufacturing industries',
      '|  |  |',
      '<table',
      'About This Report',
      'ABOUT THIS REPORT',
    ];
    
    let sectionEnd = html.length;
    if (sectionStart !== -1) {
      for (const marker of endMarkers) {
        const idx = html.indexOf(marker, sectionStart + 100);
        if (idx !== -1 && idx < sectionEnd) {
          sectionEnd = idx;
        }
      }
    }
    
    const textToSearch = sectionStart !== -1 
      ? html.substring(sectionStart, sectionEnd)
      : html;
      
    console.log(`[PRNewswire Parser] Searching section (${textToSearch.length} chars)`);
    
    if (sectionStart === -1) {
      console.log(`[PRNewswire Parser] ⚠️ Section header not found, searching entire HTML`);
    }
    
    // ★★★ EXPANDED PATTERNS - catches ALL ISM industry names ★★★
    const patterns = [
      // Pattern 1: Bullet * "Quote" (Industry) - EXPANDED industry matching
      /\*\s*[""\u201C\u201D]([^""\u201C\u201D]{30,700})[""\u201C\u201D]\s*\(([^)]{3,80})\)/g,
      // Pattern 2: Just "Quote" (Industry) without bullet  
      /[""\u201C\u201D]([^""\u201C\u201D]{30,700})[""\u201C\u201D]\s*\(([^)]{3,80})\)/g,
      // Pattern 3: HTML entities - &quot;Quote&quot; (Industry)
      /&quot;([^&]{30,700})&quot;\s*\(([^)]{3,80})\)/g,
    ];
    
    // Known ISM industries for validation
    const knownIndustries = [
      'machinery', 'transportation equipment', 'chemical products',
      'computer & electronic products', 'food, beverage & tobacco',
      'fabricated metal products', 'electrical equipment', 'appliances',
      'miscellaneous manufacturing', 'primary metals', 'paper products',
      'plastics & rubber products', 'textile mills', 'furniture',
      'petroleum & coal products', 'nonmetallic mineral products',
      'wood products', 'printing', 'apparel', 'leather'
    ];
    
    const seenQuotes = new Set();
    
    for (const pattern of patterns) {
      pattern.lastIndex = 0; // Reset regex state
      let match;
      while ((match = pattern.exec(textToSearch)) !== null) {
        const quoteText = match[1].trim();
        const industry = match[2].trim();
        
        // Skip if too short
        if (quoteText.length < 30) continue;
        
        // Skip methodology/boilerplate text
        const lowerQuote = quoteText.toLowerCase();
        if (lowerQuote.includes('seasonally adjusted') || 
            lowerQuote.includes('report is based') ||
            lowerQuote.includes('ism®') ||
            lowerQuote.includes('pmi®') ||
            lowerQuote.includes('diffusion index') ||
            lowerQuote.includes('institute for supply')) continue;
        
// Validate industry name - must match known pattern
        const lowerIndustry = industry.toLowerCase();
        const isValidIndustry = knownIndustries.some(known => 
          lowerIndustry.includes(known) || known.includes(lowerIndustry.split(' ')[0])
        );
        
        if (!isValidIndustry && industry.length > 50) continue;
        
        // ★★★ NEW: Use isRealQuoteNotSummary filter ★★★
        if (!this.isRealQuoteNotSummary(quoteText)) {
          console.log(`[PRNewswire Parser] ✗ Filtered summary: "${quoteText.substring(0, 40)}..."`);
          continue;
        }
        
        // Deduplicate by first 50 chars
        const quoteKey = quoteText.substring(0, 50).toLowerCase();
        if (seenQuotes.has(quoteKey)) continue;
        seenQuotes.add(quoteKey);
        
        console.log(`[PRNewswire Parser] ✓ Found: "${quoteText.substring(0, 40)}..." (${industry})`);
        
        quotes.push({
          industry: industry,
          comment: quoteText,
          sentiment: this.detectSentiment(quoteText),
          keyTheme: this.detectTheme(quoteText),
          source: 'ISM Official via PRNewswire (Direct HTML)',
          isVerified: true,
          isFallback: false,
        });
      }
    }
    
    console.log(`[PRNewswire Parser] ✓ Extracted ${quotes.length} unique quotes`);
    return quotes;
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  getCurrentDataMonth() {
    const now = new Date();
    const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return `${prevMonth.getFullYear()}-${String(prevMonth.getMonth() + 1).padStart(2, '0')}`;
  }

  getPreviousMonth(month) {
    const [year, monthNum] = month.split('-').map(Number);
    let prevMonthNum = monthNum - 1;
    let prevYear = year;
    if (prevMonthNum < 1) {
      prevMonthNum = 12;
      prevYear -= 1;
    }
    return `${prevYear}-${String(prevMonthNum).padStart(2, '0')}`;
  }

  getMonthName(month) {
    const [year, monthNum] = month.split('-');
    const date = new Date(parseInt(year), parseInt(monthNum) - 1, 1);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  }

  getExpectedReleaseDate(dataMonth) {
    const [year, month] = dataMonth.split('-').map(Number);
    let releaseMonth = month + 1;
    let releaseYear = year;
    if (releaseMonth > 12) { releaseMonth = 1; releaseYear += 1; }
    
    const releaseDate = new Date(releaseYear, releaseMonth - 1, 1);
    const dayOfWeek = releaseDate.getDay();
    if (dayOfWeek === 0) releaseDate.setDate(2);
    if (dayOfWeek === 6) releaseDate.setDate(3);
    
    return releaseDate;
  }

  checkISMAvailability(dataMonth) {
    const expectedRelease = this.getExpectedReleaseDate(dataMonth);
    const now = new Date();
    const isAvailable = now >= expectedRelease;
    
    return {
      dataMonth,
      available: isAvailable,
      expectedReleaseDate: expectedRelease.toISOString(),
      daysUntilRelease: isAvailable ? 0 : Math.ceil((expectedRelease - now) / (1000 * 60 * 60 * 24)),
      source: 'Perplexity Web Search',
    };
  }

  // ============================================
  // MAIN DATA FETCHING - WITH PRIOR VALUES
  // ============================================

  async fetchISMData(month) {
    const ismURL = this.getISMReportURL(month);
    
    console.log(`\n[ISMData] ========================================`);
    console.log(`[ISMData] Fetching ISM data for: ${month}`);
    console.log(`[ISMData] Source: Perplexity API (live web search)`);
    console.log(`[ISMData] Target ISM URL: ${ismURL}`);
    console.log(`[ISMData] ========================================\n`);
    
    // Step 1: Check cache first
    console.log('[ISMData] Step 1: Checking cache...');
    const cached = await this.getCachedData(month);
    if (cached && this.isValidCache(cached)) {
      console.log(`[ISMData] Using cached data from: ${cached.dataSource}`);
      return cached;
    }
    
    // Step 2: Fetch CURRENT month data with retry logic
    console.log('[ISMData] Step 2: Fetching current month via Perplexity...');
    let currentData = null;
    
    // Try multiple times with different query strategies
    for (let attempt = 1; attempt <= 3; attempt++) {
      console.log(`[ISMData] Attempt ${attempt}/3...`);
      currentData = await this.fetchISMViaPerplexity(month, attempt);
      
      if (currentData && this.validateISMData(currentData)) {
        console.log(`[ISMData] Successfully fetched data on attempt ${attempt}`);
        break;
      }
      
      if (attempt < 3) {
        console.log(`[ISMData] Attempt ${attempt} failed, waiting before retry...`);
        await this.sleep(1000);
      }
    }
    
    if (!currentData || !this.validateISMData(currentData)) {
      throw new Error(`Failed to fetch valid ISM data for ${month}. Please check Perplexity API status.`);
    }
    
    // Step 3: Fetch PRIOR month data for MoM calculation
    console.log('[ISMData] Step 3: Fetching prior month for MoM comparison...');
    const priorMonth = this.getPreviousMonth(month);
    const priorData = await this.fetchISMViaPerplexity(priorMonth, 1);
    
    // Step 4: Calculate MoM changes
    if (priorData && priorData.manufacturing) {
      console.log('[ISMData] Step 4: Calculating MoM changes...');
      currentData.priorMonth = {
        month: priorMonth,
        pmi: priorData.manufacturing.pmi,
        newOrders: priorData.manufacturing.newOrders,
        production: priorData.manufacturing.production,
        employment: priorData.manufacturing.employment,
        prices: priorData.manufacturing.prices,
        backlog: priorData.manufacturing.backlog,
        inventories: priorData.manufacturing.inventories,
        supplierDeliveries: priorData.manufacturing.supplierDeliveries,
      };
      
      // Calculate deltas
      currentData.momChanges = this.calculateMoMChanges(
        currentData.manufacturing,
        currentData.priorMonth
      );
      
      console.log('[ISMData] MoM changes calculated:', JSON.stringify(currentData.momChanges, null, 2));
    } else {
      console.log('[ISMData] WARNING: Could not fetch prior month data for MoM');
      currentData.priorMonth = null;
      currentData.momChanges = null;
    }
    
    // Step 5: Fetch real industry quotes from ISM "What Respondents Are Saying"
    console.log('[ISMData] Step 5: Fetching real industry quotes from ISM...');
    console.log('[ISMData] DEBUG: Perplexity API Key present:', !!this.perplexityApiKey);
    const quotes = await this.fetchIndustryQuotes(month);
    console.log('[ISMData] DEBUG: Quotes returned:', quotes?.length || 0);
    if (quotes && quotes.length > 0) {
      console.log('[ISMData] DEBUG: First quote sample:', quotes[0]?.comment?.substring(0, 80) || 'NONE');
      console.log('[ISMData] DEBUG: Quote industries:', quotes.slice(0, 5).map(q => q.industry).join(', '));
    } else {
      console.warn('[ISMData] ⚠️ NO QUOTES RETURNED - Check Perplexity API and PRNewswire availability');
    }

    currentData.respondentComments = quotes || [];
    console.log(`[ISMData] ★★★ FINAL QUOTE COUNT: ${currentData.respondentComments.length} ★★★`);
    
    // Step 6: Fetch historical context
    console.log('[ISMData] Step 6: Fetching historical context...');
    const historical = await this.fetchHistoricalViaPerplexity(month, 6);
    currentData.historicalData = historical;
    
    // Step 7: Cache the data
    await this.cacheData(month, currentData);
    
    console.log(`[ISMData] SUCCESS: PMI = ${currentData.manufacturing.pmi}`);
    if (currentData.momChanges) {
      console.log(`[ISMData] PMI Change: ${currentData.momChanges.pmi?.delta > 0 ? '+' : ''}${currentData.momChanges.pmi?.delta}`);
    }
    
    return currentData;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // ============================================
  // MoM CALCULATION
  // ============================================

  calculateMoMChanges(current, prior) {
    const components = ['pmi', 'newOrders', 'production', 'employment', 'prices', 'backlog', 'inventories', 'supplierDeliveries'];
    const changes = {};
    
    for (const comp of components) {
      const currentVal = current[comp];
      const priorVal = prior[comp];
      
      if (currentVal != null && priorVal != null) {
        const delta = this.roundTo1(currentVal - priorVal);
        changes[comp] = {
          prior: priorVal,
          current: currentVal,
          delta: delta,
          direction: delta > 0 ? 'improving' : delta < 0 ? 'deteriorating' : 'unchanged',
          aboveThreshold: currentVal >= 50,
          crossedThreshold: (currentVal >= 50) !== (priorVal >= 50),
          signal: this.getSignal(comp, currentVal, delta),
        };
      } else {
        changes[comp] = {
          prior: priorVal,
          current: currentVal,
          delta: null,
          direction: 'unknown',
          aboveThreshold: currentVal != null ? currentVal >= 50 : null,
          crossedThreshold: false,
          signal: null,
        };
      }
    }
    
    // Summary
    changes.summary = {
      mostImproved: this.findMostImproved(changes),
      mostDeteriorated: this.findMostDeteriorated(changes),
      thresholdCrosses: Object.entries(changes)
        .filter(([k, v]) => v.crossedThreshold && k !== 'summary')
        .map(([k, v]) => ({
          component: k,
          from: v.prior,
          to: v.current,
          direction: v.current >= 50 ? 'into expansion' : 'into contraction',
        })),
    };
    
    return changes;
  }

  getSignal(component, value, delta) {
    const isAbove50 = value >= 50;
    const isImproving = delta > 0;
    
    const signals = {
      pmi: isAbove50 
        ? (isImproving ? 'Expansion accelerating' : 'Expansion decelerating')
        : (isImproving ? 'Contraction easing' : 'Contraction deepening'),
      newOrders: isAbove50
        ? (isImproving ? 'Demand strengthening' : 'Demand moderating')
        : (isImproving ? 'Demand stabilizing' : 'Demand deteriorating'),
      employment: isAbove50
        ? (isImproving ? 'Hiring accelerating' : 'Hiring slowing')
        : (isImproving ? 'Cuts slowing' : 'Cuts accelerating'),
      prices: value > 55
        ? (isImproving ? 'Cost pressure rising' : 'Cost pressure easing')
        : (isImproving ? 'Costs stabilizing' : 'Deflation risk'),
      backlog: isAbove50
        ? (isImproving ? 'Visibility improving' : 'Backlog depleting')
        : (isImproving ? 'Pipeline stabilizing' : 'Pipeline shrinking'),
      production: isAbove50
        ? (isImproving ? 'Output accelerating' : 'Output slowing')
        : (isImproving ? 'Cuts easing' : 'Output falling'),
      inventories: value > 50
        ? 'Building' : 'Depleting',
      supplierDeliveries: value > 50
        ? 'Slowing deliveries' : 'Faster deliveries',
    };
    
    return signals[component] || null;
  }

  findMostImproved(changes) {
    const validChanges = Object.entries(changes)
      .filter(([k, v]) => k !== 'summary' && v.delta != null)
      .sort((a, b) => b[1].delta - a[1].delta);
    
    if (validChanges.length === 0) return null;
    
    const [component, data] = validChanges[0];
    return data.delta > 0 ? { component, ...data } : null;
  }

  findMostDeteriorated(changes) {
    const validChanges = Object.entries(changes)
      .filter(([k, v]) => k !== 'summary' && v.delta != null)
      .sort((a, b) => a[1].delta - b[1].delta);
    
    if (validChanges.length === 0) return null;
    
    const [component, data] = validChanges[0];
    return data.delta < 0 ? { component, ...data } : null;
  }

  // ============================================
  // PERPLEXITY: ISM DATA FETCH - ENHANCED v10.0
  // ============================================

  async fetchISMViaPerplexity(month, attemptNumber = 1) {
    const monthName = this.getMonthName(month);
    const ismURL = this.getISMReportURL(month);
    const ismArchiveURL = this.getISMArchiveURL(month);
    
    console.log(`[Perplexity] ISM URL: ${ismURL}`);
    
    // Different query strategies for different attempts
    const queryStrategies = {
      1: this.buildPrimaryQuery(monthName, month, ismURL),
      2: this.buildSecondaryQuery(monthName, ismURL, ismArchiveURL),
      3: this.buildTertiaryQuery(monthName),
    };
    
    const { systemPrompt, userPrompt } = queryStrategies[attemptNumber] || queryStrategies[1];
    
    try {
      console.log(`[Perplexity] Searching for ISM Manufacturing data for ${monthName} (Strategy ${attemptNumber})...`);
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar' , // ✅ או 'sonar-pro',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
          temperature: 0.1,
          max_tokens: 3000,
          // Web search parameters
          search_domain_filter: ['ismworld.org', 'tradingeconomics.com', 'reuters.com', 'bloomberg.com'],
          search_recency_filter: 'month',
          return_citations: true,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[Perplexity] API error: ${response.status} - ${errorText}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      const citations = data.citations || [];
      
      if (!content) {
        console.log('[Perplexity] No content in response');
        return null;
      }
      
      console.log('[Perplexity] Raw response received, parsing...');
      console.log('[Perplexity] Content preview:', content.substring(0, 500));
      console.log('[Perplexity] Citations:', citations.length > 0 ? citations.slice(0, 3) : 'NO CITATIONS');
      
      if (citations.length === 0) {
        console.warn('[Perplexity] WARNING: No citations. Data may not be from real web search.');
      }
      
      const parsed = this.extractJSON(content);
      
      if (!parsed || parsed.error === 'DATA_NOT_FOUND') {
        console.log('[Perplexity] Data not found:', parsed?.reason || 'Unknown reason');
        return null;
      }
      
      // Validate PMI is a reasonable value
      if (!parsed.pmi || parsed.pmi < 35 || parsed.pmi > 70) {
        console.log(`[Perplexity] Invalid PMI value: ${parsed.pmi}`);
        // Try to extract from text if JSON failed
        const extractedPMI = this.extractPMIFromText(content);
        if (extractedPMI) {
          parsed.pmi = extractedPMI;
          console.log(`[Perplexity] Extracted PMI from text: ${extractedPMI}`);
        } else {
          return null;
        }
      }
      
      console.log(`[Perplexity] Successfully parsed: PMI = ${parsed.pmi}`);
      
      return this.formatISMData({
        pmi: this.parseNumber(parsed.pmi),
        previousPmi: this.parseNumber(parsed.previousPmi),
        newOrders: this.parseNumber(parsed.newOrders),
        production: this.parseNumber(parsed.production),
        employment: this.parseNumber(parsed.employment),
        prices: this.parseNumber(parsed.prices),
        supplierDeliveries: this.parseNumber(parsed.supplierDeliveries),
        inventories: this.parseNumber(parsed.inventories),
        backlog: this.parseNumber(parsed.backlog),
        newExportOrders: this.parseNumber(parsed.newExportOrders),
        imports: this.parseNumber(parsed.imports),
        customersInventories: parsed.customersInventories || null,
        consecutiveContractionMonths: parsed.consecutiveContractionMonths || 0,
        consecutiveExpansionMonths: parsed.consecutiveExpansionMonths || 0,
        releaseDate: parsed.releaseDate || new Date().toISOString().split('T')[0],
        source: parsed.source || 'ISM via Perplexity',
      }, month);
      
    } catch (error) {
      console.error('[Perplexity] Error:', error.message);
      return null;
    }
  }

  buildPrimaryQuery(monthName, month, ismURL) {
    return {
      systemPrompt: `You are a financial data specialist that extracts ISM Manufacturing PMI data from the official ISM website.

CRITICAL INSTRUCTIONS:
1. GO DIRECTLY to the ISM official website: ${ismURL}
2. Extract the EXACT data from the ISM Report On Business for ${monthName}
3. The ISM website has ALL the component data and respondent quotes
4. Return ONLY a valid JSON object - no markdown, no explanation, no extra text
5. All ISM index values are typically between 35-70
6. If you cannot find verified data, return: {"error": "DATA_NOT_FOUND", "reason": "explanation"}

The ISM website URL format is:
- Current month: ${ismURL}
- The page contains: PMI headline, all component indexes, and "What Respondents Are Saying" quotes`,
      
      userPrompt: `Go to ${ismURL} and extract the ISM Manufacturing PMI Report data for ${monthName}.

From the OFFICIAL ISM website, find and return ONLY this JSON structure:

{
  "pmi": <headline Manufacturing PMI number>,
  "previousPmi": <prior month PMI>,
  "newOrders": <New Orders Index>,
  "production": <Production Index>,
  "employment": <Employment Index>,
  "supplierDeliveries": <Supplier Deliveries Index>,
  "inventories": <Inventories Index>,
  "prices": <Prices Paid Index>,
  "backlog": <Backlog of Orders Index>,
  "newExportOrders": <New Export Orders Index>,
  "imports": <Imports Index>,
  "customersInventories": "<too_high|about_right|too_low>",
  "consecutiveContractionMonths": <number of months PMI<50, or 0>,
  "consecutiveExpansionMonths": <number of months PMI>=50, or 0>,
  "releaseDate": "YYYY-MM-DD",
  "source": "ISM - ismworld.org"
}

Return ONLY the JSON. No markdown code blocks. No explanation.`,
    };
  }

  buildSecondaryQuery(monthName, ismURL, ismArchiveURL) {
    return {
      systemPrompt: `You retrieve ISM Manufacturing data. Try these URLs in order:
1. ${ismURL}
2. ${ismArchiveURL}
3. tradingeconomics.com/united-states/business-confidence
4. reuters.com ISM Manufacturing

Return data as JSON only.`,
      
      userPrompt: `What was the ISM Manufacturing PMI for ${monthName}?

Search these sources in order:
1. ${ismURL} (ISM official)
2. Trading Economics
3. Reuters
4. Bloomberg

I need these specific numbers from the ISM Report:
- PMI (headline number)
- New Orders Index
- Production Index  
- Employment Index
- Prices Index
- Backlog Index
- Previous month PMI

Return as JSON:
{"pmi": X, "newOrders": X, "production": X, "employment": X, "prices": X, "backlog": X, "previousPmi": X, "source": "source name"}`,
    };
  }

  buildTertiaryQuery(monthName) {
    return {
      systemPrompt: `Extract ISM Manufacturing data from web search. Respond with JSON only.`,
      
      userPrompt: `ISM Manufacturing PMI ${monthName} - find the headline number and components.

Look up on tradingeconomics.com or ismworld.org.

JSON response format:
{"pmi": number, "newOrders": number, "employment": number, "prices": number, "source": ""}`,
    };
  }

  extractPMIFromText(text) {
    // Try to find PMI value in the text
    const patterns = [
      /PMI[:\s]+(\d+\.?\d*)/i,
      /manufacturing\s+PMI[:\s]+(\d+\.?\d*)/i,
      /registered\s+(\d+\.?\d*)/i,
      /came\s+in\s+at\s+(\d+\.?\d*)/i,
      /(\d+\.?\d*)\s*percent/i,
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        const value = parseFloat(match[1]);
        if (value >= 35 && value <= 70) {
          return value;
        }
      }
    }
    
    return null;
  }

  formatISMData(raw, month) {
    return {
      dataMonth: month,
      manufacturing: {
        pmi: raw.pmi,
        previousPmi: raw.previousPmi,
        newOrders: raw.newOrders,
        production: raw.production,
        employment: raw.employment,
        supplierDeliveries: raw.supplierDeliveries,
        inventories: raw.inventories,
        prices: raw.prices,
        backlog: raw.backlog,
        newExportOrders: raw.newExportOrders,
        imports: raw.imports,
        customersInventories: raw.customersInventories,
      },
      releaseDate: raw.releaseDate,
      consecutiveContractionMonths: raw.consecutiveContractionMonths,
      consecutiveExpansionMonths: raw.consecutiveExpansionMonths,
      dataSource: raw.source || 'Perplexity Web Search',
      dataQuality: 'live',
      fetchedAt: new Date().toISOString(),
    };
  }

  // ============================================
  // QUOTES FETCHING - ENHANCED v12.1
  // 5-Strategy Fallback System for Real ISM Quotes
  // ============================================

async fetchIndustryQuotes(month) {
    const monthName = this.getMonthName(month);
    const [year, monthNum] = month.split('-');
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                        'July', 'August', 'September', 'October', 'November', 'December'];
    const fullMonthName = monthNames[parseInt(monthNum) - 1];
    
    console.log(`\n[Quotes v14.0] ========================================`);
    console.log(`[Quotes v14.0] TIERED Quote Extraction for ${monthName}`);
    console.log(`[Quotes v14.0] ========================================\n`);
    
    const quoteValidator = new QuoteValidator();
    let quotes = null;
    let extractionAttempts = [];

    // ============================================
    // TIER 1: PRNewswire Direct HTML (Most Reliable)
    // ============================================
    console.log('[Quotes v14.0] TIER 1: PRNewswire Direct HTML...');
    
    try {
      quotes = await this.fetchQuotesDirectPRNewswire(month);
      extractionAttempts.push({ 
        tier: 1, 
        source: 'PRNewswire HTML', 
        success: !!quotes, 
        count: quotes?.length || 0 
      });
      
      if (quotes && quotes.length >= 5) {
        const validated = validateQuotes(quotes);
        
        if (validated.valid.length >= 5) {
          console.log(`[Quotes v14.0] ✓ TIER 1 SUCCESS: ${validated.valid.length} verified quotes`);
          return this.finalizeQuotes(validated.valid, 'PRNewswire HTML Direct', extractionAttempts);
        }
        console.log(`[Quotes v14.0] TIER 1: Only ${validated.valid.length} passed validation`);
      }
    } catch (error) {
      console.error(`[Quotes v14.0] TIER 1 Error: ${error.message}`);
      extractionAttempts.push({ tier: 1, source: 'PRNewswire HTML', success: false, error: error.message });
    }

    // ============================================
    // TIER 2: ISM Website Direct
    // ============================================
    console.log('[Quotes v14.0] TIER 2: ISM Website Direct...');
    
    try {
      quotes = await this.fetchQuotesDirectISM(month);
      extractionAttempts.push({ 
        tier: 2, 
        source: 'ISM Website', 
        success: !!quotes, 
        count: quotes?.length || 0 
      });
      
      if (quotes && quotes.length >= 5) {
        const validated = validateQuotes(quotes);
        
        if (validated.valid.length >= 5) {
          console.log(`[Quotes v14.0] ✓ TIER 2 SUCCESS: ${validated.valid.length} verified quotes`);
          return this.finalizeQuotes(validated.valid, 'ISM Website Direct', extractionAttempts);
        }
        console.log(`[Quotes v14.0] TIER 2: Only ${validated.valid.length} passed validation`);
      }
    } catch (error) {
      console.error(`[Quotes v14.0] TIER 2 Error: ${error.message}`);
      extractionAttempts.push({ tier: 2, source: 'ISM Website', success: false, error: error.message });
    }

   // ============================================
    // TIER 3: ISM Official PDF - DISABLED
    // ISM changed PDF URL structure from mfgrob-MMYYYY.pdf to new format
    // PRNewswire HTML is now more reliable
    // ============================================
    console.log('[Quotes v14.0] TIER 3: ISM PDF SKIPPED (URL structure changed)');
    extractionAttempts.push({ 
      tier: 3, 
      source: 'ISM PDF', 
      success: false, 
      count: 0,
      error: 'ISM changed PDF URL structure - tier disabled'
    });
    
    // NOTE: If you want to re-enable PDF extraction in the future,
    // you'll need to update ISMPDFExtractor with the new URL pattern.
    // Current known working format: turk202511pmi.pdf (for November 2025)

    // ============================================
    // TIER 4: Perplexity Strategies (UNVERIFIED - Last Resort)
    // ============================================
    console.log('[Quotes v14.0] ⚠️ TIER 4: Perplexity (UNVERIFIED)...');
    
    try {
      // Try existing Perplexity strategies
      quotes = await this.fetchQuotesExactURL(month, fullMonthName, year);
      
      if (!quotes || quotes.length < 3) {
        quotes = await this.fetchQuotesPerplexityV2(month, fullMonthName, year);
      }
      
      if (!quotes || quotes.length < 3) {
        quotes = await this.fetchQuotesDirectCopy(month, fullMonthName, year);
      }
      
      if (!quotes || quotes.length < 3) {
        quotes = await this.fetchQuotesSimple(month, fullMonthName, year);
      }
      
      extractionAttempts.push({ 
        tier: 4, 
        source: 'Perplexity', 
        success: !!quotes, 
        count: quotes?.length || 0 
      });
      
      if (quotes && quotes.length > 0) {
        const validated = validateQuotes(quotes);
        
        if (validated.valid.length > 0) {
          console.log(`[Quotes v14.0] ⚠️ TIER 4: ${validated.valid.length} quotes (UNVERIFIED)`);
          
          // Mark as unverified
          return this.finalizeQuotes(
            validated.valid.map(q => ({
              ...q,
              isVerified: false,
              needsManualReview: true,
              verificationNote: 'Perplexity source - manual verification recommended',
            })),
            'Perplexity (Unverified)',
            extractionAttempts
          );
        }
      }
    } catch (error) {
      console.error(`[Quotes v14.0] TIER 4 Error: ${error.message}`);
      extractionAttempts.push({ tier: 4, source: 'Perplexity', success: false, error: error.message });
    }

    // ============================================
    // NO QUOTES AVAILABLE
    // ============================================
    console.log('\n[Quotes v14.0] ==========================================');
    console.log('[Quotes v14.0] ❌ ALL TIERS FAILED - EXTRACTION SUMMARY:');
    console.log('[Quotes v14.0] ==========================================');
    extractionAttempts.forEach(attempt => {
      const status = attempt.success && attempt.count >= 5 ? '✓ SUCCESS' : '✗ FAILED';
      console.log(`[Quotes v14.0]   TIER ${attempt.tier} (${attempt.source}): ${status} - ${attempt.count} quotes`);
      if (attempt.error) console.log(`[Quotes v14.0]     Error: ${attempt.error}`);
    });
    console.log('[Quotes v14.0] ==========================================\n');
    
    return this.finalizeQuotes([], 'None Available', extractionAttempts);
  }
  // ============================================
  // NEW: Finalize quotes with metadata
  // ============================================
  finalizeQuotes(quotes, source, attempts) {
    return quotes.map((q, index) => ({
      ...q,
      source: source,
      isVerified: !source.includes('Unverified') && source !== 'None Available',
      extractedAt: new Date().toISOString(),
      position: index + 1,
      extractionMeta: {
        tiersAttempted: attempts.length,
        successfulTier: attempts.find(a => a.success && a.count >= 5)?.tier || null,
        allAttempts: attempts,
      },
    }));
  }

  // ============================================
  // Strategy 0: Exact URL Extraction (BEST)
  // Uses explicit PRNewswire URL pattern
  // ============================================
  async fetchQuotesExactURL(month, fullMonthName, year) {
    try {
      console.log('[ISM Quotes v13.0] Strategy 0: Exact PRNewswire extraction...');
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [
            {
              role: 'user',
              content: `I need the EXACT quotes from the "WHAT RESPONDENTS ARE SAYING" section of the ISM Manufacturing PMI Report for ${fullMonthName} ${year} published on prnewswire.com.

CRITICAL: I need REAL executive quotes, NOT report summaries!

❌ WRONG (these are NOT quotes, these are summaries - DO NOT RETURN THESE):
- "Reported growth in November"
- "Reported contraction in November"
- "Reported increased production"
- "Manufacturing activity contracted at a faster rate"

✅ CORRECT (these are REAL executive quotes - I NEED THESE):
- "New order entries are within the forecast. We have increased requests from customers to get their orders sooner. Transit time on imports seems to be longer." (Machinery)
- "We are starting to institute more permanent changes due to the tariff environment. This includes reduction of staff." (Transportation Equipment)
- "Tariff conversations continue to cause concern." (Chemical Products)
- "Shutdown has been extended to an indeterminate date." (Computer & Electronic Products)

REAL quotes contain:
- Specific operational details (orders, inventory, lead times)
- First-person language ("we", "our", "customers")
- Specific concerns (tariffs, supply chain, demand)
- 50+ characters of actual content

Find the PRNewswire page and COPY the exact bullet points from "WHAT RESPONDENTS ARE SAYING".

Format:
1. "[exact quote - must be 50+ chars with real content]" (Specific Industry Name)
2. "[exact quote]" (Specific Industry Name)

If you cannot find REAL quotes (not summaries), return: QUOTES_NOT_FOUND`
            }
          ],
          temperature: 0,
          max_tokens: 5000,
          return_citations: true,
          search_recency_filter: 'month',
          web_search_options: {
            search_context_size: 'high'
          }
        }),
      });

      if (!response.ok) {
        console.error(`[ISM Quotes v13.0] Strategy 0 HTTP error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      const citations = data.citations || [];
      
      console.log('[ISM Quotes v13.0] Strategy 0 response length:', content.length);
      console.log('[ISM Quotes v13.0] Strategy 0 first 500 chars:', content.substring(0, 500));
      console.log('[ISM Quotes v13.0] Strategy 0 citations:', JSON.stringify(citations.slice(0, 3)));
      
      // Check if we got PRNewswire citation
      const hasPRNewswire = citations.some(c => 
        (typeof c === 'string' && c.includes('prnewswire.com')) ||
        (c?.url && c.url.includes('prnewswire.com'))
      );
      console.log('[ISM Quotes v13.0] Has PRNewswire citation:', hasPRNewswire);
      
      // Parse using multiple methods
      let quotes = this.parseNumberedQuotes(content);
      
      // Filter out "General Manufacturing" - we want specific industries
      quotes = quotes.filter(q => {
        const industry = (q.industry || '').toLowerCase();
        return !industry.includes('general') && industry.length > 3;
      });
      
      if (quotes.length < 3) {
        const v3Quotes = this.parseQuotesV3(content);
        const filteredV3 = v3Quotes.filter(q => {
          const industry = (q.industry || '').toLowerCase();
          return !industry.includes('general') && industry.length > 3;
        });
        if (filteredV3.length > quotes.length) {
          quotes = filteredV3;
        }
      }
      
      if (quotes.length < 3) {
        const formatQuotes = this.parseIndustryQuoteFormat(content);
        const filteredFormat = formatQuotes.filter(q => {
          const industry = (q.industry || '').toLowerCase();
          return !industry.includes('general') && industry.length > 3;
        });
        if (filteredFormat.length > quotes.length) {
          quotes = filteredFormat;
        }
      }
      
      if (quotes.length >= 3) {
        console.log(`[ISM Quotes v13.0] Strategy 0 SUCCESS: ${quotes.length} quotes with specific industries`);
        return quotes.map(q => ({ ...q, isVerified: hasPRNewswire, source: 'PRNewswire' }));
      }
      
      console.log(`[ISM Quotes v13.0] Strategy 0: Only found ${quotes.length} quotes with specific industries`);
      return quotes.length > 0 ? quotes : null;
      
    } catch (error) {
      console.error('[ISM Quotes v13.0] Strategy 0 error:', error.message);
      return null;
    }
  }

  // ============================================
  // SUMMARY FILTER - Validates quote is real, not a report summary
  // ============================================
// ============================================
  // SUMMARY FILTER v2.0 - Validates quote is real, not a report summary
  // ============================================
  isRealQuoteNotSummary(quoteText) {
    const text = quoteText.toLowerCase();
    
    // ═══════════════════════════════════════════════════════════════
    // ❌ REJECT: These phrases appear in ISM REPORT SUMMARIES
    //    (Susan Spence statements), not in real executive quotes
    // ═══════════════════════════════════════════════════════════════
    const summaryIndicators = [
  // PMI/Index references (Susan Spence language)
  'manufacturing pmi',
  'manufacturing activity',
  'composite pmi',
  'index registered',
  'pmi registered',
  'pmi®',
  
  // Statistical language
  'contracted at',
  'expanded at',
  'percentage point',
  'consecutive month',
  'gdp contracted',
  'gdp expanded',
  'compared to',
  'percent of respondents',
  'matching the previous',
  
  // ISM report structure phrases
  'panelists',
  'six largest manufacturing',
  'still the norm at their companies',
  'of the six big',
  'of the six largest',
  
  // ★★★ Fake "reported" phrases from Perplexity ★★★
  'reported growth',
  'reported contraction',
  'reported increased',
  'reported decreased',
  'reported stable',
  'reported expansion',
  'reported improvement',
  'reported higher',
  'reported lower',
  
  // ★★★ NEW: Industry list patterns (definitely summaries) ★★★
  'industries reporting growth',
  'industries reporting contraction',
  'industries that reported',
  'the following order',
  'in the following order',
  'listed in order',
  
  // ★★★ NEW: Susan Spence attribution ★★★
  'susan spence',
  'spence said',
  'spence says',
  'says spence',
  'ism chair',
  'survey committee',
  
  // ★★★ NEW: Report summary phrases ★★★
  'for every positive comment',
  'for every comment',
  'ratio of positive to negative',
  '1-to-1 ratio',
  'positive to negative comments',
  'the four manufacturing',
  'the five manufacturing',
  'the six manufacturing',
  'the seven manufacturing',
  
  // ★★★ NEW v15.0: Susan Spence style summaries - THE MAIN FIX ★★★
  'survey respondents',
  'respondents continue',
  'respondents in several',
  'respondents are expecting',
  'continue to report',
  'substantial struggles',
  'expecting to see larger changes',
  'larger changes to revenue',
  'cited the lack',
  'impediment to planning',
  'some respondents',
  'several industries',
  'demand remains soft',
  'companies are',
  'panelists reported',
  'majority of panelists',
  'comments were generally',
  'sentiment was',
  'outlook remains',
];
    
    for (const indicator of summaryIndicators) {
      if (text.includes(indicator)) {
        console.log(`[Quote Filter] ❌ SUMMARY detected ("${indicator}"): "${text.substring(0, 60)}..."`);
        return false;
      }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ❌ REJECT: Summaries often start with these patterns
    // ═══════════════════════════════════════════════════════════════
    const summaryStarts = [
      // Temporal references at start
      'in november', 'in december', 'in october', 'in september',
      'in august', 'in july', 'in june', 'in may',
      'in april', 'in march', 'in february', 'in january',
      
      // Report language starts
      'regarding output',
      'looking at the',
      'of the six',
      'another month',
      'the manufacturing',
      'u.s. manufacturing',
      'economic activity',
      
      // List starters (industry summaries)
      'the four',
      'the five', 
      'the six',
      'the seven',
      'the eight',
    ];
    
    for (const start of summaryStarts) {
      if (text.startsWith(start)) {
        console.log(`[Quote Filter] ❌ SUMMARY detected (starts "${start}"): "${text.substring(0, 60)}..."`);
        return false;
      }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ❌ REJECT: Pattern matching for industry lists
    // ═══════════════════════════════════════════════════════════════
    // Pattern: "(Industry A; Industry B; Industry C)" - this is a summary list
    const industryListPattern = /\([^)]*;[^)]*;[^)]*\)/;
    if (industryListPattern.test(text)) {
      console.log(`[Quote Filter] ❌ SUMMARY detected (industry list pattern): "${text.substring(0, 60)}..."`);
      return false;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ✅ REQUIRE: Real executive quotes must have operational language
    //    At least ONE of these indicators should be present
    // ═══════════════════════════════════════════════════════════════
    const realQuoteIndicators = [
      // First-person language (executives speaking)
      ' we ', " we're ", " we've ", ' our ', ' my ', ' i ',
      ' us ', " i'm ", " i've ",
      
      // Business operations
      'customer', 'order', 'inventory', 'supplier', 'lead time',
      'forecast', 'business', 'revenue', 'margin', 'profit',
      'sourcing', 'procurement', 'vendor', 'buyer',
      
      // Workforce
      'head count', 'headcount', 'workforce', 'staff', 'employee',
      'hiring', 'layoff', 'severance', 'reduction',
      
      // Trade/Policy
      'tariff', 'import', 'export', 'trade', 'policy',
      'shutdown', 'government',
      
      // Market conditions
      'pricing', 'demand', 'volatile', 'uncertainty', 'uncertain',
      'challenge', 'struggle', 'difficult', 'soft',
      
      // Specific operations
      'transit time', 'shipping', 'freight', 'delivery',
      'production', 'capacity', 'utilization',
    ];
    
    const hasRealIndicator = realQuoteIndicators.some(ind => text.includes(ind));
    
    // For shorter quotes (under 80 chars), require real indicators
    // For longer quotes, be more lenient
    if (!hasRealIndicator && text.length < 80) {
      console.log(`[Quote Filter] ❌ REJECTED (short quote, no real-quote indicators): "${text.substring(0, 60)}..."`);
      return false;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ✅ PASSED all filters
    // ═══════════════════════════════════════════════════════════════
    console.log(`[Quote Filter] ✅ PASSED: "${text.substring(0, 60)}..."`);
    return true;
  }
  // ============================================
  // Parse Numbered Quotes: 1. "quote" (Industry)
  // ============================================
  parseNumberedQuotes(text) {
    const quotes = [];
    const seen = new Set();
    
    // Pattern: 1. "quote text" (Industry)
    const pattern = /\d+\.\s*"([^"]{40,})"[^(]*\(([^)]+)\)/g;
    let match;
    
    while ((match = pattern.exec(text)) !== null) {
      const comment = match[1].trim();
      const industry = match[2].trim();
      
if (!seen.has(comment.substring(0, 50))) {
        seen.add(comment.substring(0, 50));
        
        // NEW: Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(comment)) {
          continue;
        }
        
        quotes.push({
          industry,
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment)
        });
      }
    }
    
    // Also try: 1. "[quote]" (Industry) with brackets
    const pattern2 = /\d+\.\s*\[?"([^"]{40,})"?\][^(]*\(([^)]+)\)/g;
    while ((match = pattern2.exec(text)) !== null) {
      const comment = match[1].trim();
      const industry = match[2].trim();
      
if (!seen.has(comment.substring(0, 50))) {
        seen.add(comment.substring(0, 50));
        
        // NEW: Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(comment)) {
          continue;
        }
        
        quotes.push({
          industry,
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment)
        });
      }
    }
    
    console.log(`[ISM Quotes] parseNumberedQuotes found ${quotes.length} quotes`);
    return quotes;
  }

  // ============================================
  // Parse INDUSTRY/QUOTE format
  // ============================================
  parseIndustryQuoteFormat(text) {
    const quotes = [];
    const seen = new Set();
    
    // Pattern 1: INDUSTRY: xxx\nQUOTE: xxx
    const pattern1 = /INDUSTRY:\s*([^\n]+)\s*\n\s*QUOTE:\s*"?([^"]+)"?/gi;
    let match;
    
    while ((match = pattern1.exec(text)) !== null) {
      const industry = match[1].trim();
      const comment = match[2].trim().replace(/^["']|["']$/g, '');
      
      if (comment.length > 30 && !seen.has(comment.substring(0, 50))) {
        seen.add(comment.substring(0, 50));
        quotes.push({
          industry,
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment)
        });
      }
    }
    
    // Pattern 2: **Industry Name**: "quote"
    const pattern2 = /\*\*([^*]+)\*\*[:\s]*"([^"]{40,})"/gi;
    while ((match = pattern2.exec(text)) !== null) {
      const industry = match[1].trim();
      const comment = match[2].trim();
      
if (!seen.has(comment.substring(0, 50))) {
        seen.add(comment.substring(0, 50));
        
        // NEW: Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(comment)) {
          continue;
        }
        
        quotes.push({
          industry,
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment)
        });
      }
    }
    
    // Pattern 3: - "quote" (Industry)
    const pattern3 = /[-•*]\s*"([^"]{40,})"\s*\(([^)]+)\)/gi;
    while ((match = pattern3.exec(text)) !== null) {
      const comment = match[1].trim();
      const industry = match[2].trim();
      
if (!seen.has(comment.substring(0, 50))) {
        seen.add(comment.substring(0, 50));
        
        // NEW: Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(comment)) {
          continue;
        }
        
        quotes.push({
          industry,
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment)
        });
      }
    }
    
    // Pattern 4: Numbered list - 1. "quote" (Industry)
    const pattern4 = /\d+\.\s*"([^"]{40,})"\s*\(([^)]+)\)/gi;
    while ((match = pattern4.exec(text)) !== null) {
      const comment = match[1].trim();
      const industry = match[2].trim();
      
if (!seen.has(comment.substring(0, 50))) {
        seen.add(comment.substring(0, 50));
        
        // NEW: Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(comment)) {
          continue;
        }
        
        quotes.push({
          industry,
          comment,
          sentiment: this.detectSentiment(comment),
          keyTheme: this.detectTheme(comment)
        });
      }
    }
    
    return quotes;
  }

  // ============================================
  // Sentiment Detection Helper
  // ============================================
  detectSentiment(text) {
    const lower = text.toLowerCase();
    const negative = ['struggle', 'difficult', 'weak', 'decline', 'uncertain', 'soft', 'concern', 
                      'challenge', 'tariff', 'contraction', 'reduction', 'layoff', 'cut'];
    const positive = ['growth', 'strong', 'increase', 'improve', 'optimis', 'recover', 'expand'];
    
    const negCount = negative.filter(w => lower.includes(w)).length;
    const posCount = positive.filter(w => lower.includes(w)).length;
    
    if (negCount > posCount) return 'negative';
    if (posCount > negCount) return 'positive';
    return 'neutral';
  }

  // ============================================
  // Theme Detection Helper
  // ============================================
  detectTheme(text) {
    const lower = text.toLowerCase();
    if (lower.includes('tariff')) return 'tariffs';
    if (lower.includes('supply chain') || lower.includes('supplier')) return 'supply_chain';
    if (lower.includes('demand') || lower.includes('order')) return 'demand';
    if (lower.includes('price') || lower.includes('cost')) return 'costs';
    if (lower.includes('employ') || lower.includes('staff') || lower.includes('head count')) return 'employment';
    if (lower.includes('uncertain')) return 'uncertainty';
    return 'general';
  }

  // ============================================
  // Strategy 1: ENHANCED Perplexity PRNewswire Search
  // ============================================
 async fetchQuotesStrategy1(month, monthName, ismURL) {
  try {
    console.log('[Perplexity] Strategy 1: Searching for ISM quotes on PRNewswire...');
    
    const [year, monthNum] = month.split('-');
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                        'July', 'August', 'September', 'October', 'November', 'December'];
    const fullMonthName = monthNames[parseInt(monthNum) - 1];
    
    const searchResponse = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.perplexityApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'sonar-pro',
        messages: [

          {
  role: 'user',
  content: `Search for: site:prnewswire.com "Manufacturing PMI" "${fullMonthName} ${year}" "WHAT RESPONDENTS ARE SAYING"

CRITICAL TASK: I need the EXECUTIVE QUOTES from the "WHAT RESPONDENTS ARE SAYING" section.

These are REAL quotes - they look like this (from a previous report as example):
- "New order entries are within the forecast. We have increased requests from customers to get their orders sooner." (Machinery)
- "We are starting to institute more permanent changes due to the tariff environment. This includes reduction of staff." (Transportation Equipment)
- "Tariffs and economic uncertainty continue to weigh on demand for adhesives and sealants." (Chemical Products)

REAL EXECUTIVE QUOTES have these characteristics:
✅ First-person language: "We", "Our", "I have"
✅ Specific operational details: orders, inventory, lead times, customers, pricing
✅ Industry-specific concerns: tariffs, supply chain, demand, costs
✅ Length: Usually 50-200 words
✅ End with specific industry in parentheses: (Machinery), (Chemical Products), (Transportation Equipment)

DO NOT RETURN these - they are REPORT SUMMARIES, not executive quotes:
❌ "Manufacturing activity contracted..." 
❌ "The PMI registered 48.2 percent..."
❌ "Panelists had a 1-to-1 ratio..."
❌ "(Industry A; Industry B; Industry C) reported growth"
❌ "Of the six largest manufacturing industries..."
❌ Any text from Susan Spence (ISM Chair)

Find the PRNewswire ISM press release for ${fullMonthName} ${year} and extract ONLY the bullet-point quotes from "WHAT RESPONDENTS ARE SAYING" section.

Return format (one per line):
"[exact executive quote]" (Industry Name)

If you cannot find real executive quotes, respond with: QUOTES_NOT_FOUND`
}
        ],
        temperature: 0,
        max_tokens: 4000,
        search_recency_filter: 'month',
        return_citations: true,
      }),
    });

    if (!searchResponse.ok) {
      const errorText = await searchResponse.text();
      console.error(`[Perplexity] Strategy 1 HTTP error: ${searchResponse.status}`, errorText);
      return null;
    }

    const searchData = await searchResponse.json();
    const rawContent = searchData.choices?.[0]?.message?.content || '';
    const citations = searchData.citations || [];
    
    console.log('[Perplexity] Strategy 1 response length:', rawContent.length);
    console.log('[Perplexity] Strategy 1 citations:', citations.length > 0 ? JSON.stringify(citations.slice(0, 3)) : 'NONE');
    
    // Check if Perplexity couldn't find the quotes
    if (rawContent.includes('QUOTES NOT FOUND') || rawContent.includes('could not find') || rawContent.includes('unable to locate')) {
      console.warn('[Perplexity] Strategy 1: Could not find quotes');
      return null;
    }
    
    // Verify response contains real ISM quote indicators
    const realQuoteIndicators = [
      'tariff', 'Machinery', 'Transportation Equipment', 'Chemical Products',
      'Computer & Electronic', 'Food, Beverage', 'Fabricated Metal',
      'shutdown', 'uncertainty', 'sourcing', 'orders', 'demand'
    ];
    
    const hasRealQuotes = realQuoteIndicators.some(indicator => 
      rawContent.toLowerCase().includes(indicator.toLowerCase())
    );
    
    if (!hasRealQuotes) {
      console.warn('[Perplexity] Strategy 1: Response does not contain expected ISM quote indicators');
      console.log('[Perplexity] Response preview:', rawContent.substring(0, 600));
      return null;
    }
    
    // Parse quotes from response
    const quotes = this.parseQuotesFromText(rawContent, month);
    
    if (quotes.length >= 3) {
      console.log(`[Perplexity] ✓ Strategy 1 SUCCESS: Extracted ${quotes.length} real quotes`);
      
      const hasPRNCitation = citations.some(c => 
        (typeof c === 'string' && c.includes('prnewswire.com')) ||
        (c?.url && c.url.includes('prnewswire.com'))
      );
      
      return quotes.map(q => ({
        ...q,
        source: hasPRNCitation ? 'ISM Official via PRNewswire' : 'Perplexity Web Search',
        isVerified: hasPRNCitation,
      }));
    }
    
    console.warn(`[Perplexity] Strategy 1: Only found ${quotes.length} quotes`);
    return quotes.length > 0 ? quotes : null;
    
  } catch (error) {
    console.error('[Perplexity] Strategy 1 error:', error.message);
    return null;
  }
}

  // ============================================
  // Strategy 2: PRNewswire focused search
  // ============================================
  async fetchQuotesStrategy2(month, monthName) {
    try {
      console.log('[Perplexity] Strategy 2: Broader PRNewswire search...');
      
      const [year, monthNum] = month.split('-');
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];
      const fullMonthName = monthNames[parseInt(monthNum) - 1];
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [
            {
              role: 'user',
content: `Search prnewswire.com for "ISM Manufacturing PMI ${fullMonthName} ${year}" press release.

CRITICAL: I need REAL executive quotes from "WHAT RESPONDENTS ARE SAYING" section.

❌ WRONG - DO NOT RETURN these (they are summaries, NOT quotes):
- "Reported growth in November"
- "Reported contraction in November"  
- "Manufacturing activity contracted"
- "Survey respondents continue to cite"
- "Panelists reported"
- Any mention of "PMI registered" or "index"

✅ CORRECT - These are REAL executive quotes I need:
- "New order entries are within the forecast. We have increased requests from customers." (Machinery)
- "We are starting to institute more permanent changes due to tariffs." (Transportation Equipment)
- "Tariffs and economic uncertainty continue to weigh on demand." (Chemical Products)

REAL quotes have:
- First-person: "we", "our", "customers"
- Operational details: orders, inventory, suppliers
- 50+ characters
- Industry in parentheses at end

Format:
1. "[exact quote]" (Industry Name)
2. "[exact quote]" (Industry Name)

If no REAL quotes found, return: QUOTES_NOT_FOUND`
            }
          ],
          temperature: 0,
          max_tokens: 4000,
          search_recency_filter: 'month',
          return_citations: true,
        }),
      });

      if (!response.ok) {
        console.error(`[Perplexity] Strategy 2 HTTP error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      const citations = data.citations || [];
      
      console.log('[Perplexity] Strategy 2 response length:', content.length);
      console.log('[Perplexity] Strategy 2 citations:', citations.length);
      
      // Parse quotes from response
      const quotes = this.parseQuotesFromText(content, month);
      
      if (quotes.length >= 3) {
        console.log(`[Perplexity] ✓ Strategy 2 SUCCESS: Found ${quotes.length} quotes`);
        return quotes.map(q => ({
          ...q,
          source: 'ISM via PRNewswire',
          isVerified: citations.some(c => 
            (typeof c === 'string' && c.includes('prnewswire.com')) ||
            (c?.url && c.url.includes('prnewswire.com'))
          ),
        }));
      }
      
      // Try JSON extraction as fallback
      const jsonQuotes = this.extractJSON(content);
      if (Array.isArray(jsonQuotes) && jsonQuotes.length >= 3) {
        return jsonQuotes.filter(q => q.industry && q.comment && q.comment.length > 20);
      }
      
      console.log(`[Perplexity] Strategy 2: Only found ${quotes.length} quotes`);
      return quotes.length > 0 ? quotes : null;
      
    } catch (error) {
      console.error('[Perplexity] Strategy 2 error:', error.message);
      return null;
    }
  }

  // ============================================
  // Strategy 3: Direct quote extraction with simpler prompt
  // ============================================
  async fetchQuotesStrategy3(month, monthName) {
    try {
      console.log('[Perplexity] Strategy 3: General ISM quote search...');
      
      const [year, monthNum] = month.split('-');
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];
      const fullMonthName = monthNames[parseInt(monthNum) - 1];
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar',
          messages: [
            {
              role: 'user',
content: `ISM Manufacturing Report ${fullMonthName} ${year} - Executive quotes needed.

CRITICAL: Find REAL quotes from purchasing managers (NOT summaries).

❌ WRONG (DO NOT include):
- "Reported growth/contraction in..."
- "Manufacturing PMI registered..."
- "Survey respondents..."
- Anything with "panelists" or "index"

✅ CORRECT (I NEED these):
- "We are seeing increased demand from customers." (Machinery)
- "Our suppliers are extending lead times." (Chemical Products)
- "Tariff uncertainty impacts our planning." (Transportation Equipment)

Requirements:
1. First-person: "we", "our", "customers"
2. Operational details
3. 50+ characters
4. Industry in parentheses

Format:
- "[exact quote]" (Industry Name)

Only return REAL quotes, not summaries.`  }
          ],
          temperature: 0,
          max_tokens: 3000,
          search_recency_filter: 'month',
          return_citations: true,
        }),
      });

      if (!response.ok) {
        console.error(`[Perplexity] Strategy 3 HTTP error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      
      console.log('[Perplexity] Strategy 3 response length:', content.length);
      
      // Parse quotes
      const quotes = this.parseQuotesFromText(content, month);
      
      if (quotes.length >= 2) {
        console.log(`[Perplexity] ✓ Strategy 3 found ${quotes.length} quotes`);
        return quotes.map(q => ({
          ...q,
          source: 'Perplexity Web Search',
          isVerified: false,
        }));
      }
      
      return null;
      
    } catch (error) {
      console.error('[Perplexity] Strategy 3 error:', error.message);
      return null;
    }
  }

  // ============================================
  // Strategy 4: Direct PRNewswire URL Fetch - NEW in v10.4
  // Two-step approach: Find URL → Read quotes
  // ============================================
  async fetchQuotesStrategy4(month, monthName) {
    try {
      console.log('[Perplexity] Strategy 4: Direct PRNewswire page fetch...');
      
      const [year, monthNum] = month.split('-');
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];
      const fullMonthName = monthNames[parseInt(monthNum) - 1];
      
      // Step 1: Find the PRNewswire URL
      const findURLResponse = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar',
          messages: [
            {
              role: 'user',
              content: `Find the prnewswire.com URL for the ISM Manufacturing PMI press release for ${fullMonthName} ${year}.

The URL looks like: prnewswire.com/news-releases/manufacturing-pmi-at-XX-X-MONTH-YEAR-ism-manufacturing-pmi-report-XXXXXXX.html

Give me only the URL.`
            }
          ],
          temperature: 0,
          max_tokens: 500,
          search_recency_filter: 'month',
          return_citations: true,
        }),
      });

      if (!findURLResponse.ok) {
        console.error('[Perplexity] Strategy 4: Failed to find PRNewswire URL');
        return null;
      }

      const urlData = await findURLResponse.json();
      const urlContent = urlData.choices?.[0]?.message?.content || '';
      const citations = urlData.citations || [];
      
      // Extract PRNewswire URL
      let prnURL = null;
      
      // Check citations first
      for (const citation of citations) {
        const url = typeof citation === 'string' ? citation : citation?.url;
        if (url && url.includes('prnewswire.com') && url.includes('ism') && url.includes('manufacturing')) {
          prnURL = url;
          break;
        }
      }
      
      // Try content if not in citations
      if (!prnURL) {
        const urlMatch = urlContent.match(/(https?:\/\/[^\s]+prnewswire\.com[^\s]+manufacturing[^\s]+)/i);
        if (urlMatch) {
          prnURL = urlMatch[1].replace(/[.,;:!?\)]+$/, '');
        }
      }
      
      if (!prnURL) {
        console.log('[Perplexity] Strategy 4: Could not find PRNewswire URL');
        return null;
      }
      
      console.log(`[Perplexity] Strategy 4: Found PRNewswire URL: ${prnURL}`);
      
      // Step 2: Fetch quotes from that URL
      const quotesResponse = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [
            {
              role: 'system',
              content: `You are a text extraction robot. You can ONLY copy text character-by-character.

ABSOLUTE RULES:
1. COPY ONLY - never summarize, never paraphrase, never reword
2. Every character must match the source exactly
3. Do not add, remove, or change any words
4. If unsure, output: "EXTRACTION FAILED"

You are a scanner, not a writer.`
            },
            {
              role: 'user',
              content: `ACCESS: ${prnURL}

TASK: Find "WHAT RESPONDENTS ARE SAYING" section.

This section contains 10 bullet points that look like:
* "Exact quote text here word for word." (Industry Name)

EXTRACTION INSTRUCTIONS:
1. Copy the text between the quotation marks " "
2. Copy the industry name in parentheses ( )
3. Output format: "copied text exactly" (Industry Name)

CRITICAL: 
- Copy character by character - do not change ANY words
- Include full sentences, not snippets

START EXTRACTION:`
            }
          ],
          temperature: 0,
          max_tokens: 4000,
          return_citations: true,
        }),
      });

      if (!quotesResponse.ok) {
        console.error('[Perplexity] Strategy 4: Failed to fetch quotes');
        return null;
      }

      const quotesData = await quotesResponse.json();
      const quotesContent = quotesData.choices?.[0]?.message?.content || '';
      
      console.log('[Perplexity] Strategy 4 quotes response length:', quotesContent.length);
      
      const quotes = this.parseQuotesFromText(quotesContent, month);
      
      if (quotes.length >= 3) {
        console.log(`[Perplexity] ✓ Strategy 4 SUCCESS: Extracted ${quotes.length} quotes from PRNewswire`);
        return quotes.map(q => ({
          ...q,
          source: 'ISM via PRNewswire (direct)',
          isVerified: true,
        }));
      }
      
      return quotes.length > 0 ? quotes : null;
      
    } catch (error) {
      console.error('[Perplexity] Strategy 4 error:', error.message);
      return null;
    }
  }

// ============================================
  // Strategy 1: Best Perplexity Prompt V2
  // ============================================
  async fetchQuotesPerplexityV2(month, fullMonthName, year) {
    try {
      console.log('[Perplexity V2] Starting...');
      
      // Build more specific search query
      const searchTerms = [
        `site:prnewswire.com "ISM Manufacturing PMI" "${fullMonthName} ${year}"`,
        `"WHAT RESPONDENTS ARE SAYING"`,
        `"Manufacturing PMI at"`,
      ].join(' ');
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [
            {
              role: 'system',
              content: `You are a data extraction specialist. Your ONLY job is to find and copy verbatim quotes from official ISM press releases.

CRITICAL INSTRUCTIONS:
1. Search for the PRNewswire press release titled "Manufacturing PMI at XX.X" for ${fullMonthName} ${year}
2. Find the section "WHAT RESPONDENTS ARE SAYING" 
3. COPY each bullet point EXACTLY - do not paraphrase, do not summarize, do not change any words
4. The format is: * "Quote text" (Industry Name)
5. There should be approximately 10 bullet points
6. If you cannot find the exact press release, say "QUOTES_NOT_FOUND"

IMPORTANT: Real ISM quotes contain specific operational details like:
- Order volumes, lead times, delivery schedules
- Supply chain issues, tariffs, sourcing
- Customer behavior, inventory levels
- Specific products or components mentioned

DO NOT generate generic statements like "Reported growth in orders" or "Facing challenges" - these are NOT real quotes.`
            },
            {
              role: 'user',
content: `Find the official ISM Manufacturing press release on PRNewswire for ${fullMonthName} ${year}.

The press release title contains "Manufacturing PMI at" and is published by "Institute for Supply Management".

Locate the "WHAT RESPONDENTS ARE SAYING" section and copy EVERY bullet point exactly as written.

Format your response as:
1. "exact quote text" (Industry Name)
2. "exact quote text" (Industry Name)
...and so on

DO NOT paraphrase. DO NOT summarize. COPY the exact text.

If you cannot find the press release, respond only with: QUOTES_NOT_FOUND`
            }
          ],
          temperature: 0,
          max_tokens: 6000,
          web_search_options: {
            search_context_size: "high"
          },
          return_citations: true,
        }),
      });

      if (!response.ok) {
        console.error(`[Perplexity V2] HTTP error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      const citations = data.citations || [];
      
      console.log('[Perplexity V2] Response length:', content.length);
      console.log('[Perplexity V2] First 500 chars:', content.substring(0, 500));
      console.log('[Perplexity V2] Citations:', citations.length);
      
      if (content.includes('QUOTES_NOT_FOUND') || content.length < 200) {
        console.log('[Perplexity V2] Quotes not found');
        return null;
      }
      
      const quotes = this.parseQuotesV3(content);
      console.log(`[Perplexity V2] Parsed ${quotes.length} quotes`);
      
      if (quotes.length >= 3) {
        const hasOfficial = citations.some(c => {
          const url = typeof c === 'string' ? c : c?.url;
          return url && (url.includes('prnewswire.com') || url.includes('ismworld.org'));
        });
        
        return quotes.map(q => ({
          ...q,
          source: hasOfficial ? 'ISM Official via PRNewswire' : 'ISM via Web Search',
          isVerified: hasOfficial,
        }));
      }
      
      return quotes.length > 0 ? quotes : null;
      
    } catch (error) {
      console.error('[Perplexity V2] Error:', error.message);
      return null;
    }
  }

  // ============================================
  // Strategy 2: Direct Copy
  // ============================================
  async fetchQuotesDirectCopy(month, fullMonthName, year) {
    try {
      console.log('[Direct Copy] Starting...');
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [
            {
              role: 'user',
              content: `Find PRNewswire press release: "Manufacturing PMI ${fullMonthName} ${year}" from ISM.

In that press release there is a section "WHAT RESPONDENTS ARE SAYING" with bullet points like:
* "Quote text here" (Industry Name)

Copy and paste EVERY quote from that section.
Do not change any words - copy exactly.

Format each quote as:
"[full quote]" (Industry Name)

Start listing quotes:`
            }
          ],
          temperature: 0,
          max_tokens: 5000,
          search_recency_filter: 'month',
          return_citations: true,
        }),
      });

      if (!response.ok) return null;

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      
      console.log('[Direct Copy] Response length:', content.length);
      
      const quotes = this.parseQuotesV3(content);
      
      return quotes.length >= 2 ? quotes.map(q => ({
        ...q,
        source: 'ISM via PRNewswire',
        isVerified: true,
      })) : null;
      
    } catch (error) {
      console.error('[Direct Copy] Error:', error.message);
      return null;
    }
  }

  // ============================================
  // Strategy 3: Simple Search - Enhanced
  // ============================================
  async fetchQuotesSimple(month, fullMonthName, year) {
    try {
      console.log('[Simple] Starting enhanced search...');
      
      // Try multiple search approaches
      const searches = [
        {
          query: `ISM Manufacturing PMI ${fullMonthName} ${year} "WHAT RESPONDENTS ARE SAYING" site:prnewswire.com`,
          name: 'PRNewswire specific'
        },
        {
          query: `ISM Manufacturing Report ${fullMonthName} ${year} industry quotes purchasing managers`,
          name: 'General ISM'
        },
        {
          query: `"Manufacturing PMI" ${fullMonthName} ${year} executive quotes tariff supply chain`,
          name: 'Executive quotes'
        }
      ];
      
      for (const search of searches) {
        console.log(`[Simple] Trying: ${search.name}`);
        
        const response = await fetch('https://api.perplexity.ai/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.perplexityApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'sonar',
            messages: [
              {
                role: 'user',
                content: `${search.query}

Find quotes from manufacturing executives about business conditions. Each quote should be from a specific industry like Machinery, Transportation Equipment, Chemical Products, etc.

List each quote in this exact format:
"[exact quote text]" (Industry Name)

Only include real quotes that mention specific details about orders, supply chains, inventory, customers, tariffs, or operations. Do NOT include generic statements.`
              }
            ],
            temperature: 0,
            max_tokens: 4000,
            return_citations: true,
          }),
        });

        if (!response.ok) continue;

        const data = await response.json();
        const content = data.choices?.[0]?.message?.content || '';
        const citations = data.citations || [];
        
        console.log(`[Simple] ${search.name} response: ${content.length} chars, ${citations.length} citations`);
        
        const quotes = this.parseQuotesV3(content);
        
        if (quotes.length >= 3) {
          console.log(`[Simple] ✓ SUCCESS with ${search.name}: Found ${quotes.length} quotes`);
          return quotes.map(q => ({
            ...q,
            source: `ISM via ${search.name}`,
            isVerified: citations.some(c => {
              const url = typeof c === 'string' ? c : c?.url;
              return url && (url.includes('prnewswire.com') || url.includes('ismworld.org'));
            }),
          }));
        }
      }
      
      console.log('[Simple] All searches failed');
      return null;
      
    } catch (error) {
      console.error('[Simple] Error:', error.message);
      return null;
    }
  }
  
  // ============================================
  // Strategy 4: ISM World Direct - NEW
  // ============================================
  async fetchQuotesISMWorldDirect(month, fullMonthName, year) {
    try {
      console.log('[ISM World Direct] Starting...');
      
      const ismURL = this.getISMReportURL(month);
      console.log(`[ISM World Direct] Target URL: ${ismURL}`);
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar-pro',
          messages: [
            {
              role: 'user',
              content: `Go to ${ismURL} and find the "WHAT RESPONDENTS ARE SAYING" section.

This section contains quotes from manufacturing executives about their business conditions.

Copy each quote exactly as it appears on the page. The format is:
"Quote text" (Industry Name like Machinery, Transportation Equipment, etc.)

List all quotes you find. Do not summarize or paraphrase - copy the exact words.

If the page is not available or quotes cannot be found, say: QUOTES_NOT_FOUND`
            }
          ],
          temperature: 0,
          max_tokens: 5000,
          return_citations: true,
        }),
      });

      if (!response.ok) {
        console.error(`[ISM World Direct] HTTP error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      const citations = data.citations || [];
      
      console.log('[ISM World Direct] Response:', content.length, 'chars');
      
      if (content.includes('QUOTES_NOT_FOUND')) {
        console.log('[ISM World Direct] Quotes not found');
        return null;
      }
      
      const quotes = this.parseQuotesV3(content);
      
      if (quotes.length >= 2) {
        console.log(`[ISM World Direct] ✓ Found ${quotes.length} quotes`);
        return quotes.map(q => ({
          ...q,
          source: 'ISM World Direct',
          isVerified: citations.some(c => {
            const url = typeof c === 'string' ? c : c?.url;
            return url && url.includes('ismworld.org');
          }),
        }));
      }
      
      return null;
      
    } catch (error) {
      console.error('[ISM World Direct] Error:', error.message);
      return null;
    }
  }

  // ============================================
  // NEW Parser V3 - Better pattern matching
  // ============================================
  parseQuotesV3(text) {
    const quotes = [];
    const seen = new Set();
    
    if (!text || text.length < 100) return quotes;
    
    // Normalize quotes
    const normalized = text
      .replace(/[""„"«»]/g, '"')
      .replace(/[''`]/g, "'")
      .replace(/\r\n/g, '\n');
    
    // Patterns
    const patterns = [
      /"([^"]{40,800})"\s*\(([^)]+)\)/g,
      /\*\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
      /-\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
      /\d+[\.\)]\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
    ];
    
    for (const pattern of patterns) {
      let match;
      pattern.lastIndex = 0;
      
      while ((match = pattern.exec(normalized)) !== null) {
        const quoteText = match[1].trim();
        const industry = match[2].trim();
        
        // Validations
        if (quoteText.length < 40) continue;
        if (industry.length < 3 || industry.length > 60) continue;
        
        // Skip boilerplate
        const lower = quoteText.toLowerCase();
        if (lower.includes('seasonally adjusted') ||
            lower.includes('pmi®') ||
            lower.includes('ism®') ||
            lower.includes('report is based')) continue;
        
        // Skip fake quotes
        if (lower.startsWith('reported ') ||
            lower.includes('reported growth') ||
            lower.includes('reported contraction') ||
            lower.includes('remains stable') ||
            lower.includes('continues to')) continue;
        
        // Dedupe
// Dedupe
        const key = quoteText.substring(0, 60).toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        
        // NEW: Skip if this is a summary, not a real executive quote
        if (!this.isRealQuoteNotSummary(quoteText)) {
          continue;
        }
        
        quotes.push({
          industry: industry,
          comment: quoteText,
          sentiment: this.detectSentiment(quoteText),
          keyTheme: this.detectTheme(quoteText),
        });
      }
    }
    
    console.log(`[Parser V3] Found ${quotes.length} quotes`);
    return quotes;
  }

// ============================================
// IMPROVED Quote Parser - catches more patterns
// Add this as a new method in ISMDataService
// ============================================

parseQuotesFromTextV2(text, month) {
  const quotes = [];
  const seenQuotes = new Set();
  
  console.log('[Parser V2] Parsing text length:', text.length);
  
  // Normalize different quote characters
  const normalizedText = text
    .replace(/[""„"«»]/g, '"')  // Normalize all quote types
    .replace(/[''`]/g, "'")     // Normalize apostrophes
    .replace(/\r\n/g, '\n');    // Normalize line endings
  
  // Known ISM industry names (for validation)
  const knownIndustries = [
    'Machinery', 'Transportation Equipment', 'Chemical Products', 
    'Computer & Electronic Products', 'Food, Beverage & Tobacco',
    'Fabricated Metal Products', 'Electrical Equipment',
    'Miscellaneous Manufacturing', 'Primary Metals', 'Paper Products',
    'Plastics & Rubber Products', 'Textile Mills', 'Furniture',
    'Petroleum & Coal Products', 'Nonmetallic Mineral Products',
    'Wood Products', 'Printing', 'Apparel', 'Appliances & Components'
  ];
  
  // IMPROVED patterns - more flexible
  const patterns = [
    // Pattern 1: "Quote" (Industry) - most common format
    /"([^"]{40,800})"\s*\(([^)]+)\)/g,
    
    // Pattern 2: * "Quote" (Industry) - bullet format
    /\*\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
    
    // Pattern 3: - "Quote" (Industry) - dash format
    /-\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
    
    // Pattern 4: 1. "Quote" (Industry) - numbered
    /\d+[\.\)]\s*"([^"]{40,800})"\s*\(([^)]+)\)/g,
    
    // Pattern 5: **Industry**: "Quote" - markdown bold
    /\*\*([^*]+)\*\*:\s*"([^"]{40,800})"/g,
    
    // Pattern 6: Industry: "Quote" - simple colon
    /^([A-Z][A-Za-z,\s&]+):\s*"([^"]{40,800})"/gm,
  ];
  
  for (const pattern of patterns) {
    let match;
    pattern.lastIndex = 0;
    
    while ((match = pattern.exec(normalizedText)) !== null) {
      let quoteText, industry;
      
      // Pattern 5 and 6 have industry first
      if (pattern.source.includes('\\*\\*([^*]+)\\*\\*') || pattern.source.startsWith('^([A-Z]')) {
        industry = match[1].trim().replace(/\*/g, '');
        quoteText = match[2].trim();
      } else {
        quoteText = match[1].trim();
        industry = match[2].trim();
      }
      
      // Clean up industry name
      industry = industry.replace(/^\*+|\*+$/g, '').trim();
      
      // Skip if quote is too short
      if (quoteText.length < 40) {
        console.log(`[Parser V2] ⊘ Skipped (too short): "${quoteText.substring(0, 30)}..."`);
        continue;
      }
      
      // Skip boilerplate text
      const lowerQuote = quoteText.toLowerCase();
      if (lowerQuote.includes('seasonally adjusted') || 
          lowerQuote.includes('pmi®') ||
          lowerQuote.includes('ism®') ||
          lowerQuote.includes('report is based') ||
          lowerQuote.includes('institute for supply management')) {
        console.log(`[Parser V2] ⊘ Skipped (boilerplate): "${quoteText.substring(0, 30)}..."`);
        continue;
      }
      
      // Skip if industry name is invalid
      if (industry.length < 3 || industry.length > 60) {
        console.log(`[Parser V2] ⊘ Skipped (bad industry name): "${industry}"`);
        continue;
      }
      
      // Deduplicate
      const quoteKey = quoteText.substring(0, 60).toLowerCase().replace(/\s+/g, ' ');
      if (seenQuotes.has(quoteKey)) continue;
      seenQuotes.add(quoteKey);
      
      console.log(`[Parser V2] ✓ Found: "${quoteText.substring(0, 50)}..." (${industry})`);
      
      quotes.push({
        industry: industry,
        comment: quoteText,
        sentiment: this.detectSentiment(quoteText),
        keyTheme: this.detectTheme(quoteText),
      });
    }
  }
  
  console.log(`[Parser V2] Total quotes extracted: ${quotes.length}`);
  return quotes;
}
  // ============================================
  // Quote Parser - ENHANCED v10.4
  // Multiple patterns for different quote formats
  // ============================================
 parseQuotesFromText(text, month) {
    const quotes = [];
    const seenQuotes = new Set();
    
    // Pattern 1: "Quote text" (Industry Name)
    const pattern1 = /"([^"]{30,600})"\s*\(([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)\)/g;
    let match;
    while ((match = pattern1.exec(text)) !== null) {
      const quoteKey = match[1].substring(0, 50).toLowerCase();
      if (!seenQuotes.has(quoteKey)) {
        seenQuotes.add(quoteKey);
        
        // Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(match[1])) {
          continue;
        }
        
        quotes.push({
          industry: match[2].trim(),
          comment: match[1].trim(),
          sentiment: this.detectSentiment(match[1]),
          keyTheme: this.detectTheme(match[1]),
        });
      }
    }
    
    // Pattern 2: * "Quote text" (Industry Name) - bullet point format
    const pattern2 = /\*\s*"([^"]{30,600})"\s*\(([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)\)/g;
    while ((match = pattern2.exec(text)) !== null) {
      const quoteKey = match[1].substring(0, 50).toLowerCase();
      if (!seenQuotes.has(quoteKey)) {
        seenQuotes.add(quoteKey);
        
        // Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(match[1])) {
          continue;
        }
        
        quotes.push({
          industry: match[2].trim(),
          comment: match[1].trim(),
          sentiment: this.detectSentiment(match[1]),
          keyTheme: this.detectTheme(match[1]),
        });
      }
    }
    
    // Pattern 3: - "Quote text" (Industry Name) - dash bullet format
    const pattern3 = /-\s*"([^"]{30,600})"\s*\(([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)\)/g;
    while ((match = pattern3.exec(text)) !== null) {
      const quoteKey = match[1].substring(0, 50).toLowerCase();
      if (!seenQuotes.has(quoteKey)) {
        seenQuotes.add(quoteKey);
        
        // Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(match[1])) {
          continue;
        }
        
        quotes.push({
          industry: match[2].trim(),
          comment: match[1].trim(),
          sentiment: this.detectSentiment(match[1]),
          keyTheme: this.detectTheme(match[1]),
        });
      }
    }
    
    // Pattern 4: **Industry Name**: "Quote text" - bold industry format
    const pattern4 = /\*?\*?([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?))\*?\*?[:\s]+"([^"]{30,600})"/g;
    while ((match = pattern4.exec(text)) !== null) {
      const quoteKey = match[2].substring(0, 50).toLowerCase();
      if (!seenQuotes.has(quoteKey)) {
        seenQuotes.add(quoteKey);
        
        // Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(match[2])) {
          continue;
        }
        
        quotes.push({
          industry: match[1].trim().replace(/\*/g, ''),
          comment: match[2].trim(),
          sentiment: this.detectSentiment(match[2]),
          keyTheme: this.detectTheme(match[2]),
        });
      }
    }
    
    // Pattern 5: Numbered list - 1. "Quote" (Industry)
    const pattern5 = /\d+\.\s*"([^"]{30,600})"\s*\(([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)\)/g;
    while ((match = pattern5.exec(text)) !== null) {
      const quoteKey = match[1].substring(0, 50).toLowerCase();
      if (!seenQuotes.has(quoteKey)) {
        seenQuotes.add(quoteKey);
        
        // Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(match[1])) {
          continue;
        }
        
        quotes.push({
          industry: match[2].trim(),
          comment: match[1].trim(),
          sentiment: this.detectSentiment(match[1]),
          keyTheme: this.detectTheme(match[1]),
        });
      }
    }
    
    // Pattern 6: "Quote text" - Industry Name (alternate dash format)
    const pattern6 = /"([^"]{30,600})"\s*[-–—]\s*([A-Za-z,\s&]+(?:Products?|Equipment|Manufacturing|Metals?)?)/g;
    while ((match = pattern6.exec(text)) !== null) {
      const quoteKey = match[1].substring(0, 50).toLowerCase();
      if (!seenQuotes.has(quoteKey)) {
        seenQuotes.add(quoteKey);
        
        // Skip if this is a summary, not a real quote
        if (!this.isRealQuoteNotSummary(match[1])) {
          continue;
        }
        
        quotes.push({
          industry: match[2].trim(),
          comment: match[1].trim(),
          sentiment: this.detectSentiment(match[1]),
          keyTheme: this.detectTheme(match[1]),
        });
      }
    }
    
    console.log(`[Parser] Extracted ${quotes.length} unique quotes from text`);
    return quotes;
  }

  // ============================================
  // Sentiment Detection - ENHANCED v10.4
  // ============================================
  detectSentiment(text) {
    const lower = text.toLowerCase();
    
    const negativeWords = ['struggle', 'weak', 'decline', 'uncertain', 'soft', 'concern', 
                          'challenge', 'difficult', 'pressure', 'reduce', 'cut', 'layoff',
                          'tariff', 'shutdown', 'eroding', 'lackluster', 'apprehensive',
                          'volatile', 'confusion', 'trying', 'undermined', 'clouded',
                          'slower', 'lower', 'weakening', 'contraction', 'negative'];
    const positiveWords = ['strong', 'growth', 'increase', 'improve', 'stable', 'solid',
                          'recovery', 'optimis', 'expand', 'demand remains', 'successfully',
                          'within forecast', 'normalizing', 'good', 'better', 'higher',
                          'accelerat', 'positive', 'strength'];
    
    const negCount = negativeWords.filter(w => lower.includes(w)).length;
    const posCount = positiveWords.filter(w => lower.includes(w)).length;
    
    if (negCount > posCount + 1) return 'negative';
    if (posCount > negCount + 1) return 'positive';
    return 'neutral';
  }

  // ============================================
  // Theme Detection - ENHANCED v10.4
  // ============================================
  detectTheme(text) {
    const lower = text.toLowerCase();
    
    if (lower.includes('tariff')) return 'tariffs';
    if (lower.includes('trade') && (lower.includes('confus') || lower.includes('uncertain'))) return 'tariffs';
    if (lower.includes('price') || lower.includes('cost') || lower.includes('margin')) return 'pricing';
    if (lower.includes('supply chain') || lower.includes('supplier') || lower.includes('delivery') || lower.includes('lead time') || lower.includes('transit')) return 'supply_chain';
    if (lower.includes('employ') || lower.includes('labor') || lower.includes('staff') || lower.includes('workforce') || lower.includes('head count')) return 'labor';
    if (lower.includes('inventor')) return 'inventory';
    if (lower.includes('order') || lower.includes('demand') || lower.includes('backlog')) return 'demand';
    if (lower.includes('uncertain') || lower.includes('confus') || lower.includes('unclear') || lower.includes('shutdown')) return 'uncertainty';
    if (lower.includes('expect') || lower.includes('outlook') || lower.includes('forecast') || lower.includes('2026') || lower.includes('going into')) return 'outlook';
    
    return 'demand';
  }

  // ============================================
  // Quote Authenticity Validation - NEW v11.0
  // ============================================
  
  /**
   * Validates that quotes appear to be real ISM quotes, not AI-generated
   */
  validateQuoteAuthenticity(quotes) {
    if (!quotes || quotes.length === 0) return false;
    
    const realQuoteCount = quotes.filter(q => this.isQuoteLikelyReal(q)).length;
    const ratio = realQuoteCount / quotes.length;
    
    console.log(`[Quote Auth] ${realQuoteCount}/${quotes.length} quotes passed authenticity check (${(ratio * 100).toFixed(0)}%)`);
    
    // Lowered threshold from 0.6 to 0.5 - if at least half are real, accept them
    return ratio >= 0.5;
  }

  /**
   * Checks if a single quote appears to be real vs AI-generated
   */
  isQuoteLikelyReal(quote) {
    const text = (quote.comment || quote.originalQuote || '').toLowerCase();
    
    // REJECT: Generic phrases that indicate AI-generated content
    const genericPhrases = [
      'reported growth',
      'reported contraction', 
      'reported stable',
      'reported increased production',
      'reported decreased',
      'continues to grow',
      'remains stable',
      'showing improvement',
      'facing challenges',
      'experiencing difficulties',
      'reported in november',
      'reported in december',
      'reported in january',
      'reported in february',
      'reported in march',
      'reported in april',
      'reported in may',
      'reported in june',
      'reported in july',
      'reported in august',
      'reported in september',
      'reported in october',
      'reporting contraction',
      'reporting growth',
    ];
    
    for (const phrase of genericPhrases) {
      if (text.includes(phrase)) {
        console.log(`[Quote Auth] ❌ REJECTED (generic phrase "${phrase}"): "${text.substring(0, 50)}..."`);
        return false;
      }
    }
    
    // REJECT: Too short
    if (text.length < 40) {
      console.log(`[Quote Auth] ❌ REJECTED (too short: ${text.length} chars): "${text}"`);
      return false;
    }
    
    console.log(`[Quote Auth] ✓ ACCEPTED: "${text.substring(0, 50)}..."`);
    return true;
  }
  // ============================================
  // Fallback Quotes Generator
  // Only used when ALL other strategies fail
  // ============================================
  generateFallbackQuotes(month, ismData) {
    console.log('[ISM Quotes] ⚠️⚠️⚠️ GENERATING FALLBACK QUOTES ⚠️⚠️⚠️');
    console.log('[ISM Quotes] These are NOT real ISM quotes!');
    
    const pmi = ismData?.manufacturing?.pmi || 48;
    const prices = ismData?.manufacturing?.prices || 55;
    const employment = ismData?.manufacturing?.employment || 45;
    
    // CLEARLY MARKED as not real quotes
    const fallbackTemplates = [
      {
        industry: 'Notice',
        comment: `[⚠️ REAL ISM QUOTES UNAVAILABLE] The system was unable to retrieve actual respondent quotes from the ISM Manufacturing Report. Please visit ismworld.org or search PRNewswire for "ISM Manufacturing PMI Report" to read the authentic industry commentary.`,
        sentiment: 'neutral',
        keyTheme: 'unavailable',
        isFallback: true,
        isVerified: false,
        source: 'SYSTEM - Quotes unavailable',
      },
      {
        industry: 'Data Summary',
        comment: `[⚠️ NOT A REAL QUOTE] Current ISM Manufacturing PMI: ${pmi}. Prices Index: ${prices}. Employment Index: ${employment}. This is data summary, not a respondent quote.`,
        sentiment: pmi < 50 ? 'negative' : 'neutral',
        keyTheme: 'unavailable',
        isFallback: true,
        isVerified: false,
        source: 'SYSTEM - Data summary only',
      },
    ];
    
    return fallbackTemplates;
  }

  // ============================================
  // HISTORICAL CONTEXT - ENHANCED
  // ============================================

  async getHistoricalContext(currentMonth, monthsBack = 12) {
    console.log(`[ISMData] Getting ${monthsBack} months of historical context...`);
    
    // First try cache
    const cached = await this.getCachedHistorical(currentMonth);
    if (cached && cached.length >= 3) {
      console.log('[ISMData] Using cached historical data');
      return this.processHistorical(cached);
    }
    
    // Fetch via Perplexity
    const historical = await this.fetchHistoricalViaPerplexity(currentMonth, monthsBack);
    
    if (historical.length > 0) {
      await this.cacheHistorical(currentMonth, historical);
    }
    
    return this.processHistorical(historical);
  }

  processHistorical(historical) {
    if (!historical || historical.length === 0) {
      return {
        historical: [],
        monthCount: 0,
        consecutiveContractionMonths: 0,
        consecutiveExpansionMonths: 0,
        trends: {},
      };
    }

    // Sort by month
    historical.sort((a, b) => a.month.localeCompare(b.month));

    // Calculate trends
    const trends = {};
    const components = ['pmi', 'newOrders', 'employment', 'prices', 'backlog'];
    
    for (const comp of components) {
      const values = historical
        .map(h => h[comp])
        .filter(v => v != null);
      
      if (values.length >= 2) {
        const direction = values[values.length - 1] > values[0] ? 'improving' 
          : values[values.length - 1] < values[0] ? 'deteriorating' 
          : 'stable';
        trends[comp] = { 
          direction, 
          recent: values,
          average: this.roundTo1(values.reduce((a, b) => a + b, 0) / values.length),
          min: Math.min(...values),
          max: Math.max(...values),
        };
      }
    }

    // Calculate consecutive months
    let consecutiveContractionMonths = 0;
    let consecutiveExpansionMonths = 0;
    
    for (let i = historical.length - 1; i >= 0; i--) {
      if (historical[i].pmi < 50) {
        if (consecutiveExpansionMonths === 0) consecutiveContractionMonths++;
        else break;
      } else {
        if (consecutiveContractionMonths === 0) consecutiveExpansionMonths++;
        else break;
      }
    }

    return {
      historical,
      monthCount: historical.length,
      consecutiveContractionMonths,
      consecutiveExpansionMonths,
      trends,
    };
  }

  async fetchHistoricalViaPerplexity(currentMonth, monthsBack = 6) {
    try {
      console.log(`[Perplexity] Fetching historical ISM data for past ${monthsBack} months...`);
      
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar'  ,
          messages: [
            {
              role: 'system',
              content: `You provide historical ISM Manufacturing PMI data. Search Trading Economics, FRED, or ISM archives. Return JSON array only.`
            },
            {
              role: 'user',
              content: `Find ISM Manufacturing PMI data for the past ${monthsBack} months ending ${currentMonth}.

Search tradingeconomics.com or fred.stlouisfed.org.

Return JSON array:
[
  {"month": "YYYY-MM", "pmi": number, "newOrders": number, "employment": number, "prices": number}
]

Order oldest to newest. JSON only, no markdown.`
            }
          ],
          temperature: 0.1,
          max_tokens: 3000,
        }),
      });

      if (!response.ok) return [];

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      
      const historical = this.extractJSON(content);
      
      if (!Array.isArray(historical)) return [];
      
      console.log(`[Perplexity] Found ${historical.length} months of historical data`);
      return historical;
      
    } catch (error) {
      console.error('[Perplexity] Historical data error:', error.message);
      return [];
    }
  }

  async fetchHistoricalData(currentMonth, monthsBack = 12) {
    return this.getHistoricalContext(currentMonth, monthsBack);
  }

  // ============================================
  // CACHING
  // ============================================

  async getCachedData(month) {
    if (!this.supabase) return null;
    
    try {
      const { data, error } = await this.supabase
        .from('ism_source_cache')
        .select('parsed_data, fetched_at, source_url')
        .eq('data_month', month)
        .eq('is_valid', true)
        .single();
      
      if (error || !data) return null;
      
      return data.parsed_data;
    } catch {
      return null;
    }
  }

  async getCachedHistorical(month) {
    if (!this.supabase) return null;
    
    try {
      const { data, error } = await this.supabase
        .from('ism_historical_cache')
        .select('historical_data')
        .eq('current_month', month)
        .single();
      
      if (error || !data) return null;
      
      return data.historical_data;
    } catch {
      return null;
    }
  }

  async cacheHistorical(month, historical) {
    if (!this.supabase) return;
    
    try {
      await this.supabase.from('ism_historical_cache').upsert({
        current_month: month,
        historical_data: historical,
        cached_at: new Date().toISOString(),
      }, { onConflict: 'current_month' });
    } catch (error) {
      console.error('[Cache] Historical cache error:', error.message);
    }
  }

  isValidCache(cached) {
    if (!cached?.fetchedAt) return false;
    const hoursSince = (Date.now() - new Date(cached.fetchedAt).getTime()) / (1000 * 60 * 60);
    return hoursSince < 6;
  }

  async cacheData(month, data) {
    if (!this.supabase) return;
    
    try {
      await this.supabase.from('ism_source_cache').upsert({
        data_month: month,
        source_url: data.dataSource,
        raw_data: data,
        parsed_data: { ...data, fetchedAt: new Date().toISOString() },
        fetched_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(),
        is_valid: true,
      }, { onConflict: 'data_month' });
      
      console.log(`[Cache] Cached data for ${month}`);
    } catch (error) {
      console.error('[Cache] Error:', error.message);
    }
  }

  async clearCache(month) {
    if (!this.supabase) return;
    
    try {
      await this.supabase
        .from('ism_source_cache')
        .delete()
        .eq('data_month', month);
      
      console.log(`[Cache] Cleared cache for ${month}`);
    } catch (error) {
      console.error('[Cache] Clear error:', error.message);
    }
  }

  async clearAllCache() {
    if (!this.supabase) return;
    
    try {
      await this.supabase
        .from('ism_source_cache')
        .delete()
        .neq('data_month', '');
      
      console.log('[Cache] Cleared ALL cache');
    } catch (error) {
      console.error('[Cache] Clear all error:', error.message);
    }
  }

  // ============================================
  // VALIDATION
  // ============================================

  validateISMData(data) {
    if (!data?.manufacturing?.pmi) return false;
    
    const pmi = data.manufacturing.pmi;
    if (pmi < 35 || pmi > 70) return false;
    
    const components = ['newOrders', 'production', 'employment', 'prices'];
    for (const comp of components) {
      const value = data.manufacturing[comp];
      if (value !== null && value !== undefined) {
        if (value < 30 || value > 75) {
          console.warn(`[ISMData] Suspicious ${comp} value: ${value}`);
        }
      }
    }
    
    return true;
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  parseNumber(value) {
    if (value === null || value === undefined || value === 'UNCERTAIN') return null;
    const num = parseFloat(value);
    return isNaN(num) ? null : num;
  }

  roundTo1(value) {
    if (value === null || value === undefined) return null;
    return Math.round(value * 10) / 10;
  }

  extractJSON(text) {
    if (!text) return null;
    
    // Try direct parse first
    try {
      return JSON.parse(text);
    } catch {
      // Continue to extraction methods
    }
    
    // Try to find JSON in markdown code blocks
    const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (codeBlockMatch) {
      try {
        return JSON.parse(codeBlockMatch[1].trim());
      } catch {
        // Continue
      }
    }
    
    // Try to find JSON object or array
    const jsonPatterns = [
      /(\{[\s\S]*\})/,
      /(\[[\s\S]*\])/,
    ];
    
    for (const pattern of jsonPatterns) {
      const match = text.match(pattern);
      if (match) {
        try {
          // Clean up common issues
          let cleaned = match[1]
            .replace(/,\s*}/g, '}')  // Remove trailing commas in objects
            .replace(/,\s*]/g, ']')  // Remove trailing commas in arrays
            .replace(/'/g, '"')       // Replace single quotes with double
            .replace(/(\w+):/g, '"$1":') // Quote unquoted keys
            .replace(/""/g, '"');     // Fix double quotes
          
          return JSON.parse(cleaned);
        } catch (e) {
          console.error('[JSON Parse] Failed:', e.message);
        }
      }
    }
    
    return null;
  }
}

export { ISMDataService };