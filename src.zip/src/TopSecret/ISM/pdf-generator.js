// ==========================================
// ISM REPORT PDF GENERATOR v9.0 - WITH CHARTS
// ==========================================
// MAJOR CHANGES from v8.3:
// 1. Added Chart Triad section (Context, Tension, Implications)
// 2. Charts generated via QuickChart API (server-side)
// 3. Visual Analysis section after Macro Environment
// 4. No additional dependencies required
// ==========================================

import PDFDocument from 'pdfkit';
import { ISMQuoteStorage } from './quote-storage.js';
import fs from 'fs';
import { generateAllReportCharts } from './chart-generator.js';
import path from 'path';
let pdfQuoteStorage = null;

function getPDFQuoteStorage() {
  if (!pdfQuoteStorage) {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    pdfQuoteStorage = new ISMQuoteStorage(supabaseUrl, supabaseKey);
  }
  return pdfQuoteStorage;
}

// ============ COLORS ============
const COLORS = {
  gold: '#C9A646',
  goldDark: '#A68A3A',
  goldLight: '#E5D5A0',
  black: '#000000',
  darkText: '#1A1A1A',
  mediumGray: '#555555',
  lightGray: '#888888',
  veryLightGray: '#CCCCCC',
  ultraLightGray: '#F5F5F5',
  white: '#FFFFFF',
  green: '#16A34A',
  greenLight: '#DCFCE7',
  red: '#DC2626',
  redLight: '#FEE2E2',
  orange: '#EA580C',
  blue: '#2563EB',
};

// ============ TYPOGRAPHY ============
const FONT_DIR = path.join(process.cwd(), 'static', 'fonts');
const INTER_REGULAR = path.join(FONT_DIR, 'Inter_18pt-Regular.ttf');
const INTER_BOLD = path.join(FONT_DIR, 'Inter_18pt-Bold.ttf');

const hasInterFont = fs.existsSync(INTER_REGULAR) && fs.existsSync(INTER_BOLD);

const FONTS = {
  title: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  heading: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  body: hasInterFont ? 'Inter-Regular' : 'Helvetica',
  bold: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
};

function registerFonts(doc) {
  if (hasInterFont) {
    doc.registerFont('Inter-Regular', INTER_REGULAR);
    doc.registerFont('Inter-Bold', INTER_BOLD);
    console.log('[ISM PDF] Using Inter font');
  }
}

const SIZES = {
  coverTitle: 32,
  coverSubtitle: 16,
  coverDate: 14,
  coverTagline: 11,
  sectionTitle: 16,
  subSection: 13,
  stockTicker: 13,
  body: 10.5,
  small: 9.5,
  tableHeader: 9,
  tableCell: 9,
  footer: 8,
  logo: 42,
};

// ============ PAGE LAYOUT ============
const PAGE = {
  width: 612,
  height: 792,
  marginLeft: 50,
  marginRight: 50,
  marginTop: 60,
  marginBottom: 50,
  
  get contentWidth() { return this.width - this.marginLeft - this.marginRight; },
  get contentTop() { return this.marginTop + 25; },
  get footerY() { return this.height - 30; },
  get contentBottom() { return this.footerY - 25; },
  get safeBottom() { return this.footerY - 40; },
  get contentHeight() { return this.contentBottom - this.contentTop; },
  get threshold60() { return this.contentTop + (this.contentHeight * 0.60); },
  get minSectionSpace() { return 80; },
};

const COPYRIGHT = '© 2025 FINOTAUR';

// ============ DEFAULT LOGO PATH ============
const DEFAULT_LOGO_PATHS = [
  // Frontend paths (when running from backend - various structures)
  path.join(process.cwd(), '..', 'finotaur-frontend', 'public', 'logo.png'),
  path.join(process.cwd(), '..', 'frontend', 'public', 'logo.png'),
  path.join(process.cwd(), '..', 'client', 'public', 'logo.png'),
  // Railway/Render deployment paths
  '/app/finotaur-frontend/public/logo.png',
  '/app/frontend/public/logo.png',
  '/opt/render/project/src/finotaur-frontend/public/logo.png',
  // Monorepo structures
  path.join(process.cwd(), 'packages', 'frontend', 'public', 'logo.png'),
  path.join(process.cwd(), 'apps', 'frontend', 'public', 'logo.png'),
  // Backend paths (if logo is copied to backend)
  path.join(process.cwd(), 'public', 'logo.png'),
  path.join(process.cwd(), 'public', 'logo-text.png'),
  path.join(process.cwd(), 'static', 'logo.png'),
  path.join(process.cwd(), 'static', 'logo-text.png'),
  path.join(process.cwd(), 'assets', 'logo.png'),
  // Absolute paths
  '/app/public/logo.png',
  '/app/public/logo-text.png',
  './public/logo.png',
  './public/logo-text.png',
];

// ============ HELPER FUNCTIONS ============
function needsPageBreak(currentY, requiredSpace) {
  return currentY + requiredSpace > PAGE.safeBottom;
}

function pastThresholdForNewSection(currentY) {
  return currentY > PAGE.threshold60;
}

function formatMonthDisplay(monthStr) {
  if (!monthStr) return 'Unknown Month';
  const [year, month] = monthStr.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

function cleanText(text) {
  if (!text) return '';
  
  return text
    .replace(/[\u{1F300}-\u{1F9FF}]/gu, '')
    .replace(/[\u{2600}-\u{26FF}]/gu, '')
    .replace(/[\u{2700}-\u{27BF}]/gu, '')
    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
    .replace(/[\u{1F1E0}-\u{1F1FF}]/gu, '')
    .replace(/[📊📖💰🌍🌏📚🎯🏛️⬆️⬇️📅📈🔗⚡📉📌⚠️🎰💼✅❌🔥💹🏗️📡📰🔄📐🔍🔧🎨📦🏆⭐🗺️📝💡🎲📆🤖📄🟨🟦🟩🟪🔹🔴🟢🔵🟡🔒]/g, '')
    .replace(/\*\*/g, '')
    .replace(/\#\#/g, '')
    .replace(/\#/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function findLogo(providedPath) {
  console.log('[ISM PDF] Looking for logo...');
  console.log('[ISM PDF] Current working directory:', process.cwd());
  
  // Check environment variable first
  const envLogoPath = process.env.LOGO_PATH || process.env.FINOTAUR_LOGO_PATH;
  if (envLogoPath && fs.existsSync(envLogoPath)) {
    console.log(`[ISM PDF] Found logo via environment variable: ${envLogoPath}`);
    return envLogoPath;
  }
  
  if (providedPath) {
    if (Buffer.isBuffer(providedPath)) {
      console.log('[ISM PDF] Logo provided as Buffer');
      return providedPath;
    }
    if (typeof providedPath === 'string') {
      if (providedPath.startsWith('data:image')) {
        console.log('[ISM PDF] Logo provided as base64 data URL');
        const base64Data = providedPath.split(',')[1];
        return Buffer.from(base64Data, 'base64');
      }
      if (fs.existsSync(providedPath)) {
        console.log(`[ISM PDF] Logo found at provided path: ${providedPath}`);
        return providedPath;
      }
      console.log(`[ISM PDF] Logo not found at provided path: ${providedPath}`);
    }
  }
  
  console.log('[ISM PDF] Searching default logo paths...');
  for (const p of DEFAULT_LOGO_PATHS) {
    console.log(`[ISM PDF] Checking: ${p}`);
    if (fs.existsSync(p)) {
      console.log(`[ISM PDF] Found logo at: ${p}`);
      return p;
    }
  }
  
  console.log('[ISM PDF] No logo found in any default path');
  console.log('[ISM PDF] TIP: Set LOGO_PATH environment variable to specify logo location');
  return null;
}

function formatNumber(num) {
  if (num === null || num === undefined || isNaN(num)) return 'N/A';
  return Number(num).toFixed(1);
}

function getChangeSymbol(current, previous) {
  if (!previous || !current) return '';
  const diff = current - previous;
  if (Math.abs(diff) < 0.3) return '→';
  return diff > 0 ? '↑' : '↓';
}

function getSignalText(current, threshold = 50) {
  if (current === null || current === undefined || isNaN(current)) return 'N/A';
  return current >= threshold ? 'Expansion' : 'Contraction';
}


// ============ CHART DRAWING FUNCTIONS (v9.0) ============

/**
 * Draw a chart image from buffer into the PDF
 */
function drawChartImage(doc, chartBuffer, x, y, width, height = null) {
  if (!chartBuffer) {
    console.log('[ISM PDF] No chart buffer provided');
    return y;
  }
  
  try {
    const options = { width };
    if (height) options.height = height;
    
    doc.image(chartBuffer, x, y, options);
    const estimatedHeight = height || (width * 0.6);
    return y + estimatedHeight;
  } catch (error) {
    console.error('[ISM PDF] Error drawing chart:', error.message);
    return y;
  }
}


// ============ MAIN EXPORT (v10.0 - CLEAN CHARTS) ============
async function generateISMReportPDFBuffer(report, logoData = null) {
  // ★★★ PRE-GENERATE CHARTS (async) ★★★
  let charts = {};
  try {
    const currentData = {
      manufacturing: report.ism_data?.manufacturing || report.ism_manufacturing || report.macro_snapshot || {},
      month: report.report_month
    };
    const historicalData = report.historicalData || [];
    
    console.log('[ISM PDF v9] Generating charts...');
    charts = await generateAllReportCharts(currentData, historicalData, null);
    const chartCount = Object.keys(charts).filter(k => charts[k]).length;
    console.log(`[ISM PDF v9] Charts ready: ${chartCount} charts`);
  } catch (chartError) {
    console.warn('[ISM PDF v9] Charts skipped:', chartError.message);
    charts = {};
  }

  return new Promise((resolve, reject) => {
    try {
      const reportMonth = report.report_month || report.meta?.month || 'Unknown';
      const monthDisplay = formatMonthDisplay(reportMonth);

      console.log(`[ISM PDF v9] Starting - Institutional Quality with Charts`);

      const doc = new PDFDocument({
        size: 'letter',
        margin: 0,
        autoFirstPage: false,
        info: {
          Title: `Finotaur ISM Manufacturing Report - ${monthDisplay}`,
          Author: 'Finotaur Research',
          Subject: 'ISM Manufacturing Analysis',
          Creator: 'Finotaur v9.0',
        },
      });

      registerFonts(doc);

      const chunks = [];
      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(chunks);
        console.log(`[ISM PDF v9] Complete: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      const logo = findLogo(logoData);

      let currentPageNumber = 0;
      
      const addContentPage = () => {
        doc.addPage();
        currentPageNumber++;
        drawPageHeader(doc, monthDisplay);
        return PAGE.contentTop;
      };

      const drawFooter = (pageNum) => {
        doc.strokeColor(COLORS.veryLightGray)
           .lineWidth(0.3)
           .moveTo(PAGE.marginLeft, PAGE.footerY - 8)
           .lineTo(PAGE.width - PAGE.marginRight, PAGE.footerY - 8)
           .stroke();

        doc.font(FONTS.body).fontSize(SIZES.footer).fillColor(COLORS.lightGray);
        doc.text(COPYRIGHT, PAGE.marginLeft, PAGE.footerY, { lineBreak: false });
        doc.text('For educational purposes only. Not investment advice.', 
          PAGE.width / 2 - 100, PAGE.footerY, { width: 200, align: 'center', lineBreak: false });
        doc.text(`${pageNum}`, PAGE.width - PAGE.marginRight - 20, PAGE.footerY, { 
          width: 20, align: 'right', lineBreak: false 
        });
      };

      // ========== COVER PAGE ==========
      doc.addPage();
      drawCoverPage(doc, monthDisplay, logo);

      // ========== CONTENT PAGES ==========
      let currentY = addContentPage();
      let contentPageNum = 1;

      // 1. ANALYST CONTEXT (Human opening)
      if (report.analyst_context || report.macro_snapshot) {
        currentY = drawAnalystContext(doc, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 20;
      }

      // ★★★ CHART 1: REGIME TREND - after Our View ★★★
      if (charts.regimeMap) {
        if (needsPageBreak(currentY, 380)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        
        const chartWidth = 460;
        const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
        
        try {
          doc.image(charts.regimeMap, chartX, currentY, { width: chartWidth });
          currentY += 250;
        } catch (e) {
          console.log('[ISM PDF] Regime Map failed:', e.message);
        }
        
        currentY += 12; // Space before text
        
        // Explanatory paragraph below chart
        const mfg = report.ism_data?.manufacturing || report.macro_snapshot || {};
        const orders = mfg.newOrders || 47.4;
        const prices = mfg.prices || 58.5;
        let regimeExplanation = '';
        
        if (orders < 50 && prices >= 50) {
          regimeExplanation = 'The chart shows the widening gap between falling demand (blue) and rising costs (red). When the blue line drops below 50 while the red line stays above - that\'s Stagflation. Manufacturers can\'t pass through higher costs because demand is too weak.';
        } else if (orders >= 50 && prices >= 50) {
          regimeExplanation = 'Both lines are above 50 - Growth mode. Strong demand allows companies to pass through rising costs. Watch for the gap to widen as a warning sign.';
        } else if (orders >= 50 && prices < 50) {
          regimeExplanation = 'Demand (blue) above 50, costs (red) below 50 - Goldilocks. The ideal environment: healthy sales with easing input costs. Margins should expand.';
        } else {
          regimeExplanation = 'Both lines below 50 - Contraction. Demand is falling but so are costs. Deflationary environment with volume declines.';
        }
        
        doc.fillColor(COLORS.mediumGray)
           .font(FONTS.body)
           .fontSize(SIZES.small)
           .text(regimeExplanation, PAGE.marginLeft, currentY, { 
             width: PAGE.contentWidth, 
             align: 'left',
             lineGap: 2
           });
        currentY += doc.heightOfString(regimeExplanation, { width: PAGE.contentWidth }) + 25;
      }

      // 2. WHAT CHANGED THIS MONTH
      if (report.what_changed || report.macro_snapshot || report.ism_data) {
        if (needsPageBreak(currentY, 180)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawWhatChanged(doc, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 20;
      }

      // 3. EXECUTIVE SUMMARY
      if (report.executive_summary) {
        if (needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawExecutiveSummaryProse(doc, report.executive_summary, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // 4. MACRO ENVIRONMENT
      if (report.macro_snapshot) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawMacroEnvironment(doc, report.macro_snapshot, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // ★★★ CHART 2: MARGIN PRESSURE - after Macro Environment ★★★
      if (charts.marginPressure) {
        if (needsPageBreak(currentY, 380)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        
        const chartWidth = 440;
        const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
        
        try {
          doc.image(charts.marginPressure, chartX, currentY, { width: chartWidth });
          currentY += 240;
        } catch (e) {
          console.log('[ISM PDF] Margin Pressure failed:', e.message);
        }
        
        currentY += 15; // Space before text
        
        // Explanatory paragraph - SHORTER
        const marginExplanation = 'Red = Prices (costs). Blue = Orders (demand). Purple dashed = Employment. When red rises while blue and purple fall, companies face margin squeeze.';
        
        doc.fillColor(COLORS.mediumGray)
           .font(FONTS.body)
           .fontSize(SIZES.small)
           .text(marginExplanation, PAGE.marginLeft, currentY, { 
             width: PAGE.contentWidth, 
             align: 'left',
             lineGap: 2
           });
        currentY += doc.heightOfString(marginExplanation, { width: PAGE.contentWidth }) + 25;
      }

      // 5. KEY DIVERGENCES
      if (report.macro_snapshot?.criticalGaps?.length > 0) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawDivergencesNarrative(doc, report.macro_snapshot.criticalGaps, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // 6. INDUSTRY QUOTES ANALYSIS (NEW)
      // ★★★ Check ALL possible quote locations ★★★
      const hasQuotes = report.quotes_analysis || 
                       report.industry_quotes || 
                       report.respondentComments?.length > 0 ||
                       report.quotes?.length > 0 ||
                       report.ism_data?.respondentComments?.length > 0 ||
                       report.rawData?.respondentComments?.length > 0;
      
      if (hasQuotes) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 150)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawQuotesAnalysis(doc, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // 7. SECTOR ROTATION
      if (report.sector_impacts || report.sector_rotation) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawSectorRotation(doc, report.sector_impacts || report.sector_rotation, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        }, report, charts);
        currentY += 25;
      }

      // 8. EQUITY SELECTION FRAMEWORK
      if (report.equity_logic) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawEquityFramework(doc, report.equity_logic, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // 9. INVESTMENT THEMES
      if (report.trade_ideas || report.ism_manufacturing) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawInvestmentThemes(doc, report.trade_ideas, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        }, report);
        currentY += 25;
      }

      // 10. TRADE IDEAS - ALWAYS SHOW (generates defaults if no data)
      if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 100)) {
        drawFooter(contentPageNum);
        currentY = addContentPage();
        contentPageNum++;
      }
      currentY = drawStockPicks(doc, report, currentY, () => {
        drawFooter(contentPageNum);
        const newY = addContentPage();
        contentPageNum++;
        return newY;
      });
      currentY += 25;

      // 11. PRACTICAL POSITIONING (NEW)
      if (report.practical_positioning) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 120)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawPracticalPositioning(doc, report.practical_positioning, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
        currentY += 25;
      }

      // 12. WHAT WOULD CHANGE THIS VIEW
      if (report.invalidation_scenarios && report.invalidation_scenarios.length > 0) {
        if (pastThresholdForNewSection(currentY) || needsPageBreak(currentY, 80)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawInvalidationScenarios(doc, report.invalidation_scenarios, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        }, report);
        currentY += 25;
      }

      // 13. INDICATORS TO WATCH
      if (report.next_month_indicators && report.next_month_indicators.length > 0) {
        if (needsPageBreak(currentY, 80)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawNextMonthIndicators(doc, report.next_month_indicators, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        }, report);
      }

      // 14. SYNTHESIS (NEW)
      if (report.synthesis || report.mispricing) {
        if (needsPageBreak(currentY, 100)) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        currentY = drawSynthesis(doc, report, currentY, () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        });
      }

      drawFooter(contentPageNum);
      
      // Disclaimer page - black and white with logo and copyright warning
      generateDisclaimerSection(doc, logoData);
      
      console.log(`[ISM PDF v5] Generated: 1 cover + ${contentPageNum} content pages + disclaimer`);
      doc.end();

    } catch (error) {
      console.error('[ISM PDF v5] Error:', error);
      reject(error);
    }
  });
}

// ============ COVER PAGE WITH PROPER LOGO ============
function drawCoverPage(doc, monthDisplay, logoData) {
  const centerX = PAGE.width / 2;

  // Black background
  doc.rect(0, 0, PAGE.width, PAGE.height).fill(COLORS.black);
  
  // Top gold accent bar - slightly thicker
  doc.rect(0, 0, PAGE.width, 5).fill(COLORS.gold);

  // === FINOTAUR TEXT LOGO === (v8.3: larger text)
  const textLogoY = 100;
  
  // Main logo text with gold color - LARGER (48px)
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(48)
     .text('FINOTAUR', 0, textLogoY, { align: 'center', width: PAGE.width });
  
  // Thicker underline (3px instead of 2px, wider)
  const textWidth = 220;
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .moveTo(centerX - textWidth/2, textLogoY + 52)
     .lineTo(centerX + textWidth/2, textLogoY + 52)
     .stroke();
  
  // Tagline under logo
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(10)
     .text('Institutional-Grade Market Intelligence', 0, textLogoY + 68, { 
       align: 'center', width: PAGE.width 
     });

  // === COMPANY LOGO IMAGE (v8.3: smaller, stretched horizontally, NO frame) ===
  let logoImageY = 210;
  let logoLoaded = false;
  const logoWidth = 200;  // Wider
  const logoHeight = 160; // Shorter - creates horizontal stretch effect
  
  if (logoData) {
    try {
      const logoX = centerX - logoWidth/2;
      const logoY = logoImageY;
      
      if (Buffer.isBuffer(logoData)) {
        doc.image(logoData, logoX, logoY, { width: logoWidth, height: logoHeight });
        logoLoaded = true;
      } else if (typeof logoData === 'string' && fs.existsSync(logoData)) {
        doc.image(logoData, logoX, logoY, { width: logoWidth, height: logoHeight });
        logoLoaded = true;
      }
      // NO gold frame - removed per user request
    } catch (e) {
      console.log('[ISM PDF] Logo image load failed:', e.message);
    }
  }
  
  // Adjust title position based on whether logo was loaded
  const titleY = logoLoaded ? logoImageY + logoHeight + 40 : textLogoY + 180;
  
  // Decorative line above title (wider)
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .moveTo(centerX - 150, titleY - 35)
     .lineTo(centerX + 150, titleY - 35)
     .stroke();
  
  // Gold diamond decoration
  const diamondY = titleY - 25;
  const diamondSize = 6;
  doc.fillColor(COLORS.gold)
     .moveTo(centerX, diamondY - diamondSize)
     .lineTo(centerX + diamondSize, diamondY)
     .lineTo(centerX, diamondY + diamondSize)
     .lineTo(centerX - diamondSize, diamondY)
     .closePath()
     .fill();
  
  // Report type label
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(11)
     .text('INSTITUTIONAL RESEARCH', 0, titleY - 8, { align: 'center', width: PAGE.width });
  
  // Main title (v8.3: larger - 36px)
  doc.fillColor(COLORS.white)
     .font(FONTS.title)
     .fontSize(36)
     .text('ISM Manufacturing Report', 0, titleY + 20, { 
       align: 'center', width: PAGE.width 
     });

  // Gold separator line (wider)
  doc.strokeColor(COLORS.gold)
     .lineWidth(2)
     .moveTo(centerX - 180, titleY + 68)
     .lineTo(centerX + 180, titleY + 68)
     .stroke();

  // Month display (v8.3: larger - 20px)
  doc.fillColor(COLORS.white)
     .font(FONTS.body)
     .fontSize(20)
     .text(monthDisplay, 0, titleY + 88, { align: 'center', width: PAGE.width });

  // Tagline
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.coverTagline)
     .text('Macro Signal • Sector Shifts • Trade Implications', 0, titleY + 120, { 
       align: 'center', width: PAGE.width 
     });

  // Bottom gold accent bar - slightly thicker
  doc.rect(0, PAGE.height - 5, PAGE.width, 5).fill(COLORS.gold);

  // Copyright at bottom
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.footer)
     .text(COPYRIGHT, 0, PAGE.height - 25, { align: 'center', width: PAGE.width });
}

// ============ TEXT LOGO DRAWING (kept for compatibility) ============
function drawTextLogo(doc, centerX, y) {
  // Main logo text with gold color
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.logo)
     .text('FINOTAUR', 0, y, { align: 'center', width: PAGE.width });
  
  // Subtle underline
  const textWidth = 200;
  doc.strokeColor(COLORS.gold)
     .lineWidth(2)
     .moveTo(centerX - textWidth/2, y + 45)
     .lineTo(centerX + textWidth/2, y + 45)
     .stroke();
  
  // Tagline under logo
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(10)
     .text('Institutional-Grade Market Intelligence', 0, y + 55, { 
       align: 'center', width: PAGE.width 
     });
}

// ============ PAGE HEADER WITH LOGO ============
function drawPageHeader(doc, monthDisplay) {
  // FINOTAUR text in header
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(12)
     .text('FINOTAUR', PAGE.marginLeft, 28, { lineBreak: false });

  // Date on right side
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.small)
     .text(monthDisplay, PAGE.width - PAGE.marginRight - 150, 30, { 
       width: 150, align: 'right', lineBreak: false 
     });

  // Gold line under header
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.75)
     .moveTo(PAGE.marginLeft, 45)
     .lineTo(PAGE.width - PAGE.marginRight, 45)
     .stroke();
}

// ============ SECTION HEADER ============
function drawSectionHeader(doc, title, subtitle, startY) {
  let y = startY;

  doc.fillColor(COLORS.black)
     .font(FONTS.bold)
     .fontSize(SIZES.sectionTitle)
     .text(title, PAGE.marginLeft, y, { lineBreak: false });

  const titleWidth = doc.widthOfString(title);
  y += 18;

  // Gold underline
  doc.strokeColor(COLORS.gold)
     .lineWidth(2.5)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + Math.min(titleWidth + 20, 200), y)
     .stroke();

  y += 8;

  if (subtitle) {
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.small)
       .text(subtitle, PAGE.marginLeft, y, { lineBreak: false });
    y += 18;
  } else {
    y += 10;
  }

  return y;
}

// ============ 1. ANALYST CONTEXT ============
function drawAnalystContext(doc, report, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Our View', 'Why This Print Matters Now', startY);
  
  const macro = report.macro_snapshot || {};
  const context = report.analyst_context || {};
  const ismData = report.ism_data || {};
  const mfg = ismData.manufacturing || {};
  
  // Build human context paragraph
  let contextText = context.opening || '';
  
  if (!contextText && macro.regime) {
    // Try to get PMI from multiple sources
    const pmi = macro.pmi || macro.pmiValue || mfg.pmi || null;
    
    contextText = `We are approaching this ISM print at a fragile point in the cycle — where inflation persistence, earnings sensitivity, and labor fatigue are colliding. `;
    contextText += `This report is not about whether the PMI is above or below 50. It is about where pressure is accumulating — and where it is quietly easing. `;
    
    if (pmi !== null && pmi > 0) {
      if (pmi < 50) {
        contextText += `This matters because the current reading of ${formatNumber(pmi)} places manufacturing firmly in contraction territory, but the composition of that weakness — demand, costs, employment — tells us far more than the headline. `;
      } else {
        contextText += `This matters because even with the PMI at ${formatNumber(pmi)}, the underlying mix of components reveals where the cycle is truly headed. `;
      }
    } else {
      contextText += `This matters because the composition of the data — demand, costs, employment — tells us far more than the headline. `;
    }
    
    contextText += `Our goal here is not to restate the numbers. It is to translate them into what matters for positioning: which parts of the economy are absorbing pressure, which are starting to crack, and where the next set of earnings surprises is most likely to come from.`;
  }
  
  // Draw context as flowing prose
doc.fillColor(COLORS.darkText)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(cleanText(contextText), PAGE.marginLeft, y, { 
       width: PAGE.contentWidth, 
       lineGap: 3,
       align: 'justify'
     });
  
  y += doc.heightOfString(contextText, { width: PAGE.contentWidth }) + 15;
  
  return y;
}

// ============ 2. WHAT CHANGED THIS MONTH - FIXED v5.2 ============
function drawWhatChanged(doc, report, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'What Changed This Month', 'Key Movements vs Prior', startY);
  
  const macro = report.macro_snapshot || {};
  const whatChanged = report.what_changed || {};
  const ismData = report.ism_data || {};
  const rawData = report.rawData || {};
  
  // Get momChanges from multiple possible locations
  const momChanges = report.mom_changes || ismData.momChanges || rawData.momChanges || {};
  
  // Get manufacturing data for direct fallback - try multiple sources
  const mfg = ismData.manufacturing || rawData.manufacturing || rawData.ismData?.manufacturing || {};
  const priorMonth = ismData.priorMonth || rawData.priorMonth || {};
  
  // DEBUG: Log what data sources we have
  console.log('[PDF] What Changed data sources:', {
    hasMacro: Object.keys(macro).length > 0,
    hasMomChanges: Object.keys(momChanges).length > 0,
    hasMfg: Object.keys(mfg).length > 0,
    hasPrior: Object.keys(priorMonth).length > 0,
    macroPmi: macro.pmi,
    mfgPmi: mfg.pmi,
    momPmi: momChanges.pmi?.current
  });
  
  // FIXED: Proper key lookup with camelCase support
  const getPriorCurrent = (camelKey, displayName) => {
    // 1. Try momChanges with exact camelCase key
    if (momChanges[camelKey] && (momChanges[camelKey].current !== null && momChanges[camelKey].current !== undefined)) {
      return {
        prior: momChanges[camelKey].prior,
        current: momChanges[camelKey].current,
        delta: momChanges[camelKey].delta
      };
    }
    
    // 2. Try what_changed.changes array
    if (whatChanged.changes && Array.isArray(whatChanged.changes)) {
      const found = whatChanged.changes.find(c => 
        c.component?.toLowerCase() === displayName.toLowerCase() ||
        c.component?.replace(/\s+/g, '').toLowerCase() === camelKey.toLowerCase()
      );
      if (found && found.current !== null && found.current !== undefined) {
        return { prior: found.prior, current: found.current, delta: found.delta };
      }
    }
    
    // 3. Try ism_data.manufacturing directly
    if (mfg[camelKey] !== null && mfg[camelKey] !== undefined) {
      const priorVal = priorMonth[camelKey];
      const currVal = mfg[camelKey];
      return { 
        prior: priorVal,
        current: currVal,
        delta: (priorVal !== null && priorVal !== undefined) 
          ? parseFloat((currVal - priorVal).toFixed(1)) 
          : null
      };
    }
    
    // 4. Try macro_snapshot directly
    if (macro[camelKey] !== null && macro[camelKey] !== undefined) {
      const priorKey = camelKey === 'pmi' ? 'previousPmi' : `previous${camelKey.charAt(0).toUpperCase() + camelKey.slice(1)}`;
      return {
        prior: macro[priorKey] || null,
        current: macro[camelKey],
        delta: null
      };
    }
    
    return { prior: null, current: null, delta: null };
  };
  
  // Build changes array with CORRECT camelCase keys
  const changes = [
    { 
      component: 'PMI',
      ...getPriorCurrent('pmi', 'PMI'),
      fallbackCurrent: macro.pmi || macro.pmiValue,
      fallbackPrior: macro.previousPmi,
      threshold: 50 
    },
    { 
      component: 'New Orders',
      ...getPriorCurrent('newOrders', 'New Orders'),
      fallbackCurrent: macro.newOrders,
      threshold: 50 
    },
    { 
      component: 'Employment',
      ...getPriorCurrent('employment', 'Employment'),
      fallbackCurrent: macro.employment,
      threshold: 50 
    },
    { 
      component: 'Prices',
      ...getPriorCurrent('prices', 'Prices'),
      fallbackCurrent: macro.prices,
      threshold: 50 
    },
    { 
      component: 'Backlog',
      ...getPriorCurrent('backlog', 'Backlog'),
      fallbackCurrent: macro.backlog,
      threshold: 50 
    },
    { 
      component: 'Production',
      ...getPriorCurrent('production', 'Production'),
      fallbackCurrent: macro.production,
      threshold: 50 
    },
  ];
  
  // Resolve actual values using fallbacks
  changes.forEach(c => {
    if ((c.current === null || c.current === undefined) && c.fallbackCurrent !== null && c.fallbackCurrent !== undefined) {
      c.current = c.fallbackCurrent;
    }
    if ((c.prior === null || c.prior === undefined) && c.fallbackPrior !== null && c.fallbackPrior !== undefined) {
      c.prior = c.fallbackPrior;
    }
    if (c.current !== null && c.current !== undefined && 
        c.prior !== null && c.prior !== undefined && 
        (c.delta === null || c.delta === undefined)) {
      c.delta = parseFloat((c.current - c.prior).toFixed(1));
    }
  });
  
  // Draw table with proper styling
  const colWidths = [100, 70, 70, 70, 100];
  const totalWidth = colWidths.reduce((a, b) => a + b, 0);
  const headers = ['Component', 'Prior', 'Current', 'Change', 'Signal'];
  
  // Table header background
  doc.rect(PAGE.marginLeft, y - 3, totalWidth, 18).fill(COLORS.ultraLightGray);
  
  // Header row
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.tableHeader);
  
  let xPos = PAGE.marginLeft + 5;
  headers.forEach((header, i) => {
    doc.text(header, xPos, y, { width: colWidths[i] - 10, lineBreak: false });
    xPos += colWidths[i];
  });
  
  y += 18;
  
  // Separator line
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + totalWidth, y)
     .stroke();
  
  y += 8;
  
  // Data rows
  doc.font(FONTS.body).fontSize(SIZES.tableCell);
  
  for (const row of changes) {
    if (needsPageBreak(y, 22) && onPageBreak) {
      y = onPageBreak();
    }
    
    const current = row.current;
    const prior = row.prior;
    const delta = row.delta !== null && row.delta !== undefined 
      ? row.delta 
      : (prior && current ? (current - prior) : null);
    const deltaNum = delta || 0;
    
    // Determine signal
    let signal = 'N/A';
    if (current !== null && current !== undefined && !isNaN(current)) {
      signal = current >= row.threshold ? 'Expansion' : 'Contraction';
    }
    
    xPos = PAGE.marginLeft + 5;
    
    // Component name
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .text(row.component, xPos, y, { width: colWidths[0] - 10, lineBreak: false });
    xPos += colWidths[0];
    
    // Prior value
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .text(prior !== null && prior !== undefined ? formatNumber(prior) : '—', xPos, y, { 
         width: colWidths[1] - 10, lineBreak: false 
       });
    xPos += colWidths[1];
    
    // Current value
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .text(current !== null && current !== undefined ? formatNumber(current) : '—', xPos, y, { 
         width: colWidths[2] - 10, lineBreak: false 
       });
    xPos += colWidths[2];
    
    // Change with color
    let changeText = '—';
    let deltaColor = COLORS.mediumGray;
    if (delta !== null && !isNaN(delta)) {
      changeText = deltaNum > 0 ? `+${deltaNum.toFixed(1)}` : deltaNum.toFixed(1);
      deltaColor = deltaNum > 0.3 ? COLORS.green : deltaNum < -0.3 ? COLORS.red : COLORS.mediumGray;
    }
    doc.fillColor(deltaColor)
       .font(FONTS.bold)
       .text(changeText, xPos, y, { width: colWidths[3] - 10, lineBreak: false });
    xPos += colWidths[3];
    
    // Signal with color
    const signalColor = signal === 'Expansion' ? COLORS.green : signal === 'Contraction' ? COLORS.red : COLORS.mediumGray;
    doc.fillColor(signalColor)
       .font(FONTS.body)
       .text(signal, xPos, y, { width: colWidths[4] - 10, lineBreak: false });
    
    y += 16;
    
    // Light row separator
    doc.strokeColor(COLORS.veryLightGray)
       .lineWidth(0.3)
       .moveTo(PAGE.marginLeft, y - 2)
       .lineTo(PAGE.marginLeft + totalWidth, y - 2)
       .stroke();
  }
  
  y += 12;
  
  // Narrative summary with "This matters because"
  let narrativeSummary = whatChanged.narrative || whatChanged.takeaway;
  
  if (!narrativeSummary) {
    narrativeSummary = generateChangeNarrative(macro, changes);
  }
  
  if (narrativeSummary) {
    // Add "This matters because" box
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 4).fill(COLORS.gold);
    y += 8;
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(cleanText(narrativeSummary), PAGE.marginLeft, y, { 
         width: PAGE.contentWidth, 
         lineGap: 2,
         align: 'justify'
       });
    y += doc.heightOfString(narrativeSummary, { width: PAGE.contentWidth }) + 10;
  }
  
  return y;
}

function generateChangeNarrative(macro, changes) {
  const pmi = macro.pmi || macro.pmiValue || 0;
  const prices = macro.prices || 0;
  const employment = macro.employment || 0;
  const newOrders = macro.newOrders || 0;
  
  // Find components that changed significantly
  const significantChanges = changes.filter(c => c.delta && Math.abs(c.delta) > 0.5);
  
  let narrative = 'This matters because ';
  
  if (pmi < 50 && prices > 55) {
    narrative += `the mix tells the story better than the headline: demand remains weak while cost pressure persists. This combination creates the worst margin environment for manufacturers — falling volumes with elevated input costs. `;
    if (employment < 50) {
      narrative += `The employment reading at ${formatNumber(employment)} suggests companies are already in protection mode, cutting costs rather than investing for growth.`;
    }
  } else if (pmi < 50) {
    narrative += `manufacturing remains below the expansion threshold, but the composition of weakness matters. `;
    if (newOrders < 48) {
      narrative += `The New Orders reading at ${formatNumber(newOrders)} indicates demand softness is not yet stabilizing — this is a leading indicator worth monitoring closely.`;
    } else {
      narrative += `The balance of evidence suggests we are in a mature contraction rather than an accelerating one.`;
    }
  } else {
    narrative += `the headline expansion masks some nuance beneath the surface. `;
    if (prices > 55) {
      narrative += `Prices at ${formatNumber(prices)} suggest cost pressures remain elevated even as activity improves — watch for margin implications.`;
    } else {
      narrative += `The sustainability of this reading depends on whether New Orders can maintain momentum in coming months.`;
    }
  }
  
  return narrative;
}

// ============ 3. EXECUTIVE SUMMARY ============
function drawExecutiveSummaryProse(doc, summary, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Five Things That Matter', 'Executive Summary', startY);
  
  const summaryData = summary.summary || summary;
  
  const sentences = [];
  
  if (summaryData.situation) sentences.push(cleanText(summaryData.situation));
  if (summaryData.trend) sentences.push(cleanText(summaryData.trend));
  if (summaryData.sectors) sentences.push(cleanText(summaryData.sectors));
  if (summaryData.risk) sentences.push(cleanText(summaryData.risk));
  if (summaryData.action) sentences.push(cleanText(summaryData.action));
  
  for (let i = 0; i < sentences.length; i++) {
    if (needsPageBreak(y, 30) && onPageBreak) {
      y = onPageBreak();
    }
    
    const text = sentences[i];
    if (!text) continue;
    
    // Gold number circle
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(SIZES.body)
       .text(`${i + 1}.`, PAGE.marginLeft, y, { lineBreak: false });
    
    // Text
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(text, PAGE.marginLeft + 20, y, { 
         width: PAGE.contentWidth - 25,
         lineGap: 2
       });
    
    y += doc.heightOfString(text, { width: PAGE.contentWidth - 25 }) + 10;
  }
  
  return y + 5;
}

// ============ 4. MACRO ENVIRONMENT ============
function drawMacroEnvironment(doc, macro, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'The Manufacturing Environment', 'Macro Regime Assessment', startY);
  
  const regime = macro.regime || macro.regimeLabel || 'Unknown';
  
  // Regime box
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 28)
     .fill(COLORS.ultraLightGray);
  
  const labelText = 'Current Assessment: ';
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.subSection)
     .text(labelText, PAGE.marginLeft + 10, y + 7, { lineBreak: false });
  
  const labelWidth = doc.widthOfString(labelText);
  doc.fillColor(COLORS.darkText)
     .text(regime, PAGE.marginLeft + 10 + labelWidth, y + 7, { lineBreak: false });
  
  y += 38;
  
  // Narrative
  if (macro.narrative) {
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(cleanText(macro.narrative), PAGE.marginLeft, y, { 
         width: PAGE.contentWidth, 
         lineGap: 3,
         align: 'justify'
       });
    y += doc.heightOfString(macro.narrative, { width: PAGE.contentWidth }) + 12;
  }

  // Key Drivers as prose, not bullets
  if (macro.keyDrivers && macro.keyDrivers.length > 0) {
    if (needsPageBreak(y, 60) && onPageBreak) {
      y = onPageBreak();
    }
    
    y += 5;
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text('Key Observations:', PAGE.marginLeft, y);
    y += 14;
    
    const driversText = macro.keyDrivers.slice(0, 4).map(d => cleanText(d)).join('. ') + '.';
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(driversText, PAGE.marginLeft, y, { 
         width: PAGE.contentWidth,
         lineGap: 2
       });
    y += doc.heightOfString(driversText, { width: PAGE.contentWidth }) + 10;
  }

  // Time Horizon as flowing text
  const timeHorizon = macro.timeHorizon || macro.timeHorizons;
  if (timeHorizon) {
    if (needsPageBreak(y, 60) && onPageBreak) {
      y = onPageBreak();
    }
    
    y += 5;
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text('Outlook by Horizon:', PAGE.marginLeft, y);
    y += 14;
    
    const horizons = [];
    if (timeHorizon.shortTerm) horizons.push(`Near-term: ${cleanText(timeHorizon.shortTerm)}`);
    if (timeHorizon.mediumTerm) horizons.push(`Medium-term: ${cleanText(timeHorizon.mediumTerm)}`);
    if (timeHorizon.longTerm) horizons.push(`Longer-term: ${cleanText(timeHorizon.longTerm)}`);
    
    const horizonText = horizons.join(' ');
    
    if (horizonText) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(horizonText, PAGE.marginLeft, y, { 
           width: PAGE.contentWidth,
           lineGap: 2
         });
      y += doc.heightOfString(horizonText, { width: PAGE.contentWidth }) + 10;
    }
  }

  return y;
}

// ============ 5. DIVERGENCES AS NARRATIVE ============
function drawDivergencesNarrative(doc, gaps, report, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Key Divergences', 'Where the Data Tells Different Stories', startY);
  
  for (const gap of gaps.slice(0, 5)) {
    if (needsPageBreak(y, 80) && onPageBreak) {
      y = onPageBreak();
    }
    
    const gapTitle = typeof gap === 'string' ? gap : gap.type || gap.title || 'Signal';
    const gapDescription = typeof gap === 'string' ? '' : gap.description || gap.meaning || '';
    const gapImplication = typeof gap === 'string' ? '' : gap.implication || gap.tradingSignal || '';
    
    // Divergence title with subtle accent
    doc.strokeColor(COLORS.gold)
       .lineWidth(3)
       .moveTo(PAGE.marginLeft, y)
       .lineTo(PAGE.marginLeft, y + 14)
       .stroke();
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.body)
       .text(cleanText(gapTitle), PAGE.marginLeft + 10, y);
    
    y += 18;
    
    // Build narrative structure: What we see → What it implies → Why market might miss it
    let narrative = '';
    
    if (gapDescription) {
      narrative += `What we observe: ${cleanText(gapDescription)} `;
    }
    
    if (gapImplication) {
      narrative += `This implies: ${cleanText(gapImplication)} `;
    }
    
    // Add "why market might miss it" if available
    const marketMiss = typeof gap === 'object' ? gap.marketMiss || gap.contrarian : null;
    if (marketMiss) {
      narrative += `The market may be missing this because: ${cleanText(marketMiss)}`;
    }
    
    if (narrative) {
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text(narrative.trim(), PAGE.marginLeft + 10, y, { 
           width: PAGE.contentWidth - 15,
           lineGap: 2
         });
      y += doc.heightOfString(narrative, { width: PAGE.contentWidth - 15 }) + 12;
    } else {
      y += 8;
    }
  }

  return y;
}

// ============ 6. INDUSTRY QUOTES ANALYSIS (v8.3: Enhanced with gray boxes) ============
function drawQuotesAnalysis(doc, report, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Industry Leaders Speak', 'What Executives Are Saying', startY);
  
  // ★★★ ENHANCED QUOTE SOURCING - Check ALL possible locations ★★★
  const quotesData = report.quotes_analysis || report.industry_quotes || {};
  let quotes = quotesData.quotes || quotesData.analyzed || [];
  
  // Check ISM data containers
  const ismData = report.ism_manufacturing || report.ism_data || {};
  const rawQuotes = ismData.respondentQuotes || ismData.respondentComments || ismData.quotes || ismData.whatRespondentsAreSaying || [];
  
  // Check report root level
  const rootQuotes = report.respondentComments || report.quotes || [];
  
  // Check rawData
  const rawDataQuotes = report.rawData?.respondentComments || [];
  
  // Check supplementary
  const suppQuotes = report.supplementary?.quotes?.quotes || [];
  
  // ★★★ MERGE QUOTES FROM ALL SOURCES (prefer analyzed, fallback to raw) ★★★
  console.log('[PDF Quotes] Searching for quotes...');
  console.log('[PDF Quotes] quotes_analysis.quotes:', quotes.length);
  console.log('[PDF Quotes] ismData.respondentComments:', rawQuotes.length);
  console.log('[PDF Quotes] report.respondentComments:', rootQuotes.length);
  console.log('[PDF Quotes] rawData.respondentComments:', rawDataQuotes.length);
  
  if (quotes.length === 0 && rawQuotes.length > 0) {
    console.log('[PDF Quotes] Using rawQuotes from ismData');
    quotes = rawQuotes;
  }
  if (quotes.length === 0 && rootQuotes.length > 0) {
    console.log('[PDF Quotes] Using rootQuotes from report root');
    quotes = rootQuotes;
  }
  if (quotes.length === 0 && report.quotes) {
    quotes = Array.isArray(report.quotes) ? report.quotes : (report.quotes.quotes || report.quotes.analyzed || []);
  }
  if (quotes.length === 0 && rawDataQuotes.length > 0) {
    console.log('[PDF Quotes] Using rawDataQuotes');
    quotes = rawDataQuotes;
  }
  if (quotes.length === 0 && suppQuotes.length > 0) {
    console.log('[PDF Quotes] Using suppQuotes');
    quotes = suppQuotes;
  }
  
  console.log('[PDF Quotes] Final quote count:', quotes.length);
  
  // ★★★ ENHANCED DEBUG LOGGING v2 ★★★
  console.log('[PDF Quotes] ========== DEBUG START ==========');
  console.log('[PDF Quotes] quotes type:', typeof quotes);
  console.log('[PDF Quotes] quotes is array:', Array.isArray(quotes));
  
  if (quotes.length > 0) {
    console.log('[PDF Quotes] First quote object:', JSON.stringify(quotes[0], null, 2));
    console.log('[PDF Quotes] First quote keys:', Object.keys(quotes[0] || {}));
  }
  
  // Log each quote before filtering
  console.log('[PDF Quotes] Before filter:', quotes.length, 'quotes');
  quotes.forEach((q, i) => {
    const text = (q.comment || q.originalQuote || q.text || q.quote || '');
    console.log(`[PDF Quotes] Quote ${i+1}:`);
    console.log(`  - industry: ${q.industry || 'NONE'}`);
    console.log(`  - comment length: ${q.comment?.length || 0}`);
    console.log(`  - text length: ${q.text?.length || 0}`);
    console.log(`  - quote length: ${q.quote?.length || 0}`);
    console.log(`  - content: "${text.substring(0, 100)}..."`);
  });
  console.log('[PDF Quotes] ========== DEBUG END ==========');

// ★★★ QUOTE AUTHENTICITY FILTER - STRICT v4.0 ★★★
  // Catches fake "Reported growth/contraction" summaries AND Susan Spence statements
  const QUOTE_BLOCKLIST = [
    // Original blocklist
    'reported growth',
    'reported contraction',  
    'reported increased',
    'reported decreased',
    'reported stable',
    'reported expansion',
    'reported improvement',
    'reported higher',
    'reported lower',
    
    // ★★★ NEW v4.0: PMI/Index language (Susan Spence) ★★★
    'manufacturing pmi',
    'manufacturing activity',
    'pmi registered',
    'index registered',
    'composite pmi',
    
    // ★★★ NEW v4.0: Statistical language ★★★
    'contracted at',
    'expanded at',
    'percentage point',
    'consecutive month',
    'percent of respondents',
    
    // ★★★ NEW v4.0: ISM report structure phrases ★★★
    'panelists',
    'six largest manufacturing',
    'of the six big',
    'of the six largest',
    
    // ★★★ NEW v4.0: Susan Spence style summaries ★★★
    'survey respondents',
    'respondents continue',
    'respondents in several',
    'respondents are expecting',
    'continue to report',
    'substantial struggles',
    'expecting to see larger changes',
    'cited the lack',
    'impediment to planning',
    'some respondents',
    'several industries',
    'demand remains soft',
    'panelists reported',
    'majority of panelists',
    'comments were generally',
    'outlook remains',
    
    // ★★★ NEW v4.0: Industry list patterns ★★★
    'industries reporting growth',
    'industries reporting contraction',
    'industries that reported',
    'the following order',
    'in the following order',
  ];

  const beforeCount = quotes.length;
  quotes = quotes.filter(q => {
    const text = (q.comment || q.originalQuote || q.text || q.quote || '').toLowerCase();
    
    // Length check - real quotes are 40+ chars
    if (text.length < 40) {
      console.log(`[PDF Quotes v4.0] ❌ Rejected (too short): "${text.substring(0, 50)}..."`);
      return false;
    }
    
    // Blocklist check
    for (const phrase of QUOTE_BLOCKLIST) {
      if (text.includes(phrase)) {
        console.log(`[PDF Quotes v4.0] ❌ Rejected (summary: "${phrase}"): "${text.substring(0, 50)}..."`);
        return false;
      }
    }
    
    // ★★★ NEW v4.0: Require real quote indicators ★★★
    const realIndicators = [
      ' we ', " we're ", " we've ", ' our ', ' my ', ' i ',
      'customer', 'order', 'inventory', 'supplier', 'lead time',
      'tariff', 'import', 'export', 'pricing', 'demand',
      'staff', 'employee', 'hiring', 'layoff',
      'shipping', 'freight', 'delivery', 'production',
    ];
    
    const hasRealIndicator = realIndicators.some(ind => text.includes(ind));
    
    // For quotes under 80 chars, REQUIRE real indicators
    if (!hasRealIndicator && text.length < 80) {
      console.log(`[PDF Quotes v4.0] ❌ Rejected (no real indicators): "${text.substring(0, 50)}..."`);
      return false;
    }
    
    console.log(`[PDF Quotes v4.0] ✓ Accepted (${q.industry}): "${text.substring(0, 60)}..."`);
    return true;
  });

  console.log(`[PDF Quotes] After filter: ${quotes.length}/${beforeCount} quotes passed`);
  // ★★★ END FILTER ★★★
  
if (!quotes || quotes.length === 0) {
    // כותרת
    doc.fillColor(COLORS.orange)
       .font(FONTS.bold)
       .fontSize(SIZES.body)
       .text('Industry Quotes Currently Unavailable', PAGE.marginLeft, y);
    y += 18;
    
    // הסבר
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.small)
       .text('Real-time ISM respondent quotes could not be retrieved for this report.', PAGE.marginLeft, y);
    y += 14;
    
    // הפניה
    doc.fillColor(COLORS.mediumGray)
       .text('For actual executive commentary, visit:', PAGE.marginLeft, y);
    y += 14;
    
    // לינקים
    doc.fillColor(COLORS.blue)
       .text('• ismworld.org - Official ISM Report', PAGE.marginLeft + 10, y);
    y += 12;
    doc.text('• prnewswire.com - Search "ISM Manufacturing PMI Report"', PAGE.marginLeft + 10, y);
    y += 20;
    
    return y;
}
  
  // Intro text
  const intro = 'The qualitative signals from industry executives often precede the quantitative data. Here is what stood out:';
  doc.fillColor(COLORS.darkText)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(intro, PAGE.marginLeft, y, { width: PAGE.contentWidth });
  y += doc.heightOfString(intro, { width: PAGE.contentWidth }) + 15;
  
// v9.2: Display up to 8 quotes with gray background boxes
  for (const quote of quotes.slice(0, 8)) {
    // Extract quote data FIRST to calculate actual height
    let industryName = quote.industry || quote.sector || quote.source || '';
    let quoteText = quote.quote || quote.text || quote.originalQuote || quote.comment || (typeof quote === 'string' ? quote : '');
    
    // Clean up quote text
    if (typeof quoteText === 'string') {
      quoteText = quoteText
        .replace(/^["']|["']$/g, '')
        .replace(/^\[ISM quotes unavailable\]\s*/i, '')
        .replace(/^\[unavailable\]\s*/i, '')
        .trim();
    }
    
    // Extract industry from quote text if needed
    if (typeof quoteText === 'string' && quoteText.includes('(') && quoteText.endsWith(')')) {
      const match = quoteText.match(/\(([^)]+)\)$/);
      if (match && !industryName) {
        industryName = match[1];
        quoteText = quoteText.replace(/\s*\([^)]+\)$/, '').trim();
      }
    }
    
    if (!industryName) industryName = 'Manufacturing';
    
    // Calculate ACTUAL height needed BEFORE page break check
    const cleanedQuote = cleanText(quoteText);
    doc.font(FONTS.body).fontSize(SIZES.body);
    const quoteHeight = doc.heightOfString(`"${cleanedQuote}"`, { width: PAGE.contentWidth - 30, lineGap: 2 });
    const boxHeight = quoteHeight + 45; // Header + quote + padding
    
    // NOW check if we need page break with REAL height
    if (needsPageBreak(y, boxHeight + 20) && onPageBreak) {
      y = onPageBreak();
    }     
    // v8.3: Draw gray background box
    doc.rect(PAGE.marginLeft, y - 5, PAGE.contentWidth, boxHeight + 10)
       .fill(COLORS.ultraLightGray);
    
    // Industry name BOLD with gold underline
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.body)
       .text(industryName, PAGE.marginLeft + 10, y);
    
    // Gold underline below industry name (v8.3: slightly thicker)
    const industryWidth = doc.widthOfString(industryName);
    doc.strokeColor(COLORS.gold)
       .lineWidth(2)
       .moveTo(PAGE.marginLeft + 10, y + 14)
       .lineTo(PAGE.marginLeft + 10 + industryWidth, y + 14)
       .stroke();
    
    y += 22;
    
    // Quote text in regular weight, indented
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(`"${cleanedQuote}"`, PAGE.marginLeft + 15, y, { 
         width: PAGE.contentWidth - 30,
         lineGap: 2
       });
    
    y += quoteHeight + 18;
  }

  return y;
}

// ============ 7. SECTOR ROTATION WITH TABLE ============
function drawSectorRotation(doc, sectorData, startY, onPageBreak, report = {}, charts = {}) {
  // Get ISM data for the trend analysis
  const ism = report?.ism_manufacturing || report?.ism_data?.manufacturing || {};
  const prior = report?.prior_month_data || {};
  
  const pmi = ism.pmi || 48;
  const newOrders = ism.newOrders || 47;
  const employment = ism.employment || 44;
  const prices = ism.prices || 58;
  const production = ism.production || 51;
  const backlog = ism.backlog || 44;
  const inventories = ism.inventories || 49;
  
  // Prior month values
  const priorPmi = prior.pmi || ism.previousPmi || 49;
  const priorNewOrders = prior.newOrders || 49;
  const priorEmployment = prior.employment || 46;
  const priorPrices = prior.prices || 57;
  const priorProduction = prior.production || 48;
  
  let y = drawSectionHeader(doc, 'Trend Analysis', 'What the Numbers Are Telling Us', startY);
  
  // Calculate changes
  const pmiChange = pmi - priorPmi;
  const newOrdersChange = newOrders - priorNewOrders;
  const employmentChange = employment - priorEmployment;
  const pricesChange = prices - priorPrices;
  const productionChange = production - priorProduction;
  
  // Determine the narrative based on data
  const isContraction = pmi < 50;
  const isStagflation = pmi < 50 && prices > 55;
  const isEmploymentWeak = employment < 46;
  const isOrdersWeak = newOrders < 48;
  const isPricesHot = prices > 55;
  
  // Build the opening summary
  let openingText = '';
  
  if (isStagflation) {
    openingText = `The PMI came in at ${pmi}, which puts us firmly in contraction territory. But here's the real story: prices are sitting at ${prices}. That's the stagflationary combination nobody wants to see - activity slowing while costs stay elevated. For manufacturers, this is the worst of both worlds.`;
  } else if (isContraction) {
    openingText = `Manufacturing continues to contract with PMI at ${pmi}. This marks another month below the 50 threshold, confirming that the industrial economy remains under pressure. The question now isn't whether we're in contraction - we know we are - it's how long it lasts and what breaks first.`;
  } else {
    openingText = `PMI at ${pmi} signals expansion, which is constructive. The manufacturing sector is showing resilience, though we need to watch the underlying components to see if this strength is broad-based or concentrated in a few areas.`;
  }
  
  doc.fillColor(COLORS.darkText)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(openingText, PAGE.marginLeft, y, { 
       width: PAGE.contentWidth,
       lineGap: 3
     });
  y += doc.heightOfString(openingText, { width: PAGE.contentWidth }) + 20;
  
  // ═══════════════════════════════════════════════════════════════════
  // WEAKENING TRENDS
  // ═══════════════════════════════════════════════════════════════════
  
  let weakeningText = '';
  const weakPoints = [];
  
  if (isEmploymentWeak) {
    weakPoints.push(`Employment at ${employment} is concerning - this tells us companies are cutting headcount to protect margins, not just slowing hiring`);
  }
  if (isOrdersWeak) {
    weakPoints.push(`New Orders at ${newOrders} signal continued demand weakness - this is a leading indicator and it's not giving us good news`);
  }
  if (backlog < 46) {
    weakPoints.push(`Backlog dropped to ${backlog}, meaning the cushion of existing orders is depleting fast`);
  }
  if (newOrdersChange < -1) {
    weakPoints.push(`New Orders fell ${Math.abs(newOrdersChange).toFixed(1)} points from last month - that's acceleration to the downside`);
  }
  if (employmentChange < -1) {
    weakPoints.push(`Employment dropped ${Math.abs(employmentChange).toFixed(1)} points - companies are moving from "wait and see" to "cut costs now"`);
  }
  
  if (weakPoints.length > 0) {
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.subSection)
       .text('Signs of Continued Weakness', PAGE.marginLeft, y);
    y += 18;
    
    weakeningText = weakPoints.slice(0, 3).join('. ') + '.';
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(weakeningText, PAGE.marginLeft, y, { 
         width: PAGE.contentWidth,
         lineGap: 3
       });
    y += doc.heightOfString(weakeningText, { width: PAGE.contentWidth }) + 20;
  }
  
  // ★★★ CHART 3: FORWARD VISIBILITY ★★★
  if (charts.forwardVisibility) {
    if (needsPageBreak(y, 380) && onPageBreak) {
      y = onPageBreak();
    }
    
    const chartWidth = 440;
    const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
    
    try {
      doc.image(charts.forwardVisibility, chartX, y, { width: chartWidth });
      y += 240;
    } catch (e) {
      console.log('[ISM PDF] Forward Visibility failed:', e.message);
    }
    
    y += 15; // Space before text
    
    // Explanatory paragraph - SHORTER
    const visibilityExplanation = 'Orange area = Backlog (existing orders cushion). Blue line = New Orders (refill rate). When both are below 50, visibility is poor for the next 2-3 quarters.';
    
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.small)
       .text(visibilityExplanation, PAGE.marginLeft, y, { 
         width: PAGE.contentWidth, 
         align: 'left',
         lineGap: 2
       });
    y += doc.heightOfString(visibilityExplanation, { width: PAGE.contentWidth }) + 25;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // STRENGTHENING TRENDS  
  // ═══════════════════════════════════════════════════════════════════
  
  let strengtheningText = '';
  const strongPoints = [];
  
  if (production > 50) {
    strongPoints.push(`Production at ${production} is actually above 50, which is a bright spot - factories are still running even if new orders are weak`);
  }
  if (productionChange > 1) {
    strongPoints.push(`Production jumped ${productionChange.toFixed(1)} points from last month - that's meaningful acceleration`);
  }
  if (inventories < 47) {
    strongPoints.push(`Customer inventories are reported as too low - this sets up a potential restocking cycle when confidence returns`);
  }
  if (pmiChange > 0 && pmi < 50) {
    strongPoints.push(`PMI improved ${pmiChange.toFixed(1)} points even while staying below 50 - the rate of contraction is slowing`);
  }
  if (newOrdersChange > 0) {
    strongPoints.push(`New Orders ticked up ${newOrdersChange.toFixed(1)} points - early sign that demand may be stabilizing`);
  }
  
  if (strongPoints.length > 0) {
    if (needsPageBreak(y, 100) && onPageBreak) {
      y = onPageBreak();
    }
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.subSection)
       .text('Early Signs Worth Watching', PAGE.marginLeft, y);
    y += 18;
    
    strengtheningText = strongPoints.slice(0, 3).join('. ') + '.';
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(strengtheningText, PAGE.marginLeft, y, { 
         width: PAGE.contentWidth,
         lineGap: 3
       });
    y += doc.heightOfString(strengtheningText, { width: PAGE.contentWidth }) + 20;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // THE PRICE PRESSURE STORY
  // ═══════════════════════════════════════════════════════════════════
  
  if (isPricesHot) {
    if (needsPageBreak(y, 80) && onPageBreak) {
      y = onPageBreak();
    }
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.subSection)
       .text('The Inflation Question', PAGE.marginLeft, y);
    y += 18;
    
    let priceText = `Prices at ${prices} remain stubbornly elevated. `;
    if (pricesChange > 0) {
      priceText += `They actually rose ${pricesChange.toFixed(1)} points from last month, which is not what you want to see when activity is this weak. `;
    }
    priceText += `This creates a margin squeeze - companies can't easily pass through costs when demand is soft, but they also can't ignore rising input costs. The companies that survive this environment will be the ones with real pricing power.`;
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(priceText, PAGE.marginLeft, y, { 
         width: PAGE.contentWidth,
         lineGap: 3
       });
    y += doc.heightOfString(priceText, { width: PAGE.contentWidth }) + 20;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // BOTTOM LINE
  // ═══════════════════════════════════════════════════════════════════
  
  if (needsPageBreak(y, 80) && onPageBreak) {
    y = onPageBreak();
  }
  
  doc.fillColor(COLORS.darkText)
     .font(FONTS.bold)
     .fontSize(SIZES.subSection)
     .text('The Bottom Line', PAGE.marginLeft, y);
  y += 18;
  
  let bottomLine = '';
  if (isStagflation) {
    bottomLine = `This is a defensive environment. Focus on companies with pricing power and lean cost structures. Avoid high operating leverage and capex-dependent names. The winners will be businesses that can protect margins without volume growth. Quality over growth.`;
  } else if (isContraction) {
    bottomLine = `Selectivity matters more than direction here. Not everything will go down together, and not everything will recover at the same pace. Look for companies already through the worst of the adjustment, with clean inventories and stable employment. They'll outperform when the cycle turns.`;
  } else {
    bottomLine = `Expansion favors cyclical exposure, but don't chase it blindly. The strength of the recovery will depend on whether new orders can accelerate from here. Watch the employment component for confirmation - when companies start hiring again, that's when you know the expansion has legs.`;
  }
  
  doc.fillColor(COLORS.darkText)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(bottomLine, PAGE.marginLeft, y, { 
       width: PAGE.contentWidth,
       lineGap: 3
     });
  y += doc.heightOfString(bottomLine, { width: PAGE.contentWidth }) + 15;
  
  return y;
}

// ============ 8. EQUITY FRAMEWORK ============
// ============ 8. EQUITY FRAMEWORK - DISABLED (merged into Trend Analysis) ============
function drawEquityFramework(doc, equity, startY, onPageBreak) {
  // Section removed - analysis now in Trend Analysis (The Bottom Line)
  return startY;
}

// ============ 9. INVESTMENT THEMES - DISABLED ============
function drawInvestmentThemes(doc, trades, startY, onPageBreak, report = {}) {
  // Section removed - analysis now in Trend Analysis
  return startY;
}

// ═══════════════════════════════════════════════════════════════════
// ENHANCED SECTOR-STOCK MAPPING WITH DETAILED ANALYSIS (v9.0)
// ═══════════════════════════════════════════════════════════════════

const ENHANCED_SECTOR_STOCKS = {
  'Food, Beverage & Tobacco Products': { 
    etf: 'XLP', 
    stocks: ['PG', 'KO', 'PEP', 'GIS', 'COST'],
    analysis: {
      leaders: ['PG', 'KO'],
      leaderReason: 'Strongest pricing power - can pass through costs without destroying demand',
      laggards: ['GIS'],
      laggardReason: 'More vulnerable to private label competition',
      catalyst: 'COST benefits from trade-down behavior if conditions worsen'
    }
  },
  'Food, Beverage & Tobacco': { 
    etf: 'XLP', 
    stocks: ['PG', 'KO', 'PEP', 'GIS', 'COST'],
    analysis: {
      leaders: ['PG', 'KO'],
      leaderReason: 'Strongest pricing power - can pass through costs without destroying demand',
      laggards: ['GIS'],
      laggardReason: 'More vulnerable to private label competition',
      catalyst: 'COST benefits from trade-down behavior if conditions worsen'
    }
  },
  'Computer & Electronic Products': { 
    etf: 'XLK', 
    stocks: ['NVDA', 'AMD', 'AVGO', 'ANET', 'INTC'],
    analysis: {
      leaders: ['NVDA', 'AVGO'],
      leaderReason: 'AI/data center secular demand insulated from PMI cycle',
      laggards: ['INTC'],
      laggardReason: 'Legacy business more exposed to manufacturing weakness',
      catalyst: 'Hyperscaler capex announcements drive near-term moves'
    }
  },
  'Machinery': { 
    etf: 'XLI', 
    stocks: ['CAT', 'DE', 'PCAR', 'CMI', 'EMR'],
    analysis: {
      leaders: ['CAT', 'EMR'],
      leaderReason: 'Infrastructure exposure provides demand floor',
      laggards: ['DE'],
      laggardReason: 'Ag cycle weakness adds headwind',
      catalyst: 'Government infrastructure spending visibility'
    }
  },
  'Transportation Equipment': { 
    etf: 'IYT', 
    stocks: ['BA', 'LMT', 'GD', 'RTX', 'NOC'],
    analysis: {
      leaders: ['LMT', 'RTX'],
      leaderReason: 'Defense backlog provides earnings visibility',
      laggards: ['BA'],
      laggardReason: 'Execution risk and commercial aerospace uncertainty',
      catalyst: 'Defense budget clarity and Boeing delivery normalization'
    }
  },
  'Chemical Products': { 
    etf: 'XLB', 
    stocks: ['LIN', 'APD', 'DD', 'DOW', 'ECL'],
    analysis: {
      leaders: ['LIN', 'APD'],
      leaderReason: 'Industrial gas duopoly with contracted revenue',
      laggards: ['DOW'],
      laggardReason: 'Commodity chemical exposure vulnerable to volume',
      catalyst: 'Restocking cycle would benefit all equally'
    }
  },
  'Fabricated Metal Products': { 
    etf: 'XLI', 
    stocks: ['NUE', 'STLD', 'CLF', 'X', 'AA'],
    analysis: {
      leaders: ['NUE', 'STLD'],
      leaderReason: 'EAF operators with lower cost structure',
      laggards: ['X', 'CLF'],
      laggardReason: 'Legacy integrated mills, higher fixed costs',
      catalyst: 'Section 232 tariff policy and infrastructure demand'
    }
  },
  'Primary Metals': { 
    etf: 'XLB', 
    stocks: ['NUE', 'STLD', 'CLF', 'FCX', 'AA'],
    analysis: {
      leaders: ['FCX'],
      leaderReason: 'Copper demand tied to electrification megatrend',
      laggards: ['AA'],
      laggardReason: 'Aluminum oversupply risk from China',
      catalyst: 'China stimulus and EV adoption rate'
    }
  },
  'Electrical Equipment': { 
    etf: 'XLI', 
    stocks: ['ETN', 'EMR', 'ROK', 'AME', 'PH'],
    analysis: {
      leaders: ['ETN', 'PH'],
      leaderReason: 'Data center and electrification exposure',
      laggards: ['ROK'],
      laggardReason: 'Manufacturing automation tied to capex cycle',
      catalyst: 'AI-driven power infrastructure demand'
    }
  },
  'Petroleum & Coal Products': { 
    etf: 'XLE', 
    stocks: ['XOM', 'CVX', 'COP', 'PSX', 'VLO'],
    analysis: {
      leaders: ['XOM', 'CVX'],
      leaderReason: 'Integrated model provides earnings stability',
      laggards: ['VLO', 'PSX'],
      laggardReason: 'Refining margins more volatile',
      catalyst: 'OPEC+ decisions and refinery utilization'
    }
  },
  'Consumer Staples': { 
    etf: 'XLP', 
    stocks: ['PG', 'KO', 'PEP', 'CL', 'KMB'],
    analysis: {
      leaders: ['PG', 'KO'],
      leaderReason: 'Brand strength enables pricing power',
      laggards: ['KMB'],
      laggardReason: 'Commodity pulp exposure',
      catalyst: 'Consumer trade-down trends'
    }
  },
  'Consumer Discretionary': { 
    etf: 'XLY', 
    stocks: ['AMZN', 'HD', 'MCD', 'NKE', 'SBUX'],
    analysis: {
      leaders: ['AMZN', 'MCD'],
      leaderReason: 'Scale and value positioning',
      laggards: ['NKE'],
      laggardReason: 'Inventory and China exposure',
      catalyst: 'Consumer confidence and employment'
    }
  },
  'Miscellaneous Manufacturing': { 
    etf: 'XLI', 
    stocks: ['MMM', 'ITW', 'PH', 'GE', 'HON'],
    analysis: {
      leaders: ['HON', 'ITW'],
      leaderReason: 'Diversified portfolios provide stability',
      laggards: ['MMM'],
      laggardReason: 'Legal overhang and restructuring',
      catalyst: 'Broad manufacturing recovery'
    }
  },
};

// ═══════════════════════════════════════════════════════════════════
// HELPER: Get sector stock data with fuzzy matching
// ═══════════════════════════════════════════════════════════════════

function getEnhancedStocksForIndustry(industry) {
  if (!industry) {
    return ENHANCED_SECTOR_STOCKS['Consumer Staples'];
  }
  if (ENHANCED_SECTOR_STOCKS[industry]) {
    return ENHANCED_SECTOR_STOCKS[industry];
  }
  const lowerIndustry = industry.toLowerCase();
  for (const [key, value] of Object.entries(ENHANCED_SECTOR_STOCKS)) {
    const lowerKey = key.toLowerCase();
    if (lowerIndustry.includes(lowerKey.split(' ')[0]) ||
        lowerKey.includes(lowerIndustry.split(' ')[0])) {
      return value;
    }
  }
  return ENHANCED_SECTOR_STOCKS['Miscellaneous Manufacturing'];
}

// ═══════════════════════════════════════════════════════════════════
// HELPER: Generate detailed stock impact text
// ═══════════════════════════════════════════════════════════════════

function generateDetailedStockImpact(sectorData, isLong) {
  if (!sectorData?.analysis) {
    return `${sectorData?.etf || 'XLI'} provides broad sector exposure.`;
  }
  const { leaders, leaderReason, laggards, laggardReason, catalyst } = sectorData.analysis;
  if (isLong) {
    return `${leaders?.join(' and ') || 'Leaders'}: ${leaderReason}. Avoid ${laggards?.join(', ') || 'laggards'} - ${laggardReason}. Catalyst: ${catalyst}`;
  } else {
    return `Short candidates: ${laggards?.join(', ') || 'Laggards'} - ${laggardReason}. Avoid shorting ${leaders?.join(' and ') || 'leaders'} due to relative strength. Catalyst: ${catalyst}`;
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// 🎯 TRADE IDEAS SECTION (v9.0) - ALWAYS GENERATES CONTENT
// ════════════════════════════════════════════════════════════════════════════════

function drawStockPicks(doc, report, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Trade Ideas', 'Derived From Executive Commentary', startY);
  
  const ism = report.ism_manufacturing || report.ism_data?.manufacturing || {};
  const quoteAnalysis = report.quotes_analysis || {};
  
  // Get quotes from multiple sources
  let quotes = quoteAnalysis.quotes || [];
  if (quotes.length === 0) quotes = report.respondentComments || [];
  if (quotes.length === 0) quotes = ism.respondentQuotes || ism.respondentComments || [];
  if (quotes.length === 0) quotes = report.rawData?.respondentComments || [];
  
  // Get ISM data for context (with smart defaults)
  const pmi = ism.pmi || report.macro_snapshot?.pmi || 48;
  const prices = ism.prices || report.macro_snapshot?.prices || 55;
  const employment = ism.employment || report.macro_snapshot?.employment || 44;
  const newOrders = ism.newOrders || report.macro_snapshot?.newOrders || 47;
  const backlog = ism.backlog || 44;
  const production = ism.production || 51;
  
  // ★★★ ALWAYS GENERATE TRADE IDEAS ★★★
  let tradeIdeas = generateQuoteDrivenDefaults(
    quotes, 
    { pmi, prices, employment, newOrders, backlog, production },
    ENHANCED_SECTOR_STOCKS
  );
  
  // Intro text
  doc.fillColor(COLORS.mediumGray)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(`Each trade idea below connects ISM data signals to specific sector positioning. The analysis is driven by executive commentary and supported by the underlying numbers.`, PAGE.marginLeft, y, { width: PAGE.contentWidth });
  y += doc.heightOfString(`Each trade idea below...`, { width: PAGE.contentWidth }) + 25;
  
  // Draw each trade idea - CLEAN PROFESSIONAL STYLE
  for (let i = 0; i < Math.min(tradeIdeas.length, 4); i++) {
    const idea = tradeIdeas[i];
    
    // Check for page break - need more space for cleaner layout
    if (needsPageBreak(y, 280) && onPageBreak) {
      y = onPageBreak();
    }
    
    const isLong = (idea.direction || 'long').toLowerCase() === 'long';
    const sectorName = idea.sector || idea.executiveQuoteIndustry || 'Manufacturing';
    const sectorData = getEnhancedStocksForIndustry(sectorName);
    const etf = idea.ticker || sectorData.etf;
    const stocks = idea.alternativeStocks || sectorData.stocks;
    
    // ════════════════════════════════════════════════════════════
    // HEADER LINE - Direction + Sector (clean, gray)
    // ════════════════════════════════════════════════════════════
    
    // Gold accent bar
    doc.rect(PAGE.marginLeft, y, 3, 16)
       .fill(COLORS.gold);
    
    // Direction text
    const directionText = isLong ? 'LONG' : 'SHORT';
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.stockTicker)
       .text(`${directionText}: ${sectorName}`, PAGE.marginLeft + 10, y);
    y += 20;
    
    // Tickers line
    if (stocks && stocks.length > 0) {
      doc.fillColor(COLORS.mediumGray)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(`Sector ETF: ${etf}  |  Tickers: ${stocks.slice(0, 5).join(', ')}`, PAGE.marginLeft + 10, y);
      y += 20;
    }
    
    // ════════════════════════════════════════════════════════════
    // EXECUTIVE QUOTE - Simple gray italic box
    // ════════════════════════════════════════════════════════════
    
    const execQuote = idea.executiveQuote || '';
    const quoteIndustry = idea.executiveQuoteIndustry || sectorName;
    
    if (execQuote && execQuote.length > 30) {
      const quoteText = cleanText(execQuote);
      const quoteHeight = doc.heightOfString(`"${quoteText}"`, { width: PAGE.contentWidth - 40 });
      const boxHeight = quoteHeight + 25;
      
      // Light gray background
      doc.rect(PAGE.marginLeft + 10, y, PAGE.contentWidth - 20, boxHeight)
         .fill('#F5F5F5');
      
      // Quote text - italic
      doc.fillColor('#555555')
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(`"${quoteText}"`, PAGE.marginLeft + 20, y + 10, {
           width: PAGE.contentWidth - 40,
           lineGap: 2
         });
      
      // Industry attribution
      doc.fillColor('#888888')
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text(`— ${quoteIndustry}`, PAGE.marginLeft + 20, y + boxHeight - 12);
      
      y += boxHeight + 15;
    }
    
    // ════════════════════════════════════════════════════════════
    // ANALYSIS PARAGRAPH - Natural language, like analyst speaking
    // ════════════════════════════════════════════════════════════
    
    // Build a flowing analysis paragraph
    const quoteDecoded = idea.quoteDecoded || idea.thesis || '';
    const trendContext = idea.trendContext || {};
    const trendExplanation = typeof trendContext === 'string' ? trendContext : (trendContext.explanation || '');
    const directImpact = idea.directImpact || '';
    const conviction = (idea.conviction || 'medium').toLowerCase();
    const risks = idea.risks || ['Market conditions change'];
    const riskText = Array.isArray(risks) ? risks[0] : risks;
    
    // Combine into natural flowing paragraph
    let analysisText = '';
    
    if (quoteDecoded) {
      analysisText += cleanText(quoteDecoded) + ' ';
    }
    
    if (directImpact) {
      analysisText += cleanText(directImpact) + ' ';
    }
    
    // Add conviction naturally
    if (conviction === 'high') {
      analysisText += 'This is a high conviction idea based on the current data. ';
    } else if (conviction === 'low') {
      analysisText += 'This is a lower conviction idea - monitor closely. ';
    }
    
    // Add risk naturally
    if (riskText) {
      analysisText += `Key risk: ${cleanText(riskText).toLowerCase()}.`;
    }
    
    if (analysisText) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(analysisText.trim(), PAGE.marginLeft + 10, y, { 
           width: PAGE.contentWidth - 20,
           lineGap: 3
         });
      y += doc.heightOfString(analysisText, { width: PAGE.contentWidth - 20 }) + 35;
    }
  }
  
  // Disclaimer at bottom
  if (needsPageBreak(y, 40) && onPageBreak) {
    y = onPageBreak();
  }
  
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.small - 1)
     .text('These are analytical frameworks, not trade recommendations. Conduct your own due diligence before any investment decision.', 
           PAGE.marginLeft, y, { width: PAGE.contentWidth });
  y += 25;

  return y;
}

// ════════════════════════════════════════════════════════════
// HELPER: Generate quote-driven trade ideas - ALWAYS CREATES CONTENT
// ════════════════════════════════════════════════════════════
function generateQuoteDrivenDefaults(quotes, ismData, sectorStocks) {
  const { pmi, prices, employment, newOrders, backlog, production } = ismData;
  const isContraction = pmi < 50;
  const isStagflation = pmi < 50 && prices > 55;
  
  const ideas = [];
  
  // Filter to valid quotes only (if any exist)
  const validQuotes = (quotes || []).filter(q => {
    const text = (q.quote || q.comment || q.originalQuote || q.text || '').toLowerCase();
    return text.length > 40 && 
           !text.includes('reported growth') && 
           !text.includes('pmi registered') &&
           !text.includes('survey respondents');
  });
  
  // Find quotes by keywords
  const findQuoteByKeywords = (keywords) => {
    for (const kw of keywords) {
      const match = validQuotes.find(q => {
        const text = (q.quote || q.comment || q.originalQuote || q.text || '').toLowerCase();
        const industry = (q.industry || '').toLowerCase();
        return text.includes(kw) || industry.includes(kw);
      });
      if (match) return match;
    }
    return null;
  };
  
  // ════════════════════════════════════════════════════════════
  // IDEA 1: Consumer Staples / Defensives (ALWAYS CREATED)
  // ════════════════════════════════════════════════════════════
  
  // Only use quote if it's actually from food/beverage industry
  const defensiveQuote = findQuoteByKeywords(['food', 'beverage', 'consumer', 'stable', 'pricing']);
  const isDefensiveQuoteRelevant = defensiveQuote && 
    (defensiveQuote.industry?.toLowerCase().includes('food') || 
     defensiveQuote.industry?.toLowerCase().includes('beverage') ||
     defensiveQuote.industry?.toLowerCase().includes('tobacco'));
  
  ideas.push({
    direction: 'long',
    sector: 'Consumer Staples',  // FIXED - always use correct sector name
    ticker: 'XLP',
    alternativeStocks: ['PG', 'KO', 'PEP', 'COST', 'CL'],
    executiveQuote: isDefensiveQuoteRelevant ? (defensiveQuote?.quote || defensiveQuote?.comment || null) : null,
    executiveQuoteIndustry: isDefensiveQuoteRelevant ? defensiveQuote?.industry : null,
    quoteDecoded: isContraction 
      ? `With PMI at ${pmi}, this is a defensive environment. Consumer staples companies have something most manufacturers don't right now: pricing power. PG and KO can raise prices and customers keep buying - try doing that when you make machinery. These stocks tend to hold up in downturns because demand is inelastic - people still need to eat, clean their homes, and yes, drink Coca-Cola regardless of what the PMI says.`
      : `Even with PMI at ${pmi}, staples make sense as portfolio ballast. These companies generate consistent cash flows and can pass through cost inflation while maintaining volumes. Think of it as insurance against the cycle turning.`,
    directImpact: `Core holdings: PG and KO - brand strength enables pricing power. COST benefits if consumers trade down to warehouse shopping. Avoid KMB - commodity pulp exposure hurts margins in this environment.`,
    conviction: isContraction ? 'high' : 'medium',
    risks: ['Consumer trade-down to private label erodes brand premium', 'Broad market selloff overwhelms defensive positioning']
  });
  
  // ════════════════════════════════════════════════════════════
  // IDEA 2: AI Infrastructure / Semiconductors (ALWAYS CREATED)
  // ════════════════════════════════════════════════════════════
  
  // Only use quote if it's actually from tech/electronics industry
  const techQuote = findQuoteByKeywords(['computer', 'electronic', 'semiconductor', 'tech', 'data center', 'ai']);
  const isTechQuoteRelevant = techQuote && 
    (techQuote.industry?.toLowerCase().includes('computer') || 
     techQuote.industry?.toLowerCase().includes('electronic') ||
     techQuote.industry?.toLowerCase().includes('semiconductor'));
  
  ideas.push({
    direction: 'long',
    sector: 'AI Infrastructure / Semiconductors',  // FIXED - always use correct sector name
    ticker: 'SMH',  // Semiconductor ETF - more accurate than XLK
    alternativeStocks: ['NVDA', 'AVGO', 'AMD', 'ANET'],  // Removed INTC - doesn't fit thesis
    executiveQuote: isTechQuoteRelevant ? (techQuote?.quote || techQuote?.comment || null) : null,
    executiveQuoteIndustry: isTechQuoteRelevant ? techQuote?.industry : null,
    quoteDecoded: `This trade is about structural demand, not the PMI cycle. Hyperscaler capex from Microsoft, Amazon, Google, and Meta is driving AI infrastructure buildout - and that spending is largely independent of whether manufacturing PMI is at ${pmi} or 55. These companies committed to multi-year buildouts and aren't going to pause because traditional manufacturing is weak. NVDA and AVGO are the clearest beneficiaries - they're the picks and shovels of the AI buildout. AMD is a secondary play with more execution risk. We're deliberately excluding INTC because it's tied to the traditional PC cycle, which DOES correlate with manufacturing weakness.`,
    directImpact: `Core positions: NVDA (AI compute), AVGO (networking/custom silicon). Secondary: AMD, ANET (data center networking). Avoid: INTC - legacy PC exposure makes it vulnerable to PMI weakness.`,
    conviction: 'medium',
    risks: ['Hyperscaler capex slowdown', 'Semiconductor inventory correction', 'Valuation compression in risk-off']
  });
  
  // ════════════════════════════════════════════════════════════
  // IDEA 3: Cyclical Short (if contraction) or Industrials Long
  // ════════════════════════════════════════════════════════════
  
  if (isContraction) {
    // Only use quote if it's from machinery/transportation/industrial industry
    const negativeQuote = findQuoteByKeywords(['tariff', 'weak', 'slow', 'decline', 'uncertain', 'layoff', 'cancel', 'machinery', 'equipment']);
    const isIndustrialQuoteRelevant = negativeQuote && 
      (negativeQuote.industry?.toLowerCase().includes('machinery') || 
       negativeQuote.industry?.toLowerCase().includes('transportation') ||
       negativeQuote.industry?.toLowerCase().includes('equipment') ||
       negativeQuote.industry?.toLowerCase().includes('metal'));
    
    ideas.push({
      direction: 'short',
      sector: 'Cyclical Industrials / Machinery',  // FIXED - always use correct sector name
      ticker: 'XLI',
      alternativeStocks: ['CAT', 'DE', 'EMR', 'CMI', 'PCAR'],
      executiveQuote: isIndustrialQuoteRelevant ? (negativeQuote?.quote || negativeQuote?.comment || null) : null,
      executiveQuoteIndustry: isIndustrialQuoteRelevant ? negativeQuote?.industry : null,
      quoteDecoded: `Here's why we're cautious on machinery and industrial equipment: PMI at ${pmi} means demand is contracting, and Employment at ${employment} tells us companies are already cutting costs. Backlog is at ${backlog} - that's the cushion of existing orders, and it's depleting. When corporate customers are uncertain about the future, they defer capital equipment purchases. That's exactly what's happening now. Earnings estimates for these companies are probably still too optimistic.`,
      directImpact: `Underweight or short: DE has the most risk - agricultural cycle weakness adds to manufacturing headwinds. CAT and EMR have infrastructure exposure that provides some floor, but not enough to offset cyclical pressure. PCAR and CMI tied to trucking replacement cycle.`,
      conviction: 'high',
      risks: ['Infrastructure stimulus announcement', 'Trade deal optimism', 'Short squeeze in oversold names']
    });
  } else {
    const industrialQuote = findQuoteByKeywords(['machinery', 'equipment', 'capital', 'expansion', 'infrastructure']);
    const isIndustrialQuoteRelevant = industrialQuote && 
      (industrialQuote.industry?.toLowerCase().includes('machinery') || 
       industrialQuote.industry?.toLowerCase().includes('equipment') ||
       industrialQuote.industry?.toLowerCase().includes('transportation'));
    
    ideas.push({
      direction: 'long',
      sector: 'Industrials / Machinery',  // FIXED - always use correct sector name
      ticker: 'XLI',
      alternativeStocks: ['CAT', 'EMR', 'HON', 'ETN', 'ITW'],
      executiveQuote: isIndustrialQuoteRelevant ? (industrialQuote?.quote || industrialQuote?.comment || null) : null,
      executiveQuoteIndustry: isIndustrialQuoteRelevant ? industrialQuote?.industry : null,
      quoteDecoded: `With PMI at ${pmi}, industrials have tailwinds. These companies have operating leverage - when volumes increase, margins expand disproportionately. Government infrastructure spending provides a demand floor even if private capex moderates. The key is finding companies with backlog visibility and pricing power.`,
      directImpact: `Core holdings: CAT and EMR - infrastructure exposure. HON and ITW for diversified industrial exposure. DE more volatile due to ag cycle exposure.`,
      conviction: 'medium',
      risks: ['PMI rollover below 50', 'Tariff escalation', 'Credit tightening']
    });
  }
  
  // ════════════════════════════════════════════════════════════
  // IDEA 4: Materials / Industrial Gases (based on inventory cycle)
  // ════════════════════════════════════════════════════════════
  
  // Only use quote if it's from chemicals/materials industry
  const materialsQuote = findQuoteByKeywords(['chemical', 'material', 'inventory', 'restock', 'primary metal']);
  const isMaterialsQuoteRelevant = materialsQuote && 
    (materialsQuote.industry?.toLowerCase().includes('chemical') || 
     materialsQuote.industry?.toLowerCase().includes('metal') ||
     materialsQuote.industry?.toLowerCase().includes('material') ||
     materialsQuote.industry?.toLowerCase().includes('petroleum'));
  
  const isRestocking = backlog < 47 || (newOrders > 48 && production < 52);
  
  ideas.push({
    direction: isRestocking ? 'long' : 'short',
    sector: 'Materials / Industrial Gases',  // FIXED - always use correct sector name
    ticker: 'XLB',
    alternativeStocks: ['LIN', 'APD', 'SHW', 'ECL', 'DD'],
    executiveQuote: isMaterialsQuoteRelevant ? (materialsQuote?.quote || materialsQuote?.comment || null) : null,
    executiveQuoteIndustry: isMaterialsQuoteRelevant ? materialsQuote?.industry : null,
    quoteDecoded: isRestocking
      ? `This is a bit contrarian given PMI at ${pmi}, but the inventory data tells a different story. Customer inventories are reported as "too low" and backlog is at ${backlog}. When inventories get this lean, the restocking eventually happens - it's not optional, it's operational necessity. New Orders at ${newOrders} could be the early sign of that cycle starting. Industrial gas companies (LIN, APD) benefit because their products are consumed in manufacturing regardless of what's being made.`
      : `Materials look challenged with production at ${production} and New Orders at ${newOrders}. These are volume-dependent businesses with fixed cost structures - when volumes decline, margins compress. Commodity chemicals are particularly exposed because they don't have pricing power in a weak demand environment.`,
    directImpact: isRestocking
      ? `Core longs: LIN and APD - industrial gas duopoly with contracted revenue. SHW for coatings exposure. Avoid commodity chemicals (DOW) - too much volume sensitivity.`
      : `Underweight or avoid: DOW and commodity chemical names. If shorting, focus on the most volume-sensitive players. LIN and APD are harder to short given contracted revenue base.`,
    conviction: 'medium',
    risks: isRestocking 
      ? ['Demand fails to materialize', 'China oversupply pressures pricing']
      : ['China stimulus drives commodity rally', 'Supply disruption spikes prices']
  });
  
  return ideas;
}

// ============ 11. PRACTICAL POSITIONING (NEW) ============
function drawPracticalPositioning(doc, positioning, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Practical Positioning', 'Action Summary', startY);
  
  // Overweight
  if (positioning.overweight && positioning.overweight.length > 0) {
    doc.fillColor(COLORS.green)
       .font(FONTS.bold)
       .fontSize(SIZES.subSection)
       .text('OVERWEIGHT', PAGE.marginLeft, y);
    y += 16;
    
    for (const item of positioning.overweight.slice(0, 4)) {
      const sector = typeof item === 'string' ? item : item.sector;
      const rationale = typeof item === 'object' ? item.rationale : '';
      
      doc.fillColor(COLORS.green)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('▲', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .font(FONTS.bold)
         .text(` ${sector}`, PAGE.marginLeft + 18, y, { lineBreak: false });
      
      if (rationale) {
        doc.fillColor(COLORS.mediumGray)
           .font(FONTS.body)
           .text(` — ${cleanText(rationale)}`, PAGE.marginLeft + 18 + doc.widthOfString(sector) + 5, y, {
             width: PAGE.contentWidth - doc.widthOfString(sector) - 30
           });
      }
      y += 16;
    }
    y += 10;
  }
  
  // Underweight
  if (positioning.underweight && positioning.underweight.length > 0) {
    doc.fillColor(COLORS.red)
       .font(FONTS.bold)
       .fontSize(SIZES.subSection)
       .text('UNDERWEIGHT', PAGE.marginLeft, y);
    y += 16;
    
    for (const item of positioning.underweight.slice(0, 4)) {
      const sector = typeof item === 'string' ? item : item.sector;
      const rationale = typeof item === 'object' ? item.rationale : '';
      
      doc.fillColor(COLORS.red)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('▼', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.darkText)
         .font(FONTS.bold)
         .text(` ${sector}`, PAGE.marginLeft + 18, y, { lineBreak: false });
      
      if (rationale) {
        doc.fillColor(COLORS.mediumGray)
           .font(FONTS.body)
           .text(` — ${cleanText(rationale)}`, PAGE.marginLeft + 18 + doc.widthOfString(sector) + 5, y, {
             width: PAGE.contentWidth - doc.widthOfString(sector) - 30
           });
      }
      y += 16;
    }
    y += 10;
  }
  
  // Avoid
  if (positioning.avoid && positioning.avoid.length > 0) {
    doc.fillColor(COLORS.black)
       .font(FONTS.bold)
       .fontSize(SIZES.subSection)
       .text('AVOID', PAGE.marginLeft, y);
    y += 16;
    
    for (const item of positioning.avoid.slice(0, 3)) {
      const text = typeof item === 'string' ? item : item.characteristic || item.description;
      doc.fillColor(COLORS.red)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('✗', PAGE.marginLeft + 5, y, { lineBreak: false });
      doc.fillColor(COLORS.mediumGray)
         .text(` ${cleanText(text)}`, PAGE.marginLeft + 18, y, { width: PAGE.contentWidth - 25 });
      y += doc.heightOfString(text, { width: PAGE.contentWidth - 25 }) + 6;
    }
    y += 10;
  }
  
  // Watch for longs
  if (positioning.watchForLongs) {
    doc.fillColor(COLORS.orange)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text('Watch for potential longs if: ', PAGE.marginLeft, y, { lineBreak: false });
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .text(cleanText(positioning.watchForLongs), PAGE.marginLeft + 140, y, { 
         width: PAGE.contentWidth - 145 
       });
    y += doc.heightOfString(positioning.watchForLongs, { width: PAGE.contentWidth - 145 }) + 10;
  }
  
  // Summary action
  if (positioning.summaryAction) {
    y += 5;
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 3).fill(COLORS.gold);
    y += 10;
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.body)
       .text(cleanText(positioning.summaryAction), PAGE.marginLeft, y, { 
         width: PAGE.contentWidth,
         align: 'center'
       });
    y += doc.heightOfString(positioning.summaryAction, { width: PAGE.contentWidth }) + 10;
  }
  
  return y;
}

// ============ 12. INVALIDATION SCENARIOS - FIXED v9.1 ============
function drawInvalidationScenarios(doc, scenarios, startY, onPageBreak, report = {}) {
  // Get ISM data for context
  const ism = report?.ism_manufacturing || report?.ism_data?.manufacturing || {};
  const pmi = ism.pmi || 48;
  const isContraction = pmi < 50;
  
  // ★★★ BUILD FULL TEXT FIRST ★★★
  let text = '';
  if (isContraction) {
    text = `The defensive stance we're recommending would need to change if we see PMI cross back above 50 and stay there for two consecutive months - that would signal a genuine turn in the cycle, not just noise. `;
    text += `Similarly, if New Orders punch through 52, that's the demand recovery signal we'd need to rotate back into cyclicals. `;
    text += `\n\nOn the policy side, watch for any major Fed pivot. Unexpected rate cuts would change the calculus for rate-sensitive sectors, and a surprise hawkish turn would pressure growth stocks further. `;
    text += `Geopolitical events that disrupt supply chains or spike energy prices would also force us to revisit - those tend to hit when you least expect them.`;
    text += `\n\nFinally, if the Prices index drops below 52, that would ease the stagflation concern and open up more options. `;
    text += `And if Employment stabilizes above 50, it would tell us companies have stopped cutting and are ready to grow again.`;
  } else {
    text = `The constructive view would need revision if PMI rolls over below 48 for two consecutive months - that would signal the expansion is losing steam. `;
    text += `A collapse in New Orders below 45 would be an even more urgent warning sign. `;
    text += `\n\nWatch for credit conditions tightening or any Fed hawkish surprises - those can quickly shift the landscape for cyclicals. `;
    text += `Geopolitical shocks remain a wildcard that could change everything overnight.`;
    text += `\n\nIf Prices spike above 60 while PMI weakens, that stagflation scenario would require a complete rethink of positioning.`;
  }
  
  // ★★★ CHECK IF ENTIRE SECTION FITS BEFORE STARTING ★★★
  const headerHeight = 50;
doc.font(FONTS.body).fontSize(SIZES.body);
const textHeight = doc.heightOfString(text, { width: PAGE.contentWidth, lineGap: 3 });
  const totalNeeded = headerHeight + textHeight + 40;
  
  if (startY + totalNeeded > PAGE.safeBottom && onPageBreak) {
    startY = onPageBreak();
  }
  
  // NOW draw the section
  let y = drawSectionHeader(doc, 'What Would Change This View', 'When to Revisit', startY);
  
  doc.fillColor(COLORS.darkText)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(text, PAGE.marginLeft, y, { 
       width: PAGE.contentWidth,
       lineGap: 3
     });
y += doc.heightOfString(text, { width: PAGE.contentWidth, lineGap: 3 }) + 25;

  return y;
}
// ============ 13. NEXT MONTH INDICATORS - FIXED v9.1 ============
function drawNextMonthIndicators(doc, indicators, startY, onPageBreak, report = {}) {
  // Get ISM data for context
  const ism = report?.ism_manufacturing || report?.ism_data?.manufacturing || {};
  const newOrders = ism.newOrders || 47;
  const employment = ism.employment || 44;
  const prices = ism.prices || 58;
  const backlog = ism.backlog || 44;
  
  // ★★★ BUILD FULL TEXT FIRST to calculate height ★★★
  let text = `The most important number to watch next month is New Orders, currently at ${newOrders}. `;
  text += `This is the leading indicator that tells us where PMI is heading - if it starts to turn, we'll see it here first. `;
  text += `\n\nEmployment at ${employment} is the second priority. Right now it's telling us companies are in cost-cutting mode. `;
  text += `If it stabilizes or ticks up, that's a sign the worst may be behind us. If it keeps falling, expect more earnings pressure ahead.`;
  text += `\n\nPrices at ${prices} need monitoring for the inflation story. Any move toward 52 would ease margin concerns; another leg higher would make things tougher for manufacturers.`;
  text += `\n\nBacklog at ${backlog} is your visibility metric - it tells you how much cushion companies have. `;
  text += `Watch for stabilization here as a sign that the order pipeline is refilling.`;
  text += `\n\nOutside of ISM, keep an eye on the regional Fed surveys - Empire State and Philly Fed come out before the national number and can give you an early read. `;
  text += `And don't ignore ISM Services - manufacturing is important, but services is the bigger part of the economy.`;
  
// ★★★ CHECK IF ENTIRE SECTION FITS BEFORE STARTING ★★★
  const headerHeight = 50;
  doc.font(FONTS.body).fontSize(SIZES.body);
  const textHeight = doc.heightOfString(text, { width: PAGE.contentWidth, lineGap: 3 });
  const totalNeeded = headerHeight + textHeight + 50;
  if (startY + totalNeeded > PAGE.safeBottom && onPageBreak) {
    startY = onPageBreak();
  }
  
  // NOW draw the section
  let y = drawSectionHeader(doc, 'What to Watch Next Month', 'Leading Indicators', startY);
  
  doc.fillColor(COLORS.darkText)
     .font(FONTS.body)
     .fontSize(SIZES.body)
     .text(text, PAGE.marginLeft, y, { 
       width: PAGE.contentWidth,
       lineGap: 3
     });
y += doc.heightOfString(text, { width: PAGE.contentWidth, lineGap: 3 }) + 25;

  return y;
}

// ============ 14. SYNTHESIS (NEW) ============
function drawSynthesis(doc, report, startY, onPageBreak) {
  let y = drawSectionHeader(doc, 'Synthesis', 'What The Market May Be Mispricing', startY);
  
  const synthesis = report.synthesis || {};
  const mispricing = report.mispricing || synthesis.mispricing || [];
  
  if (mispricing.length > 0) {
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text('What the market may be mispricing right now:', PAGE.marginLeft, y);
    y += 18;
    
    for (const item of mispricing.slice(0, 4)) {
      const text = typeof item === 'string' ? item : item.description;
      // Draw gold bullet circle
      doc.fillColor(COLORS.gold)
         .circle(PAGE.marginLeft + 8, y + 5, 3)
         .fill();
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(cleanText(text), PAGE.marginLeft + 20, y, { width: PAGE.contentWidth - 30 });
      y += doc.heightOfString(text, { width: PAGE.contentWidth - 30 }) + 10;
    }
  }
  
  // Key unresolved question
  if (synthesis.keyQuestion) {
    y += 10;
    doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, 3).fill(COLORS.gold);
    y += 10;
    
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text('Key Unresolved Question: ', PAGE.marginLeft, y, { lineBreak: false });
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .text(cleanText(synthesis.keyQuestion), PAGE.marginLeft + 140, y, { 
         width: PAGE.contentWidth - 145 
       });
    y += doc.heightOfString(synthesis.keyQuestion, { width: PAGE.contentWidth - 145 }) + 10;
  }
  
  // What flips narrative
  if (synthesis.whatFlipsNarrative) {
    doc.fillColor(COLORS.orange)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text('What would flip our view: ', PAGE.marginLeft, y, { lineBreak: false });
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .text(cleanText(synthesis.whatFlipsNarrative), PAGE.marginLeft + 135, y, { 
         width: PAGE.contentWidth - 140 
       });
    y += doc.heightOfString(synthesis.whatFlipsNarrative, { width: PAGE.contentWidth - 140 }) + 10;
  }
  
  return y;
}

// ============ DISCLAIMER WITH GOLD+BLACK FRAME ============
function generateDisclaimerSection(doc, logoData) {
  doc.addPage();
  
  // BLACK BACKGROUND
  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  
  const frameMargin = 25;
  const frameWidth = PAGE.width - (frameMargin * 2);
  const frameHeight = PAGE.height - (frameMargin * 2);
  
  // OUTER GOLD BORDER (thick)
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .rect(frameMargin, frameMargin, frameWidth, frameHeight)
     .stroke();
  
  // INNER GOLD BORDER (thin - creates double frame effect)
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .rect(frameMargin + 8, frameMargin + 8, frameWidth - 16, frameHeight - 16)
     .stroke();
  
  let y = frameMargin + 35;
  const centerX = PAGE.width / 2;
  const contentMargin = frameMargin + 35;
  const contentWidth = frameWidth - 70;
  
  // ═══════════════════════════════════════════════════════════════════
  // FINOTAUR TEXT
  // ═══════════════════════════════════════════════════════════════════
  doc.fillColor(COLORS.gold)
     .fontSize(28)
     .font(FONTS.bold)
     .text('FINOTAUR', 0, y, { align: 'center', width: PAGE.width });
  
  y += 40;
  
  // LOGO under FINOTAUR text
  if (logoData) {
    try {
      const logoWidth = 120;
      const logoX = (PAGE.width - logoWidth) / 2;
      doc.image(logoData, logoX, y, { width: logoWidth });
      y += 70;
    } catch (e) {
      y += 10;
    }
  } else {
    y += 10;
  }
  
  // Gold decorative line
  doc.strokeColor(COLORS.gold)
     .lineWidth(1.5)
     .moveTo(centerX - 80, y)
     .lineTo(centerX + 80, y)
     .stroke();
  
  y += 25;
  
  // ═══════════════════════════════════════════════════════════════════
  // IMPORTANT DISCLAIMER TITLE
  // ═══════════════════════════════════════════════════════════════════
  doc.fillColor(COLORS.gold)
     .fontSize(18)
     .font(FONTS.bold)
     .text('IMPORTANT DISCLAIMER', 0, y, { align: 'center', width: PAGE.width });
  
  y += 30;
  
  // Gold line under title
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .moveTo(centerX - 100, y)
     .lineTo(centerX + 100, y)
     .stroke();
  
  y += 25;
  
  // ═══════════════════════════════════════════════════════════════════
  // DISCLAIMER SECTIONS
  // ═══════════════════════════════════════════════════════════════════
  const disclaimerSections = [
    {
      title: 'GENERAL INFORMATION ONLY',
      content: 'This report is produced by Finotaur for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.'
    },
    {
      title: 'NOT INVESTMENT ADVICE',
      content: 'This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. Finotaur is NOT a registered investment adviser or broker-dealer.'
    },
    {
      title: 'RISK DISCLOSURE',
      content: 'Trading and investing involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital.'
    },
    {
      title: 'NO GUARANTEES',
      content: 'Finotaur makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.'
    },
    {
      title: 'YOUR RESPONSIBILITY',
      content: 'You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.'
    },
    {
      title: 'LIMITATION OF LIABILITY',
      content: 'Finotaur shall NOT be liable for any damages arising from your use of or reliance on this report.'
    }
  ];
  
  for (const section of disclaimerSections) {
    if (y > PAGE.height - 200) break;
    
    // Section title in GOLD with line underneath
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(9)
       .text(section.title, contentMargin, y);
    
    y += 12;
    
    // Small gold line under section title
    doc.strokeColor(COLORS.gold)
       .lineWidth(0.5)
       .moveTo(contentMargin, y)
       .lineTo(contentMargin + 120, y)
       .stroke();
    
    y += 8;
    
    // Section content in WHITE
    doc.fillColor('#FFFFFF')
       .font(FONTS.body)
       .fontSize(8.5)
       .text(section.content, contentMargin, y, { width: contentWidth, align: 'justify' });
    
    y += doc.heightOfString(section.content, { width: contentWidth }) + 12;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // COPYRIGHT WARNING - RED BOX
  // ═══════════════════════════════════════════════════════════════════
  
  y = PAGE.height - frameMargin - 135;
  
  // Red warning box
  const warningBoxX = contentMargin - 8;
  const warningBoxWidth = contentWidth + 16;
  const warningBoxHeight = 75;
  
  // Dark red background
  doc.rect(warningBoxX, y, warningBoxWidth, warningBoxHeight)
     .fill('#330000');
  
  // Red border
  doc.strokeColor('#CC0000')
     .lineWidth(2)
     .rect(warningBoxX, y, warningBoxWidth, warningBoxHeight)
     .stroke();
  
  y += 10;
  
  // Warning title in RED
  doc.fillColor('#FF3333')
     .font(FONTS.bold)
     .fontSize(10)
     .text('⚠ COPYRIGHT WARNING', contentMargin, y, { width: contentWidth, align: 'center' });
  
  y += 16;
  
  // Warning text in lighter red
  const copyrightWarning = 'This report is the exclusive intellectual property of FINOTAUR. Unauthorized reproduction, distribution, transmission, display, or publication of this report, in whole or in part, without the prior written consent of FINOTAUR is strictly prohibited and constitutes a violation of copyright law. Violators will be subject to legal action and may be liable for statutory damages.';
  
  doc.fillColor('#FF6666')
     .font(FONTS.body)
     .fontSize(7.5)
     .text(copyrightWarning, contentMargin, y, { width: contentWidth, align: 'justify' });
  
  // ═══════════════════════════════════════════════════════════════════
  // BOTTOM - Copyright and acknowledgment
  // ═══════════════════════════════════════════════════════════════════
  
  y = PAGE.height - frameMargin - 40;
  
  // Thin gold line
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .moveTo(contentMargin, y)
     .lineTo(contentMargin + contentWidth, y)
     .stroke();
  
  y += 12;
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.body)
     .fontSize(8)
     .text(`© ${new Date().getFullYear()} Finotaur. All Rights Reserved.`, 
           contentMargin, y, { width: contentWidth, align: 'center' });
  
  y += 12;
  
  doc.fillColor('#888888')
     .font(FONTS.body)
     .fontSize(7)
     .text('By reading this report, you acknowledge and agree to the terms above.', 
           contentMargin, y, { width: contentWidth, align: 'center' });
}

// ============ FILE-BASED GENERATION ============
async function generateISMReportPDF(report, logoData, outputPath) {
  const buffer = await generateISMReportPDFBuffer(report, logoData);
  fs.writeFileSync(outputPath, buffer);
  return {
    path: outputPath,
    filename: path.basename(outputPath),
    size: buffer.length,
  };
}

// ============ EXPORTS ============
export {
  generateISMReportPDFBuffer,
  generateISMReportPDF,
};