// =====================================================
// ISM REPORT EMAIL SERVICE - PROFESSIONAL v2.0
// =====================================================
// Location: src/TopSecret/ISM/email-service.js
//
// Clean professional emails - NO EMOJIS, NO "TOP SECRET"
// =====================================================

const nodemailer = require('nodemailer');

// ============================================
// EMAIL CONFIGURATION
// ============================================

const EMAIL_CONFIG = {
  from: process.env.EMAIL_FROM || 'reports@finotaur.com',
  fromName: process.env.EMAIL_FROM_NAME || 'Finotaur Reports',
  replyTo: process.env.EMAIL_REPLY_TO || 'support@finotaur.com',
};

// ============================================
// CREATE TRANSPORTER
// ============================================

function createTransporter() {
  // Check which email provider is configured
  if (process.env.SMTP_HOST) {
    // Generic SMTP
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  
  if (process.env.SENDGRID_API_KEY) {
    // SendGrid
    return nodemailer.createTransport({
      host: 'smtp.sendgrid.net',
      port: 587,
      auth: {
        user: 'apikey',
        pass: process.env.SENDGRID_API_KEY,
      },
    });
  }
  
  if (process.env.MAILGUN_API_KEY) {
    // Mailgun
    return nodemailer.createTransport({
      host: 'smtp.mailgun.org',
      port: 587,
      auth: {
        user: process.env.MAILGUN_USER || 'postmaster@mg.finotaur.com',
        pass: process.env.MAILGUN_API_KEY,
      },
    });
  }
  
  if (process.env.AWS_SES_REGION) {
    // AWS SES
    const aws = require('@aws-sdk/client-ses');
    const { defaultProvider } = require('@aws-sdk/credential-provider-node');
    
    const ses = new aws.SES({
      region: process.env.AWS_SES_REGION,
      credentials: defaultProvider(),
    });
    
    return nodemailer.createTransport({
      SES: { ses, aws },
    });
  }
  
  // Fallback: Ethereal (for testing)
  console.warn('[ISMEmail] No email provider configured, using Ethereal test account');
  return nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
      user: 'ethereal.user@ethereal.email',
      pass: 'ethereal.pass',
    },
  });
}

// ============================================
// EMAIL TEMPLATES - PROFESSIONAL (NO EMOJIS)
// ============================================

/**
 * Generate HTML email template - CLEAN PROFESSIONAL
 */
function generateEmailHTML(data) {
  const { recipientName, reportMonth, executiveSummary, isPremium } = data;
  
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ISM Manufacturing Report - ${reportMonth}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0a0a12;
      color: #e5e5e5;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: #111118;
      border-radius: 12px;
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      padding: 25px;
      text-align: center;
      border-bottom: 3px solid #C9A646;
    }
    .header h1 {
      color: #C9A646;
      margin: 0;
      font-size: 18px;
      letter-spacing: 1px;
      font-weight: 600;
    }
    .header .subtitle {
      color: #888;
      font-size: 13px;
      margin-top: 5px;
    }
    .content {
      padding: 30px;
    }
    .title {
      color: #C9A646;
      font-size: 24px;
      margin-bottom: 5px;
    }
    .month-label {
      color: #888;
      font-size: 16px;
      margin-bottom: 25px;
    }
    .greeting {
      color: #e5e5e5;
      margin-bottom: 20px;
      line-height: 1.6;
    }
    .summary-box {
      background: rgba(201, 166, 70, 0.08);
      border-left: 4px solid #C9A646;
      padding: 20px;
      margin: 20px 0;
      border-radius: 0 8px 8px 0;
    }
    .summary-title {
      margin-top: 0;
      color: #C9A646;
      font-size: 16px;
      margin-bottom: 15px;
    }
    .summary-item {
      margin-bottom: 12px;
      line-height: 1.5;
    }
    .summary-label {
      color: #C9A646;
      font-weight: 600;
      display: inline;
    }
    .summary-value {
      color: #e5e5e5;
    }
    .cta-button {
      display: inline-block;
      background: #C9A646;
      color: #000;
      padding: 14px 28px;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
      margin: 20px 0;
    }
    .attachment-note {
      background: rgba(255,255,255,0.05);
      padding: 18px;
      border-radius: 8px;
      margin: 20px 0;
      font-size: 14px;
      border: 1px solid rgba(201, 166, 70, 0.2);
    }
    .attachment-note strong {
      color: #C9A646;
    }
    .attachment-note ul {
      margin: 12px 0 0 0;
      padding-left: 20px;
      color: #ccc;
    }
    .attachment-note li {
      margin-bottom: 6px;
    }
    .footer {
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      padding: 20px;
      text-align: center;
      border-top: 1px solid #333;
    }
    .footer-text {
      color: #888;
      font-size: 12px;
      margin: 0;
    }
    .footer-brand {
      color: #C9A646;
      font-weight: 600;
    }
    .disclaimer {
      color: #666;
      font-size: 11px;
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid #333;
      line-height: 1.5;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Institutional Grade Analysis</h1>
      <p class="subtitle">ISM Manufacturing Intelligence</p>
    </div>
    
    <div class="content">
      <h1 class="title">ISM Manufacturing Report</h1>
      <p class="month-label">${reportMonth}</p>
      
      <p class="greeting">Hello${recipientName ? ` ${recipientName}` : ''},</p>
      
      <p style="color: #ccc; line-height: 1.6;">Your ${reportMonth} ISM Manufacturing Report is ready. This report provides institutional-grade analysis of the latest ISM data with actionable trade ideas.</p>
      
      ${executiveSummary ? `
      <div class="summary-box">
        <h3 class="summary-title">Executive Summary</h3>
        ${executiveSummary.situation ? `<div class="summary-item"><span class="summary-label">Situation:</span> <span class="summary-value">${executiveSummary.situation}</span></div>` : ''}
        ${executiveSummary.trend ? `<div class="summary-item"><span class="summary-label">Trend:</span> <span class="summary-value">${executiveSummary.trend}</span></div>` : ''}
        ${executiveSummary.sectors ? `<div class="summary-item"><span class="summary-label">Sectors:</span> <span class="summary-value">${executiveSummary.sectors}</span></div>` : ''}
        ${executiveSummary.risk ? `<div class="summary-item"><span class="summary-label">Risk:</span> <span class="summary-value">${executiveSummary.risk}</span></div>` : ''}
        ${executiveSummary.action ? `<div class="summary-item"><span class="summary-label">Action:</span> <span class="summary-value">${executiveSummary.action}</span></div>` : ''}
      </div>
      ` : ''}
      
      <div class="attachment-note">
        <strong>PDF Report Attached</strong><br>
        The full report is attached to this email. It includes:
        <ul>
          <li>Macro Regime Snapshot</li>
          <li>Trend Engine Analysis</li>
          <li>Sector Impact Rankings</li>
          <li>Equity Selection Logic</li>
          <li>Actionable Trade Ideas</li>
        </ul>
      </div>
      
      ${isPremium ? `
      <p style="color: #ccc;">As a Premium subscriber, you have full access to all report sections and trade ideas.</p>
      ` : `
      <p style="color: #ccc;">Upgrade to Premium for complete access to all trade ideas and detailed analysis.</p>
      <a href="https://finotaur.com/premium" class="cta-button">Upgrade to Premium</a>
      `}
      
      <div class="disclaimer">
        <strong>DISCLAIMER:</strong> This report is for educational and informational purposes only. It does not constitute investment advice or a recommendation to buy or sell any security. Past performance is not indicative of future results. See the full disclaimer in the attached PDF.
      </div>
    </div>
    
    <div class="footer">
      <p class="footer-text"><span class="footer-brand">FINOTAUR</span> | Institutional Grade Research</p>
      <p class="footer-text" style="margin-top: 5px;">&copy; ${new Date().getFullYear()} Finotaur. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
  `.trim();
}

/**
 * Generate plain text email - CLEAN PROFESSIONAL
 */
function generateEmailText(data) {
  const { recipientName, reportMonth, executiveSummary } = data;
  
  let text = `
════════════════════════════════════════════════════════
ISM MANUFACTURING REPORT
${reportMonth}
Institutional Grade Analysis
════════════════════════════════════════════════════════

Hello${recipientName ? ` ${recipientName}` : ''},

Your ${reportMonth} ISM Manufacturing Report is ready.

`;

  if (executiveSummary) {
    text += `
EXECUTIVE SUMMARY
─────────────────────
`;
    if (executiveSummary.situation) text += `Situation: ${executiveSummary.situation}\n`;
    if (executiveSummary.trend) text += `Trend: ${executiveSummary.trend}\n`;
    if (executiveSummary.sectors) text += `Sectors: ${executiveSummary.sectors}\n`;
    if (executiveSummary.risk) text += `Risk: ${executiveSummary.risk}\n`;
    if (executiveSummary.action) text += `Action: ${executiveSummary.action}\n`;
  }

  text += `

PDF REPORT ATTACHED
─────────────────────
The full report is attached to this email. It includes:
- Macro Regime Snapshot
- Trend Engine Analysis  
- Sector Impact Rankings
- Equity Selection Logic
- Actionable Trade Ideas

════════════════════════════════════════════════════════
DISCLAIMER: This report is for educational purposes only.
It does not constitute investment advice.
════════════════════════════════════════════════════════
© ${new Date().getFullYear()} FINOTAUR | Institutional Grade Research
`;

  return text.trim();
}

// ============================================
// MAIN SEND FUNCTION
// ============================================

/**
 * Send ISM report email
 */
async function sendISMReportEmail(options) {
  const {
    to,
    recipientName,
    reportMonth,
    report,
    pdfBuffer,
    isPremium = true,
  } = options;

  if (!to) {
    throw new Error('Recipient email is required');
  }

  if (!pdfBuffer) {
    throw new Error('PDF buffer is required');
  }

  const transporter = createTransporter();

  // Extract executive summary
  const executiveSummary = report.executive_summary?.summary || report.executive_summary || null;

  // Generate email content
  const htmlContent = generateEmailHTML({
    recipientName,
    reportMonth,
    executiveSummary,
    isPremium,
  });

  const textContent = generateEmailText({
    recipientName,
    reportMonth,
    executiveSummary,
  });

  // Prepare email - CLEAN SUBJECT LINE
  const mailOptions = {
    from: `"${EMAIL_CONFIG.fromName}" <${EMAIL_CONFIG.from}>`,
    replyTo: EMAIL_CONFIG.replyTo,
    to,
    subject: `ISM Manufacturing Report - ${reportMonth}`,
    text: textContent,
    html: htmlContent,
    attachments: [
      {
        filename: `ISM_Report_${reportMonth.replace(/\s+/g, '_')}.pdf`,
        content: pdfBuffer,
        contentType: 'application/pdf',
      },
    ],
    headers: {
      'X-Priority': '1',
      'X-Report-Type': 'ISM-Manufacturing',
      'X-Report-Month': reportMonth,
    },
  };

  // Send email
  try {
    const result = await transporter.sendMail(mailOptions);
    
    console.log(`[ISMEmail] Email sent to ${to}: ${result.messageId}`);
    
    return {
      success: true,
      messageId: result.messageId,
      recipient: to,
    };
    
  } catch (error) {
    console.error(`[ISMEmail] Failed to send email to ${to}:`, error);
    
    throw error;
  }
}

// ============================================
// BATCH SEND
// ============================================

/**
 * Send ISM report to multiple recipients
 */
async function sendISMReportToSubscribers(options) {
  const {
    subscribers, // Array of { email, name, isPremium }
    reportMonth,
    report,
    pdfBuffer,
    onProgress,
  } = options;

  const results = {
    sent: [],
    failed: [],
    total: subscribers.length,
  };

  for (let i = 0; i < subscribers.length; i++) {
    const subscriber = subscribers[i];
    
    try {
      await sendISMReportEmail({
        to: subscriber.email,
        recipientName: subscriber.name,
        reportMonth,
        report,
        pdfBuffer,
        isPremium: subscriber.isPremium !== false,
      });
      
      results.sent.push(subscriber.email);
      
    } catch (error) {
      results.failed.push({
        email: subscriber.email,
        error: error.message,
      });
    }

    // Report progress
    if (onProgress) {
      onProgress({
        current: i + 1,
        total: subscribers.length,
        lastEmail: subscriber.email,
        success: !results.failed.find(f => f.email === subscriber.email),
      });
    }

    // Small delay between emails to avoid rate limiting
    if (i < subscribers.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 200));
    }
  }

  console.log(`[ISMEmail] Batch complete: ${results.sent.length} sent, ${results.failed.length} failed`);

  return results;
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  sendISMReportEmail,
  sendISMReportToSubscribers,
  generateEmailHTML,
  generateEmailText,
  createTransporter,
  EMAIL_CONFIG,
};