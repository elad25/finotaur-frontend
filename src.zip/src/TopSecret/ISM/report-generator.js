// =====================================================
// ISM REPORT GENERATOR - INSTITUTIONAL QUALITY v14.0
// =====================================================
// 
// ISM Monthly Macro & Sector Intelligence Report
// Frequency: Monthly
// Audience: Investors, traders, analysts (not beginners)
// Tone: Human, sharp, analytical - not academic or marketing
// Goal: Understand what changed, why it matters, where money will be affected
//
// v14.0 CHANGES:
// - NEW PAGE 0: Analyst Context & Why This Report Matters (½ page)
// - NEW PAGE 1: ISM Macro Snapshot (The Big Picture)
// - NEW PAGE 2: Under-the-Surface Signals (Internal Tensions + Trend Detection)
// - Preserved Pages 3-7 for future updates
// - Enhanced Hebrew-Israeli analyst voice
// - Focus on "What Changed" not just data
//
// ABSOLUTE RULES - VIOLATING ANY IS FAILURE:
// 1. ZERO emojis - not one character
// 2. ZERO markdown tables - no | characters
// 3. ZERO marketing language
// 4. ZERO Entry/Stop/Target in trade ideas
// 5. Prose paragraphs, not bullet lists for analysis
// 6. Human analyst voice with "we" perspective
// 7. Opinionated views, not summaries
// 8. Focus on WHAT CHANGED, not what the number is
//
// =====================================================

import { REPORT_SECTIONS, ADDITIONAL_SECTIONS, KEY_SECTORS, STOCK_ARCHETYPES } from './config.js';
import { ISMQuoteStorage } from './quote-storage.js';

let reportQuoteStorage = null;

function getReportQuoteStorage() {
  if (!reportQuoteStorage) {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    reportQuoteStorage = new ISMQuoteStorage(supabaseUrl, supabaseKey);
  }
  return reportQuoteStorage;
}
// ============================================
// CLEAN TEXT - Strips ALL emojis/decorators
// ============================================

function cleanText(text) {
  if (!text) return '';
  if (typeof text !== 'string') return String(text);
  
  return text
    .replace(/[\u{1F300}-\u{1FAFF}]/gu, '')
    .replace(/[\u{2600}-\u{27BF}]/gu, '')
    .replace(/[\u{FE00}-\u{FE0F}]/gu, '')
    .replace(/[\u{1F000}-\u{1F02F}]/gu, '')
    .replace(/[\u{1F0A0}-\u{1F0FF}]/gu, '')
    .replace(/[\u{200D}]/gu, '')
    .replace(/[\u{2300}-\u{23FF}]/gu, '')
    .replace(/[\u{2700}-\u{27BF}]/gu, '')
    .replace(/[\u{E000}-\u{F8FF}]/gu, '')
    .replace(/[│├└┌┐┘┬┴┼─═║]/g, '')
    .replace(/[★☆✦✧◆◇◈▶►▷▻◀◄◁◅↑↓←→⇐⇒⇑⇓↔↕]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function deepClean(obj) {
  if (typeof obj === 'string') return cleanText(obj);
  if (Array.isArray(obj)) return obj.map(deepClean);
  if (obj && typeof obj === 'object') {
    const cleaned = {};
    for (const [key, value] of Object.entries(obj)) {
      cleaned[key] = deepClean(value);
    }
    return cleaned;
  }
  return obj;
}

// ============================================
// FORMAT HELPERS
// ============================================

function formatMonthDisplay(month) {
  if (!month) return '';
  const [year, monthNum] = month.split('-');
  const date = new Date(parseInt(year), parseInt(monthNum) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

function formatNumber(num) {
  if (num === null || num === undefined) return 'N/A';
  return Number(num).toFixed(1);
}

function formatDelta(delta) {
  if (delta === null || delta === undefined) return '—';
  const sign = delta > 0 ? '+' : '';
  return `${sign}${delta.toFixed(1)}`;
}

function getOrdinalSuffix(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return (s[(v - 20) % 10] || s[v] || s[0]);
}

// ============================================
// MACRO REGIME DETERMINATION
// ============================================

function determineRegime(mfg, momChanges) {
  const pmi = mfg.pmi || 50;
  const newOrders = mfg.newOrders || 50;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const pmiDelta = momChanges?.pmi?.delta || 0;
  
  // Stagflation
  if (pmi < 50 && prices > 55 && employment < 48) {
    return { regime: 'Contraction', subtype: 'Stagflation Risk', confidence: 'High' };
  }
  
  // Contraction deepening
  if (pmi < 50 && pmiDelta < -1) {
    return { regime: 'Contraction', subtype: 'Deepening', confidence: 'High' };
  }
  
  // Contraction stabilizing/recovering
  if (pmi < 50 && pmiDelta > 0.5) {
    return { regime: 'Contraction', subtype: 'Early Recovery Signs', confidence: 'Medium' };
  }
  
  // Transition zone
  if (pmi >= 48 && pmi <= 52) {
    return { regime: 'Transition', subtype: 'Inflection Point', confidence: 'Low' };
  }
  
  // Expansion accelerating
  if (pmi >= 52 && pmiDelta > 0.5 && newOrders > 52) {
    return { regime: 'Expansion', subtype: 'Accelerating', confidence: 'High' };
  }
  
  // Expansion decelerating
  if (pmi >= 50 && pmiDelta < -0.5) {
    return { regime: 'Slowdown', subtype: 'Decelerating', confidence: 'Medium' };
  }
  
  // Basic contraction
  if (pmi < 50) {
    return { regime: 'Contraction', subtype: null, confidence: 'Medium' };
  }
  
  // Basic expansion
  return { regime: 'Expansion', subtype: null, confidence: 'Medium' };
}

// ============================================
// MAIN MARKDOWN REPORT GENERATOR
// ============================================

async function generateMarkdownReport(report, context) {
  const { meta, executiveSummary, sections, supplementary, invalidationScenarios, nextMonthIndicators } = report;
  
  const month = context.reportMonth;
  const ismData = context.results?.ism_data_fetcher;
  const mfg = ismData?.manufacturing || {};
  const momChanges = ismData?.momChanges || {};
  const priorMonth = ismData?.priorMonth || {};
const historical = supplementary?.historical || {};
  
  // ★★★ LOAD FROM DATABASE ★★★
  const storage = getReportQuoteStorage();
  let dbData = null;
  
  if (month && storage) {
    try {
      dbData = await storage.getDataForPDFGeneration(month);
      console.log(`[ReportGen] ✓ Loaded: ${dbData.meta.quoteCount} quotes, ${dbData.meta.sectorCount} sectors, ${dbData.meta.tradeIdeaCount} trades`);
      
      // Enrich sectorImpact with quoteSupport from DB
      if (dbData.sectorRankings && dbData.sectorRankings.length > 0) {
        if (!sections.sectorImpact) sections.sectorImpact = {};
        sections.sectorImpact.sectors = dbData.sectorRankings.map(db => ({
          sector: db.sector_name,
          etf: db.sector_etf,
          rank: db.rank,
          impactScore: db.impact_score,
          direction: db.direction,
          reasoning: db.reasoning,
          quoteSupport: db.quote_support,  // ★ KEY FIELD
          quoteSupportIndustry: db.quote_support_industry,
          changeVsLastMonth: db.change_vs_last_month,
          whyNow: db.why_now,
          keyStocks: db.key_stocks || [],
        }));
      }
      
      // Enrich tradeIdeas with executiveQuote from DB
      if (dbData.tradeIdeas && dbData.tradeIdeas.length > 0) {
        if (!sections.tradeIdeas) sections.tradeIdeas = {};
        sections.tradeIdeas.ideas = dbData.tradeIdeas.map(db => ({
          direction: db.direction,
          sector: db.sector,
          title: db.title,
          etf: db.etf,
          stocks: db.stocks || [],
          thesis: db.thesis,
          executiveQuote: db.executive_quote,  // ★ KEY FIELD
          executiveQuoteIndustry: db.executive_quote_industry,
          directImpact: db.direct_impact,  // ★ KEY FIELD
          conviction: db.conviction,
          invalidation: db.invalidation || [],
          risks: db.risks || [],
        }));
      }
    } catch (error) {
      console.warn(`[ReportGen] DB load failed: ${error.message}`);
    }
  }
  
  // ★★★ ENHANCED QUOTE SOURCING ★★★
  // Try multiple sources for quotes
  let quotes = ismData?.respondentComments || [];
  if (quotes.length === 0) quotes = report?.respondentComments || [];
  if (quotes.length === 0) quotes = report?.quotes_analysis?.quotes || [];
  if (quotes.length === 0) quotes = report?.industry_quotes?.quotes || [];
  if (quotes.length === 0) quotes = report?.ism_data?.respondentComments || [];
  if (quotes.length === 0) quotes = report?.rawData?.respondentComments || [];
  
  console.log('[ReportGen] Quotes found:', quotes.length);
  
  const quoteAnalysis = context.results?.quote_analyzer || report?.quotes_analysis || {};
  
  // Clean all data upfront
  const cleanMfg = deepClean(mfg);
  const cleanSections = deepClean(sections);
  
  let md = '';

  // ========== COVER / HEADER ==========
  md += `# ISM Monthly Macro & Sector Intelligence Report\n`;
  md += `## ${formatMonthDisplay(month)}\n\n`;
  md += `---\n\n`;

  // =====================================================
  // PAGE 0 — Analyst Context & Why This Report Matters
  // =====================================================
  md += writePage0_AnalystContext(cleanMfg, historical, cleanSections, momChanges, priorMonth);
  md += `\n\n---\n\n`;

  // =====================================================
  // PAGE 1 — ISM Macro Snapshot (The Big Picture)
  // =====================================================
  md += writePage1_MacroSnapshot(cleanMfg, priorMonth, momChanges, cleanSections);
  md += `\n\n---\n\n`;

  // =====================================================
  // PAGE 2 — Under-the-Surface Signals
  // =====================================================
  md += writePage2_UnderTheSurface(cleanMfg, momChanges, historical, cleanSections);
  md += `\n\n---\n\n`;

  // =====================================================
  // PAGE 3 — Sector-Level Impact (Who Feels It First)
  // =====================================================
  md += writePage3_SectorImpact(cleanMfg, cleanSections?.sectorImpact, momChanges, historical);
  md += `\n\n---\n\n`;

  // =====================================================
  // PAGE 4 — Voices from the Field (Executive Commentary)
  // =====================================================
  md += writePage4_VoicesFromField(quotes, quoteAnalysis, cleanMfg, cleanSections?.sectorImpact);
  md += `\n\n---\n\n`;

  // =====================================================
  // PAGE 5 — Sector in Focus (The Funnel Tip)
  // =====================================================
  md += writePage5_SectorInFocus(cleanMfg, cleanSections?.sectorImpact, cleanSections?.tradeIdeas, momChanges);
  md += `\n\n---\n\n`;

  // =====================================================
  // PAGES 6-7 - Remaining Sections
  // =====================================================

  // ========== PRACTICAL POSITIONING ==========
  md += `## Practical Positioning Summary\n\n`;
  md += writePracticalPositioning(cleanMfg, cleanSections?.sectorImpact, cleanSections?.tradeIdeas, momChanges);
  md += `\n\n---\n\n`;

  // ========== WHAT WOULD CHANGE OUR VIEW ==========
  md += `## What Would Change This View\n\n`;
  md += writeInvalidation(invalidationScenarios, cleanMfg, momChanges);
  md += `\n\n---\n\n`;

  // ========== INDICATORS TO WATCH ==========
  md += `## Key Indicators for Next Month\n\n`;
  md += writeWatchlist(nextMonthIndicators, cleanMfg);
  md += `\n\n---\n\n`;

  // ========== SIGNAL HIERARCHY (if available) ==========
  const gapData = context.results?.gap_analyzer;
  if (gapData?.signalHierarchy) {
    md += writeSignalHierarchy(gapData.signalHierarchy);
    md += `\n\n---\n\n`;
  }

  // ========== THE EDGE - MISPRICING (if available) ==========
  if (executiveSummary?.mispricing) {
    md += writeMispricingCall(executiveSummary.mispricing);
    md += `\n\n---\n\n`;
  }

  // ========== COUNTER-THESIS (if available) ==========
  const regimeData = context.results?.macro_regime_detector;
  if (regimeData?.alternativeInterpretation) {
    md += writeCounterThesis(regimeData);
    md += `\n\n---\n\n`;
  }

  // ========== DISCLAIMER ==========
  md += `*This analysis is for informational purposes only and does not constitute investment advice. `;
  md += `Past performance is not indicative of future results.*\n`;

  return md;
}

// =====================================================
// PAGE 0 — Analyst Context & Why This Report Matters
// =====================================================
// Purpose: Get the reader into macro analyst mindset
// Length: ½ page
// =====================================================

function writePage0_AnalystContext(mfg, historical, sections, momChanges, priorMonth) {
  const pmi = mfg.pmi || 0;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const newOrders = mfg.newOrders || 50;
  const consecutive = historical.consecutiveContractionMonths || 0;
  const pmiDelta = momChanges?.pmi?.delta || 0;
  const priorPmi = priorMonth?.pmi || pmi;
  const priorPrices = priorMonth?.prices || prices;
  const priorEmployment = priorMonth?.employment || employment;
  
  let context = `## Analyst Context & Why This Report Matters\n\n`;
  
  // =========================================
  // Formal Regime Label (NEW)
  // =========================================
  
  const regimeInfo = determineRegimeLabel(pmi, prices, employment, newOrders, pmiDelta, consecutive);
  
  context += `**Regime:** ${regimeInfo.label}\n`;
  context += `**Confidence:** ${regimeInfo.confidence}\n\n`;
  
  // =========================================
  // Personal Opening Paragraph
  // Why this month's report is different from last month
  // =========================================
  
  context += `**Why This Month Is Different**\n\n`;
  
  // Determine the narrative: Inflection / Escalation / Continuation
  if (pmi < 50 && priorPmi >= 50) {
    // Crossed into contraction - INFLECTION
    context += `This is the month manufacturing crossed below 50. `;
    context += `The headline change from ${formatNumber(priorPmi)} to ${formatNumber(pmi)} is not just a number—it marks a regime shift. `;
    context += `We are no longer debating whether the expansion is slowing; we are now in contraction territory. `;
    context += `The question changes from "how fast are we growing" to "how deep and how long."\n\n`;
    
    // Last month connection
    context += `*Last month we flagged decelerating momentum in an expansion—this month confirms the expansion has ended.*\n\n`;
    
  } else if (pmi >= 50 && priorPmi < 50) {
    // Crossed into expansion - INFLECTION
    context += `Manufacturing crossed back above 50 this month. `;
    context += `After ${consecutive > 0 ? consecutive + ' months of contraction' : 'a period of weakness'}, the ${formatDelta(pmiDelta)} point improvement marks a potential inflection. `;
    context += `The question now is whether this is a sustainable recovery or a dead-cat bounce. The components underneath will tell us.\n\n`;
    
    // Last month connection
    context += `*Last month we flagged early stabilization signals—this month the data confirms the turn, though durability remains uncertain.*\n\n`;
    
  } else if (pmi < 48 && prices > 55 && employment < 48) {
    // Stagflation pocket - ESCALATION
    context += `We are navigating a stagflationary pocket within manufacturing—and it is getting worse. `;
    context += `PMI at ${formatNumber(pmi)}, Prices at ${formatNumber(prices)}, Employment at ${formatNumber(employment)}. `;
    context += `This is the most challenging operating environment: falling demand combined with rising costs.\n\n`;
    
    // Last month connection
    if (priorPrices > 55 && priorEmployment < 48) {
      context += `*Last month we flagged stagflation risk—this month confirms the difficulty is structural, not transitory.*\n\n`;
    } else {
      context += `*Last month the stagflation setup was emerging—this month it is fully entrenched.*\n\n`;
    }
    
  } else if (Math.abs(pmiDelta) < 0.5 && pmi < 50) {
    // Sideways in contraction - CONTINUATION
    context += `Manufacturing remains stuck. The ${formatNumber(pmi)} reading is essentially unchanged from last month. `;
    context += `This is not stabilization—it is prolonged weakness. `;
    context += `The market may be hoping for a bounce, but the data shows no catalyst for one yet.\n\n`;
    
    // Last month connection
    context += `*Last month we flagged continuation of contraction—this month neither confirms nor invalidates that view. We remain in the same regime.*\n\n`;
    
  } else if (pmiDelta < -1.5) {
    // Accelerating weakness - ESCALATION
    context += `The deterioration is accelerating. `;
    context += `A ${formatDelta(pmiDelta)} point decline is not noise—it is a signal that conditions are getting worse faster. `;
    context += `The direction matters more than the level right now.\n\n`;
    
    // Last month connection
    context += `*Last month we flagged weakness—this month we are flagging acceleration. The downside has momentum.*\n\n`;
    
  } else if (pmiDelta > 1.5 && pmi < 50) {
    // Early recovery signs - INFLECTION potential
    context += `For the first time in ${consecutive > 0 ? consecutive : 'several'} months, we see genuine improvement. `;
    context += `The ${formatDelta(pmiDelta)} point gain while still in contraction territory is meaningful. `;
    context += `This month's report is different because we are looking for confirmation of a turn, not just measuring damage.\n\n`;
    
    // Last month connection
    context += `*Last month we flagged contraction—this month we are asking whether that narrative is about to change.*\n\n`;
    
  } else {
    // General continuation with context
    if (pmi >= 50) {
      context += `Manufacturing continues to expand at ${formatNumber(pmi)}. `;
      context += `The change of ${formatDelta(pmiDelta)} versus last month represents ${Math.abs(pmiDelta) > 1 ? 'meaningful' : 'modest'} movement. `;
      context += `The question this month is not whether we are expanding—we are—but whether the quality of expansion is improving or deteriorating.\n\n`;
      
      // Last month connection
      if (pmiDelta > 0) {
        context += `*Last month we noted expansion—this month the expansion strengthens. The trend remains intact.*\n\n`;
      } else {
        context += `*Last month we noted expansion—this month the data neither confirms acceleration nor signals rollover.*\n\n`;
      }
    } else {
      context += `Manufacturing contracted for ${consecutive > 0 ? `the ${consecutive}${getOrdinalSuffix(consecutive)} consecutive month` : 'another month'} at ${formatNumber(pmi)}. `;
      context += `This report is not about confirming what we know—it is about understanding what changed beneath the surface that could affect positioning.\n\n`;
      
      // Last month connection
      context += `*Last month we flagged contraction—this month the data confirms the regime continues without clear inflection.*\n\n`;
    }
  }
  
  // =========================================
  // Key Statement - MUST APPEAR
  // =========================================
  
  context += `**This report is not about what ISM printed—it is about what changed underneath.**\n\n`;
  
  // =========================================
  // Brief ISM Reminder (2-3 lines only)
  // =========================================
  
  context += `**What ISM Measures (Brief Reminder)**\n\n`;
  context += `The ISM Manufacturing PMI aggregates purchasing manager sentiment across new orders, production, employment, supplier deliveries, and inventories. `;
  context += `It is a leading indicator—not lagging economic data or earnings reports. `;
  context += `Readings above 50 indicate expansion; below 50 indicates contraction. The components tell the story the headline cannot.\n`;
  
  return context;
}

/**
 * Determine formal regime label with confidence
 */
function determineRegimeLabel(pmi, prices, employment, newOrders, pmiDelta, consecutive) {
  // Stagflation
  if (pmi < 48 && prices > 55 && employment < 48) {
    return {
      label: 'Late-cycle contraction with stagflationary pressure',
      confidence: 'High',
    };
  }
  
  // Deep contraction
  if (pmi < 45) {
    return {
      label: 'Deep contraction',
      confidence: 'High',
    };
  }
  
  // Contraction deepening
  if (pmi < 50 && pmiDelta < -1.5) {
    return {
      label: 'Contraction — deterioration accelerating',
      confidence: 'High',
    };
  }
  
  // Contraction stabilizing
  if (pmi < 50 && pmiDelta > 1) {
    return {
      label: 'Contraction — early stabilization signals',
      confidence: 'Medium',
    };
  }
  
  // Prolonged contraction
  if (pmi < 50 && consecutive > 3) {
    return {
      label: 'Prolonged contraction',
      confidence: 'High',
    };
  }
  
  // Basic contraction
  if (pmi < 50) {
    return {
      label: 'Contraction',
      confidence: 'Medium',
    };
  }
  
  // Transition zone
  if (pmi >= 48 && pmi <= 52) {
    return {
      label: 'Transition — near inflection point',
      confidence: 'Low',
    };
  }
  
  // Expansion accelerating
  if (pmi >= 52 && pmiDelta > 1 && newOrders > 52) {
    return {
      label: 'Expansion — momentum building',
      confidence: 'High',
    };
  }
  
  // Expansion decelerating
  if (pmi >= 50 && pmiDelta < -1) {
    return {
      label: 'Expansion — losing momentum',
      confidence: 'Medium',
    };
  }
  
  // Strong expansion
  if (pmi >= 55) {
    return {
      label: 'Strong expansion',
      confidence: 'High',
    };
  }
  
  // Basic expansion
  return {
    label: 'Expansion',
    confidence: 'Medium',
  };
}

// =====================================================
// PAGE 1 — ISM Macro Snapshot (The Big Picture)
// =====================================================
// 1.1 Headline Numbers (without flooding)
// 1.2 Macro Regime Assessment
// =====================================================

function writePage1_MacroSnapshot(mfg, priorMonth, momChanges, sections) {
  const pmi = mfg.pmi || 0;
  const newOrders = mfg.newOrders || 0;
  const production = mfg.production || 0;
  const employment = mfg.employment || 0;
  const prices = mfg.prices || 0;
  const backlog = mfg.backlog || null;
  const supplierDeliveries = mfg.supplierDeliveries || null;
  const inventories = mfg.inventories || null;
  
  const pmiDelta = momChanges?.pmi?.delta || 0;
  const newOrdersDelta = momChanges?.newOrders?.delta || 0;
  const employmentDelta = momChanges?.employment?.delta || 0;
  const pricesDelta = momChanges?.prices?.delta || 0;
  
  const regime = determineRegime(mfg, momChanges);
  
  let section = `## ISM Macro Snapshot\n`;
  section += `### The Big Picture\n\n`;
  
  // =========================================
  // 1.1 Headline Numbers
  // One line per metric: what actually changed
  // =========================================
  
  section += `**1.1 Headline Numbers**\n\n`;
  
  // PMI headline
  section += `**ISM Manufacturing:** ${formatNumber(pmi)} `;
  section += `(${formatDelta(pmiDelta)} vs prior month) — `;
  if (pmi >= 50) {
    section += `expansion territory, ${pmiDelta > 0.5 ? 'improving' : pmiDelta < -0.5 ? 'losing momentum' : 'steady'}\n\n`;
  } else {
    section += `contraction territory, ${pmiDelta > 0.5 ? 'showing early stabilization' : pmiDelta < -0.5 ? 'deterioration accelerating' : 'no clear change'}\n\n`;
  }
  
  // Key components - ONE LINE EACH with insight
  section += `**New Orders:** ${formatNumber(newOrders)} (${formatDelta(newOrdersDelta)}) — `;
  if (newOrders > pmi) {
    section += `leading indicator positive; demand outpacing current activity\n\n`;
  } else if (newOrders < pmi - 2) {
    section += `leading indicator negative; demand weaker than current production\n\n`;
  } else {
    section += `aligned with headline; no divergence signal\n\n`;
  }
  
  section += `**Employment:** ${formatNumber(employment)} (${formatDelta(employmentDelta)}) — `;
  if (employment < 45) {
    section += `aggressive workforce reductions; companies in defensive mode\n\n`;
  } else if (employment < 48) {
    section += `headcount trimming through attrition; cautious but not panicked\n\n`;
  } else if (employment >= 50) {
    section += `payrolls stable or growing; confidence signal\n\n`;
  } else {
    section += `modest reductions; wait-and-see mode\n\n`;
  }
  
  section += `**Prices:** ${formatNumber(prices)} (${formatDelta(pricesDelta)}) — `;
  if (prices > 57) {
    section += `significant input cost pressure; margin compression risk elevated\n\n`;
  } else if (prices > 52) {
    section += `modest inflation; manageable through pricing actions\n\n`;
  } else if (prices < 48) {
    section += `disinflation; demand weakness may be outweighing cost factors\n\n`;
  } else {
    section += `neutral pricing environment; no extreme pressure\n\n`;
  }
  
  if (backlog !== null) {
    const backlogDelta = momChanges?.backlog?.delta || 0;
    section += `**Backlog:** ${formatNumber(backlog)} (${formatDelta(backlogDelta)}) — `;
    if (backlog < 44) {
      section += `critically low; forward visibility severely impaired\n\n`;
    } else if (backlog < 48) {
      section += `depleting; work being completed faster than orders coming in\n\n`;
    } else {
      section += `healthy; adequate forward visibility\n\n`;
    }
  }
  
  // =========================================
  // 1.2 Macro Regime Assessment
  // Fixed structure - MUST BE SHARP
  // =========================================
  
  section += `**1.2 Macro Regime Assessment**\n\n`;
  
  // Regime declaration
  section += `**Macro Regime:** ${regime.regime}`;
  if (regime.subtype) section += ` — ${regime.subtype}`;
  section += `\n\n`;
  
  section += `**Confidence Level:** ${regime.confidence}\n\n`;
  
  // What changed vs last month - structured
  section += `**What Changed vs Last Month:**\n\n`;
  
  // Demand dynamics
  section += `*Demand:* `;
  if (newOrdersDelta > 1.5) {
    section += `Demand dynamics have shifted positive. New Orders improved by ${formatDelta(newOrdersDelta)}, suggesting the demand-production relationship is strengthening.\n\n`;
  } else if (newOrdersDelta < -1.5) {
    section += `Demand dynamics have deteriorated. New Orders fell by ${formatDelta(newOrdersDelta)}, indicating the flow of new business is weakening further.\n\n`;
  } else if (newOrders > production + 2) {
    section += `Demand continues to outpace production. This gap typically signals future production increases as manufacturers catch up to orders.\n\n`;
  } else if (newOrders < production - 2) {
    section += `Demand remains below production rates. Manufacturers are working through existing backlogs rather than building for new demand.\n\n`;
  } else {
    section += `Demand dynamics are largely unchanged. No significant shift in the order-production relationship.\n\n`;
  }
  
  // Pricing dynamics
  section += `*Pricing:* `;
  if (pricesDelta > 3) {
    section += `Cost pressures have intensified. The ${formatDelta(pricesDelta)} point increase in Prices changes the margin calculus for manufacturers.\n\n`;
  } else if (pricesDelta < -3) {
    section += `Cost pressures are easing. The ${formatDelta(pricesDelta)} point decline provides margin relief, though it may also signal weakening demand.\n\n`;
  } else if (prices > 55 && pmi < 50) {
    section += `The stagflation dynamic persists—elevated costs with contracting activity. This is the worst combination for operating margins.\n\n`;
  } else {
    section += `Pricing dynamics are stable. No material shift in the cost-demand balance.\n\n`;
  }
  
  // Employment dynamics
  section += `*Employment:* `;
  if (employmentDelta < -2) {
    section += `The employment picture has worsened. A ${formatDelta(employmentDelta)} point decline indicates accelerating workforce reductions.\n\n`;
  } else if (employmentDelta > 2) {
    section += `Employment is recovering. The ${formatDelta(employmentDelta)} point improvement signals renewed confidence in demand.\n\n`;
  } else if (employment < 45) {
    section += `Labor shedding continues at an aggressive pace. This is not trimming—this is restructuring.\n\n`;
  } else if (employment >= 50 && pmi < 50) {
    section += `Notably, employment remains in expansion despite PMI contraction. Companies are hoarding labor, expecting recovery.\n\n`;
  } else {
    section += `Employment dynamics are steady. No acceleration or reversal in hiring/firing trends.\n\n`;
  }
  
  // Supply chain dynamics
  section += `*Supply Chains:* `;
  if (supplierDeliveries !== null) {
    if (supplierDeliveries > 55) {
      section += `Supply chain constraints are tightening. Supplier Deliveries at ${formatNumber(supplierDeliveries)} suggests longer lead times, which can support pricing power but limit output flexibility.\n\n`;
    } else if (supplierDeliveries < 48) {
      section += `Supply chains are exceptionally loose. Fast deliveries at ${formatNumber(supplierDeliveries)} reflect weak demand rather than supply efficiency gains.\n\n`;
    } else {
      section += `Supply chain conditions are normalized. No constraint or slack signal from deliveries data.\n\n`;
    }
  } else {
    section += `Supply chain data not available for this period.\n\n`;
  }
  
  return section;
}

// =====================================================
// PAGE 2 — Under-the-Surface Signals
// =====================================================
// 2.1 Internal ISM Tensions
// 2.2 Trend Shift Detection
// =====================================================

function writePage2_UnderTheSurface(mfg, momChanges, historical, sections) {
  const pmi = mfg.pmi || 50;
  const newOrders = mfg.newOrders || 50;
  const production = mfg.production || 50;
  const employment = mfg.employment || 50;
  const prices = mfg.prices || 50;
  const inventories = mfg.inventories || 50;
  const supplierDeliveries = mfg.supplierDeliveries || 50;
  const backlog = mfg.backlog || 50;
  const customersInventories = mfg.customersInventories || null;
  
  const pmiDelta = momChanges?.pmi?.delta || 0;
  const consecutive = historical?.consecutiveContractionMonths || 0;
  
  let section = `## Under-the-Surface Signals\n`;
  section += `### What The Data Really Shows\n\n`;
  
  section += `This is the part of the analysis that separates signal from noise. The headline PMI is what gets reported; what follows is what drives positioning.\n\n`;
  
  // =========================================
  // 2.1 Internal ISM Tensions
  // Organized by: Demand → Cost → Labor → Supply Chain
  // =========================================
  
  section += `**2.1 Internal ISM Tensions**\n\n`;
  
  // ==================================================
  // DEMAND-RELATED TENSIONS
  // ==================================================
  section += `### Demand-Related\n\n`;
  
  // ------------------------------------------
  // Tension: New Orders vs Production
  // ------------------------------------------
  section += `**New Orders vs Production**\n\n`;
  
  const noVsProd = newOrders - production;
  
  section += `*What we are seeing:* `;
  if (noVsProd > 3) {
    section += `New Orders at ${formatNumber(newOrders)} significantly outpaces Production at ${formatNumber(production)}. `;
    section += `Demand is running ahead of output. Backlogs should be building.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `This is a leading indicator of production acceleration. Manufacturers cannot ignore incoming orders indefinitely. `;
    section += `Either production ramps up, or delivery times lengthen and customers look elsewhere.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Historically, sustained New Orders > Production gaps lead to Production gains within 1-2 months. `;
    section += `This creates asymmetric upside risk for cyclical names with operating leverage.\n\n`;
  } else if (noVsProd < -3) {
    section += `Production at ${formatNumber(production)} exceeds New Orders at ${formatNumber(newOrders)}. `;
    section += `Manufacturers are producing more than they are selling—working through backlogs, not building for new demand.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `This is unsustainable. You cannot produce your way to prosperity without orders to match. `;
    section += `Once backlogs are depleted, production must fall to match the order rate.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Production declines follow within 2-3 months unless New Orders recover. `;
    section += `This creates asymmetric downside risk for industrial names, particularly those with high fixed costs.\n\n`;
  } else {
    section += `New Orders (${formatNumber(newOrders)}) and Production (${formatNumber(production)}) are roughly aligned. `;
    section += `No significant tension between demand and output currently.\n\n`;
    
    section += `*Why this matters:* `;
    section += `Alignment is neutral—it means neither acceleration nor deceleration is imminent from this relationship alone. `;
    section += `Other components become more important in this scenario.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Stability in this relationship suggests the current PMI trajectory is likely to persist until another component shifts.\n\n`;
  }
  
  // ------------------------------------------
  // Tension: Backlog Health (Demand Pipeline)
  // ------------------------------------------
  if (backlog && (backlog < 46 || backlog > 52)) {
    section += `**Backlog Health (Demand Pipeline)**\n\n`;
    
    section += `*What we are seeing:* `;
    if (backlog < 44) {
      section += `Backlog at ${formatNumber(backlog)} is critically depleted. The order pipeline is running dry.\n\n`;
      
      section += `*Why this tension matters:* `;
      section += `Backlogs represent committed future work. When they deplete to this level, forward visibility is severely impaired. `;
      section += `Companies are living hand-to-mouth on orders.\n\n`;
      
      section += `*What typically follows:* `;
      section += `Production cuts and potential layoffs within 1-2 quarters. `;
      section += `Earnings guidance will disappoint as companies acknowledge reduced visibility.\n\n`;
    } else if (backlog > 52) {
      section += `Backlog at ${formatNumber(backlog)} indicates building order pipeline. Companies have committed work ahead.\n\n`;
      
      section += `*Why this tension matters:* `;
      section += `Healthy backlogs provide earnings visibility and pricing power. Companies can be selective about which orders to accept.\n\n`;
      
      section += `*What typically follows:* `;
      section += `Production stability and potential pricing strength. This environment supports cyclical earnings.\n\n`;
    } else {
      section += `Backlog at ${formatNumber(backlog)} is below neutral, signaling depleting order pipeline.\n\n`;
      
      section += `*Why this tension matters:* `;
      section += `This level suggests companies are completing work faster than new orders arrive. Not critical yet, but trending the wrong direction.\n\n`;
      
      section += `*What typically follows:* `;
      section += `If New Orders do not recover, backlog depletion accelerates. Watch for production adjustments.\n\n`;
    }
  }
  
  // ==================================================
  // COST-RELATED TENSIONS
  // ==================================================
  section += `### Cost-Related\n\n`;
  
  // ------------------------------------------
  // Tension: Prices vs Demand
  // ------------------------------------------
  section += `**Prices vs Demand**\n\n`;
  
  section += `*What we are seeing:* `;
  if (prices > 55 && newOrders < 50) {
    section += `Prices elevated at ${formatNumber(prices)} while New Orders contract at ${formatNumber(newOrders)}. `;
    section += `This is the stagflation setup: costs rising while demand falls.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `Companies face a brutal choice: absorb costs and compress margins, or raise prices and risk further volume declines. `;
    section += `There is no good option. Earnings will disappoint regardless of which path companies choose.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Margin compression appears in earnings within 1-2 quarters. `;
    section += `This creates asymmetric downside risk for manufacturers without pricing power, particularly commodity-exposed names.\n\n`;
  } else if (prices < 50 && newOrders < 50) {
    section += `Both Prices (${formatNumber(prices)}) and New Orders (${formatNumber(newOrders)}) are contracting. `;
    section += `This is classic demand destruction: weak activity pulling down costs.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `The good news is there is no margin squeeze from input costs. `;
    section += `The bad news is that falling prices often signal demand is even weaker than the order numbers suggest.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Prices are a concurrent indicator in demand-driven downturns. Watch for New Orders stabilization to signal the trough.\n\n`;
  } else if (prices > 52 && newOrders > 52) {
    section += `Both Prices (${formatNumber(prices)}) and New Orders (${formatNumber(newOrders)}) are expanding. `;
    section += `Demand is strong enough to absorb cost increases—the healthy inflation scenario.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `This is the environment where pricing power translates to margin expansion. `;
    section += `Companies can pass through costs because customers cannot defer purchases.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Sustained operating leverage for manufacturers. This creates asymmetric upside for names with pricing power.\n\n`;
  } else {
    section += `Prices at ${formatNumber(prices)} and New Orders at ${formatNumber(newOrders)} present a mixed picture. `;
    section += `Neither full alignment nor full tension.\n\n`;
    
    section += `*Why this matters:* `;
    section += `The price-demand relationship is not providing a clear signal. Company-specific factors will drive dispersion.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Look for other components (Employment, Backlog) to provide directional guidance.\n\n`;
  }
  
  // ==================================================
  // LABOR-RELATED TENSIONS
  // ==================================================
  section += `### Labor-Related\n\n`;
  
  // ------------------------------------------
  // Tension: Employment vs PMI
  // ------------------------------------------
  section += `**Employment vs Activity**\n\n`;
  
  const empVsPmi = employment - pmi;
  
  section += `*What we are seeing:* `;
  if (employment < 45) {
    section += `Employment at ${formatNumber(employment)} indicates aggressive workforce reductions. `;
    section += `This is not trimming—this is restructuring.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `Labor cuts at this pace historically precede broader economic weakness by 2-3 quarters. `;
    section += `Companies do not cut this aggressively unless they see sustained demand weakness.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Consumer spending impacts as manufacturing job losses spread. `;
    section += `Earnings risk extends beyond industrials to consumer-facing sectors.\n\n`;
  } else if (employment >= 50 && pmi < 50) {
    section += `Employment at ${formatNumber(employment)} remains stable despite PMI contraction at ${formatNumber(pmi)}. `;
    section += `Companies are hoarding labor, expecting recovery.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `Labor hoarding is either confidence or denial. If demand recovers, companies are well-positioned. `;
    section += `If contraction persists, delayed layoffs create a second-wave earnings risk.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Resolution within 2-3 months. Either New Orders recover (validating the hoarding), or employment catches down to activity.\n\n`;
  } else if (employment < pmi - 3) {
    section += `Employment at ${formatNumber(employment)} is lagging well below PMI at ${formatNumber(pmi)}. `;
    section += `Labor market weakness is leading the cycle.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `When employment leads the weakness, the downturn has momentum. `;
    section += `Companies have moved past "wait and see" into defensive mode.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Employment is typically a lagging indicator—when it leads, the cycle is mature. `;
    section += `Expect further PMI deterioration unless demand recovers quickly.\n\n`;
  } else {
    section += `Employment at ${formatNumber(employment)} is aligned with overall activity. `;
    section += `No significant labor-activity divergence.\n\n`;
    
    section += `*Why this matters:* `;
    section += `Alignment suggests companies are appropriately sized for current demand. No forced adjustment imminent.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Employment will follow PMI direction with typical 1-2 month lag.\n\n`;
  }
  
  // ==================================================
  // SUPPLY CHAIN TENSIONS
  // ==================================================
  section += `### Supply Chain\n\n`;
  
  // ------------------------------------------
  // Tension: Inventories vs Deliveries
  // ------------------------------------------
  section += `**Inventories vs Deliveries**\n\n`;
  
  section += `*What we are seeing:* `;
  
  if (inventories < 45 && supplierDeliveries < 50) {
    section += `Inventories lean (${formatNumber(inventories)}) with fast supplier deliveries (${formatNumber(supplierDeliveries)}). `;
    section += `The supply chain is unconstrained but customers are not restocking.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `Low inventories typically precede restocking cycles. `;
    section += `But fast deliveries suggest demand is weak—suppliers are eager because they have excess capacity.\n\n`;
    
    section += `*What typically follows:* `;
    section += `When demand eventually returns, the restocking impulse will be strong. `;
    section += `Materials and industrials names are the beneficiaries, but timing depends on New Orders recovery.\n\n`;
  } else if (inventories > 52 && supplierDeliveries < 50) {
    section += `Inventories elevated (${formatNumber(inventories)}) with fast deliveries (${formatNumber(supplierDeliveries)}). `;
    section += `Companies are sitting on stock they cannot sell.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `Excess inventory must be worked down before new orders translate to new production. `;
    section += `This is an overhang that delays recovery.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Production cuts and promotional activity to clear inventory. `;
    section += `This creates asymmetric downside risk for inventory-heavy names until the overhang clears.\n\n`;
  } else if (supplierDeliveries > 55) {
    section += `Supplier deliveries are slow (${formatNumber(supplierDeliveries)}), indicating supply constraints. `;
    section += `Inventories at ${formatNumber(inventories)} reflect the challenge of getting materials.\n\n`;
    
    section += `*Why this tension matters:* `;
    section += `Supply constraints support pricing power but limit volume upside. `;
    section += `Companies with secured supply chains have an advantage.\n\n`;
    
    section += `*What typically follows:* `;
    section += `As supply normalizes, watch for production acceleration. The demand may be there; the supply chain was the bottleneck.\n\n`;
  } else {
    section += `Inventories (${formatNumber(inventories)}) and Supplier Deliveries (${formatNumber(supplierDeliveries)}) are both in neutral territory. `;
    section += `No significant tension in the supply-inventory relationship.\n\n`;
    
    section += `*Why this matters:* `;
    section += `Neutral conditions mean this dimension is not driving the cycle. Focus attention on demand signals instead.\n\n`;
    
    section += `*What typically follows:* `;
    section += `Inventories and deliveries become important again when New Orders shift meaningfully in either direction.\n\n`;
  }
  
  // =========================================
  // 2.2 Trend Shift Detection
  // =========================================
  
  section += `**2.2 Trend Shift Detection**\n\n`;
  
  section += `The goal here is not to chase trends—it is to identify where in the cycle we are and what comes next.\n\n`;
  
  // ------------------------------------------
  // Weakening Trends (Late-cycle behavior)
  // ------------------------------------------
  section += `**Weakening Trends (Late-cycle behavior):**\n\n`;
  
  let hasWeakeningTrends = false;
  
  if (pmi >= 50 && pmiDelta < -1 && newOrders < pmi) {
    section += `The expansion is losing steam. PMI still above 50 at ${formatNumber(pmi)}, but the ${formatDelta(pmiDelta)} point decline and New Orders lagging at ${formatNumber(newOrders)} are classic late-cycle signals. `;
    section += `This matters because late-cycle environments favor quality over beta and defensives over cyclicals.\n\n`;
    hasWeakeningTrends = true;
  }
  
  if (employment < 48 && pmi > employment + 3) {
    section += `Employment weakness (${formatNumber(employment)}) is leading PMI lower. Companies are cutting heads while production has not yet fully adjusted. `;
    section += `This matters because employment is typically lagging—when it leads the weakness, the downturn has momentum.\n\n`;
    hasWeakeningTrends = true;
  }
  
  if (backlog && backlog < 44 && pmi > 45) {
    section += `Backlog depletion (${formatNumber(backlog)}) signals the pipeline is running dry. Current production is masking the severity of the demand drop. `;
    section += `This matters because when backlogs are exhausted, production must fall to match the order rate.\n\n`;
    hasWeakeningTrends = true;
  }
  
  if (!hasWeakeningTrends) {
    section += `No significant late-cycle weakening patterns identified this month. `;
    if (pmi < 50) {
      section += `The contraction is established, not emerging.\n\n`;
    } else {
      section += `The expansion retains structural support.\n\n`;
    }
  }
  
  // ------------------------------------------
  // Emerging Trends
  // ------------------------------------------
  section += `**Emerging Trends:**\n\n`;
  
  let hasEmergingTrends = false;
  
  if (newOrders > pmi && pmi < 50 && momChanges?.newOrders?.delta > 1) {
    section += `New Orders recovery emerging. At ${formatNumber(newOrders)}, now above PMI with improving momentum. `;
    section += `This is the leading indicator that would signal a turn. Watch for sustainment above 50 for confirmation.\n\n`;
    hasEmergingTrends = true;
  }
  
  if (pmi < 50 && pmiDelta > 1.5 && consecutive > 3) {
    section += `Early stabilization after prolonged contraction. After ${consecutive} months of contraction, a ${formatDelta(pmiDelta)} point improvement is meaningful. `;
    section += `This matters because the sequencing for recovery typically starts with a deceleration of decline before actual improvement.\n\n`;
    hasEmergingTrends = true;
  }
  
  if (customersInventories && customersInventories < 40 && newOrders > 48) {
    section += `Restocking setup emerging. Customer inventories depleted (${formatNumber(customersInventories)}) with orders stabilizing (${formatNumber(newOrders)}). `;
    section += `When confidence returns, the restocking impulse will drive demand. Materials names are the beneficiaries.\n\n`;
    hasEmergingTrends = true;
  }
  
  if (!hasEmergingTrends) {
    section += `No clear emerging positive trends identified this month. `;
    if (pmi < 50) {
      section += `We are not yet seeing the signals that typically precede recovery.\n\n`;
    } else {
      section += `The current expansion trend continues without new acceleration catalysts.\n\n`;
    }
  }
  
  // ------------------------------------------
  // Deceptive Trends (Strong-looking but crumbling)
  // ------------------------------------------
  section += `**Deceptive Trends (Strong but crumbling inside):**\n\n`;
  
  let hasDeceptiveTrends = false;
  
  if (pmi >= 50 && newOrders < 48 && production > 50) {
    section += `Production masking demand weakness. PMI looks healthy at ${formatNumber(pmi)}, but New Orders at ${formatNumber(newOrders)} tells a different story. `;
    section += `Production is running on backlog fumes. This strength is borrowed time.\n\n`;
    hasDeceptiveTrends = true;
  }
  
  if (employment >= 50 && newOrders < 47 && pmi < 50) {
    section += `Employment resilience may be temporary. Companies are hoarding labor (${formatNumber(employment)}) despite contracting orders (${formatNumber(newOrders)}). `;
    section += `This is either confidence in recovery or denial. The gap typically resolves with employment cuts if orders do not recover within 2-3 months.\n\n`;
    hasDeceptiveTrends = true;
  }
  
  if (prices > 55 && pmi < 48) {
    section += `Input cost persistence looks like demand strength—it is not. Elevated Prices (${formatNumber(prices)}) despite contracting PMI (${formatNumber(pmi)}) reflects supply constraints or commodity dynamics, not healthy demand. `;
    section += `This is the stagflation illusion.\n\n`;
    hasDeceptiveTrends = true;
  }
  
  if (!hasDeceptiveTrends) {
    section += `No significant deceptive patterns identified. The surface story and the underlying story appear aligned this month.\n\n`;
  }
  
  return section;
}

// =====================================================
// PAGE 3 — Sector-Level Impact (Who Feels It First)
// =====================================================
// 3.1 Sector Mapping: Beneficiaries / At Risk / Neutral
// 3.2 Industry-Level Focus
// =====================================================

function writePage3_SectorImpact(mfg, sectorData, momChanges, historical) {
  const pmi = mfg.pmi || 50;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const newOrders = mfg.newOrders || 50;
  const backlog = mfg.backlog || 50;
  const pmiDelta = momChanges?.pmi?.delta || 0;
  const pricesDelta = momChanges?.prices?.delta || 0;
  const consecutive = historical?.consecutiveContractionMonths || 0;
  
  const isContraction = pmi < 50;
  const isStagflation = pmi < 48 && prices > 55;
  const isRecovering = pmi < 50 && pmiDelta > 1;
  
  let section = `## Sector-Level Impact\n`;
  section += `### Who Feels It First\n\n`;
  
  // =========================================
  // 3.1 Sector Mapping
  // =========================================
  
  section += `**3.1 Sector Mapping**\n\n`;
  
  // ------------------------------------------
  // BENEFICIARIES
  // ------------------------------------------
  section += `### Beneficiaries\n\n`;
  
  if (isStagflation) {
    // Stagflation beneficiaries
    section += `**Consumer Staples (XLP)**\n`;
    section += `*What ISM tells us:* Pricing power is critical when Prices are at ${formatNumber(prices)} and demand is contracting. Staples can pass through costs.\n`;
    section += `*New or continuation:* ${prices > 55 && consecutive > 1 ? 'Continuation — this has been the defensive play for months' : 'Emerging setup as stagflation dynamics solidify'}.\n`;
    section += `*Why smart money is positioning:* Margin protection in a margin-hostile environment. Relative outperformance when absolute returns are negative.\n\n`;
    
    section += `**Healthcare (XLV)**\n`;
    section += `*What ISM tells us:* Employment at ${formatNumber(employment)} signals broad workforce cuts, but healthcare demand is inelastic.\n`;
    section += `*New or continuation:* Defensive leadership typically extends throughout contraction periods.\n`;
    section += `*Why smart money is positioning:* Demographics provide structural tailwind regardless of manufacturing cycle.\n\n`;
    
    section += `**Utilities (XLU)**\n`;
    section += `*What ISM tells us:* Rate-sensitive but defensive. In this environment, the defensive characteristic dominates.\n`;
    section += `*New or continuation:* Traditional late-cycle rotation.\n`;
    section += `*Why smart money is positioning:* Yield support when growth expectations compress.\n\n`;
    
  } else if (isContraction && !isStagflation) {
    // Regular contraction beneficiaries
    section += `**Consumer Staples (XLP)**\n`;
    section += `*What ISM tells us:* Defensive demand characteristics matter when PMI is at ${formatNumber(pmi)}.\n`;
    section += `*New or continuation:* ${consecutive > 2 ? 'Continuation of defensive rotation' : 'Emerging as contraction establishes'}.\n`;
    section += `*Why smart money is positioning:* Relative stability when cyclical earnings collapse.\n\n`;
    
    section += `**Quality Factor**\n`;
    section += `*What ISM tells us:* High ROE, low leverage companies outperform when the cycle turns negative.\n`;
    section += `*New or continuation:* Quality outperformance is cyclical — this is that phase.\n`;
    section += `*Why smart money is positioning:* Earnings volatility punishes low-quality names disproportionately.\n\n`;
    
  } else if (isRecovering) {
    // Early recovery beneficiaries
    section += `**Early-Cycle Industrials (XLI)**\n`;
    section += `*What ISM tells us:* The ${formatDelta(pmiDelta)} improvement after ${consecutive} months of contraction signals potential turn.\n`;
    section += `*New or continuation:* NEW — this is an inflection setup, not a continuation.\n`;
    section += `*Why smart money is positioning:* Operating leverage works in reverse — first movers capture the turn.\n\n`;
    
    section += `**Materials (XLB)**\n`;
    section += `*What ISM tells us:* New Orders at ${formatNumber(newOrders)} improving suggests restocking impulse may follow.\n`;
    section += `*New or continuation:* Early positioning for recovery trade.\n`;
    section += `*Why smart money is positioning:* Materials lead early-cycle — by the time PMI crosses 50, the move is underway.\n\n`;
    
  } else {
    // Expansion beneficiaries
    section += `**Industrials (XLI)**\n`;
    section += `*What ISM tells us:* PMI at ${formatNumber(pmi)} with New Orders at ${formatNumber(newOrders)} supports capex-sensitive names.\n`;
    section += `*New or continuation:* ${pmiDelta > 0 ? 'Momentum building' : 'Established trend'}.\n`;
    section += `*Why smart money is positioning:* Operating leverage drives earnings upside when volumes rise.\n\n`;
    
    section += `**Financials (XLF)**\n`;
    section += `*What ISM tells us:* Manufacturing expansion is a proxy for economic health. Banks benefit from credit demand and economic activity.\n`;
    section += `*New or continuation:* Pro-cyclical positioning.\n`;
    section += `*Why smart money is positioning:* Economic expansion supports loan growth and credit quality.\n\n`;
  }
  
  // ------------------------------------------
  // AT RISK
  // ------------------------------------------
  section += `### At Risk\n\n`;
  
  if (isContraction) {
    section += `**Machinery & Heavy Equipment**\n`;
    section += `*What ISM tells us:* Backlog at ${formatNumber(backlog)} with Employment at ${formatNumber(employment)} signals order pipeline depletion and cost cutting.\n`;
    section += `*New or continuation:* ${consecutive > 2 ? 'Deepening risk as contraction extends' : 'Risk emerging as cycle turns negative'}.\n`;
    section += `*Why smart money is exiting:* High fixed costs amplify earnings decline. Backlog depletion removes earnings visibility.\n\n`;
    
    section += `**Transportation Equipment**\n`;
    section += `*What ISM tells us:* Labor-intensive sector facing Employment at ${formatNumber(employment)}. Cost structures are sticky.\n`;
    section += `*New or continuation:* ${employment < 47 ? 'Accelerating risk' : 'Established risk'}.\n`;
    section += `*Why smart money is exiting:* Labor costs do not adjust as fast as revenue. Margin compression is mechanical.\n\n`;
    
    if (isStagflation) {
      section += `**Consumer Discretionary (XLY)**\n`;
      section += `*What ISM tells us:* Prices at ${formatNumber(prices)} with demand contracting means consumers face higher costs with less income security.\n`;
      section += `*New or continuation:* Stagflation setup is particularly punishing for discretionary.\n`;
      section += `*Why smart money is exiting:* Demand elasticity meets cost pressure. Double compression.\n\n`;
    }
  } else {
    section += `**Utilities (XLU)**\n`;
    section += `*What ISM tells us:* In expansion, defensive sectors have opportunity cost. Rate sensitivity becomes a headwind.\n`;
    section += `*New or continuation:* Relative underperformance in expansion is structural.\n`;
    section += `*Why smart money is rotating out:* Capital flows to growth. Yield stocks lag.\n\n`;
    
    section += `**Consumer Staples (XLP) — Relative**\n`;
    section += `*What ISM tells us:* Not absolute risk, but relative underperformance as cyclicals gain.\n`;
    section += `*New or continuation:* Rotation away from defensives in expansion.\n`;
    section += `*Why smart money is rotating:* Opportunity cost of missing cyclical upside.\n\n`;
  }
  
  // ------------------------------------------
  // NEUTRAL / TRANSITIONAL
  // ------------------------------------------
  section += `### Neutral / Transitional\n\n`;
  
  section += `**Technology (XLK)**\n`;
  section += `*What ISM tells us:* Secular demand (AI, cloud) partially insulates from manufacturing cycle, but capex sensitivity remains.\n`;
  section += `*New or continuation:* Tech has been transitional — secular growth vs cyclical exposure creates dispersion.\n`;
  section += `*Positioning nuance:* Favor software/services over hardware. Secular > cyclical within tech.\n\n`;
  
  section += `**Energy (XLE)**\n`;
  section += `*What ISM tells us:* Commodity-driven, less directly tied to manufacturing PMI. Prices component has some read-through.\n`;
  section += `*New or continuation:* Energy trades on its own dynamics (oil prices, geopolitics) more than ISM.\n`;
  section += `*Positioning nuance:* Use ISM for broad risk appetite context, not direct sector call.\n\n`;
  
  // =========================================
  // 3.2 Industry-Level Focus
  // =========================================
  
  section += `**3.2 Industry-Level Focus**\n\n`;
  
  section += `Drilling down within sectors, the ISM data creates differentiation:\n\n`;
  
  if (isContraction) {
    section += `**Within Industrials — Who Gets Hit First:**\n\n`;
    section += `*First impact:* General industrial machinery, metal fabrication. These are directly tied to manufacturing PMI.\n`;
    section += `*Delayed impact:* Aerospace & defense (backlog-protected), construction equipment (infrastructure spend may offset).\n`;
    section += `*Risk pricing:* Market has priced weakness in commodity machinery. Less priced: specialty industrial names with perceived quality that still have cyclical exposure.\n\n`;
    
    section += `**Within Materials — Dispersion:**\n\n`;
    section += `*Most exposed:* Steel, aluminum — high operating leverage, commodity pricing.\n`;
    section += `*More insulated:* Specialty chemicals, industrial gases — contracted revenue, pricing power.\n`;
    section += `*Risk pricing:* Commodity materials are priced for pain. Industrial gases (LIN, APD) may be under-pricing earnings risk if industrial demand falls further.\n\n`;
    
  } else {
    section += `**Within Industrials — Who Leads:**\n\n`;
    section += `*First beneficiaries:* Multi-industry conglomerates (HON, MMM) with broad exposure. Early-cycle machinery.\n`;
    section += `*Lagging beneficiaries:* Aerospace (long-cycle), construction (project timing).\n`;
    section += `*Risk pricing:* Early-cycle names have moved. The question is whether the move is overdone or has room to run.\n\n`;
    
    section += `**Within Materials — Recovery Sequence:**\n\n`;
    section += `*First movers:* Copper (FCX), industrial metals — tied to production ramp.\n`;
    section += `*Second wave:* Chemicals, packaging — follows production recovery.\n`;
    section += `*Risk pricing:* Copper has anticipated recovery. Chemicals may offer better risk/reward if recovery confirms.\n\n`;
  }
  
  section += `**Cross-Sector Risk Assessment:**\n\n`;
  
  if (isStagflation) {
    section += `*Underpriced risk:* Quality industrial names that look "safe" but have margin exposure to the stagflation dynamic.\n`;
    section += `*Overpriced risk:* Pure commodity plays — the market has already punished these heavily.\n`;
  } else if (isContraction) {
    section += `*Underpriced risk:* Companies with strong backlogs that mask deteriorating order rates. Backlog at ${formatNumber(backlog)} suggests this is real.\n`;
    section += `*Overpriced risk:* Defensive staples trading at peak relative multiples.\n`;
  } else {
    section += `*Underpriced risk:* Late-cycle quality names that have not participated in the cyclical rally.\n`;
    section += `*Overpriced risk:* High-beta cyclicals that have run ahead of fundamentals.\n`;
  }
  
  return section;
}

// =====================================================
// PAGE 4 — Voices from the Field (Executive Commentary)
// =====================================================
// 4.1 Key Executive Quotes
// 4.2 Analyst Interpretation
// =====================================================

function writePage4_VoicesFromField(quotes, quoteAnalysis, mfg, sectorData) {
  const pmi = mfg.pmi || 50;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const newOrders = mfg.newOrders || 50;
  
  let section = `## Voices from the Field\n`;
  section += `### Executive Commentary\n\n`;
  
  section += `The numbers tell one story. What executives are saying — and not saying — tells another. This section separates actionable intelligence from noise.\n\n`;
  
  // =========================================
  // 4.1 Key Executive Quotes
  // =========================================
  
  section += `**4.1 Key Executive Quotes**\n\n`;
  
const cleanedQuotes = (quotes || []).filter(q => q.comment && q.industry);
  const analyzedQuotes = quoteAnalysis?.quotes || [];
let sourceQuotes = analyzedQuotes.length > 0 ? analyzedQuotes : cleanedQuotes;

// ★★★ FILTER FAKE QUOTES ★★★
const BLOCKLIST = [
  // Original
  'reported growth', 'reported contraction', 'reporting', 'remains stable', 'continues to',
  // ★★★ NEW: Susan Spence style summaries ★★★
  'survey respondents', 'respondents continue', 'respondents in several',
  'respondents are expecting', 'continue to report', 'substantial struggles',
  'expecting to see larger changes', 'larger changes to revenue',
  'cited the lack', 'impediment to planning',
  // Generic observer language
  'some respondents', 'several industries', 'manufacturing activity',
  'pmi registered', 'percent reported', 'diffusion index',
  // Third person references
  'manufacturers reported', 'companies reported', 'panelists reported',
];sourceQuotes = sourceQuotes.filter(q => {
  const text = (q.comment || q.originalQuote || '').toLowerCase();
  if (text.length < 40) return false;
  for (const phrase of BLOCKLIST) {
    if (text.includes(phrase)) return false;
  }
  return true;
});  
  // CHECK IF QUOTES ARE REAL OR FALLBACK
  const hasFallbackQuotes = sourceQuotes.some(q => q.isFallback === true);
  const hasRealQuotes = sourceQuotes.some(q => q.isVerified === true || (!q.isFallback && q.comment && q.comment.length > 50));
  const allAreFallback = sourceQuotes.length > 0 && sourceQuotes.every(q => q.isFallback === true);
  
  // SHOW WARNING IF QUOTES ARE NOT REAL
  if (allAreFallback || !hasRealQuotes) {
    section += `**Important Notice:**\n\n`;
    section += `Real ISM respondent quotes were unavailable for this report. `;
    section += `For actual industry commentary, please visit ismworld.org or search PRNewswire for "ISM Manufacturing PMI Report".\n\n`;
    section += `---\n\n`;
    section += `**Data-Based Assessment:**\n\n`;
    
    if (pmi < 48 && prices > 55) {
      section += `Based on PMI at ${formatNumber(pmi)} with Prices at ${formatNumber(prices)}, manufacturers are likely facing margin pressure from elevated input costs alongside contracting demand.\n\n`;
    } else if (pmi < 50) {
      section += `With PMI contracting at ${formatNumber(pmi)} and Employment at ${formatNumber(employment)}, industry executives are likely describing cautious customer behavior and workforce optimization efforts.\n\n`;
    } else {
      section += `PMI expanding at ${formatNumber(pmi)} suggests industry executives are likely reporting improved order flows and confident capacity planning.\n\n`;
    }
    
  } else if (analyzedQuotes.length > 0) {
    // Use analyzed quotes with sentiment
const selectedQuotes = analyzedQuotes.slice(0, 10);  // Show up to 10 quotes    
    selectedQuotes.forEach((quote, index) => {
      const industry = cleanText(quote.industry || 'Manufacturing');
      const comment = cleanText(quote.originalQuote || quote.comment || '');
      const sentiment = quote.sentiment || 'neutral';
      
      section += `**Quote ${index + 1} — ${industry}:**\n`;
      section += `"${comment}"\n\n`;
    });
    
  } else if (cleanedQuotes.length > 0) {
    // Use raw quotes
const selectedQuotes = cleanedQuotes.slice(0, 10);  // Show up to 10 quotes    
    selectedQuotes.forEach((quote, index) => {
      section += `**Quote ${index + 1} — ${cleanText(quote.industry)}:**\n`;
      section += `"${cleanText(quote.comment)}"\n\n`;
    });
  } else {
    // NO QUOTES AVAILABLE - Show clear notice instead of generating fake quotes
    section += `**Notice: Real Industry Quotes Unavailable**\n\n`;
    section += `The system was unable to retrieve authentic respondent quotes from the ISM Manufacturing Report "What Respondents Are Saying" section for this period.\n\n`;
    section += `**To access real quotes:**\n`;
    section += `- Visit ismworld.org for the official ISM Manufacturing Report\n`;
    section += `- Search PRNewswire for "ISM Manufacturing PMI Report"\n`;
    section += `- Look for the "WHAT RESPONDENTS ARE SAYING" section\n\n`;
    
    section += `**Data-Based Context (not quotes):**\n\n`;
    
    if (pmi < 48 && prices > 55) {
      section += `Current ISM data suggests a stagflation environment: PMI at ${formatNumber(pmi)} indicates manufacturing contraction while Prices at ${formatNumber(prices)} show persistent cost pressure. Employment at ${formatNumber(employment)} confirms workforce reductions are underway.\n\n`;
    } else if (pmi < 50) {
      section += `ISM data indicates manufacturing contraction with PMI at ${formatNumber(pmi)}. New Orders at ${formatNumber(newOrders)} and Employment at ${formatNumber(employment)} suggest cautious industry conditions.\n\n`;
    } else {
      section += `ISM data indicates manufacturing expansion with PMI at ${formatNumber(pmi)}. New Orders at ${formatNumber(newOrders)} suggests healthy demand conditions.\n\n`;
    }
  }
  
  // =========================================
  // 4.2 Analyst Interpretation
  // =========================================
  
  section += `**4.2 Analyst Interpretation**\n\n`;
  
  section += `Beyond what executives are saying, here is what we hear:\n\n`;
  
  // Analyze themes from quotes or conditions
  if (analyzedQuotes.length > 0 || cleanedQuotes.length > 0) {
    const quoteSource = analyzedQuotes.length > 0 ? analyzedQuotes : cleanedQuotes;
    
    // Look for demand-related comments
    const demandQuotes = quoteSource.filter(q => {
      const text = (q.comment || q.originalQuote || '').toLowerCase();
      return text.includes('order') || text.includes('demand') || text.includes('customer') || text.includes('backlog');
    });
    
    if (demandQuotes.length > 0) {
      section += `**On Demand:**\n`;
      section += `*What they are saying:* References to order flow, customer behavior, backlog conditions.\n`;
      section += `*What they are NOT saying:* ${pmi < 50 ? 'No mention of recovery timing or confidence in near-term improvement' : 'Limited concern about sustainability of demand'}.\n`;
      section += `*ISM connection:* New Orders at ${formatNumber(newOrders)} ${newOrders < 50 ? 'confirms the caution in their commentary' : 'aligns with the confidence in their tone'}.\n`;
      section += `*Sector implications:* ${newOrders < 48 ? 'Supports defensive positioning in cyclicals' : 'Supports continued cyclical exposure'}.\n\n`;
    }
    
    // Look for cost-related comments
    const costQuotes = quoteSource.filter(q => {
      const text = (q.comment || q.originalQuote || '').toLowerCase();
      return text.includes('cost') || text.includes('price') || text.includes('margin') || text.includes('input');
    });
    
    if (costQuotes.length > 0) {
      section += `**On Costs & Margins:**\n`;
      section += `*What they are saying:* Input cost pressures, pricing dynamics, margin commentary.\n`;
      section += `*What they are NOT saying:* ${prices > 55 ? 'No expectation of near-term cost relief' : 'No acute concern about cost pressures'}.\n`;
      section += `*ISM connection:* Prices at ${formatNumber(prices)} ${prices > 55 ? 'validates the margin concern' : 'suggests manageable cost environment'}.\n`;
      section += `*Sector implications:* ${prices > 55 && pmi < 50 ? 'Strengthens case for pricing-power names, weakens commodity producers' : 'Neutral for sector selection'}.\n\n`;
    }
    
    // Look for labor-related comments
    const laborQuotes = quoteSource.filter(q => {
      const text = (q.comment || q.originalQuote || '').toLowerCase();
      return text.includes('labor') || text.includes('workforce') || text.includes('hiring') || text.includes('layoff') || text.includes('headcount');
    });
    
    if (laborQuotes.length > 0) {
      section += `**On Labor:**\n`;
      section += `*What they are saying:* Workforce adjustments, hiring/firing decisions, labor market conditions.\n`;
      section += `*What they are NOT saying:* ${employment < 48 ? 'No optimism about near-term staffing stabilization' : 'No panic about workforce needs'}.\n`;
      section += `*ISM connection:* Employment at ${formatNumber(employment)} ${employment < 48 ? 'confirms defensive labor posture' : 'suggests stable workforce conditions'}.\n`;
      section += `*Sector implications:* ${employment < 45 ? 'Labor-intensive sectors face disproportionate margin pressure' : 'Labor dynamics are not a primary differentiator this month'}.\n\n`;
    }
  }
  
  // Overall assessment
  section += `**Summary Assessment:**\n\n`;
  
  if (pmi < 48 && prices > 55) {
    section += `The tone from the field confirms the stagflation reading in the data. Executives are describing a difficult environment: `;
    section += `demand is not recovering, costs are not falling, and visibility is limited. `;
    section += `Notably absent is any confident expectation of near-term improvement. `;
    section += `This strengthens the case for defensive positioning and weakens the case for early cyclical rotation.\n\n`;
  } else if (pmi < 50) {
    section += `Executive commentary reflects caution without panic. The contraction is acknowledged, but commentary does not suggest `;
    section += `accelerating deterioration. Watch for shifts in tone next month — the absence of increased negativity may be a leading indicator `;
    section += `of stabilization before the numbers confirm it.\n\n`;
  } else {
    section += `The field confirms the expansion narrative. Executives are describing healthy demand conditions and manageable cost pressures. `;
    section += `The risk is complacency — watch for early warning signs in commentary before they appear in the data.\n\n`;
  }
  
  return section;
}

// =====================================================
// PAGE 5 — Sector in Focus (The Funnel Tip)
// =====================================================
// 5.1 Chosen Sector (ONE only)
// 5.2 Selected Companies (2-4 tickers)
// =====================================================

function writePage5_SectorInFocus(mfg, sectorData, tradeData, momChanges) {
  const pmi = mfg.pmi || 50;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const newOrders = mfg.newOrders || 50;
  const backlog = mfg.backlog || 50;
  const pmiDelta = momChanges?.pmi?.delta || 0;
  
  const isContraction = pmi < 50;
  const isStagflation = pmi < 48 && prices > 55;
  const isRecovering = pmi < 50 && pmiDelta > 1;
  
  let section = `## Sector in Focus\n`;
  section += `### The Funnel Tip\n\n`;
  
  section += `From the broad sector map, we narrow to one sector where the ISM data creates the clearest thesis. This is not diversification — this is conviction.\n\n`;
  
  // =========================================
  // 5.1 Chosen Sector
  // =========================================
  
  section += `**5.1 Chosen Sector**\n\n`;
  
  // Determine the focus sector based on conditions
  let focusSector = {};
  
  if (isStagflation) {
    focusSector = {
      name: 'Consumer Staples',
      etf: 'XLP',
      ismConnection: `Prices at ${formatNumber(prices)} with PMI at ${formatNumber(pmi)} creates the stagflation setup. Staples have pricing power and defensive demand — both critical in this environment.`,
      cycleStage: 'Late-cycle defensive. This is the classic playbook when costs rise and demand falls.',
      asymmetry: 'Downside protection with limited upside. The asymmetry favors staples not for what they will gain, but for what they will avoid losing.',
    };
  } else if (isRecovering) {
    focusSector = {
      name: 'Industrials',
      etf: 'XLI',
      ismConnection: `After ${Math.abs(pmiDelta) > 1 ? 'meaningful' : 'modest'} improvement in PMI, industrials are positioned to capture operating leverage on volume recovery. New Orders at ${formatNumber(newOrders)} is the key metric.`,
      cycleStage: 'Early-cycle inflection. This is the point where early positioning can generate alpha.',
      asymmetry: 'High asymmetry. If recovery confirms, industrials outperform significantly. If recovery fails, the downside is limited from current depressed levels.',
    };
  } else if (isContraction) {
    focusSector = {
      name: 'Healthcare',
      etf: 'XLV',
      ismConnection: `Employment at ${formatNumber(employment)} signals broad workforce reductions. Healthcare demand is inelastic — it does not follow the manufacturing cycle.`,
      cycleStage: 'Mid-contraction defensive. Healthcare provides ballast when cyclical earnings compress.',
      asymmetry: 'Favorable risk/reward. Limited downside from manufacturing weakness, potential upside from demographic tailwinds regardless of cycle.',
    };
  } else {
    focusSector = {
      name: 'Industrials',
      etf: 'XLI',
      ismConnection: `PMI at ${formatNumber(pmi)} with New Orders at ${formatNumber(newOrders)} supports capex-sensitive names. This is the environment where operating leverage works.`,
      cycleStage: 'Mid-expansion. Cyclical exposure is warranted.',
      asymmetry: 'Balanced risk/reward. Upside from continued expansion, downside if momentum reverses.',
    };
  }
  
  section += `**${focusSector.name} (${focusSector.etf})**\n\n`;
  
  section += `**Why we chose this sector:**\n\n`;
  
  section += `*Direct ISM connection:* ${focusSector.ismConnection}\n\n`;
  section += `*Cycle stage:* ${focusSector.cycleStage}\n\n`;
  section += `*Asymmetry (risk/reward):* ${focusSector.asymmetry}\n\n`;
  
  // =========================================
  // 5.2 Selected Companies
  // =========================================
  
  section += `**5.2 Selected Companies**\n\n`;
  
  section += `*These are thinking scenarios, not recommendations. Each represents a different angle on the sector thesis.*\n\n`;
  
  // Generate company analyses based on focus sector
  let companies = [];
  
  if (focusSector.name === 'Consumer Staples') {
    companies = [
      {
        ticker: 'PG',
        name: 'Procter & Gamble',
        business: 'Global consumer products company with dominant positions in household and personal care categories.',
        macroImpact: 'ISM stagflation setup (Prices elevated, demand weak) favors PG because: (1) essential demand is inelastic, (2) brand strength enables pricing power, (3) global diversification reduces US manufacturing exposure.',
        leverage: 'Pricing leverage — demonstrated ability to raise prices without proportionate volume decline. Operating leverage is modest given stable, predictable volumes.',
        thesisRisk: 'Private label share gains if consumers trade down. Commodity cost spikes that exceed pricing ability. Dollar strength pressuring international earnings.',
      },
      {
        ticker: 'COST',
        name: 'Costco',
        business: 'Membership warehouse club operating on high volume, low margin model with exceptional customer loyalty.',
        macroImpact: 'Stagflation benefits COST through the trade-down effect. When budgets tighten, consumers shift to value retailers. Membership model provides revenue visibility.',
        leverage: 'Volume leverage — traffic increases as consumers seek value. Pricing leverage is limited by value positioning, but cost discipline protects margins.',
        thesisRisk: 'Consumer spending collapse that exceeds trade-down benefit. Wage inflation pressuring operating costs. Competition from traditional grocers on price.',
      },
      {
        ticker: 'KO',
        name: 'Coca-Cola',
        business: 'Global beverage company with unmatched distribution and brand portfolio across carbonated and non-carbonated categories.',
        macroImpact: 'Defensive demand profile provides downside protection. ISM weakness does not directly impact beverage consumption. Prices component is manageable given brand strength.',
        leverage: 'Pricing leverage through brand power. Geographic leverage through emerging market exposure (growth offset to developed market stagnation).',
        thesisRisk: 'Health-driven secular decline in carbonated soft drinks. Sugar tax expansion. Emerging market currency volatility.',
      },
    ];
  } else if (focusSector.name === 'Healthcare') {
    companies = [
      {
        ticker: 'UNH',
        name: 'UnitedHealth Group',
        business: 'Largest US health insurer with integrated pharmacy benefits and healthcare services through Optum.',
        macroImpact: `Healthcare utilization is inelastic to manufacturing cycle. ISM Employment weakness (${formatNumber(employment)}) does not reduce healthcare demand — may increase it through stress-related conditions.`,
        leverage: 'Scale leverage through largest membership base. Vertical integration with Optum creates cost advantages competitors cannot match.',
        thesisRisk: 'Regulatory/political risk around healthcare reform. Medical cost inflation exceeding premium growth. Antitrust scrutiny of vertical integration.',
      },
      {
        ticker: 'JNJ',
        name: 'Johnson & Johnson',
        business: 'Diversified healthcare company spanning pharmaceuticals, medical devices, and consumer health.',
        macroImpact: 'Triple defensive: pharma (non-discretionary), devices (aging demographics), consumer (stable demand). ISM manufacturing weakness has minimal read-through.',
        leverage: 'Diversification leverage — no single segment dominates. R&D leverage through scale of investment.',
        thesisRisk: 'Talc litigation overhang. Pharma pipeline execution. Consumer health spinoff integration.',
      },
      {
        ticker: 'LLY',
        name: 'Eli Lilly',
        business: 'Pharmaceutical company with leading positions in diabetes, obesity, and Alzheimer\'s therapeutics.',
        macroImpact: 'Secular growth from GLP-1 drugs (diabetes/obesity) is independent of manufacturing cycle. Premium valuation reflects growth, not cycle.',
        leverage: 'Pipeline leverage — multiple blockbuster drugs in growth phase. Pricing leverage in categories with limited competition.',
        thesisRisk: 'Valuation multiple compression if growth disappoints. Competition in GLP-1 category. Political pressure on drug pricing.',
      },
    ];
  } else {
    // Industrials
    companies = [
      {
        ticker: 'HON',
        name: 'Honeywell',
        business: 'Diversified industrial technology company serving aerospace, building automation, and performance materials.',
        macroImpact: 'ISM at ${formatNumber(pmi)} with New Orders at ${formatNumber(newOrders)} creates the setup for industrial recovery. HON\'s diversification provides multiple paths to benefit.',
        leverage: 'Operating leverage on volume recovery — high fixed cost structure means margin expansion as utilization rises. Technology content supports pricing.',
        thesisRisk: 'Aerospace exposure if travel recovery stalls. Commercial real estate weakness affecting building segment. China exposure.',
      },
      {
        ticker: 'CAT',
        name: 'Caterpillar',
        business: 'Global leader in construction and mining equipment, diesel engines, and industrial gas turbines.',
        macroImpact: `Direct beneficiary of manufacturing recovery. Backlog at ${formatNumber(backlog)} suggests ${backlog < 48 ? 'pipeline depletion that will reverse if orders recover' : 'healthy forward visibility'}. Infrastructure spending provides secular support.`,
        leverage: 'Extreme operating leverage — high fixed costs mean earnings are highly sensitive to volume. Pricing power in equipment with limited competition.',
        thesisRisk: 'Cyclicality cuts both ways — leverage amplifies downside if recovery fails. Mining capex volatility. China construction slowdown.',
      },
      {
        ticker: 'ETN',
        name: 'Eaton',
        business: 'Power management company serving electrical, aerospace, and vehicle markets with efficiency solutions.',
        macroImpact: 'Electrification megatrend provides secular growth layered on cyclical recovery. ISM improvement supports traditional industrial end markets.',
        leverage: 'Growth leverage through electrification exposure. Operating leverage on traditional industrial recovery.',
        thesisRisk: 'Electrification investment timing — capex may be deferred in weak economy. Aerospace recovery pace. Acquisition integration.',
      },
    ];
  }
  
  // Write company analyses
  companies.forEach((company, index) => {
    section += `**${index + 1}. ${company.ticker} — ${company.name}**\n\n`;
    section += `*What they do:* ${company.business}\n\n`;
    section += `*How macro affects them:* ${company.macroImpact}\n\n`;
    section += `*Where the leverage is:* ${company.leverage}\n\n`;
    section += `*Main thesis risk:* ${company.thesisRisk}\n\n`;
  });
  
  // Disclaimer
  section += `---\n\n`;
  section += `*The above is a thinking framework, not investment advice. These scenarios illustrate how ISM data connects to company-level analysis. `;
  section += `Each investor must conduct their own due diligence and consider their own risk tolerance and investment objectives.*\n`;
  
  return section;
}

// ============================================
// SIGNAL HIERARCHY SECTION
// ============================================

function writeSignalHierarchy(signalHierarchy) {
  if (!signalHierarchy) return '';
  
  let section = `## Signal Hierarchy\n\n`;
  section += `*Not all signals are equal. Here is how we weight this month's data:*\n\n`;
  
  // Primary Signal
  if (signalHierarchy.primary) {
    section += `**Primary Signal: ${signalHierarchy.primary.signal}**\n\n`;
    section += `${signalHierarchy.primary.description}. `;
    section += `${signalHierarchy.primary.implication}\n\n`;
    if (signalHierarchy.primary.tradingImplication) {
      section += `*Trading implication:* ${signalHierarchy.primary.tradingImplication}\n\n`;
    }
  }
  
  // Confirmation
  if (signalHierarchy.confirmation && signalHierarchy.confirmation.length > 0) {
    section += `**Confirmation Signals:**\n\n`;
    signalHierarchy.confirmation.forEach(conf => {
      section += `- *${conf.signal}* (${conf.value}): ${conf.role}\n`;
    });
    section += `\n`;
  }
  
  // Noise
  if (signalHierarchy.noise && signalHierarchy.noise.length > 0) {
    section += `**Secondary / Noise:**\n\n`;
    signalHierarchy.noise.forEach(noise => {
      section += `- *${noise.signal}* (${noise.value}): ${noise.reason}\n`;
    });
    section += `\n`;
  }
  
  return section;
}

// ============================================
// MISPRICING CALL SECTION
// ============================================

function writeMispricingCall(mispricing) {
  if (!mispricing) return '';
  
  let section = `## The Edge\n\n`;
  section += `*Where the market is wrong and how to exploit it:*\n\n`;
  
  if (mispricing.whatMarketThinks) {
    section += `**Consensus view:** ${cleanText(mispricing.whatMarketThinks)}\n\n`;
  }
  
  if (mispricing.whatDataShows) {
    section += `**What ISM shows:** ${cleanText(mispricing.whatDataShows)}\n\n`;
  }
  
  if (mispricing.theGap) {
    section += `**The gap:** ${cleanText(mispricing.theGap)}\n\n`;
  }
  
  if (mispricing.magnitude) {
    section += `**Magnitude:** ${cleanText(mispricing.magnitude)}\n\n`;
  }
  
  if (mispricing.timeToConvergence) {
    section += `*Expected convergence:* ${cleanText(mispricing.timeToConvergence)}\n\n`;
  }
  
  if (mispricing.closingStatement) {
    section += `---\n\n`;
    section += `**${cleanText(mispricing.closingStatement)}**\n\n`;
  }
  
  return section;
}

// ============================================
// COUNTER-THESIS SECTION
// ============================================

function writeCounterThesis(regime) {
  if (!regime?.alternativeInterpretation) return '';
  
  const alt = regime.alternativeInterpretation;
  
  let section = `## Alternative Interpretation\n\n`;
  section += `*What if we are wrong?*\n\n`;
  
  if (alt.thesis) {
    section += `**The alternative reading:** ${cleanText(alt.thesis)}\n\n`;
  }
  
  if (alt.supportingEvidence) {
    section += `**Supporting evidence:** ${cleanText(alt.supportingEvidence)}\n\n`;
  }
  
  if (alt.whatWouldConfirmIt) {
    section += `**What would confirm it:** ${cleanText(alt.whatWouldConfirmIt)}\n\n`;
  }
  
  if (alt.whyWeDiscountIt) {
    section += `**Why we discount it:** ${cleanText(alt.whyWeDiscountIt)}\n\n`;
  }
  
  if (regime.whatWeCouldBeWrongAbout) {
    section += `*Our biggest assumption:* ${cleanText(regime.whatWeCouldBeWrongAbout)}\n\n`;
  }
  
  if (regime.keyDebate) {
    section += `*The key debate:* ${cleanText(regime.keyDebate)}\n\n`;
  }
  
  return section;
}

// ============================================
// SECTOR ROTATION (ENHANCED)
// ============================================

function writeSectorRotation(mfg, sectorData, momChanges) {
  let section = '';
  
  const pmi = mfg.pmi || 0;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const newOrders = mfg.newOrders || 50;
  const pmiDelta = momChanges?.pmi?.delta || 0;
  
  section += `Based on current ISM conditions, we identify the following sector dynamics:\n\n`;
  
  // Leading Sectors
  section += `**Sectors positioned to lead:**\n\n`;
  
  if (sectorData?.rankings && sectorData.rankings.length > 0) {
    const sorted = [...sectorData.rankings].sort((a, b) => (b.score || 0) - (a.score || 0));
    
    sorted.slice(0, 2).forEach(sector => {
      section += `*${cleanText(sector.name || sector.sector)}:* `;
      section += cleanText(sector.rationale || sector.thesis || sector.description || '') + ' ';
      
      if (sector.changeVsLastMonth) {
        section += `This sector has been ${sector.changeVsLastMonth} versus last month. `;
      }
      
      section += `This matters because the ISM data specifically supports this rotation.\n\n`;
    });
  } else {
    if (pmi < 48) {
      section += `*Consumer Staples (XLP):* Defensive demand and pricing power position this sector favorably. `;
      section += `With Prices at ${formatNumber(prices)} and PMI contracting, companies that can pass through costs while maintaining volumes will outperform. `;
      section += `This matters because margin protection becomes critical in stagflationary environments.\n\n`;
      
      section += `*Healthcare (XLV):* Inelastic demand provides downside protection. `;
      section += `Employment weakness at ${formatNumber(employment)} suggests defensive positioning remains appropriate. `;
      section += `This matters because healthcare typically outperforms in late-cycle weakness.\n\n`;
    } else {
      section += `*Industrials (XLI):* Manufacturing expansion supports capex-sensitive names. `;
      section += `New Orders at ${formatNumber(newOrders)} indicates improving demand. `;
      section += `This matters because operating leverage will drive earnings upside.\n\n`;
    }
  }
  
  // Under Pressure
  section += `**Sectors under pressure:**\n\n`;
  
  if (sectorData?.rankings && sectorData.rankings.length > 0) {
    const sorted = [...sectorData.rankings].sort((a, b) => (b.score || 0) - (a.score || 0));
    
    sorted.slice(-2).forEach(sector => {
      section += `*${cleanText(sector.name || sector.sector)}:* `;
      section += cleanText(sector.rationale || sector.thesis || sector.description || '') + ' ';
      
      if (sector.changeVsLastMonth) {
        section += `Conditions have ${sector.changeVsLastMonth} versus last month. `;
      }
      section += `\n\n`;
    });
  } else {
    if (pmi < 50) {
      section += `*Machinery/Industrials (XLI - selective):* `;
      section += `Backlog weakness at ${formatNumber(mfg.backlog || 45)} signals poor forward visibility. `;
      section += `Employment at ${formatNumber(employment)} confirms companies are cutting capacity. `;
      section += `This matters because backlog deterioration historically leads earnings cuts by 1-2 quarters.\n\n`;
      
      section += `*Transportation Equipment:* `;
      section += `High labor intensity meets Employment at ${formatNumber(employment)}. `;
      section += `This matters because labor cuts in this sector are typically followed by production cuts.\n\n`;
    }
  }
  
  // Inflection Points
  section += `**Recent inflection points:**\n\n`;
  
  if (momChanges?.summary?.thresholdCrosses?.length > 0) {
    momChanges.summary.thresholdCrosses.forEach(cross => {
      section += `${cross.component} crossed ${cross.direction} (${formatNumber(cross.from)} → ${formatNumber(cross.to)}). `;
      section += `This is actionable because threshold crosses often mark regime changes for affected sectors.\n\n`;
    });
  } else if (pmiDelta > 1.5 || pmiDelta < -1.5) {
    section += `The ${Math.abs(pmiDelta).toFixed(1)} point ${pmiDelta > 0 ? 'improvement' : 'decline'} in PMI represents a potential inflection. `;
    if (pmiDelta > 1.5) {
      section += `Early-cycle sectors (Materials, Industrials) may begin to outperform. `;
    } else {
      section += `Late-cycle defensives (Staples, Utilities) should continue to lead. `;
    }
    section += `This matters because waiting for confirmation may mean missing the first move.\n\n`;
  } else {
    section += `No major threshold crosses this month. The current regime remains intact. `;
    section += `This matters because patience is appropriate—no forced rotation required.\n\n`;
  }
  
  return section;
}

// ============================================
// ENHANCED QUOTE ANALYSIS
// ============================================

function writeEnhancedQuoteAnalysis(quotes, quoteAnalysis, mfg) {
  let section = '';
  
  section += `Direct commentary from ISM survey respondents provides color beyond the numbers. `;
  section += `The question is not just what they are saying—it is whether they are leading or lagging indicators.\n\n`;
  
  const cleanedQuotes = quotes.filter(q => q.comment && q.industry);
  const analyzedQuotes = quoteAnalysis?.quotes || [];
  
  const positiveQuotes = analyzedQuotes.filter(q => q.sentiment === 'positive') || [];
  const negativeQuotes = analyzedQuotes.filter(q => q.sentiment === 'negative') || [];
  
  if (analyzedQuotes.length > 0) {
    section += `**Overall tone: ${quoteAnalysis.overallSentiment || 'mixed'}**\n\n`;
    
    if (quoteAnalysis.summaryInsight) {
      section += cleanText(quoteAnalysis.summaryInsight) + '\n\n';
    }
    
    if (quoteAnalysis.keyThemes && quoteAnalysis.keyThemes.length > 0) {
      section += `**Key themes:** ${quoteAnalysis.keyThemes.join(', ')}\n\n`;
    }
    
    const leadingQuotes = analyzedQuotes.filter(q => q.leadingOrLagging === 'leading');
    if (leadingQuotes.length > 0) {
      section += `**Leading indicator signals:**\n\n`;
      leadingQuotes.slice(0, 3).forEach(q => {
        section += `*${cleanText(q.industry)}:* "${cleanText(q.originalQuote || q.comment)}"\n\n`;
        section += `This is a leading indicator because ${cleanText(q.investmentImplication || 'demand commentary typically precedes production changes')}.\n\n`;
      });
    }
    
    const laggingQuotes = analyzedQuotes.filter(q => q.leadingOrLagging === 'lagging');
    if (laggingQuotes.length > 0) {
      section += `**Lagging confirmation signals:**\n\n`;
      laggingQuotes.slice(0, 2).forEach(q => {
        section += `*${cleanText(q.industry)}:* "${cleanText(q.originalQuote || q.comment)}"\n\n`;
        section += `This is lagging confirmation because employment and production decisions follow orders by 3-6 months.\n\n`;
      });
    }
  } else {
    cleanedQuotes.slice(0, 6).forEach(quote => {
      section += `**${cleanText(quote.industry)}:**\n`;
      section += `"${cleanText(quote.comment)}"\n\n`;
      
      const sentiment = (quote.sentiment || '').toLowerCase();
      const theme = (quote.keyTheme || quote.theme || '').toLowerCase();
      
      section += `*Analysis:* `;
      
      if (theme.includes('demand') || theme.includes('order')) {
        section += `This is a leading indicator. Demand commentary typically precedes production shifts by 2-3 months. `;
      } else if (theme.includes('labor') || theme.includes('employment')) {
        section += `This is a lagging indicator. Employment decisions typically lag the cycle by 3-6 months. `;
      } else if (theme.includes('price') || theme.includes('cost')) {
        section += `This is contemporaneous. Cost pressures have immediate margin implications. `;
      } else if (theme.includes('inventory')) {
        section += `This is a leading indicator for production. Inventory adjustments drive near-term output. `;
      } else {
        section += `The timing signal is unclear. `;
      }
      
      if (sentiment === 'positive') {
        section += `This is constructive for sector equities.\n\n`;
      } else if (sentiment === 'negative') {
        section += `This suggests underweighting exposure to this segment.\n\n`;
      } else {
        section += `Selectivity within this segment is warranted.\n\n`;
      }
    });
  }
  
  return section;
}

// ============================================
// EQUITY FRAMEWORK
// ============================================

function writeEquityFramework(mfg, criteria) {
  let section = '';
  
  const pmi = mfg.pmi || 0;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const isContraction = pmi < 50;
  
  section += `Current ISM conditions call for the following equity selection framework:\n\n`;
  
  section += `**Characteristics to favor:**\n\n`;
  
  if (criteria?.favorable && criteria.favorable.length > 0) {
    criteria.favorable.slice(0, 4).forEach(item => {
      section += `*${cleanText(item.characteristic || item.name)}:* `;
      section += cleanText(item.rationale || item.reason || item.description || '') + '\n\n';
    });
  } else {
    if (isContraction && prices > 55) {
      section += `*Demonstrated pricing power:* Companies that have raised prices without volume destruction over the past 4 quarters. This matters because input costs at ${formatNumber(prices)} require pass-through ability.\n\n`;
      section += `*Lean cost structures:* Lower fixed costs limit earnings downside. Variable cost models outperform in volume declines.\n\n`;
      section += `*Strong free cash flow:* Funds shareholder returns without incremental leverage. Quality screen: FCF/EV > 5%.\n\n`;
    } else if (isContraction) {
      section += `*Quality metrics:* High ROE (>15%), low debt/EBITDA (<2x), consistent margins. This matters because quality outperforms in late cycle.\n\n`;
      section += `*Defensive demand:* End markets with inelastic demand. Examples: staples, healthcare, utilities.\n\n`;
    } else {
      section += `*Operating leverage:* High fixed cost structures benefit from volume recovery. This is the environment for cyclical exposure.\n\n`;
      section += `*Order book visibility:* Companies with rebuilding backlogs. Screen: backlog/revenue increasing.\n\n`;
    }
  }
  
  section += `**Characteristics to avoid:**\n\n`;
  
  if (criteria?.unfavorable && criteria.unfavorable.length > 0) {
    criteria.unfavorable.slice(0, 4).forEach(item => {
      section += `*${cleanText(item.characteristic || item.name)}:* `;
      section += cleanText(item.rationale || item.reason || item.description || '') + '\n\n';
    });
  } else {
    if (isContraction) {
      section += `*High operating leverage:* Fixed cost structures amplify earnings declines. Employment at ${formatNumber(employment)} signals companies are already cutting to protect margins.\n\n`;
      section += `*CapEx dependency:* Demand tied to customer capital spending decisions, which are being deferred.\n\n`;
      section += `*Excessive leverage:* Debt/EBITDA > 3x limits strategic flexibility and increases refinancing risk.\n\n`;
    } else {
      section += `*Stretched valuations:* P/E > 25x on cyclical earnings creates downside risk if expansion falters.\n\n`;
      section += `*Capacity constrained:* Companies that cut too aggressively may miss the recovery.\n\n`;
    }
  }
  
  return section;
}

// ============================================
// INVESTMENT THEMES
// ============================================

function writeTradeThemes(mfg, tradeData) {
  let section = '';
  
  section += `Based on current ISM conditions, we highlight the following investment themes:\n\n`;
  
  if (tradeData?.ideas && tradeData.ideas.length > 0) {
    tradeData.ideas.slice(0, 4).forEach((idea, index) => {
      const ticker = cleanText(idea.ticker || idea.symbol || '');
      const direction = (idea.direction || '').toLowerCase();
      const sector = cleanText(idea.sector || '');
      
      section += `**Theme ${index + 1}: `;
      if (direction === 'long') section += `Constructive on `;
      else if (direction === 'short') section += `Cautious on `;
      section += `${ticker || sector}**\n\n`;
      
      if (idea.thesis) {
        const thesis = typeof idea.thesis === 'string' 
          ? idea.thesis 
          : idea.thesis.ismLogic || idea.thesis.description || '';
        if (thesis) section += cleanText(thesis) + '\n\n';
      }
      
      section += `*Why this matters:* `;
      if (idea.ismConnection || idea.thesis?.ismConnection) {
        section += cleanText(idea.ismConnection || idea.thesis.ismConnection) + '\n\n';
      } else {
        section += `This theme is directly supported by current ISM readings.\n\n`;
      }
      
      if (idea.invalidation && idea.invalidation.length > 0) {
        section += `*What would change this view:* ${idea.invalidation.map(i => cleanText(i)).join('; ')}\n\n`;
      }
    });
  } else {
    const pmi = mfg.pmi || 0;
    
    if (pmi < 48) {
      section += `**Theme 1: Quality over cyclicality**\n\n`;
      section += `With manufacturing in contraction at ${formatNumber(pmi)}, quality factors historically outperform. `;
      section += `Screen for high ROE, consistent margins, and low leverage. `;
      section += `This matters because earnings volatility increases in contraction—quality provides ballast.\n\n`;
      
      section += `**Theme 2: Consumer Staples over Discretionary**\n\n`;
      section += `Defensive demand and pricing power favor staples. `;
      section += `Prices at ${formatNumber(mfg.prices)} with weak demand creates margin squeeze for discretionary. `;
      section += `This matters because relative performance divergence typically widens in late cycle.\n\n`;
    } else {
      section += `**Theme 1: Selective cyclical exposure**\n\n`;
      section += `Manufacturing expansion at ${formatNumber(pmi)} supports earnings for companies with operating leverage. `;
      section += `Focus on names with order book visibility and pricing power.\n\n`;
    }
  }
  
  section += `*These themes are frameworks for analysis, not specific trade recommendations.*`;
  
  return section;
}

// ============================================
// STOCK-LEVEL IMPLICATIONS
// ============================================

function writeStockImplications(mfg, sectorData, tradeData) {
  let section = '';
  
  const pmi = mfg.pmi || 0;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const isContraction = pmi < 50;
  
  section += `Moving from sectors to specific names, these archetypes warrant attention:\n\n`;
  
  const rankings = sectorData?.rankings || [];
  const sortedRankings = [...rankings].sort((a, b) => (b.score || 0) - (a.score || 0));
  
  section += `**Names positioned to outperform:**\n\n`;
  
  if (isContraction && prices > 55) {
    section += `*Margin-protected staples:* PG, KO, COST. These names have demonstrated pricing power and defensive demand. `;
    section += `With Prices at ${formatNumber(prices)}, their ability to pass through costs matters.\n\n`;
    
    section += `*Quality defensives:* JNJ, UNH, MSFT. High ROE, low leverage, consistent margins. `;
    section += `Quality outperforms in late-cycle weakness.\n\n`;
  } else if (isContraction) {
    section += `*Quality cyclicals:* HON, ETN, CMI. These industrials have diversified end markets and strong balance sheets. `;
    section += `If stabilization occurs, they will lead the recovery.\n\n`;
    
    section += `*Defensive growth:* MSFT, GOOGL. Secular demand offsets cyclical headwinds.\n\n`;
  } else {
    section += `*Early-cycle industrials:* CAT, DE, EMR. Operating leverage benefits from volume recovery. `;
    section += `New Orders at ${formatNumber(mfg.newOrders)} supports equipment demand.\n\n`;
    
    section += `*Materials beneficiaries:* FCX, LIN, NUE. Tied to manufacturing activity and infrastructure spend.\n\n`;
  }
  
  if (sortedRankings.length > 0 && sortedRankings[0].keyStocks) {
    const topSector = sortedRankings[0];
    section += `*${topSector.sector || topSector.name} leaders:* ${topSector.keyStocks.join(', ')}. `;
    section += `Our top-ranked sector based on ISM dynamics.\n\n`;
  }
  
  section += `**Names requiring caution:**\n\n`;
  
  if (isContraction) {
    section += `*High operating leverage cyclicals:* CAT, DE (if employment deteriorates further). `;
    section += `Fixed costs amplify earnings declines. Employment at ${formatNumber(employment)} signals margin pressure.\n\n`;
    
    section += `*Labor-intensive manufacturers:* FDX, DAL, UPS. `;
    section += `Labor costs are sticky while volumes decline.\n\n`;
    
    section += `*CapEx-dependent:* AMAT, LRCX, KLAC (if New Orders weakens). `;
    section += `Customer capital spending decisions are being deferred.\n\n`;
  } else {
    section += `*Over-extended valuations:* Names trading > 25x forward P/E on cyclical earnings. `;
    section += `Multiple compression risk if expansion falters.\n\n`;
  }
  
  if (sortedRankings.length > 0) {
    const bottomSector = sortedRankings[sortedRankings.length - 1];
    if (bottomSector.keyStocks) {
      section += `*${bottomSector.sector || bottomSector.name} laggards:* ${bottomSector.keyStocks.join(', ')}. `;
      section += `Our lowest-ranked sector based on ISM dynamics.\n\n`;
    }
  }
  
  section += `*Note: These are illustrative examples based on ISM dynamics, not specific recommendations. `;
  section += `Company-specific factors should be evaluated before taking positions.*\n`;
  
  return section;
}

// ============================================
// PRACTICAL POSITIONING
// ============================================

function writePracticalPositioning(mfg, sectorData, tradeData, momChanges) {
  let section = '';
  
  const pmi = mfg.pmi || 0;
  const prices = mfg.prices || 50;
  const employment = mfg.employment || 50;
  const newOrders = mfg.newOrders || 50;
  const isContraction = pmi < 50;
  const pmiDelta = momChanges?.pmi?.delta || 0;
  
  section += `Translating analysis into actionable positioning:\n\n`;
  
  section += `**Overweight:**\n\n`;
  
  if (isContraction && prices > 55) {
    section += `- Consumer Staples (pricing power in cost-push environment)\n`;
    section += `- Quality / Low Volatility factor (margin of safety)\n`;
    section += `- Healthcare (defensive demand, demographic tailwind)\n`;
    section += `- Selective Technology (secular demand, AI infrastructure)\n\n`;
  } else if (isContraction) {
    section += `- Consumer Staples (defensive positioning)\n`;
    section += `- Healthcare (inelastic demand)\n`;
    section += `- Quality factor across sectors\n`;
    section += `- Utilities (rate-sensitive but defensive)\n\n`;
  } else {
    section += `- Industrials (operating leverage on volume recovery)\n`;
    section += `- Materials (tied to manufacturing activity)\n`;
    section += `- Financials (economic proxy, rate benefit)\n`;
    section += `- Technology (capex beneficiary)\n\n`;
  }
  
  section += `**Underweight:**\n\n`;
  
  if (isContraction) {
    section += `- Machinery / Heavy Equipment (backlog depletion, capex deferral)\n`;
    section += `- Transportation Equipment (labor cost pressure)\n`;
    section += `- High operating leverage cyclicals\n`;
    section += `- Consumer Discretionary (demand elasticity)\n\n`;
  } else {
    section += `- Utilities (opportunity cost in expansion)\n`;
    section += `- Defensive REITS (yield compression risk)\n`;
    section += `- Cash / short duration (missing upside)\n\n`;
  }
  
  section += `**Avoid:**\n\n`;
  
  if (isContraction) {
    section += `- High inventory + low pricing power names\n`;
    section += `- Levered cyclicals (Debt/EBITDA > 3x)\n`;
    section += `- Companies with labor-heavy cost structures and union exposure\n`;
    section += `- Commoditized manufacturers without differentiation\n\n`;
  } else {
    section += `- Extreme valuations on cyclical earnings (>25x P/E)\n`;
    section += `- Companies that cut too aggressively (capacity constrained)\n`;
    section += `- Names with deteriorating order books despite sector tailwind\n\n`;
  }
  
  section += `**Watch for longs if data stabilizes:**\n\n`;
  
  if (isContraction) {
    section += `- Materials tied to restocking cycle (LIN, FCX, DOW)\n`;
    section += `- Quality industrials with order book visibility (HON, ETN)\n`;
    section += `- Early-cycle small caps (if New Orders crosses above 52)\n`;
    section += `- CapEx beneficiaries once confidence returns (CAT, DE)\n\n`;
    
    section += `*Trigger:* New Orders sustained above 50, Employment stabilizing above 48, PMI improving for 2 consecutive months.\n\n`;
  } else {
    section += `- Second derivative beneficiaries (suppliers to lead sectors)\n`;
    section += `- Beaten-down cyclicals with improving fundamentals\n`;
    section += `- International exposure plays (if global PMIs confirm)\n\n`;
  }
  
  section += `**Example names to monitor (not recommendations):**\n\n`;
  
  if (isContraction && prices > 55) {
    section += `*Margin-protected:* PG, KO, COST, WMT\n`;
    section += `*Quality defensives:* JNJ, MSFT, GOOGL\n`;
    section += `*Weak cyclicals to avoid:* CAT, DE, X, NUE\n`;
    section += `*Restocking candidates if stabilizing:* LIN, FCX, DOW\n`;
  } else if (isContraction) {
    section += `*Defensives:* PG, KO, JNJ, UNH\n`;
    section += `*Quality:* MSFT, GOOGL, V, MA\n`;
    section += `*Early-cycle watchlist:* CAT, DE, ETN, HON\n`;
  } else {
    section += `*Cyclical leaders:* CAT, DE, HON, ETN\n`;
    section += `*Materials beneficiaries:* FCX, LIN, NUE\n`;
    section += `*Reduce defensives:* Utilities, Staples (relative underweight)\n`;
  }
  
  return section;
}

// ============================================
// INVALIDATION
// ============================================

function writeInvalidation(scenarios, mfg, momChanges) {
  let section = '';
  
  section += `This analysis would require material revision if:\n\n`;
  
  if (scenarios && scenarios.length > 0) {
    scenarios.slice(0, 6).forEach(scenario => {
      section += `- ${cleanText(scenario)}\n`;
    });
  } else {
    const pmi = mfg.pmi || 0;
    
    if (pmi < 50) {
      section += `- PMI crosses above 50 and sustains for 2+ consecutive months (regime change)\n`;
      section += `- New Orders accelerates above 52, signaling demand recovery (leading indicator flip)\n`;
      section += `- Employment stabilizes above 50, signaling business confidence (labor hoarding)\n`;
    } else {
      section += `- PMI drops below 50 and sustains (expansion ends)\n`;
      section += `- New Orders decelerates below 48 (demand weakness)\n`;
    }
    
    section += `- Federal Reserve materially shifts policy stance (rate cut/hike surprise)\n`;
    section += `- Geopolitical shock affecting supply chains or energy prices\n`;
    
    if (mfg.prices > 55) {
      section += `- Prices index normalizes below 52, relieving margin pressure\n`;
    }
    if (mfg.backlog && mfg.backlog < 45) {
      section += `- Backlog recovers above 48, improving forward visibility\n`;
    }
  }
  
  return section;
}

// ============================================
// WATCHLIST
// ============================================

function writeWatchlist(indicators, mfg) {
  let section = '';
  
  if (indicators && indicators.length > 0) {
    indicators.slice(0, 7).forEach(indicator => {
      section += `- ${cleanText(indicator)}\n`;
    });
  } else {
    section += `- New Orders direction (currently ${formatNumber(mfg.newOrders)}) — leading indicator of PMI direction\n`;
    section += `- Employment trajectory (currently ${formatNumber(mfg.employment)}) — confirms or denies severity of weakness\n`;
    section += `- Prices trend (currently ${formatNumber(mfg.prices)}) — margin pressure persistence\n`;
    section += `- Backlog level (currently ${formatNumber(mfg.backlog)}) — forward visibility metric\n`;
    section += `- Customer inventories normalization — restocking trigger\n`;
    section += `- Regional Fed surveys (Empire State, Philly Fed) — early confirmation\n`;
    section += `- ISM Services PMI — broader economy health check\n`;
  }
  
  return section;
}

// ============================================
// HTML REPORT GENERATOR
// ============================================

function generateHTMLReport(report, context) {
  const markdown = generateMarkdownReport(report, context);
  
  let html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ISM Manufacturing Report - ${formatMonthDisplay(context.reportMonth)}</title>
  <style>
    body {
      font-family: 'Georgia', serif;
      max-width: 800px;
      margin: 0 auto;
      padding: 40px 20px;
      line-height: 1.7;
      color: #333;
      background: #fff;
    }
    h1 { font-size: 24px; font-weight: normal; border-bottom: 2px solid #333; padding-bottom: 10px; }
    h2 { font-size: 18px; font-weight: bold; margin-top: 30px; color: #1a1a1a; }
    h3 { font-size: 16px; font-weight: bold; margin-top: 20px; }
    p { margin: 10px 0; text-align: justify; }
    strong { font-weight: 600; }
    em { font-style: italic; color: #555; }
    hr { border: none; border-top: 1px solid #ddd; margin: 30px 0; }
    blockquote {
      border-left: 3px solid #ccc;
      padding-left: 15px;
      margin: 15px 0;
      color: #555;
      font-style: italic;
    }
    ul { padding-left: 20px; }
    li { margin: 5px 0; }
    .disclaimer { font-size: 12px; color: #888; margin-top: 40px; }
  </style>
</head>
<body>
${markdownToHTML(markdown)}
</body>
</html>`;

  return html;
}

function markdownToHTML(md) {
  return md
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>')
    .replace(/^---$/gm, '<hr>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^(?!<[h|u|l|p|hr])/gm, '<p>')
    .replace(/<p><\/p>/g, '')
    .replace(/<p>(<h|<ul|<hr)/g, '$1')
    .replace(/(<\/h1>|<\/h2>|<\/h3>|<\/ul>|<hr>)<\/p>/g, '$1');
}

// ============================================
// EXPORTS
// ============================================

export {
  generateMarkdownReport,
  generateHTMLReport,
  cleanText,
  deepClean,
  formatMonthDisplay,
  formatNumber,
  formatDelta,
  writeSignalHierarchy,
  writeMispricingCall,
  writeCounterThesis,
  writePage0_AnalystContext,
  writePage1_MacroSnapshot,
  writePage2_UnderTheSurface,
  writePage3_SectorImpact,
  writePage4_VoicesFromField,
  writePage5_SectorInFocus,
};