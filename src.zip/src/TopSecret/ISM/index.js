// =====================================================
// ISM REPORT SYSTEM - ENTRY POINT v2.3
// =====================================================
// Location: src/TopSecret/ISM/index.js
//
// CHANGES from v2.2:
// - Added deleteISMReport function for complete cleanup
// - Added forceRegenerateISMReport function
// - Fixed: Delete now clears ism_report_tracking
// =====================================================

import { ISMDataService } from './data-service.js';
import { ISMOrchestrator, workflowManager } from './orchestrator.js';
import { ALL_AGENTS, AGENT_DEFINITIONS } from './IsmAgents.js';
import { generateMarkdownReport, generateHTMLReport } from './report-generator.js';
import {
  saveSectorAnalysis,
  saveTickerSelections,
  getSectorsForMonth,
  getTickersForMonth,
  getLatestSectorRankings,
  getLatestTickerSelections,
} from './sector-storage.js';
import { 
  PHASES, 
  PHASE_ORDER, 
  PHASE_LABELS,
  MACRO_REGIMES,
  REGIME_LABELS,
  VERSION 
} from './config.js';

// Global instances (initialized via initISMService)
let dataService = null;
let supabaseClient = null;
let openaiApiKey = null;
// Note: perplexityApiKey is passed directly to ISMDataService, not stored globally

/**
 * Initialize the ISM Service
 * Call this once at app startup
 */
function initISMService(supabase, options = {}) {
  console.log('[ISM] Initializing ISM Service v' + VERSION);
  
  supabaseClient = supabase;
  openaiApiKey = options.openaiApiKey || process.env.OPENAI_API_KEY;
  const perplexityApiKey = options.perplexityApiKey || process.env.PERPLEXITY_API_KEY;
  
  // Set environment variables for agents
  if (openaiApiKey) {
    process.env.OPENAI_API_KEY = openaiApiKey;
    console.log('[ISM] OpenAI API key configured (for analysis)');
  } else {
    console.warn('[ISM] WARNING: No OpenAI API key - AI agents will use fallbacks');
  }
  
  if (perplexityApiKey) {
    process.env.PERPLEXITY_API_KEY = perplexityApiKey;
    console.log('[ISM] Perplexity API key configured (for data fetching)');
  } else {
    console.warn('[ISM] WARNING: No Perplexity API key - will use fallback data only');
  }
  
  // Initialize data service
  // Perplexity = data fetching (has internet access)
  // OpenAI = analysis and report generation
  dataService = new ISMDataService(supabase, {
    perplexityApiKey,
    openaiApiKey,
  });
  
  console.log('[ISM] Data service initialized');
  console.log(`[ISM] ${ALL_AGENTS.length} agents loaded`);
  
  return {
    dataService,
    version: VERSION,
    agentsCount: ALL_AGENTS.length,
  };
}

/**
 * Generate an ISM report for a specific month
 */
async function generateISMReport(month, options = {}) {
  if (!dataService) {
    throw new Error('ISM Service not initialized. Call initISMService first.');
  }
  
  console.log(`[ISM] Generating report for ${month}...`);
  
  const orchestrator = new ISMOrchestrator(dataService, {
    supabase: supabaseClient,
    onProgress: options.onProgress || ((p) => {
      console.log(`[ISM] Progress: ${p.progress}% - ${p.currentAgentName || p.currentPhase}`);
    }),
    onAgentComplete: options.onAgentComplete || ((a) => {
      console.log(`[ISM] Agent ${a.agentName}: ${a.success ? 'OK' : 'FAILED'}`);
    }),
    onError: options.onError || console.error,
  });
  
  const result = await orchestrator.generate(month, {
    reportId: options.reportId,
    isAdminOverride: options.isAdminOverride || false,
    overrideReason: options.overrideReason,
    adminId: options.adminId,
  });
  
  if (result.success && supabaseClient && options.saveToDatabase !== false) {
    try {
      // Save main report
      await saveReportToDatabase(result);
      console.log('[ISM] Report saved to database');
      
      // Save sector analysis and ticker selections
      await saveSectorAndTickerData(result);
      
    } catch (error) {
      console.error('[ISM] Failed to save report:', error.message);
      result.saveError = error.message;
    }
  }
  
  return result;
}

/**
 * Save sector analysis and ticker selections to database
 */
async function saveSectorAndTickerData(result) {
  if (!supabaseClient || !result.report) return;
  
  const { reportId, report, meta } = result;
  const reportMonth = meta.reportMonth;
  
  // Get sector data from report
  const sectorData = report.sector_impacts || report.sector_rotation || report.sections?.sectorImpact;
  
  if (sectorData) {
    const sectorResult = await saveSectorAnalysis(
      supabaseClient,
      reportId,
      reportMonth,
      sectorData
    );
    
    if (sectorResult.success) {
      console.log(`[ISM] Saved ${sectorResult.count} sectors to database`);
    } else {
      console.warn('[ISM] Sector save warning:', sectorResult.error);
    }
    
    // Save ticker selections
    const stockImplications = report.stock_implications || report.stock_picks;
    
    const tickerResult = await saveTickerSelections(
      supabaseClient,
      reportId,
      reportMonth,
      sectorData,
      stockImplications
    );
    
    if (tickerResult.success) {
      console.log(`[ISM] Saved ${tickerResult.count} tickers to database`);
    } else {
      console.warn('[ISM] Ticker save warning:', tickerResult.error);
    }
  }
}

/**
 * Save report to Supabase
 */
async function saveReportToDatabase(result) {
  if (!supabaseClient) return;
  
  const { reportId, report, markdown, html, meta } = result;
  
  const reportRecord = {
    report_id: reportId,
    report_month: meta.reportMonth,
    status: 'completed',
    executive_summary: report.executiveSummary,
    five_line_summary: report.fiveLineSummary,
    macro_snapshot: report.macro_snapshot || report.sections?.macroSnapshot,
    trend_engine: report.supplementary?.trends || report.sections?.trendEngine,
    sector_impact: report.sector_impacts || report.sections?.sectorImpact,
    equity_logic: report.equity_logic || report.sections?.equityLogic,
    trade_ideas: report.trade_ideas || report.sections?.tradeIdeas,
    quotes: report.quotes_analysis || report.supplementary?.quotes,
    qa_results: report.supplementary?.qa,
    historical_context: report.supplementary?.historical,
    invalidation_scenarios: report.invalidation_scenarios || report.invalidationScenarios,
    next_month_indicators: report.next_month_indicators || report.nextMonthIndicators,
    markdown_content: markdown,
    html_content: html,
    data_source: report.meta?.dataSource,
    pmi_value: report.macro_snapshot?.pmi || report.rawData?.ismData?.pmi,
    regime_code: report.macro_snapshot?.regime || report.sections?.macroSnapshot?.regime,
    regime_label: report.macro_snapshot?.regimeLabel || report.sections?.macroSnapshot?.regimeLabel,
    qa_score: report.supplementary?.qa?.qaScore,
    generation_duration_ms: meta.durationMs,
    agents_completed: meta.agentsCompleted,
    agents_total: meta.agentsTotal,
    errors_count: meta.errorsCount,
    generated_at: meta.generatedAt,
    version: VERSION,
  };
  
  const { error } = await supabaseClient
    .from('ism_reports')
    .upsert(reportRecord, { onConflict: 'report_id' });
  
  if (error) throw error;
  
  await supabaseClient
    .from('ism_report_tracking')
    .upsert({
      report_month: meta.reportMonth,
      latest_report_id: reportId,
      status: 'completed',
      generated_at: meta.generatedAt,
      pmi_value: report.rawData?.ismData?.pmi,
    }, { onConflict: 'report_month' });
}

/**
 * Get an existing report from database
 */
async function getISMReport(reportIdOrMonth) {
  if (!supabaseClient) {
    throw new Error('Supabase not initialized');
  }
  
  const isMonth = /^\d{4}-\d{2}$/.test(reportIdOrMonth);
  let query = supabaseClient.from('ism_reports');
  
  if (isMonth) {
    query = query.eq('report_month', reportIdOrMonth);
  } else {
    query = query.eq('report_id', reportIdOrMonth);
  }
  
  const { data, error } = await query
    .order('generated_at', { ascending: false })
    .limit(1)
    .single();
  
  if (error) throw error;
  return data;
}

// =====================================================
// DELETE & REGENERATE FUNCTIONS (NEW in v2.3)
// =====================================================

/**
 * Delete report and ALL related data for a month
 * This clears everything including tracking, cache, sectors, tickers
 * @param {string} month - Format: YYYY-MM (e.g., '2025-11')
 */
async function deleteISMReport(month) {
  if (!supabaseClient) {
    throw new Error('Supabase not initialized');
  }
  
  console.log(`[ISM] ⚠️ Deleting ALL data for ${month}...`);
  
  const results = {
    success: true,
    deleted: [],
    errors: [],
  };
  
  // List of tables to clean
  const tablesToClean = [
    { table: 'ism_reports', column: 'report_month' },
    { table: 'ism_report_tracking', column: 'report_month' },
    { table: 'ism_source_cache', column: 'data_month' },
    { table: 'ism_sector_analysis', column: 'report_month' },
    { table: 'ism_ticker_selections', column: 'report_month' },
    { table: 'ism_agent_logs', column: 'report_month' },
    { table: 'ism_report_progress', column: 'report_id' }, // Special handling below
  ];
  
  for (const { table, column } of tablesToClean) {
    try {
      // Special case for report_progress - need to find by report_id pattern
      if (table === 'ism_report_progress') {
        const { error } = await supabaseClient
          .from(table)
          .delete()
          .like('report_id', `%${month.replace('-', '')}%`);
        if (error && !error.message.includes('does not exist')) {
          results.errors.push(`${table}: ${error.message}`);
        } else {
          results.deleted.push(table);
        }
      } else {
        const { error } = await supabaseClient
          .from(table)
          .delete()
          .eq(column, month);
        if (error && !error.message.includes('does not exist')) {
          results.errors.push(`${table}: ${error.message}`);
        } else {
          results.deleted.push(table);
        }
      }
    } catch (err) {
      // Table might not exist, that's OK
      if (!err.message?.includes('does not exist')) {
        results.errors.push(`${table}: ${err.message}`);
      }
    }
  }
  
  results.success = results.errors.length === 0;
  
  console.log(`[ISM] ✓ Deleted from: ${results.deleted.join(', ')}`);
  if (results.errors.length > 0) {
    console.warn(`[ISM] ⚠️ Errors (may be OK if tables don't exist): ${results.errors.join(', ')}`);
  }
  
  return results;
}

/**
 * Force regenerate a report (delete old + clear cache + generate new)
 * @param {string} month - Format: YYYY-MM
 * @param {object} options - Generation options
 */
async function forceRegenerateISMReport(month, options = {}) {
  console.log(`[ISM] 🔄 Force regenerating report for ${month}...`);
  
  // Step 1: Delete all existing data
  const deleteResult = await deleteISMReport(month);
  console.log(`[ISM] Delete result:`, deleteResult);
  
  // Step 2: Clear data service cache (in memory)
  if (dataService) {
    await dataService.clearCache(month);
  }
  
  // Step 3: Generate new report with admin override
  const result = await generateISMReport(month, {
    ...options,
    isAdminOverride: true,
    overrideReason: options.overrideReason || 'Force regenerate requested',
  });
  
  return result;
}

// =====================================================
// EXISTING FUNCTIONS
// =====================================================

/**
 * Get available months that have data
 */
function getAvailableMonths() {
  if (!dataService) {
    throw new Error('ISM Service not initialized');
  }
  
  // Check for FALLBACK_DATA instead of REAL_ISM_DATA
  const fallbackData = dataService.FALLBACK_DATA || {};
  const months = Object.keys(fallbackData).sort().reverse();
  return months.map(month => ({
    month,
    available: true,
    source: 'ISM Data',
  }));
}

/**
 * Check if ISM data is available for a month
 */
function checkISMAvailability(month) {
  if (!dataService) {
    throw new Error('ISM Service not initialized');
  }
  return dataService.checkISMAvailability(month);
}

/**
 * Clear cache for a specific month
 */
async function clearCache(month) {
  if (!dataService) {
    throw new Error('ISM Service not initialized');
  }
  await dataService.clearCache(month);
  console.log(`[ISM] Cache cleared for ${month}`);
}

/**
 * Clear all cache
 */
async function clearAllCache() {
  if (!dataService) {
    throw new Error('ISM Service not initialized');
  }
  await dataService.clearAllCache();
  console.log('[ISM] All cache cleared');
}

/**
 * Get agent definitions for UI
 */
function getAgentDefinitions() {
  return AGENT_DEFINITIONS.map(agent => ({
    id: agent.id,
    name: agent.name,
    description: agent.description,
    icon: agent.icon,
    phase: agent.phase,
    phaseLabel: PHASE_LABELS[agent.phase],
    order: agent.order,
    estimatedSeconds: agent.estimatedSeconds,
  }));
}

/**
 * Get phase information for UI
 */
function getPhaseInfo() {
  return PHASE_ORDER.map(phase => ({
    id: phase,
    label: PHASE_LABELS[phase],
    agents: AGENT_DEFINITIONS.filter(a => a.phase === phase).map(a => a.id),
  }));
}

/**
 * Get regime information for UI
 */
function getRegimeInfo() {
  return Object.entries(REGIME_LABELS).map(([code, label]) => ({
    code,
    label,
  }));
}

/**
 * Fetch progress for a running report
 */
async function fetchISMProgress(reportId) {
  if (!supabaseClient) return null;
  
  const { data, error } = await supabaseClient
    .from('ism_report_progress')
    .select('*')
    .eq('report_id', reportId)
    .single();
  
  if (error) return null;
  return data;
}

/**
 * Update progress in database
 */
async function updateProgress(progress) {
  if (!supabaseClient) return;
  
  await supabaseClient
    .from('ism_report_progress')
    .upsert({
      report_id: progress.reportId,
      status: progress.status,
      progress: progress.progress,
      current_phase: progress.currentPhase,
      current_agent_id: progress.currentAgentId,
      current_agent_name: progress.currentAgentName,
      completed_agents: progress.completedAgents,
      total_agents: progress.totalAgents,
      elapsed_seconds: progress.elapsedSeconds,
      error: progress.error,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'report_id' });
}

// =====================================================
// SECTOR & TICKER DATA FUNCTIONS
// =====================================================

/**
 * Get sector rankings for a specific month
 * @param {string} reportMonth - Format: YYYY-MM
 */
async function fetchSectorsForMonth(reportMonth) {
  if (!supabaseClient) {
    throw new Error('Supabase not initialized');
  }
  return await getSectorsForMonth(supabaseClient, reportMonth);
}

/**
 * Get ticker selections for a specific month
 * @param {string} reportMonth - Format: YYYY-MM
 */
async function fetchTickersForMonth(reportMonth) {
  if (!supabaseClient) {
    throw new Error('Supabase not initialized');
  }
  return await getTickersForMonth(supabaseClient, reportMonth);
}

/**
 * Get latest sector rankings (most recent report)
 */
async function fetchLatestSectors() {
  if (!supabaseClient) {
    throw new Error('Supabase not initialized');
  }
  return await getLatestSectorRankings(supabaseClient);
}

/**
 * Get latest ticker selections (most recent report)
 */
async function fetchLatestTickers() {
  if (!supabaseClient) {
    throw new Error('Supabase not initialized');
  }
  return await getLatestTickerSelections(supabaseClient);
}

// =====================================================
// EXPORTS
// =====================================================

export {
  // Initialization
  initISMService,
  
  // Report Generation
  generateISMReport,
  getISMReport,
  getAvailableMonths,
  checkISMAvailability,
  
  // Delete & Regenerate (NEW in v2.3)
  deleteISMReport,
  forceRegenerateISMReport,
  
  // Cache Management
  clearCache,
  clearAllCache,
  
  // Progress Tracking
  fetchISMProgress,
  updateProgress,
  
  // UI Helpers
  getAgentDefinitions,
  getPhaseInfo,
  getRegimeInfo,
  
  // Sector & Ticker Data
  fetchSectorsForMonth,
  fetchTickersForMonth,
  fetchLatestSectors,
  fetchLatestTickers,
  
  // Constants
  PHASES,
  PHASE_ORDER,
  PHASE_LABELS,
  MACRO_REGIMES,
  REGIME_LABELS,
  VERSION,
  
  // Classes & Utilities
  ALL_AGENTS,
  AGENT_DEFINITIONS,
  ISMDataService,
  ISMOrchestrator,
  workflowManager,
  generateMarkdownReport,
  generateHTMLReport,
};