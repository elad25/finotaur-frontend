// =====================================================
// ISM REPORT AGENTS - INSTITUTIONAL QUALITY v9.1
// =====================================================
// NEW in v9.1:
// - Quote analyzer preserves ORIGINAL quotes verbatim
// - No AI rewriting of real ISM quotes
// - Clearer separation of quote text vs analysis
// NEW in v9.0:
// - Added fed_earnings_analyzer agent
// - Added stock_implications_generator agent  
// - Added practical_positioning_builder agent
// - Enhanced quote_analyzer with Leading/Lagging
// - Added "This matters because" language throughout
// - Enhanced MoM data handling
// =====================================================
// ABSOLUTE RULES:
// - ZERO emojis in ANY prompt or output
// - ZERO markdown tables anywhere
// - Goldman Sachs institutional tone only
// - Every prompt explicitly forbids emojis/tables
// - ALL DATA MUST COME FROM PERPLEXITY (via data-service)
// - QUOTES MUST BE PRESERVED VERBATIM - NO REWRITING
// =====================================================

import OpenAI from 'openai';
import { PHASES, MACRO_REGIMES, REGIME_LABELS, KEY_SECTORS, STOCK_ARCHETYPES } from './config.js';
import { ISMQuoteStorage, INDUSTRY_TO_SECTOR_MAP, SECTOR_TO_INDUSTRIES } from './quote-storage.js';


let quoteStorage = null;

function getQuoteStorage() {
  if (!quoteStorage) {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    quoteStorage = new ISMQuoteStorage(supabaseUrl, supabaseKey);
  }
  return quoteStorage;
}
// ============================================
// INSTITUTIONAL WRITING MANDATE - ENHANCED
// ============================================

const INSTITUTIONAL_MANDATE = `
YOU ARE A SENIOR ECONOMIST AT GOLDMAN SACHS GLOBAL INVESTMENT RESEARCH.

ABSOLUTE PROHIBITIONS - VIOLATING ANY IS IMMEDIATE FAILURE:
1. NO EMOJIS - Not a single emoji character anywhere
2. NO MARKDOWN TABLES - Never use | or table formatting. Write in prose.
3. NO BULLET POINTS for main analysis - Use flowing paragraphs
4. NO FIRST PERSON - Never "I think" or "I analyze"
5. NO META-COMMENTARY - Never "Let me analyze" or "Looking at the data"
6. NO HEDGING - Avoid "might", "could potentially", "seems to"
7. NO DECORATORS - No arrows, checkmarks, stars, or special symbols
8. NO "TOP SECRET", "EXCLUSIVE", "INSIDER" or marketing language
9. NO EXCLAMATION MARKS in analytical content

REQUIRED STYLE:
- Direct, confident statements with specific numbers woven into prose
- Numbers integrated naturally: "PMI registered 48.2" not "PMI: 48.2"
- Connected paragraphs with cause-and-effect reasoning
- Be OPINIONATED - institutional clients pay for your VIEW, not summaries
- Write as if briefing a portfolio manager who controls billions
- Analytical confidence without arrogance

REQUIRED PHRASES (use these to drive home impact):
- "This matters because..." (explain WHY something is important)
- "The risk here is not X, but Y" (clarify real risks)
- "If this persists into the next ISM, the implication is..." (forward guidance)
- "The question for positioning is..." (frame the decision)
- "We favor X over Y because..." (take a side)

AVOID THESE WEAK PHRASES:
- "Watch for..." (too passive - replace with "This matters because")
- "May indicate..." (be more direct)
- "Could suggest..." (take a position)

EXAMPLE OF CORRECT WRITING:
"Manufacturing remains under pressure with PMI registering 48.2. This matters because the ninth consecutive month below 50 signals structural weakness rather than a temporary soft patch. Employment contracted sharply to 44.0, the weakest reading since mid-2020, as companies accelerate workforce reductions to protect margins. The question for positioning is not whether conditions are weak—they clearly are—but whether we are approaching an inflection. New Orders at 49.8 suggest we may be, but confirmation is required."
`;
// ============================================
// OPENAI CLIENT SINGLETON
// ============================================

let openaiClient = null;

function getOpenAI() {
  if (!openaiClient) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (apiKey) {
      openaiClient = new OpenAI({ apiKey });
      console.log('[ISM Agents] OpenAI client initialized');
    }
  }
  return openaiClient;
}
// ============================================
// SECTOR MAPPING
// ============================================

const SECTOR_ETF_MAP = {
  'Consumer Staples': { etf: 'XLP', stocks: ['PG', 'KO', 'PEP', 'COST', 'WMT'] },
  'Industrials': { etf: 'XLI', stocks: ['CAT', 'DE', 'HON', 'UNP', 'GE'] },
  'Technology': { etf: 'XLK', stocks: ['AAPL', 'MSFT', 'NVDA', 'AMD', 'AVGO'] },
  'Materials': { etf: 'XLB', stocks: ['LIN', 'APD', 'FCX', 'NEM', 'DOW'] },
  'Healthcare': { etf: 'XLV', stocks: ['UNH', 'JNJ', 'PFE', 'ABBV', 'MRK'] },
  'Consumer Discretionary': { etf: 'XLY', stocks: ['AMZN', 'TSLA', 'HD', 'MCD', 'NKE'] },
  'Financials': { etf: 'XLF', stocks: ['JPM', 'BAC', 'WFC', 'GS', 'MS'] },
  'Energy': { etf: 'XLE', stocks: ['XOM', 'CVX', 'COP', 'SLB', 'EOG'] },
  'Transportation': { etf: 'IYT', stocks: ['UNP', 'FDX', 'DAL', 'UPS', 'CSX'] },
  'Utilities': { etf: 'XLU', stocks: ['NEE', 'DUK', 'SO', 'D', 'AEP'] },
};

// ============================================
// AGENT DEFINITIONS - UPDATED with new agents
// ============================================

const AGENT_DEFINITIONS = [
  { id: 'ism_data_fetcher', name: 'ISM Data Fetcher', description: 'Fetches live ISM data via Perplexity', phase: PHASES.DATA_ACQUISITION, order: 1, dependencies: [], estimatedSeconds: 30 },
  { id: 'historical_context_builder', name: 'Historical Context Builder', description: 'Builds multi-month context', phase: PHASES.DATA_ACQUISITION, order: 2, dependencies: ['ism_data_fetcher'], estimatedSeconds: 15 },
  { id: 'macro_regime_detector', name: 'Macro Regime Detector', description: 'Classifies current economic regime', phase: PHASES.MACRO_ANALYSIS, order: 3, dependencies: ['ism_data_fetcher', 'historical_context_builder'], estimatedSeconds: 45 },
  { id: 'gap_analyzer', name: 'Critical Gap Analyzer', description: 'Identifies divergences in ISM components', phase: PHASES.MACRO_ANALYSIS, order: 4, dependencies: ['ism_data_fetcher'], estimatedSeconds: 30 },
  { id: 'narrative_architect', name: 'Narrative Architect', description: 'Writes institutional macro narrative', phase: PHASES.MACRO_ANALYSIS, order: 5, dependencies: ['macro_regime_detector', 'gap_analyzer'], estimatedSeconds: 60 },
  { id: 'fed_earnings_analyzer', name: 'Fed & Earnings Analyzer', description: 'Connects ISM to Fed policy and earnings', phase: PHASES.MACRO_ANALYSIS, order: 6, dependencies: ['ism_data_fetcher', 'narrative_architect'], estimatedSeconds: 45, isNew: true },
  { id: 'persistent_trend_scanner', name: 'Persistent Trend Scanner', description: 'Identifies multi-month trends', phase: PHASES.TREND_ANALYSIS, order: 7, dependencies: ['historical_context_builder', 'ism_data_fetcher'], estimatedSeconds: 40 },
  { id: 'structural_pressure_mapper', name: 'Structural Pressure Mapper', description: 'Maps headwinds and tailwinds', phase: PHASES.TREND_ANALYSIS, order: 8, dependencies: ['ism_data_fetcher', 'persistent_trend_scanner'], estimatedSeconds: 35 },
  { id: 'sector_impact_scorer', name: 'Sector Impact Scorer', description: 'Ranks sectors by ISM impact', phase: PHASES.SECTOR_ANALYSIS, order: 9, dependencies: ['narrative_architect', 'persistent_trend_scanner'], estimatedSeconds: 60 },
  { id: 'quote_analyzer', name: 'Respondent Quote Analyzer', description: 'Analyzes real industry quotes with Leading/Lagging classification', phase: PHASES.SECTOR_ANALYSIS, order: 10, dependencies: ['ism_data_fetcher', 'sector_impact_scorer'], estimatedSeconds: 50 },
  { id: 'equity_criteria_builder', name: 'Equity Criteria Builder', description: 'Defines stock selection criteria', phase: PHASES.EQUITY_ANALYSIS, order: 11, dependencies: ['narrative_architect', 'sector_impact_scorer'], estimatedSeconds: 45 },
  { id: 'stock_implications_generator', name: 'Stock Implications Generator', description: 'Maps sectors to specific stocks', phase: PHASES.EQUITY_ANALYSIS, order: 12, dependencies: ['sector_impact_scorer', 'equity_criteria_builder'], estimatedSeconds: 50, isNew: true },
  { id: 'trade_idea_generator', name: 'Trade Idea Generator', description: 'Generates actionable trade ideas', phase: PHASES.TRADE_SYNTHESIS, order: 13, dependencies: ['equity_criteria_builder', 'sector_impact_scorer'], estimatedSeconds: 75 },
  { id: 'practical_positioning_builder', name: 'Practical Positioning Builder', description: 'Creates Overweight/Underweight summary', phase: PHASES.TRADE_SYNTHESIS, order: 14, dependencies: ['sector_impact_scorer', 'trade_idea_generator', 'stock_implications_generator'], estimatedSeconds: 45, isNew: true },
  { id: 'coherence_checker', name: 'Quality Assurance', description: 'Validates report consistency', phase: PHASES.QUALITY_ASSURANCE, order: 15, dependencies: ['trade_idea_generator', 'practical_positioning_builder'], estimatedSeconds: 30 },
  { id: 'executive_summary_writer', name: 'Executive Summary Writer', description: 'Writes 5-line executive summary', phase: PHASES.QUALITY_ASSURANCE, order: 16, dependencies: ['coherence_checker'], estimatedSeconds: 40 },
];

// ============================================
// OPENAI HELPER
// ============================================

async function callOpenAI(systemPrompt, userPrompt, options = {}) {
  const openai = getOpenAI();
  
  if (!openai) {
    console.warn('[Agent] No OpenAI client available');
    return null;
  }

  const fullSystemPrompt = INSTITUTIONAL_MANDATE + '\n\n' + systemPrompt;

  try {
    const response = await openai.chat.completions.create({
      model: options.model || 'gpt-4o',
      messages: [
        { role: 'system', content: fullSystemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: options.temperature || 0.2,
      max_tokens: options.maxTokens || 4000,
    });

    const content = response.choices[0]?.message?.content;
    
    if (options.parseJSON) {
      return extractJSON(content);
    }
    
    return content;

  } catch (error) {
    console.error('[OpenAI] Error:', error.message);
    return null;
  }
}

function extractJSON(text) {
  if (!text) return null;
  
  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/```(?:json)?\s*([\s\S]*?)```/) || text.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (match) {
      try {
        return JSON.parse(match[1].trim());
      } catch {}
    }
  }
  return null;
}

// ============================================
// AGENT 1: ISM Data Fetcher
// ============================================

async function executeISMDataFetcher(context) {
  const startTime = Date.now();
  
  try {
    const { dataService, reportMonth } = context;
    
    console.log(`[ISM Data Fetcher] Fetching LIVE data for ${reportMonth}...`);
    const ismData = await dataService.fetchISMData(reportMonth);
    
    if (!ismData || !ismData.manufacturing?.pmi) {
      return {
        success: false,
        data: null,
        error: 'Failed to fetch ISM data - no PMI value. Verify Perplexity API is working and ISM data has been released.',
        duration: Date.now() - startTime,
      };
    }
    
    console.log(`[ISM Data Fetcher] SUCCESS: PMI=${ismData.manufacturing.pmi}, Source=${ismData.dataSource}`);
    console.log(`[ISM Data Fetcher] Prior month PMI: ${ismData.priorMonth?.pmi || 'N/A'}`);
    console.log(`[ISM Data Fetcher] MoM changes available: ${ismData.momChanges ? 'Yes' : 'No'}`);
    console.log(`[ISM Data Fetcher] Quotes: ${ismData.respondentComments?.length || 0} real industry quotes`);
    
    return {
      success: true,
      data: ismData,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return {
      success: false,
      error: error.message,
      duration: Date.now() - startTime,
    };
  }
}

// ============================================
// AGENT 2: Historical Context Builder
// ============================================

async function executeHistoricalContextBuilder(context) {
  const startTime = Date.now();
  
  try {
    const { dataService, reportMonth } = context;
    const historical = await dataService.getHistoricalContext(reportMonth, 12);
    
    return {
      success: true,
      data: historical,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return {
      success: false,
      error: error.message,
      duration: Date.now() - startTime,
    };
  }
}

// ============================================
// AGENT 3: Macro Regime Detector
// ============================================

async function executeMacroRegimeDetector(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const historical = context.results.historical_context_builder;
    
    if (!ismData) {
      return { success: false, error: 'No ISM data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    const consecutiveContraction = historical?.consecutiveContractionMonths || 0;
    const consecutiveExpansion = historical?.consecutiveExpansionMonths || 0;
    
    const aiAnalysis = await callOpenAI(
  `You classify the current US manufacturing economic regime based on ISM data.
You MUST also provide an alternative interpretation - what if we are wrong?

REGIME CODES (use exact code):
- expansion_accelerating: PMI > 50 AND momentum increasing
- expansion_decelerating: PMI > 50 BUT momentum fading
- contraction_recovering: PMI < 50 BUT showing stabilization
- contraction_deepening: PMI < 50 AND worsening
- late_cycle_weakness: PMI 48-52 with mixed signals
- stagflation_risk: PMI < 50 AND Prices > 55 AND Employment < 48
- early_cycle_recovery: PMI just crossed above 50 after contraction
- goldilocks: PMI 52-56, moderate growth, stable prices`,
  
  `Classify this ISM Manufacturing data:

PMI: ${mfg.pmi} (Previous: ${ismData.priorMonth?.pmi || 'N/A'}, Delta: ${momChanges.pmi?.delta || 'N/A'})
New Orders: ${mfg.newOrders} (Previous: ${ismData.priorMonth?.newOrders || 'N/A'})
Production: ${mfg.production}
Employment: ${mfg.employment} (Previous: ${ismData.priorMonth?.employment || 'N/A'})
Prices: ${mfg.prices}
Backlog: ${mfg.backlog}
Consecutive contraction months: ${consecutiveContraction}
Consecutive expansion months: ${consecutiveExpansion}

Return JSON only:
{
  "regime": "<exact_regime_code>",
  "confidence": <60-99>,
  "reasoning": "<2-3 sentences with specific ISM numbers explaining classification>",
  "keyFactors": ["<factor1>", "<factor2>", "<factor3>"],
  "criticalObservation": "<single most important insight - start with 'This matters because'>",
  "cyclePosition": "early|mid|late|recession",
  "direction": "improving|stable|deteriorating",
  "riskLevel": "low|moderate|elevated|high",
  
  "alternativeInterpretation": {
    "thesis": "<what is a reasonable alternative reading of the same data?>",
    "supportingEvidence": "<which ISM components support the alternative view?>",
    "whatWouldConfirmIt": "<what would we need to see next month to validate this alternative?>",
    "whyWeDiscountIt": "<why do we think our primary view is more likely?>"
  },
  "whatWeCouldBeWrongAbout": "<biggest assumption we are making that could be wrong>",
  "keyDebate": "<the central question investors should be asking>"
}`,
  { parseJSON: true, temperature: 0.15 }
);

    if (aiAnalysis) {
      return {
        success: true,
        data: {
          regimeCode: aiAnalysis.regime,
          regimeLabel: REGIME_LABELS[aiAnalysis.regime] || aiAnalysis.regime,
          confidence: aiAnalysis.confidence,
          reasoning: aiAnalysis.reasoning,
          keyFactors: aiAnalysis.keyFactors || [],
          criticalObservation: aiAnalysis.criticalObservation,
          cyclePosition: aiAnalysis.cyclePosition,
          direction: aiAnalysis.direction,
          riskLevel: aiAnalysis.riskLevel,
          pmiLevel: mfg.pmi,
          isContraction: mfg.pmi < 50,
          isExpansion: mfg.pmi >= 50,
          consecutiveContractionMonths: consecutiveContraction,
          consecutiveExpansionMonths: consecutiveExpansion,
          momChanges: momChanges,
          // NEW COUNTER-THESIS FIELDS
          alternativeInterpretation: aiAnalysis.alternativeInterpretation || null,
          whatWeCouldBeWrongAbout: aiAnalysis.whatWeCouldBeWrongAbout || null,
          keyDebate: aiAnalysis.keyDebate || null,
        },
        duration: Date.now() - startTime,
      };
    }

    // Fallback logic
    let regime, reasoning, riskLevel, direction;
    
    if (mfg.pmi < 50 && mfg.prices > 55 && mfg.employment < 48) {
      regime = 'stagflation_risk';
      reasoning = `PMI at ${mfg.pmi} contracting with Prices at ${mfg.prices} elevated and Employment at ${mfg.employment} weak creates stagflationary conditions. This matters because margin compression will be severe.`;
      riskLevel = 'high';
      direction = 'deteriorating';
    } else if (mfg.pmi < 50) {
      regime = consecutiveContraction > 6 ? 'contraction_deepening' : 'contraction_recovering';
      reasoning = `PMI at ${mfg.pmi} indicates ${consecutiveContraction} consecutive months of contraction. This matters because duration signals structural weakness.`;
      riskLevel = 'elevated';
      direction = momChanges.pmi?.delta > 0 ? 'improving' : 'deteriorating';
    } else {
      regime = mfg.newOrders > mfg.pmi ? 'expansion_accelerating' : 'expansion_decelerating';
      reasoning = `PMI at ${mfg.pmi} with New Orders at ${mfg.newOrders}. This matters because New Orders is a leading indicator.`;
      riskLevel = 'moderate';
      direction = mfg.newOrders > mfg.pmi ? 'improving' : 'stable';
    }

    return {
      success: true,
      data: {
        regimeCode: regime,
        regimeLabel: REGIME_LABELS[regime] || regime,
        confidence: 75,
        reasoning,
        keyFactors: [`PMI at ${mfg.pmi}`, `Employment at ${mfg.employment}`, `Prices at ${mfg.prices}`],
        criticalObservation: reasoning,
        cyclePosition: mfg.pmi < 48 ? 'late' : 'mid',
        direction,
        riskLevel,
        pmiLevel: mfg.pmi,
        isContraction: mfg.pmi < 50,
        isExpansion: mfg.pmi >= 50,
        consecutiveContractionMonths: consecutiveContraction,
        consecutiveExpansionMonths: consecutiveExpansion,
        momChanges: momChanges,
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 4: Critical Gap Analyzer
// ============================================

async function executeGapAnalyzer(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    if (!ismData) {
      return { success: false, error: 'No ISM data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    const gaps = [];

    // Production vs New Orders Gap
    const prodOrderGap = mfg.production - mfg.newOrders;
    if (Math.abs(prodOrderGap) > 2) {
      gaps.push({
        id: 'prod_orders_gap',
        type: 'Production-Orders Divergence',
        severity: Math.abs(prodOrderGap) > 4 ? 'high' : 'moderate',
        gap: parseFloat(prodOrderGap.toFixed(1)),
        signal: prodOrderGap > 0 
          ? `Production at ${mfg.production} outpaces New Orders at ${mfg.newOrders} by ${prodOrderGap.toFixed(1)} points.`
          : `New Orders at ${mfg.newOrders} exceeds Production at ${mfg.production}.`,
        implication: prodOrderGap > 0 
          ? `This matters because companies are depleting backlogs rather than building for future demand. Earnings visibility is impaired.`
          : `This matters because demand exceeds current output—a positive leading signal for future production.`,
        investmentAction: prodOrderGap > 0 
          ? 'Caution on inventory-heavy industrials. Favor lean operators.'
          : 'Constructive on capacity-constrained manufacturers.',
      });
    }

    // Stagflation Signal
    if (mfg.prices > 52 && mfg.pmi < 50) {
      const stagGap = mfg.prices - mfg.pmi;
      gaps.push({
        id: 'stagflation_gap',
        type: 'Stagflationary Pressure',
        severity: stagGap > 8 ? 'high' : 'moderate',
        gap: parseFloat(stagGap.toFixed(1)),
        signal: `Costs rising with Prices at ${mfg.prices} while activity contracts with PMI at ${mfg.pmi}.`,
        implication: `This matters because companies cannot pass through costs in weak demand. Expect margin compression worse than consensus.`,
        investmentAction: 'Defensive positioning required. Favor pricing power and essential goods.',
      });
    }

    // Employment vs Production
    const empProdGap = mfg.employment - mfg.production;
    if (Math.abs(empProdGap) > 3) {
      gaps.push({
        id: 'emp_prod_gap',
        type: 'Employment-Production Divergence',
        severity: Math.abs(empProdGap) > 5 ? 'high' : 'moderate',
        gap: parseFloat(empProdGap.toFixed(1)),
        signal: empProdGap < 0
          ? `Companies maintain Production at ${mfg.production} while cutting Employment to ${mfg.employment}.`
          : `Employment at ${mfg.employment} expands faster than Production.`,
        implication: empProdGap < 0 
          ? `This matters because workforce reductions signal margin protection mode. Expect earnings focus on cost control.`
          : `This matters because labor costs are rising faster than output—margin compression risk.`,
        investmentAction: empProdGap < 0 
          ? 'Favor automation exposure and low labor intensity.'
          : 'Caution on labor-intensive manufacturers.',
      });
    }

    // New Orders vs Backlog
    if (mfg.backlog && mfg.newOrders) {
      const ordersBacklogGap = mfg.newOrders - mfg.backlog;
      if (Math.abs(ordersBacklogGap) > 3) {
        gaps.push({
          id: 'orders_backlog_gap',
          type: 'Orders-Backlog Divergence',
          severity: Math.abs(ordersBacklogGap) > 5 ? 'high' : 'moderate',
          gap: parseFloat(ordersBacklogGap.toFixed(1)),
          signal: ordersBacklogGap > 0
            ? `New Orders at ${mfg.newOrders} exceeds Backlog at ${mfg.backlog}.`
            : `Backlog at ${mfg.backlog} exceeds New Orders at ${mfg.newOrders}.`,
          implication: ordersBacklogGap > 0
            ? `This matters because new demand is being filled immediately rather than building pipeline. Watch for production acceleration.`
            : `This matters because backlog provides visibility even as new orders slow.`,
          investmentAction: ordersBacklogGap > 0
            ? 'Production-sensitive names may benefit.'
            : 'Backlog provides cushion for near-term earnings.',
        });
      }
    }

    // Sort by severity
    gaps.sort((a, b) => {
      const severityOrder = { high: 0, moderate: 1, low: 2 };
      return severityOrder[a.severity] - severityOrder[b.severity];
    });

    // Build Signal Hierarchy - ADD THIS BEFORE THE RETURN
const signalHierarchy = {
  primary: null,
  confirmation: [],
  noise: [],
};

// Determine PRIMARY signal based on regime
if (mfg.newOrders < 50 && mfg.prices > 55) {
  // Stagflation scenario - prices/orders divergence is primary
  signalHierarchy.primary = {
    signal: 'New Orders + Prices Divergence',
    description: `Demand weak (New Orders ${mfg.newOrders}) while costs sticky (Prices ${mfg.prices})`,
    implication: 'Margin squeeze is the primary risk - this is not priced into consensus estimates',
    tradingImplication: 'Short high operating leverage, long pricing power',
  };
} else if (momChanges.newOrders?.delta > 2 && mfg.pmi < 50) {
  // Potential inflection - new orders momentum is primary
  signalHierarchy.primary = {
    signal: 'New Orders Momentum Shift',
    description: `New Orders improved ${momChanges.newOrders.delta.toFixed(1)} points while PMI still contracting`,
    implication: 'Leading indicator diverging from headline - potential inflection ahead',
    tradingImplication: 'Begin building watchlist for early-cycle names',
  };
} else if (mfg.employment < 45) {
  // Labor capitulation is primary
  signalHierarchy.primary = {
    signal: 'Employment Capitulation',
    description: `Employment at ${mfg.employment} indicates aggressive workforce reductions`,
    implication: 'Companies have moved past "wait and see" into defensive mode',
    tradingImplication: 'Favor lean operators, avoid labor-intensive names',
  };
} else {
  signalHierarchy.primary = {
    signal: 'PMI Direction',
    description: `PMI at ${mfg.pmi} ${momChanges.pmi?.delta > 0 ? 'improving' : 'deteriorating'}`,
    implication: 'No single component dominating - watch for emerging signal',
    tradingImplication: 'Maintain current positioning pending clearer signal',
  };
}

// CONFIRMATION signals
if (mfg.employment < 48) {
  signalHierarchy.confirmation.push({
    signal: 'Employment Contraction',
    value: mfg.employment,
    role: 'Confirms companies are in defensive mode - supports primary thesis',
  });
}

if (mfg.backlog && mfg.backlog < 45) {
  signalHierarchy.confirmation.push({
    signal: 'Backlog Depletion',
    value: mfg.backlog,
    role: 'Confirms poor forward visibility - earnings risk skewed negative',
  });
}

if (momChanges.prices?.delta > 1 && mfg.pmi < 50) {
  signalHierarchy.confirmation.push({
    signal: 'Prices Acceleration in Contraction',
    value: mfg.prices,
    role: 'Confirms stagflationary pressure - margin compression accelerating',
  });
}

// NOISE - things that look important but are less predictive
signalHierarchy.noise.push({
  signal: 'PMI Headline',
  value: mfg.pmi,
  reason: 'Headline is a lagging composite; components tell the real story',
});

if (Math.abs(momChanges.production?.delta || 0) < 1.5) {
  signalHierarchy.noise.push({
    signal: 'Production',
    value: mfg.production,
    reason: 'Small moves in production are noise; focus on orders and employment',
  });
}

return {
  success: true,
  data: {
    gaps,
    signalHierarchy,  // ADD THIS
    gapCount: gaps.length,
    criticalGap: gaps[0] || null,
    hasStagflation: gaps.some(g => g.id === 'stagflation_gap'),
    overallAssessment: gaps.filter(g => g.severity === 'high').length >= 2
      ? 'Multiple significant divergences warrant caution.'
      : gaps.length > 0
        ? 'Notable divergences require selective positioning.'
        : 'Components relatively aligned with headline.',
  },
  duration: Date.now() - startTime,
};
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 5: Narrative Architect
// ============================================

async function executeNarrativeArchitect(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const regime = context.results.macro_regime_detector;
    const gaps = context.results.gap_analyzer;
    
    if (!ismData || !regime) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    
    const narrative = await callOpenAI(
  `Write a 4-paragraph institutional macro narrative for ISM Manufacturing.

STRUCTURE:
1. MACRO FRAME: Start with the external context - where are we in the Fed cycle, 
   what is the current inflation regime, where are we in the earnings season. 
   This paragraph sets up WHY this ISM matters NOW, not just what it shows.
   Example opening: "This ISM matters now because the market is still pricing 
   normalization, while the data suggests margin stress is becoming structural."

2. HEADLINE: What the data shows (with numbers woven in)

3. CONTEXT: What this means for the cycle (include "This matters because")

4. MISPRICING: What the market is getting wrong - the gap between narrative and data. 
   This is where the edge comes from. End with a clear statement like: 
   "The market is positioned for X; the ISM argues for Y."

Use connected prose. No bullets. No tables. Integrate specific numbers naturally.`,
      
      `Write macro narrative for this ISM data:

Regime: ${regime.regimeLabel}
Risk Level: ${regime.riskLevel}
Direction: ${regime.direction}

ISM Data:
- PMI: ${mfg.pmi} (Previous: ${ismData.priorMonth?.pmi || 'N/A'}, Delta: ${momChanges.pmi?.delta || 'N/A'})
- New Orders: ${mfg.newOrders}
- Production: ${mfg.production}
- Employment: ${mfg.employment}
- Prices: ${mfg.prices}
- Backlog: ${mfg.backlog}

Key Divergence: ${gaps?.criticalGap?.type || 'None'}
Critical Observation: ${regime.criticalObservation}

Return JSON:
{
  "headline": "<opening sentence capturing the key message>",
  "narrative": "<3 connected paragraphs, institutional tone, numbers woven in, includes 'This matters because' and 'We favor X over Y because'>",
  "bottomLine": "<single sentence - the one thing investors must know>",
  "keyRisks": ["<risk 1>", "<risk 2>", "<risk 3>"],
  "positioningBias": "defensive|neutral|constructive"
}`,
      { parseJSON: true, temperature: 0.25 }
    );

    if (narrative) {
      return {
        success: true,
        data: {
          ...narrative,
          regimeCode: regime.regimeCode,
          regimeLabel: regime.regimeLabel,
          riskLevel: regime.riskLevel,
          criticalObservation: regime.criticalObservation,
        },
        duration: Date.now() - startTime,
      };
    }

    // Fallback narrative
    const isContraction = mfg.pmi < 50;
    return {
      success: true,
      data: {
        headline: `Manufacturing ${isContraction ? 'contracts' : 'expands'} at ${mfg.pmi}, signaling ${regime.regimeLabel}.`,
        narrative: `The ISM Manufacturing PMI registered ${mfg.pmi}, ${isContraction ? 'indicating continued contraction' : 'signaling expansion'} in the manufacturing sector. ${regime.criticalObservation || ''} This matters because the composition of the reading—not just the headline—drives sector allocation decisions. We favor ${isContraction ? 'defensives over cyclicals' : 'quality cyclicals over pure defensives'} because ${isContraction ? 'earnings risk is skewed negative for high operating leverage names' : 'operating leverage will amplify earnings growth'}.`,
        bottomLine: `${isContraction ? 'Defensive positioning with quality focus remains appropriate.' : 'Measured cyclical exposure through quality names.'}`,
        keyRisks: isContraction 
          ? ['Contraction deepens if New Orders deteriorates', 'Margin compression if Prices remain elevated', 'Consumer contagion from Employment weakness']
          : ['Expansion falters if New Orders decelerates', 'Inflation re-acceleration', 'Fed policy surprise'],
        positioningBias: isContraction ? 'defensive' : 'constructive',
        regimeCode: regime.regimeCode,
        regimeLabel: regime.regimeLabel,
        riskLevel: regime.riskLevel,
        criticalObservation: regime.criticalObservation,
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 6: Fed & Earnings Analyzer (NEW)
// ============================================

async function executeFedEarningsAnalyzer(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const narrative = context.results.narrative_architect;
    
    if (!ismData || !narrative) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    
    const analysis = await callOpenAI(
      `Analyze ISM Manufacturing data for Federal Reserve policy implications and corporate earnings sensitivity.

REQUIREMENTS:
1. How will the FOMC interpret this data?
2. What does this mean for rate expectations?
3. Which company archetypes face earnings pressure?
4. Which benefit from current conditions?

Use "This matters because" to explain significance.`,
      
      `Analyze Fed and earnings implications:

ISM Data:
- PMI: ${mfg.pmi} (Previous: ${ismData.priorMonth?.pmi || 'N/A'})
- Employment: ${mfg.employment}
- Prices: ${mfg.prices}
- New Orders: ${mfg.newOrders}

Regime: ${narrative.regimeLabel}
Risk Level: ${narrative.riskLevel}

Return JSON:
{
  "fedInterpretation": "<3-4 sentences on how Fed will read this, include 'This matters because'>",
  "rateImplications": "<what this means for rate expectations>",
  "policyBias": "hawkish|neutral|dovish|uncertain",
  "earningsRiskAssessment": "<2-3 sentences on earnings sensitivity>",
  "vulnerableArchetypes": [
    {
      "archetype": "<company type>",
      "whyVulnerable": "<reason tied to ISM>",
      "examples": ["STOCK1", "STOCK2"]
    }
  ],
  "beneficiaryArchetypes": [
    {
      "archetype": "<company type>",
      "whyBenefiting": "<reason tied to ISM>",
      "examples": ["STOCK1", "STOCK2"]
    }
  ],
  "keyQuestion": "<the question investors should be asking>"
}`,
      { parseJSON: true, temperature: 0.2 }
    );

    if (analysis) {
      return {
        success: true,
        data: analysis,
        duration: Date.now() - startTime,
      };
    }

    // Fallback
    const isContraction = mfg.pmi < 50;
    const isStagflation = isContraction && mfg.prices > 55;
    
    return {
      success: true,
      data: {
        fedInterpretation: isStagflation
          ? `This print creates a dilemma for the FOMC. Manufacturing weakness at PMI ${mfg.pmi} argues for accommodation, but Prices at ${mfg.prices} keeps inflation concerns alive. This matters because the Fed cannot cut into persistent inflation.`
          : isContraction
            ? `This print supports the case for eventual rate cuts. PMI at ${mfg.pmi} with Employment at ${mfg.employment} signals meaningful weakness. This matters because labor market softening is a Fed priority.`
            : `This print gives the Fed cover to maintain current policy. Manufacturing expansion at ${mfg.pmi} is consistent with soft landing. This matters because there is no urgency to cut.`,
        rateImplications: isStagflation 
          ? 'Higher for longer bias persists. Cuts unlikely until inflation clearly recedes.'
          : isContraction
            ? 'Market pricing for cuts may be appropriate, though timing remains uncertain.'
            : 'Stable rate expectations. No forced moves in either direction.',
        policyBias: isStagflation ? 'uncertain' : isContraction ? 'dovish' : 'neutral',
        earningsRiskAssessment: isContraction
          ? `Companies with high operating leverage face amplified earnings risk. Fixed costs as percentage of revenue rise as volumes decline. Expect negative revisions.`
          : `Operating leverage works in reverse—margin expansion as volumes rise. Positive revision cycle possible.`,
        vulnerableArchetypes: isContraction ? [
          { archetype: 'High operating leverage manufacturers', whyVulnerable: `Fixed costs amplify weakness at PMI ${mfg.pmi}`, examples: ['CAT', 'DE'] },
          { archetype: 'Labor-intensive assemblers', whyVulnerable: `Employment at ${mfg.employment} signals cuts`, examples: ['FDX', 'UPS'] },
        ] : [],
        beneficiaryArchetypes: isContraction ? [
          { archetype: 'Pricing power defensives', whyBenefiting: 'Can pass through costs despite weak demand', examples: ['PG', 'KO'] },
          { archetype: 'Quality defensives', whyBenefiting: 'Earnings stability premium', examples: ['JNJ', 'MSFT'] },
        ] : [
          { archetype: 'Cyclical industrials', whyBenefiting: 'Operating leverage on volume recovery', examples: ['CAT', 'HON'] },
        ],
        keyQuestion: isContraction 
          ? 'Are we approaching an inflection point, or will weakness persist?'
          : 'Is this expansion sustainable, or are we late cycle?',
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 7-8: Trend Scanner & Pressure Mapper
// (Keeping existing implementations but enhanced)
// ============================================

async function executePersistentTrendScanner(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const historical = context.results.historical_context_builder;
    
    if (!ismData) {
      return { success: false, error: 'No ISM data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    const trends = [];
    const redFlags = [];
    
    // Check PMI trend
    if (mfg.pmi < 50 && (historical?.consecutiveContractionMonths || 0) >= 3) {
      trends.push({
        indicator: 'PMI Contraction',
        months: historical.consecutiveContractionMonths,
        description: `Manufacturing contracted for ${historical.consecutiveContractionMonths} consecutive months. This matters because duration of 6+ months historically correlates with earnings recession in industrials.`,
        signal: 'persistent_weakness',
      });
      if (historical.consecutiveContractionMonths >= 6) {
        redFlags.push('Extended contraction typically triggers meaningful earnings revisions');
      }
    }

    // Check Employment trend
    if (mfg.employment < 48) {
      trends.push({
        indicator: 'Employment Weakness',
        value: mfg.employment,
        description: `Employment at ${mfg.employment} indicates accelerating workforce reductions. This matters because labor cuts at this pace precede broader economic weakness.`,
        signal: 'late_cycle',
      });
      redFlags.push(`Employment at ${mfg.employment} signals defensive corporate behavior`);
    }

    // Check Prices persistence
    if (mfg.prices > 55 && mfg.pmi < 50) {
      trends.push({
        indicator: 'Stagflation Risk',
        value: mfg.prices,
        description: `Prices at ${mfg.prices} with PMI at ${mfg.pmi} creates stagflationary pressure. This matters because margin compression will be worse than consensus.`,
        signal: 'stagflation_risk',
      });
      redFlags.push('Stagflationary conditions are worst-case for manufacturers');
    }

    // Check New Orders leading
    if (momChanges.newOrders?.delta > 1.5 && mfg.pmi < 50) {
      trends.push({
        indicator: 'New Orders Leading',
        delta: momChanges.newOrders.delta,
        description: `New Orders improved by ${momChanges.newOrders.delta} points. This matters because New Orders is a leading indicator—this may signal inflection.`,
        signal: 'potential_turn',
      });
    }

    return {
      success: true,
      data: {
        persistentTrends: trends,
        redFlags,
        trendCount: trends.length,
        redFlagCount: redFlags.length,
        overallSignal: redFlags.length >= 2 ? 'warning' : trends.length > 0 ? 'caution' : 'stable',
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

async function executeStructuralPressureMapper(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    
    if (!ismData) {
      return { success: false, error: 'No ISM data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const pressures = [];
    const tailwinds = [];

    // Headwinds
    if (mfg.prices > 52) {
      pressures.push({
        type: 'Input Cost Inflation',
        severity: mfg.prices > 58 ? 'high' : mfg.prices > 55 ? 'moderate' : 'low',
        indicator: `Prices at ${mfg.prices}`,
        description: `Input costs ${mfg.prices > 55 ? 'significantly elevated' : 'above trend'}. This matters because companies without pricing power face margin compression.`,
      });
    }

    if (mfg.employment < 50) {
      pressures.push({
        type: 'Labor Market Contraction',
        severity: mfg.employment < 45 ? 'high' : mfg.employment < 48 ? 'moderate' : 'low',
        indicator: `Employment at ${mfg.employment}`,
        description: mfg.employment < 45 
          ? `Severe workforce reductions underway. This matters because cuts at this pace signal preparation for extended weakness.`
          : `Workforce reductions continuing. This matters because companies have moved past "wait and see" into defensive mode.`,
      });
    }

    if (mfg.newOrders < 50) {
      pressures.push({
        type: 'Demand Weakness',
        severity: mfg.newOrders < 45 ? 'high' : mfg.newOrders < 48 ? 'moderate' : 'low',
        indicator: `New Orders at ${mfg.newOrders}`,
        description: `Incoming orders contracting. This matters because New Orders leads PMI by 2-3 months.`,
      });
    }

    // Tailwinds
    if (mfg.newOrders > 50 && mfg.pmi < 50) {
      tailwinds.push({
        type: 'Demand Recovery Signal',
        strength: 'high',
        indicator: `New Orders at ${mfg.newOrders} diverging from PMI at ${mfg.pmi}`,
        description: `New Orders expanding despite headline contraction. This matters because this divergence often precedes PMI recovery.`,
      });
    }

    if (ismData.manufacturing.supplierDeliveries && ismData.manufacturing.supplierDeliveries < 52) {
      tailwinds.push({
        type: 'Supply Chain Normalization',
        strength: 'moderate',
        indicator: `Supplier Deliveries at ${mfg.supplierDeliveries}`,
        description: `Supply chain bottlenecks have eased. This matters because lead time reductions improve operational efficiency.`,
      });
    }

    return {
      success: true,
      data: {
        pressures,
        tailwinds,
        netAssessment: pressures.length > tailwinds.length ? 'headwinds_dominant' : 
                       tailwinds.length > pressures.length ? 'tailwinds_dominant' : 'balanced',
        highSeverityPressures: pressures.filter(p => p.severity === 'high').length,
        totalPressures: pressures.length,
        totalTailwinds: tailwinds.length,
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 9: Sector Impact Scorer (Enhanced)
// ============================================

async function executeSectorImpactScorer(context) {
  const startTime = Date.now();
  const storage = getQuoteStorage();  // ★ הוסף שורה זו
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const narrative = context.results.narrative_architect;
    const trends = context.results.persistent_trend_scanner;
    const quoteAnalysis = context.results.quote_analyzer;  // ★ הוסף שורה זו
    const reportMonth = context.reportMonth;  // ★ הוסף שורה זו
    const reportId = context.reportId;  // ★ NEW: Extract reportId for DB storage
    
    if (!ismData) {
      return { success: false, error: 'No ISM data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    
    // ★ הוסף שורה זו:
    const quotes = quoteAnalysis?.quotes || ismData.respondentComments || [];

    
    const sectorAnalysis = await callOpenAI(
      `You are a senior equity sector strategist analyzing how ISM Manufacturing data creates winners and losers.

REQUIREMENTS:
1. Rank exactly 6 sectors from MOST to LEAST favorable
2. For each sector: cite EXACT ISM numbers
3. Include "changeVsLastMonth" based on component deltas
4. Include "whyNow" explaining urgency
5. Use "This matters because" in reasoning`,
      
      `Rank these 6 sectors based on ISM Manufacturing data:

PMI: ${mfg.pmi} (Delta: ${momChanges.pmi?.delta || 'N/A'})
New Orders: ${mfg.newOrders} (Delta: ${momChanges.newOrders?.delta || 'N/A'})
Production: ${mfg.production}
Employment: ${mfg.employment} (Delta: ${momChanges.employment?.delta || 'N/A'})
Prices: ${mfg.prices}
Backlog: ${mfg.backlog}

Sectors to rank:
1. Technology (XLK)
2. Consumer Staples (XLP)
3. Industrials/Machinery (XLI)
4. Healthcare (XLV)
5. Materials (XLB)
6. Consumer Discretionary (XLY)

Regime: ${narrative?.regimeLabel || 'Unknown'}

★ AVAILABLE ISM QUOTES - Use these VERBATIM for quoteSupport field:
${quotes.slice(0, 12).map((q, i) => `${i+1}. [${q.industry}]: "${q.comment || q.originalQuote || q.text}"`).join('\n')}

Return JSON array:
[
  {
    "rank": 1,
    "sectorId": "<sector_id>",
    "sector": "<full name>",
    "impactScore": <1-10>,
    "direction": "positive|neutral|negative",
    "reasoning": "<3-4 sentences with ISM numbers and 'This matters because'>",
    "keyDriver": "<ISM component>",
    "keyDriverValue": <value>,
    "changeVsLastMonth": "improving|stable|deteriorating",
    "whyNow": "<why this positioning is urgent>",
    "etf": "<ETF>",
    "keyStocks": ["STOCK1", "STOCK2", "STOCK3"],

        "quoteSupport": "<★ EXACT verbatim quote from AVAILABLE ISM QUOTES list>",
    "quoteSupportIndustry": "<which industry the quote came from>",
    
    "timingStatus": {
      "positioning": "early|consensus|crowded|capitulation",
      "positioningRationale": "<why this timing assessment>",
      "valuationRisk": "low|moderate|elevated",
      "crowdingIndicator": "<fund flows, positioning data, or sentiment>",
      "asymmetry": "<upside vs downside assessment - e.g. '3:1 upside' or 'risk/reward poor'>"
    },
    "tradeTiming": {
      "action": "add_now|scale_in|wait_for_confirmation|reduce",
      "trigger": "<what would trigger action if not now>",
      "urgency": "immediate|next_2_weeks|next_month|patient"
    },
    "riskIfWrong": "<what happens to this sector if our ISM thesis is wrong>"
  }
]`,
      { parseJSON: true, temperature: 0.25 }
    );

if (sectorAnalysis && Array.isArray(sectorAnalysis) && sectorAnalysis.length >= 4) {
      const sorted = sectorAnalysis.sort((a, b) => b.impactScore - a.impactScore);
      sorted.forEach((s, i) => s.rank = i + 1);
      
      // ★★★ Store to database ★★★
      if (reportMonth && storage && reportId) {
        try {
          await storage.saveSectorRankings(reportId, reportMonth, sorted);
          console.log(`[SectorImpactScorer] ✓ Stored ${sorted.length} sectors to DB`);
        } catch (dbError) {
          console.error(`[SectorImpactScorer] DB storage failed: ${dbError.message}`);
        }
      }
      
      return {
        success: true,
        data: {
          sectors: sorted,
          rankings: sorted,
          topPick: sorted[0],
          bottomPick: sorted[sorted.length - 1],
          sectorCount: sorted.length,
          spread: sorted[0].impactScore - sorted[sorted.length - 1].impactScore,
          recommendation: `We favor ${sorted[0].sector} over ${sorted[sorted.length - 1].sector} because ISM dynamics specifically support this rotation.`,
        },
        duration: Date.now() - startTime,
      };
    }

// Fallback (keeping existing logic but enhanced)
    const isContraction = mfg.pmi < 50;
    const isPricesHigh = mfg.prices > 55;
    
    // Helper to find quote for sector
    const findQuoteForSector = (sectorName) => {
      const keywordMap = {
        'Consumer Staples': ['food', 'beverage', 'tobacco'],
        'Technology': ['computer', 'electronic', 'semiconductor'],
        'Industrials': ['machinery', 'transportation', 'equipment'],
        'Healthcare': ['pharmaceutical', 'medical'],
        'Materials': ['chemical', 'metal', 'paper', 'plastics'],
        'Consumer Discretionary': ['apparel', 'furniture', 'textile'],
      };
      const keywords = keywordMap[sectorName] || [];
      for (const kw of keywords) {
        const match = quotes.find(q => (q.industry || '').toLowerCase().includes(kw));
        if (match) {
          return {
            quoteSupport: match.comment || match.originalQuote || match.text,
            quoteSupportIndustry: match.industry,
          };
        }
      }
      return { quoteSupport: null, quoteSupportIndustry: null };
    };
    
    const fallbackSectors = [
      {
        rank: isContraction ? 1 : 4,
        sectorId: 'staples',
        sector: 'Consumer Staples',
        impactScore: isContraction ? 8.0 : 5.0,
        direction: isContraction ? 'positive' : 'neutral',
        reasoning: isContraction 
          ? `In contraction with PMI at ${mfg.pmi}, defensive sectors with inelastic demand outperform. This matters because staples can pass through costs while maintaining volumes.`
          : `In expansion, staples underperform cyclicals relatively. This matters because opportunity cost of defensive positioning rises.`,
        keyDriver: 'prices',
        keyDriverValue: mfg.prices,
        changeVsLastMonth: 'stable',
        whyNow: isContraction ? 'Defensive rotation accelerates as earnings risk rises' : 'Relative value diminishes in expansion',
        etf: 'XLP',
        keyStocks: ['PG', 'KO', 'PEP'],
        ...findQuoteForSector('Consumer Staples'),
      },
      {
        rank: isContraction ? 2 : 2,
        sectorId: 'technology',
        sector: 'Technology',
        impactScore: 6.5,
        direction: 'neutral',
        reasoning: `Technology is mixed. New Orders at ${mfg.newOrders} signals CapEx uncertainty broadly, but secular AI demand provides offset. This matters because stock selection within tech is critical.`,
        keyDriver: 'newOrders',
        keyDriverValue: mfg.newOrders,
        changeVsLastMonth: 'stable',
        whyNow: 'Secular vs cyclical split widens',
        etf: 'XLK',
        keyStocks: ['NVDA', 'MSFT', 'AAPL'],
      },
      {
        rank: isContraction ? 3 : 1,
        sectorId: 'industrials',
        sector: 'Industrials',
        impactScore: isContraction ? 4.0 : 7.5,
        direction: isContraction ? 'negative' : 'positive',
        reasoning: isContraction
          ? `Industrials directly exposed to manufacturing weakness. Backlog at ${mfg.backlog || 45} signals poor visibility. This matters because backlog depletion leads earnings cuts by 1-2 quarters.`
          : `Industrials benefit from expansion. New Orders at ${mfg.newOrders} supports equipment demand. This matters because operating leverage amplifies upside.`,
        keyDriver: 'backlog',
        keyDriverValue: mfg.backlog || 45,
        changeVsLastMonth: isContraction ? 'deteriorating' : 'improving',
        whyNow: isContraction ? 'Backlog deterioration not yet in consensus' : 'Earnings revisions turning positive',
        etf: 'XLI',
        keyStocks: ['CAT', 'DE', 'HON'],
      },
      {
        rank: isContraction ? 4 : 3,
        sectorId: 'healthcare',
        sector: 'Healthcare',
        impactScore: isContraction ? 7.0 : 5.5,
        direction: isContraction ? 'positive' : 'neutral',
        reasoning: isContraction
          ? `Healthcare provides defensive ballast with inelastic demand. Employment at ${mfg.employment} suggests broader caution warranted. This matters because healthcare outperforms in late cycle.`
          : `Healthcare underperforms cyclicals in expansion. This matters because opportunity cost rises.`,
        keyDriver: 'employment',
        keyDriverValue: mfg.employment,
        changeVsLastMonth: 'stable',
        whyNow: isContraction ? 'Late-cycle positioning' : 'Reduced relative attraction',
        etf: 'XLV',
        keyStocks: ['UNH', 'JNJ', 'LLY'],
      },
      {
        rank: isContraction ? 5 : 5,
        sectorId: 'materials',
        sector: 'Materials',
        impactScore: isContraction ? 3.5 : 6.0,
        direction: isContraction ? 'negative' : 'neutral',
        reasoning: isContraction
          ? `Materials highly cyclical and commodity-exposed. PMI at ${mfg.pmi} directly impacts demand. This matters because materials typically leads industrial cycle lower.`
          : `Materials benefits from activity but commodity volatility persists. This matters because stock selection critical.`,
        keyDriver: 'pmi',
        keyDriverValue: mfg.pmi,
        changeVsLastMonth: 'deteriorating',
        whyNow: isContraction ? 'Avoid until stabilization' : 'Selective exposure only',
        etf: 'XLB',
        keyStocks: ['LIN', 'FCX', 'DOW'],
      },
      {
        rank: 6,
        sectorId: 'discretionary',
        sector: 'Consumer Discretionary',
        impactScore: isContraction && isPricesHigh ? 2.5 : isContraction ? 3.5 : 5.0,
        direction: 'negative',
        reasoning: isContraction
          ? `Discretionary faces dual headwinds. Prices at ${mfg.prices} squeezes consumers while Employment at ${mfg.employment} undermines confidence. This matters because margin and revenue both at risk.`
          : `Discretionary mixed in expansion. Valuation sensitivity high. This matters because late-cycle risk persists.`,
        keyDriver: 'employment',
        keyDriverValue: mfg.employment,
        changeVsLastMonth: 'deteriorating',
        whyNow: 'Consumer spending at risk',
        etf: 'XLY',
        keyStocks: ['AMZN', 'HD', 'MCD'],
      },
    ];
    
fallbackSectors.sort((a, b) => b.impactScore - a.impactScore);
    fallbackSectors.forEach((s, i) => s.rank = i + 1);
    
    // ★★★ Store fallback to database too ★★★
    if (reportMonth && storage && reportId) {
      try {
        await storage.saveSectorRankings(reportId, reportMonth, fallbackSectors);
        console.log(`[SectorImpactScorer] ✓ Stored ${fallbackSectors.length} fallback sectors to DB`);
      } catch (dbError) {
        console.error(`[SectorImpactScorer] Fallback DB storage failed: ${dbError.message}`);
      }
    }
    
    return {
      success: true,
      data: {
        sectors: fallbackSectors,
        rankings: fallbackSectors,
        topPick: fallbackSectors[0],
        bottomPick: fallbackSectors[fallbackSectors.length - 1],
        sectorCount: fallbackSectors.length,
        spread: fallbackSectors[0].impactScore - fallbackSectors[fallbackSectors.length - 1].impactScore,
        recommendation: `We favor ${fallbackSectors[0].sector} over ${fallbackSectors[fallbackSectors.length - 1].sector} because ISM dynamics support this rotation.`,
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 10: Quote Analyzer (v9.1 - Preserves Original Quotes)
// ============================================
// CRITICAL: This agent MUST preserve the original quote text verbatim.
// The quotes come from ISM website via Perplexity and should NOT be rewritten.
// Only add analysis metadata - never modify the quote text itself.
// ============================================

async function executeQuoteAnalyzer(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const sectors = context.results.sector_impact_scorer;
    
    if (!ismData) {
      return { success: false, error: 'No ISM data', duration: Date.now() - startTime };
    }

    const realQuotes = ismData.respondentComments || [];
    
    if (realQuotes.length === 0) {
      console.log('[Quote Analyzer] No real quotes available from ISM data');
      console.log('[Quote Analyzer] NOTE: Quotes should come from Perplexity web search of ismworld.org');
      return {
        success: true,
        data: {
          quotes: [],
          quoteCount: 0,
          overallSentiment: 'unavailable',
          keyThemes: [],
          summaryInsight: 'Real industry quotes not available for this period. Check Perplexity API citation results.',
          dataSource: 'No quotes from ISM website',
        },
        duration: Date.now() - startTime,
      };
    }
    
    console.log(`[Quote Analyzer] Processing ${realQuotes.length} REAL quotes from ISM website`);
    console.log(`[Quote Analyzer] Quote industries: ${realQuotes.map(q => q.industry).join(', ')}`);
    
    // v9.1: Process quotes WITHOUT sending to OpenAI for rewriting
    // Only add classification metadata locally
    const processedQuotes = realQuotes.slice(0, 10).map((q, idx) => {
      const comment = q.comment || q.text || q.quote || '';
      const industry = q.industry || q.sector || 'Manufacturing';
      const lowerComment = comment.toLowerCase();
      
      // Local classification - no AI rewriting
      let leadingOrLagging = 'contemporaneous';
      let keyTheme = 'general';
      let sentiment = q.sentiment || 'neutral';
      
      // Determine leading vs lagging
      if (lowerComment.includes('order') || lowerComment.includes('demand') || 
          lowerComment.includes('customer') || lowerComment.includes('backlog') ||
          lowerComment.includes('inquir')) {
        leadingOrLagging = 'leading';
      } else if (lowerComment.includes('employ') || lowerComment.includes('staff') ||
                 lowerComment.includes('layoff') || lowerComment.includes('cut') ||
                 lowerComment.includes('production')) {
        leadingOrLagging = 'lagging';
      }
      
      // Determine key theme
      if (lowerComment.includes('tariff') || lowerComment.includes('trade')) {
        keyTheme = 'tariffs';
      } else if (lowerComment.includes('price') || lowerComment.includes('cost') || lowerComment.includes('margin')) {
        keyTheme = 'pricing';
      } else if (lowerComment.includes('demand') || lowerComment.includes('order')) {
        keyTheme = 'demand';
      } else if (lowerComment.includes('supply') || lowerComment.includes('supplier') || lowerComment.includes('lead time')) {
        keyTheme = 'supply_chain';
      } else if (lowerComment.includes('employ') || lowerComment.includes('labor') || lowerComment.includes('worker')) {
        keyTheme = 'labor';
      } else if (lowerComment.includes('inventory') || lowerComment.includes('stock')) {
        keyTheme = 'inventory';
      }
      
      // Determine sentiment from keywords
      if (lowerComment.includes('strong') || lowerComment.includes('growing') || 
          lowerComment.includes('improving') || lowerComment.includes('positive') ||
          lowerComment.includes('stable') || lowerComment.includes('solid')) {
        sentiment = 'positive';
      } else if (lowerComment.includes('weak') || lowerComment.includes('declining') ||
                 lowerComment.includes('uncertain') || lowerComment.includes('pressure') ||
                 lowerComment.includes('difficult') || lowerComment.includes('concern')) {
        sentiment = 'negative';
      }
      
      return {
        // PRESERVE ORIGINAL QUOTE VERBATIM
        industry: industry,
        sector: industry,
        originalQuote: comment,  // EXACT original text
        quote: comment,          // EXACT original text
        comment: comment,        // EXACT original text
        text: comment,           // EXACT original text
        
        // Analysis metadata (computed locally, not AI-generated)
        sentiment: sentiment,
        leadingOrLagging: leadingOrLagging,
        classification: leadingOrLagging === 'leading' ? 'leading' : leadingOrLagging === 'lagging' ? 'lagging' : 'contemporaneous',
        type: leadingOrLagging,
        keyTheme: keyTheme,
        signalStrength: 'moderate',
        
        // Flag that this is a real ISM quote
        isVerified: true,
        source: 'ISM Manufacturing Report - What Respondents Are Saying',
      };
    });
    
    // Calculate summary stats
    const sentiments = processedQuotes.map(q => q.sentiment);
    const positiveCount = sentiments.filter(s => s === 'positive').length;
    const negativeCount = sentiments.filter(s => s === 'negative').length;
    const leadingCount = processedQuotes.filter(q => q.leadingOrLagging === 'leading').length;
    const laggingCount = processedQuotes.filter(q => q.leadingOrLagging === 'lagging').length;
    
    let overallSentiment = 'mixed';
    if (positiveCount > negativeCount * 1.5) overallSentiment = 'positive';
    else if (negativeCount > positiveCount * 1.5) overallSentiment = 'negative';
    else if (positiveCount === 0 && negativeCount === 0) overallSentiment = 'neutral';
    
    // Extract key themes
    const themeCounts = {};
    processedQuotes.forEach(q => {
      themeCounts[q.keyTheme] = (themeCounts[q.keyTheme] || 0) + 1;
    });
    const keyThemes = Object.entries(themeCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([theme]) => theme);
    
    console.log(`[Quote Analyzer] Processed ${processedQuotes.length} quotes`);
    console.log(`[Quote Analyzer] Sentiment: ${overallSentiment} (${positiveCount} positive, ${negativeCount} negative)`);
    console.log(`[Quote Analyzer] Leading: ${leadingCount}, Lagging: ${laggingCount}`);
    
    return {
      success: true,
      data: {
        quotes: processedQuotes,
        analyzed: processedQuotes,
        quoteCount: processedQuotes.length,
        overallSentiment: overallSentiment,
        keyThemes: keyThemes,
        leadingSignalCount: leadingCount,
        laggingSignalCount: laggingCount,
        summaryInsight: `Industry executives report ${overallSentiment} conditions. ${leadingCount} comments reflect forward-looking demand signals, ${laggingCount} reflect lagging operational adjustments.`,
        dataSource: 'Real ISM Respondent Comments - Verbatim',
        isVerifiedFromISM: true,
      },
      duration: Date.now() - startTime,
    };
    
  } catch (error) {
    console.error('[Quote Analyzer] Error:', error.message);
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 11: Equity Criteria Builder
// ============================================

async function executeEquityCriteriaBuilder(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const narrative = context.results.narrative_architect;
    const sectors = context.results.sector_impact_scorer;
    
    if (!narrative || !ismData) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const isContraction = mfg.pmi < 50;
    const isPricesHigh = mfg.prices > 55;
    
    const criteria = await callOpenAI(
      `Define stock selection criteria based on ISM Manufacturing conditions.

Each criterion must:
1. Connect directly to a specific ISM reading
2. Explain WHY this matters NOW
3. Give concrete company examples

Use "This matters because" language.`,
      
      `Define stock selection criteria:

Regime: ${narrative.regimeLabel}
Risk Level: ${narrative.riskLevel}

ISM Data:
- PMI: ${mfg.pmi}
- New Orders: ${mfg.newOrders}
- Employment: ${mfg.employment}
- Prices: ${mfg.prices}
- Backlog: ${mfg.backlog}

Return JSON:
{
  "favorable": [
    {
      "characteristic": "<trait to favor>",
      "importance": "critical|high|moderate",
      "ismConnection": "<link to ISM with number>",
      "rationale": "<2 sentences with 'This matters because'>",
      "examples": ["profile1", "profile2"]
    }
  ],
  "unfavorable": [
    {
      "characteristic": "<trait to avoid>",
      "riskLevel": "high|moderate",
      "ismConnection": "<link to ISM>",
      "rationale": "<2 sentences>",
      "examples": ["profile1", "profile2"]
    }
  ]
}`,
      { parseJSON: true, temperature: 0.25 }
    );

    if (criteria) {
      return { success: true, data: criteria, duration: Date.now() - startTime };
    }

    // Fallback
    return {
      success: true,
      data: {
        favorable: [
          { 
            characteristic: isContraction ? 'Demonstrated Pricing Power' : 'Operating Leverage',
            importance: 'critical',
            ismConnection: `Prices at ${mfg.prices}`,
            rationale: isContraction 
              ? `With input costs elevated and demand weak, only companies that can pass through costs will maintain margins. This matters because margin compression will be worse than consensus.`
              : `Operating leverage amplifies earnings growth in expansion. This matters because volume recovery is underway.`,
            examples: isContraction 
              ? ['Consumer staples leaders', 'Essential healthcare products']
              : ['Industrials with high fixed costs', 'Technology with recurring revenue'],
          },
        ],
        unfavorable: [
          {
            characteristic: isContraction ? 'High Operating Leverage' : 'Commodity Input Exposure',
            riskLevel: 'high',
            ismConnection: `PMI at ${mfg.pmi}`,
            rationale: isContraction
              ? `High fixed costs accelerate margin compression when volumes decline. This matters because earnings volatility increases.`
              : `Commodity exposure creates earnings volatility even in expansion.`,
            examples: ['Heavy industrials', 'Commodity producers'],
          },
        ],
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 12: Stock Implications Generator (NEW)
// ============================================

async function executeStockImplicationsGenerator(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const sectors = context.results.sector_impact_scorer;
    const equity = context.results.equity_criteria_builder;
    
    if (!ismData || !sectors) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const isContraction = mfg.pmi < 50;
    const isPricesHigh = mfg.prices > 55;
    
    const stockAnalysis = await callOpenAI(
      `Map ISM conditions to specific stock implications.

For each category provide:
1. Stock archetype description
2. Specific ticker examples
3. Why ISM supports this view
4. What to watch

No Entry/Stop/Target levels. Focus on fundamental logic.`,
      
      `Generate stock implications:

ISM Data:
- PMI: ${mfg.pmi}
- Employment: ${mfg.employment}
- Prices: ${mfg.prices}
- New Orders: ${mfg.newOrders}

Top Sector: ${sectors.topPick?.sector} (${sectors.topPick?.etf})
Bottom Sector: ${sectors.bottomPick?.sector} (${sectors.bottomPick?.etf})

Return JSON:
{
  "outperformCandidates": [
    {
      "archetype": "<company type>",
      "tickers": ["TICK1", "TICK2", "TICK3"],
      "ismRationale": "<why ISM supports, include specific numbers>",
      "whatToWatch": "<catalyst or risk>"
    }
  ],
  "underperformCandidates": [
    {
      "archetype": "<company type>",
      "tickers": ["TICK1", "TICK2"],
      "ismRationale": "<why ISM is negative>",
      "whatToWatch": "<what would change view>"
    }
  ],
  "watchlistForTurn": [
    {
      "archetype": "<company type for potential rotation>",
      "tickers": ["TICK1", "TICK2"],
      "trigger": "<ISM condition that would trigger add>"
    }
  ]
}`,
      { parseJSON: true, temperature: 0.25 }
    );

    if (stockAnalysis) {
      return { success: true, data: stockAnalysis, duration: Date.now() - startTime };
    }

    // Fallback
    return {
      success: true,
      data: {
        outperformCandidates: isContraction ? [
          { archetype: 'Margin-protected staples', tickers: ['PG', 'KO', 'COST'], ismRationale: `Pricing power critical with Prices at ${mfg.prices}`, whatToWatch: 'Volume resilience' },
          { archetype: 'Quality defensives', tickers: ['JNJ', 'MSFT', 'V'], ismRationale: 'Earnings stability premium in contraction', whatToWatch: 'Multiple sustainability' },
        ] : [
          { archetype: 'Cyclical industrials', tickers: ['CAT', 'DE', 'HON'], ismRationale: `Operating leverage on PMI recovery at ${mfg.pmi}`, whatToWatch: 'Order book trends' },
        ],
        underperformCandidates: isContraction ? [
          { archetype: 'High operating leverage', tickers: ['X', 'NUE'], ismRationale: `Fixed costs amplify weakness at PMI ${mfg.pmi}`, whatToWatch: 'PMI sustained above 50' },
        ] : [],
        watchlistForTurn: isContraction ? [
          { archetype: 'Restocking beneficiaries', tickers: ['LIN', 'FCX', 'DOW'], trigger: 'New Orders sustained above 52 for 2 months' },
        ] : [],
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 13: Trade Idea Generator
// ============================================

async function executeTradeIdeaGenerator(context) {
  const startTime = Date.now();
  const storage = getQuoteStorage();  // ★ NEW
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const narrative = context.results.narrative_architect;
    const sectors = context.results.sector_impact_scorer;
    const equity = context.results.equity_criteria_builder;
    const gaps = context.results.gap_analyzer;
    const quoteAnalysis = context.results.quote_analyzer;  // ★ NEW
    const reportMonth = context.reportMonth;  // ★ NEW
    const reportId = context.reportId;  // ★ NEW: Extract reportId for DB storage
    
    if (!ismData || !narrative || !sectors) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const isContraction = mfg.pmi < 50;
    
    // ★ NEW: Get available quotes
    const quotes = quoteAnalysis?.quotes || ismData.respondentComments || [];

    const ideas = await callOpenAI(
      `You are a senior macro-financial analyst at a top-tier investment bank. Generate 3-4 trade ideas where each idea is DRIVEN by a specific executive quote from the ISM survey.

## YOUR ANALYTICAL FRAMEWORK
You don't just read the quote - you DECODE what the executive is really telling you:
- What operational reality is behind these words?
- What does this imply for the next 1-2 quarters?
- How does this CONTRADICT or CONFIRM the headline ISM numbers?
- Where is the market likely WRONG based on this ground-level intelligence?

## CRITICAL REQUIREMENTS
1. Each trade idea MUST start with an EXACT VERBATIM quote from the available ISM quotes
2. Your analysis must explain WHY this quote matters - what is the executive really saying?
3. Connect the quote to specific stocks with DIRECT IMPACT reasoning
4. Identify if this quote CONFIRMS the trend or is a COUNTER-TREND signal

## OUTPUT STRUCTURE FOR EACH IDEA
- executiveQuote: The EXACT verbatim quote (copy-paste from available quotes)
- executiveQuoteIndustry: Which industry said this
- quoteDecoded: What is this executive REALLY telling us? (2-3 sentences of analyst interpretation)
- thesis: The trade thesis derived from this quote
- trendContext: "CONFIRMS TREND" or "COUNTER-TREND SIGNAL" with explanation
- directImpact: Which specific stocks are affected and HOW
- conviction: high/medium/low based on quote clarity and ISM data alignment`,

      `Generate trade ideas based on executive quotes:

ISM Data Context:
- PMI: ${mfg.pmi} (${mfg.pmi >= 50 ? 'EXPANSION' : 'CONTRACTION'})
- New Orders: ${mfg.newOrders} (leading indicator)
- Employment: ${mfg.employment} (labor signal)
- Prices: ${mfg.prices} (inflation/margin signal)
- Backlog: ${mfg.backlog} (visibility signal)
- Production: ${mfg.production}

Regime: ${narrative.regimeLabel}
Primary Signal: ${gaps?.data?.signalHierarchy?.primary?.signal || 'N/A'}

Top Sector: ${sectors.topPick?.sector}
Bottom Sector: ${sectors.bottomPick?.sector}

★★★ AVAILABLE ISM EXECUTIVE QUOTES - USE THESE VERBATIM ★★★
${quotes.slice(0, 15).map((q, i) => `${i+1}. [${q.industry}]: "${q.comment || q.originalQuote || q.text}"`).join('\n')}

Return JSON array:
[
  {
    "title": "<LONG/SHORT: Industry/Sector Name>",
    "ticker": "<primary ETF>",
    "alternativeStocks": ["STOCK1", "STOCK2", "STOCK3", "STOCK4", "STOCK5"],
    "direction": "long|short",
    "sector": "<sector name>",
    
    "executiveQuote": "<★ EXACT verbatim quote from list above - THIS IS REQUIRED>",
    "executiveQuoteIndustry": "<industry of the executive>",
    
    "quoteDecoded": "<What is this executive REALLY telling us? Your analyst interpretation of the quote's deeper meaning - 2-3 sentences>",
    
    "thesis": "<The trade thesis - why this quote leads to this position - 2-3 sentences>",
    
    "trendContext": {
      "type": "CONFIRMS_TREND|COUNTER_TREND",
      "explanation": "<How does this quote relate to the overall ISM reading? Is the executive confirming what the numbers show, or revealing something different?>"
    },
    
    "directImpact": "<Which specific companies are most affected by what this executive said? Name 2-3 tickers and explain why THEY specifically>",
    
    "conviction": "high|medium|low",
    "convictionReason": "<Why this conviction level? Based on quote clarity, ISM alignment, multiple signals?>",
    
    "risks": ["<risk1>", "<risk2>"],
    "invalidation": ["<what would prove us wrong>"]
  }
]`,
      { parseJSON: true, temperature: 0.35, maxTokens: 5000 }
    );
    if (ideas && Array.isArray(ideas) && ideas.length >= 3) {
      // ★★★ NEW: Store to database ★★★
      if (reportMonth && storage && reportId) {
        try {
          await storage.saveTradeIdeas(reportId, reportMonth, ideas);
          console.log(`[TradeIdeaGenerator] ✓ Stored ${ideas.length} trade ideas to DB`);
        } catch (dbError) {
          console.error(`[TradeIdeaGenerator] DB storage failed: ${dbError.message}`);
        }
      }
      
      return {
        success: true,
        data: {
          ideas,  // ★ Now includes executiveQuote + directImpact
          longIdeas: ideas.filter(i => i.direction === 'long').length,
          shortIdeas: ideas.filter(i => i.direction === 'short').length,
          ideaCount: ideas.length,
        },
        duration: Date.now() - startTime,
      };
    }

    // Fallback with quote matching
    const fallbackIdeas = generateFallbackTradeIdeasWithQuotes(mfg, quotes, isContraction);
    
    if (reportMonth && storage && reportId) {
      try {
        await storage.saveTradeIdeas(reportId, reportMonth, fallbackIdeas);
      } catch (dbError) {
        console.error(`[TradeIdeaGenerator] Fallback DB storage failed: ${dbError.message}`);
      }
    }
    
    return {
      success: true,
      data: { ideas: fallbackIdeas, ideaCount: fallbackIdeas.length },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}
// ============================================
// AGENT 14: Practical Positioning Builder (NEW)
// ============================================

async function executePracticalPositioningBuilder(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const sectors = context.results.sector_impact_scorer;
    const trades = context.results.trade_idea_generator;
    const stocks = context.results.stock_implications_generator;
    
    if (!ismData || !sectors) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
    const isContraction = mfg.pmi < 50;
    const isPricesHigh = mfg.prices > 55;
    
    const positioning = await callOpenAI(
      `Create actionable positioning summary from ISM analysis.

REQUIREMENTS:
1. Overweight sectors with rationale
2. Underweight sectors with rationale
3. Avoid list with specific criteria
4. Watch list for rotation if conditions change
5. Example stocks for each category`,
      
      `Create positioning summary:

ISM Data:
- PMI: ${mfg.pmi}
- Employment: ${mfg.employment}
- Prices: ${mfg.prices}
- New Orders: ${mfg.newOrders}

Top Sectors: ${sectors.sectors?.slice(0,2).map(s => s.sector).join(', ') || 'N/A'}
Bottom Sectors: ${sectors.sectors?.slice(-2).map(s => s.sector).join(', ') || 'N/A'}

Return JSON:
{
  "overweight": {
    "sectors": ["sector1", "sector2"],
    "rationale": "<why overweight, tie to ISM>",
    "exampleStocks": ["TICK1", "TICK2", "TICK3"]
  },
  "underweight": {
    "sectors": ["sector1", "sector2"],
    "rationale": "<why underweight>",
    "exampleStocks": ["TICK1", "TICK2"]
  },
  "avoid": {
    "characteristics": ["trait1", "trait2"],
    "rationale": "<why avoid>",
    "exampleTypes": ["type1", "type2"]
  },
  "watchForLongs": {
    "sectors": ["sector1"],
    "trigger": "<ISM condition>",
    "exampleStocks": ["TICK1", "TICK2"]
  },
  "summaryAction": "<single sentence - what to do right now>"
}`,
      { parseJSON: true, temperature: 0.2 }
    );

    if (positioning) {
      return { success: true, data: positioning, duration: Date.now() - startTime };
    }

    // Fallback
    return {
      success: true,
      data: {
        overweight: {
          sectors: isContraction ? ['Consumer Staples', 'Healthcare', 'Quality'] : ['Industrials', 'Materials', 'Technology'],
          rationale: isContraction 
            ? `Defensive positioning with PMI at ${mfg.pmi}. This matters because earnings risk skewed negative for cyclicals.`
            : `Cyclical exposure with PMI at ${mfg.pmi}. This matters because operating leverage amplifies upside.`,
          exampleStocks: isContraction ? ['PG', 'KO', 'JNJ', 'MSFT'] : ['CAT', 'HON', 'LIN'],
        },
        underweight: {
          sectors: isContraction ? ['Machinery', 'Transportation', 'High-beta cyclicals'] : ['Utilities', 'REITs'],
          rationale: isContraction
            ? `Employment at ${mfg.employment} signals defensive corporate behavior. Avoid high operating leverage.`
            : `Opportunity cost of defensive positioning rises in expansion.`,
          exampleStocks: isContraction ? ['CAT', 'DE', 'FDX'] : ['NEE', 'D'],
        },
        avoid: {
          characteristics: isContraction 
            ? ['High inventory + low pricing power', 'Debt/EBITDA > 3x', 'Labor-intensive with union exposure']
            : ['Extreme valuations (>25x P/E)', 'Capacity constrained'],
          rationale: isContraction
            ? `These archetypes face maximum earnings risk in contraction with Prices at ${mfg.prices}.`
            : `Valuation risk rises as cycle matures.`,
          exampleTypes: isContraction ? ['Commoditized manufacturers', 'Levered cyclicals'] : ['Overvalued growth'],
        },
        watchForLongs: {
          sectors: isContraction ? ['Materials', 'Early-cycle industrials'] : [],
          trigger: 'New Orders sustained above 52 for 2 months, Employment stabilizing above 48',
          exampleStocks: ['LIN', 'FCX', 'ETN'],
        },
        summaryAction: isContraction 
          ? 'Reduce cyclical exposure. Favor quality and pricing power. Prepare watchlist for stabilization.'
          : 'Add selective cyclical exposure through quality names with earnings visibility.',
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 15: Coherence Checker
// ============================================

async function executeCoherenceChecker(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const narrative = context.results.narrative_architect;
    const sectors = context.results.sector_impact_scorer;
    const trades = context.results.trade_idea_generator;
    const positioning = context.results.practical_positioning_builder;
    
    const checks = [];

    // Check 1: Data consistency
    if (ismData?.manufacturing?.pmi) {
      checks.push({
        check: 'ISM data present',
        passed: true,
        detail: `PMI: ${ismData.manufacturing.pmi}`,
      });
    }

    // Check 2: MoM data present
    if (ismData?.momChanges) {
      checks.push({
        check: 'MoM changes calculated',
        passed: true,
        detail: `Delta: ${ismData.momChanges.pmi?.delta || 'N/A'}`,
      });
    } else {
      checks.push({
        check: 'MoM changes calculated',
        passed: false,
        detail: 'Prior month data not available',
      });
    }

    // Check 3: Narrative quality
    if (narrative?.narrative) {
      const hasImpactPhrases = narrative.narrative.includes('matters because') || 
                               narrative.narrative.includes('This matters');
      checks.push({
        check: 'Narrative uses impact language',
        passed: hasImpactPhrases,
        detail: hasImpactPhrases ? 'Contains "This matters because"' : 'Missing impact language',
      });
    }

    // Check 4: Trade ideas have invalidation
    if (trades?.ideas) {
      checks.push({
        check: 'Trade ideas have invalidation',
        passed: trades.ideas.filter(t => t.invalidation?.length > 0).length >= trades.ideas.length * 0.8,
        detail: `${trades.ideas.filter(t => t.invalidation?.length > 0).length}/${trades.ideas.length} have invalidation`,
      });
    }

    // Check 5: Practical positioning present
    if (positioning) {
      checks.push({
        check: 'Practical positioning generated',
        passed: true,
        detail: 'Overweight/Underweight/Avoid all present',
      });
    }

    // Check 6: Sector analysis comprehensive
    if (sectors?.sectors) {
      checks.push({
        check: 'Sector analysis comprehensive',
        passed: sectors.sectors.length >= 4,
        detail: `${sectors.sectors.length} sectors analyzed`,
      });
    }

    const passedCount = checks.filter(c => c.passed).length;
    const qaScore = checks.length > 0 ? Math.round((passedCount / checks.length) * 100) : 0;

    return {
      success: true,
      data: {
        checks,
        passedCount,
        totalCount: checks.length,
        qaScore,
        qaPassed: qaScore >= 70,
        grade: qaScore >= 90 ? 'A' : qaScore >= 80 ? 'B' : qaScore >= 70 ? 'C' : 'D',
        issues: checks.filter(c => !c.passed).map(c => c.detail),
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT 16: Executive Summary Writer
// ============================================

async function executeExecutiveSummaryWriter(context) {
  const startTime = Date.now();
  
  try {
    const ismData = context.results.ism_data_fetcher;
    const narrative = context.results.narrative_architect;
    const sectors = context.results.sector_impact_scorer;
    const trades = context.results.trade_idea_generator;
    const positioning = context.results.practical_positioning_builder;
    const qa = context.results.coherence_checker;
    
    if (!ismData || !narrative) {
      return { success: false, error: 'Missing required data', duration: Date.now() - startTime };
    }

    const mfg = ismData.manufacturing;
    const momChanges = ismData.momChanges || {};
const summary = await callOpenAI(
  `Write 6 key takeaways for investment managers.
The 6th point is THE MOST IMPORTANT - it identifies where the market is WRONG.

Each point must:
1. Be ONE powerful sentence
2. Include specific numbers
3. Be actionable
4. No hedging`,
  
  `Create 6 key takeaways:

PMI: ${mfg.pmi} (Delta: ${momChanges.pmi?.delta || 'N/A'})
New Orders: ${mfg.newOrders}
Employment: ${mfg.employment}
Prices: ${mfg.prices}

Regime: ${narrative.regimeLabel}
Top Sector: ${sectors?.topPick?.sector}
Overweight: ${positioning?.overweight?.sectors?.join(', ') || 'Defensives'}
Counter-thesis: ${context.results.macro_regime_detector?.alternativeInterpretation?.thesis || 'N/A'}

Return JSON:
{
  "headline": "<10-15 words - the one thing>",
  "trend": "<what direction>",
  "sectors": "<favor X over Y>",
  "risk": "<main risk>",
  "action": "<what to do>",
  
  "mispricing": {
    "whatMarketThinks": "<current consensus positioning/narrative>",
    "whatDataShows": "<what ISM actually implies>",
    "theGap": "<where the opportunity is - be specific>",
    "magnitude": "<how big is the mispricing - moderate/significant/extreme>",
    "timeToConvergence": "<when will market realize - next ISM/next earnings/next quarter>",
    "closingStatement": "<THE EDGE - one powerful sentence that the reader takes with them>"
  }
}`,
      { parseJSON: true, temperature: 0.25 }
    );

    const summaryData = summary || {
      headline: `Manufacturing ${mfg.pmi >= 50 ? 'expands' : 'contracts'} at ${mfg.pmi}, signaling ${narrative.regimeLabel}.`,
      trend: momChanges.pmi?.delta > 0 ? 'Improvement underway' : momChanges.pmi?.delta < 0 ? 'Weakness accelerating' : 'Stable conditions',
      sectors: `Favor ${sectors?.topPick?.sector || 'Defensives'} over ${sectors?.bottomPick?.sector || 'Cyclicals'}.`,
      risk: mfg.prices > 55 && mfg.pmi < 50 
        ? `Stagflation pressure with Prices at ${mfg.prices} while PMI at ${mfg.pmi}.`
        : `Demand deterioration if New Orders breaks below 45.`,
      action: positioning?.summaryAction || 'Maintain current positioning pending clearer signal.',
    };

    return {
      success: true,
      data: {
        summary: summaryData,
        fiveLines: [
          `Headline: ${summaryData.headline}`,
          `Trend: ${summaryData.trend}`,
          `Sectors: ${summaryData.sectors}`,
          `Risk: ${summaryData.risk}`,
          `Action: ${summaryData.action}`,
        ],
        qaScore: qa?.qaScore || 0,
        qaPassed: qa?.qaPassed || false,
        reportReady: true,
        generatedAt: new Date().toISOString(),
        dataSource: ismData.dataSource,
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, error: error.message, duration: Date.now() - startTime };
  }
}
function generateFallbackTradeIdeasWithQuotes(mfg, quotes, isContraction) {
  const isStagflation = mfg.pmi < 50 && mfg.prices > 55;
  
  // Helper to find quote by industry keyword
  const findQuote = (keyword) => {
    const match = quotes.find(q => 
      (q.industry || '').toLowerCase().includes(keyword.toLowerCase())
    );
    if (match) {
      return {
        executiveQuote: match.comment || match.originalQuote || match.text,
        executiveQuoteIndustry: match.industry,
      };
    }
    return { executiveQuote: null, executiveQuoteIndustry: null };
  };

  const ideas = [];
  
  if (isStagflation) {
    // LONG Consumer Staples
    const staplesQuote = findQuote('food') || findQuote('beverage');
    ideas.push({
      title: 'LONG XLP - Defensive Pricing Power',
      ticker: 'XLP',
      alternativeStocks: ['PG', 'KO', 'PEP', 'COST', 'GIS'],
      direction: 'long',
      sector: 'Consumer Staples',
      thesis: `Pricing power protects margins in stagflation. PMI at ${mfg.pmi} with Prices at ${mfg.prices} creates margin pressure across manufacturing. This matters because staples have both pricing power and inelastic demand.`,
      ismConnection: `PMI at ${mfg.pmi} with Prices at ${mfg.prices}`,
      ...staplesQuote,
      directImpact: staplesQuote.executiveQuote 
        ? 'PG, GIS exposed to input costs; KO, PEP have stronger pricing power. COST benefits from trade-down.'
        : 'PG, KO positioned for margin protection via pricing power.',
      conviction: 'high',
      invalidation: ['PMI crosses above 52', 'Prices drops below 52'],
      risks: ['Consumer trade-down to private label', 'Broad market selloff'],
    });
    
    // SHORT Machinery
    const machineryQuote = findQuote('machinery') || findQuote('transportation');
    ideas.push({
      title: 'SHORT XLI - Capex Hesitation',
      ticker: 'XLI',
      alternativeStocks: ['CAT', 'DE', 'PCAR', 'CMI'],
      direction: 'short',
      sector: 'Industrials',
      thesis: `Backlog depletion signals earnings risk. With Backlog at ${mfg.backlog || 45}, forward visibility is impaired. This matters because capex deferral hits this sector first.`,
      ismConnection: `Backlog at ${mfg.backlog || 45}, Employment at ${mfg.employment}`,
      ...machineryQuote,
      directImpact: machineryQuote.executiveQuote
        ? 'CAT, DE most exposed to capex weakness. CMI has aftermarket buffer.'
        : 'CAT, DE directly exposed to capex cycle.',
      conviction: 'high',
      invalidation: ['New Orders above 52', 'Infrastructure stimulus'],
      risks: ['Policy intervention', 'Unexpected demand recovery'],
    });
  }
  
  if (isContraction && !isStagflation) {
    // LONG Healthcare
    ideas.push({
      title: 'LONG XLV - Defensive Demand',
      ticker: 'XLV',
      alternativeStocks: ['UNH', 'JNJ', 'LLY', 'ABBV'],
      direction: 'long',
      sector: 'Healthcare',
      thesis: `Inelastic demand provides protection. Employment at ${mfg.employment} shows cost-cutting. This matters because healthcare demand persists regardless.`,
      ismConnection: `PMI at ${mfg.pmi}, Employment at ${mfg.employment}`,
      executiveQuote: null,
      directImpact: 'UNH, LLY strongest secular growth. JNJ defensive. ABBV has patent exposure.',
      conviction: 'medium',
      invalidation: ['PMI rebounds above 52'],
      risks: ['Regulatory risk', 'Multiple compression'],
    });
  }
  
  // Tech secular
  const techQuote = findQuote('computer') || findQuote('electronic');
  ideas.push({
    title: 'LONG XLK - Secular AI Demand',
    ticker: 'XLK',
    alternativeStocks: ['NVDA', 'AMD', 'AVGO', 'MSFT'],
    direction: 'long',
    sector: 'Technology',
    thesis: `AI infrastructure transcends manufacturing cycle. Even with PMI at ${mfg.pmi}, data center spend continues.`,
    ismConnection: `PMI at ${mfg.pmi}`,
    ...techQuote,
    directImpact: techQuote.executiveQuote
      ? 'NVDA, AVGO benefit from AI buildout. INTC has PC cycle exposure.'
      : 'NVDA, AVGO AI infrastructure beneficiaries.',
    conviction: 'medium',
    invalidation: ['Capex pullback', 'AI spending slowdown'],
    risks: ['Valuation compression', 'Competition'],
  });
  
  return ideas;
}

// ============================================
// EXPORTS
// ============================================

const AGENT_EXECUTORS = {
  ism_data_fetcher: executeISMDataFetcher,
  historical_context_builder: executeHistoricalContextBuilder,
  macro_regime_detector: executeMacroRegimeDetector,
  gap_analyzer: executeGapAnalyzer,
  narrative_architect: executeNarrativeArchitect,
  fed_earnings_analyzer: executeFedEarningsAnalyzer,
  persistent_trend_scanner: executePersistentTrendScanner,
  structural_pressure_mapper: executeStructuralPressureMapper,
  sector_impact_scorer: executeSectorImpactScorer,
  quote_analyzer: executeQuoteAnalyzer,
  equity_criteria_builder: executeEquityCriteriaBuilder,
  stock_implications_generator: executeStockImplicationsGenerator,
  trade_idea_generator: executeTradeIdeaGenerator,
  practical_positioning_builder: executePracticalPositioningBuilder,
  coherence_checker: executeCoherenceChecker,
  executive_summary_writer: executeExecutiveSummaryWriter,
};

const ALL_AGENTS = AGENT_DEFINITIONS.map(def => ({
  ...def,
  execute: AGENT_EXECUTORS[def.id],
}));

export {
  ALL_AGENTS,
  AGENT_DEFINITIONS,
  AGENT_EXECUTORS,
  getOpenAI,
  getQuoteStorage,  // ★ NEW
  INSTITUTIONAL_MANDATE,
  SECTOR_ETF_MAP,
  generateFallbackTradeIdeasWithQuotes,  // ★ NEW
};