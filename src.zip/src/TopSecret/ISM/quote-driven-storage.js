// =====================================================
// QUOTE-DRIVEN STORAGE v1.0
// =====================================================
// Location: src/TopSecret/ISM/quote-driven-storage.js
//
// Stores quote-derived sector rankings and trade ideas
// to database for historical reference and future use.
//
// Tables required:
// - ism_quote_derived_sectors
// - ism_quote_derived_trades
// - ism_quote_theme_analysis
// =====================================================

import { createClient } from '@supabase/supabase-js';

// ============================================
// SQL MIGRATIONS (Run these in Supabase)
// ============================================

const MIGRATION_SQL = `
-- =====================================================
-- QUOTE-DERIVED SECTOR RANKINGS TABLE
-- =====================================================
-- Stores sector rankings that were DERIVED from quote analysis
-- (not from ISM numbers directly)

CREATE TABLE IF NOT EXISTS ism_quote_derived_sectors (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id TEXT NOT NULL,
  report_month TEXT NOT NULL,
  
  -- Sector info
  sector_name TEXT NOT NULL,
  sector_etf TEXT,
  rank INTEGER NOT NULL,
  
  -- Quote-derived metrics
  impact_score DECIMAL(4,2) NOT NULL,
  direction TEXT CHECK (direction IN ('positive', 'neutral', 'negative')),
  confidence TEXT CHECK (confidence IN ('high', 'medium', 'low')),
  
  -- Quote support
  quote_count INTEGER DEFAULT 0,
  avg_sentiment DECIMAL(4,2),
  themes TEXT[], -- Array of detected themes
  supporting_quote TEXT,
  supporting_quote_industry TEXT,
  
  -- Stocks
  key_stocks TEXT[],
  
  -- Reasoning derived from quotes
  quote_derived_reasoning TEXT,
  
  -- Meta
  analysis_method TEXT DEFAULT 'quote-driven',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT unique_report_sector UNIQUE (report_id, sector_name)
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_qds_report_month ON ism_quote_derived_sectors(report_month);
CREATE INDEX IF NOT EXISTS idx_qds_sector ON ism_quote_derived_sectors(sector_name);

-- =====================================================
-- QUOTE-DERIVED TRADE IDEAS TABLE
-- =====================================================
-- Stores trade ideas that were GENERATED from quote analysis

CREATE TABLE IF NOT EXISTS ism_quote_derived_trades (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id TEXT NOT NULL,
  report_month TEXT NOT NULL,
  
  -- Trade info
  direction TEXT CHECK (direction IN ('long', 'short', 'pair')),
  title TEXT NOT NULL,
  sector TEXT NOT NULL,
  ticker TEXT,
  alternative_stocks TEXT[],
  
  -- Quote-driven thesis
  thesis TEXT NOT NULL,
  executive_quote TEXT,
  executive_quote_industry TEXT,
  direct_impact TEXT,
  
  -- Confidence and risk
  conviction TEXT CHECK (conviction IN ('high', 'medium', 'low')),
  invalidation TEXT[],
  risks TEXT[],
  
  -- Quotes that drove this idea
  driving_quotes JSONB, -- Array of {industry, excerpt, sentiment}
  themes_supporting TEXT[],
  
  -- Display
  display_order INTEGER DEFAULT 1,
  
  -- Meta
  analysis_method TEXT DEFAULT 'quote-driven',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT unique_report_trade UNIQUE (report_id, title)
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_qdt_report_month ON ism_quote_derived_trades(report_month);
CREATE INDEX IF NOT EXISTS idx_qdt_direction ON ism_quote_derived_trades(direction);

-- =====================================================
-- QUOTE THEME ANALYSIS TABLE
-- =====================================================
-- Stores the theme analysis from quotes for trend tracking

CREATE TABLE IF NOT EXISTS ism_quote_theme_analysis (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id TEXT NOT NULL,
  report_month TEXT NOT NULL,
  
  -- Theme info
  theme_name TEXT NOT NULL,
  mention_count INTEGER DEFAULT 0,
  
  -- Sentiment for this theme
  avg_sentiment DECIMAL(4,2),
  sentiment_direction TEXT CHECK (sentiment_direction IN ('positive', 'neutral', 'negative')),
  
  -- Industries mentioning this theme
  industries_mentioned TEXT[],
  
  -- Sample quotes for this theme
  sample_quotes JSONB, -- Array of {industry, excerpt}
  
  -- Meta
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT unique_report_theme UNIQUE (report_id, theme_name)
);

-- Index
CREATE INDEX IF NOT EXISTS idx_qta_report_month ON ism_quote_theme_analysis(report_month);
CREATE INDEX IF NOT EXISTS idx_qta_theme ON ism_quote_theme_analysis(theme_name);

-- =====================================================
-- VIEWS FOR EASY ACCESS
-- =====================================================

-- Latest sector rankings view
CREATE OR REPLACE VIEW v_quote_sector_rankings_latest AS
SELECT *
FROM ism_quote_derived_sectors
WHERE report_month = (
  SELECT MAX(report_month) FROM ism_quote_derived_sectors
)
ORDER BY rank ASC;

-- Latest trade ideas view
CREATE OR REPLACE VIEW v_quote_trade_ideas_latest AS
SELECT *
FROM ism_quote_derived_trades
WHERE report_month = (
  SELECT MAX(report_month) FROM ism_quote_derived_trades
)
ORDER BY display_order ASC;

-- Theme trends over time view
CREATE OR REPLACE VIEW v_theme_trends AS
SELECT 
  theme_name,
  report_month,
  mention_count,
  avg_sentiment,
  sentiment_direction
FROM ism_quote_theme_analysis
ORDER BY report_month DESC, mention_count DESC;

-- Sector ranking history view
CREATE OR REPLACE VIEW v_sector_ranking_history AS
SELECT 
  sector_name,
  report_month,
  rank,
  impact_score,
  direction,
  quote_count,
  confidence
FROM ism_quote_derived_sectors
ORDER BY report_month DESC, rank ASC;
`;

// ============================================
// QUOTE-DRIVEN STORAGE CLASS
// ============================================

class QuoteDrivenStorage {
  constructor(supabaseUrl, supabaseKey) {
    this.supabase = null;
    
    if (supabaseUrl && supabaseKey) {
      try {
        this.supabase = createClient(supabaseUrl, supabaseKey);
        console.log('[QuoteDrivenStorage] Initialized with Supabase');
      } catch (error) {
        console.warn('[QuoteDrivenStorage] Failed to initialize Supabase:', error.message);
      }
    } else {
      console.warn('[QuoteDrivenStorage] No Supabase credentials - running in offline mode');
    }
  }

  // ============================================
  // SAVE QUOTE-DERIVED SECTOR RANKINGS
  // ============================================

  async saveSectorRankings(reportId, reportMonth, sectorRankings) {
    if (!this.supabase || !sectorRankings || sectorRankings.length === 0) {
      return { success: false, error: 'No supabase or sector rankings' };
    }

    console.log(`[QuoteDrivenStorage] Saving ${sectorRankings.length} quote-derived sector rankings for ${reportMonth}`);

    try {
      const records = sectorRankings.map(sector => ({
        report_id: reportId,
        report_month: reportMonth,
        sector_name: sector.sector,
        sector_etf: sector.etf || null,
        rank: sector.rank || 0,
        impact_score: parseFloat(sector.score) || 5.0,
        direction: sector.direction || 'neutral',
        confidence: sector.confidence || 'medium',
        quote_count: sector.quoteCount || 0,
        avg_sentiment: sector.avgSentiment || 0,
        themes: sector.themes || [],
        supporting_quote: sector.supportingQuote || null,
        supporting_quote_industry: sector.supportingQuoteIndustry || null,
        key_stocks: sector.keyStocks || [],
        quote_derived_reasoning: this.buildSectorReasoning(sector),
        analysis_method: 'quote-driven',
        updated_at: new Date().toISOString(),
      }));

      const { data, error } = await this.supabase
        .from('ism_quote_derived_sectors')
        .upsert(records, { onConflict: 'report_id,sector_name' })
        .select();

      if (error) {
        console.error('[QuoteDrivenStorage] Error saving sector rankings:', error);
        return { success: false, error: error.message };
      }

      console.log(`[QuoteDrivenStorage] ✓ Saved ${data?.length || 0} sector rankings`);
      return { success: true, count: data?.length || 0 };

    } catch (error) {
      console.error('[QuoteDrivenStorage] Exception:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // SAVE QUOTE-DERIVED TRADE IDEAS
  // ============================================

  async saveTradeIdeas(reportId, reportMonth, tradeIdeas) {
    if (!this.supabase || !tradeIdeas || tradeIdeas.length === 0) {
      return { success: false, error: 'No supabase or trade ideas' };
    }

    console.log(`[QuoteDrivenStorage] Saving ${tradeIdeas.length} quote-derived trade ideas for ${reportMonth}`);

    try {
      const records = tradeIdeas.map((idea, index) => ({
        report_id: reportId,
        report_month: reportMonth,
        direction: idea.direction || 'long',
        title: idea.title || `Trade ${index + 1}`,
        sector: idea.sector || 'Unknown',
        ticker: idea.ticker || null,
        alternative_stocks: idea.alternativeStocks || [],
        thesis: idea.thesis || '',
        executive_quote: idea.executiveQuote || null,
        executive_quote_industry: idea.executiveQuoteIndustry || null,
        direct_impact: idea.directImpact || null,
        conviction: idea.conviction || 'medium',
        invalidation: idea.invalidation || [],
        risks: idea.risks || [],
        driving_quotes: idea.quotesDriving || [],
        themes_supporting: this.extractThemesFromIdea(idea),
        display_order: index + 1,
        analysis_method: 'quote-driven',
        updated_at: new Date().toISOString(),
      }));

      const { data, error } = await this.supabase
        .from('ism_quote_derived_trades')
        .upsert(records, { onConflict: 'report_id,title' })
        .select();

      if (error) {
        console.error('[QuoteDrivenStorage] Error saving trade ideas:', error);
        return { success: false, error: error.message };
      }

      console.log(`[QuoteDrivenStorage] ✓ Saved ${data?.length || 0} trade ideas`);
      return { success: true, count: data?.length || 0 };

    } catch (error) {
      console.error('[QuoteDrivenStorage] Exception:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // SAVE THEME ANALYSIS
  // ============================================

  async saveThemeAnalysis(reportId, reportMonth, themeBreakdown, processedQuotes) {
    if (!this.supabase || !themeBreakdown) {
      return { success: false, error: 'No supabase or theme data' };
    }

    console.log(`[QuoteDrivenStorage] Saving theme analysis for ${reportMonth}`);

    try {
      const records = [];

      for (const [themeName, count] of Object.entries(themeBreakdown)) {
        // Find quotes for this theme
        const themeQuotes = (processedQuotes || []).filter(q => 
          q.themes && q.themes.includes(themeName)
        );
        
        // Calculate average sentiment for this theme
        const avgSentiment = themeQuotes.length > 0
          ? themeQuotes.reduce((sum, q) => sum + (q.sentimentScore || 0), 0) / themeQuotes.length
          : 0;

        // Determine sentiment direction
        let sentimentDirection = 'neutral';
        if (avgSentiment < -0.3) sentimentDirection = 'negative';
        else if (avgSentiment > 0.3) sentimentDirection = 'positive';

        records.push({
          report_id: reportId,
          report_month: reportMonth,
          theme_name: themeName,
          mention_count: count,
          avg_sentiment: parseFloat(avgSentiment.toFixed(2)),
          sentiment_direction: sentimentDirection,
          industries_mentioned: [...new Set(themeQuotes.map(q => q.industry))],
          sample_quotes: themeQuotes.slice(0, 3).map(q => ({
            industry: q.industry,
            excerpt: (q.comment || '').substring(0, 150),
          })),
        });
      }

      if (records.length === 0) {
        return { success: true, count: 0 };
      }

      const { data, error } = await this.supabase
        .from('ism_quote_theme_analysis')
        .upsert(records, { onConflict: 'report_id,theme_name' })
        .select();

      if (error) {
        console.error('[QuoteDrivenStorage] Error saving theme analysis:', error);
        return { success: false, error: error.message };
      }

      console.log(`[QuoteDrivenStorage] ✓ Saved ${data?.length || 0} theme analyses`);
      return { success: true, count: data?.length || 0 };

    } catch (error) {
      console.error('[QuoteDrivenStorage] Exception:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // SAVE ALL QUOTE-DRIVEN DATA
  // ============================================

  async saveQuoteDrivenAnalysis(reportId, reportMonth, analysis) {
    console.log(`[QuoteDrivenStorage] Saving complete quote-driven analysis for ${reportMonth}`);

    const results = {
      sectors: await this.saveSectorRankings(
        reportId, 
        reportMonth, 
        analysis.sectorRankings
      ),
      tradeIdeas: await this.saveTradeIdeas(
        reportId, 
        reportMonth, 
        analysis.tradeIdeas
      ),
      themes: await this.saveThemeAnalysis(
        reportId, 
        reportMonth, 
        analysis.quoteAnalysis?.themeBreakdown,
        analysis.quoteAnalysis?.processedQuotes
      ),
    };

    const allSuccess = results.sectors.success && 
                       results.tradeIdeas.success && 
                       results.themes.success;

    console.log(`[QuoteDrivenStorage] Save complete:`, {
      sectorsCount: results.sectors.count || 0,
      tradesCount: results.tradeIdeas.count || 0,
      themesCount: results.themes.count || 0,
      allSuccess,
    });

    return {
      success: allSuccess,
      results,
    };
  }

  // ============================================
  // RETRIEVAL METHODS
  // ============================================

  async getSectorRankingsForMonth(month) {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('ism_quote_derived_sectors')
      .select('*')
      .eq('report_month', month)
      .order('rank', { ascending: true });

    if (error) {
      console.error('[QuoteDrivenStorage] Error fetching sectors:', error);
      return null;
    }

    return data;
  }

  async getTradeIdeasForMonth(month) {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('ism_quote_derived_trades')
      .select('*')
      .eq('report_month', month)
      .order('display_order', { ascending: true });

    if (error) {
      console.error('[QuoteDrivenStorage] Error fetching trades:', error);
      return null;
    }

    return data;
  }

  async getThemeAnalysisForMonth(month) {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('ism_quote_theme_analysis')
      .select('*')
      .eq('report_month', month)
      .order('mention_count', { ascending: false });

    if (error) {
      console.error('[QuoteDrivenStorage] Error fetching themes:', error);
      return null;
    }

    return data;
  }

  async getLatestSectorRankings() {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('v_quote_sector_rankings_latest')
      .select('*');

    if (error) {
      console.error('[QuoteDrivenStorage] Error:', error);
      return null;
    }

    return data;
  }

  async getLatestTradeIdeas() {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('v_quote_trade_ideas_latest')
      .select('*');

    if (error) {
      console.error('[QuoteDrivenStorage] Error:', error);
      return null;
    }

    return data;
  }

  async getSectorRankingHistory(sectorName, limit = 12) {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('ism_quote_derived_sectors')
      .select('report_month, rank, impact_score, direction, quote_count')
      .eq('sector_name', sectorName)
      .order('report_month', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('[QuoteDrivenStorage] Error:', error);
      return null;
    }

    return data;
  }

  async getThemeTrends(themeName, limit = 12) {
    if (!this.supabase) return null;

    const { data, error } = await this.supabase
      .from('ism_quote_theme_analysis')
      .select('report_month, mention_count, avg_sentiment, sentiment_direction')
      .eq('theme_name', themeName)
      .order('report_month', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('[QuoteDrivenStorage] Error:', error);
      return null;
    }

    return data;
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  buildSectorReasoning(sector) {
    const parts = [];
    
    if (sector.quoteCount > 0) {
      parts.push(`Based on ${sector.quoteCount} executive quote(s).`);
    }
    
    if (sector.themes && sector.themes.length > 0) {
      parts.push(`Key themes: ${sector.themes.join(', ')}.`);
    }
    
    if (sector.avgSentiment !== undefined) {
      const sentimentDesc = sector.avgSentiment > 0.3 ? 'positive' : 
                           sector.avgSentiment < -0.3 ? 'negative' : 'mixed';
      parts.push(`Overall sentiment: ${sentimentDesc}.`);
    }
    
    return parts.join(' ') || 'Quote-derived ranking.';
  }

  extractThemesFromIdea(idea) {
    const themes = [];
    
    if (idea.quotesDriving) {
      for (const quote of idea.quotesDriving) {
        if (quote.themes) {
          themes.push(...quote.themes);
        }
      }
    }
    
    return [...new Set(themes)];
  }

  // ============================================
  // CLEANUP OLD DATA
  // ============================================

  async cleanupOldData(monthsToKeep = 24) {
    if (!this.supabase) return { success: false };

    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - monthsToKeep);
    const cutoffMonth = `${cutoffDate.getFullYear()}-${String(cutoffDate.getMonth() + 1).padStart(2, '0')}`;

    console.log(`[QuoteDrivenStorage] Cleaning up data older than ${cutoffMonth}`);

    try {
      await this.supabase
        .from('ism_quote_derived_sectors')
        .delete()
        .lt('report_month', cutoffMonth);

      await this.supabase
        .from('ism_quote_derived_trades')
        .delete()
        .lt('report_month', cutoffMonth);

      await this.supabase
        .from('ism_quote_theme_analysis')
        .delete()
        .lt('report_month', cutoffMonth);

      console.log(`[QuoteDrivenStorage] Cleanup complete`);
      return { success: true };

    } catch (error) {
      console.error('[QuoteDrivenStorage] Cleanup error:', error);
      return { success: false, error: error.message };
    }
  }
}

// ============================================
// GET MIGRATION SQL
// ============================================

function getMigrationSQL() {
  return MIGRATION_SQL;
}

// ============================================
// EXPORTS
// ============================================

export {
  QuoteDrivenStorage,
  getMigrationSQL,
  MIGRATION_SQL,
};