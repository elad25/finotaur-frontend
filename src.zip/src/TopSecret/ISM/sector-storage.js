// =====================================================
// ISM SECTOR STORAGE SERVICE v1.0
// =====================================================
// Location: src/TopSecret/ISM/sector-storage.js
//
// Saves sector rankings and ticker selections from
// each ISM report to database for historical reference
// =====================================================

/**
 * Save sector rankings from report to database
 */
async function saveSectorAnalysis(supabase, reportId, reportMonth, sectorData) {
  if (!supabase || !sectorData) {
    console.warn('[SectorStorage] Missing supabase or sector data');
    return { success: false, error: 'Missing data' };
  }

  const sectors = sectorData.sectors || sectorData.rankings || [];
  
  if (sectors.length === 0) {
    console.warn('[SectorStorage] No sectors to save');
    return { success: false, error: 'No sectors' };
  }

  console.log(`[SectorStorage] Saving ${sectors.length} sectors for ${reportMonth}`);

  try {
    const sectorRecords = sectors.map(sector => ({
      report_id: reportId,
      report_month: reportMonth,
      sector_id: sector.sectorId || normalizeSectorId(sector.sector),
      sector_name: sector.sector || sector.sectorName,
      etf_symbol: sector.etf || null,
      rank: sector.rank || 0,
      impact_score: parseFloat(sector.impactScore) || 5.0,
      direction: sector.direction || 'neutral',
      ism_signal: sector.ismSignal || (sector.direction === 'positive' ? 'Positive' : 'Negative'),
      trend: sector.trend || (sector.direction === 'positive' ? 'Favorable' : 'Unfavorable'),
      reasoning: sector.reasoning || null,
      key_driver: sector.keyDriver || null,
      key_driver_value: sector.keyDriverValue ? parseFloat(sector.keyDriverValue) : null,
    }));

    const { data, error } = await supabase
      .from('ism_sector_analysis')
      .upsert(sectorRecords, { onConflict: 'report_id,sector_id' })
      .select();

    if (error) {
      console.error('[SectorStorage] Error saving sectors:', error);
      return { success: false, error: error.message };
    }

    console.log(`[SectorStorage] Saved ${data?.length || 0} sectors`);
    return { success: true, count: data?.length || 0 };

  } catch (error) {
    console.error('[SectorStorage] Exception:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Save ticker selections from report to database
 */
async function saveTickerSelections(supabase, reportId, reportMonth, sectorData, stockImplications) {
  if (!supabase) return { success: false };

  const tickerRecords = [];
  const sectors = sectorData?.sectors || sectorData?.rankings || [];

  // Extract tickers from sector keyStocks
  for (const sector of sectors) {
    const keyStocks = sector.keyStocks || [];
    const selectionType = getSelectionType(sector);
    
    for (const ticker of keyStocks) {
      tickerRecords.push({
        report_id: reportId,
        report_month: reportMonth,
        ticker: ticker,
        sector_id: sector.sectorId || normalizeSectorId(sector.sector),
        sector_name: sector.sector || sector.sectorName,
        selection_type: selectionType,
        conviction: getConviction(sector),
        reasoning: `${sector.sector}: ${sector.reasoning?.slice(0, 200) || 'ISM-driven selection'}`,
        archetype: getArchetype(ticker),
      });
    }
  }

  // Add from stock_implications if available
  if (stockImplications) {
    // Overweight
    const overweight = stockImplications.outperformCandidates || stockImplications.overweight || [];
    for (const stock of overweight) {
      const ticker = stock.ticker || stock.symbol;
      if (ticker && !tickerRecords.find(t => t.ticker === ticker)) {
        tickerRecords.push({
          report_id: reportId,
          report_month: reportMonth,
          ticker: ticker,
          sector_id: normalizeSectorId(stock.sector),
          sector_name: stock.sector,
          selection_type: 'overweight',
          conviction: stock.conviction || 'medium',
          reasoning: stock.reasoning || stock.rationale,
          archetype: stock.archetype || getArchetype(ticker),
        });
      }
    }

    // Underweight/Avoid
    const underweight = stockImplications.underperformCandidates || stockImplications.underweight || [];
    for (const stock of underweight) {
      const ticker = stock.ticker || stock.symbol;
      if (ticker && !tickerRecords.find(t => t.ticker === ticker)) {
        tickerRecords.push({
          report_id: reportId,
          report_month: reportMonth,
          ticker: ticker,
          sector_id: normalizeSectorId(stock.sector),
          sector_name: stock.sector,
          selection_type: stock.avoid ? 'avoid' : 'underweight',
          conviction: stock.conviction || 'medium',
          reasoning: stock.reasoning || stock.rationale,
          archetype: stock.archetype,
        });
      }
    }

    // Watchlist
    const watchlist = stockImplications.watchlist || [];
    for (const stock of watchlist) {
      const ticker = stock.ticker || stock.symbol;
      if (ticker && !tickerRecords.find(t => t.ticker === ticker)) {
        tickerRecords.push({
          report_id: reportId,
          report_month: reportMonth,
          ticker: ticker,
          sector_id: normalizeSectorId(stock.sector),
          sector_name: stock.sector,
          selection_type: 'watchlist',
          conviction: 'low',
          reasoning: stock.reasoning || stock.rationale,
          archetype: stock.archetype,
        });
      }
    }
  }

  if (tickerRecords.length === 0) {
    return { success: true, count: 0 };
  }

  try {
    const { data, error } = await supabase
      .from('ism_ticker_selections')
      .upsert(tickerRecords, { onConflict: 'report_id,ticker' })
      .select();

    if (error) {
      console.error('[SectorStorage] Error saving tickers:', error);
      return { success: false, error: error.message };
    }

    console.log(`[SectorStorage] Saved ${data?.length || 0} tickers`);
    return { success: true, count: data?.length || 0 };

  } catch (error) {
    console.error('[SectorStorage] Exception:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Get sectors for a specific month
 */
async function getSectorsForMonth(supabase, reportMonth) {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from('ism_sector_analysis')
    .select('*')
    .eq('report_month', reportMonth)
    .order('rank', { ascending: true });

  if (error) {
    console.error('[SectorStorage] Error fetching sectors:', error);
    return null;
  }

  return data;
}

/**
 * Get tickers for a specific month
 */
async function getTickersForMonth(supabase, reportMonth) {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from('ism_ticker_selections')
    .select('*')
    .eq('report_month', reportMonth)
    .order('selection_type');

  if (error) {
    console.error('[SectorStorage] Error fetching tickers:', error);
    return null;
  }

  return data;
}

/**
 * Get latest sector rankings
 */
async function getLatestSectorRankings(supabase) {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from('v_sector_rankings_latest')
    .select('*');

  if (error) {
    console.error('[SectorStorage] Error:', error);
    return null;
  }

  return data;
}

/**
 * Get latest ticker selections
 */
async function getLatestTickerSelections(supabase) {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from('v_ticker_selections_latest')
    .select('*');

  if (error) {
    console.error('[SectorStorage] Error:', error);
    return null;
  }

  return data;
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function normalizeSectorId(sectorName) {
  if (!sectorName) return 'unknown';
  return sectorName.toLowerCase()
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

function getSelectionType(sector) {
  const score = sector.impactScore || 5;
  const direction = sector.direction || 'neutral';
  
  if (direction === 'positive' && score >= 6) return 'overweight';
  if (direction === 'negative' && score <= 4) return 'underweight';
  if (direction === 'negative' && score <= 3) return 'avoid';
  return 'watchlist';
}

function getConviction(sector) {
  const score = sector.impactScore || 5;
  if (score >= 7.5 || score <= 3) return 'high';
  if (score >= 6 || score <= 4) return 'medium';
  return 'low';
}

function getArchetype(ticker) {
  const archetypes = {
    // Quality Defensives
    'JNJ': 'quality_defensives', 'PG': 'quality_defensives', 'KO': 'quality_defensives',
    'PEP': 'quality_defensives', 'COST': 'quality_defensives', 'WMT': 'quality_defensives',
    'UNH': 'quality_defensives', 'MSFT': 'quality_defensives',
    
    // Cyclical Leaders
    'CAT': 'cyclical_leaders', 'DE': 'cyclical_leaders', 'HON': 'cyclical_leaders',
    'ETN': 'cyclical_leaders', 'GE': 'cyclical_leaders', 'EMR': 'cyclical_leaders',
    'ROK': 'cyclical_leaders',
    
    // Restocking Beneficiaries
    'LIN': 'restocking_beneficiaries', 'FCX': 'restocking_beneficiaries', 
    'DOW': 'restocking_beneficiaries', 'APD': 'restocking_beneficiaries',
    'NEM': 'restocking_beneficiaries',
    
    // High Operating Leverage
    'X': 'high_operating_leverage', 'NUE': 'high_operating_leverage',
    'AA': 'high_operating_leverage', 'CLF': 'high_operating_leverage',
    
    // Tech/Growth
    'NVDA': 'tech_growth', 'AMD': 'tech_growth', 'AVGO': 'tech_growth',
    'AAPL': 'tech_growth',
    
    // Transportation
    'UNP': 'transportation', 'FDX': 'transportation', 'UPS': 'transportation',
    'DAL': 'transportation', 'CSX': 'transportation',
  };
  
  return archetypes[ticker] || null;
}

// ============================================
// EXPORTS
// ============================================

export {
  saveSectorAnalysis,
  saveTickerSelections,
  getSectorsForMonth,
  getTickersForMonth,
  getLatestSectorRankings,
  getLatestTickerSelections,
};