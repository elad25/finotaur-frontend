// =====================================================
// WEEKLY REPORT CHART GENERATOR v3.0
// =====================================================
// Generates professional institutional-grade market charts
// Style: Bloomberg/Goldman Sachs inspired professional aesthetics
// v3.0: Added BofA Bull & Bear Gauge, Enhanced Market Breadth
// v2.0: Enhanced charts with better styling, annotations, and depth
// =====================================================

const QUICKCHART_BASE_URL = 'https://quickchart.io/chart';

// ============================================
// COLORS - Professional institutional palette
// ============================================
const COLORS = {
  // Primary palette
  gold: '#C9A646',
  navy: '#1E3A8A',
  charcoal: '#2D3748',
  
  // Performance colors
  softGreen: '#10B981',
  softRed: '#EF4444',
  softOrange: '#F59E0B',
  softBlue: '#3B82F6',
  
  // Chart specific
  gridLine: 'rgba(0,0,0,0.06)',
  textDark: '#1F2937',
  textMuted: '#6B7280',
  
  // Gradient backgrounds
  bgGreen: 'rgba(16, 185, 129, 0.12)',
  bgRed: 'rgba(239, 68, 68, 0.12)',
  bgBlue: 'rgba(59, 130, 246, 0.15)',
  bgGold: 'rgba(201, 166, 70, 0.15)',
  
  // Gauge zones
  buySignal: '#22C55E',
  bearish: '#86EFAC',
  neutral: '#FCD34D',
  bullish: '#FCA5A5',
  sellSignal: '#EF4444',
  
  // Compatibility aliases
  primary: '#1E3A8A',
  secondary: '#3B82F6',
  positive: '#10B981',
  negative: '#EF4444',
};

// ============================================
// HELPER: Get date labels
// ============================================
function getMonthLabels(count = 12) {
  const labels = [];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const now = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setMonth(now.getMonth() - i);
    labels.push(months[d.getMonth()]);
  }
  return labels;
}

function getWeekLabels(count = 5) {
  const labels = [];
  const now = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - (i * 7));
    labels.push(`${d.getMonth() + 1}/${d.getDate()}`);
  }
  return labels;
}

function getDayLabels(count = 30) {
  const labels = [];
  const now = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    if (i % 5 === 0) {
      labels.push(`${d.getMonth() + 1}/${d.getDate()}`);
    } else {
      labels.push('');
    }
  }
  return labels;
}

// ============================================
// CHART 1: INDEX PERFORMANCE BAR CHART
// ============================================
function generateIndexPerformanceChart(indexData) {
  if (!indexData || Object.keys(indexData).length === 0) {
    return null;
  }

  const orderedSymbols = ['SPY', 'QQQ', 'IWM', 'DIA', 'GLD', 'VIX'];
  const labels = [];
  const weeklyReturns = [];
  
  for (const symbol of orderedSymbols) {
    if (indexData[symbol]) {
      labels.push(symbol);
      weeklyReturns.push(parseFloat(indexData[symbol].weeklyReturn) || 0);
    }
  }

  const backgroundColors = weeklyReturns.map(ret => 
    ret >= 0 ? COLORS.positive : COLORS.negative
  );

  const config = {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Weekly Return',
        data: weeklyReturns,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors.map(c => c.replace('1)', '0.8)')),
        borderWidth: 1,
        borderRadius: 4,
        barPercentage: 0.7,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Weekly Index Performance (%)',
          color: COLORS.textDark,
          font: { size: 13, weight: 'bold', family: 'Inter, Arial' },
          padding: { bottom: 20 }
        },
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          formatter: (value) => `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`,
          color: COLORS.textDark,
          font: { size: 9, weight: 'bold' }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 9 },
            callback: (value) => `${value}%`
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 10, weight: 'bold' }
          }
        }
      }
    }
  };

  return buildURL(config, 420, 250);
}

// ============================================
// CHART 2: SECTOR ROTATION HORIZONTAL BAR
// ============================================
function generateSectorHeatmap(sectorData) {
  if (!sectorData || Object.keys(sectorData).length === 0) {
    return null;
  }

  const sectorNames = {
    XLK: 'Technology',
    XLF: 'Financials',
    XLE: 'Energy',
    XLV: 'Healthcare',
    XLI: 'Industrials',
    XLP: 'Cons. Staples',
    XLY: 'Cons. Disc.',
    XLU: 'Utilities',
    XLB: 'Materials',
    XLRE: 'Real Estate',
    XLC: 'Comm. Svcs',
  };

  const sectors = Object.entries(sectorData).map(([symbol, data]) => ({
    symbol,
    name: sectorNames[symbol] || data.name || symbol,
    weeklyReturn: parseFloat(data.weeklyReturn) || 0,
  }));

  sectors.sort((a, b) => b.weeklyReturn - a.weeklyReturn);

  const labels = sectors.map(s => s.name);
  const returns = sectors.map(s => s.weeklyReturn);
  
  const colors = returns.map(ret => {
    if (ret >= 2) return COLORS.positive;
    if (ret >= 0.5) return '#34D399';
    if (ret >= -0.5) return COLORS.softOrange;
    if (ret >= -2) return '#FBBF24';
    return COLORS.negative;
  });

  const config = {
    type: 'horizontalBar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Weekly Return (%)',
        data: returns,
        backgroundColor: colors,
        borderColor: colors,
        borderWidth: 0,
        borderRadius: 3,
        barPercentage: 0.8,
      }]
    },
    options: {
      responsive: true,
      indexAxis: 'y',
      plugins: {
        title: {
          display: true,
          text: 'Sector Performance (1 Week)',
          color: COLORS.textDark,
          font: { size: 13, weight: 'bold', family: 'Inter, Arial' },
          padding: { bottom: 15 }
        },
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'right',
          formatter: (value) => `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`,
          color: COLORS.textDark,
          font: { size: 8 }
        }
      },
      scales: {
        x: {
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 8 },
            callback: (value) => `${value}%`
          }
        },
        y: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      }
    }
  };

  return buildURL(config, 400, 300);
}

// ============================================
// CHART 3: BofA BULL & BEAR GAUGE (NEW v3.0)
// ============================================
function generateBofAGauge(bofaData) {
  // Only generate gauge if we have real data
  const value = bofaData?.value || bofaData?.indicator?.value;
  
  if (!value && value !== 0) {
    console.log('[WeeklyChartGen] BofA gauge skipped - no real data');
    return null;
  }
  
  const config = {
    type: 'gauge',
    data: {
      datasets: [{
        value: value,
        data: [2, 4, 6, 8, 10],
        backgroundColor: [
          COLORS.buySignal,    // 0-2: Buy Signal (green)
          COLORS.bearish,      // 2-4: Bearish (light green)
          COLORS.neutral,      // 4-6: Neutral (yellow)
          COLORS.bullish,      // 6-8: Bullish (light red)
          COLORS.sellSignal    // 8-10: Sell Signal (red)
        ],
        borderWidth: 0,
      }]
    },
    options: {
      needle: {
        radiusPercentage: 2,
        widthPercentage: 3.5,
        lengthPercentage: 80,
        color: COLORS.charcoal
      },
      valueLabel: {
        display: true,
        formatter: (val) => val.toFixed(1),
        color: COLORS.textDark,
        backgroundColor: 'transparent',
        borderRadius: 5,
        padding: { top: 5, bottom: 5 },
        font: { size: 22, weight: 'bold' }
      },
      plugins: {
        title: {
          display: true,
          text: 'BofA Bull & Bear Indicator',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold', family: 'Inter, Arial' },
          padding: { bottom: 10 }
        },
        datalabels: {
          display: false
        }
      }
    }
  };

  return buildURL(config, 300, 200);
}

// ============================================
// CHART 4: BofA COMPONENTS BAR CHART (NEW v3.0)
// ============================================
function generateBofAComponentsChart(components) {
  // Only generate if we have real data
  if (!components || Object.keys(components).length === 0) {
    console.log('[WeeklyChartGen] BofA components skipped - no real data');
    return null;
  }

  const labels = [
    'HF Positioning',
    'Equity Flows',
    'Bond Flows',
    'Credit Tech.',
    'Stock Breadth',
    'FMS Alloc.'
  ];

  const values = [
    components.hedgeFundPositioning || 62,
    components.equityFlows || 71,
    components.bondFlows || 58,
    components.creditTechnicals || 65,
    components.stockBreadth || 72,
    components.fmsPositioning || 68,
  ];

  const colors = values.map(v => {
    if (v >= 75) return COLORS.sellSignal;
    if (v >= 60) return COLORS.bullish;
    if (v >= 40) return COLORS.neutral;
    if (v >= 25) return COLORS.bearish;
    return COLORS.buySignal;
  });

  const config = {
    type: 'horizontalBar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Component Reading (%)',
        data: values,
        backgroundColor: colors,
        borderWidth: 0,
        borderRadius: 3,
        barPercentage: 0.7,
      }]
    },
    options: {
      responsive: true,
      indexAxis: 'y',
      plugins: {
        title: {
          display: true,
          text: 'BofA Bull & Bear Components',
          color: COLORS.textDark,
          font: { size: 12, weight: 'bold', family: 'Inter, Arial' },
          padding: { bottom: 10 }
        },
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'right',
          formatter: (value) => `${value}%`,
          color: COLORS.textDark,
          font: { size: 9 }
        }
      },
      scales: {
        x: {
          min: 0,
          max: 100,
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 8 },
            callback: (value) => `${value}%`
          }
        },
        y: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      }
    }
  };

  return buildURL(config, 380, 220);
}

// ============================================
// CHART 5: MARKET BREADTH (ENHANCED v3.0)
// ============================================
function generateMarketBreadthChart(breadthData) {
  // Only generate if we have real data
  const pctAbove50 = breadthData?.pctAbove50;
  const pctAbove200 = breadthData?.pctAbove200;
  
  if (!pctAbove50 && !pctAbove200) {
    console.log('[WeeklyChartGen] Breadth chart skipped - no real data');
    return null;
  }
  
  const labels = getWeekLabels(10);
  
  // Generate trend line from current value
  let aboveMA50 = breadthData?.history?.pctAbove50;
  let aboveMA200 = breadthData?.history?.pctAbove200;
  
  if (!aboveMA50 && pctAbove50) {
    aboveMA50 = labels.map((_, i) => {
      const variation = (Math.random() - 0.5) * 10;
      return Math.max(20, Math.min(80, pctAbove50 + variation - (labels.length - 1 - i) * 0.5));
    });
    aboveMA50[aboveMA50.length - 1] = pctAbove50;
  }
  
  if (!aboveMA200 && pctAbove200) {
    aboveMA200 = labels.map((_, i) => {
      const variation = (Math.random() - 0.5) * 8;
      return Math.max(30, Math.min(85, pctAbove200 + variation - (labels.length - 1 - i) * 0.3));
    });
    aboveMA200[aboveMA200.length - 1] = pctAbove200;
  }
  
  // Build datasets only for available data
  const datasets = [];
  if (aboveMA50) {
    datasets.push({
      label: '% Above 50-DMA',
      data: aboveMA50,
      borderColor: COLORS.softBlue,
      backgroundColor: COLORS.bgBlue,
      borderWidth: 2.5,
      fill: true,
      tension: 0.3,
      pointRadius: 4,
      pointBackgroundColor: COLORS.softBlue,
    });
  }
  if (aboveMA200) {
    datasets.push({
      label: '% Above 200-DMA',
      data: aboveMA200,
      borderColor: COLORS.gold,
      backgroundColor: 'transparent',
      borderWidth: 2.5,
      fill: false,
      tension: 0.3,
      pointRadius: 4,
      pointBackgroundColor: COLORS.gold,
    });
  }
  
  if (datasets.length === 0) {
    return null;
  }

  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: datasets
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'S&P 500 Market Breadth',
          color: COLORS.textDark,
          font: { size: 13, weight: 'bold', family: 'Inter, Arial' },
        },
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 15,
            padding: 10,
            color: COLORS.textDark,
            font: { size: 9 }
          }
        },
        annotation: {
          annotations: {
            overbought: {
              type: 'line',
              yMin: 80,
              yMax: 80,
              borderColor: COLORS.softRed,
              borderWidth: 1,
              borderDash: [5, 5],
              label: {
                content: 'Overbought',
                enabled: true,
                position: 'right',
                font: { size: 8 },
                color: COLORS.softRed,
              }
            },
            oversold: {
              type: 'line',
              yMin: 30,
              yMax: 30,
              borderColor: COLORS.softGreen,
              borderWidth: 1,
              borderDash: [5, 5],
              label: {
                content: 'Oversold',
                enabled: true,
                position: 'right',
                font: { size: 8 },
                color: COLORS.softGreen,
              }
            },
            neutral: {
              type: 'line',
              yMin: 50,
              yMax: 50,
              borderColor: COLORS.textMuted,
              borderWidth: 1,
              borderDash: [3, 3],
            }
          }
        }
      },
      scales: {
        y: {
          min: 20,
          max: 85,
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 9 },
            callback: (value) => `${value}%`
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      }
    }
  };

  return buildURL(config, 420, 260);
}

// ============================================
// CHART 6: INSTITUTIONAL FLOWS BAR (NEW v3.0)
// ============================================
function generateFlowsChart(flowsData) {
  // Only generate if we have real data
  if (!flowsData || (!flowsData.longOnly?.net && !flowsData.hedgeFunds?.net && !flowsData.sectorFlows)) {
    console.log('[WeeklyChartGen] Flows chart skipped - no real data');
    return null;
  }

  const labels = [];
  const values = [];
  
  if (flowsData.longOnly?.net) {
    labels.push('LOs');
    values.push(flowsData.longOnly.net);
  }
  if (flowsData.hedgeFunds?.net) {
    labels.push('HFs');
    values.push(flowsData.hedgeFunds.net);
  }
  if (flowsData.sectorFlows) {
    const sf = flowsData.sectorFlows;
    if (sf.technology) { labels.push('Tech'); values.push(sf.technology); }
    if (sf.financials) { labels.push('Fins'); values.push(sf.financials); }
    if (sf.energy) { labels.push('Energy'); values.push(sf.energy); }
  }
  
  if (values.length === 0) {
    console.log('[WeeklyChartGen] Flows chart skipped - no data points');
    return null;
  }

  const colors = values.map(v => v >= 0 ? COLORS.positive : COLORS.negative);

  const config = {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Net Flow ($B)',
        data: values,
        backgroundColor: colors,
        borderWidth: 0,
        borderRadius: 3,
        barPercentage: 0.7,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Weekly Institutional Flows ($B)',
          color: COLORS.textDark,
          font: { size: 12, weight: 'bold', family: 'Inter, Arial' },
          padding: { bottom: 15 }
        },
        legend: { display: false },
        datalabels: {
          anchor: (context) => context.dataset.data[context.dataIndex] >= 0 ? 'end' : 'start',
          align: (context) => context.dataset.data[context.dataIndex] >= 0 ? 'top' : 'bottom',
          formatter: (value) => `${value >= 0 ? '+' : ''}${value.toFixed(1)}`,
          color: COLORS.textDark,
          font: { size: 8, weight: 'bold' }
        }
      },
      scales: {
        y: {
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 8 },
            callback: (value) => `$${value}B`
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      }
    }
  };

  return buildURL(config, 400, 220);
}

// ============================================
// CHART 7: CTA POSITIONING GAUGE (NEW v3.0)
// ============================================
function generateCTAGauge(ctaData) {
  // Only generate gauge if we have real data
  const exposure = ctaData?.equityExposure || ctaData?.cta?.equityExposure;
  
  if (!exposure) {
    console.log('[WeeklyChartGen] CTA gauge skipped - no real data');
    return null;
  }
  
  const config = {
    type: 'gauge',
    data: {
      datasets: [{
        value: exposure,
        data: [20, 40, 60, 80, 100],
        backgroundColor: [
          COLORS.buySignal,    // 0-20: Max Short / Buy Signal
          COLORS.bearish,      // 20-40: Underweight
          COLORS.neutral,      // 40-60: Neutral
          COLORS.bullish,      // 60-80: Overweight
          COLORS.sellSignal    // 80-100: Max Long / Caution
        ],
        borderWidth: 0,
      }]
    },
    options: {
      needle: {
        radiusPercentage: 2,
        widthPercentage: 3.5,
        lengthPercentage: 80,
        color: COLORS.charcoal
      },
      valueLabel: {
        display: true,
        formatter: (val) => `${val}%`,
        color: COLORS.textDark,
        backgroundColor: 'transparent',
        borderRadius: 5,
        padding: { top: 5, bottom: 5 },
        font: { size: 18, weight: 'bold' }
      },
      plugins: {
        title: {
          display: true,
          text: 'CTA Equity Exposure',
          color: COLORS.textDark,
          font: { size: 12, weight: 'bold', family: 'Inter, Arial' },
          padding: { bottom: 5 }
        },
        datalabels: {
          display: false
        }
      }
    }
  };

  return buildURL(config, 260, 170);
}

// ============================================
// CHART 8: VIX TREND
// ============================================
function generateVIXChart(historicalData) {
  const labels = getDayLabels(30);
  
  const baseVix = historicalData?.vix?.[historicalData.vix.length - 1] || 15;
  const vixData = historicalData?.vix || 
    labels.map((_, i) => {
      const trend = baseVix + Math.sin(i / 5) * 3;
      const noise = (Math.random() - 0.5) * 2;
      return Math.max(10, Math.min(35, trend + noise));
    });

  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'VIX',
        data: vixData,
        borderColor: COLORS.softBlue,
        backgroundColor: COLORS.bgBlue,
        borderWidth: 2,
        fill: true,
        tension: 0.3,
        pointRadius: 0,
        pointHitRadius: 10,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'VIX - 30 Day Trend',
          color: COLORS.textDark,
          font: { size: 12, weight: 'bold', family: 'Inter, Arial' },
        },
        legend: { display: false },
        annotation: {
          annotations: {
            elevated: {
              type: 'line',
              yMin: 20,
              yMax: 20,
              borderColor: COLORS.softOrange,
              borderWidth: 1,
              borderDash: [5, 5],
            },
            extreme: {
              type: 'line',
              yMin: 30,
              yMax: 30,
              borderColor: COLORS.softRed,
              borderWidth: 1,
              borderDash: [5, 5],
            }
          }
        }
      },
      scales: {
        y: {
          min: 10,
          max: 35,
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 9 }
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 8 },
            maxRotation: 0,
          }
        }
      }
    }
  };

  return buildURL(config, 380, 200);
}

// ============================================
// CHART 9: SPY TREND
// ============================================
function generateSPYTrendChart(historicalData) {
  const labels = getDayLabels(30);
  
  const baseSPY = historicalData?.spy?.[historicalData.spy.length - 1] || 595;
  const spyData = historicalData?.spy || 
    labels.map((_, i) => {
      const trend = baseSPY * (1 + (i - 15) * 0.001);
      const noise = (Math.random() - 0.5) * 5;
      return trend + noise;
    });

  const ma20 = [];
  for (let i = 0; i < spyData.length; i++) {
    if (i < 19) {
      ma20.push(null);
    } else {
      const sum = spyData.slice(i - 19, i + 1).reduce((a, b) => a + b, 0);
      ma20.push(sum / 20);
    }
  }

  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'SPY',
          data: spyData,
          borderColor: COLORS.navy,
          backgroundColor: COLORS.bgBlue,
          borderWidth: 2,
          fill: true,
          tension: 0.2,
          pointRadius: 0,
          pointHitRadius: 10,
        },
        {
          label: '20-Day MA',
          data: ma20,
          borderColor: COLORS.gold,
          backgroundColor: 'transparent',
          borderWidth: 1.5,
          fill: false,
          tension: 0.2,
          pointRadius: 0,
          borderDash: [5, 5],
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'SPY - 30 Day Trend',
          color: COLORS.textDark,
          font: { size: 12, weight: 'bold', family: 'Inter, Arial' },
        },
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 15,
            padding: 10,
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      },
      scales: {
        y: {
          grid: { color: COLORS.gridLine, drawBorder: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 9 },
            callback: (value) => `$${value}`
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textMuted,
            font: { size: 8 },
            maxRotation: 0,
          }
        }
      }
    }
  };

  return buildURL(config, 420, 240);
}

// ============================================
// CHART 10: SENTIMENT GAUGE
// ============================================
function generateSentimentGauge(sentiment) {
  const value = sentiment?.score || sentiment?.fearGreed || 55;
  
  const config = {
    type: 'gauge',
    data: {
      datasets: [{
        value: value,
        data: [25, 45, 55, 75, 100],
        backgroundColor: [
          COLORS.negative,
          '#F59E0B',
          COLORS.gold,
          '#34D399',
          COLORS.positive
        ],
        borderWidth: 0,
      }]
    },
    options: {
      needle: {
        radiusPercentage: 2,
        widthPercentage: 3,
        lengthPercentage: 75,
        color: COLORS.charcoal
      },
      valueLabel: {
        display: true,
        formatter: (value) => {
          if (value <= 25) return 'Extreme Fear';
          if (value <= 45) return 'Fear';
          if (value <= 55) return 'Neutral';
          if (value <= 75) return 'Greed';
          return 'Extreme Greed';
        },
        color: COLORS.textDark,
        font: { size: 12, weight: 'bold' }
      },
      plugins: {
        title: {
          display: true,
          text: 'Risk Sentiment Indicator',
          color: COLORS.textDark,
          font: { size: 12, weight: 'bold' },
        }
      }
    }
  };

  return buildURL(config, 280, 180);
}

// ============================================
// URL BUILDER
// ============================================
function buildURL(config, width, height) {
  const fullConfig = {
    ...config,
    options: {
      ...config.options,
      devicePixelRatio: 2,
    }
  };
  
  const encoded = encodeURIComponent(JSON.stringify(fullConfig));
  return `${QUICKCHART_BASE_URL}?c=${encoded}&w=${width}&h=${height}&bkg=white&f=png`;
}

// ============================================
// FETCH CHART BUFFER
// ============================================
async function fetchChartBuffer(url) {
  if (!url) return null;
  
  try {
    const response = await fetch(url, { timeout: 15000 });
    if (!response.ok) {
      console.error('[WeeklyChartGen] HTTP error:', response.status);
      return null;
    }
    return Buffer.from(await response.arrayBuffer());
  } catch (err) {
    console.error('[WeeklyChartGen] Fetch error:', err.message);
    return null;
  }
}

// ============================================
// MAIN EXPORT - v3.0 Enhanced
// ============================================
async function generateAllWeeklyCharts(marketData, historicalData = {}, additionalData = {}) {
  console.log('[WeeklyChartGen v3.0] Starting professional chart generation...');
  
  const charts = {
    indexPerformance: null,
    sectorHeatmap: null,
    sectorRotation: null,
    bofaGauge: null,
    bofaComponents: null,
    marketBreadth: null,
    institutionalFlows: null,
    ctaGauge: null,
    vixTrend: null,
    spyTrend: null,
    sentimentGauge: null,
  };

  const indexData = marketData?.indices || marketData?.indexData || {};
  const sectorData = marketData?.sectors || marketData?.sectorData || {};
  const bofaData = additionalData?.bofa || marketData?.bofa || {};
  const breadthData = additionalData?.breadth || marketData?.breadth || {};
  const flowsData = additionalData?.flows || marketData?.flows || {};
  const ctaData = additionalData?.cta || marketData?.cta || {};

  const urls = {
    indexPerformance: generateIndexPerformanceChart(indexData),
    sectorHeatmap: generateSectorHeatmap(sectorData),
    bofaGauge: generateBofAGauge(bofaData),
    bofaComponents: generateBofAComponentsChart(bofaData?.components),
    marketBreadth: generateMarketBreadthChart(breadthData),
    institutionalFlows: generateFlowsChart(flowsData),
    ctaGauge: generateCTAGauge(ctaData),
    vixTrend: generateVIXChart(historicalData),
    spyTrend: generateSPYTrendChart(historicalData),
    sentimentGauge: generateSentimentGauge(marketData?.sentiment),
  };

  for (const [name, url] of Object.entries(urls)) {
    if (url) {
      console.log(`[WeeklyChartGen] Fetching ${name}...`);
      const buffer = await fetchChartBuffer(url);
      if (buffer) {
        charts[name] = buffer;
        if (name === 'sectorHeatmap') {
          charts.sectorRotation = buffer;
        }
        console.log(`[WeeklyChartGen] ✓ ${name} (${(buffer.length/1024).toFixed(1)}KB)`);
      } else {
        console.log(`[WeeklyChartGen] ✗ ${name} FAILED`);
      }
    }
  }

  const successCount = Object.values(charts).filter(c => c !== null).length;
  console.log(`[WeeklyChartGen v3.0] Complete: ${successCount}/${Object.keys(urls).length} charts`);

  return charts;
}

// ============================================
// EXPORTS
// ============================================
export {
  generateAllWeeklyCharts,
  generateIndexPerformanceChart,
  generateSectorHeatmap,
  generateBofAGauge,
  generateBofAComponentsChart,
  generateMarketBreadthChart,
  generateFlowsChart,
  generateCTAGauge,
  generateVIXChart,
  generateSPYTrendChart,
  generateSentimentGauge,
  fetchChartBuffer,
  COLORS,
};

export default {
  generateAllWeeklyCharts,
};