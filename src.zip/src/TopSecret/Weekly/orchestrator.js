// =====================================================
// WEEKLY TACTICAL REVIEW - ORCHESTRATOR v1.0
// =====================================================
// Location: src/TopSecret/Weekly/orchestrator.js
// =====================================================

import { PHASES, PHASE_ORDER, AGENT_DEFINITIONS, VERSION } from './config.js';
import { createAgent } from './WeeklyAgents.js';
import { generateMarkdownReport, generateHTMLReport } from './report-generator.js';

// =====================================================
// WORKFLOW MANAGER (In-Memory Progress Tracking)
// =====================================================

class WorkflowManager {
  constructor() {
    this.workflows = new Map();
  }

  create(reportId) {
    const workflow = {
      reportId,
      status: 'running',
      progress: 0,
      currentPhase: PHASES.DATA_ACQUISITION,
      currentAgentId: null,
      currentAgentName: null,
      completedAgents: [],
      totalAgents: AGENT_DEFINITIONS.length,
      elapsedSeconds: 0,
      startedAt: new Date().toISOString(),
      error: null,
    };
    this.workflows.set(reportId, workflow);
    return workflow;
  }

  get(reportId) {
    return this.workflows.get(reportId);
  }

  update(reportId, updates) {
    const workflow = this.workflows.get(reportId);
    if (workflow) {
      Object.assign(workflow, updates);
    }
    return workflow;
  }

  delete(reportId) {
    this.workflows.delete(reportId);
  }

  getAll() {
    return Array.from(this.workflows.values());
  }
}

export const workflowManager = new WorkflowManager();

// =====================================================
// WEEKLY ORCHESTRATOR
// =====================================================

export class WeeklyOrchestrator {
  constructor(dataService, options) {
    const opts = options || {};
    this.dataService = dataService;
    this.supabase = opts.supabase;
    this.onProgress = opts.onProgress || (() => {});
    this.onAgentComplete = opts.onAgentComplete || (() => {});
    this.onError = opts.onError || console.error;
    this.openaiApiKey = opts.openaiApiKey || process.env.OPENAI_API_KEY;
  }

  async generate(reportWeek, options) {
    const opts = options || {};
    const reportId = opts.reportId || `weekly-${reportWeek}-${Date.now()}`;
    const startTime = Date.now();
    
    console.log(`[WeeklyOrchestrator] Starting generation for ${reportWeek}, reportId: ${reportId}`);
    
    // Create workflow tracking
    const workflow = workflowManager.create(reportId);
    
    // Start elapsed time tracker
    const elapsedInterval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      workflowManager.update(reportId, { elapsedSeconds: elapsed });
    }, 1000);

    const results = {};
    const errors = [];
    
    try {
      // Execute agents in phase order
      for (const phase of PHASE_ORDER) {
        const phaseAgents = AGENT_DEFINITIONS.filter(a => a.phase === phase);
        
        workflowManager.update(reportId, { currentPhase: phase });
        console.log(`[WeeklyOrchestrator] Starting phase: ${phase}`);
        
        for (const agentDef of phaseAgents) {
          try {
            // Update current agent
            workflowManager.update(reportId, {
              currentAgentId: agentDef.id,
              currentAgentName: agentDef.name,
            });
            
            // Calculate progress
            const completedCount = workflow.completedAgents.length;
            const progress = Math.round((completedCount / workflow.totalAgents) * 100);
            workflowManager.update(reportId, { progress });
            
            // Notify progress
            this.onProgress({
              reportId,
              progress,
              currentPhase: phase,
              currentAgentId: agentDef.id,
              currentAgentName: agentDef.name,
              completedAgents: workflow.completedAgents,
              elapsedSeconds: workflow.elapsedSeconds,
            });
            
            console.log(`[WeeklyOrchestrator] Running agent: ${agentDef.name}`);
            
            // Create and execute agent
            const agent = createAgent(agentDef.id);
            agent.setApiKey(this.openaiApiKey);
            
            const context = {
              dataService: this.dataService,
              reportWeek,
              previousResults: results,
              supabase: this.supabase,
            };
            
            const result = await agent.execute(context);
            results[agentDef.id] = result;
            
            // Mark agent complete
            workflow.completedAgents.push(agentDef.id);
            
            this.onAgentComplete({
              agentId: agentDef.id,
              agentName: agentDef.name,
              success: result.success,
              phase,
            });
            
          } catch (agentError) {
            console.error(`[WeeklyOrchestrator] Agent ${agentDef.id} failed:`, agentError.message);
            errors.push({ agent: agentDef.id, error: agentError.message });
            results[agentDef.id] = { success: false, error: agentError.message };
          }
        }
      }
      
      // Generate final report
      console.log('[WeeklyOrchestrator] Generating final report...');
      
      const compiledData = results.final_compiler?.data || { sections: results };
      const markdown = generateMarkdownReport(compiledData, reportWeek);
      const html = generateHTMLReport(compiledData, reportWeek);
      
      // Update workflow as complete
      clearInterval(elapsedInterval);
      const durationMs = Date.now() - startTime;
      
      workflowManager.update(reportId, {
        status: 'completed',
        progress: 100,
        currentAgentId: null,
        currentAgentName: null,
        elapsedSeconds: Math.floor(durationMs / 1000),
      });
      
      console.log(`[WeeklyOrchestrator] Generation complete in ${Math.floor(durationMs / 1000)}s`);
      
      return {
        success: true,
        reportId,
        reportWeek,
        report: compiledData,
        markdown,
        html,
        meta: {
          reportWeek,
          generatedAt: new Date().toISOString(),
          durationMs,
          agentsCompleted: workflow.completedAgents.length,
          agentsTotal: workflow.totalAgents,
          errorsCount: errors.length,
          version: VERSION,
        },
      };
      
    } catch (error) {
      clearInterval(elapsedInterval);
      
      console.error('[WeeklyOrchestrator] Generation failed:', error);
      
      workflowManager.update(reportId, {
        status: 'error',
        error: error.message,
      });
      
      this.onError(error);
      
      return {
        success: false,
        reportId,
        reportWeek,
        error: error.message,
        meta: {
          reportWeek,
          generatedAt: new Date().toISOString(),
          durationMs: Date.now() - startTime,
          agentsCompleted: workflow.completedAgents.length,
          agentsTotal: workflow.totalAgents,
          errorsCount: errors.length + 1,
          version: VERSION,
        },
      };
    }
  }
}

export default WeeklyOrchestrator;