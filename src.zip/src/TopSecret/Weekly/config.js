// =====================================================
// WEEKLY TACTICAL REVIEW - CONFIGURATION v10.0
// =====================================================
// Midapnim-Style Institutional Research Configuration
// v10.0 MAJOR UPDATE: 
//   - Added Weekly Event Calendar Agent (day-by-day)
//   - Added BofA Bull & Bear Indicator with components
//   - Added Market Breadth Analysis (MA50/MA200, A/D)
//   - Added Detailed Institutional Flows ($B specifics)
//   - Added CTA & Systematic Positioning Agent
// Location: src/TopSecret/Weekly/config.js
// =====================================================

export const VERSION = '10.0.0';
export const REPORT_NAME = 'Weekly Tactical Review';
export const REPORT_TITLE = 'Weekly Tactical Review';
export const COMPANY_NAME = 'FINOTAUR';
export const TAGLINE = 'Institutional-Grade Market Intelligence';

// =====================================================
// PHASES & WORKFLOW
// =====================================================
export const PHASES = {
  DATA_ACQUISITION: 'data_acquisition',
  WEEK_SUMMARY: 'week_summary',
  WEEK_AHEAD: 'week_ahead',
  TACTICAL_PREPARATION: 'tactical_preparation',
  TRADE_IDEAS: 'trade_ideas',
  QUALITY_ASSURANCE: 'quality_assurance',
};

export const PHASE_ORDER = [
  PHASES.DATA_ACQUISITION,
  PHASES.WEEK_SUMMARY,
  PHASES.WEEK_AHEAD,
  PHASES.TACTICAL_PREPARATION,
  PHASES.TRADE_IDEAS,
  PHASES.QUALITY_ASSURANCE,
];

export const PHASE_LABELS = {
  [PHASES.DATA_ACQUISITION]: 'Data Acquisition',
  [PHASES.WEEK_SUMMARY]: 'Week Summary',
  [PHASES.WEEK_AHEAD]: 'Week Ahead',
  [PHASES.TACTICAL_PREPARATION]: 'Tactical Preparation',
  [PHASES.TRADE_IDEAS]: 'Trade Ideas',
  [PHASES.QUALITY_ASSURANCE]: 'Quality Assurance',
};

// =====================================================
// TACTICAL PREPARATION SUBSECTIONS (Midapnim Style)
// =====================================================
export const TACTICAL_SUBSECTIONS = [
  {
    id: 'bofa_indicator',
    title: 'Sentiment & Risk Appetite',
    subtitle: 'BofA Bull & Bear Indicator Analysis',
    agent: 'bofa_indicator_agent',
    dataKey: 'bofa_indicator_agent',
    minParagraphs: 2,
    maxParagraphs: 3,
  },
  {
    id: 'market_breadth',
    title: 'Market Breadth',
    subtitle: 'Internal Market Health Assessment',
    agent: 'market_breadth_agent',
    dataKey: 'market_breadth_agent',
    minParagraphs: 2,
    maxParagraphs: 4,
  },
  {
    id: 'institutional_flows',
    title: 'Institutional Flows',
    subtitle: 'Who Is Buying, Who Is Selling',
    agent: 'institutional_flows_agent',
    dataKey: 'institutional_flows_agent',
    minParagraphs: 3,
    maxParagraphs: 5,
  },
  {
    id: 'cta_positioning',
    title: 'CTA & Systematic Positioning',
    subtitle: 'Trend-Following Exposure & Signals',
    agent: 'cta_positioning_agent',
    dataKey: 'cta_positioning_agent',
    minParagraphs: 2,
    maxParagraphs: 4,
  },
  {
    id: 'global_macro',
    title: 'Global Macro',
    subtitle: 'The Economy Continues to Run, But With Clear Constraints',
    agent: 'tactical_global_macro',
    dataKey: 'tactical_global_macro',
    minParagraphs: 4,
    maxParagraphs: 6,
  },
  {
    id: 'rates_policy',
    title: 'Rates & Monetary Policy',
    subtitle: 'Fed Trajectory and Rate Environment',
    agent: 'tactical_rates_policy',
    dataKey: 'tactical_rates_policy',
    minParagraphs: 3,
    maxParagraphs: 5,
  },
  {
    id: 'fiscal_risks',
    title: 'Fiscal Risks & Tail Scenarios',
    subtitle: 'What Could Disrupt the Base Case',
    agent: 'tactical_fiscal_risks',
    dataKey: 'tactical_fiscal_risks',
    minParagraphs: 3,
    maxParagraphs: 4,
  },
  {
    id: 'flows_sentiment',
    title: 'Flows, Sentiment & Risk Pricing',
    subtitle: 'Positioning and Market Psychology',
    agent: 'tactical_flows_sentiment',
    dataKey: 'tactical_flows_sentiment',
    minParagraphs: 4,
    maxParagraphs: 6,
  },
  {
    id: 'geographic',
    title: 'Geographic Considerations',
    subtitle: 'Regional Dynamics and Relative Value',
    agent: 'tactical_geographic',
    dataKey: 'tactical_geographic',
    minParagraphs: 3,
    maxParagraphs: 4,
  },
  {
    id: 'positioning',
    title: 'Positioning & Crowding',
    subtitle: 'Where the Market is Leaning',
    agent: 'tactical_positioning',
    dataKey: 'tactical_positioning',
    minParagraphs: 3,
    maxParagraphs: 5,
  },
  {
    id: 'synthesis',
    title: 'Tactical Bottom Line',
    subtitle: 'Putting It All Together',
    agent: 'tactical_synthesis',
    dataKey: 'tactical_synthesis',
    minParagraphs: 3,
    maxParagraphs: 4,
  },
];

// =====================================================
// AGENT DEFINITIONS (23 Agents - v10.0 Expanded)
// =====================================================
export const AGENT_DEFINITIONS = [
  // Phase 1: Data Acquisition (5 agents - added new data fetchers)
  {
    id: 'market_data_fetcher',
    name: 'Market Data Fetcher',
    phase: PHASES.DATA_ACQUISITION,
    dependencies: [],
    estimatedDuration: 15,
    description: 'Fetches price data for indices and sectors from Polygon API',
  },
  {
    id: 'news_aggregator',
    name: 'News Aggregator',
    phase: PHASES.DATA_ACQUISITION,
    dependencies: [],
    estimatedDuration: 20,
    description: 'Aggregates market news using Perplexity API',
  },
  {
    id: 'economic_calendar_fetcher',
    name: 'Economic Calendar Fetcher',
    phase: PHASES.DATA_ACQUISITION,
    dependencies: [],
    estimatedDuration: 15,
    description: 'Fetches upcoming economic events and earnings',
  },
  {
    id: 'sentiment_data_fetcher',
    name: 'Sentiment Data Fetcher',
    phase: PHASES.DATA_ACQUISITION,
    dependencies: [],
    estimatedDuration: 20,
    description: 'Fetches BofA Bull & Bear, Put/Call, VIX term structure, AAII data',
  },
  {
    id: 'flows_data_fetcher',
    name: 'Flows Data Fetcher',
    phase: PHASES.DATA_ACQUISITION,
    dependencies: [],
    estimatedDuration: 20,
    description: 'Fetches institutional flows, ETF flows, CTA positioning data',
  },

  // Phase 2: Week Summary (2 agents)
  {
    id: 'week_narrative_writer',
    name: 'Week Narrative Writer',
    phase: PHASES.WEEK_SUMMARY,
    dependencies: ['market_data_fetcher', 'news_aggregator'],
    estimatedDuration: 60,
    description: 'Writes "The Week That Was" narrative in Midapnim style',
  },
  {
    id: 'sector_rotation_analyzer',
    name: 'Sector Rotation Analyzer',
    phase: PHASES.WEEK_SUMMARY,
    dependencies: ['market_data_fetcher'],
    estimatedDuration: 40,
    description: 'Analyzes sector performance and rotation patterns',
  },

  // Phase 3: Week Ahead (3 agents - added detailed calendar)
  {
    id: 'weekly_calendar_agent',
    name: 'Weekly Event Calendar',
    phase: PHASES.WEEK_AHEAD,
    dependencies: ['economic_calendar_fetcher'],
    estimatedDuration: 45,
    description: 'Creates detailed day-by-day calendar: macro, earnings, dividends, investor days',
  },
  {
    id: 'macro_events_writer',
    name: 'Macro Events Writer',
    phase: PHASES.WEEK_AHEAD,
    dependencies: ['economic_calendar_fetcher', 'weekly_calendar_agent'],
    estimatedDuration: 45,
    description: 'Writes macro event calendar with deep impact analysis',
  },
  {
    id: 'micro_events_writer',
    name: 'Micro Events Writer',
    phase: PHASES.WEEK_AHEAD,
    dependencies: ['economic_calendar_fetcher', 'weekly_calendar_agent'],
    estimatedDuration: 35,
    description: 'Writes earnings and corporate events calendar',
  },

  // Phase 4: TACTICAL PREPARATION - v10.0 EXPANDED (12 agents)
  {
    id: 'bofa_indicator_agent',
    name: 'BofA Bull & Bear Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['sentiment_data_fetcher'],
    estimatedDuration: 40,
    description: 'Analyzes BofA Bull & Bear indicator with component breakdown',
  },
  {
    id: 'market_breadth_agent',
    name: 'Market Breadth Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['market_data_fetcher'],
    estimatedDuration: 40,
    description: 'Analyzes market internals: % above MA50/200, A/D line, breadth thrust',
  },
  {
    id: 'institutional_flows_agent',
    name: 'Institutional Flows Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['flows_data_fetcher'],
    estimatedDuration: 50,
    description: 'Detailed institutional flows: LOs, HFs, ETF flows by sector in $B',
  },
  {
    id: 'cta_positioning_agent',
    name: 'CTA & Systematic Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['flows_data_fetcher'],
    estimatedDuration: 45,
    description: 'CTA positioning, systematic signals, vol-control exposure',
  },
  {
    id: 'macro_insights',
    name: 'Macro Insights Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['news_aggregator', 'market_data_fetcher'],
    estimatedDuration: 60,
    description: 'Dynamic market themes: Breadth, CTA Flows, Mag7, Valuations, Gamma, China, BTC, Seasonality',
  },
  {
    id: 'tactical_global_macro',
    name: 'Global Macro Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['week_narrative_writer', 'macro_events_writer'],
    estimatedDuration: 60,
    description: 'Global macro environment, growth outlook, cycle positioning',
  },
  {
    id: 'tactical_rates_policy',
    name: 'Rates & Monetary Policy Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['tactical_global_macro'],
    estimatedDuration: 50,
    description: 'Interest rates, Fed policy, yield curve analysis',
  },
  {
    id: 'tactical_fiscal_risks',
    name: 'Fiscal & Tail Risks Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['tactical_global_macro'],
    estimatedDuration: 45,
    description: 'Fiscal policy, deficits, tail risk scenarios',
  },
  {
    id: 'tactical_flows_sentiment',
    name: 'Flows & Sentiment Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['market_data_fetcher', 'news_aggregator', 'bofa_indicator_agent', 'institutional_flows_agent'],
    estimatedDuration: 55,
    description: 'Fund flows, CTA positioning, sentiment indicators, risk pricing',
  },
  {
    id: 'tactical_geographic',
    name: 'Geographic Analysis',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['tactical_global_macro'],
    estimatedDuration: 40,
    description: 'Regional analysis: US, Europe, China, EM positioning',
  },
  {
    id: 'tactical_positioning',
    name: 'Positioning & Crowding Analyst',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['tactical_flows_sentiment', 'cta_positioning_agent'],
    estimatedDuration: 45,
    description: 'Hedge fund positioning, crowding risks, contrarian signals',
  },
  {
    id: 'tactical_synthesis',
    name: 'Tactical Synthesis',
    phase: PHASES.TACTICAL_PREPARATION,
    dependencies: ['tactical_global_macro', 'tactical_rates_policy', 'tactical_fiscal_risks', 'tactical_flows_sentiment', 'tactical_geographic', 'tactical_positioning', 'macro_insights', 'bofa_indicator_agent', 'market_breadth_agent', 'cta_positioning_agent'],
    estimatedDuration: 50,
    description: 'Synthesizes all tactical analysis into actionable view',
  },

  // Phase 5: Trade Ideas (2 agents)
  {
    id: 'trade_idea_generator',
    name: 'Trade Idea Generator',
    phase: PHASES.TRADE_IDEAS,
    dependencies: ['tactical_synthesis', 'sector_rotation_analyzer'],
    estimatedDuration: 50,
    description: 'Generates 2-3 trade ideas flowing from tactical analysis',
  },
  {
    id: 'risk_manager',
    name: 'Risk Manager',
    phase: PHASES.TRADE_IDEAS,
    dependencies: ['trade_idea_generator'],
    estimatedDuration: 25,
    description: 'Position sizing and risk/reward validation',
  },

  // Phase 6: Quality Assurance (2 agents)
  {
    id: 'coherence_checker',
    name: 'Coherence Checker',
    phase: PHASES.QUALITY_ASSURANCE,
    dependencies: ['trade_idea_generator', 'risk_manager'],
    estimatedDuration: 15,
    description: 'Validates narrative coherence and style compliance',
  },
  {
    id: 'final_compiler',
    name: 'Final Compiler',
    phase: PHASES.QUALITY_ASSURANCE,
    dependencies: ['coherence_checker'],
    estimatedDuration: 10,
    description: 'Compiles all sections into final report',
  },
];

// =====================================================
// WRITING MANDATE - MIDAPNIM STYLE v10.0
// =====================================================
export const WRITING_MANDATE = {
  PHILOSOPHY: `
    You are NOT an AI writing a report. You ARE a senior analyst at a top-tier 
    institutional research firm, dictating your weekly market observations to 
    a colleague. Your voice is confident, direct, and analytical. You have 
    opinions. You see patterns others miss. You connect dots.
    
    Midapnim's signature approach:
    1. Observe something specific in the market
    2. Explain why it matters (with historical context)
    3. Tell the reader what to do about it
    
    Every paragraph earns its place by adding analytical value.
    Every section connects to a CENTRAL THESIS for the week.
  `,

  CENTRAL_THESIS: `
    Each weekly report MUST have a unifying central thesis that ties all sections together.
    Examples of central theses:
    - "Run-it-hot environment - growth continues but with clear constraints"
    - "Defensive rotation with Energy leadership signals late-cycle positioning"  
    - "Repricing of risk premiums as Fed flexibility narrows"
    
    Every section should reference back to this thesis. The reader should finish
    the report with ONE clear takeaway about what the market is telling us.
  `,

  NEVER: [
    'Use emojis anywhere',
    'Use bullet points in prose sections',
    'Use markdown symbols (#, *, **) in output',
    'Write paragraphs longer than 4 sentences',
    'Use filler phrases: "it is worth noting", "it should be mentioned", "interestingly"',
    'Use vague language: "interesting", "nice", "good", "significant movement"',
    'Use marketing language: "exciting", "amazing", "incredible"',
    'Use exclamation marks',
    'Start paragraphs with "In conclusion", "To summarize", "Overall"',
    'Reference AI, automation, or that content is generated',
    'Repeat the same idea using different words',
    'Use first person (I, we, our) - except for "we are watching" style',
    'Write incomplete sentences or fragments',
    'Write standalone numbers without context',
    'Fragment decimal numbers',
    'Use generic transitions: "Furthermore", "Additionally", "Moreover"',
    'Hedge excessively: "may potentially", "could possibly"',
    'Use passive voice when active is clearer',
    'Present data without interpretation',
    'List facts without connecting them to the thesis',
  ],

  ALWAYS: [
    'Write SHORT paragraphs - STRICT MAX 4 sentences',
    'ONE main idea per paragraph - no exceptions',
    'Lead with the insight, not the setup',
    'Include COMPLETE number context: "XLE gained 2.56% to close at $95.40"',
    'Say it once, say it clearly - no repetition',
    'Connect every observation to an actionable implication',
    'Use active voice: "Markets sold off" not "A selloff was observed"',
    'Be specific: "Technology fell on rate fears" not "Markets were mixed"',
    'Give your view - Midapnim analysts have opinions',
    'Explain WHY something matters, not just WHAT happened',
    'Reference the central thesis in each major section',
    'Include historical context for key claims',
    'Use contrarian framing when consensus is one-sided',
  ],

  NUMBER_RULES: {
    prices: 'Always: "SPY closed at $683.17" - include ticker, $, full decimal',
    percentages: 'Always: "XLE rose 2.56%" - include ticker/name before number',
    changes: 'Complete context: "VIX spiked 8.18% to 16.23, signaling..."',
    prohibition: 'NEVER: standalone "64%." or "closed at 683. 17"',
    decimals: 'NEVER fragment: "$683.17" not "683. 17"',
    comparison: 'Both sides: "XLE (+2.56%) vs XLY (-2.64%)"',
    indicators: 'Name the source: "The BofA Bull & Bear at 7.2..." not just "sentiment is high"',
    flows: 'Be specific: "Long-only funds sold $3.2 billion net" not "LOs were sellers"',
  },

  PHRASES: {
    insight_openers: [
      'What stands out this week:',
      'The story here is not X, but Y.',
      'This is not a coincidence.',
      'The pattern is clear:',
      'Exactly at this point, the risk begins to appear.',
    ],
    significance: [
      'This matters because...',
      'The implication:',
      'Why this is important:',
      'The key issue is not X, but Y.',
    ],
    contrast: [
      'From one side... from the other side...',
      'On the surface... beneath the surface...',
      'The headline says X. The reality is Y.',
      'This is not panic - it is repositioning.',
    ],
    action: [
      'The tactical implication:',
      'For positioning:',
      'The question investors should ask:',
      'This is not a call to exit - it is a call to be selective.',
    ],
    evidence: [
      'Evidence from flows suggests...',
      'Data confirms...',
      'Price action tells us...',
      'The indicator picture deserves close attention.',
    ],
    forward_looking: [
      'Watching for:',
      'The trigger to watch:',
      'If X happens, expect Y.',
      'Historically, when this pattern emerges...',
    ],
    contrarian: [
      'Exactly at this point...',
      'When everyone has already rotated...',
      'Such consensus creates contrarian risk.',
      'When protection is this cheap and sentiment this sanguine...',
    ],
  },

  PARAGRAPH_STRUCTURE: {
    maxSentences: 4,
    strictEnforcement: true,
    pattern: 'OBSERVATION → CONTEXT → SIGNIFICANCE → IMPLICATION',
  },

  SECTION_GUIDES: {
    week_summary: {
      goal: 'Set the scene - what happened and why it matters',
      structure: '6 paragraphs covering: headline, beneath surface, drivers, sectors, indicators, implications',
      tone: 'Confident narrator explaining the week to a sophisticated investor',
      mustInclude: 'Central thesis introduction, BofA Bull/Bear reference, put/call ratio',
    },
    sector_rotation: {
      goal: 'Explain what the sector moves MEAN, not just what they were',
      structure: '3 paragraphs: pattern recognition, laggard analysis, tactical positioning',
      tone: 'Analytical - connecting sector moves to macro themes and central thesis',
      mustInclude: 'Historical context for rotation pattern, specific percentages for all sectors mentioned',
    },
    weekly_calendar: {
      goal: 'Comprehensive day-by-day schedule of market-moving events',
      structure: 'By day: Monday through Friday with all events categorized',
      tone: 'Reference material - clear, organized, actionable',
      mustInclude: 'Macro releases with previous/forecast, earnings with estimates, dividends, investor days',
    },
    events_calendar: {
      goal: 'Each event gets FULL ANALYSIS: previous, forecast, why it matters, if-then scenarios',
      structure: 'By day, each event with 4-5 sentence analysis paragraph',
      tone: 'Practical - helping reader prepare with clear if-then scenarios',
      mustInclude: 'Previous reading, forecast, market implications, deviation scenarios',
    },
    bofa_indicator: {
      goal: 'Explain BofA Bull & Bear reading with component breakdown',
      structure: 'Current reading, historical context, component analysis, tactical implication',
      tone: 'Quantitative but accessible - translate numbers into positioning guidance',
      mustInclude: 'Current level, sell/buy signals, component breakdown table data',
    },
    market_breadth: {
      goal: 'Show health beneath index surface - participation quality',
      structure: '% above MA50/200, A/D line trend, breadth thrust signals',
      tone: 'Technical but meaningful - what breadth tells us about sustainability',
      mustInclude: '% above 50-day, % above 200-day, A/D line direction, historical comparison',
    },
    institutional_flows: {
      goal: 'Who is buying, who is selling, how much - specific dollar amounts',
      structure: 'LO flows, HF flows, ETF flows by sector, regional flows',
      tone: 'Data-rich but interpreted - what flows tell us about conviction',
      mustInclude: 'Specific $B amounts, sector breakdown, week-over-week change',
    },
    cta_positioning: {
      goal: 'Where systematic strategies are positioned and what triggers changes',
      structure: 'Current exposure level, vs historical range, trigger levels for add/reduce',
      tone: 'Technical - understanding mechanical flows that can amplify moves',
      mustInclude: 'Current exposure %, historical percentile, key trigger levels',
    },
    tactical_preparation: {
      goal: 'DEEP 11-subsection analysis matching Midapnim depth',
      structure: 'BofA → Breadth → Flows → CTA → Global Macro → Rates → Fiscal Risks → Flows/Sentiment → Geographic → Positioning → Synthesis',
      tone: 'Senior analyst perspective with specific data and historical precedent',
      mustInclude: 'BofA indicator with components, breadth metrics, specific flow data, CTA levels, put/call ratio, hedge fund positioning, implied correlation',
    },
    trade_ideas: {
      goal: 'Trades that FLOW from tactical analysis, not standalone',
      structure: 'Each trade as 2-3 paragraphs connecting to tactical themes',
      tone: 'Direct and confident - this is what the analysis naturally suggests',
      mustInclude: 'Clear connection to thesis, catalyst, risk scenario, historical context',
    },
  },

  TARGETS: {
    maxParagraphSentences: 4,
    maxParagraphWords: 80,
    dataPointsPerParagraph: 1,
    tacticalSectionParagraphs: 35,
    minAnalyticalDepth: 3,
    historicalReferencesPerSection: 2,
    indicatorMentionsMinimum: 8,
  },
};

// =====================================================
// SENTIMENT INDICATORS (Required for Midapnim style)
// =====================================================
export const SENTIMENT_INDICATORS = {
  bofa_bull_bear: {
    name: 'BofA Bull & Bear Indicator',
    extreme_bullish: 8.0,
    extreme_bearish: 2.0,
    neutral: 5.0,
    sell_signal: 8.0,
    buy_signal: 2.0,
    components: [
      'Hedge Fund Positioning',
      'Equity Flows',
      'Bond Flows',
      'Credit Technicals',
      'Stock Index Breadth',
      'FMS Cash Levels',
    ],
  },
  put_call_ratio: {
    name: 'Put/Call Ratio',
    fear_threshold: 1.2,
    complacency_threshold: 0.7,
  },
  vix: {
    name: 'VIX',
    elevated: 20,
    extreme: 30,
    complacent: 12,
  },
  aaii_sentiment: {
    name: 'AAII Sentiment Survey',
    extreme_bullish: 55,
    extreme_bearish: 25,
  },
  implied_correlation: {
    name: 'Implied Correlation Index',
    description: 'Low readings suggest dispersion, high readings suggest systematic risk',
  },
  hedge_fund_exposure: {
    name: 'Hedge Fund Net Equity Exposure',
    description: 'Gross and net exposure levels from prime brokerage data',
  },
  cta_positioning: {
    name: 'CTA Positioning',
    description: 'Systematic trend-following exposure levels',
    max_long: 100,
    max_short: -100,
    neutral: 0,
  },
};

// =====================================================
// BOFA BULL & BEAR COMPONENT DEFINITIONS
// =====================================================
export const BOFA_COMPONENTS = {
  hedge_fund_positioning: {
    name: 'Hedge Fund Positioning',
    weight: 0.20,
    bullish_threshold: 70,
    bearish_threshold: 30,
  },
  equity_flows: {
    name: 'Equity Flows',
    weight: 0.15,
    bullish_threshold: 80,
    bearish_threshold: 20,
  },
  bond_flows: {
    name: 'Bond Flows',
    weight: 0.15,
    bullish_threshold: 75,
    bearish_threshold: 25,
  },
  credit_technicals: {
    name: 'Credit Market Technicals',
    weight: 0.15,
    bullish_threshold: 70,
    bearish_threshold: 30,
  },
  stock_breadth: {
    name: 'Global Stock Index Breadth',
    weight: 0.20,
    bullish_threshold: 75,
    bearish_threshold: 25,
  },
  fms_positioning: {
    name: 'FMS Equity Allocation',
    weight: 0.15,
    bullish_threshold: 65,
    bearish_threshold: 35,
  },
};

// =====================================================
// MARKET BREADTH THRESHOLDS
// =====================================================
export const BREADTH_THRESHOLDS = {
  pct_above_ma50: {
    name: '% Above 50-Day MA',
    overbought: 80,
    healthy: 60,
    oversold: 30,
    extreme_oversold: 20,
  },
  pct_above_ma200: {
    name: '% Above 200-Day MA',
    strong: 70,
    healthy: 55,
    weak: 40,
    bear_market: 30,
  },
  advance_decline: {
    name: 'Advance/Decline Line',
    description: 'New highs vs new lows, cumulative breadth',
  },
  mcclellan: {
    name: 'McClellan Oscillator',
    overbought: 60,
    oversold: -60,
  },
};

// =====================================================
// CTA POSITIONING LEVELS
// =====================================================
export const CTA_LEVELS = {
  equity_exposure: {
    max_long: '+100%',
    current_typical_range: '+40% to +80%',
    neutral: '0%',
    max_short: '-100%',
  },
  trigger_levels: {
    add_on_rally: 'SPY above 20-day MA with positive momentum',
    reduce_on_decline: 'SPY below 20-day MA with negative momentum',
    max_exposure_threshold: '3 consecutive weeks above 50-day MA',
  },
  historical_context: {
    percentile_90: '+85%',
    percentile_75: '+65%',
    percentile_50: '+45%',
    percentile_25: '+20%',
    percentile_10: '-10%',
  },
};

// =====================================================
// INSTITUTIONAL FLOW CATEGORIES
// =====================================================
export const FLOW_CATEGORIES = {
  long_only: {
    name: 'Long-Only Funds',
    abbreviation: 'LOs',
    typical_weekly_range: '$1B - $5B',
  },
  hedge_funds: {
    name: 'Hedge Funds',
    abbreviation: 'HFs',
    typical_weekly_range: '$500M - $3B',
  },
  etf_flows: {
    name: 'ETF Flows',
    abbreviation: 'ETFs',
    typical_weekly_range: '$2B - $10B',
  },
  retail: {
    name: 'Retail Flows',
    abbreviation: 'Retail',
    typical_weekly_range: '$500M - $2B',
  },
  sectors: [
    'Technology', 'Financials', 'Energy', 'Healthcare', 
    'Industrials', 'Consumer Discretionary', 'Consumer Staples',
    'Utilities', 'Materials', 'Real Estate', 'Communication Services'
  ],
};

// =====================================================
// MARKET DATA SYMBOLS
// =====================================================
export const MARKET_INDICES = {
  SPY: { name: 'S&P 500', ticker: 'SPY', fullName: 'SPDR S&P 500 ETF Trust' },
  QQQ: { name: 'Nasdaq 100', ticker: 'QQQ', fullName: 'Invesco QQQ Trust' },
  IWM: { name: 'Russell 2000', ticker: 'IWM', fullName: 'iShares Russell 2000 ETF' },
  DIA: { name: 'Dow Jones', ticker: 'DIA', fullName: 'SPDR Dow Jones Industrial Average ETF' },
  VIX: { name: 'VIX', ticker: 'VIX', fullName: 'CBOE Volatility Index' },
  GLD: { name: 'Gold', ticker: 'GLD', fullName: 'SPDR Gold Trust' },
};

export const EXTENDED_INDICES = {
  TLT: { name: '20+ Year Treasury', ticker: 'TLT', fullName: 'iShares 20+ Year Treasury Bond ETF' },
  IEF: { name: '7-10 Year Treasury', ticker: 'IEF', fullName: 'iShares 7-10 Year Treasury Bond ETF' },
  USO: { name: 'Crude Oil', ticker: 'USO', fullName: 'United States Oil Fund' },
  UUP: { name: 'US Dollar', ticker: 'UUP', fullName: 'Invesco DB US Dollar Index Bullish Fund' },
  HYG: { name: 'High Yield', ticker: 'HYG', fullName: 'iShares iBoxx High Yield Corporate Bond ETF' },
  LQD: { name: 'Investment Grade', ticker: 'LQD', fullName: 'iShares iBoxx Investment Grade Corporate Bond ETF' },
  EEM: { name: 'Emerging Markets', ticker: 'EEM', fullName: 'iShares MSCI Emerging Markets ETF' },
  EFA: { name: 'EAFE', ticker: 'EFA', fullName: 'iShares MSCI EAFE ETF' },
  FXI: { name: 'China Large-Cap', ticker: 'FXI', fullName: 'iShares China Large-Cap ETF' },
};

export const SECTOR_ETFS = {
  XLK: { name: 'Technology', ticker: 'XLK', fullName: 'Technology Select Sector SPDR' },
  XLF: { name: 'Financials', ticker: 'XLF', fullName: 'Financial Select Sector SPDR' },
  XLE: { name: 'Energy', ticker: 'XLE', fullName: 'Energy Select Sector SPDR' },
  XLV: { name: 'Healthcare', ticker: 'XLV', fullName: 'Health Care Select Sector SPDR' },
  XLI: { name: 'Industrials', ticker: 'XLI', fullName: 'Industrial Select Sector SPDR' },
  XLP: { name: 'Consumer Staples', ticker: 'XLP', fullName: 'Consumer Staples Select Sector SPDR' },
  XLY: { name: 'Consumer Disc.', ticker: 'XLY', fullName: 'Consumer Discretionary Select Sector SPDR' },
  XLU: { name: 'Utilities', ticker: 'XLU', fullName: 'Utilities Select Sector SPDR' },
  XLB: { name: 'Materials', ticker: 'XLB', fullName: 'Materials Select Sector SPDR' },
  XLRE: { name: 'Real Estate', ticker: 'XLRE', fullName: 'Real Estate Select Sector SPDR' },
  XLC: { name: 'Comm. Services', ticker: 'XLC', fullName: 'Communication Services Select Sector SPDR' },
};

export const getSectorDisplayName = (symbol) => {
  const sector = SECTOR_ETFS[symbol];
  return sector ? `${sector.name} (${symbol})` : symbol;
};

export const getIndexDisplayName = (symbol) => {
  const index = MARKET_INDICES[symbol];
  return index ? `${index.name} (${symbol})` : symbol;
};

// =====================================================
// PDF STYLING (Midapnim-Inspired)
// =====================================================
export const PDF_FONTS = {
  title: 'Helvetica-Bold',
  heading: 'Helvetica-Bold',
  body: 'Helvetica',
  bold: 'Helvetica-Bold',
  caption: 'Helvetica',
};

export const PDF_STYLES = {
  colors: {
    primaryDark: '#0A1628',
    primaryBlue: '#1E3A8A',
    accentGold: '#C9A646',
    textDark: '#1a1a2e',
    textGray: '#4a4a6a',
    bgLight: '#F8F9FA',
    positive: '#22C55E',
    negative: '#EF4444',
    neutral: '#64748B',
    tableHeader: '#1E3A8A',
    tableAlt: '#F1F5F9',
  },
  fonts: {
    title: 'Helvetica-Bold',
    heading: 'Helvetica-Bold',
    body: 'Helvetica',
    caption: 'Helvetica',
  },
  spacing: {
    sectionGap: 24,
    paragraphGap: 12,
    tableGap: 16,
  },
};

// =====================================================
// REPORT SECTIONS - v10.0 EXPANDED
// =====================================================
export const REPORT_SECTIONS = [
  { id: 'cover', title: 'Cover Page', pageBreakAfter: true },
  {
    id: 'week_summary',
    title: 'The Week That Was',
    subtitle: 'Weekly Market Review & Sector Analysis',
    agents: ['week_narrative_writer', 'sector_rotation_analyzer'],
    hasCharts: true,
    hasTables: false,
    pageBreakAfter: false,
  },
  {
    id: 'weekly_calendar',
    title: 'This Week at a Glance',
    subtitle: 'Day-by-Day Event Calendar',
    agents: ['weekly_calendar_agent'],
    hasCalendarTable: true,
    pageBreakAfter: false,
  },
  {
    id: 'events_week',
    title: 'Events This Week',
    subtitle: 'Key Data Releases & Market Catalysts',
    agents: ['macro_events_writer', 'micro_events_writer'],
    hasTables: false,
    pageBreakAfter: false,
  },
  {
    id: 'tactical_preparation',
    title: 'Tactical Preparation',
    subtitle: 'Markets & Macro Analysis',
    agents: [
      'bofa_indicator_agent',
      'market_breadth_agent',
      'institutional_flows_agent',
      'cta_positioning_agent',
      'tactical_global_macro',
      'tactical_rates_policy',
      'tactical_fiscal_risks',
      'tactical_flows_sentiment',
      'tactical_geographic',
      'tactical_positioning',
      'tactical_synthesis',
    ],
    subsections: TACTICAL_SUBSECTIONS,
    hasCharts: true,
    pageBreakAfter: false,
  },
  {
    id: 'trade_ideas',
    title: 'Trade Ideas',
    subtitle: 'Actionable Opportunities',
    agents: ['trade_idea_generator', 'risk_manager'],
    hasTables: false,
    pageBreakAfter: false,
  },
  { id: 'disclaimer', title: 'Disclaimer', pageBreakAfter: false },
];

// =====================================================
// CHART CONFIGURATION - v10.0 EXPANDED
// =====================================================
export const CHART_CONFIG = {
  indexPerformance: {
    type: 'bar',
    title: 'Weekly Return (%)',
    dataKey: 'weeklyReturn',
    colorPositive: '#22C55E',
    colorNegative: '#EF4444',
    placement: 'page2',
  },
  sectorRotation: {
    type: 'horizontalBar',
    title: 'Sector Performance (1 Week)',
    dataKey: 'weeklyReturn',
    colorPositive: '#22C55E',
    colorNegative: '#EF4444',
    colorNeutral: '#F59E0B',
    placement: 'page2',
  },
  bofaBullBear: {
    type: 'gauge',
    title: 'BofA Bull & Bear Indicator',
    min: 0,
    max: 10,
    zones: [
      { from: 0, to: 2, color: '#22C55E', label: 'Buy Signal' },
      { from: 2, to: 4, color: '#86EFAC', label: 'Bearish' },
      { from: 4, to: 6, color: '#FCD34D', label: 'Neutral' },
      { from: 6, to: 8, color: '#FCA5A5', label: 'Bullish' },
      { from: 8, to: 10, color: '#EF4444', label: 'Sell Signal' },
    ],
    placement: 'tactical',
  },
  marketBreadth: {
    type: 'line',
    title: 'Market Breadth - % Above Moving Averages',
    lines: [
      { key: 'pctAbove50', label: '% Above 50-DMA', color: '#3B82F6' },
      { key: 'pctAbove200', label: '% Above 200-DMA', color: '#C9A646' },
    ],
    placement: 'tactical',
  },
  vixTrend: {
    type: 'line',
    title: 'VIX',
    color: '#C9A646',
    fill: true,
    placement: 'tactical',
  },
  spyTrend: {
    type: 'line',
    title: 'SPY',
    color: '#1E3A8A',
    fill: true,
    placement: 'tactical',
  },
};

// =====================================================
// DISCLAIMER TEXT
// =====================================================
export const DISCLAIMER_TEXT = {
  short: 'This report is for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. © 2026 FINOTAUR. All Rights Reserved.',
  
  full: `GENERAL INFORMATION ONLY

This report is produced by FINOTAUR for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.

NOT INVESTMENT ADVICE

This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. FINOTAUR is NOT a registered investment adviser or broker-dealer.

RISK DISCLOSURE

Trading and investing involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital.

NO GUARANTEES

FINOTAUR makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.

YOUR RESPONSIBILITY

You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.

LIMITATION OF LIABILITY

FINOTAUR shall NOT be liable for any damages arising from your use of or reliance on this report.

COPYRIGHT WARNING

This report is the exclusive intellectual property of FINOTAUR. Unauthorized reproduction is strictly prohibited.

© 2026 FINOTAUR. All Rights Reserved.`,
};

// =====================================================
// API CONFIGURATION
// =====================================================
export const API_CONFIG = {
  openai: {
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 2500,
  },
  perplexity: {
    model: 'llama-3.1-sonar-large-128k-online',
    maxTokens: 2500,
  },
  polygon: {
    baseUrl: 'https://api.polygon.io',
  },
  quickchart: {
    baseUrl: 'https://quickchart.io/chart',
    width: 500,
    height: 300,
    backgroundColor: 'white',
  },
};

// =====================================================
// MARKET REGIMES
// =====================================================
export const MARKET_REGIMES = {
  RISK_ON: 'risk_on',
  RISK_OFF: 'risk_off',
  NEUTRAL: 'neutral',
  ROTATION: 'rotation',
  TRANSITION: 'transition',
  VOLATILE: 'volatile',
  LATE_CYCLE: 'late_cycle',
  RUN_HOT: 'run_hot',
};

export const REGIME_LABELS = {
  risk_on: 'Risk-On',
  risk_off: 'Risk-Off',
  neutral: 'Neutral',
  rotation: 'Rotation',
  transition: 'Transition',
  volatile: 'Volatile',
  late_cycle: 'Late-Cycle',
  run_hot: 'Run-It-Hot',
};

export default {
  VERSION,
  REPORT_NAME,
  REPORT_TITLE,
  COMPANY_NAME,
  TAGLINE,
  PHASES,
  PHASE_ORDER,
  PHASE_LABELS,
  AGENT_DEFINITIONS,
  TACTICAL_SUBSECTIONS,
  WRITING_MANDATE,
  SENTIMENT_INDICATORS,
  BOFA_COMPONENTS,
  BREADTH_THRESHOLDS,
  CTA_LEVELS,
  FLOW_CATEGORIES,
  MARKET_INDICES,
  EXTENDED_INDICES,
  SECTOR_ETFS,
  getSectorDisplayName,
  getIndexDisplayName,
  PDF_FONTS,
  PDF_STYLES,
  REPORT_SECTIONS,
  CHART_CONFIG,
  DISCLAIMER_TEXT,
  API_CONFIG,
  MARKET_REGIMES,
  REGIME_LABELS,
};