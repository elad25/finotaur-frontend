// =====================================================
// WEEKLY TACTICAL REVIEW - PDF GENERATOR v12.0
// =====================================================
// v12.0 Changes:
//   - NEW: Weekly Calendar Table (day-by-day)
//   - NEW: BofA Bull & Bear Section with components table
//   - NEW: Market Breadth Section with metrics
//   - NEW: Institutional Flows Section with table
//   - NEW: CTA Positioning Section with gauge
//   - UPDATED: TACTICAL_SUBSECTIONS expanded to 11 items
// v11.4: Removed Index Performance chart, cleaner layout
// v11.3: News-driven narrative explaining WHY markets moved
// v11.2: Index Performance Table, spacing improvements
// v11.1: All black titles, increased spacing
// =====================================================

import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import {
  VERSION,
  REPORT_TITLE,
  COMPANY_NAME,
  DISCLAIMER_TEXT,
  PDF_FONTS,
  TACTICAL_SUBSECTIONS as CONFIG_TACTICAL_SUBSECTIONS,
} from './config.js';

// ============ COLOR SCHEMES ============
const DARK = {
  background: '#000000',
  gold: '#C9A646',
  goldDark: '#A68A3A',
  goldLight: '#E5D5A0',
  textWhite: '#FFFFFF',
  textLight: '#E0E0E0',
  textMuted: '#888888',
  borderRed: '#DC2626',
};

const LIGHT = {
  background: '#FFFFFF',
  primary: '#1E3A8A',
  secondary: '#2563EB',
  accent: '#C9A646',
  textDark: '#1A1A1A',
  textMedium: '#374151',
  textMuted: '#6B7280',
  positive: '#059669',
  negative: '#DC2626',
  tableBorder: '#E5E7EB',
  tableHeader: '#F3F4F6',
  tableAlt: '#F9FAFB',
  highlight: '#FEF3C7',
};

// ============ TYPOGRAPHY ============
const FONT_DIR = path.join(process.cwd(), 'static', 'fonts');
const INTER_REGULAR = path.join(FONT_DIR, 'Inter_18pt-Regular.ttf');
const INTER_BOLD = path.join(FONT_DIR, 'Inter_18pt-Bold.ttf');
const hasInterFont = fs.existsSync(INTER_REGULAR) && fs.existsSync(INTER_BOLD);

const FONTS = {
  title: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  heading: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  body: hasInterFont ? 'Inter-Regular' : 'Helvetica',
  bold: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
};

function registerFonts(doc) {
  if (hasInterFont) {
    doc.registerFont('Inter-Regular', INTER_REGULAR);
    doc.registerFont('Inter-Bold', INTER_BOLD);
  }
}

// ============ PAGE LAYOUT ============
const PAGE = {
  width: 612,
  height: 792,
  marginLeft: 50,
  marginRight: 50,
  marginTop: 60,
  marginBottom: 50,
  get contentWidth() { return this.width - this.marginLeft - this.marginRight; },
  contentTop: 70,
  footerY: 750,
  safeBottom: 720,
};

// ============ UTILITIES ============
function cleanText(text) {
  if (!text) return '';
  return String(text)
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/#{1,6}\s*/g, '')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function formatNumber(num) {
  if (num === null || num === undefined) return '-';
  const n = Number(num);
  if (isNaN(n)) return '-';
  if (Math.abs(n) >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return n.toFixed(2);
}

function formatPercent(num) {
  if (num === null || num === undefined) return '-';
  const n = Number(num);
  if (isNaN(n)) return '-';
  const prefix = n > 0 ? '+' : '';
  return prefix + n.toFixed(2) + '%';
}

function formatDateShort(dateStr) {
  try {
    const date = new Date(dateStr);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return `${day}.${month}.${year}`;
  } catch {
    return new Date().toLocaleDateString('en-GB').replace(/\//g, '.');
  }
}

function findLogo(customPath) {
  const searchPaths = [
    customPath,
    './static/images/logo.png',
    './static/logo.png',
    './logo.png',
    path.join(process.cwd(), 'static', 'images', 'logo.png'),
  ].filter(Boolean);
  
  for (const p of searchPaths) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// =====================================================
// TEXT PROCESSING - FIXED v8.0
// =====================================================

// Protect decimal numbers from being split
function protectDecimals(text) {
  if (!text) return text;
  return text.replace(/(\$?\d+)\.(\d+)/g, '$1__DECIMAL__$2');
}

// Restore decimal numbers after processing
function restoreDecimals(text) {
  if (!text) return text;
  return text.replace(/__DECIMAL__/g, '.');
}

// FIXED: Split sentences without cutting decimal numbers
function splitIntoSentences(text) {
  if (!text) return [];
  
  let safeText = protectDecimals(text);
  const sentences = safeText.split(/(?<=[.!?])\s+(?=[A-Z])/);
  return sentences.map(s => restoreDecimals(s.trim())).filter(s => s.length > 0);
}

// FIXED: Enforce max sentences without cutting numbers
function enforceMaxSentences(paragraph, maxSentences = 4) {
  if (!paragraph) return '';
  
  const sentences = splitIntoSentences(paragraph);
  
  if (sentences.length <= maxSentences) {
    return paragraph;
  }
  
  return sentences.slice(0, maxSentences).join(' ').trim();
}

function splitIntoParagraphs(text) {
  if (!text) return [];
  const cleaned = cleanText(text);
  return cleaned.split(/\n\n+/).filter(p => p.trim().length > 0);
}

function needsPageBreak(currentY, requiredSpace) {
  return currentY + requiredSpace > PAGE.safeBottom;
}

// =====================================================
// COVER PAGE (Dark Theme)
// =====================================================
function drawCoverPage(doc, reportDate, logo) {
  doc.addPage();
  
  doc.rect(0, 0, PAGE.width, PAGE.height).fill(DARK.background);

  const centerX = PAGE.width / 2;
  const frameMargin = 25;

  doc.strokeColor(DARK.gold)
     .lineWidth(3)
     .rect(frameMargin, frameMargin, PAGE.width - (frameMargin * 2), PAGE.height - (frameMargin * 2))
     .stroke();
  
  doc.strokeColor(DARK.gold)
     .lineWidth(0.5)
     .rect(frameMargin + 8, frameMargin + 8, PAGE.width - (frameMargin * 2) - 16, PAGE.height - (frameMargin * 2) - 16)
     .stroke();

  function centerText(text, y, fontSize, font, color) {
    doc.font(font).fontSize(fontSize);
    const width = doc.widthOfString(text);
    doc.fillColor(color).text(text, centerX - width/2, y, { lineBreak: false });
  }

  let y = 100;
  
  centerText(COMPANY_NAME, y, 48, FONTS.bold, DARK.gold);

  const textWidth = 220;
  doc.strokeColor(DARK.gold)
     .lineWidth(3)
     .moveTo(centerX - textWidth/2, y + 52)
     .lineTo(centerX + textWidth/2, y + 52)
     .stroke();

  centerText('Institutional-Grade Market Intelligence', y + 68, 10, FONTS.body, DARK.textMuted);

  let logoY = 210;
  if (logo) {
    try {
      const logoWidth = 200;
      const logoX = centerX - logoWidth/2;
      if (Buffer.isBuffer(logo)) {
        doc.image(logo, logoX, logoY, { width: logoWidth, height: 160 });
      } else if (typeof logo === 'string' && fs.existsSync(logo)) {
        doc.image(logo, logoX, logoY, { width: logoWidth, height: 160 });
      }
      logoY += 200;
    } catch (e) {
      logoY += 40;
    }
  } else {
    logoY += 40;
  }

  const titleY = logoY + 20;
  
  doc.strokeColor(DARK.gold)
     .lineWidth(1)
     .moveTo(centerX - 150, titleY - 35)
     .lineTo(centerX + 150, titleY - 35)
     .stroke();

  const diamondY = titleY - 25;
  const diamondSize = 6;
  doc.fillColor(DARK.gold)
     .moveTo(centerX, diamondY - diamondSize)
     .lineTo(centerX + diamondSize, diamondY)
     .lineTo(centerX, diamondY + diamondSize)
     .lineTo(centerX - diamondSize, diamondY)
     .closePath()
     .fill();

  centerText('INSTITUTIONAL RESEARCH', titleY - 8, 11, FONTS.bold, DARK.gold);
  centerText('Weekly Tactical Review', titleY + 20, 36, FONTS.title, DARK.textWhite);

  doc.strokeColor(DARK.gold)
     .lineWidth(2)
     .moveTo(centerX - 180, titleY + 68)
     .lineTo(centerX + 180, titleY + 68)
     .stroke();

  const dateDisplay = formatDateShort(reportDate);
  centerText(dateDisplay, titleY + 88, 20, FONTS.body, DARK.textWhite);
  centerText('Macro Signal • Sector Shifts • Trade Implications', titleY + 120, 11, FONTS.body, DARK.textMuted);

  doc.rect(0, PAGE.height - 5, PAGE.width, 5).fill(DARK.gold);
  centerText(`© ${new Date().getFullYear()} ${COMPANY_NAME}`, PAGE.height - 25, 8, FONTS.body, DARK.textMuted);
}

// =====================================================
// DISCLAIMER PAGE (Dark Theme - At End)
// =====================================================
function drawDisclaimerPage(doc, logo) {
  doc.addPage();
  
  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  
  const frameMargin = 25;
  const frameWidth = PAGE.width - (frameMargin * 2);
  const frameHeight = PAGE.height - (frameMargin * 2);
  const centerX = PAGE.width / 2;
  const contentMargin = frameMargin + 35;
  const contentWidth = frameWidth - 70;
  
  function centerText(text, y, fontSize, font, color) {
    doc.font(font).fontSize(fontSize);
    const width = doc.widthOfString(text);
    doc.fillColor(color).text(text, centerX - width/2, y, { lineBreak: false });
  }
  
  doc.strokeColor(DARK.gold)
     .lineWidth(3)
     .rect(frameMargin, frameMargin, frameWidth, frameHeight)
     .stroke();
  
  doc.strokeColor(DARK.gold)
     .lineWidth(0.5)
     .rect(frameMargin + 8, frameMargin + 8, frameWidth - 16, frameHeight - 16)
     .stroke();
  
  let y = frameMargin + 35;
  
  centerText(COMPANY_NAME, y, 28, FONTS.bold, DARK.gold);
  
  y += 40;
  
  if (logo) {
    try {
      const logoWidth = 120;
      const logoX = (PAGE.width - logoWidth) / 2;
      if (Buffer.isBuffer(logo)) {
        doc.image(logo, logoX, y, { width: logoWidth });
      } else if (typeof logo === 'string' && fs.existsSync(logo)) {
        doc.image(logo, logoX, y, { width: logoWidth });
      }
      y += 70;
    } catch (e) {
      y += 10;
    }
  } else {
    y += 10;
  }
  
  doc.strokeColor(DARK.gold)
     .lineWidth(1.5)
     .moveTo(centerX - 80, y)
     .lineTo(centerX + 80, y)
     .stroke();
  
  y += 25;
  
  centerText('IMPORTANT DISCLAIMER', y, 18, FONTS.bold, DARK.gold);
  
  y += 30;
  
  doc.strokeColor(DARK.gold)
     .lineWidth(1)
     .moveTo(centerX - 100, y)
     .lineTo(centerX + 100, y)
     .stroke();
  
  y += 25;
  
  const disclaimerSections = [
    { title: 'GENERAL INFORMATION ONLY', content: `This report is produced by ${COMPANY_NAME} for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.` },
    { title: 'NOT INVESTMENT ADVICE', content: `This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. ${COMPANY_NAME} is NOT a registered investment adviser or broker-dealer.` },
    { title: 'RISK DISCLOSURE', content: 'Trading and investing involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital.' },
    { title: 'NO GUARANTEES', content: `${COMPANY_NAME} makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.` },
    { title: 'YOUR RESPONSIBILITY', content: 'You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.' },
    { title: 'LIMITATION OF LIABILITY', content: `${COMPANY_NAME} shall NOT be liable for any damages arising from your use of or reliance on this report.` },
  ];
  
  for (const section of disclaimerSections) {
    if (y > PAGE.height - 200) break;
    
    doc.fillColor(DARK.gold)
       .font(FONTS.bold)
       .fontSize(9)
       .text(section.title, contentMargin, y, { lineBreak: false });
    
    y += 12;
    
    doc.strokeColor(DARK.gold)
       .lineWidth(0.5)
       .moveTo(contentMargin, y)
       .lineTo(contentMargin + 120, y)
       .stroke();
    
    y += 8;
    
    const textHeight = doc.heightOfString(section.content, { width: contentWidth });
    doc.fillColor('#FFFFFF')
       .font(FONTS.body)
       .fontSize(8.5)
       .text(section.content, contentMargin, y, { width: contentWidth, lineBreak: false, height: textHeight + 5 });
    
    y += textHeight + 12;
  }
  
  const warningY = PAGE.height - frameMargin - 135;
  const warningBoxX = contentMargin - 8;
  const warningBoxWidth = contentWidth + 16;
  const warningBoxHeight = 75;
  
  doc.rect(warningBoxX, warningY, warningBoxWidth, warningBoxHeight).fill('#330000');
  
  doc.strokeColor('#CC0000')
     .lineWidth(2)
     .rect(warningBoxX, warningY, warningBoxWidth, warningBoxHeight)
     .stroke();
  
  doc.font(FONTS.bold).fontSize(10);
  const warningTitle = 'COPYRIGHT WARNING';
  const warningTitleWidth = doc.widthOfString(warningTitle);
  doc.fillColor('#FF3333').text(warningTitle, centerX - warningTitleWidth/2, warningY + 10, { lineBreak: false });
  
  const copyrightWarning = `This report is the exclusive intellectual property of ${COMPANY_NAME}. Unauthorized reproduction, distribution, transmission, display, or publication of this report, in whole or in part, without the prior written consent of ${COMPANY_NAME} is strictly prohibited and constitutes a violation of copyright law.`;
  
  doc.fillColor('#FF6666')
     .font(FONTS.body)
     .fontSize(7.5)
     .text(copyrightWarning, contentMargin, warningY + 26, { width: contentWidth, lineBreak: false, height: 50 });
  
  const bottomY = PAGE.height - frameMargin - 40;
  
  doc.strokeColor(DARK.gold)
     .lineWidth(0.5)
     .moveTo(contentMargin, bottomY)
     .lineTo(contentMargin + contentWidth, bottomY)
     .stroke();
  
  doc.font(FONTS.body).fontSize(8);
  const allRights = `© ${new Date().getFullYear()} ${COMPANY_NAME}. All Rights Reserved.`;
  const allRightsWidth = doc.widthOfString(allRights);
  doc.fillColor(DARK.gold).text(allRights, centerX - allRightsWidth/2, bottomY + 12, { lineBreak: false });
  
  doc.font(FONTS.body).fontSize(7);
  const acknowledge = 'By reading this report, you acknowledge and agree to the terms above.';
  const ackWidth = doc.widthOfString(acknowledge);
  doc.fillColor('#888888').text(acknowledge, centerX - ackWidth/2, bottomY + 24, { lineBreak: false });
}

// =====================================================
// CONTENT PAGE HEADER & FOOTER
// =====================================================
function drawContentPageHeader(doc, sectionTitle) {
  doc.rect(0, 0, PAGE.width, PAGE.height).fill(LIGHT.background);
  
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.bold)
     .fontSize(14)
     .text(sectionTitle || REPORT_TITLE, PAGE.marginLeft, 30, { lineBreak: false });

  doc.font(FONTS.bold).fontSize(10);
  const brandWidth = doc.widthOfString(COMPANY_NAME);
  doc.fillColor(LIGHT.accent)
     .text(COMPANY_NAME, PAGE.width - PAGE.marginRight - brandWidth, 32, { lineBreak: false });

  doc.strokeColor(LIGHT.accent)
     .lineWidth(1)
     .moveTo(PAGE.marginLeft, 50)
     .lineTo(PAGE.width - PAGE.marginRight, 50)
     .stroke();
}

function drawContentPageFooter(doc, pageNum) {
  const y = PAGE.footerY;

  doc.strokeColor(LIGHT.tableBorder)
     .lineWidth(0.5)
     .moveTo(PAGE.marginLeft, y - 10)
     .lineTo(PAGE.width - PAGE.marginRight, y - 10)
     .stroke();

  doc.fillColor(LIGHT.textMuted)
     .font(FONTS.body)
     .fontSize(8)
     .text(`${pageNum}`, PAGE.marginLeft, y, { lineBreak: false });

  const footerText = `All Rights Reserved to ${COMPANY_NAME}`;
  doc.font(FONTS.body).fontSize(8);
  const footerWidth = doc.widthOfString(footerText);
  doc.fillColor(LIGHT.textMuted)
     .text(footerText, (PAGE.width - footerWidth) / 2, y, { lineBreak: false });
}

// =====================================================
// SECTION & SUB-SECTION TITLES
// =====================================================
// v11.1: ALL section titles now use BLACK color (LIGHT.textDark)
// to match Midapnim professional style - no blue headers
function drawSectionTitle(doc, title, startY, subtitle = null) {
  let y = startY || PAGE.contentTop;

  // ALL titles are BLACK for professional look
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.bold)
     .fontSize(16)
     .text(title || 'Section', PAGE.marginLeft, y, { lineBreak: false });

  const titleWidth = doc.widthOfString(title || 'Section');
  y += 20;
  
  doc.strokeColor(LIGHT.accent)
     .lineWidth(2.5)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + Math.min(titleWidth + 20, 200), y)
     .stroke();

  y += 8;

  if (subtitle) {
    doc.fillColor(LIGHT.textMuted)
       .font(FONTS.body)
       .fontSize(9)
       .text(subtitle, PAGE.marginLeft, y, { lineBreak: false });
    y += 18;
  }

  return y + 10;
}

// v10.1: Enhanced subsection title with proper spacing (like ISM report)
function drawSubSectionTitle(doc, title, startY, subtitle = null) {
  let y = startY;
  
  // Title - bold, BLACK color (like ISM report, not blue)
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.bold)
     .fontSize(13)
     .text(title, PAGE.marginLeft, y, { lineBreak: false });
  
  const titleWidth = doc.widthOfString(title);
  y += 20; // Space after title text
  
  // Gold underline - slightly thicker
  doc.strokeColor(LIGHT.accent)
     .lineWidth(2)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + Math.min(titleWidth + 15, 180), y)
     .stroke();
  
  y += 10; // Space after underline
  
  // Subtitle if provided (Midapnim style - gray)
  if (subtitle) {
    doc.fillColor(LIGHT.textMuted)
       .font(FONTS.body)
       .fontSize(9)
       .text(subtitle, PAGE.marginLeft, y, { lineBreak: false });
    y += 20; // Space after subtitle
  } else {
    y += 8; // Extra space if no subtitle
  }
  
  return y; // No extra padding needed - spacing is built in
}

// =====================================================
// BODY TEXT - v11.1 Increased spacing
// =====================================================
function drawBodyText(doc, text, startY, maxY) {
  let y = startY;
  
  if (!text) return { y, needsNewPage: false, remaining: '' };
  
  const paragraphs = splitIntoParagraphs(text);

  for (let i = 0; i < paragraphs.length; i++) {
    let paragraph = paragraphs[i].trim();
    if (paragraph.length === 0) continue;
    
    // Apply max sentences but preserve decimal numbers
    paragraph = enforceMaxSentences(paragraph, 4);
    
    const textHeight = doc.heightOfString(paragraph, { width: PAGE.contentWidth });
    
    if (y + textHeight > maxY) {
      return { y, needsNewPage: true, remaining: paragraphs.slice(i).join('\n\n') };
    }

    doc.fillColor(LIGHT.textDark)
       .font(FONTS.body)
       .fontSize(10.5)
       .text(paragraph, PAGE.marginLeft, y, {
         width: PAGE.contentWidth,
         align: 'justify',
         lineGap: 3,
       });

    y += textHeight + 22; // Increased from 16 to 22 for more spacing
  }

  return { y, needsNewPage: false, remaining: '' };
}

// =====================================================
// TABLES (Kept for compatibility)
// =====================================================
function drawPerformanceTable(doc, data, startY, maxY) {
  let y = startY + 10;

  if (!data || data.length === 0) return { y: startY, needsNewPage: false };

  const excludedSymbols = ['TLT', 'IEF', 'USO', 'UUP'];
  const filteredData = data.filter(row => !excludedSymbols.includes(row.symbol));

  if (filteredData.length === 0) return { y: startY, needsNewPage: false };

  const indexNames = {
    SPY: 'S&P 500',
    QQQ: 'Nasdaq 100',
    IWM: 'Russell 2000',
    DIA: 'Dow Jones',
    GLD: 'Gold',
    VIX: 'Volatility',
  };

  const colWidths = [120, 90, 90, 90];
  const headers = ['Asset', 'Close', 'Weekly %', 'Volume'];
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const rowHeight = 20;
  
  const requiredHeight = (filteredData.length + 1) * rowHeight + 30;
  if (y + requiredHeight > maxY) {
    return { y: startY, needsNewPage: true };
  }

  doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight + 4).fill(LIGHT.tableHeader);
  doc.strokeColor(LIGHT.tableBorder).lineWidth(0.5).rect(PAGE.marginLeft, y, tableWidth, rowHeight + 4).stroke();

  doc.fillColor(LIGHT.textMedium).font(FONTS.bold).fontSize(9);
  let xPos = PAGE.marginLeft + 8;
  headers.forEach((header, i) => {
    doc.text(header, xPos, y + 6, { width: colWidths[i] - 16, lineBreak: false });
    xPos += colWidths[i];
  });

  y += rowHeight + 4;

  filteredData.forEach((row, idx) => {
    const bgColor = idx % 2 === 0 ? LIGHT.background : LIGHT.tableAlt;
    doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight).fill(bgColor);
    doc.strokeColor(LIGHT.tableBorder).lineWidth(0.25).rect(PAGE.marginLeft, y, tableWidth, rowHeight).stroke();

    xPos = PAGE.marginLeft + 8;
    
    const displayName = indexNames[row.symbol] 
      ? `${indexNames[row.symbol]} (${row.symbol})`
      : row.symbol || '-';
    doc.fillColor(LIGHT.textDark).font(FONTS.bold).fontSize(9)
       .text(displayName, xPos, y + 5, { width: colWidths[0] - 16, lineBreak: false });
    xPos += colWidths[0];

    const close = row.close || row.price || row.last;
    doc.fillColor(LIGHT.textDark).font(FONTS.body).fontSize(9)
       .text(close ? `$${formatNumber(close)}` : '-', xPos, y + 5, { width: colWidths[1] - 16, lineBreak: false });
    xPos += colWidths[1];

    const weeklyPct = parseFloat(row.weeklyReturn) || row.weeklyChange || row.changePercent || 0;
    const pctColor = weeklyPct > 0 ? LIGHT.positive : weeklyPct < 0 ? LIGHT.negative : LIGHT.textMedium;
    doc.fillColor(pctColor).font(FONTS.body).fontSize(9)
       .text(formatPercent(weeklyPct), xPos, y + 5, { width: colWidths[2] - 16, lineBreak: false });
    xPos += colWidths[2];

    doc.fillColor(LIGHT.textMedium).font(FONTS.body).fontSize(9)
       .text(row.avgVolume ? formatNumber(row.avgVolume) : '-', xPos, y + 5, { width: colWidths[3] - 16, lineBreak: false });

    y += rowHeight;
  });

  return { y: y + 20, needsNewPage: false };
}

function drawSectorTable(doc, data, startY, maxY) {
  let y = startY + 10;

  if (!data || data.length === 0) return { y: startY, needsNewPage: false };

  const sectorNames = {
    XLK: 'Technology',
    XLF: 'Financials',
    XLE: 'Energy',
    XLV: 'Healthcare',
    XLI: 'Industrials',
    XLP: 'Consumer Staples',
    XLY: 'Consumer Disc.',
    XLU: 'Utilities',
    XLB: 'Materials',
    XLRE: 'Real Estate',
    XLC: 'Comm. Services',
  };

  const colWidths = [140, 90, 90, 90];
  const headers = ['Sector', '1 Week', '1 Month', 'YTD'];
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const rowHeight = 18;
  
  const requiredHeight = (data.length + 1) * rowHeight + 30;
  if (y + requiredHeight > maxY) {
    return { y: startY, needsNewPage: true };
  }

  doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight + 2).fill(LIGHT.tableHeader);
  doc.strokeColor(LIGHT.tableBorder).lineWidth(0.5).rect(PAGE.marginLeft, y, tableWidth, rowHeight + 2).stroke();

  doc.fillColor(LIGHT.textMedium).font(FONTS.bold).fontSize(8);
  let xPos = PAGE.marginLeft + 6;
  headers.forEach((header, i) => {
    doc.text(header, xPos, y + 5, { width: colWidths[i] - 12, lineBreak: false });
    xPos += colWidths[i];
  });

  y += rowHeight + 2;

  data.forEach((row, idx) => {
    const bgColor = idx % 2 === 0 ? LIGHT.background : LIGHT.tableAlt;
    doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight).fill(bgColor);
    doc.strokeColor(LIGHT.tableBorder).lineWidth(0.25).rect(PAGE.marginLeft, y, tableWidth, rowHeight).stroke();

    xPos = PAGE.marginLeft + 6;
    
    const symbol = row.symbol || row.ticker;
    const displayName = sectorNames[symbol] 
      ? `${sectorNames[symbol]} (${symbol})`
      : row.name || symbol || '-';
    doc.fillColor(LIGHT.textDark).font(FONTS.bold).fontSize(8)
       .text(displayName, xPos, y + 5, { width: colWidths[0] - 12, lineBreak: false });
    xPos += colWidths[0];

    const weekPct = parseFloat(row.weeklyReturn) || row.weeklyChange || 0;
    const weekColor = weekPct > 0 ? LIGHT.positive : weekPct < 0 ? LIGHT.negative : LIGHT.textMedium;
    doc.fillColor(weekColor).font(FONTS.body).fontSize(8)
       .text(formatPercent(weekPct), xPos, y + 5, { width: colWidths[1] - 12, lineBreak: false });
    xPos += colWidths[1];

    const monthPct = parseFloat(row.monthlyReturn) || row.monthlyChange || null;
    doc.fillColor(LIGHT.textMedium).font(FONTS.body).fontSize(8)
       .text(monthPct !== null ? formatPercent(monthPct) : '-', xPos, y + 5, { width: colWidths[2] - 12, lineBreak: false });
    xPos += colWidths[2];

    const ytdPct = parseFloat(row.ytdReturn) || row.ytdChange || null;
    doc.fillColor(LIGHT.textMedium).font(FONTS.body).fontSize(8)
       .text(ytdPct !== null ? formatPercent(ytdPct) : '-', xPos, y + 5, { width: colWidths[3] - 12, lineBreak: false });

    y += rowHeight;
  });

  return { y: y + 20, needsNewPage: false };
}

// =====================================================
// EARNINGS TABLE (v11.0 - Detailed earnings calendar)
// =====================================================
function drawEarningsTable(doc, earnings, startY, maxY) {
  let y = startY + 10;

  if (!earnings || earnings.length === 0) return { y: startY, needsNewPage: false };

  const colWidths = [80, 140, 100, 100];
  const headers = ['Day', 'Company', 'Ticker', 'Focus'];
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const rowHeight = 22;
  
  const displayEarnings = earnings.slice(0, 8); // Max 8 rows
  const requiredHeight = (displayEarnings.length + 1) * rowHeight + 30;
  
  if (y + requiredHeight > maxY) {
    return { y: startY, needsNewPage: true };
  }

  // Header row
  doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight + 2).fill(LIGHT.tableHeader);
  doc.strokeColor(LIGHT.tableBorder).lineWidth(0.5).rect(PAGE.marginLeft, y, tableWidth, rowHeight + 2).stroke();

  doc.fillColor(LIGHT.textMedium).font(FONTS.bold).fontSize(9);
  let xPos = PAGE.marginLeft + 8;
  headers.forEach((header, i) => {
    doc.text(header, xPos, y + 6, { width: colWidths[i] - 12, lineBreak: false });
    xPos += colWidths[i];
  });

  y += rowHeight + 2;

  // Data rows
  displayEarnings.forEach((earning, idx) => {
    const bgColor = idx % 2 === 0 ? LIGHT.background : LIGHT.tableAlt;
    doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight).fill(bgColor);
    doc.strokeColor(LIGHT.tableBorder).lineWidth(0.25).rect(PAGE.marginLeft, y, tableWidth, rowHeight).stroke();

    xPos = PAGE.marginLeft + 8;
    
    // Day
    const day = earning.day || earning.date || '-';
    doc.fillColor(LIGHT.accent).font(FONTS.bold).fontSize(8)
       .text(day, xPos, y + 6, { width: colWidths[0] - 12, lineBreak: false });
    xPos += colWidths[0];

    // Company
    const company = earning.company || earning.name || '-';
    doc.fillColor(LIGHT.textDark).font(FONTS.body).fontSize(8)
       .text(company, xPos, y + 6, { width: colWidths[1] - 12, lineBreak: false });
    xPos += colWidths[1];

    // Ticker
    const ticker = earning.ticker || earning.symbol || '-';
    doc.fillColor(LIGHT.primary).font(FONTS.bold).fontSize(8)
       .text(ticker, xPos, y + 6, { width: colWidths[2] - 12, lineBreak: false });
    xPos += colWidths[2];

    // Focus/Theme
    const focus = earning.focus || earning.theme || earning.sector || '-';
    doc.fillColor(LIGHT.textMuted).font(FONTS.body).fontSize(8)
       .text(focus, xPos, y + 6, { width: colWidths[3] - 12, lineBreak: false });

    y += rowHeight;
  });

  return { y: y + 15, needsNewPage: false };
}

// =====================================================
// INDEX PERFORMANCE TABLE (v11.2 - Visual index data)
// =====================================================
function drawIndexPerformanceTable(doc, indexData, startY, maxY) {
  let y = startY + 10;

  if (!indexData || Object.keys(indexData).length === 0) return { y: startY, needsNewPage: false };

  const indices = ['SPY', 'QQQ', 'IWM', 'DIA', 'VIX'];
  const displayIndices = indices.filter(sym => indexData[sym]);
  
  if (displayIndices.length === 0) return { y: startY, needsNewPage: false };

  const colWidths = [70, 90, 90, 90];
  const headers = ['Index', 'Price', 'Weekly Chg', '% Change'];
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const rowHeight = 22;
  
  const requiredHeight = (displayIndices.length + 1) * rowHeight + 30;
  
  if (y + requiredHeight > maxY) {
    return { y: startY, needsNewPage: true };
  }

  // Table title
  doc.fillColor(LIGHT.textMuted)
     .font(FONTS.body)
     .fontSize(9)
     .text('Index Performance Summary', PAGE.marginLeft, y - 5, { lineBreak: false });
  y += 12;

  // Header row
  doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight + 2).fill(LIGHT.tableHeader);
  doc.strokeColor(LIGHT.tableBorder).lineWidth(0.5).rect(PAGE.marginLeft, y, tableWidth, rowHeight + 2).stroke();

  doc.fillColor(LIGHT.textMedium).font(FONTS.bold).fontSize(9);
  let xPos = PAGE.marginLeft + 8;
  headers.forEach((header, i) => {
    doc.text(header, xPos, y + 6, { width: colWidths[i] - 12, lineBreak: false });
    xPos += colWidths[i];
  });

  y += rowHeight + 2;

  // Data rows
  displayIndices.forEach((symbol, idx) => {
    const data = indexData[symbol];
    const bgColor = idx % 2 === 0 ? LIGHT.background : LIGHT.tableAlt;
    doc.rect(PAGE.marginLeft, y, tableWidth, rowHeight).fill(bgColor);
    doc.strokeColor(LIGHT.tableBorder).lineWidth(0.25).rect(PAGE.marginLeft, y, tableWidth, rowHeight).stroke();

    xPos = PAGE.marginLeft + 8;
    
    // Symbol
    doc.fillColor(LIGHT.textDark).font(FONTS.bold).fontSize(9)
       .text(symbol, xPos, y + 6, { width: colWidths[0] - 12, lineBreak: false });
    xPos += colWidths[0];

    // Price
    const price = data.price || data.close || '-';
    const priceStr = typeof price === 'number' ? `$${price.toFixed(2)}` : price;
    doc.fillColor(LIGHT.textDark).font(FONTS.body).fontSize(9)
       .text(priceStr, xPos, y + 6, { width: colWidths[1] - 12, lineBreak: false });
    xPos += colWidths[1];

    // Weekly Change (absolute)
    const weeklyChange = parseFloat(data.weeklyChange) || 0;
    const changeStr = weeklyChange >= 0 ? `+${weeklyChange.toFixed(2)}` : weeklyChange.toFixed(2);
    doc.fillColor(weeklyChange >= 0 ? '#10B981' : '#EF4444').font(FONTS.body).fontSize(9)
       .text(changeStr, xPos, y + 6, { width: colWidths[2] - 12, lineBreak: false });
    xPos += colWidths[2];

    // Weekly Return (%)
    const weeklyReturn = parseFloat(data.weeklyReturn) || 0;
    const returnStr = weeklyReturn >= 0 ? `+${weeklyReturn.toFixed(2)}%` : `${weeklyReturn.toFixed(2)}%`;
    doc.fillColor(weeklyReturn >= 0 ? '#10B981' : '#EF4444').font(FONTS.bold).fontSize(9)
       .text(returnStr, xPos, y + 6, { width: colWidths[3] - 12, lineBreak: false });

    y += rowHeight;
  });

  return { y: y + 20, needsNewPage: false };
}

// =====================================================
// MACRO EVENT & DAY HEADER - v11.1 All titles black
// =====================================================
function drawMacroEvent(doc, event, startY, maxY) {
  let y = startY;
  
  const name = event.name || event.title || event.event || 'Economic Event';
  const previous = event.previous || event.prior || '-';
  const forecast = event.forecast || event.expected || '-';
  const analysis = event.analysis || event.description || '';
  
  const analysisHeight = analysis ? doc.heightOfString(cleanText(analysis), { width: PAGE.contentWidth }) : 0;
  const cardHeight = 40 + analysisHeight;
  
  if (y + cardHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  // Event name in BLACK (was blue)
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.bold)
     .fontSize(11)
     .text(name, PAGE.marginLeft, y, { lineBreak: false });
  
  y += 16;
  
  doc.fillColor(LIGHT.textMedium)
     .font(FONTS.body)
     .fontSize(9)
     .text(`Previous: ${previous}  |  Forecast: ${forecast}`, PAGE.marginLeft, y, { lineBreak: false });
  
  y += 18;
  
  if (analysis) {
    doc.fillColor(LIGHT.textDark)
       .font(FONTS.body)
       .fontSize(9.5)
       .text(cleanText(analysis), PAGE.marginLeft, y, { width: PAGE.contentWidth, align: 'justify', lineGap: 2 });
    y += analysisHeight + 15; // Increased spacing
  }
  
  return { y: y + 12, needsNewPage: false }; // More spacing between events
}

function drawDayHeader(doc, dayName, startY) {
  let y = startY;
  
  // Day name in BLACK (was gold)
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.bold)
     .fontSize(12)
     .text(dayName, PAGE.marginLeft, y, { lineBreak: false });
  
  y += 16;
  
  doc.strokeColor(LIGHT.accent)
     .lineWidth(1)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + 80, y)
     .stroke();
  
  return y + 12;
}

// =====================================================
// RISK ITEM
// =====================================================
function drawRiskItem(doc, risk, startY, maxY) {
  let y = startY;
  
  const rawTitle = risk.title || risk.name || 'Market Risk';
  const title = cleanText(rawTitle);
  const description = risk.description || risk.analysis || risk.content || '';
  
  const cleaned = cleanText(description);
  const textHeight = doc.heightOfString(cleaned, { width: PAGE.contentWidth });
  const totalHeight = textHeight + 45;
  
  if (y + totalHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  doc.fillColor(LIGHT.secondary)
     .font(FONTS.bold)
     .fontSize(11)
     .text(title, PAGE.marginLeft, y, { lineBreak: false });
  
  y += 15;
  
  doc.strokeColor(LIGHT.accent)
     .lineWidth(0.5)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + 120, y)
     .stroke();
  
  y += 10;
  
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.body)
     .fontSize(10)
     .text(cleaned, PAGE.marginLeft, y, { width: PAGE.contentWidth, align: 'justify', lineGap: 3 });
  
  y += textHeight + 18;
  
  return { y, needsNewPage: false };
}

// =====================================================
// TRADE IDEA CARD (Legacy - kept for compatibility)
// =====================================================
function drawTradeIdeaCard(doc, trade, index, startY, maxY) {
  let y = startY;
  
  const ticker = trade.ticker || trade.symbol || 'N/A';
  const direction = trade.direction || trade.side || 'LONG';
  const conviction = trade.conviction || trade.confidence || 'MEDIUM';
  const entry = trade.entry || '-';
  const stop = trade.stop || trade.stopLoss || '-';
  const target = trade.target || trade.targetPrice || '-';
  const timeframe = trade.timeframe || trade.horizon || '2-4 weeks';
  const rationale = trade.rationale || trade.reason || trade.thesis || '';
  
  const cleaned = cleanText(rationale);
  const rationaleHeight = doc.heightOfString(cleaned, { width: PAGE.contentWidth - 40 });
  const cardHeight = rationaleHeight + 110;
  
  if (y + cardHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, cardHeight)
     .fill(LIGHT.tableAlt);
  doc.strokeColor(LIGHT.accent)
     .lineWidth(1.5)
     .rect(PAGE.marginLeft, y, PAGE.contentWidth, cardHeight)
     .stroke();
  
  y += 12;
  
  const convColor = conviction === 'HIGH' ? LIGHT.positive : conviction === 'LOW' ? LIGHT.negative : LIGHT.accent;
  
  doc.fillColor(LIGHT.textMuted).font(FONTS.body).fontSize(9)
     .text(`Trade #${index}`, PAGE.marginLeft + 15, y);
  
  doc.fillColor(convColor).font(FONTS.bold).fontSize(9)
     .text(conviction, PAGE.marginLeft + PAGE.contentWidth - 70, y);
  
  y += 18;
  
  const dirColor = direction.toUpperCase() === 'LONG' ? LIGHT.positive : LIGHT.negative;
  
  doc.fillColor(LIGHT.primary).font(FONTS.bold).fontSize(16)
     .text(ticker, PAGE.marginLeft + 15, y);
  
  doc.fillColor(dirColor).font(FONTS.bold).fontSize(12)
     .text(`- ${direction.toUpperCase()}`, PAGE.marginLeft + 80, y + 3);
  
  y += 25;
  
  doc.fillColor(LIGHT.textMedium).font(FONTS.body).fontSize(9)
     .text(`Entry: ${entry}  |  Stop: ${stop}  |  Target: ${target}  |  Timeframe: ${timeframe}`, PAGE.marginLeft + 15, y);
  
  y += 22;
  
  doc.fillColor(LIGHT.secondary).font(FONTS.bold).fontSize(10)
     .text('Rationale:', PAGE.marginLeft + 15, y);
  
  y += 14;
  
  doc.fillColor(LIGHT.textDark).font(FONTS.body).fontSize(9)
     .text(cleaned, PAGE.marginLeft + 15, y, { width: PAGE.contentWidth - 40, align: 'justify', lineGap: 2 });
  
  y += rationaleHeight + 20;
  
  return { y: y + 10, needsNewPage: false };
}

// =====================================================
// TRADE IDEA PROSE (v9.0 - Midapnim style)
// =====================================================
function drawTradeIdeaProse(doc, trade, index, startY, maxY) {
  let y = startY;
  
  const ticker = trade.ticker || trade.symbol || 'N/A';
  const direction = (trade.direction || trade.side || 'LONG').toUpperCase();
  const conviction = trade.conviction || trade.confidence || 'MEDIUM';
  const entry = trade.entry || 'Current levels';
  const stop = trade.stop || trade.stopLoss || '-3%';
  const target = trade.target || trade.targetPrice || '+6%';
  const timeframe = trade.timeframe || trade.horizon || '2-4 weeks';
  const rationale = trade.rationale || trade.reason || trade.thesis || '';
  
  const cleaned = cleanText(rationale);
  const rationaleHeight = doc.heightOfString(cleaned, { width: PAGE.contentWidth });
  const totalHeight = rationaleHeight + 70;
  
  if (y + totalHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  const dirColor = direction === 'LONG' ? LIGHT.positive : LIGHT.negative;
  const convText = conviction === 'HIGH' ? 'High Conviction' : conviction === 'LOW' ? 'Modest Conviction' : 'Medium Conviction';
  
  doc.fillColor(LIGHT.primary)
     .font(FONTS.bold)
     .fontSize(13)
     .text(`Trade #${index}: ${ticker}`, PAGE.marginLeft, y, { continued: true });
  
  doc.fillColor(dirColor)
     .text(` (${direction})`, { continued: true });
  
  doc.fillColor(LIGHT.textMuted)
     .font(FONTS.body)
     .fontSize(11)
     .text(` — ${convText}`, { lineBreak: true });
  
  y += 22;
  
  doc.fillColor(LIGHT.textMedium)
     .font(FONTS.bold)
     .fontSize(9)
     .text(`Entry: ${entry}  |  Stop: ${stop}  |  Target: ${target}  |  Timeframe: ${timeframe}`, PAGE.marginLeft, y, { lineBreak: false });
  
  y += 20;
  
  doc.fillColor(LIGHT.textDark)
     .font(FONTS.body)
     .fontSize(10)
     .text(cleaned, PAGE.marginLeft, y, { width: PAGE.contentWidth, align: 'justify', lineGap: 3 });
  
  y += rationaleHeight + 25;
  
  return { y, needsNewPage: false };
}

// Default to prose style
function drawTradeIdea(doc, trade, index, startY, maxY) {
  return drawTradeIdeaProse(doc, trade, index, startY, maxY);
}

// =====================================================
// CHART IMAGE
// =====================================================
function drawChartImage(doc, chartData, x, startY, width) {
  let y = startY;
  
  if (!chartData) return y;
  
  try {
    let imgBuffer;
    if (Buffer.isBuffer(chartData)) {
      imgBuffer = chartData;
    } else if (chartData.startsWith && chartData.startsWith('data:image')) {
      const base64Data = chartData.split(',')[1];
      imgBuffer = Buffer.from(base64Data, 'base64');
    } else if (fs.existsSync(chartData)) {
      imgBuffer = fs.readFileSync(chartData);
    } else {
      return y;
    }
    
    const height = width * 0.55;
    doc.image(imgBuffer, x, y, { width, height });
    return y + height + 25;
  } catch (e) {
    console.error('[PDF] Chart error:', e.message);
    return y;
  }
}

// =====================================================
// v12.0: TACTICAL SUBSECTIONS DEFINITION (EXPANDED)
// Added: BofA Indicator, Market Breadth, Institutional Flows, CTA Positioning
// =====================================================
const TACTICAL_SUBSECTIONS = CONFIG_TACTICAL_SUBSECTIONS || [
  // NEW v12.0 subsections (first 4)
  {
    id: 'bofa_indicator',
    title: 'Sentiment & Risk Appetite',
    subtitle: 'BofA Bull & Bear Indicator Analysis',
    dataKey: 'bofa_indicator_agent',
  },
  {
    id: 'market_breadth',
    title: 'Market Breadth',
    subtitle: 'Internal Market Health Assessment',
    dataKey: 'market_breadth_agent',
  },
  {
    id: 'institutional_flows',
    title: 'Institutional Flows',
    subtitle: 'Who Is Buying, Who Is Selling',
    dataKey: 'institutional_flows_agent',
  },
  {
    id: 'cta_positioning',
    title: 'CTA & Systematic Positioning',
    subtitle: 'Trend-Following Exposure & Signals',
    dataKey: 'cta_positioning_agent',
  },
  // Original v10.0 subsections
  {
    id: 'global_macro',
    title: 'Global Macro',
    subtitle: 'The Economy Continues to Run, But With Clear Constraints',
    dataKey: 'tactical_global_macro',
  },
  {
    id: 'rates_policy',
    title: 'Rates & Monetary Policy',
    subtitle: 'Fed Trajectory and Rate Environment',
    dataKey: 'tactical_rates_policy',
  },
  {
    id: 'fiscal_risks',
    title: 'Fiscal Risks & Tail Scenarios',
    subtitle: 'What Could Disrupt the Base Case',
    dataKey: 'tactical_fiscal_risks',
  },
  {
    id: 'flows_sentiment',
    title: 'Flows, Sentiment & Risk Pricing',
    subtitle: 'Positioning and Market Psychology',
    dataKey: 'tactical_flows_sentiment',
  },
  {
    id: 'geographic',
    title: 'Geographic Considerations',
    subtitle: 'Regional Dynamics and Relative Value',
    dataKey: 'tactical_geographic',
  },
  {
    id: 'positioning',
    title: 'Positioning & Crowding',
    subtitle: 'Where the Market is Leaning',
    dataKey: 'tactical_positioning',
  },
  {
    id: 'synthesis',
    title: 'Tactical Bottom Line',
    subtitle: 'Putting It All Together',
    dataKey: 'tactical_synthesis',
  },
];

// =====================================================
// v12.0: NEW COMPONENT DRAWING FUNCTIONS
// =====================================================

// WEEKLY CALENDAR TABLE (day-by-day events) - v12.1 IMPROVED DESIGN
function drawWeeklyCalendarTable(doc, calendarData, startY, maxY) {
  let y = startY + 15;
  
  if (!calendarData) return { y: startY, needsNewPage: false };
  
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const dayWidth = PAGE.contentWidth / 5;
  const headerHeight = 28;
  const contentHeight = 160;
  
  const requiredHeight = headerHeight + contentHeight + 30;
  if (y + requiredHeight > maxY) {
    return { y: startY, needsNewPage: true };
  }
  
  // Header row with dark blue background (professional look)
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, headerHeight).fill('#1E3A5F');
  
  let xPos = PAGE.marginLeft;
  doc.fillColor('#FFFFFF').font(FONTS.bold).fontSize(10);
  days.forEach((day, i) => {
    doc.text(day, xPos + 5, y + 8, { width: dayWidth - 10, align: 'center' });
    // Vertical separator in header
    if (i < 4) {
      doc.strokeColor('#3B5998')
         .lineWidth(1)
         .moveTo(xPos + dayWidth, y + 4)
         .lineTo(xPos + dayWidth, y + headerHeight - 4)
         .stroke();
    }
    xPos += dayWidth;
  });
  
  y += headerHeight;
  
  // Content area with white background
  doc.rect(PAGE.marginLeft, y, PAGE.contentWidth, contentHeight).fill('#FFFFFF');
  doc.strokeColor('#E5E7EB').lineWidth(1).rect(PAGE.marginLeft, y, PAGE.contentWidth, contentHeight).stroke();
  
  // Draw vertical separators (light gray)
  xPos = PAGE.marginLeft + dayWidth;
  for (let i = 0; i < 4; i++) {
    doc.strokeColor('#E5E7EB')
       .lineWidth(0.5)
       .moveTo(xPos, y)
       .lineTo(xPos, y + contentHeight)
       .stroke();
    xPos += dayWidth;
  }
  
  // Draw events for each day with improved styling
  xPos = PAGE.marginLeft;
  days.forEach(day => {
    const dayData = calendarData[day] || {};
    let eventY = y + 10;
    const colX = xPos + 6;
    const colWidth = dayWidth - 12;
    
    // Macro events - Blue styling
    const macros = dayData.macro || [];
    macros.slice(0, 3).forEach(event => {
      if (eventY < y + contentHeight - 20) {
        // Event name (bold, dark blue)
        doc.font(FONTS.bold).fontSize(8).fillColor('#1E3A8A')
           .text((event.name || '').substring(0, 20), colX, eventY, { width: colWidth, lineBreak: false });
        eventY += 12;
        
        // Estimate (smaller, gray)
        if (event.forecast && eventY < y + contentHeight - 15) {
          doc.font(FONTS.body).fontSize(7).fillColor('#6B7280')
             .text(`Est: ${event.forecast}`, colX + 4, eventY, { width: colWidth - 4, lineBreak: false });
          eventY += 11;
        }
      }
    });
    
    // Small gap before earnings
    if (macros.length > 0 && eventY < y + contentHeight - 30) {
      eventY += 5;
    }
    
    // Earnings - Gold/amber styling
    const earnings = dayData.earnings || [];
    earnings.slice(0, 3).forEach(earning => {
      if (eventY < y + contentHeight - 15) {
        const ticker = earning.ticker || earning.company || '';
        doc.font(FONTS.bold).fontSize(8).fillColor('#B45309')
           .text(ticker.substring(0, 15), colX, eventY, { width: colWidth, lineBreak: false });
        eventY += 13;
      }
    });
    
    // Small gap before Fed speakers
    if (earnings.length > 0 && eventY < y + contentHeight - 25) {
      eventY += 4;
    }
    
    // Fed speakers - Red styling
    const fedSpeakers = dayData.fedSpeakers || [];
    fedSpeakers.slice(0, 2).forEach(speaker => {
      if (eventY < y + contentHeight - 12) {
        doc.font(FONTS.body).fontSize(7).fillColor('#DC2626')
           .text(`Fed: ${(speaker.name || '').substring(0, 12)}`, colX, eventY, { width: colWidth, lineBreak: false });
        eventY += 11;
      }
    });
    
    xPos += dayWidth;
  });
  
  // Legend at bottom
  const legendY = y + contentHeight + 8;
  const legendItems = [
    { color: '#1E3A8A', label: 'Macro Data' },
    { color: '#B45309', label: 'Earnings' },
    { color: '#DC2626', label: 'Fed Speakers' },
  ];
  
  let legendX = PAGE.marginLeft + 80;
  doc.fontSize(7);
  legendItems.forEach(item => {
    doc.rect(legendX, legendY + 2, 8, 8).fill(item.color);
    doc.font(FONTS.body).fillColor('#6B7280')
       .text(item.label, legendX + 12, legendY + 1, { lineBreak: false });
    legendX += 90;
  });
  
  return { y: legendY + 25, needsNewPage: false };
}

// BofA BULL & BEAR INDICATOR SECTION
function drawBofASection(doc, bofaData, charts, startY, maxY) {
  let y = startY;
  
  const indicator = bofaData?.indicator || bofaData || {};
  const value = indicator.value;
  const signal = indicator.signal || 'unknown';
  const analysis = bofaData?.analysis || '';
  const hasData = value !== null && value !== undefined;
  
  // Estimate required height
  const analysisHeight = analysis ? doc.heightOfString(cleanText(analysis), { width: PAGE.contentWidth }) : 0;
  const requiredHeight = (hasData ? 100 : 30) + analysisHeight;
  
  if (y + requiredHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  // Only show value box if we have real data
  if (hasData) {
    // Chart if available
    if (charts?.bofaGauge && Buffer.isBuffer(charts.bofaGauge)) {
      try {
        const chartWidth = 160;
        const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
        doc.image(charts.bofaGauge, chartX, y, { width: chartWidth });
        y += 110;
      } catch (e) {
        // Skip chart on error
      }
    }
    
    // Value display box - compact
    const boxWidth = 120;
    const boxX = PAGE.marginLeft + (PAGE.contentWidth - boxWidth) / 2;
    
    doc.rect(boxX, y, boxWidth, 40).fill('#F8FAFC');
    doc.strokeColor(LIGHT.accent).lineWidth(1.5).rect(boxX, y, boxWidth, 40).stroke();
    
    const valueColor = value >= 8 ? '#DC2626' : value <= 2 ? '#16A34A' : '#1E3A8A';
    doc.font(FONTS.bold).fontSize(20).fillColor(valueColor)
       .text(value.toFixed(1), boxX, y + 5, { width: boxWidth, align: 'center' });
    
    const signalText = signal.charAt(0).toUpperCase() + signal.slice(1);
    doc.font(FONTS.body).fontSize(8).fillColor('#6B7280')
       .text(signalText.toUpperCase(), boxX, y + 26, { width: boxWidth, align: 'center' });
    
    y += 55;
  }
  
  // Analysis text
  if (analysis) {
    const result = drawBodyText(doc, analysis, y, maxY);
    y = result.y;
  }
  
  return { y, needsNewPage: false };
}

// MARKET BREADTH SECTION
function drawBreadthSection(doc, breadthData, charts, startY, maxY) {
  let y = startY;
  
  const breadth = breadthData?.breadth || breadthData || {};
  const analysis = breadthData?.analysis || '';
  const hasData = breadth.pctAbove50 || breadth.pctAbove200;
  
  const analysisHeight = analysis ? doc.heightOfString(cleanText(analysis), { width: PAGE.contentWidth }) : 0;
  const requiredHeight = (hasData ? 80 : 30) + analysisHeight;
  
  if (y + requiredHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  // Only show metrics if we have real data
  if (hasData) {
    // Compact inline metrics - smaller cards
    const metrics = [];
    if (breadth.pctAbove50) metrics.push({ label: 'Above 50-DMA', value: `${breadth.pctAbove50}%` });
    if (breadth.pctAbove200) metrics.push({ label: 'Above 200-DMA', value: `${breadth.pctAbove200}%` });
    if (breadth.advanceDecline && breadth.advanceDecline !== 'unknown') {
      metrics.push({ label: 'A/D Line', value: (breadth.advanceDecline || '').replace('_', ' ') });
    }
    
    if (metrics.length > 0) {
      const boxWidth = 100;
      const boxHeight = 36;
      const boxSpacing = 12;
      const totalWidth = metrics.length * boxWidth + (metrics.length - 1) * boxSpacing;
      let boxX = PAGE.marginLeft + (PAGE.contentWidth - totalWidth) / 2;
      
      metrics.forEach(metric => {
        // Compact card with border
        doc.rect(boxX, y, boxWidth, boxHeight).fill('#F8FAFC');
        doc.strokeColor('#E2E8F0').lineWidth(0.5).rect(boxX, y, boxWidth, boxHeight).stroke();
        
        // Label - small
        doc.font(FONTS.body).fontSize(6).fillColor('#6B7280')
           .text(metric.label, boxX, y + 5, { width: boxWidth, align: 'center' });
        
        // Value - medium bold
        doc.font(FONTS.bold).fontSize(13).fillColor('#1E3A8A')
           .text(metric.value, boxX, y + 16, { width: boxWidth, align: 'center' });
        
        boxX += boxWidth + boxSpacing;
      });
      
      y += boxHeight + 15;
    }
  }
  
  // Analysis text
  if (analysis) {
    const result = drawBodyText(doc, analysis, y, maxY);
    y = result.y;
  }
  
  return { y, needsNewPage: false };
}

// INSTITUTIONAL FLOWS SECTION
function drawFlowsSection(doc, flowsData, charts, startY, maxY) {
  let y = startY;
  
  const flows = flowsData?.flows || flowsData || {};
  const analysis = flowsData?.analysis || '';
  
  const analysisHeight = analysis ? doc.heightOfString(cleanText(analysis), { width: PAGE.contentWidth }) : 0;
  const requiredHeight = 200 + analysisHeight;
  
  if (y + requiredHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  // Chart if available
  if (charts?.institutionalFlows && Buffer.isBuffer(charts.institutionalFlows)) {
    try {
      const chartWidth = 340;
      const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
      doc.image(charts.institutionalFlows, chartX, y, { width: chartWidth });
      y += 160;
    } catch (e) {
      // Skip on error
    }
  }
  
  // Summary table
  const colWidths = [140, 100, 90];
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const tableX = PAGE.marginLeft + (PAGE.contentWidth - tableWidth) / 2;
  
  // Header
  doc.rect(tableX, y, tableWidth, 18).fill(LIGHT.tableHeader);
  doc.fillColor(LIGHT.textMedium).font(FONTS.bold).fontSize(8);
  doc.text('Investor Type', tableX + 5, y + 5, { width: colWidths[0] - 10 });
  doc.text('Net Flow', tableX + colWidths[0] + 5, y + 5, { width: colWidths[1] - 10, align: 'center' });
  doc.text('Direction', tableX + colWidths[0] + colWidths[1] + 5, y + 5, { width: colWidths[2] - 10, align: 'center' });
  
  y += 18;
  
  const flowRows = [
    { type: 'Long-Only Funds', net: flows.longOnly?.net || -2.3 },
    { type: 'Hedge Funds', net: flows.hedgeFunds?.net || -1.1 },
  ];
  
  const sectorFlows = flows.sectorFlows || {};
  Object.entries(sectorFlows).slice(0, 3).forEach(([sector, value]) => {
    flowRows.push({ type: sector.replace(/([A-Z])/g, ' $1').trim(), net: value });
  });
  
  flowRows.forEach((row, i) => {
    const bgColor = i % 2 === 0 ? LIGHT.background : LIGHT.tableAlt;
    doc.rect(tableX, y, tableWidth, 16).fill(bgColor);
    
    const flowColor = row.net >= 0 ? LIGHT.positive : LIGHT.negative;
    const direction = row.net >= 0 ? 'Inflow' : 'Outflow';
    
    doc.font(FONTS.body).fontSize(8).fillColor(LIGHT.textDark)
       .text(row.type, tableX + 5, y + 4, { width: colWidths[0] - 10 });
    doc.fillColor(flowColor)
       .text(`$${row.net >= 0 ? '+' : ''}${row.net.toFixed(1)}B`, tableX + colWidths[0] + 5, y + 4, { width: colWidths[1] - 10, align: 'center' });
    doc.text(direction, tableX + colWidths[0] + colWidths[1] + 5, y + 4, { width: colWidths[2] - 10, align: 'center' });
    
    y += 16;
  });
  
  y += 15;
  
  // Analysis
  if (analysis) {
    const result = drawBodyText(doc, analysis, y, maxY);
    y = result.y;
  }
  
  return { y, needsNewPage: false };
}

// CTA & SYSTEMATIC POSITIONING SECTION
function drawCTASection(doc, ctaData, charts, startY, maxY) {
  let y = startY;
  
  const cta = ctaData?.cta || ctaData || {};
  const analysis = ctaData?.analysis || '';
  const hasData = cta.equityExposure || cta.volControlExposure;
  
  const analysisHeight = analysis ? doc.heightOfString(cleanText(analysis), { width: PAGE.contentWidth }) : 0;
  const requiredHeight = (hasData ? 90 : 30) + analysisHeight;
  
  if (y + requiredHeight > maxY) {
    return { y, needsNewPage: true };
  }
  
  // Only show if we have real data
  if (hasData) {
    // Compact metrics boxes (no gauge chart to avoid overlap)
    const metrics = [];
    if (cta.equityExposure) metrics.push({ label: 'CTA Exposure', value: `${cta.equityExposure}%` });
    if (cta.volControlExposure) metrics.push({ label: 'Vol-Control', value: `${cta.volControlExposure}%` });
    if (cta.historicalPercentile) metrics.push({ label: 'Historical %ile', value: `${cta.historicalPercentile}th` });
    
    if (metrics.length > 0) {
      const boxWidth = 100;
      const boxHeight = 36;
      const boxSpacing = 12;
      const totalWidth = metrics.length * boxWidth + (metrics.length - 1) * boxSpacing;
      let boxX = PAGE.marginLeft + (PAGE.contentWidth - totalWidth) / 2;
      
      metrics.forEach(metric => {
        doc.rect(boxX, y, boxWidth, boxHeight).fill('#F8FAFC');
        doc.strokeColor('#E2E8F0').lineWidth(0.5).rect(boxX, y, boxWidth, boxHeight).stroke();
        
        doc.font(FONTS.body).fontSize(6).fillColor('#6B7280')
           .text(metric.label, boxX, y + 5, { width: boxWidth, align: 'center' });
        
        doc.font(FONTS.bold).fontSize(13).fillColor('#1E3A8A')
           .text(metric.value, boxX, y + 16, { width: boxWidth, align: 'center' });
        
        boxX += boxWidth + boxSpacing;
      });
      
      y += boxHeight + 15;
    }
  }
  
  // Analysis
  if (analysis) {
    const result = drawBodyText(doc, analysis, y, maxY);
    y = result.y;
  }
  
  return { y, needsNewPage: false };
}

// =====================================================
// MAIN PDF GENERATOR v12.0
// =====================================================
async function generateWeeklyPDF(reportData, options = {}) {
  return new Promise((resolve, reject) => {
    try {
      console.log('[Weekly PDF v12.0] Starting generation (BofA, Breadth, Flows, CTA sections added)...');

      const outputPath = options.outputPath || './weekly_report.pdf';
      const logoPath = findLogo(options.logoPath);
      const reportDate = reportData.meta?.reportWeek || new Date().toISOString();
      const charts = options.charts || {};

      let logo = null;
      if (logoPath) {
        try {
          logo = fs.readFileSync(logoPath);
        } catch (e) {
          console.log('[Weekly PDF] Could not load logo');
        }
      }

      const doc = new PDFDocument({
        size: 'letter',
        autoFirstPage: false,
        margins: {
          top: PAGE.marginTop,
          bottom: PAGE.marginBottom,
          left: PAGE.marginLeft,
          right: PAGE.marginRight,
        },
      });

      registerFonts(doc);

      const chunks = [];
      doc.on('data', chunk => chunks.push(chunk));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(chunks);
        
        fs.writeFileSync(outputPath, pdfBuffer);
        console.log(`[Weekly PDF v12.0] Saved to ${outputPath}`);
        
        resolve({
          success: true,
          path: outputPath,
          buffer: pdfBuffer,
          size: pdfBuffer.length,
        });
      });

      // ========== PAGE 1: COVER PAGE ==========
      drawCoverPage(doc, reportDate, logo);

      // ========== CONTENT PAGES ==========
      let contentPageNum = 1;
      let currentY = PAGE.contentTop;
      let currentSection = 'The Week That Was';
      const maxY = PAGE.safeBottom;

      function newContentPage(sectionName) {
        drawContentPageFooter(doc, contentPageNum);
        contentPageNum++;
        doc.addPage();
        currentSection = sectionName || currentSection;
        drawContentPageHeader(doc, currentSection);
        return PAGE.contentTop;
      }

      // ========== SECTION 1: THE WEEK THAT WAS (v11.2 Enhanced) ==========
      doc.addPage();
      drawContentPageHeader(doc, currentSection);
      currentY = drawSectionTitle(doc, 'The Week That Was', currentY, 'Weekly Market Review & Sector Analysis');

      // INDEX PERFORMANCE TABLE (v11.2 - Visual data - replaces text description)
      const indexData = reportData.sections?.market_data_fetcher?.data?.indices || {};
      if (Object.keys(indexData).length > 0) {
        let tableResult = drawIndexPerformanceTable(doc, indexData, currentY, maxY);
        if (tableResult.needsNewPage) {
          currentY = newContentPage(currentSection);
          tableResult = drawIndexPerformanceTable(doc, indexData, currentY, maxY);
        }
        currentY = tableResult.y;
      }

      // NARRATIVE (v11.0 - News-driven WHY analysis)
      const weekNarrative = reportData.sections?.week_narrative_writer?.data?.narrative || 
                            reportData.summary?.narrative;
      if (weekNarrative) {
        currentY += 5;
        currentY = drawSubSectionTitle(doc, 'What Drove the Markets', currentY, 'News Events & Market Reaction');
        
        let result = drawBodyText(doc, weekNarrative, currentY, maxY);
        currentY = result.y;
        
        while (result.needsNewPage && result.remaining) {
          currentY = newContentPage(currentSection);
          result = drawBodyText(doc, result.remaining, currentY, maxY);
          currentY = result.y;
        }
      }

      // SECTOR ROTATION ANALYSIS (v11.0 - News-driven WHY)
      const sectorAnalysis = reportData.sections?.sector_rotation_analyzer?.data?.analysis;
      if (sectorAnalysis) {
        if (needsPageBreak(currentY, 120)) {
          currentY = newContentPage(currentSection);
        }
        currentY += 20;
        currentY = drawSubSectionTitle(doc, 'Sector Rotation', currentY, 'What It Tells Us');
        
        let result = drawBodyText(doc, sectorAnalysis, currentY, maxY);
        currentY = result.y;
        
        while (result.needsNewPage && result.remaining) {
          currentY = newContentPage(currentSection);
          result = drawBodyText(doc, result.remaining, currentY, maxY);
          currentY = result.y;
        }
      }

      // SECTOR ROTATION CHART ONLY (v11.4: Removed index chart - data is in table)
      if (charts.sectorRotation) {
        if (needsPageBreak(currentY, 280)) {
          currentY = newContentPage(currentSection);
        }
        currentY += 30;
        const chartWidth = 400;
        const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
        currentY = drawChartImage(doc, charts.sectorRotation, chartX, currentY, chartWidth);
        currentY += 25;
      }

      // ========== SECTION 1.5: WEEKLY CALENDAR (v12.0 NEW) ==========
      const calendarData = reportData.sections?.weekly_calendar_agent?.data?.calendar;
      if (calendarData) {
        if (needsPageBreak(currentY, 200)) {
          currentY = newContentPage('This Week at a Glance');
        } else {
          currentY += 25;
        }
        currentSection = 'This Week at a Glance';
        currentY = drawSectionTitle(doc, 'This Week at a Glance', currentY, 'Day-by-Day Event Calendar');
        
        let calResult = drawWeeklyCalendarTable(doc, calendarData, currentY, maxY);
        if (calResult.needsNewPage) {
          currentY = newContentPage(currentSection);
          calResult = drawWeeklyCalendarTable(doc, calendarData, currentY, maxY);
        }
        currentY = calResult.y;
      }

      // ========== SECTION 2: EVENTS THIS WEEK ==========
      const macroEventsData = reportData.sections?.macro_events_writer?.data || {};
      const macroEvents = macroEventsData.events ||
                         reportData.sections?.economic_calendar_fetcher?.data?.events ||
                         reportData.macroEvents || [];
      const eventsByDay = macroEventsData.eventsByDay || {};
      
      const hasEvents = macroEvents && macroEvents.length > 0;
      
      if (hasEvents) {
        if (needsPageBreak(currentY, 150)) {
          currentY = newContentPage('Events This Week');
        } else {
          currentY += 30;
        }
        currentSection = 'Events This Week';
        currentY = drawSectionTitle(doc, 'Events This Week', currentY, 'Key Data Releases & Market Catalysts');

        const dayOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        const daysWithEvents = dayOrder.filter(day => eventsByDay[day] && eventsByDay[day].length > 0);
        
        if (daysWithEvents.length > 0) {
          for (const day of daysWithEvents) {
            const dayEvents = eventsByDay[day];
            
            if (needsPageBreak(currentY, 80)) {
              currentY = newContentPage(currentSection);
            }
            
            currentY = drawDayHeader(doc, day, currentY);
            
            for (const event of dayEvents) {
              let result = drawMacroEvent(doc, event, currentY, maxY);
              if (result.needsNewPage) {
                currentY = newContentPage(currentSection);
                result = drawMacroEvent(doc, event, currentY, maxY);
              }
              currentY = result.y;
            }
          }
        } else {
          currentY = drawSubSectionTitle(doc, 'Macro Calendar', currentY, 'Key Economic Releases');
          
          for (const event of macroEvents.slice(0, 8)) {
            let result = drawMacroEvent(doc, event, currentY, maxY);
            if (result.needsNewPage) {
              currentY = newContentPage(currentSection);
              result = drawMacroEvent(doc, event, currentY, maxY);
            }
            currentY = result.y;
          }
        }

        const microAnalysis = reportData.sections?.micro_events_writer?.data?.analysis;
        const earningsCalendar = reportData.sections?.micro_events_writer?.data?.earnings || 
                                 reportData.sections?.economic_calendar_fetcher?.data?.earnings || [];
        
        if (microAnalysis || earningsCalendar.length > 0) {
          if (needsPageBreak(currentY, 150)) {
            currentY = newContentPage(currentSection);
          }
          currentY += 15;
          currentY = drawSubSectionTitle(doc, 'Earnings Watch', currentY, 'Notable Releases This Week');
          
          // Draw earnings table if we have specific earnings data
          if (earningsCalendar.length > 0) {
            let result = drawEarningsTable(doc, earningsCalendar, currentY, maxY);
            if (result.needsNewPage) {
              currentY = newContentPage(currentSection);
              result = drawEarningsTable(doc, earningsCalendar, currentY, maxY);
            }
            currentY = result.y;
            currentY += 10;
          }
          
          // Draw analysis text
          if (microAnalysis) {
            let result = drawBodyText(doc, microAnalysis, currentY, maxY);
            currentY = result.y;
            
            while (result.needsNewPage && result.remaining) {
              currentY = newContentPage(currentSection);
              result = drawBodyText(doc, result.remaining, currentY, maxY);
              currentY = result.y;
            }
          }
        }
      }

      // ========== SECTION 3: TACTICAL PREPARATION (v10.0 EXPANDED) ==========
      if (needsPageBreak(currentY, 150)) {
        currentY = newContentPage('Tactical Preparation');
      } else {
        currentY += 30;
      }
      currentSection = 'Tactical Preparation';
      currentY = drawSectionTitle(doc, 'Tactical Preparation', currentY, 'Markets, Macro & Positioning');

      // v10.0: Try new 7-subsection structure first
      let hasExpandedTactical = false;
      for (const subsection of TACTICAL_SUBSECTIONS) {
        const subsectionData = reportData.sections?.[subsection.dataKey]?.data;
        if (subsectionData?.analysis) {
          hasExpandedTactical = true;
          break;
        }
      }

      if (hasExpandedTactical) {
        // v12.0: Render all 11 tactical subsections with special handling for new components
        for (const subsection of TACTICAL_SUBSECTIONS) {
          const subsectionData = reportData.sections?.[subsection.dataKey]?.data;
          
          // v12.0: Special rendering for new components
          if (subsection.id === 'bofa_indicator' && subsectionData) {
            if (needsPageBreak(currentY, 250)) {
              currentY = newContentPage(currentSection);
            }
            currentY = drawSubSectionTitle(doc, subsection.title, currentY, subsection.subtitle);
            let result = drawBofASection(doc, subsectionData, charts, currentY, maxY);
            if (result.needsNewPage) {
              currentY = newContentPage(currentSection);
              result = drawBofASection(doc, subsectionData, charts, currentY, maxY);
            }
            currentY = result.y + 20;
            continue;
          }
          
          if (subsection.id === 'market_breadth' && subsectionData) {
            if (needsPageBreak(currentY, 280)) {
              currentY = newContentPage(currentSection);
            }
            currentY = drawSubSectionTitle(doc, subsection.title, currentY, subsection.subtitle);
            let result = drawBreadthSection(doc, subsectionData, charts, currentY, maxY);
            if (result.needsNewPage) {
              currentY = newContentPage(currentSection);
              result = drawBreadthSection(doc, subsectionData, charts, currentY, maxY);
            }
            currentY = result.y + 20;
            continue;
          }
          
          if (subsection.id === 'institutional_flows' && subsectionData) {
            if (needsPageBreak(currentY, 280)) {
              currentY = newContentPage(currentSection);
            }
            currentY = drawSubSectionTitle(doc, subsection.title, currentY, subsection.subtitle);
            let result = drawFlowsSection(doc, subsectionData, charts, currentY, maxY);
            if (result.needsNewPage) {
              currentY = newContentPage(currentSection);
              result = drawFlowsSection(doc, subsectionData, charts, currentY, maxY);
            }
            currentY = result.y + 20;
            continue;
          }
          
          if (subsection.id === 'cta_positioning' && subsectionData) {
            if (needsPageBreak(currentY, 220)) {
              currentY = newContentPage(currentSection);
            }
            currentY = drawSubSectionTitle(doc, subsection.title, currentY, subsection.subtitle);
            let result = drawCTASection(doc, subsectionData, charts, currentY, maxY);
            if (result.needsNewPage) {
              currentY = newContentPage(currentSection);
              result = drawCTASection(doc, subsectionData, charts, currentY, maxY);
            }
            currentY = result.y + 20;
            continue;
          }
          
          // Standard subsection rendering (original v10.0 style)
          const analysis = subsectionData?.analysis;
          if (analysis) {
            // Check for page break - need space for title + subtitle + first paragraph
            if (needsPageBreak(currentY, 140)) {
              currentY = newContentPage(currentSection);
            }
            
            // Draw subsection with title and subtitle
            currentY = drawSubSectionTitle(doc, subsection.title, currentY, subsection.subtitle);
            
            let result = drawBodyText(doc, analysis, currentY, maxY);
            currentY = result.y;
            
            while (result.needsNewPage && result.remaining) {
              currentY = newContentPage(currentSection);
              result = drawBodyText(doc, result.remaining, currentY, maxY);
              currentY = result.y;
            }
            
            // Add spacing between subsections
            currentY += 20;
          }
        }
      } else {
        // Fallback to v9.0 structure (tactical_macro_analyst + flows_sentiment_analyst)
        const tacticalData = reportData.sections?.tactical_macro_analyst?.data || {};
        const regimeTitle = tacticalData.regimeTitle || 'Market Regime Assessment';
        const flowsTitle = tacticalData.flowsTitle || 'Flows & Positioning';

        const globalMacro = tacticalData.globalMacro || tacticalData.analysis ||
                           reportData.tacticalPrep?.globalMacro || reportData.tacticalAnalysis;

        if (globalMacro) {
          currentY = drawSubSectionTitle(doc, regimeTitle, currentY, 'Current Market Environment');
          let result = drawBodyText(doc, globalMacro, currentY, maxY);
          currentY = result.y;
          
          while (result.needsNewPage && result.remaining) {
            currentY = newContentPage(currentSection);
            result = drawBodyText(doc, result.remaining, currentY, maxY);
            currentY = result.y;
          }
        }

        const flowsSentiment = reportData.sections?.flows_sentiment_analyst?.data?.analysis ||
                              reportData.flowsSentiment || reportData.sentiment;

        if (flowsSentiment) {
          if (needsPageBreak(currentY, 120)) {
            currentY = newContentPage(currentSection);
          }
          currentY += 20;
          currentY = drawSubSectionTitle(doc, flowsTitle, currentY, 'Positioning and Market Psychology');
          
          const flowsText = typeof flowsSentiment === 'string' ? flowsSentiment : flowsSentiment.analysis || flowsSentiment.summary;
          if (flowsText) {
            let result = drawBodyText(doc, flowsText, currentY, maxY);
            currentY = result.y;
            currentY = result.y;
            
            while (result.needsNewPage && result.remaining) {
              currentY = newContentPage(currentSection);
              result = drawBodyText(doc, result.remaining, currentY, maxY);
              currentY = result.y;
            }
          }
        }
      }

      // ========== v11.0: MACRO INSIGHTS (Dynamic Market Themes) ==========
      const macroInsights = reportData.sections?.macro_insights?.data?.insights || [];
      if (macroInsights.length > 0) {
        if (needsPageBreak(currentY, 150)) {
          currentY = newContentPage(currentSection);
        }
        currentY += 20;
        currentY = drawSubSectionTitle(doc, 'Market Intelligence', currentY, 'Dynamic Insights from Current Analysis');
        
        for (const insight of macroInsights) {
          if (needsPageBreak(currentY, 120)) {
            currentY = newContentPage(currentSection);
          }
          
          // Draw theme name as sub-header
          doc.fillColor(LIGHT.accent)
             .font(FONTS.bold)
             .fontSize(11)
             .text(insight.theme, PAGE.marginLeft, currentY, { lineBreak: false });
          currentY += 18;
          
          // Draw analysis text
          let result = drawBodyText(doc, insight.analysis, currentY, maxY);
          currentY = result.y;
          
          while (result.needsNewPage && result.remaining) {
            currentY = newContentPage(currentSection);
            result = drawBodyText(doc, result.remaining, currentY, maxY);
            currentY = result.y;
          }
          
          currentY += 15; // Spacing between insights
        }
      }

      // TACTICAL CHARTS (v11.0: Reduced size to 320px)
      if (charts.vixTrend) {
        if (needsPageBreak(currentY, 220)) {
          currentY = newContentPage(currentSection);
        }
        currentY += 15; // Extra spacing before chart
        const chartWidth = 320; // Reduced from 400
        const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
        currentY = drawChartImage(doc, charts.vixTrend, chartX, currentY, chartWidth);
        currentY += 10; // Extra spacing after chart
      }

      if (charts.spyTrend) {
        if (needsPageBreak(currentY, 220)) {
          currentY = newContentPage(currentSection);
        }
        currentY += 15; // Extra spacing before chart
        const chartWidth = 340; // Reduced from 420
        const chartX = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
        currentY = drawChartImage(doc, charts.spyTrend, chartX, currentY, chartWidth);
        currentY += 10; // Extra spacing after chart
      }

      // KEY RISKS (if using old structure or standalone)
      const keyRisks = reportData.sections?.risk_assessment_builder?.data?.risks ||
                      reportData.sections?.risk_monitor?.data?.risks ||
                      reportData.keyRisks || reportData.risks;

      if (keyRisks && Array.isArray(keyRisks) && keyRisks.length > 0 && !hasExpandedTactical) {
        if (needsPageBreak(currentY, 120)) {
          currentY = newContentPage(currentSection);
        }
        currentY += 20;
        currentY = drawSubSectionTitle(doc, 'Key Risks to Monitor', currentY, 'What Could Derail the View');
        
        for (const risk of keyRisks) {
          let result = drawRiskItem(doc, risk, currentY, maxY);
          if (result.needsNewPage) {
            currentY = newContentPage(currentSection);
            result = drawRiskItem(doc, risk, currentY, maxY);
          }
          currentY = result.y;
        }
      }

      // ========== SECTION 4: TRADE IDEAS ==========
      const tradeIdeas = reportData.sections?.trade_idea_generator?.data?.ideas ||
                        reportData.sections?.risk_manager?.data?.ideas ||
                        reportData.tradeIdeas || reportData.ideas || [];

      if (tradeIdeas.length > 0) {
        if (needsPageBreak(currentY, 150)) {
          currentY = newContentPage('Trade Ideas');
        } else {
          currentY += 25;
        }
        currentSection = 'Trade Ideas';
        currentY = drawSectionTitle(doc, 'Trade Ideas', currentY, 'Actionable Opportunities');
        
        for (let i = 0; i < tradeIdeas.length; i++) {
          let result = drawTradeIdeaProse(doc, tradeIdeas[i], i + 1, currentY, maxY);
          if (result.needsNewPage) {
            currentY = newContentPage(currentSection);
            result = drawTradeIdeaProse(doc, tradeIdeas[i], i + 1, currentY, maxY);
          }
          currentY = result.y;
        }
      }

      drawContentPageFooter(doc, contentPageNum);

      // ========== DISCLAIMER PAGE ==========
      drawDisclaimerPage(doc, logo);

      doc.end();

    } catch (error) {
      console.error('[Weekly PDF v11.4] Generation error:', error);
      reject(error);
    }
  });
}

// =====================================================
// EXPORTS
// =====================================================
export { 
  generateWeeklyPDF,
  // Export individual drawing functions for custom use
  drawPerformanceTable,
  drawSectorTable,
  drawEarningsTable,
  drawIndexPerformanceTable,
  // v12.0: New component drawing functions
  drawWeeklyCalendarTable,
  drawBofASection,
  drawBreadthSection,
  drawFlowsSection,
  drawCTASection,
  // Original drawing functions
  drawTradeIdeaCard,
  drawTradeIdeaProse,
  drawTradeIdea,
  drawMacroEvent,
  drawRiskItem,
  drawChartImage,
  drawBodyText,
  drawSectionTitle,
  drawSubSectionTitle,
  drawDayHeader,
  drawCoverPage,
  drawDisclaimerPage,
  drawContentPageHeader,
  drawContentPageFooter,
  // Utilities
  cleanText,
  formatNumber,
  formatPercent,
  formatDateShort,
  needsPageBreak,
  // Constants
  TACTICAL_SUBSECTIONS,
  PAGE,
  LIGHT,
  DARK,
  FONTS,
};

export default {
  generateWeeklyPDF,
};