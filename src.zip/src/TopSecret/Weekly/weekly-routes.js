// =====================================================
// WEEKLY TACTICAL REVIEW - EXPRESS ROUTES v1.0
// =====================================================

import {
  initWeeklyService,
  generateWeeklyReport,
  fetchWeeklyProgress,
  workflowManager,
  VERSION,
  AGENT_DEFINITIONS,
  PHASE_LABELS,
} from './index.js';

// In-memory report cache
const reportCache = new Map();

/**
 * Setup Weekly Tactical routes on Express app
 * @param {Express} app - Express application
 * @param {SupabaseClient} supabase - Supabase client (optional, for future persistent storage)
 * @param {Object} options - Configuration options (optional)
 */
export function setupWeeklyRoutes(app, supabase, options) {
  // Handle both signatures: (app, options) and (app, supabase, options)
  let opts = {};
  let supabaseClient = null;
  
  if (supabase && typeof supabase === 'object') {
    // Check if it's a supabase client (has 'from' method) or options object
    if (typeof supabase.from === 'function') {
      supabaseClient = supabase;
      opts = options || {};
    } else {
      // It's actually an options object
      opts = supabase;
    }
  }
  
  console.log('[Weekly Tactical Routes] Setting up routes...');
  console.log(`[Weekly Tactical Routes] Supabase client: ${supabaseClient ? 'provided' : 'not provided'}`);
  
  // Initialize the service
  initWeeklyService({
    supabase: supabaseClient,
    openaiApiKey: opts.openaiApiKey || process.env.OPENAI_API_KEY,
    polygonApiKey: opts.polygonApiKey || process.env.POLYGON_API_KEY,
    perplexityApiKey: opts.perplexityApiKey || process.env.PERPLEXITY_API_KEY,
  });

  // =====================================================
  // POST /api/reports/weekly/generate
  // Start generating a new report
  // =====================================================
  app.post('/api/reports/weekly/generate', async (req, res) => {
    try {
      const { reportWeek } = req.body;
      
      const weekStr = reportWeek || new Date().toISOString().split('T')[0];
      const reportId = `weekly-${weekStr}-${Date.now()}`;
      
      console.log(`[Weekly Tactical API] Starting generation: ${reportId}`);
      
      // Start generation in background
      generateWeeklyReport(weekStr, {
        reportId,
        onProgress: (progress) => {
          // Progress tracked via workflowManager
        },
        onAgentComplete: (agent) => {
          console.log(`[Weekly Tactical API] Agent ${agent.agentName}: ${agent.success ? '✓' : '✗'}`);
        },
        onError: (error) => {
          console.error(`[Weekly Tactical API] Error:`, error.message);
        },
      }).then(result => {
        if (result.success) {
          reportCache.set(reportId, result);
          console.log(`[Weekly Tactical API] Report ${reportId} completed and cached`);
        }
      }).catch(error => {
        console.error(`[Weekly Tactical API] Generation failed:`, error);
      });
      
      // Return immediately with reportId
      res.json({
        success: true,
        data: {
          reportId,
          reportWeek: weekStr,
          status: 'running',
          message: 'Report generation started. Poll /progress/:reportId for updates.',
        },
      });
      
    } catch (error) {
      console.error('[Weekly Tactical API] Generate error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // =====================================================
  // GET /api/reports/weekly/progress/:reportId
  // Get generation progress
  // =====================================================
  app.get('/api/reports/weekly/progress/:reportId', async (req, res) => {
    try {
      const { reportId } = req.params;
      const progress = fetchWeeklyProgress(reportId);
      
      if (progress.status === 'not_found') {
        // Check if completed in cache
        const cached = reportCache.get(reportId);
        if (cached) {
          return res.json({
            success: true,
            data: {
              reportId,
              status: 'completed',
              progress: 100,
              completedAgents: cached.meta?.agentsCompleted || 0,
              elapsedSeconds: Math.floor((cached.meta?.durationMs || 0) / 1000),
            },
          });
        }
        
        return res.status(404).json({
          success: false,
          error: 'Report not found',
        });
      }
      
      res.json({
        success: true,
        data: progress,
      });
      
    } catch (error) {
      console.error('[Weekly Tactical API] Progress error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // =====================================================
  // GET /api/reports/weekly/report/:reportId
  // Get completed report with full content
  // =====================================================
  app.get('/api/reports/weekly/report/:reportId', async (req, res) => {
    try {
      const { reportId } = req.params;
      
      const cached = reportCache.get(reportId);
      if (!cached) {
        return res.status(404).json({
          success: false,
          error: 'Report not found',
        });
      }
      
      // Build markdown content from sections if available
      let markdownContent = '';
      let htmlContent = '';
      
      const sections = cached.report?.sections || {};
      const reportData = cached.report || {};
      
      // Try to build markdown from section data
      if (sections.final_compiler?.data?.compiledReport) {
        markdownContent = sections.final_compiler.data.compiledReport;
      } else if (sections.final_compiler?.data?.markdown) {
        markdownContent = sections.final_compiler.data.markdown;
      } else {
        // Build markdown from individual sections
        const parts = [];
        
        // Title
        parts.push(`# Weekly Tactical Review`);
        parts.push(`**Week of ${cached.reportWeek}**`);
        parts.push('');
        parts.push('---');
        parts.push('');
        
        // Week Summary / Narrative
        if (sections.week_narrative_writer?.data?.narrative) {
          parts.push('## The Week That Was');
          parts.push('');
          parts.push(sections.week_narrative_writer.data.narrative);
          parts.push('');
        }
        
        // Sector Analysis
        if (sections.sector_rotation_analyzer?.data?.analysis) {
          parts.push('## Sector Rotation Analysis');
          parts.push('');
          parts.push(sections.sector_rotation_analyzer.data.analysis);
          parts.push('');
        }
        
        // Macro Events
        if (sections.macro_events_writer?.data?.analysis) {
          parts.push('## The Week Ahead - Macro');
          parts.push('');
          parts.push(sections.macro_events_writer.data.analysis);
          parts.push('');
        }
        
        // Micro Events
        if (sections.micro_events_writer?.data?.analysis) {
          parts.push('## Micro Events & Earnings');
          parts.push('');
          parts.push(sections.micro_events_writer.data.analysis);
          parts.push('');
        }
        
        // Tactical Analysis
        if (sections.tactical_macro_analyst?.data?.analysis) {
          parts.push('## Tactical Macro Analysis');
          parts.push('');
          parts.push(sections.tactical_macro_analyst.data.analysis);
          parts.push('');
        }
        
        // Flows & Sentiment
        if (sections.flows_sentiment_analyst?.data?.analysis) {
          parts.push('## Flows & Sentiment');
          parts.push('');
          parts.push(sections.flows_sentiment_analyst.data.analysis);
          parts.push('');
        }
        
        // Risk Assessment
        if (sections.risk_assessment_builder?.data?.analysis) {
          parts.push('## Risk Assessment');
          parts.push('');
          parts.push(sections.risk_assessment_builder.data.analysis);
          parts.push('');
        }
        
        // Trade Ideas
        if (sections.trade_idea_generator?.data?.ideas) {
          parts.push('## Trade Ideas');
          parts.push('');
          const ideas = sections.trade_idea_generator.data.ideas;
          if (Array.isArray(ideas)) {
            ideas.forEach((idea, idx) => {
              parts.push(`### Trade ${idx + 1}: ${idea.ticker || idea.symbol || 'Idea'}`);
              parts.push('');
              if (idea.thesis) parts.push(idea.thesis);
              if (idea.direction) parts.push(`**Direction:** ${idea.direction}`);
              if (idea.entry) parts.push(`**Entry:** ${idea.entry}`);
              if (idea.target) parts.push(`**Target:** ${idea.target}`);
              if (idea.stop) parts.push(`**Stop:** ${idea.stop}`);
              if (idea.timeframe) parts.push(`**Timeframe:** ${idea.timeframe}`);
              if (idea.conviction) parts.push(`**Conviction:** ${idea.conviction}`);
              parts.push('');
            });
          } else if (typeof ideas === 'string') {
            parts.push(ideas);
            parts.push('');
          }
        }
        
        // Risk Manager additions
        if (sections.risk_manager?.data?.analysis) {
          parts.push('## Risk Management');
          parts.push('');
          parts.push(sections.risk_manager.data.analysis);
          parts.push('');
        }
        
        // Coherence check summary
        if (sections.coherence_checker?.data?.summary) {
          parts.push('---');
          parts.push('');
          parts.push(`*QA Score: ${sections.coherence_checker.data.qaScore || 'N/A'}/100*`);
          parts.push('');
        }
        
        // Footer
        parts.push('---');
        parts.push('');
        parts.push(`*Report generated on ${new Date(cached.meta?.generatedAt || Date.now()).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}*`);
        parts.push('');
        parts.push('*This report is for informational purposes only and does not constitute investment advice.*');
        
        markdownContent = parts.join('\n');
      }
      
      console.log(`[Weekly Tactical API] Returning report ${reportId} with ${markdownContent.length} chars`);
      
      res.json({
        success: true,
        data: {
          reportId,
          reportWeek: cached.reportWeek,
          meta: cached.meta,
          hasPdf: !!cached.pdfBuffer,
          // Include actual content!
          markdown_content: markdownContent,
          html_content: htmlContent,
          content: markdownContent,
          // Also include raw sections for debugging
          sections: Object.keys(sections),
          qa_score: sections.coherence_checker?.data?.qaScore || cached.meta?.qaScore,
          created_at: cached.meta?.generatedAt,
        },
      });
      
    } catch (error) {
      console.error('[Weekly Tactical API] Get report error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // =====================================================
  // GET /api/reports/weekly/report/:reportId/pdf
  // Download PDF
  // =====================================================
  app.get('/api/reports/weekly/report/:reportId/pdf', async (req, res) => {
    try {
      const { reportId } = req.params;
      
      const cached = reportCache.get(reportId);
      if (!cached || !cached.pdfBuffer) {
        return res.status(404).json({
          success: false,
          error: 'PDF not found',
        });
      }
      
      // Ensure pdfBuffer is a valid Buffer
      const pdfBuffer = Buffer.isBuffer(cached.pdfBuffer) 
        ? cached.pdfBuffer 
        : (cached.pdfBuffer.buffer || cached.pdfBuffer);
      
      if (!pdfBuffer || !pdfBuffer.length) {
        return res.status(500).json({
          success: false,
          error: 'Invalid PDF buffer',
        });
      }
      
      const filename = `Weekly_Tactical_Review_${cached.reportWeek || 'report'}.pdf`;
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Length', pdfBuffer.length);
      res.send(pdfBuffer);
      
      console.log(`[Weekly Tactical API] PDF sent: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
      
    } catch (error) {
      console.error('[Weekly Tactical API] PDF error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // =====================================================
  // GET /api/reports/weekly/agents
  // Get agent definitions
  // =====================================================
  app.get('/api/reports/weekly/agents', (req, res) => {
    const agents = AGENT_DEFINITIONS.map(agent => ({
      id: agent.id,
      name: agent.name,
      description: agent.description,
      phase: agent.phase,
      phaseLabel: PHASE_LABELS[agent.phase],
      order: agent.order,
      estimatedSeconds: agent.estimatedSeconds,
    }));

    res.json({
      success: true,
      data: {
        agents,
        totalAgents: agents.length,
        version: VERSION,
      },
    });
  });

  // =====================================================
  // GET /api/reports/weekly/status
  // Get service status
  // =====================================================
  app.get('/api/reports/weekly/status', (req, res) => {
    const activeWorkflows = workflowManager.getAll().filter(w => w.status === 'running');
    
    res.json({
      success: true,
      data: {
        version: VERSION,
        status: 'operational',
        activeGenerations: activeWorkflows.length,
        cachedReports: reportCache.size,
        agentCount: AGENT_DEFINITIONS.length,
        hasOpenAI: !!process.env.OPENAI_API_KEY,
        hasPolygon: !!process.env.POLYGON_API_KEY,
        hasPerplexity: !!process.env.PERPLEXITY_API_KEY,
      },
    });
  });

  // =====================================================
  // GET /api/reports/weekly/latest
  // Get latest report
  // =====================================================
  app.get('/api/reports/weekly/latest', async (req, res) => {
    try {
      let latest = null;
      let latestTime = 0;
      
      for (const [id, report] of reportCache.entries()) {
        const time = new Date(report.meta?.generatedAt || 0).getTime();
        if (time > latestTime) {
          latestTime = time;
          latest = { id, report };
        }
      }
      
      if (!latest) {
        return res.status(404).json({
          success: false,
          error: 'No reports found',
        });
      }
      
      res.json({
        success: true,
        data: {
          reportId: latest.id,
          reportWeek: latest.report.reportWeek,
          meta: latest.report.meta,
          hasPdf: !!latest.report.pdfBuffer,
        },
      });
      
    } catch (error) {
      console.error('[Weekly Tactical API] Latest error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // =====================================================
  // DELETE /api/reports/weekly/report/:reportId
  // Delete a report
  // =====================================================
  app.delete('/api/reports/weekly/report/:reportId', async (req, res) => {
    try {
      const { reportId } = req.params;
      
      reportCache.delete(reportId);
      workflowManager.delete(reportId);
      
      res.json({
        success: true,
        message: 'Report deleted',
      });
      
    } catch (error) {
      console.error('[Weekly Tactical API] Delete error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  console.log('[Weekly Tactical Routes] Routes configured:');
  console.log('  POST   /api/reports/weekly/generate');
  console.log('  GET    /api/reports/weekly/progress/:reportId');
  console.log('  GET    /api/reports/weekly/report/:reportId');
  console.log('  GET    /api/reports/weekly/report/:reportId/pdf');
  console.log('  GET    /api/reports/weekly/agents');
  console.log('  GET    /api/reports/weekly/status');
  console.log('  GET    /api/reports/weekly/latest');
  console.log('  DELETE /api/reports/weekly/report/:reportId');
}

export default setupWeeklyRoutes;