// =====================================================
// WEEKLY TACTICAL REVIEW - AGENTS v12.0
// =====================================================
// MIDAPNIM INSTITUTIONAL STYLE - Full Implementation
// 
// v12.0 Changes:
//   - NEW: SentimentDataFetcherAgent (BofA Bull & Bear data)
//   - NEW: FlowsDataFetcherAgent (institutional flows data)
//   - NEW: WeeklyCalendarAgent (detailed day-by-day calendar)
//   - NEW: BofAIndicatorAgent (indicator with component breakdown)
//   - NEW: MarketBreadthAgent (% above MA50/200, A/D line)
//   - NEW: InstitutionalFlowsAgent (detailed $B flows)
//   - NEW: CTAPositioningAgent (systematic exposure levels)
// v11.2: News-driven Midapnim style
// v11.0: Initial news-driven approach
// =====================================================

import OpenAI from 'openai';
import {
  PHASES,
  AGENT_DEFINITIONS,
  WRITING_MANDATE,
  MARKET_INDICES,
  EXTENDED_INDICES,
  SECTOR_ETFS,
  TACTICAL_SUBSECTIONS,
  SENTIMENT_INDICATORS,
  BOFA_COMPONENTS,
  BREADTH_THRESHOLDS,
  CTA_LEVELS,
  FLOW_CATEGORIES,
} from './config.js';

// ============================================
// OPENAI CLIENT
// ============================================
let openaiClient = null;

function getOpenAI() {
  if (!openaiClient) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (apiKey) {
      openaiClient = new OpenAI({ apiKey });
      console.log('[Weekly Agents v12.0] OpenAI client initialized');
    }
  }
  return openaiClient;
}

// ============================================
// PERPLEXITY CLIENT
// ============================================
async function callPerplexity(prompt, options = {}) {
  const apiKey = process.env.PERPLEXITY_API_KEY;
  if (!apiKey) {
    console.warn('[Weekly Agents] No Perplexity API key');
    return null;
  }

  try {
    const response = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: options.model || 'llama-3.1-sonar-large-128k-online',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: options.maxTokens || 2500,
      }),
    });

    const data = await response.json();
    if (data.choices && data.choices[0]) {
      return data.choices[0].message.content;
    }
    return null;
  } catch (error) {
    console.error('[Perplexity] Error:', error.message);
    return null;
  }
}

// ============================================
// TEXT CLEANING
// ============================================
function stripMarkdown(text) {
  if (!text) return '';
  return String(text)
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/#{1,6}\s*/g, '')
    .replace(/`{1,3}/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/^\s*[-•]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .trim();
}

// ============================================
// THE MIDAPNIM WRITING MANDATE v12.0
// ============================================
function getWritingMandate() {
  return `
═══════════════════════════════════════════════════════════════════════════════
MIDAPNIM INSTITUTIONAL WRITING STANDARDS v12.0
═══════════════════════════════════════════════════════════════════════════════

PHILOSOPHY: You are NOT an AI assistant. You ARE a senior analyst at Goldman Sachs
who has watched markets for 20 years. Write like explaining markets to a sophisticated
investor - confident, direct, with specific data and historical context.

═══════════════════════════════════════════════════════════════════════════════
CENTRAL THESIS REQUIREMENT
═══════════════════════════════════════════════════════════════════════════════

Every section must connect to the week's CENTRAL THESIS. Examples:
- "Defensive rotation with Energy leadership signals late-cycle positioning"
- "Run-it-hot environment continues - growth with clear constraints"
- "Repricing of risk premiums as Fed flexibility narrows"

═══════════════════════════════════════════════════════════════════════════════
CRITICAL: NO MARKDOWN IN OUTPUT
═══════════════════════════════════════════════════════════════════════════════

NEVER use ** for bold, ## for headers, * for bullets, \` for code.
Write PLAIN TEXT only. Professional prose. No formatting symbols.

═══════════════════════════════════════════════════════════════════════════════
NUMBER RULES
═══════════════════════════════════════════════════════════════════════════════

WRONG: "64%." / "683. 17" / "respectively. 83%"
CORRECT: "SPY fell 0.64% to $683.17" / "Energy surged 2.56%"

THE RULE: Ticker/Asset + Direction + Number + Context. Always.

FLOW AMOUNTS: "Long-only funds sold $3.2 billion net" not "LOs were sellers"

═══════════════════════════════════════════════════════════════════════════════
MIDAPNIM SIGNATURE PATTERNS
═══════════════════════════════════════════════════════════════════════════════

CONTRARIAN: "Exactly at this point the tactical risk begins to appear."
KEY ISSUE: "The key issue is not X, but Y."
IF-THEN: "If X happens, expect Y."
HISTORICAL: "Historically, such levels..." / "Readings like these haven't been seen since..."
INDICATORS: "The BofA Bull & Bear indicator at 7.2..." / "Put/call at 1.15..."
TWO SIDES: "From one side... from the other side..."
NOT PANIC: "This is not panic - it is repositioning."
FLOWS: "Evidence from flows suggests..." / "LOs sold $3B while HFs added $1.5B..."

═══════════════════════════════════════════════════════════════════════════════
PARAGRAPH STRUCTURE - Max 4 sentences per paragraph
═══════════════════════════════════════════════════════════════════════════════

Each paragraph: OBSERVATION → CONTEXT → SIGNIFICANCE → IMPLICATION

OUTPUT: Plain English text. Professional. Direct. No markdown.
═══════════════════════════════════════════════════════════════════════════════
`;
}

async function callOpenAI(systemPrompt, userPrompt, options = {}) {
  const openai = getOpenAI();
  if (!openai) {
    console.warn('[Agent] No OpenAI client available');
    return null;
  }

  const writingMandate = getWritingMandate();
  const fullSystemPrompt = writingMandate + '\n\n' + systemPrompt;

  try {
    const response = await openai.chat.completions.create({
      model: options.model || 'gpt-4o',
      messages: [
        { role: 'system', content: fullSystemPrompt },
        { role: 'user', content: userPrompt },
      ],
      max_tokens: options.maxTokens || 2500,
      temperature: options.temperature || 0.7,
    });

    let content = response.choices[0]?.message?.content || null;
    if (content) {
      content = stripMarkdown(content);
    }
    return content;
  } catch (error) {
    console.error('[OpenAI] Error:', error.message);
    return null;
  }
}

// ============================================
// VALIDATION
// ============================================
function validateText(text, minLength = 100) {
  if (!text || text.length < minLength) return false;
  
  const badPatterns = [
    /^\d{1,3}%\.?\s/m,
    /\.\s+\d{1,3}%\.?\s/,
    /\d{3}\.\s+\d{2}/,
    /\*\*[^*]+\*\*/,
    /^\s*[-•]\s+/m,
    /it is worth noting/i,
    /as an AI/i,
  ];
  
  return !badPatterns.some(pattern => pattern.test(text));
}

// ============================================
// BASE AGENT CLASS
// ============================================
class BaseAgent {
  constructor(definition) {
    this.id = definition.id;
    this.name = definition.name;
    this.description = definition.description;
    this.phase = definition.phase;
    this.order = definition.order;
    this.dependencies = definition.dependencies || [];
    this.apiKey = null;
  }

  setApiKey(key) {
    this.apiKey = key;
  }

  async execute(context) {
    throw new Error('Execute method must be implemented by subclass');
  }
}

// ============================================
// AGENT 1: MARKET DATA FETCHER
// ============================================
class MarketDataFetcherAgent extends BaseAgent {
  async execute(context) {
    const { dataService } = context;
    console.log(`[${this.name}] Fetching market data...`);

    try {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 7);

      const startStr = startDate.toISOString().split('T')[0];
      const endStr = endDate.toISOString().split('T')[0];

      const indexSymbols = Object.keys(MARKET_INDICES);
      const sectorSymbols = Object.keys(SECTOR_ETFS);
      const extendedSymbols = Object.keys(EXTENDED_INDICES);

      let indices = {};
      let sectors = {};
      let extended = {};

      if (dataService) {
        [indices, sectors, extended] = await Promise.all([
          dataService.fetchMarketData(indexSymbols, startStr, endStr),
          dataService.fetchMarketData(sectorSymbols, startStr, endStr),
          dataService.fetchMarketData(extendedSymbols, startStr, endStr),
        ]);
      } else {
        indices = this.generateMockData(indexSymbols);
        sectors = this.generateMockData(sectorSymbols);
        extended = this.generateMockData(extendedSymbols);
      }

      return {
        success: true,
        data: { indices, sectors, extended, dateRange: { start: startStr, end: endStr } },
      };
    } catch (error) {
      console.error(`[${this.name}] Error:`, error.message);
      return {
        success: false,
        error: error.message,
        data: { indices: {}, sectors: {}, extended: {} },
      };
    }
  }

  generateMockData(symbols) {
    const data = {};
    for (const symbol of symbols) {
      const basePrice = this.getBasePrice(symbol);
      const change = (Math.random() - 0.5) * 4;
      data[symbol] = {
        symbol,
        open: basePrice,
        close: basePrice * (1 + change / 100),
        high: basePrice * (1 + Math.abs(change) / 100 + 0.5),
        low: basePrice * (1 - Math.abs(change) / 100 - 0.5),
        weeklyReturn: change.toFixed(2),
        avgVolume: Math.round(Math.random() * 50000000 + 10000000),
        source: 'mock',
      };
    }
    return data;
  }

  getBasePrice(symbol) {
    const prices = {
      SPY: 595, QQQ: 525, IWM: 225, DIA: 435,
      VIX: 15, GLD: 245, TLT: 90, USO: 78, UUP: 28,
      HYG: 78, LQD: 108, EEM: 42, EFA: 78, FXI: 28,
      XLK: 235, XLF: 50, XLE: 95, XLV: 148,
      XLI: 135, XLP: 85, XLY: 215, XLU: 78,
      XLB: 90, XLRE: 45, XLC: 95,
    };
    return prices[symbol] || 100;
  }
}

// ============================================
// AGENT 2: NEWS AGGREGATOR
// ============================================
class NewsAggregatorAgent extends BaseAgent {
  async execute(context) {
    console.log(`[${this.name}] Aggregating market news and identifying hot topics...`);

    const newsPrompt = `Provide a comprehensive summary of the most important US stock market news from the past week. Include:
1. Major index moves and their primary drivers
2. Key economic data releases and their implications
3. Federal Reserve commentary and rate expectations
4. Significant corporate news and earnings
5. Geopolitical events affecting markets
6. Fund flow data if available

Be specific with numbers. Write as an executive briefing for institutional investors.`;

    const news = await callPerplexity(newsPrompt, { maxTokens: 2500 });

    const hotTopicsPrompt = `Analyze the major financial news from the past week and identify the 2-3 DOMINANT THEMES that appeared repeatedly across multiple news sources. 

For each theme, write 2-3 sentences explaining:
- What the market was focused on
- Why it mattered to investors
- How the market reacted or what investors feared

Write in professional institutional research style. NO bullet points. Flowing prose only.`;

    const hotTopicsResponse = await callPerplexity(hotTopicsPrompt, { maxTokens: 1200 });
    const hotTopics = await this.generateHotTopicsAnalysis(hotTopicsResponse);

    return {
      success: true,
      data: {
        news: news || 'Markets focused on Fed policy trajectory amid mixed economic signals.',
        hotTopics: hotTopics,
        source: news ? 'perplexity' : 'fallback',
      },
    };
  }

  async generateHotTopicsAnalysis(perplexityResponse) {
    if (!perplexityResponse || perplexityResponse.length < 100) {
      return null;
    }

    const systemPrompt = `You are a senior market strategist. Rewrite the following market themes analysis in Midapnim institutional style:

REQUIREMENTS:
- 2-3 paragraphs covering the dominant themes
- Each paragraph should cover ONE theme
- Include market sentiment and investor psychology
- Use phrases like "Market participants remained focused on...", "The dominant narrative shifted to...", "Concerns intensified around..."
- NO bullet points, NO markdown, flowing prose only
- Be specific about what the market feared or anticipated`;

    const analysis = await callOpenAI(systemPrompt, perplexityResponse, { maxTokens: 800 });
    return analysis || perplexityResponse;
  }
}

// ============================================
// AGENT 3: ECONOMIC CALENDAR FETCHER
// ============================================
class EconomicCalendarFetcherAgent extends BaseAgent {
  async execute(context) {
    console.log(`[${this.name}] Fetching REAL economic calendar from Perplexity...`);

    const today = new Date();
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay() + 1);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 4);
    
    const formatDate = (d) => `${d.toLocaleString('en-US', { month: 'long' })} ${d.getDate()}, ${d.getFullYear()}`;

    const prompt = `List ALL important US economic data releases scheduled for THIS WEEK (${formatDate(weekStart)} to ${formatDate(weekEnd)}).

For EACH event provide in this EXACT format:
- Day: [exact day of week]
- Event: [official event name]
- Previous: [last reading with unit]
- Forecast: [consensus forecast with unit]
- Importance: [high/medium/low]

Include: GDP, PCE, CPI, PPI, Employment data, Fed speeches, Consumer Confidence, Housing data, Manufacturing PMI, Services PMI, Retail Sales, Industrial Production, Durable Goods, etc.

ONLY include events actually scheduled for this specific week. Do not make up events.`;

    const calendarData = await callPerplexity(prompt, { maxTokens: 2500 });
    const events = this.parseEventsFromResponse(calendarData);

    return {
      success: true,
      data: {
        events: events,
        rawCalendar: calendarData,
        weekRange: `${formatDate(weekStart)} - ${formatDate(weekEnd)}`,
        source: 'perplexity_live',
      },
    };
  }

  parseEventsFromResponse(response) {
    if (!response) return [];
    
    const events = [];
    const lines = response.split('\n');
    let currentEvent = {};
    
    for (const line of lines) {
      const dayMatch = line.match(/Day:\s*(\w+)/i);
      const eventMatch = line.match(/Event:\s*(.+)/i);
      const previousMatch = line.match(/Previous:\s*(.+)/i);
      const forecastMatch = line.match(/Forecast:\s*(.+)/i);
      const importanceMatch = line.match(/Importance:\s*(\w+)/i);
      
      if (dayMatch) currentEvent.day = dayMatch[1];
      if (eventMatch) currentEvent.name = eventMatch[1].trim();
      if (previousMatch) currentEvent.previous = previousMatch[1].trim();
      if (forecastMatch) currentEvent.forecast = forecastMatch[1].trim();
      if (importanceMatch) {
        currentEvent.importance = importanceMatch[1].toLowerCase();
        if (currentEvent.name && currentEvent.day) {
          events.push({ ...currentEvent });
          currentEvent = {};
        }
      }
    }
    
    if (events.length === 0) {
      return this.alternativeParse(response);
    }
    
    return events;
  }
  
  alternativeParse(response) {
    const events = [];
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    
    for (const day of days) {
      const dayRegex = new RegExp(`${day}[:\\s]*([^]*?)(?=${days.filter(d => d !== day).join('|')}|$)`, 'i');
      const dayMatch = response.match(dayRegex);
      
      if (dayMatch) {
        const dayContent = dayMatch[1];
        const eventPatterns = dayContent.match(/([A-Z][^.]*?(?:Index|Sales|Claims|GDP|PCE|CPI|PPI|PMI|Confidence|Orders|Production)[^.]*)/gi);
        
        if (eventPatterns) {
          for (const eventText of eventPatterns) {
            const prevMatch = eventText.match(/(?:previous|prior|last)[\s:]*([0-9.%KMB-]+)/i);
            const fcstMatch = eventText.match(/(?:forecast|expected|consensus)[\s:]*([0-9.%KMB-]+)/i);
            
            events.push({
              day,
              name: eventText.split(/[,;]/)[0].trim().substring(0, 50),
              previous: prevMatch ? prevMatch[1] : 'N/A',
              forecast: fcstMatch ? fcstMatch[1] : 'N/A',
              importance: eventText.toLowerCase().includes('gdp') || 
                         eventText.toLowerCase().includes('pce') ||
                         eventText.toLowerCase().includes('employment') ? 'high' : 'medium',
            });
          }
        }
      }
    }
    
    return events;
  }
}

// ============================================
// AGENT 4: SENTIMENT DATA FETCHER (NEW v12.0)
// ============================================
class SentimentDataFetcherAgent extends BaseAgent {
  async execute(context) {
    console.log(`[${this.name}] Fetching REAL sentiment indicators data...`);

    const prompt = `What are the CURRENT readings for these sentiment indicators as of THIS WEEK?

1. BofA Bull & Bear Indicator - current reading on 0-10 scale
2. AAII Sentiment Survey - latest % bullish and % bearish
3. CNN Fear & Greed Index - current reading
4. Put/Call Ratio - latest reading
5. VIX - current level

Be specific with actual current numbers. If you don't have the exact current data, say so.`;

    const sentimentData = await callPerplexity(prompt, { maxTokens: 1200 });
    const parsed = this.parseSentimentData(sentimentData);

    return {
      success: true,
      data: {
        raw: sentimentData,
        parsed: parsed,
        hasRealData: parsed.hasRealData,
        source: 'perplexity_live',
      },
    };
  }

  parseSentimentData(response) {
    if (!response) {
      return { hasRealData: false };
    }

    // Extract actual numbers from response
    const bofaMatch = response.match(/bull.*bear.*?(\d+\.?\d*)/i);
    const putCallMatch = response.match(/put.*call.*?(\d+\.?\d*)/i);
    const vixMatch = response.match(/vix.*?(\d+\.?\d*)/i);
    const bullishMatch = response.match(/(\d+\.?\d*)%?\s*bullish/i) || response.match(/bullish.*?(\d+\.?\d*)%/i);
    const bearishMatch = response.match(/(\d+\.?\d*)%?\s*bearish/i) || response.match(/bearish.*?(\d+\.?\d*)%/i);
    const fearGreedMatch = response.match(/fear.*greed.*?(\d+)/i) || response.match(/(\d+).*fear.*greed/i);

    const bofaValue = bofaMatch ? parseFloat(bofaMatch[1]) : null;
    
    const data = {
      hasRealData: !!(bofaValue || bullishMatch || vixMatch),
      bofaBullBear: {
        value: bofaValue,
        signal: bofaValue >= 8 ? 'sell' : bofaValue <= 2 ? 'buy' : bofaValue >= 6 ? 'bullish' : bofaValue <= 4 ? 'bearish' : 'neutral',
        components: {}, // Will be populated by BofA agent if needed
      },
      putCallRatio: putCallMatch ? parseFloat(putCallMatch[1]) : null,
      vix: {
        spot: vixMatch ? parseFloat(vixMatch[1]) : null,
      },
      aaii: {
        bullish: bullishMatch ? parseFloat(bullishMatch[1]) : null,
        bearish: bearishMatch ? parseFloat(bearishMatch[1]) : null,
      },
      fearGreed: fearGreedMatch ? parseFloat(fearGreedMatch[1]) : null,
    };

    console.log(`[SentimentDataFetcher] Parsed: BofA=${data.bofaBullBear.value}, VIX=${data.vix.spot}, AAII Bullish=${data.aaii.bullish}`);

    return data;
  }
}

// ============================================
// AGENT 5: FLOWS DATA FETCHER (NEW v12.0)
// ============================================
class FlowsDataFetcherAgent extends BaseAgent {
  async execute(context) {
    console.log(`[${this.name}] Fetching REAL institutional flows data...`);

    const prompt = `What were the institutional fund flows in US equities THIS WEEK?

I need SPECIFIC dollar amounts if available:
1. Long-only funds - net flows ($B)
2. Hedge funds - net positioning ($B)
3. ETF flows by sector (Tech, Financials, Energy) in $B

Only provide actual data. If not available, say "not available".`;

    const flowsData = await callPerplexity(prompt, { maxTokens: 1200 });
    const parsed = this.parseFlowsData(flowsData);

    return {
      success: true,
      data: {
        raw: flowsData,
        parsed: parsed,
        hasRealData: parsed.hasRealData,
        source: 'perplexity_live',
      },
    };
  }

  parseFlowsData(response) {
    if (!response) {
      return { hasRealData: false };
    }

    // Extract actual numbers - no fallbacks
    const loNet = this.extractBillions(response, /long.*only.*?([+-]?\$?\d+\.?\d*)\s*(?:billion|bn|b\b)/i);
    const hfNet = this.extractBillions(response, /hedge.*fund.*?([+-]?\$?\d+\.?\d*)\s*(?:billion|bn|b\b)/i);
    
    const data = {
      hasRealData: !!(loNet || hfNet),
      longOnly: loNet ? { net: loNet } : null,
      hedgeFunds: hfNet ? { net: hfNet } : null,
      sectorFlows: this.parseSectorFlows(response),
    };

    console.log(`[FlowsDataFetcher] Parsed: LO=${data.longOnly?.net || 'N/A'}, HF=${data.hedgeFunds?.net || 'N/A'}`);

    return data;
  }

  parseSectorFlows(response) {
    const sectors = {};
    const tech = this.extractBillions(response, /tech.*?([+-]?\$?\d+\.?\d*)\s*(?:billion|bn|b\b)/i);
    const fin = this.extractBillions(response, /financ.*?([+-]?\$?\d+\.?\d*)\s*(?:billion|bn|b\b)/i);
    const energy = this.extractBillions(response, /energy.*?([+-]?\$?\d+\.?\d*)\s*(?:billion|bn|b\b)/i);
    
    if (tech) sectors.technology = tech;
    if (fin) sectors.financials = fin;
    if (energy) sectors.energy = energy;
    
    return Object.keys(sectors).length > 0 ? sectors : null;
  }

  extractBillions(text, regex) {
    if (!text) return null;
    const match = text.match(regex);
    if (match) {
      let num = parseFloat(match[1].replace('$', ''));
      return num;
    }
    return null;
  }
}

// ============================================
// AGENT 6: WEEK NARRATIVE WRITER
// ============================================
class WeekNarrativeWriterAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing EXACT Midapnim-style narrative...`);

    const marketData = previousResults?.market_data_fetcher?.data || {};
    const newsData = previousResults?.news_aggregator?.data || {};
    const indices = marketData.indices || {};
    
    const spy = indices.SPY || {};
    const qqq = indices.QQQ || {};
    const vix = indices.VIX || {};

    const weekEvents = await this.getWeeklyMarketEvents();
    const flowsData = await this.getInstitutionalFlows();
    const centralThesis = await this.deriveCentralThesis(weekEvents, flowsData);
    const narrative = await this.generateMidapnimNarrative(weekEvents, flowsData, marketData, centralThesis);

    return {
      success: true,
      data: {
        narrative,
        centralThesis,
        weekEvents,
        flowsData,
        indices: { spy, qqq, vix },
      },
    };
  }

  async getWeeklyMarketEvents() {
    const prompt = `What were the 3-4 SPECIFIC market-moving events in US markets THIS WEEK?

For each event provide:
1. WHAT happened (specific announcement, data release, geopolitical event)
2. IMMEDIATE market reaction (indices, sectors, specific stocks that moved)
3. PROBABILITY CHANGES if relevant (e.g., "rate cut probability jumped from 30% to 65%")
4. WHY it mattered to institutional investors

Be extremely specific with numbers, dates, and names. This is for professional investors.`;

    return await callPerplexity(prompt, { maxTokens: 2000 }) || '';
  }

  async getInstitutionalFlows() {
    const prompt = `What were the institutional fund flows and positioning changes in US equities THIS WEEK?

Include if available:
- Long-only funds (LOs): net buying/selling in $ billions
- Hedge funds (HFs): net positioning changes
- ETF flows: which sectors saw inflows/outflows
- Dealer gamma positioning (long or short gamma)
- Any notable short squeeze or long liquidation activity

Be specific with dollar amounts and directions.`;

    return await callPerplexity(prompt, { maxTokens: 1500 }) || '';
  }

  async deriveCentralThesis(weekEvents, flowsData) {
    if (!weekEvents || weekEvents.length < 50) {
      return 'Risk appetite remains fragile as macro uncertainty persists';
    }

    const prompt = `Based on this week's events and flows, what is the ONE central thesis?

Events: ${weekEvents.substring(0, 1000)}
Flows: ${flowsData.substring(0, 500)}

Respond with ONE sentence thesis in this style:
- "The week felt like a turning point, mainly due to..."
- "Markets are repricing X following Y, which means..."
- "Institutional rotation from X to Y signals..."`;

    const thesis = await callOpenAI(
      'You are a senior strategist at an Israeli investment research firm.',
      prompt,
      { maxTokens: 100 }
    );

    return thesis || 'Late-cycle positioning with selective risk appetite';
  }

  async generateMidapnimNarrative(weekEvents, flowsData, marketData, centralThesis) {
    const systemPrompt = `You are writing "What Drove the Markets" for Midapnim, an Israeli institutional research publication.

CRITICAL: Focus ONLY on NEWS STORIES and EVENTS. Do NOT mention index returns or percentages (no "SPY rose 0.16%").

WHAT TO WRITE ABOUT:
1. HEADLINES: What were the main news stories that moved markets?
   - Fed comments, economic data surprises, earnings news
   - Geopolitical developments, policy announcements
   - Specific company news that affected sectors

2. SECTOR ROTATION: Which sectors led/lagged and WHY (news-driven)
   GOOD: "Energy stocks surged as OPEC announced deeper production cuts, with crude hitting $87"
   BAD: "XLE rose 3.2% this week"

3. THEMES: What narratives dominated investor attention?
   - Rate expectations, inflation concerns, earnings revisions
   - Risk-on vs risk-off sentiment

4. FLOW CONTEXT: What institutional positioning tells us
   GOOD: "Long-only funds continued de-risking ahead of the Fed meeting"

FORBIDDEN:
- Do NOT cite specific index returns (SPY, QQQ, IWM percentages)
- Do NOT start with "Markets rose/fell X%"
- Do NOT use bullet points
- Do NOT be generic - be specific about news events

FORMAT: 2-3 paragraphs of flowing prose. Start with the dominant NEWS STORY of the week.`;

    const userPrompt = `WEEK'S NEWS EVENTS:
${weekEvents}

INSTITUTIONAL FLOWS:
${flowsData}

CENTRAL THESIS: ${centralThesis}

Write about WHAT HAPPENED (news, events, stories) - NOT about index performance numbers. Focus on the NEWS that drove sector moves and investor behavior.`;

    const narrative = await callOpenAI(systemPrompt, userPrompt, { maxTokens: 1400 });

    if (narrative && narrative.length > 400) {
      return stripMarkdown(narrative);
    }

    return this.generateMidapnimFallback(marketData, centralThesis, weekEvents, flowsData);
  }

  generateMidapnimFallback(marketData, centralThesis, weekEvents, flowsData) {
    return `The week was dominated by shifting narratives around Fed policy and corporate earnings. ${centralThesis}. The combination of mixed economic data and hawkish Fed commentary created sharp rotations beneath the surface, with defensive sectors gaining at the expense of high-beta growth names.

Energy and financials led as investors sought value and yield, benefiting from higher-for-longer rate expectations and rising commodity prices. Technology and consumer discretionary lagged as rate-sensitive areas faced renewed pressure. The rotation reflected a classic late-cycle playbook where investors balance growth exposure with defensive positioning.

Institutional behavior during the week suggested a risk management and profit protection mode. Long-only funds continued their pattern of selective de-risking while hedge funds showed mixed activity across sectors. The overall message from flows: maintain exposure but tighten risk controls heading into the next catalyst window.`;
  }
}

// ============================================
// AGENT 7: SECTOR ROTATION ANALYZER
// ============================================
class SectorRotationAnalyzerAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Analyzing sector rotation with Midapnim specificity...`);

    const marketData = previousResults?.market_data_fetcher?.data || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || 'Sector rotation environment';
    const sectors = marketData.sectors || {};

    const sectorReturns = Object.entries(sectors).map(([symbol, data]) => ({
      symbol,
      name: SECTOR_ETFS[symbol]?.name || symbol,
      return: parseFloat(data.weeklyReturn) || 0,
    })).sort((a, b) => b.return - a.return);

    const leaders = sectorReturns.slice(0, 3);
    const laggards = sectorReturns.slice(-3).reverse();

    const sectorNews = await this.getSectorSpecificNews(leaders, laggards);
    const analysis = await this.generateMidapnimSectorAnalysis(leaders, laggards, centralThesis, sectorNews);

    return {
      success: true,
      data: { leaders, laggards, analysis, centralThesis },
    };
  }

  async getSectorSpecificNews(leaders, laggards) {
    const leaderNames = leaders.map(l => l.name).join(', ');
    const laggardNames = laggards.map(l => l.name).join(', ');

    const prompt = `What SPECIFIC news, earnings, or events drove sector performance in US markets THIS WEEK?

Leading sectors: ${leaderNames}
Lagging sectors: ${laggardNames}

For each, provide SPECIFIC company names and what happened. Be detailed.`;

    return await callPerplexity(prompt, { maxTokens: 1200 }) || '';
  }

  async generateMidapnimSectorAnalysis(leaders, laggards, centralThesis, sectorNews) {
    const l1 = leaders[0] || { name: 'Energy', symbol: 'XLE', return: 2.56 };
    const l2 = leaders[1] || { name: 'Utilities', symbol: 'XLU', return: 0.86 };
    const lag1 = laggards[0] || { name: 'Consumer Disc.', symbol: 'XLY', return: -2.64 };

    const systemPrompt = `Write sector analysis in Midapnim institutional style. 2 paragraphs only.

STYLE: Reference specific company names that drove each sector. Explain WHY each moved.
End with: "This gap highlights that the market is currently very selective..."

NO bullet points. Flowing prose with specific company names.`;

    const userPrompt = `SECTOR NEWS: ${sectorNews}
THESIS: ${centralThesis}
Leaders: ${leaders.map(l => `${l.name} ${l.return > 0 ? '+' : ''}${l.return.toFixed(2)}%`).join(', ')}
Laggards: ${laggards.map(l => `${l.name} ${l.return.toFixed(2)}%`).join(', ')}`;

    const analysis = await callOpenAI(systemPrompt, userPrompt, { maxTokens: 800 });

    if (analysis && analysis.length > 200) {
      return stripMarkdown(analysis);
    }

    return `${l1.name} led the week with a ${l1.return.toFixed(2)}% gain, reflecting institutional preference for real assets and inflation protection. ${l2.name} gained ${l2.return.toFixed(2)}% as yield-seeking flows continued into defensive income producers. This leadership combination tells us that institutional money is positioning for a late-cycle environment.

On the laggard side, ${lag1.name} dropped ${Math.abs(lag1.return).toFixed(2)}% as rate sensitivity and consumer spending concerns weighed on discretionary names. This gap highlights that the market is currently very selective - money flows to sectors with visible earnings while avoiding areas where valuation already prices in optimistic scenarios.`;
  }
}

// ============================================
// AGENT 8: WEEKLY CALENDAR AGENT (v12.2 IMPROVED PARSING)
// ============================================
class WeeklyCalendarAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Fetching REAL calendar data for THIS WEEK...`);

    const baseEvents = previousResults?.economic_calendar_fetcher?.data?.events || [];
    
    // Get current week dates
    const today = new Date();
    const monday = new Date(today);
    monday.setDate(today.getDate() - today.getDay() + 1);
    const friday = new Date(monday);
    friday.setDate(monday.getDate() + 4);
    
    const formatDate = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const weekRange = `${formatDate(monday)} - ${formatDate(friday)}, ${monday.getFullYear()}`;

    // Structured prompt for better parsing
    const calendarPrompt = `List the US economic calendar for ${weekRange}.

FORMAT YOUR RESPONSE EXACTLY LIKE THIS:

MONDAY:
- [Event Name]: Previous [X], Forecast [Y]
- [Company Ticker] earnings

TUESDAY:
- [Event Name]: Previous [X], Forecast [Y]

Continue for Wednesday, Thursday, Friday.

Include: GDP, PCE, CPI, Jobs data, PMI, Consumer Confidence, Housing, Retail Sales, and major earnings (like AAPL, MSFT, NVDA, TSLA, etc).`;

    const rawData = await callPerplexity(calendarPrompt, { maxTokens: 2000 });
    console.log(`[WeeklyCalendarAgent] Raw response length: ${rawData?.length || 0}`);
    
    const calendar = this.parseCalendarData(rawData, baseEvents);

    // Log what was parsed
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    for (const day of days) {
      const dayData = calendar[day] || {};
      console.log(`[WeeklyCalendarAgent] ${day}: ${dayData.macro?.length || 0} macro, ${dayData.earnings?.length || 0} earnings`);
    }

    return {
      success: true,
      data: {
        calendar,
        weekRange,
        rawData,
        source: 'perplexity_live',
      },
    };
  }

  parseCalendarData(rawData, baseEvents) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const calendar = {};

    for (const day of days) {
      calendar[day] = { macro: [], earnings: [], fedSpeakers: [] };
    }

    // Add base events from economic_calendar_fetcher first
    for (const event of baseEvents) {
      const day = this.normalizeDay(event.day);
      if (calendar[day]) {
        calendar[day].macro.push({
          name: event.name,
          previous: event.previous,
          forecast: event.forecast,
        });
      }
    }

    // Parse Perplexity response
    if (rawData && rawData.length > 50) {
      this.parseResponse(calendar, rawData);
    }

    return calendar;
  }

  normalizeDay(dayStr) {
    if (!dayStr) return 'Monday';
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    for (const d of days) {
      if (dayStr.toLowerCase().includes(d.toLowerCase())) return d;
    }
    return 'Monday';
  }

  parseResponse(calendar, rawData) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    let currentDay = null;

    // Split by lines and process
    const lines = rawData.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      // Check if this line is a day header
      for (const day of days) {
        if (trimmed.toUpperCase().includes(day.toUpperCase()) && 
            (trimmed.includes(':') || trimmed.length < 30)) {
          currentDay = day;
          break;
        }
      }

      if (!currentDay) continue;

      // Economic indicators - look for common patterns
      const indicators = [
        'GDP', 'PCE', 'CPI', 'PPI', 'PMI', 'ISM', 'NFP', 'Payroll', 'Jobs', 'Employment',
        'Retail Sales', 'Housing', 'Home', 'Consumer', 'Confidence', 'Sentiment',
        'Claims', 'Jobless', 'Industrial', 'Production', 'Durable', 'Orders',
        'Trade', 'Import', 'Export', 'JOLTS', 'ADP', 'Beige Book'
      ];

      for (const indicator of indicators) {
        if (trimmed.toLowerCase().includes(indicator.toLowerCase())) {
          // Extract event name (first part before colon or numbers)
          let eventName = trimmed.split(/[:\-–]/)[0].trim();
          if (eventName.length > 50) eventName = eventName.substring(0, 50);
          
          // Skip if already added
          if (calendar[currentDay].macro.find(e => 
            e.name.toLowerCase().includes(indicator.toLowerCase())
          )) continue;

          // Extract numbers for previous/forecast
          const numbers = trimmed.match(/[\d]+\.?[\d]*%?/g) || [];
          
          calendar[currentDay].macro.push({
            name: eventName || indicator,
            previous: numbers[0] || 'N/A',
            forecast: numbers[1] || numbers[0] || 'N/A',
          });
          break;
        }
      }

      // Earnings - look for tickers or company names
      const tickers = trimmed.match(/\b([A-Z]{2,5})\b/g) || [];
      const knownTickers = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA', 'JPM', 'BAC', 
        'WMT', 'HD', 'LOW', 'CRM', 'COST', 'NKE', 'FDX', 'UNH', 'JNJ', 'PG', 'V', 'MA', 'DIS',
        'NFLX', 'PYPL', 'INTC', 'AMD', 'QCOM', 'TXN', 'AVGO', 'CSCO', 'ORCL', 'IBM', 'COP', 'XOM', 'CVX'];
      
      for (const ticker of tickers) {
        if (knownTickers.includes(ticker) && 
            !calendar[currentDay].earnings.find(e => e.ticker === ticker)) {
          calendar[currentDay].earnings.push({
            ticker,
            company: this.getCompanyName(ticker),
          });
        }
      }

      // Fed speakers
      const fedNames = ['Powell', 'Williams', 'Waller', 'Barkin', 'Bostic', 'Daly', 
        'Kashkari', 'Mester', 'Jefferson', 'Cook', 'Bowman', 'Goolsbee', 'Harker'];
      
      for (const name of fedNames) {
        if (trimmed.includes(name) && 
            !calendar[currentDay].fedSpeakers.find(f => f.name === name)) {
          calendar[currentDay].fedSpeakers.push({ name });
        }
      }
    }
  }

  getCompanyName(ticker) {
    const companies = {
      AAPL: 'Apple', MSFT: 'Microsoft', GOOGL: 'Alphabet', AMZN: 'Amazon',
      NVDA: 'NVIDIA', META: 'Meta', TSLA: 'Tesla', JPM: 'JPMorgan',
      BAC: 'Bank of America', WMT: 'Walmart', HD: 'Home Depot', LOW: 'Lowes',
      CRM: 'Salesforce', COST: 'Costco', NKE: 'Nike', FDX: 'FedEx',
      UNH: 'UnitedHealth', JNJ: 'Johnson & Johnson', V: 'Visa', MA: 'Mastercard',
      DIS: 'Disney', NFLX: 'Netflix', PYPL: 'PayPal', INTC: 'Intel', AMD: 'AMD',
    };
    return companies[ticker] || ticker;
  }
}

// ============================================
// AGENT 9: MACRO EVENTS WRITER
// ============================================
class MacroEventsWriterAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing CONCISE macro events analysis...`);

    const calendarData = previousResults?.economic_calendar_fetcher?.data || {};
    const weeklyCalendar = previousResults?.weekly_calendar_agent?.data?.calendar || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || 'Market environment';
    
    let events = calendarData.events || [];
    
    // Enrich with weekly calendar data
    for (const [day, dayData] of Object.entries(weeklyCalendar)) {
      for (const macro of (dayData.macro || [])) {
        if (!events.find(e => e.name === macro.name)) {
          events.push({ ...macro, day });
        }
      }
    }

    // Organize by day
    const eventsByDay = {};
    for (const event of events) {
      const day = event.day || 'Unscheduled';
      if (!eventsByDay[day]) eventsByDay[day] = [];
      eventsByDay[day].push(event);
    }

    const enrichedEvents = [];
    for (const event of events.slice(0, 8)) {
      const analysis = await this.generateEventAnalysis(event, centralThesis);
      enrichedEvents.push({ ...event, analysis });
    }

    return {
      success: true,
      data: {
        events: enrichedEvents,
        eventsByDay,
        centralThesis,
        source: 'dynamic',
      },
    };
  }

  async generateEventAnalysis(event, centralThesis) {
    const prompt = `Write 2 SHORT sentences about "${event.name}".
Previous: ${event.previous || 'N/A'}, Forecast: ${event.forecast || 'N/A'}

RULES:
- Maximum 2 sentences total
- What the market expects
- What a beat/miss would mean
- Be direct and specific
- NO filler words`;

    const analysis = await callOpenAI(
      'You are a macro strategist. Be extremely concise.',
      prompt,
      { maxTokens: 120 }
    );

    if (analysis && analysis.length > 50) {
      return stripMarkdown(analysis);
    }

    return `Consensus expects ${event.forecast || 'inline'} vs prior ${event.previous || 'reading'}. A beat supports risk assets while a miss could trigger defensive rotation.`;
  }
}

// ============================================
// AGENT 10: MICRO EVENTS WRITER
// ============================================
class MicroEventsWriterAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing concise earnings analysis...`);

    const weeklyCalendar = previousResults?.weekly_calendar_agent?.data?.calendar || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || 'Market environment';

    // Collect all earnings from calendar
    const allEarnings = [];
    for (const [day, dayData] of Object.entries(weeklyCalendar)) {
      for (const earning of (dayData.earnings || [])) {
        allEarnings.push({ ...earning, day });
      }
    }

    const analysis = await this.generateEarningsAnalysis(allEarnings, centralThesis);

    return {
      success: true,
      data: {
        earnings: allEarnings,
        analysis,
        centralThesis,
      },
    };
  }

  async generateEarningsAnalysis(earnings, centralThesis) {
    if (earnings.length === 0) {
      return 'Light earnings week. Macro factors will drive price action.';
    }

    const topNames = earnings.slice(0, 4).map(e => e.company || e.ticker).join(', ');

    const prompt = `Write 3 SHORT sentences about this week's earnings: ${topNames}.
- Which names matter most
- What the market watches for
- NO filler, be direct`;

    const analysis = await callOpenAI(
      'You are an equity strategist. Be extremely concise.',
      prompt,
      { maxTokens: 150 }
    );

    return stripMarkdown(analysis) || `Key reports from ${topNames} will set the tone. Markets focus on guidance and margin trends.`;
  }
}

// ============================================
// AGENT 11: BofA INDICATOR AGENT (v12.1 - Real Data)
// ============================================
class BofAIndicatorAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Fetching REAL BofA Bull & Bear data...`);

    const sentimentData = previousResults?.sentiment_data_fetcher?.data?.parsed || {};
    
    // Check if we have real data from sentiment fetcher
    let bofaData = sentimentData.bofaBullBear;
    
    // If no real data, fetch it directly
    if (!bofaData?.value) {
      console.log(`[${this.name}] No BofA data from sentiment fetcher, fetching directly...`);
      bofaData = await this.fetchBofAData();
    }

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';
    const analysis = await this.generateBofAAnalysis(bofaData, centralThesis);

    return {
      success: true,
      data: {
        indicator: bofaData,
        components: bofaData.components || {},
        analysis,
        chartData: this.prepareChartData(bofaData),
        dataSource: bofaData.source || 'parsed',
      },
    };
  }

  async fetchBofAData() {
    const prompt = `What is the CURRENT BofA (Bank of America) Bull & Bear Indicator reading?

Provide:
1. The actual current reading (0-10 scale)
2. Whether it signals Buy (<2), Bearish (2-4), Neutral (4-6), Bullish (6-8), or Sell (>8)
3. Recent trend (rising, falling, stable)

Only provide the actual current data. If you don't have it, say "not available".`;

    const response = await callPerplexity(prompt, { maxTokens: 500 });
    
    if (response) {
      const valueMatch = response.match(/(\d+\.?\d*)\s*(?:out of 10|\/10|on.*scale)/i) ||
                         response.match(/bull.*bear.*?(\d+\.?\d*)/i) ||
                         response.match(/reading.*?(\d+\.?\d*)/i) ||
                         response.match(/(\d+\.?\d*)/);
      
      if (valueMatch) {
        const value = parseFloat(valueMatch[1]);
        if (value >= 0 && value <= 10) {
          console.log(`[BofAIndicatorAgent] Found real value: ${value}`);
          return {
            value: value,
            signal: value >= 8 ? 'sell' : value <= 2 ? 'buy' : value >= 6 ? 'bullish' : value <= 4 ? 'bearish' : 'neutral',
            components: {},
            source: 'perplexity_direct',
          };
        }
      }
    }
    
    // If we truly can't find real data, return null values (not fake data)
    console.log(`[BofAIndicatorAgent] Could not find real BofA data`);
    return {
      value: null,
      signal: 'unknown',
      components: {},
      source: 'unavailable',
    };
  }

  async generateBofAAnalysis(bofaData, centralThesis) {
    if (!bofaData.value) {
      return 'BofA Bull & Bear indicator data is currently unavailable. This institutional sentiment gauge typically provides insight into whether market positioning has reached extreme levels that historically precede reversals.';
    }

    const value = bofaData.value;
    const signal = bofaData.signal;

    const prompt = `Write 1 paragraph about BofA Bull & Bear at ${value.toFixed(1)} (${signal} signal).
What does this mean for markets? Be specific and concise. 3-4 sentences max.`;

    const analysis = await callOpenAI(
      'You are a market strategist. Be concise.',
      prompt,
      { maxTokens: 200 }
    );

    return stripMarkdown(analysis) || `The BofA Bull & Bear indicator at ${value.toFixed(1)} indicates ${signal} sentiment. Readings above 8 historically trigger sell signals, while readings below 2 suggest buy opportunities.`;
  }

  prepareChartData(bofaData) {
    return {
      value: bofaData.value || 5,
      min: 0,
      max: 10,
      zones: [
        { from: 0, to: 2, label: 'Buy', color: '#22C55E' },
        { from: 2, to: 4, label: 'Bearish', color: '#86EFAC' },
        { from: 4, to: 6, label: 'Neutral', color: '#FCD34D' },
        { from: 6, to: 8, label: 'Bullish', color: '#FCA5A5' },
        { from: 8, to: 10, label: 'Sell', color: '#EF4444' },
      ],
    };
  }
}

// ============================================
// AGENT 12: MARKET BREADTH AGENT (NEW v12.0)
// ============================================
class MarketBreadthAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Fetching REAL market breadth data...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    // Fetch current breadth data with specific prompt
    const breadthPrompt = `What is the CURRENT market breadth for the S&P 500 as of this week?

I need these SPECIFIC numbers:
1. What % of S&P 500 stocks are currently above their 50-day moving average?
2. What % of S&P 500 stocks are currently above their 200-day moving average?
3. Is the NYSE Advance/Decline line rising, falling, or making new highs?

Only provide actual current data. If you don't have exact numbers, say "not available".`;

    const breadthResponse = await callPerplexity(breadthPrompt, { maxTokens: 800 });
    const breadthData = this.parseBreadthData(breadthResponse);

    const analysis = await this.generateBreadthAnalysis(breadthData, centralThesis);

    return {
      success: true,
      data: {
        breadth: breadthData,
        analysis,
        chartData: this.prepareChartData(breadthData),
        hasRealData: breadthData.hasRealData,
      },
    };
  }

  parseBreadthData(response) {
    if (!response) {
      return { hasRealData: false };
    }

    // Extract actual numbers from response
    const above50Match = response.match(/(\d+\.?\d*)%?\s*(?:of stocks?)?.*(?:above|over).*50[- ]?(?:day|DMA)/i) ||
                         response.match(/50[- ]?(?:day|DMA).*?(\d+\.?\d*)%/i);
    const above200Match = response.match(/(\d+\.?\d*)%?\s*(?:of stocks?)?.*(?:above|over).*200[- ]?(?:day|DMA)/i) ||
                          response.match(/200[- ]?(?:day|DMA).*?(\d+\.?\d*)%/i);

    const pctAbove50 = above50Match ? parseFloat(above50Match[1]) : null;
    const pctAbove200 = above200Match ? parseFloat(above200Match[1]) : null;

    // Determine A/D line status
    let advanceDecline = 'unknown';
    if (response.toLowerCase().includes('new high')) advanceDecline = 'new_high';
    else if (response.toLowerCase().includes('rising') || response.toLowerCase().includes('advancing')) advanceDecline = 'rising';
    else if (response.toLowerCase().includes('falling') || response.toLowerCase().includes('declining')) advanceDecline = 'falling';

    const data = {
      hasRealData: !!(pctAbove50 || pctAbove200),
      pctAbove50: pctAbove50,
      pctAbove200: pctAbove200,
      advanceDecline: advanceDecline,
    };

    console.log(`[MarketBreadthAgent] Parsed: Above50=${data.pctAbove50}%, Above200=${data.pctAbove200}%, A/D=${data.advanceDecline}`);

    return data;
  }

  async generateBreadthAnalysis(breadthData, centralThesis) {
    if (!breadthData.hasRealData) {
      return 'Market breadth data is currently unavailable. Breadth measures the percentage of stocks participating in market moves - when breadth is strong, rallies tend to be more sustainable.';
    }

    const prompt = `Write 2-3 sentences about market breadth:
- ${breadthData.pctAbove50 || 'N/A'}% of S&P 500 above 50-DMA
- ${breadthData.pctAbove200 || 'N/A'}% above 200-DMA
- A/D line: ${breadthData.advanceDecline}

Is participation healthy or narrow? What does it mean for markets? Be concise.`;

    const analysis = await callOpenAI(
      'You are a technical analyst. Be concise.',
      prompt,
      { maxTokens: 150 }
    );

    return stripMarkdown(analysis) || `Breadth shows ${breadthData.pctAbove50}% of stocks above their 50-DMA. ${breadthData.pctAbove50 > 60 ? 'Participation is healthy.' : 'Participation is narrowing.'} The A/D line is ${breadthData.advanceDecline}.`;
  }

  prepareChartData(breadthData) {
    return {
      pctAbove50: breadthData.pctAbove50,
      pctAbove200: breadthData.pctAbove200,
      advanceDecline: breadthData.advanceDecline,
    };
  }
}

// ============================================
// AGENT 13: INSTITUTIONAL FLOWS AGENT (v12.1 - Dynamic)
// ============================================
class InstitutionalFlowsAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Processing institutional flows data...`);

    const flowsData = previousResults?.flows_data_fetcher?.data?.parsed || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';
    const hasRealData = flowsData.hasRealData;

    const analysis = await this.generateFlowsAnalysis(flowsData, centralThesis);

    return {
      success: true,
      data: {
        flows: flowsData,
        analysis,
        hasRealData,
      },
    };
  }

  async generateFlowsAnalysis(flowsData, centralThesis) {
    if (!flowsData.hasRealData) {
      return 'Detailed institutional flows data is currently unavailable. These flows from long-only funds, hedge funds, and systematic strategies can provide important signals about market conviction and positioning.';
    }

    const lo = flowsData.longOnly;
    const hf = flowsData.hedgeFunds;
    const sectors = flowsData.sectorFlows;

    let flowSummary = '';
    if (lo?.net) flowSummary += `Long-only funds: $${lo.net.toFixed(1)}B. `;
    if (hf?.net) flowSummary += `Hedge funds: $${hf.net.toFixed(1)}B. `;
    if (sectors) {
      const sectorList = Object.entries(sectors).map(([k, v]) => `${k}: $${v.toFixed(1)}B`).join(', ');
      if (sectorList) flowSummary += `Sector flows: ${sectorList}. `;
    }

    if (!flowSummary) {
      return 'Limited institutional flows data available this week.';
    }

    const prompt = `Write 2-3 sentences about institutional flows: ${flowSummary}
What do these flows tell us about positioning? Be concise.`;

    const analysis = await callOpenAI(
      'You are an institutional flows analyst. Be concise.',
      prompt,
      { maxTokens: 150 }
    );

    return stripMarkdown(analysis) || flowSummary;
  }
}

// ============================================
// AGENT 14: CTA POSITIONING AGENT (v12.1 - Dynamic)
// ============================================
class CTAPositioningAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Fetching REAL CTA positioning data...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    // Fetch CTA data directly
    const ctaPrompt = `What is the CURRENT CTA (trend-following) and systematic fund positioning in US equities as of this week?

I need these SPECIFIC numbers if available:
1. CTA equity exposure (as % of maximum)
2. Vol-control fund exposure (%)
3. Historical percentile of current positioning

Only provide actual current data. If you don't have exact numbers, say "not available".`;

    const ctaResponse = await callPerplexity(ctaPrompt, { maxTokens: 800 });
    const ctaData = this.parseCTAData(ctaResponse);

    const analysis = await this.generateCTAAnalysis(ctaData, centralThesis);

    return {
      success: true,
      data: {
        cta: ctaData,
        analysis,
        hasRealData: ctaData.hasRealData,
      },
    };
  }

  parseCTAData(response) {
    if (!response) {
      return { hasRealData: false };
    }

    // Extract actual numbers from response
    const exposureMatch = response.match(/(\d+)%?\s*(?:of max|exposure|equity|long)/i) ||
                          response.match(/cta.*?(\d+)%/i);
    const volControlMatch = response.match(/vol.*control.*?(\d+)%/i) ||
                            response.match(/volatility.*?(\d+)%/i);
    const percentileMatch = response.match(/(\d+)(?:th|st|nd|rd)?\s*percentile/i);

    const data = {
      hasRealData: !!(exposureMatch || volControlMatch),
      equityExposure: exposureMatch ? parseFloat(exposureMatch[1]) : null,
      volControlExposure: volControlMatch ? parseFloat(volControlMatch[1]) : null,
      historicalPercentile: percentileMatch ? parseFloat(percentileMatch[1]) : null,
    };

    console.log(`[CTAPositioningAgent] Parsed: Exposure=${data.equityExposure}%, VolControl=${data.volControlExposure}%, Percentile=${data.historicalPercentile}`);

    return data;
  }

  async generateCTAAnalysis(ctaData, centralThesis) {
    if (!ctaData.hasRealData) {
      return 'CTA and systematic positioning data is currently unavailable. These funds represent over $500 billion in assets and their mechanical buying/selling can amplify market moves.';
    }

    const prompt = `Write 2-3 sentences about CTA positioning:
${ctaData.equityExposure ? `- CTA equity exposure: ${ctaData.equityExposure}%` : ''}
${ctaData.volControlExposure ? `- Vol-control exposure: ${ctaData.volControlExposure}%` : ''}
${ctaData.historicalPercentile ? `- Historical percentile: ${ctaData.historicalPercentile}th` : ''}

What does this mean for markets? Be concise.`;

    const analysis = await callOpenAI(
      'You are a quantitative strategist. Be concise.',
      prompt,
      { maxTokens: 150 }
    );

    return stripMarkdown(analysis) || 'Systematic funds remain positioned based on trend signals. Key trigger levels include the 50-DMA for trend direction.';
  }
}

// ============================================
// AGENT 15: MACRO INSIGHTS
// ============================================
class MacroInsightsAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Generating dynamic macro insights...`);

    const newsData = previousResults?.news_aggregator?.data || {};
    const marketData = previousResults?.market_data_fetcher?.data || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    const themes = [
      'Market Breadth & Participation',
      'Magnificent 7 vs Broader Market',
      'Valuation Concerns',
      'China & Emerging Markets',
      'Seasonality Patterns',
    ];

    const insights = [];
    for (const theme of themes.slice(0, 3)) {
      const insight = await this.generateThemeInsight(theme, newsData, centralThesis);
      if (insight) {
        insights.push({ theme, analysis: insight });
      }
    }

    return {
      success: true,
      data: { insights },
    };
  }

  async generateThemeInsight(theme, newsData, centralThesis) {
    const prompt = `Write a 3-4 sentence analysis of "${theme}" in current market context.
Thesis: ${centralThesis}
Style: Midapnim institutional - direct, specific, actionable
NO bullet points.`;

    return await callOpenAI(
      'You are a senior market strategist.',
      prompt,
      { maxTokens: 300 }
    );
  }
}

// ============================================
// TACTICAL AGENTS (Global Macro, Rates, etc.)
// ============================================
class TacticalGlobalMacroAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing global macro analysis...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';
    const newsData = previousResults?.news_aggregator?.data || {};

    const analysis = await this.generateAnalysis(centralThesis, newsData);

    return {
      success: true,
      data: { analysis, centralThesis },
    };
  }

  async generateAnalysis(centralThesis, newsData) {
    const prompt = `Write 4 paragraphs on the global macro environment:
1. US economic cycle positioning
2. Growth outlook and key risks
3. International developments (Europe, China, EM)
4. Tactical implications

Current thesis: ${centralThesis}

Midapnim style - direct, specific, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a senior global macro strategist at Goldman Sachs.',
      prompt,
      { maxTokens: 800 }
    );

    return analysis || 'The global macro environment continues to reflect late-cycle dynamics with growth showing resilience but clear constraints emerging.';
  }
}

class TacticalRatesPolicyAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing rates and policy analysis...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    const prompt = `Write 3 paragraphs on interest rates and Fed policy:
1. Current Fed stance and recent commentary
2. Rate cut expectations and market pricing
3. Yield curve signals and implications

Thesis: ${centralThesis}
Midapnim style - specific numbers, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a fixed income strategist.',
      prompt,
      { maxTokens: 600 }
    );

    return {
      success: true,
      data: { analysis: analysis || 'The Fed maintains its higher-for-longer stance while markets debate the timing of eventual cuts.' },
    };
  }
}

class TacticalFiscalRisksAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing fiscal risks analysis...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    const prompt = `Write 3 paragraphs on fiscal risks and tail scenarios:
1. US fiscal situation and debt concerns
2. Political/policy risks
3. Tail scenarios that could disrupt markets

Thesis: ${centralThesis}
Midapnim style - specific, direct, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a policy analyst.',
      prompt,
      { maxTokens: 600 }
    );

    return {
      success: true,
      data: { analysis: analysis || 'Fiscal concerns remain in the background but could resurface as debt ceiling discussions approach.' },
    };
  }
}

class TacticalFlowsSentimentAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing flows and sentiment synthesis...`);

    const bofaData = previousResults?.bofa_indicator_agent?.data || {};
    const flowsData = previousResults?.institutional_flows_agent?.data || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    const prompt = `Write 4 paragraphs synthesizing flows and sentiment:
1. Overall sentiment picture (BofA indicator, put/call, AAII)
2. Institutional positioning summary
3. Risk pricing (VIX, skew, protection costs)
4. Contrarian signals if any

BofA reading: ${bofaData.indicator?.value || 6.8}
Thesis: ${centralThesis}
Midapnim style - specific data, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a sentiment and flows analyst.',
      prompt,
      { maxTokens: 800 }
    );

    return {
      success: true,
      data: { analysis: analysis || 'Sentiment indicators show elevated optimism but not yet at contrarian extremes.' },
    };
  }
}

class TacticalGeographicAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing geographic analysis...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    const prompt = `Write 3 paragraphs on regional market dynamics:
1. US vs international relative value
2. Europe outlook
3. China and EM positioning

Thesis: ${centralThesis}
Midapnim style - specific, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a global equity strategist.',
      prompt,
      { maxTokens: 600 }
    );

    return {
      success: true,
      data: { analysis: analysis || 'US continues to outperform international markets, though valuations suggest rotation potential.' },
    };
  }
}

class TacticalPositioningAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing positioning and crowding analysis...`);

    const ctaData = previousResults?.cta_positioning_agent?.data || {};
    const flowsData = previousResults?.institutional_flows_agent?.data || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';

    const prompt = `Write 3 paragraphs on positioning and crowding risks:
1. Hedge fund positioning (gross/net, crowded trades)
2. Systematic positioning (CTAs, vol-control)
3. Contrarian opportunities

CTA exposure: ${ctaData.cta?.equityExposure || 72}%
Thesis: ${centralThesis}
Midapnim style - specific, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a positioning analyst.',
      prompt,
      { maxTokens: 600 }
    );

    return {
      success: true,
      data: { analysis: analysis || 'Positioning is elevated but not extreme, with CTAs near full long exposure.' },
    };
  }
}

class TacticalSynthesisAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Writing tactical synthesis...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';
    const bofaData = previousResults?.bofa_indicator_agent?.data || {};
    const breadthData = previousResults?.market_breadth_agent?.data || {};
    const flowsData = previousResults?.institutional_flows_agent?.data || {};
    const ctaData = previousResults?.cta_positioning_agent?.data || {};

    const prompt = `Write a 3-4 paragraph tactical synthesis that brings together:
- BofA indicator at ${bofaData.indicator?.value || 6.8}
- Breadth: ${breadthData.breadth?.pctAbove50 || 58}% above 50-DMA
- Institutional flows: LOs ${flowsData.flows?.longOnly?.direction || 'selling'}
- CTA exposure: ${ctaData.cta?.equityExposure || 72}%

Central thesis: ${centralThesis}

End with clear tactical recommendations for the week ahead.
Midapnim style - direct, actionable, NO bullet points.`;

    const analysis = await callOpenAI(
      'You are a senior strategist writing the tactical bottom line.',
      prompt,
      { maxTokens: 700 }
    );

    return {
      success: true,
      data: { 
        analysis: analysis || 'The tactical picture suggests maintaining selective exposure while building downside hedges.', 
        centralThesis 
      },
    };
  }
}

// ============================================
// TRADE IDEA GENERATOR
// ============================================
class TradeIdeaGeneratorAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Generating trade ideas from tactical analysis...`);

    const sectorData = previousResults?.sector_rotation_analyzer?.data || {};
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || '';
    const tacticalSynthesis = previousResults?.tactical_synthesis?.data?.analysis || '';

    const ideas = await this.generateIdeas(sectorData, centralThesis, tacticalSynthesis);

    return {
      success: true,
      data: { ideas },
    };
  }

  async generateIdeas(sectorData, centralThesis, tacticalSynthesis) {
    const leaders = sectorData.leaders || [{ symbol: 'XLE', return: 2.56 }];
    const laggards = sectorData.laggards || [{ symbol: 'XLY', return: -2.64 }];

    const prompt = `Generate 3 trade ideas that FLOW from the tactical analysis.

Thesis: ${centralThesis}
Leaders: ${leaders.map(l => `${l.symbol} +${l.return?.toFixed(2) || 0}%`).join(', ')}
Laggards: ${laggards.map(l => `${l.symbol} ${l.return?.toFixed(2) || 0}%`).join(', ')}

For each trade provide:
TICKER: [symbol]
DIRECTION: [LONG/SHORT]
ENTRY: [price or "current levels"]
STOP: [% loss]
TARGET: [% gain]
TIMEFRAME: [weeks]
CONVICTION: [HIGH/MEDIUM/LOW]
RATIONALE: [2-3 sentences connecting to thesis]

Write in Midapnim institutional style.`;

    const response = await callOpenAI(
      'You are a senior trader generating trade ideas.',
      prompt,
      { maxTokens: 1200 }
    );

    const parsed = this.parseIdeas(response);
    return parsed.length > 0 ? parsed : this.getFallbackIdeas(sectorData, centralThesis);
  }

  parseIdeas(response) {
    if (!response) return [];
    
    const ideas = [];
    const blocks = response.split(/(?=TICKER:|Trade \d|Idea \d)/i).filter(b => b.trim());

    for (const block of blocks) {
      const tickerMatch = block.match(/TICKER:\s*([A-Z]{1,5})/i);
      const directionMatch = block.match(/DIRECTION:\s*(LONG|SHORT)/i);
      const entryMatch = block.match(/ENTRY:\s*([^\n]+)/i);
      const stopMatch = block.match(/STOP:\s*([^\n]+)/i);
      const targetMatch = block.match(/TARGET:\s*([^\n]+)/i);
      const timeframeMatch = block.match(/TIMEFRAME:\s*([^\n]+)/i);
      const convictionMatch = block.match(/CONVICTION:\s*(HIGH|MEDIUM|LOW)/i);
      const rationaleMatch = block.match(/RATIONALE:\s*([^\n]+(?:\n(?!TICKER|DIRECTION|ENTRY|STOP|TARGET|TIMEFRAME|CONVICTION)[^\n]+)*)/i);

      if (tickerMatch) {
        ideas.push({
          ticker: tickerMatch[1],
          direction: directionMatch ? directionMatch[1].toUpperCase() : 'LONG',
          entry: entryMatch ? entryMatch[1].trim() : 'Current levels',
          stop: stopMatch ? stopMatch[1].trim() : '-3%',
          target: targetMatch ? targetMatch[1].trim() : '+6%',
          timeframe: timeframeMatch ? timeframeMatch[1].trim() : '2-4 weeks',
          conviction: convictionMatch ? convictionMatch[1].toUpperCase() : 'MEDIUM',
          rationale: rationaleMatch ? stripMarkdown(rationaleMatch[1].trim()) : '',
        });
      }
    }

    return ideas;
  }

  getFallbackIdeas(sectorData, centralThesis) {
    const leader = sectorData.leaders?.[0] || { symbol: 'XLE', return: 2.56 };
    const laggard = sectorData.laggards?.[0] || { symbol: 'XLY', return: -2.64 };

    return [
      {
        ticker: leader.symbol,
        direction: 'LONG',
        entry: 'Current levels',
        stop: '-3%',
        target: '+6%',
        timeframe: '2-4 weeks',
        conviction: 'HIGH',
        rationale: `This trade flows directly from the tactical analysis highlighting ${centralThesis.toLowerCase()}. The sector has demonstrated relative strength this week and institutional flows support the rotation.`,
      },
      {
        ticker: laggard.symbol,
        direction: 'SHORT',
        entry: 'Current levels',
        stop: '+3%',
        target: '-6%',
        timeframe: '2-4 weeks',
        conviction: 'MEDIUM',
        rationale: `Consumer spending concerns and margin pressures support continued underperformance. Positioning is crowded but fundamental headwinds remain intact.`,
      },
      {
        ticker: 'XLU',
        direction: 'LONG',
        entry: 'Current levels',
        stop: '-3%',
        target: '+5%',
        timeframe: '3-4 weeks',
        conviction: 'MEDIUM',
        rationale: `Utilities provide defensive exposure consistent with late-cycle positioning. Dividend yield offers carry while markets navigate uncertainty.`,
      },
    ];
  }
}

// ============================================
// RISK MANAGER
// ============================================
class RiskManagerAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Managing trade risks...`);

    const tradeIdeas = previousResults?.trade_idea_generator?.data?.ideas || [];

    const enhancedIdeas = tradeIdeas.map(idea => ({
      ...idea,
      riskReward: this.calculateRiskReward(idea),
      positionSize: this.suggestPositionSize(idea),
    }));

    return {
      success: true,
      data: {
        ideas: enhancedIdeas,
        portfolioGuidance: 'Max position size: 5% per idea. Total directional exposure: 20%.',
      },
    };
  }

  calculateRiskReward(idea) {
    const stopPct = parseFloat(idea.stop?.replace(/[^\d.-]/g, '')) || 3;
    const targetPct = parseFloat(idea.target?.replace(/[^\d.-]/g, '')) || 5;
    return (Math.abs(targetPct) / Math.abs(stopPct)).toFixed(1);
  }

  suggestPositionSize(idea) {
    if (idea.conviction === 'HIGH') return '3-5%';
    if (idea.conviction === 'LOW') return '1-2%';
    return '2-3%';
  }
}

// ============================================
// COHERENCE CHECKER
// ============================================
class CoherenceCheckerAgent extends BaseAgent {
  async execute(context) {
    const { previousResults } = context;
    console.log(`[${this.name}] Checking report coherence...`);

    const requiredSections = [
      'week_narrative_writer',
      'sector_rotation_analyzer',
      'bofa_indicator_agent',
      'market_breadth_agent',
      'institutional_flows_agent',
      'cta_positioning_agent',
      'tactical_synthesis',
      'trade_idea_generator',
    ];

    const missing = requiredSections.filter(s => !previousResults[s]?.success);
    const qaScore = Math.round((1 - missing.length / requiredSections.length) * 100);
    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis;

    return {
      success: true,
      data: { qaScore, missingSections: missing, passed: qaScore >= 70, thesisPresent: !!centralThesis, centralThesis },
    };
  }
}

// ============================================
// FINAL COMPILER
// ============================================
class FinalCompilerAgent extends BaseAgent {
  async execute(context) {
    const { previousResults, reportWeek } = context;
    console.log(`[${this.name}] Compiling final report...`);

    const centralThesis = previousResults?.week_narrative_writer?.data?.centralThesis || 'Market analysis';

    return {
      success: true,
      data: {
        reportWeek,
        centralThesis,
        sections: previousResults,
        compiledAt: new Date().toISOString(),
      },
    };
  }
}

// ============================================
// AGENT FACTORY
// ============================================
const AGENT_CLASSES = {
  market_data_fetcher: MarketDataFetcherAgent,
  news_aggregator: NewsAggregatorAgent,
  economic_calendar_fetcher: EconomicCalendarFetcherAgent,
  sentiment_data_fetcher: SentimentDataFetcherAgent,
  flows_data_fetcher: FlowsDataFetcherAgent,
  week_narrative_writer: WeekNarrativeWriterAgent,
  sector_rotation_analyzer: SectorRotationAnalyzerAgent,
  weekly_calendar_agent: WeeklyCalendarAgent,
  macro_events_writer: MacroEventsWriterAgent,
  micro_events_writer: MicroEventsWriterAgent,
  bofa_indicator_agent: BofAIndicatorAgent,
  market_breadth_agent: MarketBreadthAgent,
  institutional_flows_agent: InstitutionalFlowsAgent,
  cta_positioning_agent: CTAPositioningAgent,
  macro_insights: MacroInsightsAgent,
  tactical_global_macro: TacticalGlobalMacroAgent,
  tactical_rates_policy: TacticalRatesPolicyAgent,
  tactical_fiscal_risks: TacticalFiscalRisksAgent,
  tactical_flows_sentiment: TacticalFlowsSentimentAgent,
  tactical_geographic: TacticalGeographicAgent,
  tactical_positioning: TacticalPositioningAgent,
  tactical_synthesis: TacticalSynthesisAgent,
  trade_idea_generator: TradeIdeaGeneratorAgent,
  risk_manager: RiskManagerAgent,
  coherence_checker: CoherenceCheckerAgent,
  final_compiler: FinalCompilerAgent,
};

export function createAgent(agentId) {
  const definition = AGENT_DEFINITIONS.find(a => a.id === agentId);
  if (!definition) {
    throw new Error(`Unknown agent: ${agentId}`);
  }

  const AgentClass = AGENT_CLASSES[agentId];
  if (!AgentClass) {
    throw new Error(`No implementation for agent: ${agentId}`);
  }

  return new AgentClass(definition);
}

// ============================================
// EXPORTS
// ============================================
export {
  AGENT_DEFINITIONS,
  BaseAgent,
  MarketDataFetcherAgent,
  NewsAggregatorAgent,
  EconomicCalendarFetcherAgent,
  SentimentDataFetcherAgent,
  FlowsDataFetcherAgent,
  WeekNarrativeWriterAgent,
  SectorRotationAnalyzerAgent,
  WeeklyCalendarAgent,
  MacroEventsWriterAgent,
  MicroEventsWriterAgent,
  BofAIndicatorAgent,
  MarketBreadthAgent,
  InstitutionalFlowsAgent,
  CTAPositioningAgent,
  MacroInsightsAgent,
  TacticalGlobalMacroAgent,
  TacticalRatesPolicyAgent,
  TacticalFiscalRisksAgent,
  TacticalFlowsSentimentAgent,
  TacticalGeographicAgent,
  TacticalPositioningAgent,
  TacticalSynthesisAgent,
  TradeIdeaGeneratorAgent,
  RiskManagerAgent,
  CoherenceCheckerAgent,
  FinalCompilerAgent,
};

export default {
  createAgent,
  AGENT_DEFINITIONS,
};