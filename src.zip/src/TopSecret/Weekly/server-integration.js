// =====================================================
// WEEKLY REPORT SERVER INTEGRATION EXAMPLE
// =====================================================
// This file shows how to integrate the Weekly Report
// system into an existing Express server
// =====================================================
// 
// Add this to your existing server file (e.g., server.js)
// or create a new routes file
// =====================================================

import express from 'express';
import {
  initWeeklyService,
  createWeeklyRoutes,
  generateWeeklyReport,
  getWeeklyReport,
  getLatestWeeklyReport,
  getWorkflowStatus,
  checkServiceStatus,
  VERSION,
} from './index.js';

// ============================================
// OPTION 1: Using createWeeklyRoutes helper
// ============================================

export function setupWeeklyReportRoutes(app, supabase) {
  // Initialize the service
  initWeeklyService(supabase, {
    polygonApiKey: process.env.POLYGON_API_KEY,
    perplexityApiKey: process.env.PERPLEXITY_API_KEY,
    openaiApiKey: process.env.OPENAI_API_KEY,
  });
  
  // Create router with all routes
  const weeklyRouter = express.Router();
  createWeeklyRoutes(weeklyRouter);
  
  // Mount at /api/reports/weekly
  app.use('/api/reports/weekly', weeklyRouter);
  
  console.log(`[Server] Weekly Report API v${VERSION} mounted at /api/reports/weekly`);
}

// ============================================
// OPTION 2: Manual route setup (more control)
// ============================================

export function setupWeeklyReportRoutesManual(app, supabase) {
  // Initialize the service
  initWeeklyService(supabase, {
    polygonApiKey: process.env.POLYGON_API_KEY,
    perplexityApiKey: process.env.PERPLEXITY_API_KEY,
    openaiApiKey: process.env.OPENAI_API_KEY,
  });

  // ============================================
  // STATUS ENDPOINT
  // GET /api/reports/weekly/status
  // ============================================
  app.get('/api/reports/weekly/status', (req, res) => {
    try {
      const status = checkServiceStatus();
      res.json({ success: true, data: status });
    } catch (error) {
      console.error('[Weekly API] Status error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ============================================
  // GENERATE ENDPOINT
  // POST /api/reports/weekly/generate
  // ============================================
  app.post('/api/reports/weekly/generate', async (req, res) => {
    try {
      const { reportWeek, force } = req.body;
      
      // Generate report ID
      const reportId = `weekly_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
      
      console.log(`[Weekly API] Starting generation: ${reportId}`);
      
      // Start generation in background (non-blocking)
      generateWeeklyReport(reportWeek, { reportId })
        .then((result) => {
          console.log(`[Weekly API] Report ${reportId} completed with QA score: ${result.meta?.qaScore}`);
        })
        .catch((err) => {
          console.error(`[Weekly API] Report ${reportId} failed:`, err.message);
        });
      
      // Immediately return with reportId for progress tracking
      res.json({
        success: true,
        data: {
          status: 'started',
          reportId,
          message: 'Report generation started. Poll /progress/:reportId for updates.',
        },
      });
    } catch (error) {
      console.error('[Weekly API] Generate error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ============================================
  // WORKFLOW PROGRESS ENDPOINT
  // GET /api/reports/weekly/workflow-progress
  // ============================================
  app.get('/api/reports/weekly/workflow-progress', (req, res) => {
    try {
      // Find any running workflow
      const { workflowManager } = require('./orchestrator.js');
      
      let runningWorkflow = null;
      for (const [id, workflow] of workflowManager.workflows) {
        if (workflow.status === 'running') {
          runningWorkflow = { reportId: id, ...workflow };
          break;
        }
      }
      
      if (!runningWorkflow) {
        // Check for latest completed
        const latest = workflowManager.workflows.get('latest');
        if (latest) {
          res.json({
            success: true,
            isRunning: false,
            progress: 100,
            ...getWorkflowStatus(latest.reportId),
          });
          return;
        }
        
        res.json({
          success: true,
          isRunning: false,
          progress: 0,
        });
        return;
      }
      
      const status = getWorkflowStatus(runningWorkflow.reportId);
      res.json({
        success: true,
        isRunning: true,
        ...status,
      });
    } catch (error) {
      console.error('[Weekly API] Workflow progress error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ============================================
  // PROGRESS ENDPOINT
  // GET /api/reports/weekly/progress/:reportId
  // ============================================
  app.get('/api/reports/weekly/progress/:reportId', (req, res) => {
    try {
      const { reportId } = req.params;
      const status = getWorkflowStatus(reportId);
      
      if (!status) {
        return res.status(404).json({
          success: false,
          error: 'Report not found or generation not started',
        });
      }
      
      res.json({
        success: true,
        data: {
          reportId,
          status: status.status,
          progress: status.progress,
          currentPhase: status.currentPhase,
          currentAgent: status.currentAgentName,
          completedAgents: status.completedAgents,
          elapsedSeconds: status.elapsedSeconds,
          elapsedFormatted: formatDuration(status.elapsedSeconds),
          error: status.error,
          recentLogs: status.recentLogs,
        },
      });
    } catch (error) {
      console.error('[Weekly API] Progress error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ============================================
  // GET REPORT ENDPOINT
  // GET /api/reports/weekly/report/:reportId
  // ============================================
  app.get('/api/reports/weekly/report/:reportId', async (req, res) => {
    try {
      const { reportId } = req.params;
      const report = await getWeeklyReport(reportId);
      
      if (!report) {
        return res.status(404).json({
          success: false,
          error: 'Report not found',
        });
      }
      
      res.json({
        success: true,
        data: {
          report,
          markdown_content: report.markdown,
          html_content: report.html,
          created_at: report.meta?.generatedAt,
          qa_score: report.meta?.qaScore,
        },
      });
    } catch (error) {
      console.error('[Weekly API] Get report error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ============================================
  // LATEST REPORT ENDPOINT
  // GET /api/reports/weekly/latest
  // ============================================
  app.get('/api/reports/weekly/latest', async (req, res) => {
    try {
      const report = await getLatestWeeklyReport();
      
      if (!report) {
        return res.json({
          success: true,
          data: null,
          message: 'No reports generated yet',
        });
      }
      
      res.json({
        success: true,
        data: report,
      });
    } catch (error) {
      console.error('[Weekly API] Latest report error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ============================================
  // PREVIEW ENDPOINT (for email preview)
  // GET /api/reports/weekly/preview
  // ============================================
  app.get('/api/reports/weekly/preview', async (req, res) => {
    try {
      const report = await getLatestWeeklyReport();
      
      if (!report) {
        return res.json({
          success: true,
          data: null,
        });
      }
      
      res.json({
        success: true,
        data: {
          subject: `Weekly Tactical Review - ${report.meta?.reportWeek || 'Current Week'}`,
          preheader: 'Institutional-Grade Market Intelligence',
          html: report.html || '',
          markdown: report.markdown || '',
          generatedAt: report.meta?.generatedAt || new Date().toISOString(),
          reportType: 'weekly',
          reportId: report.reportId,
          processorInfo: {
            version: VERSION,
            type: 'weekly',
            agentCount: 20,
            qaScore: report.meta?.qaScore,
            qaPassed: report.meta?.qaPassed,
            duration: report.meta?.durationFormatted,
          },
        },
      });
    } catch (error) {
      console.error('[Weekly API] Preview error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  console.log(`[Server] Weekly Report API v${VERSION} routes configured`);
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

// ============================================
// EXAMPLE USAGE IN server.js
// ============================================

/*
// In your main server.js file:

import express from 'express';
import { createClient } from '@supabase/supabase-js';
import { setupWeeklyReportRoutes } from './src/TopSecret/Weekly/server-integration.js';

const app = express();
app.use(express.json());

// Initialize Supabase
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Setup Weekly Report routes
setupWeeklyReportRoutes(app, supabase);

// Your other routes...
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// Start server
app.listen(3000, () => {
  console.log('Server running on port 3000');
});
*/

export default {
  setupWeeklyReportRoutes,
  setupWeeklyReportRoutesManual,
};
