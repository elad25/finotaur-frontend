// =====================================================
// WEEKLY TACTICAL REVIEW - DATA SERVICE v1.0
// =====================================================
// Location: src/TopSecret/Weekly/data-service.js
// =====================================================

import { MARKET_INDICES, SECTOR_ETFS, EXTENDED_INDICES } from './config.js';

export class WeeklyDataService {
  constructor(supabase, options) {
    const opts = options || {};
    this.supabase = supabase;
    this.polygonApiKey = opts.polygonApiKey || process.env.POLYGON_API_KEY;
    this.perplexityApiKey = opts.perplexityApiKey || process.env.PERPLEXITY_API_KEY;
    this.openaiApiKey = opts.openaiApiKey || process.env.OPENAI_API_KEY;
    this.cache = new Map();
  }

  // =====================================================
  // POLYGON API - Market Data
  // =====================================================

  async fetchMarketData(symbols, startDate, endDate) {
    console.log(`[WeeklyData] Fetching market data for ${symbols.length} symbols...`);
    
    const results = {};
    
    for (const symbol of symbols) {
      try {
        const data = await this.fetchTickerData(symbol, startDate, endDate);
        results[symbol] = data;
      } catch (error) {
        console.warn(`[WeeklyData] Failed to fetch ${symbol}:`, error.message);
        results[symbol] = this.getFallbackData(symbol);
      }
    }
    
    return results;
  }

  async fetchTickerData(symbol, startDate, endDate) {
    if (!this.polygonApiKey) {
      console.log(`[WeeklyData] No Polygon API key, using fallback for ${symbol}`);
      return this.getFallbackData(symbol);
    }

    const url = `https://api.polygon.io/v2/aggs/ticker/${symbol}/range/1/day/${startDate}/${endDate}?apiKey=${this.polygonApiKey}`;
    
    try {
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        return this.processPolygonData(symbol, data.results);
      }
      
      return this.getFallbackData(symbol);
    } catch (error) {
      console.error(`[WeeklyData] Polygon API error for ${symbol}:`, error.message);
      return this.getFallbackData(symbol);
    }
  }

  processPolygonData(symbol, results) {
    const latest = results[results.length - 1];
    const first = results[0];
    
    const weeklyReturn = ((latest.c - first.o) / first.o) * 100;
    const high = Math.max(...results.map(r => r.h));
    const low = Math.min(...results.map(r => r.l));
    const avgVolume = results.reduce((sum, r) => sum + r.v, 0) / results.length;
    
    return {
      symbol,
      open: first.o,
      close: latest.c,
      high,
      low,
      weeklyReturn: weeklyReturn.toFixed(2),
      avgVolume: Math.round(avgVolume),
      dataPoints: results.length,
      source: 'polygon',
    };
  }

  getFallbackData(symbol) {
    // Generate realistic mock data
    const basePrice = this.getBasePrice(symbol);
    const volatility = this.getVolatility(symbol);
    const change = (Math.random() - 0.5) * volatility;
    
    return {
      symbol,
      open: basePrice,
      close: basePrice * (1 + change / 100),
      high: basePrice * (1 + Math.abs(change) / 100 + 0.5),
      low: basePrice * (1 - Math.abs(change) / 100 - 0.5),
      weeklyReturn: change.toFixed(2),
      avgVolume: Math.round(Math.random() * 50000000 + 10000000),
      dataPoints: 5,
      source: 'fallback',
    };
  }

  getBasePrice(symbol) {
    const basePrices = {
      SPY: 590, QQQ: 520, IWM: 220, DIA: 430,
      TLT: 88, GLD: 240, USO: 75, UUP: 28,
      XLK: 230, XLF: 48, XLE: 92, XLV: 145,
      XLI: 130, XLP: 82, XLY: 210, XLU: 75,
      XLB: 88, XLRE: 42, XLC: 92,
    };
    return basePrices[symbol] || 100;
  }

  getVolatility(symbol) {
    const volatilities = {
      SPY: 3, QQQ: 4, IWM: 5, DIA: 2.5,
      TLT: 4, GLD: 3, USO: 8, UUP: 2,
      XLK: 4.5, XLF: 4, XLE: 6, XLV: 3,
      XLI: 3.5, XLP: 2, XLY: 4, XLU: 2.5,
      XLB: 4, XLRE: 4, XLC: 4,
    };
    return volatilities[symbol] || 4;
  }

  // =====================================================
  // PERPLEXITY API - News & Analysis
  // =====================================================

  async fetchMarketNews() {
    console.log('[WeeklyData] Fetching market news...');
    
    if (!this.perplexityApiKey) {
      console.log('[WeeklyData] No Perplexity API key, using fallback news');
      return this.getFallbackNews();
    }

    try {
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'llama-3.1-sonar-large-128k-online',
          messages: [{
            role: 'user',
            content: `Provide a comprehensive summary of the most important US stock market news and events from the past week. Include:
1. Major market moves and their drivers
2. Key economic data releases
3. Federal Reserve commentary or actions
4. Significant corporate news (earnings, M&A, etc.)
5. Geopolitical events affecting markets
6. Upcoming events to watch next week

Format as JSON with sections: marketMoves, economicData, fedNews, corporateNews, geopolitical, upcomingEvents`
          }],
          max_tokens: 2000,
        }),
      });

      const data = await response.json();
      
      if (data.choices && data.choices[0]) {
        return this.parsePerplexityResponse(data.choices[0].message.content);
      }
      
      return this.getFallbackNews();
    } catch (error) {
      console.error('[WeeklyData] Perplexity API error:', error.message);
      return this.getFallbackNews();
    }
  }

  parsePerplexityResponse(content) {
    try {
      // Try to extract JSON from response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      // Return as raw content if not JSON
      return {
        rawContent: content,
        source: 'perplexity',
      };
    } catch {
      return {
        rawContent: content,
        source: 'perplexity',
      };
    }
  }

  getFallbackNews() {
    return {
      marketMoves: [
        'Markets showed mixed performance with tech leading gains',
        'Small caps underperformed as rate concerns persisted',
        'Energy sector rallied on supply concerns',
      ],
      economicData: [
        'Inflation data came in line with expectations',
        'Jobs report showed resilient labor market',
        'Consumer sentiment improved slightly',
      ],
      fedNews: [
        'Fed officials maintained hawkish stance on rates',
        'Markets pricing in potential rate cuts later in 2025',
      ],
      corporateNews: [
        'Tech earnings season kicked off with strong results',
        'Several major M&A deals announced',
      ],
      geopolitical: [
        'Trade tensions remained elevated',
        'Energy markets watched Middle East developments',
      ],
      upcomingEvents: [
        'FOMC meeting minutes release',
        'Major tech earnings continue',
        'Monthly jobs report due Friday',
      ],
      source: 'fallback',
    };
  }

  // =====================================================
  // ECONOMIC CALENDAR
  // =====================================================

  async fetchEconomicCalendar(startDate, endDate) {
    console.log('[WeeklyData] Fetching economic calendar...');
    
    // For now, return a structured calendar
    // In production, this would fetch from an economic calendar API
    return {
      events: [
        { date: startDate, event: 'Fed Chair Speech', importance: 'high' },
        { date: startDate, event: 'ISM Services PMI', importance: 'high' },
        { date: endDate, event: 'Nonfarm Payrolls', importance: 'high' },
        { date: endDate, event: 'Unemployment Rate', importance: 'high' },
      ],
      earnings: [
        { date: startDate, company: 'Major Tech Co', ticker: 'TECH' },
        { date: endDate, company: 'Big Bank', ticker: 'BANK' },
      ],
      source: 'calendar',
    };
  }

  // =====================================================
  // AGGREGATE ALL DATA
  // =====================================================

  async fetchAllWeeklyData(reportWeek) {
    console.log(`[WeeklyData] Fetching all data for week: ${reportWeek}`);
    
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 7);
    
    const startStr = startDate.toISOString().split('T')[0];
    const endStr = endDate.toISOString().split('T')[0];
    
    // Fetch all data in parallel
    const [indexData, sectorData, news, calendar] = await Promise.all([
      this.fetchMarketData(Object.keys(MARKET_INDICES), startStr, endStr),
      this.fetchMarketData(Object.keys(SECTOR_ETFS), startStr, endStr),
      this.fetchMarketNews(),
      this.fetchEconomicCalendar(startStr, endStr),
    ]);
    
    return {
      reportWeek,
      fetchedAt: new Date().toISOString(),
      indices: indexData,
      sectors: sectorData,
      news,
      calendar,
      meta: {
        startDate: startStr,
        endDate: endStr,
        hasPolygonData: !!this.polygonApiKey,
        hasPerplexityData: !!this.perplexityApiKey,
      },
    };
  }

  // =====================================================
  // CACHE MANAGEMENT
  // =====================================================

  async clearCache(week) {
    if (week) {
      this.cache.delete(week);
    } else {
      this.cache.clear();
    }
    console.log(`[WeeklyData] Cache cleared${week ? ` for ${week}` : ''}`);
  }
}

export default WeeklyDataService;