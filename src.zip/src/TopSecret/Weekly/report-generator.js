// =====================================================
// WEEKLY TACTICAL REVIEW - REPORT GENERATOR v2.0
// =====================================================
// Style: MIDAPNIM (מידע פנים) Professional Format
// Key: Flowing prose, clear paragraphs, no bullet walls
// =====================================================

import { VERSION, REGIME_LABELS, COMPANY_NAME } from './config.js';

// =====================================================
// MARKDOWN REPORT GENERATOR (Midapnim Style)
// =====================================================

export function generateMarkdownReport(data, reportWeek) {
  const sections = data.sections || data;
  const qa = data.qa || {};
  
  const lines = [];
  
  // Header
  lines.push('# Weekly Tactical Review');
  lines.push('');
  lines.push(`**${COMPANY_NAME} | Week of ${formatWeekDisplay(reportWeek)}**`);
  lines.push('');
  lines.push('*Institutional-Grade Market Intelligence*');
  lines.push('');
  lines.push('---');
  lines.push('');
  
  // ========== THE WEEK THAT WAS ==========
  lines.push('## The Week That Was');
  lines.push('');
  lines.push('*US Equities - Weekly Review, Sectors & Valuations*');
  lines.push('');
  
  const weekNarrative = sections.week_narrative_writer?.data?.narrative || 
                        sections.summary?.narrative;
  if (weekNarrative) {
    // Split into proper paragraphs and add them
    const paragraphs = splitIntoParagraphs(weekNarrative);
    paragraphs.forEach(p => {
      lines.push(p.trim());
      lines.push('');
    });
  } else {
    lines.push('Markets showed mixed performance this week as investors digested incoming economic data. The key theme was sector rotation beneath headline calm, with divergence between growth and value factors signaling uncertainty about the next directional move.');
    lines.push('');
  }
  
  // Sector Rotation Analysis
  const sectorAnalysis = sections.sector_rotation_analyzer?.data?.analysis;
  const sectorData = sections.sector_rotation_analyzer?.data;
  
  if (sectorAnalysis) {
    lines.push('### Sector Rotation');
    lines.push('');
    const paragraphs = splitIntoParagraphs(sectorAnalysis);
    paragraphs.forEach(p => {
      lines.push(p.trim());
      lines.push('');
    });
  } else if (sectorData?.leaders && sectorData?.laggards) {
    lines.push('### Sector Rotation');
    lines.push('');
    const leaderNames = sectorData.leaders.map(s => `${s.name || s.symbol} (${formatPct(s.return)})`).join(', ');
    const laggardNames = sectorData.laggards.map(s => `${s.name || s.symbol} (${formatPct(s.return)})`).join(', ');
    
    lines.push(`Evidence from sector performance suggests a clear rotation pattern this week. Leaders were ${leaderNames}, while ${laggardNames} lagged the broader market. This matters because such rotation indicates investors recalibrating their growth expectations amid evolving macro conditions.`);
    lines.push('');
  }
  
  lines.push('---');
  lines.push('');
  
  // ========== EVENTS THIS WEEK ==========
  lines.push('## Events This Week');
  lines.push('');
  lines.push('*Key Data Releases & Corporate Calendar*');
  lines.push('');
  
  // Macro Events
  const macroEvents = sections.macro_events_writer?.data?.events ||
                     sections.economic_calendar_fetcher?.data?.events || [];
  
  if (macroEvents && macroEvents.length > 0) {
    lines.push('### Macro Events');
    lines.push('');
    
    for (const event of macroEvents.slice(0, 5)) {
      const name = event.name || event.title || 'Economic Event';
      const previous = event.previous || event.prior || '-';
      const forecast = event.forecast || event.expected || '-';
      const analysis = event.analysis || '';
      
      lines.push(`**${name}**`);
      lines.push('');
      lines.push(`Previous: ${previous} | Forecast: ${forecast}`);
      lines.push('');
      
      if (analysis) {
        lines.push(analysis);
        lines.push('');
      }
    }
  }
  
  // Micro Events (Earnings)
  const microAnalysis = sections.micro_events_writer?.data?.analysis;
  if (microAnalysis) {
    lines.push('### Earnings Calendar');
    lines.push('');
    const paragraphs = splitIntoParagraphs(microAnalysis);
    paragraphs.forEach(p => {
      lines.push(p.trim());
      lines.push('');
    });
  }
  
  lines.push('---');
  lines.push('');
  
  // ========== TACTICAL PREPARATION ==========
  lines.push('## Tactical Preparation');
  lines.push('');
  lines.push('*Markets & Macro Analysis*');
  lines.push('');
  
  // Global Macro
  const tacticalAnalysis = sections.tactical_macro_analyst?.data?.analysis ||
                          sections.tactical_macro_analyst?.data?.globalMacro;
  
  if (tacticalAnalysis) {
    lines.push('### Global Macro');
    lines.push('');
    const paragraphs = splitIntoParagraphs(tacticalAnalysis);
    paragraphs.forEach(p => {
      lines.push(p.trim());
      lines.push('');
    });
  }
  
  // Flows & Sentiment
  const flowsAnalysis = sections.flows_sentiment_analyst?.data?.analysis;
  
  if (flowsAnalysis) {
    lines.push('### Flows, Sentiment & Risk Pricing');
    lines.push('');
    const paragraphs = splitIntoParagraphs(flowsAnalysis);
    paragraphs.forEach(p => {
      lines.push(p.trim());
      lines.push('');
    });
  }
  
  // Key Risks
  const risks = sections.risk_assessment_builder?.data?.risks ||
               sections.risk_monitor?.data?.risks || [];
  
  if (risks && risks.length > 0) {
    lines.push('### Key Risks to Monitor');
    lines.push('');
    
    for (const risk of risks) {
      const title = risk.title || risk.name || 'Market Risk';
      const description = risk.description || risk.analysis || '';
      
      lines.push(`**${title}**`);
      lines.push('');
      
      if (description) {
        const paragraphs = splitIntoParagraphs(description);
        paragraphs.forEach(p => {
          lines.push(p.trim());
          lines.push('');
        });
      }
    }
  }
  
  lines.push('---');
  lines.push('');
  
  // ========== TRADE IDEAS ==========
  const tradeIdeas = sections.trade_idea_generator?.data?.ideas ||
                    sections.risk_manager?.data?.ideas || [];
  
  if (tradeIdeas && tradeIdeas.length > 0) {
    lines.push('## Trade Ideas');
    lines.push('');
    
    for (let i = 0; i < tradeIdeas.length; i++) {
      const idea = tradeIdeas[i];
      const ticker = idea.ticker || idea.symbol || 'N/A';
      const direction = (idea.direction || 'LONG').toUpperCase();
      const conviction = idea.conviction || 'MEDIUM';
      const entry = idea.entry || '-';
      const stop = idea.stop || '-';
      const target = idea.target || '-';
      const timeframe = idea.timeframe || '2-4 weeks';
      const rationale = idea.rationale || idea.reason || '';
      
      lines.push(`### Trade #${i + 1}: ${ticker} (${direction}) — ${conviction} Conviction`);
      lines.push('');
      lines.push(`**Entry:** ${entry} | **Stop:** ${stop} | **Target:** ${target} | **Timeframe:** ${timeframe}`);
      lines.push('');
      
      if (rationale) {
        lines.push('**Rationale:**');
        lines.push('');
        lines.push(rationale);
        lines.push('');
      }
    }
  }
  
  lines.push('---');
  lines.push('');
  
  // Footer
  lines.push('*This report is for informational purposes only and does not constitute investment advice.*');
  lines.push('');
  lines.push(`*Generated by ${COMPANY_NAME} Weekly Report System v${VERSION}*`);
  
  if (qa?.qaScore) {
    lines.push('');
    lines.push(`*QA Score: ${qa.qaScore}/100*`);
  }
  
  return lines.join('\n');
}

// =====================================================
// HTML REPORT GENERATOR
// =====================================================

export function generateHTMLReport(data, reportWeek) {
  const markdown = generateMarkdownReport(data, reportWeek);
  
  // Convert markdown to HTML
  let html = markdown
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    .replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/^---$/gim, '<hr>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>');
  
  // Wrap in HTML structure with professional styling
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weekly Tactical Review - ${formatWeekDisplay(reportWeek)} | ${COMPANY_NAME}</title>
  <style>
    * {
      box-sizing: border-box;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.7;
      max-width: 800px;
      margin: 0 auto;
      padding: 40px 20px;
      color: #1a1a1a;
      background: #ffffff;
    }
    
    h1 {
      color: #1E3A8A;
      font-size: 28px;
      border-bottom: 3px solid #C9A646;
      padding-bottom: 12px;
      margin-bottom: 8px;
    }
    
    h2 {
      color: #1E3A8A;
      font-size: 20px;
      margin-top: 40px;
      border-bottom: 2px solid #C9A646;
      padding-bottom: 8px;
    }
    
    h3 {
      color: #2563EB;
      font-size: 16px;
      margin-top: 25px;
      border-bottom: 1px solid #C9A646;
      padding-bottom: 5px;
    }
    
    p {
      margin: 0 0 18px 0;
      text-align: justify;
    }
    
    hr {
      border: none;
      border-top: 1px solid #e0e0e0;
      margin: 35px 0;
    }
    
    strong {
      color: #1E3A8A;
    }
    
    em {
      color: #6B7280;
      font-style: italic;
    }
    
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 20px 0;
      font-size: 14px;
    }
    
    th, td {
      border: 1px solid #e5e7eb;
      padding: 10px 12px;
      text-align: left;
    }
    
    th {
      background-color: #f3f4f6;
      font-weight: 600;
      color: #374151;
    }
    
    tr:nth-child(even) {
      background-color: #f9fafb;
    }
    
    .positive {
      color: #059669;
    }
    
    .negative {
      color: #DC2626;
    }
    
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #e0e0e0;
      font-size: 12px;
      color: #9ca3af;
      text-align: center;
    }
  </style>
</head>
<body>
  ${html}
  <div class="footer">
    © ${new Date().getFullYear()} ${COMPANY_NAME}. All Rights Reserved.
  </div>
</body>
</html>`;
}

// =====================================================
// HELPER FUNCTIONS
// =====================================================

function formatWeekDisplay(reportWeek) {
  if (!reportWeek) {
    const now = new Date();
    return now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  }
  
  try {
    const date = new Date(reportWeek);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  } catch {
    return reportWeek;
  }
}

function formatPct(num) {
  if (num === null || num === undefined) return '-';
  const n = Number(num);
  if (isNaN(n)) return '-';
  const prefix = n > 0 ? '+' : '';
  return prefix + n.toFixed(2) + '%';
}

function splitIntoParagraphs(text) {
  if (!text) return [];
  
  // Clean the text
  const cleaned = String(text)
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/#{1,6}\s*/g, '')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .trim();
  
  // Split by double newlines or single newlines that look like paragraph breaks
  return cleaned.split(/\n\n|\n/).filter(p => p.trim().length > 0);
}

export default {
  generateMarkdownReport,
  generateHTMLReport,
};