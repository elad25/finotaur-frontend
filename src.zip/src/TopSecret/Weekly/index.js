// =====================================================
// WEEKLY TACTICAL REVIEW - ORCHESTRATOR v12.0
// =====================================================
// Coordinates all agents to generate the weekly report
// v12.0: Added 5 new agents for Midapnim-style components
// =====================================================

import {
  PHASES,
  PHASE_ORDER,
  PHASE_LABELS,
  AGENT_DEFINITIONS,
  VERSION,
} from './config.js';
import { createAgent } from './WeeklyAgents.js';
import { generateWeeklyPDF } from './pdf-generator.js';
import { generateAllWeeklyCharts } from './chart-generator.js';

// =====================================================
// WORKFLOW MANAGER
// =====================================================
class WorkflowManager {
  constructor() {
    this.workflows = new Map();
  }

  create(reportId) {
    const workflow = {
      reportId,
      status: 'running',
      progress: 0,
      currentPhase: PHASES.DATA_ACQUISITION,
      currentAgentId: null,
      currentAgentName: null,
      completedAgents: [],
      totalAgents: AGENT_DEFINITIONS.length,
      elapsedSeconds: 0,
      startedAt: new Date().toISOString(),
      error: null,
      logs: [],
    };
    this.workflows.set(reportId, workflow);
    return workflow;
  }

  get(reportId) {
    return this.workflows.get(reportId);
  }

  update(reportId, updates) {
    const workflow = this.workflows.get(reportId);
    if (workflow) {
      Object.assign(workflow, updates);
    }
    return workflow;
  }

  addLog(reportId, message) {
    const workflow = this.workflows.get(reportId);
    if (workflow) {
      workflow.logs.push({
        timestamp: new Date().toISOString(),
        message,
      });
      // Keep only last 50 logs
      if (workflow.logs.length > 50) {
        workflow.logs = workflow.logs.slice(-50);
      }
    }
  }

  delete(reportId) {
    this.workflows.delete(reportId);
  }

  getAll() {
    return Array.from(this.workflows.values());
  }
}

export const workflowManager = new WorkflowManager();

// =====================================================
// DATA SERVICE WRAPPER
// =====================================================
export class WeeklyDataService {
  constructor(options) {
    const opts = options || {};
    this.polygonApiKey = opts.polygonApiKey || process.env.POLYGON_API_KEY;
    this.perplexityApiKey = opts.perplexityApiKey || process.env.PERPLEXITY_API_KEY;
  }

  async fetchMarketData(symbols, startDate, endDate) {
    const results = {};
    
    for (const symbol of symbols) {
      try {
        const data = await this.fetchTickerData(symbol, startDate, endDate);
        results[symbol] = data;
      } catch (error) {
        console.warn(`[DataService] Failed to fetch ${symbol}:`, error.message);
        results[symbol] = this.getFallbackData(symbol);
      }
    }
    
    return results;
  }

  async fetchTickerData(symbol, startDate, endDate) {
    if (!this.polygonApiKey) {
      return this.getFallbackData(symbol);
    }

    const url = `https://api.polygon.io/v2/aggs/ticker/${symbol}/range/1/day/${startDate}/${endDate}?apiKey=${this.polygonApiKey}`;
    
    try {
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        return this.processPolygonData(symbol, data.results);
      }
      
      return this.getFallbackData(symbol);
    } catch (error) {
      console.error(`[DataService] Polygon API error for ${symbol}:`, error.message);
      return this.getFallbackData(symbol);
    }
  }

  processPolygonData(symbol, results) {
    const latest = results[results.length - 1];
    const first = results[0];
    
    const weeklyReturn = ((latest.c - first.o) / first.o) * 100;
    const high = Math.max(...results.map(r => r.h));
    const low = Math.min(...results.map(r => r.l));
    const avgVolume = results.reduce((sum, r) => sum + r.v, 0) / results.length;
    
    return {
      symbol,
      open: first.o,
      close: latest.c,
      high,
      low,
      weeklyReturn: weeklyReturn.toFixed(2),
      avgVolume: Math.round(avgVolume),
      dataPoints: results.length,
      source: 'polygon',
    };
  }

  getFallbackData(symbol) {
    const basePrice = this.getBasePrice(symbol);
    const volatility = this.getVolatility(symbol);
    const change = (Math.random() - 0.5) * volatility;
    
    return {
      symbol,
      open: basePrice,
      close: basePrice * (1 + change / 100),
      high: basePrice * (1 + Math.abs(change) / 100 + 0.5),
      low: basePrice * (1 - Math.abs(change) / 100 - 0.5),
      weeklyReturn: change.toFixed(2),
      avgVolume: Math.round(Math.random() * 50000000 + 10000000),
      dataPoints: 5,
      source: 'fallback',
    };
  }

  getBasePrice(symbol) {
    const basePrices = {
      SPY: 595, QQQ: 525, IWM: 225, DIA: 435,
      TLT: 90, IEF: 95, GLD: 245, USO: 78, UUP: 28, VIX: 15,
      HYG: 78, LQD: 108, EEM: 42, EFA: 78, FXI: 28,
      XLK: 235, XLF: 50, XLE: 95, XLV: 148,
      XLI: 135, XLP: 85, XLY: 215, XLU: 78,
      XLB: 90, XLRE: 45, XLC: 95,
    };
    return basePrices[symbol] || 100;
  }

  getVolatility(symbol) {
    const volatilities = {
      SPY: 3, QQQ: 4, IWM: 5, DIA: 2.5,
      TLT: 4, IEF: 2, GLD: 3, USO: 8, UUP: 2, VIX: 20,
      HYG: 3, LQD: 2, EEM: 5, EFA: 4, FXI: 6,
      XLK: 4.5, XLF: 4, XLE: 6, XLV: 3,
      XLI: 3.5, XLP: 2, XLY: 4, XLU: 2.5,
      XLB: 4, XLRE: 4, XLC: 4,
    };
    return volatilities[symbol] || 4;
  }
}

// =====================================================
// WEEKLY ORCHESTRATOR v12.0
// =====================================================
export class WeeklyOrchestrator {
  constructor(options) {
    const opts = options || {};
    this.dataService = opts.dataService || new WeeklyDataService(opts);
    this.onProgress = opts.onProgress || (() => {});
    this.onAgentComplete = opts.onAgentComplete || (() => {});
    this.onError = opts.onError || console.error;
  }

  async generate(reportWeek, options) {
    const opts = options || {};
    const reportId = opts.reportId || `weekly-${reportWeek}-${Date.now()}`;
    const startTime = Date.now();
    
    console.log(`[Orchestrator v12.0] Starting generation for ${reportWeek}, reportId: ${reportId}`);
    console.log(`[Orchestrator v12.0] Total agents: ${AGENT_DEFINITIONS.length}`);
    
    // Create workflow tracking
    const workflow = workflowManager.create(reportId);
    
    // Start elapsed time tracker
    const elapsedInterval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      workflowManager.update(reportId, { elapsedSeconds: elapsed });
    }, 1000);

    const results = {};
    const errors = [];
    
    try {
      // Execute agents in phase order
      for (const phase of PHASE_ORDER) {
        const phaseAgents = AGENT_DEFINITIONS.filter(a => a.phase === phase);
        
        workflowManager.update(reportId, { currentPhase: phase });
        workflowManager.addLog(reportId, `Starting phase: ${PHASE_LABELS[phase]}`);
        console.log(`[Orchestrator] Starting phase: ${PHASE_LABELS[phase]} (${phaseAgents.length} agents)`);
        
        for (const agentDef of phaseAgents) {
          try {
            // Check dependencies
            const missingDeps = agentDef.dependencies.filter(dep => !results[dep]?.success);
            if (missingDeps.length > 0) {
              console.warn(`[Orchestrator] Agent ${agentDef.id} skipped - missing deps: ${missingDeps.join(', ')}`);
              continue;
            }

            // Update current agent
            workflowManager.update(reportId, {
              currentAgentId: agentDef.id,
              currentAgentName: agentDef.name,
            });
            
            // Calculate progress
            const completedCount = workflow.completedAgents.length;
            const progress = Math.round((completedCount / workflow.totalAgents) * 100);
            workflowManager.update(reportId, { progress });
            
            // Notify progress
            this.onProgress({
              reportId,
              progress,
              currentPhase: phase,
              currentAgentId: agentDef.id,
              currentAgentName: agentDef.name,
              elapsedSeconds: Math.floor((Date.now() - startTime) / 1000),
            });
            
            workflowManager.addLog(reportId, `Running: ${agentDef.name}`);
            console.log(`[Orchestrator] Running: ${agentDef.name}`);
            
            // Create and execute agent
            const agent = createAgent(agentDef.id);
            const agentStartTime = Date.now();
            
            const result = await agent.execute({
              reportWeek,
              dataService: this.dataService,
              previousResults: results,
            });
            
            const agentDuration = Date.now() - agentStartTime;
            results[agentDef.id] = result;
            
            // Mark as completed
            workflow.completedAgents.push(agentDef.id);
            workflowManager.addLog(reportId, `Completed: ${agentDef.name} (${(agentDuration/1000).toFixed(1)}s)`);
            console.log(`[Orchestrator] Completed: ${agentDef.name} (${(agentDuration/1000).toFixed(1)}s)`);
            
            // Notify agent completion
            this.onAgentComplete({
              reportId,
              agentId: agentDef.id,
              agentName: agentDef.name,
              success: result.success,
              phase,
              duration: agentDuration,
            });
            
          } catch (agentError) {
            console.error(`[Orchestrator] Agent ${agentDef.id} failed:`, agentError.message);
            errors.push({ agent: agentDef.id, error: agentError.message });
            results[agentDef.id] = { success: false, error: agentError.message };
            workflowManager.addLog(reportId, `Error in ${agentDef.name}: ${agentError.message}`);
          }
        }
      }
      
      // Generate charts with new data sources
      console.log('[Orchestrator] Generating charts...');
      workflowManager.addLog(reportId, 'Generating charts...');
      
      let charts = {};
      try {
        // Prepare chart data from new agents
        const chartData = {
          indices: results.market_data_fetcher?.data?.indices,
          sectors: results.market_data_fetcher?.data?.sectors,
          sentiment: results.flows_sentiment_analyst?.data,
        };
        
        const additionalData = {
          bofa: results.bofa_indicator_agent?.data?.indicator || results.sentiment_data_fetcher?.data?.parsed?.bofaBullBear,
          breadth: results.market_breadth_agent?.data?.breadth,
          flows: results.institutional_flows_agent?.data?.flows || results.flows_data_fetcher?.data?.parsed,
          cta: results.cta_positioning_agent?.data?.cta,
        };
        
        charts = await generateAllWeeklyCharts(chartData, {}, additionalData);
        workflowManager.addLog(reportId, `Charts generated: ${Object.keys(charts).filter(k => charts[k]).length} charts`);
      } catch (chartError) {
        console.warn('[Orchestrator] Chart generation failed:', chartError.message);
        workflowManager.addLog(reportId, `Charts skipped: ${chartError.message}`);
      }

      // Generate PDF
      console.log('[Orchestrator] Generating PDF...');
      workflowManager.addLog(reportId, 'Generating PDF...');
      
      const reportData = {
        reportWeek,
        reportDate: reportWeek,
        sections: results,
        // Extract key data for PDF
        weekSummary: {
          narrative: results.week_narrative_writer?.data?.narrative,
          centralThesis: results.week_narrative_writer?.data?.centralThesis,
          sectorAnalysis: results.sector_rotation_analyzer?.data?.analysis,
        },
        indices: results.market_data_fetcher?.data?.indices,
        sectors: results.market_data_fetcher?.data?.sectors,
        macroCalendar: {
          events: results.macro_events_writer?.data?.events || [],
          analysis: results.macro_events_writer?.data?.analysis,
        },
        microEvents: results.micro_events_writer?.data?.events || [],
        tacticalAnalysis: results.tactical_macro_analyst?.data?.analysis,
        flowsSentiment: results.flows_sentiment_analyst?.data,
        keyRisks: results.risk_assessment_builder?.data?.risks || [],
        tradeIdeas: results.risk_manager?.data?.ideas || results.trade_idea_generator?.data?.ideas || [],
      };
      
      // PDF options including charts and logo
      const pdfOptions = {
        logoPath: opts.logoPath,
        charts: charts,
      };
      
      let pdfBuffer = null;
      try {
        const pdfResult = await generateWeeklyPDF(reportData, pdfOptions);
        pdfBuffer = pdfResult.buffer || pdfResult;
        if (pdfBuffer && pdfBuffer.length) {
          workflowManager.addLog(reportId, `PDF generated: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
        }
      } catch (pdfError) {
        console.error('[Orchestrator] PDF generation failed:', pdfError.message);
        workflowManager.addLog(reportId, `PDF error: ${pdfError.message}`);
      }
      
      // Update workflow as complete
      clearInterval(elapsedInterval);
      const durationMs = Date.now() - startTime;
      
      workflowManager.update(reportId, {
        status: 'completed',
        progress: 100,
        currentAgentId: null,
        currentAgentName: null,
        elapsedSeconds: Math.floor(durationMs / 1000),
      });
      
      console.log(`[Orchestrator v12.0] Generation complete in ${Math.floor(durationMs / 1000)}s`);
      
      return {
        success: true,
        reportId,
        reportWeek,
        report: reportData,
        pdfBuffer,
        meta: {
          reportWeek,
          generatedAt: new Date().toISOString(),
          durationMs,
          durationFormatted: this.formatDuration(durationMs),
          agentsCompleted: workflow.completedAgents.length,
          agentsTotal: workflow.totalAgents,
          errorsCount: errors.length,
          qaScore: results.coherence_checker?.data?.qaScore || 0,
          centralThesis: results.week_narrative_writer?.data?.centralThesis,
          version: VERSION,
        },
      };
      
    } catch (error) {
      clearInterval(elapsedInterval);
      
      console.error('[Orchestrator] Generation failed:', error);
      workflowManager.addLog(reportId, `Generation failed: ${error.message}`);
      
      workflowManager.update(reportId, {
        status: 'error',
        error: error.message,
      });
      
      this.onError(error);
      
      return {
        success: false,
        reportId,
        reportWeek,
        error: error.message,
        meta: {
          reportWeek,
          generatedAt: new Date().toISOString(),
          durationMs: Date.now() - startTime,
          agentsCompleted: workflow.completedAgents.length,
          agentsTotal: workflow.totalAgents,
          errorsCount: errors.length + 1,
          version: VERSION,
        },
      };
    }
  }

  formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  }
}

// =====================================================
// MAIN ENTRY POINT
// =====================================================
let dataService = null;
let supabaseClient = null;

export function initWeeklyService(options) {
  const opts = options || {};
  
  console.log(`[Weekly Tactical v12.0] Initializing service v${VERSION}`);
  console.log(`[Weekly Tactical v12.0] Agents count: ${AGENT_DEFINITIONS.length}`);
  
  // Store supabase client if provided
  if (opts.supabase) {
    supabaseClient = opts.supabase;
    console.log('[Weekly Tactical] Supabase client configured for persistent storage');
  }
  
  // Set environment variables if provided
  if (opts.openaiApiKey) {
    process.env.OPENAI_API_KEY = opts.openaiApiKey;
  }
  if (opts.polygonApiKey) {
    process.env.POLYGON_API_KEY = opts.polygonApiKey;
  }
  if (opts.perplexityApiKey) {
    process.env.PERPLEXITY_API_KEY = opts.perplexityApiKey;
  }
  
  dataService = new WeeklyDataService(opts);
  
  return {
    dataService,
    supabase: supabaseClient,
    version: VERSION,
    agentsCount: AGENT_DEFINITIONS.length,
  };
}

export async function generateWeeklyReport(reportWeek, options) {
  const opts = options || {};
  
  if (!dataService) {
    dataService = new WeeklyDataService(opts);
  }
  
  const weekStr = reportWeek || new Date().toISOString().split('T')[0];
  
  const orchestrator = new WeeklyOrchestrator({
    dataService,
    onProgress: opts.onProgress,
    onAgentComplete: opts.onAgentComplete,
    onError: opts.onError,
  });
  
  return orchestrator.generate(weekStr, opts);
}

export function fetchWeeklyProgress(reportId) {
  const workflow = workflowManager.get(reportId);
  
  if (!workflow) {
    return {
      reportId,
      status: 'not_found',
      progress: 0,
    };
  }
  
  return {
    reportId,
    status: workflow.status,
    progress: workflow.progress,
    currentPhase: workflow.currentPhase,
    currentAgentId: workflow.currentAgentId,
    currentAgentName: workflow.currentAgentName,
    completedAgents: workflow.completedAgents,
    totalAgents: workflow.totalAgents,
    elapsedSeconds: workflow.elapsedSeconds,
    error: workflow.error,
    logs: workflow.logs.slice(-10),
  };
}

// =====================================================
// EXPORTS
// =====================================================
export {
  VERSION,
  PHASES,
  PHASE_ORDER,
  PHASE_LABELS,
  AGENT_DEFINITIONS,
};

export default {
  initWeeklyService,
  generateWeeklyReport,
  fetchWeeklyProgress,
  workflowManager,
  WeeklyDataService,
  WeeklyOrchestrator,
  generateWeeklyPDF,
};