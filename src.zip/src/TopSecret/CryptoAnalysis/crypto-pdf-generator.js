// ==========================================
// CRYPTO REPORT PDF GENERATOR v3.2 - PM GRADE
// ==========================================
// With Logo Support and Enhanced Formatting
// TOP SECRET - Crypto Analysis
//
// CHANGES IN v3.2:
// - IMPROVED: Stricter orphan title prevention (iron rule)
// - IMPROVED: Side-by-side charts now have section title + intro paragraph
// - IMPROVED: Larger chart sizes for better readability
// - IMPROVED: Title always stays with first paragraph
// - NEW: Title protection zone (150px minimum)
// ==========================================

import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';

// ============ COLORS ============
const COLORS = {
  gold: '#C9A646',
  black: '#000000',
  darkText: '#1A1A1A',
  mediumGray: '#555555',
  lightGray: '#888888',
  veryLightGray: '#CCCCCC',
  ultraLightGray: '#EEEEEE',
  white: '#FFFFFF',
  green: '#16A34A',
  red: '#DC2626',
  orange: '#F59E0B',
  blue: '#3B82F6',
  purple: '#8B5CF6',
  cyan: '#06B6D4',
  // Crypto-specific
  btcOrange: '#F7931A',
  ethPurple: '#627EEA',
  bullish: '#22C55E',
  bearish: '#EF4444',
  neutral: '#6B7280',
  // PM-Grade colors
  highConfidence: '#22C55E',
  mediumConfidence: '#F59E0B',
  lowConfidence: '#EF4444',
};

// ============ TYPOGRAPHY ============
const FONT_DIR = path.join(process.cwd(), 'static', 'fonts');
const INTER_REGULAR = path.join(FONT_DIR, 'Inter_18pt-Regular.ttf');
const INTER_BOLD = path.join(FONT_DIR, 'Inter_18pt-Bold.ttf');

const hasInterFont = fs.existsSync(INTER_REGULAR) && fs.existsSync(INTER_BOLD);

const FONTS = {
  title: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  heading: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  body: hasInterFont ? 'Inter-Regular' : 'Helvetica',
  bold: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
};

function registerFonts(doc) {
  if (hasInterFont) {
    doc.registerFont('Inter-Regular', INTER_REGULAR);
    doc.registerFont('Inter-Bold', INTER_BOLD);
    console.log('[Crypto PDF] Using Inter font');
  } else {
    console.log('[Crypto PDF] Inter font not found, using Helvetica');
  }
}

const SIZES = {
  coverTitle: 28,
  coverSubtitle: 18,
  coverDate: 14,
  coverTagline: 11,
  sectionTitle: 16,
  subSection: 12,
  ticker: 14,
  body: 10,
  small: 9,
  footer: 8,
  tag: 7,
};

// ============ PAGE LAYOUT ============
const PAGE = {
  width: 612,
  height: 792,
  marginLeft: 50,
  marginRight: 50,
  marginTop: 60,
  marginBottom: 50,
  
  get contentWidth() { return this.width - this.marginLeft - this.marginRight; },
  get contentTop() { return this.marginTop + 25; },
  get footerY() { return this.height - 30; },
  get contentBottom() { return this.footerY - 25; },
  get safeBottom() { return this.footerY - 40; },
  get contentHeight() { return this.contentBottom - this.contentTop; },
get threshold70() { return this.contentTop + (this.contentHeight * 0.70); },
  get minSectionSpace() { return 60; },
  get minContentSpace() { return 35; },
};

// ============ DATA TAGS STYLING ============
// Note: Tags are now simplified to "-", "N/A", etc. in report generator
const TAG_STYLES = {
  // Keep minimal styling for backward compatibility
  'Limited': { bg: '#FEF3C7', text: '#92400E', label: 'Limited' },
  'Estimated': { bg: '#FEF9C3', text: '#854D0E', label: 'Est.' },
  'TBD': { bg: '#E9D5FF', text: '#6B21A8', label: 'TBD' },
};

// ============ CONFIDENCE BADGE STYLING ============
const CONFIDENCE_STYLES = {
  'High': { bg: '#DCFCE7', text: '#166534', label: 'HIGH' },
  'Medium': { bg: '#FEF3C7', text: '#92400E', label: 'MEDIUM' },
  'Low': { bg: '#FEE2E2', text: '#991B1B', label: 'LOW' },
};

// ============ TIME HORIZON STYLING ============
const HORIZON_STYLES = {
  'Short-term': { bg: '#DBEAFE', text: '#1E40AF', label: 'SHORT' },
  'Tactical': { bg: '#E9D5FF', text: '#6B21A8', label: 'TACTICAL' },
  'Structural': { bg: '#FEF3C7', text: '#92400E', label: 'STRUCTURAL' },
};

const COPYRIGHT = '© 2025 FINOTAUR | TOP SECRET';

// ============ LOGO PATHS (Multiple fallbacks) ============
const LOGO_PATHS = [
  // Primary path from user's screenshot
  path.join(process.cwd(), 'public', 'logo.png'),
  // Alternative paths
  path.join(process.cwd(), 'static', 'logo.png'),
  path.join(process.cwd(), 'assets', 'logo.png'),
  path.join(process.cwd(), 'public', 'assets', 'logo.png'),
  path.join(process.cwd(), 'logo.png'),
];

function findLogo() {
  for (const logoPath of LOGO_PATHS) {
    if (fs.existsSync(logoPath)) {
      console.log(`[Crypto PDF] Found logo at: ${logoPath}`);
      return logoPath;
    }
  }
  console.log('[Crypto PDF] No logo file found in standard paths');
  return null;
}

// ============ HELPER FUNCTIONS ============
function needsPageBreak(currentY, requiredSpace) {
  return currentY + requiredSpace > PAGE.safeBottom;
}

function pastThresholdForNewSection(currentY) {
  return currentY > PAGE.threshold70;
}

function cleanText(text) {
  if (!text) return '';
  return text
    .replace(/[\u{10000}-\u{10FFFF}]/gu, '')
    .replace(/[\u{1F000}-\u{1FFFF}]/gu, '')
    .replace(/[\u{2600}-\u{26FF}]/gu, '')
    .replace(/[\u{2700}-\u{27BF}]/gu, '')
    .replace(/[\u{FE00}-\u{FE0F}]/gu, '')
    .replace(/[\u{2300}-\u{23FF}]/gu, '')
    .replace(/[\u{2B00}-\u{2BFF}]/gu, '')
    .replace(/[\u{25A0}-\u{25FF}]/gu, '')
    .replace(/[\u{2190}-\u{21FF}]/gu, '')
    .replace(/[\u{3000}-\u{303F}]/gu, '')
    .replace(/[\u{2000}-\u{206F}]/gu, '')
    .replace(/[\u{20D0}-\u{20FF}]/gu, '')
    .replace(/[\u{2100}-\u{214F}]/gu, '')
    .replace(/[\u{2460}-\u{24FF}]/gu, '')
    .replace(/[\u{2500}-\u{257F}]/gu, '')
    .replace(/[\u{2580}-\u{259F}]/gu, '')
    .replace(/[\u{E000}-\u{F8FF}]/gu, '')
    .replace(/[\u{FFF0}-\u{FFFF}]/gu, '')
    .replace(/[\u{D800}-\u{DFFF}]/gu, '')
    .replace(/[\u00D8\u00D8-\u00FF]/g, (char) => {
      const code = char.charCodeAt(0);
      if (code >= 0xC0 && code <= 0xFF) {
        return '';
      }
      return char;
    })
    .replace(/[\x00-\x1F\x7F-\x9F]/g, '')
    .replace(/[█▓▒░▀▄▌▐▕■□▢▣▤▥▦▧▨▩▪▫▬▭▮▯]/g, '')
    .replace(/\*\*/g, '')
    .replace(/\#\#/g, '')
    .replace(/\#/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanTitle(text) {
  if (!text) return '';
  let cleaned = cleanText(text);
  cleaned = cleaned.replace(/[^\x20-\x7E\u00A0-\u00BF]/g, '');
  cleaned = cleaned.replace(/[=]+/g, ' ');
  cleaned = cleaned.replace(/\s+/g, ' ').trim();
  return cleaned;
}

function isMetadataLine(line) {
  if (!line) return false;
  const patterns = [
    /Report generated by/i,
    /\d+ AI Agents/i,
    /Data:.*CoinGecko/i,
    /Finotaur.*Engine/i,
    /Crypto Analysis Engine/i,
    /Crypto Intelligence/i,
    /^\*.*\d{4}-\d{2}-\d{2}T\d{2}:\d{2}.*\*$/,
    /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/,
    /^• Report generated/i,
    /^• \d+ AI Agents/i,
    /^• Data:/i,
  ];
  return patterns.some(pattern => pattern.test(line));
}

function getSignalColor(signal) {
  if (!signal) return COLORS.darkText;
  const s = signal.toLowerCase();
  if (s.includes('bullish') || s.includes('green') || s.includes('positive')) return COLORS.bullish;
  if (s.includes('bearish') || s.includes('red') || s.includes('negative')) return COLORS.bearish;
  return COLORS.neutral;
}

function getPercentColor(value) {
  if (typeof value === 'string') {
    const match = value.match(/([+-]?\d+\.?\d*)/);
    if (match) value = parseFloat(match[1]);
  }
  if (typeof value !== 'number' || isNaN(value)) return COLORS.darkText;
  if (value > 0.5) return COLORS.bullish;
  if (value < -0.5) return COLORS.bearish;
  return COLORS.darkText;
}

function getConfidenceColor(confidence) {
  if (!confidence) return COLORS.mediumGray;
  const c = confidence.toLowerCase();
  if (c === 'high') return COLORS.highConfidence;
  if (c === 'medium') return COLORS.mediumConfidence;
  if (c === 'low') return COLORS.lowConfidence;
  return COLORS.mediumGray;
}

// ============ ESTIMATE SECTION HEIGHT ============
function estimateSectionHeight(section) {
  let height = 0;
  
  // Title height
  if (section.title) {
    height += section.type === 'page' ? 45 : 25;
  }
  
  // Content height estimation
  if (section.content) {
    for (const item of section.content) {
      if (item.type === 'paragraph') {
        const lines = Math.ceil((item.text?.length || 0) / 80);
        height += lines * 14 + 8;
      } else if (item.type === 'table_row') {
        height += 22;
      } else if (item.type === 'bullet') {
        height += 18;
      } else if (item.type === 'subsection') {
        height += 25;
      }
    }
  }
  
  return height;
}

// ============ ORPHAN TITLE PREVENTION - IRON RULE ============
// A title must NEVER appear at the bottom of a page without its first paragraph
// This applies to: section titles, subsection titles, chart titles
// v3.2: Strengthened - titles ALWAYS stay with minimum 2 paragraphs or first content block
const MIN_CONTENT_AFTER_TITLE = 120; // At least 120px of content must follow a title on same page
const MIN_LINES_WITH_TITLE = 4;      // At least 4 lines of text must accompany a title
const TITLE_PROTECTION_ZONE = 150;   // If less than 150px remaining, break before title

function estimateUpcomingContentHeight(content, startIndex, maxItems = 5) {
  let height = 0;
  let lineCount = 0;
  
  for (let i = startIndex; i < Math.min(startIndex + maxItems, content.length); i++) {
    const item = content[i];
    if (item.type === 'paragraph') {
      const textLength = item.text?.length || 0;
      const lines = Math.ceil(textLength / 80);
      height += lines * 14 + 8;
      lineCount += lines;
    } else if (item.type === 'table_row') {
      height += 22;
      lineCount += 1;
    } else if (item.type === 'bullet') {
      height += 18;
      lineCount += 1;
    } else if (item.type === 'subsection') {
      // Stop at next subsection - we only care about immediate content
      break;
    }
    // Stop once we have enough
    if (height > MIN_CONTENT_AFTER_TITLE && lineCount >= MIN_LINES_WITH_TITLE) break;
  }
  return height;
}

// Helper: Check if we should break page BEFORE a title (v3.2 - stricter)
function shouldBreakBeforeTitle(currentY, titleHeight, contentHeight) {
  const spaceRemaining = PAGE.height - PAGE.marginBottom - currentY;
  const requiredSpace = titleHeight + Math.max(contentHeight, MIN_CONTENT_AFTER_TITLE);
  
  // Iron rule: if less than protection zone remaining, always break
  if (spaceRemaining < TITLE_PROTECTION_ZONE) {
    return true;
  }
  
  return spaceRemaining < requiredSpace;
}

// ============ CHART DRAWING HELPER ============
// Chart titles displayed ABOVE charts (v3.1) - Clear questions the chart answers
const CHART_CAPTIONS = {
  // PM-Grade Decision Charts (v3.1) - These are QUESTIONS the chart answers
  marketRegimeGauge: 'Where Are We? Market Regime at a Glance',
  volatilityCompression: 'Is Volatility Compressed? Expect the Next Big Move',
  stablecoinSupply: 'Is Capital Still Here? Stablecoin "Dry Powder"',
  etfFlows: 'What Are Institutions Doing? ETF Flow Analysis',
  sectorHeatmap: 'Which Sectors to Favor? 14-Day Performance',
  
  // Legacy charts (v2.0)
  regimeGauge: 'Market Regime Score',
  priceFundingDivergence: 'Price vs. Funding Divergence',
  liquidityLeverage: 'Liquidity vs. Leverage',
  btcEthCorrelation: 'BTC/ETH Price Action',
};

/**
 * Draw a chart image in the PDF from base64 data
 * v3.2: Caption/title ABOVE the chart, conclusion BELOW, larger charts
 * @param {PDFDocument} doc - The PDF document
 * @param {Object} chart - Chart object with base64 property
 * @param {number} y - Current Y position
 * @param {string} caption - Caption text (now displayed ABOVE the chart)
 * @param {Function} newPageCallback - Callback to create new page if needed
 * @param {Object} options - Additional options { showConclusion: true }
 * @returns {number} New Y position after drawing
 */
function drawChart(doc, chart, y, caption, newPageCallback, options = {}) {
  if (!chart || !chart.success || !chart.base64) {
    console.log('[Crypto PDF] Chart not available, skipping');
    return y;
  }
  
  const { showConclusion = true } = options;
  
  // v3.2: Larger chart sizing - 70% of content width for better visibility
  const maxChartWidth = PAGE.contentWidth * 0.70;
  const chartWidth = Math.min(maxChartWidth, chart.dimensions?.width || 420);
  const chartHeight = chart.dimensions?.height || 280;
  const scaledHeight = (chartHeight / (chart.dimensions?.width || 420)) * chartWidth;
  
  // Calculate total space needed: caption + chart + conclusion
  const captionHeight = caption ? 30 : 0;
  const conclusionHeight = (showConclusion && chart.conclusion) ? 60 : 0;
  const requiredSpace = captionHeight + scaledHeight + conclusionHeight + 25;
  
  // ★★★ ORPHAN PREVENTION: Chart title must stay with chart ★★★
  if (needsPageBreak(y, requiredSpace) || y + captionHeight + 50 > PAGE.safeBottom) {
    y = newPageCallback();
  }
  
  try {
    // ★★★ CAPTION/TITLE ABOVE THE CHART ★★★
    if (caption) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.bold)
         .fontSize(SIZES.body + 1)
         .text(caption, PAGE.marginLeft, y, { 
           width: PAGE.contentWidth, 
           align: 'left',
         });
      y += doc.heightOfString(caption, { width: PAGE.contentWidth }) + 10;
    }
    
    // Convert base64 to buffer and draw image
    const imageBuffer = Buffer.from(chart.base64, 'base64');
    
    // Center the chart
    const xOffset = PAGE.marginLeft + (PAGE.contentWidth - chartWidth) / 2;
    
    doc.image(imageBuffer, xOffset, y, { width: chartWidth });
    y += scaledHeight + 12;
    
    // ★★★ CONCLUSION BELOW THE CHART ★★★
    if (showConclusion && chart.conclusion) {
      // Draw conclusion box
      const conclusionText = chart.conclusion;
      const conclusionBoxHeight = Math.max(45, doc.heightOfString(conclusionText, { width: PAGE.contentWidth - 20 }) + 16);
      
      // Light gold background box
      doc.fillColor('#FEF9E7')
         .roundedRect(PAGE.marginLeft, y, PAGE.contentWidth, conclusionBoxHeight, 4)
         .fill();
      
      // Gold left border
      doc.fillColor(COLORS.gold)
         .rect(PAGE.marginLeft, y, 3, conclusionBoxHeight)
         .fill();
      
      // Conclusion text
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text(conclusionText, PAGE.marginLeft + 12, y + 8, { 
           width: PAGE.contentWidth - 24, 
           align: 'left',
         });
      
      y += conclusionBoxHeight + 18;
    }
    
    console.log('[Crypto PDF] Chart drawn successfully with conclusion');
  } catch (error) {
    console.error('[Crypto PDF] Error drawing chart:', error.message);
  }
  
  return y;
}

/**
 * Draw two charts side by side with optional title, paragraph above, charts, then conclusions below
 * v3.2: Enhanced layout - Optional Title + Paragraph + Side-by-side charts + Combined conclusion
 * @param {PDFDocument} doc - The PDF document
 * @param {Object} chart1 - First chart object
 * @param {Object} chart2 - Second chart object
 * @param {number} y - Current Y position
 * @param {Function} newPageCallback - Callback to create new page if needed
 * @param {Object} options - Layout options { title, introText }
 * @returns {number} New Y position after drawing
 */
function drawChartsSideBySide(doc, chart1, chart2, y, newPageCallback, options = {}) {
  if ((!chart1 || !chart1.success) && (!chart2 || !chart2.success)) {
    return y;
  }
  
  const { title = null, introText = null } = options;
  
  // Calculate dimensions for larger, more readable charts
  const chartWidth = (PAGE.contentWidth - 20) / 2; // 20px gap between charts
  const chartHeight = 220; // Taller charts for better readability
  const conclusionHeight = 70;
  
  // Calculate total space needed
  const titleHeight = title ? 30 : 0;
  const introHeight = introText ? 45 : 0;
  const chartTitlesHeight = 25; // Space for chart titles above each chart
  const requiredSpace = titleHeight + introHeight + chartTitlesHeight + chartHeight + conclusionHeight + 50;
  
  if (needsPageBreak(y, requiredSpace)) {
    y = newPageCallback();
  }
  
  try {
    // ★★★ SECTION TITLE (if provided) ★★★
    if (title) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.bold)
         .fontSize(SIZES.subSection + 1)
         .text(title, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      y += doc.heightOfString(title, { width: PAGE.contentWidth }) + 5;
      
      // Underline
      const lineLength = Math.min(200, doc.widthOfString(title) + 20);
      doc.strokeColor(COLORS.black)
         .lineWidth(1)
         .moveTo(PAGE.marginLeft, y)
         .lineTo(PAGE.marginLeft + lineLength, y)
         .stroke();
      y += 12;
    }
    
    // ★★★ INTRO PARAGRAPH (if provided) ★★★
    if (introText) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text(introText, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      y += doc.heightOfString(introText, { width: PAGE.contentWidth }) + 15;
    }
    
    // ★★★ CHART TITLES ABOVE EACH CHART ★★★
    const chart1Title = chart1?.chartTitle || 'Stablecoin Supply';
    const chart2Title = chart2?.chartTitle || 'ETF Net Flows';
    
    // Draw chart titles
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.body + 1);
    
    doc.text(chart1Title, PAGE.marginLeft, y, { 
      width: chartWidth, 
      align: 'center' 
    });
    doc.text(chart2Title, PAGE.marginLeft + chartWidth + 20, y, { 
      width: chartWidth, 
      align: 'center' 
    });
    
    y += 20;
    
    // ★★★ DRAW CHARTS SIDE BY SIDE ★★★
    if (chart1?.success && chart1?.base64) {
      const buffer1 = Buffer.from(chart1.base64, 'base64');
      doc.image(buffer1, PAGE.marginLeft, y, { width: chartWidth, height: chartHeight });
    }
    
    if (chart2?.success && chart2?.base64) {
      const buffer2 = Buffer.from(chart2.base64, 'base64');
      doc.image(buffer2, PAGE.marginLeft + chartWidth + 20, y, { width: chartWidth, height: chartHeight });
    }
    
    y += chartHeight + 15;
    
    // ★★★ COMBINED CONCLUSION BELOW CHARTS ★★★
    if (chart1?.conclusion || chart2?.conclusion) {
      // Combine conclusions with clear separation
      let combinedConclusion = '';
      if (chart1?.conclusion) {
        combinedConclusion += chart1.conclusion;
      }
      if (chart2?.conclusion) {
        if (combinedConclusion) combinedConclusion += ' ';
        combinedConclusion += chart2.conclusion;
      }
      
      const conclusionBoxHeight = Math.max(50, doc.heightOfString(combinedConclusion, { width: PAGE.contentWidth - 20 }) + 16);
      
      // Light gold background box
      doc.fillColor('#FEF9E7')
         .roundedRect(PAGE.marginLeft, y, PAGE.contentWidth, conclusionBoxHeight, 4)
         .fill();
      
      // Gold left border
      doc.fillColor(COLORS.gold)
         .rect(PAGE.marginLeft, y, 3, conclusionBoxHeight)
         .fill();
      
      // Conclusion text
      doc.fillColor(COLORS.darkText)
         .font(FONTS.body)
         .fontSize(SIZES.small)
         .text(combinedConclusion, PAGE.marginLeft + 12, y + 8, { 
           width: PAGE.contentWidth - 24, 
         });
      
      y += conclusionBoxHeight + 18;
    }
    
    console.log('[Crypto PDF] Side-by-side charts drawn successfully');
    
  } catch (error) {
    console.error('[Crypto PDF] Error drawing side-by-side charts:', error.message);
  }
  
  return y;
}

// ============ MAIN EXPORT ============
export async function generateCryptoReportPDF(reportMarkdown, options = {}) {
  return new Promise((resolve, reject) => {
    try {
      const reportDate = options.reportDate || new Date().toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      
      // Get charts from options
      const charts = options.charts || null;
      if (charts) {
        console.log('[Crypto PDF] Charts provided:', Object.keys(charts.keySignal || {}).join(', '));
      }
      
      // Get logo from options or find it
      let logoData = options.logoBuffer || options.logoBase64 || options.logoPath || null;
      
      // If no logo provided in options, try to find it
      if (!logoData) {
        const foundLogoPath = findLogo();
        if (foundLogoPath) {
          logoData = foundLogoPath;
        }
      }

      console.log(`[Crypto PDF] Starting generation...`);
      console.log(`[Crypto PDF] Logo data type: ${logoData ? (Buffer.isBuffer(logoData) ? 'buffer' : typeof logoData) : 'none'}`);

      const doc = new PDFDocument({
        size: 'letter',
        margin: 0,
        autoFirstPage: false,
        info: {
          Title: `Finotaur Crypto Intelligence - ${reportDate}`,
          Author: 'Finotaur',
          Subject: 'TOP SECRET - Crypto Market Analysis',
          Creator: 'Finotaur Crypto PDF v2.0',
        },
      });

      registerFonts(doc);

      const chunks = [];
      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(chunks);
        console.log(`[Crypto PDF] Complete: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      let currentPageNumber = 0;
      
      const addContentPage = () => {
        doc.addPage();
        currentPageNumber++;
        drawPageHeader(doc, reportDate, logoData);
        return PAGE.contentTop;
      };

      const drawFooter = (pageNum) => {
        doc.strokeColor(COLORS.veryLightGray)
           .lineWidth(0.3)
           .moveTo(PAGE.marginLeft, PAGE.footerY - 8)
           .lineTo(PAGE.width - PAGE.marginRight, PAGE.footerY - 8)
           .stroke();

        doc.font(FONTS.body).fontSize(SIZES.footer).fillColor(COLORS.lightGray);
        doc.text(COPYRIGHT, PAGE.marginLeft, PAGE.footerY, { lineBreak: false });
        doc.text('For educational purposes only. Not investment advice.', 
          PAGE.width / 2 - 100, PAGE.footerY, { width: 200, align: 'center', lineBreak: false });
        doc.text(`${pageNum}`, PAGE.width - PAGE.marginRight - 20, PAGE.footerY, { 
          width: 20, align: 'right', lineBreak: false 
        });
      };

      // ========== COVER PAGE ==========
      doc.addPage();
      drawCoverPage(doc, reportDate, logoData);

      // ========== CONTENT PAGES ==========
      let currentY = addContentPage();
      let contentPageNum = 1;

      // Add TOP SECRET disclaimer
      currentY = addTopSecretDisclaimer(doc, currentY);

      // Parse and render markdown
      const sections = parseMarkdownSections(reportMarkdown);
      
      // Track if charts have been inserted
      const chartsInserted = {
        // PM-Grade Decision Charts (Priority)
        marketRegimeGauge: false,
        volatilityCompression: false,
        stablecoinSupplyPM: false,
        etfFlows: false,
        sectorHeatmap: false,
        // Legacy charts
        regimeGauge: false,
        priceFundingDivergence: false,
        liquidityLeverage: false,
        btcEthCorrelation: false,
      };
      
      for (let i = 0; i < sections.length; i++) {
        const section = sections[i];
        
        // Calculate estimated section height
        const estimatedHeight = estimateSectionHeight(section);
        
        // Force new page ONLY for main chapters (page type) - except the first one
        if (section.type === 'page' && i > 0) {
          drawFooter(contentPageNum);
          currentY = addContentPage();
          contentPageNum++;
        }
        // For regular sections: only break if we really can't fit the content
        // Use a smaller threshold (30px) to maximize page usage
        else if (currentY + estimatedHeight > PAGE.safeBottom && i > 0) {
          // Only break if there's actually significant content to move
          if (estimatedHeight > 100) {
            drawFooter(contentPageNum);
            currentY = addContentPage();
            contentPageNum++;
          }
        }

        const newPageCallback = () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        };

        currentY = drawSection(doc, section, currentY, newPageCallback, charts, chartsInserted);
        currentY += 15; // Reduced from 20 to 15 for tighter layout
        
        // Note: Chart insertion is now handled INSIDE drawSection after specific subsections
        // This provides more precise placement (e.g., after "The Bottom Line" vs after entire section)
      }

      // ========== FALLBACK: Insert any remaining charts at end ==========
      // NOTE: Most charts should be inserted by section-level triggers above
      // This fallback only handles charts that truly weren't placed anywhere
      if (charts?.keySignal) {
        const newPageCallback = () => {
          drawFooter(contentPageNum);
          const newY = addContentPage();
          contentPageNum++;
          return newY;
        };
        
        // NOTE: regimeGauge is handled by section-level insertion, don't duplicate here
        
        if (!chartsInserted.priceFundingDivergence && charts.keySignal.priceFundingDivergence?.success) {
          console.log('[Crypto PDF] ⚠️ FALLBACK: Inserting Price/Funding chart at end (subsection not found)');
          currentY = drawChart(doc, charts.keySignal.priceFundingDivergence, currentY, CHART_CAPTIONS.priceFundingDivergence, newPageCallback);
          chartsInserted.priceFundingDivergence = true;
        }
        
        if (!chartsInserted.liquidityLeverage && charts.keySignal.liquidityLeverage?.success) {
          console.log('[Crypto PDF] ⚠️ FALLBACK: Inserting Liquidity/Leverage chart at end (subsection not found)');
          currentY = drawChart(doc, charts.keySignal.liquidityLeverage, currentY, CHART_CAPTIONS.liquidityLeverage, newPageCallback);
          chartsInserted.liquidityLeverage = true;
        }
        
        if (!chartsInserted.btcEthCorrelation && charts.keySignal.btcEthCorrelation?.success) {
          console.log('[Crypto PDF] ⚠️ FALLBACK: Inserting BTC/ETH Correlation chart at end (subsection not found)');
          currentY = drawChart(doc, charts.keySignal.btcEthCorrelation, currentY, CHART_CAPTIONS.btcEthCorrelation, newPageCallback);
          chartsInserted.btcEthCorrelation = true;
        }
        
        // Log final chart insertion status
        console.log('[Crypto PDF] Chart insertion summary:', chartsInserted);
      }

      drawFooter(contentPageNum);
      
      // ★★★ DISCLAIMER PAGE - Last page (ISM style) ★★★
      generateDisclaimerSection(doc, logoData);
      
      console.log(`[Crypto PDF] Generated: 1 cover + ${contentPageNum} content pages + disclaimer`);
      doc.end();

    } catch (error) {
      console.error('[Crypto PDF] Error:', error);
      reject(error);
    }
  });
}

// ============ COVER PAGE ============
function drawCoverPage(doc, reportDate, logoData) {
  const centerX = PAGE.width / 2;

  // Black background
  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  
  // Gold top border
  doc.rect(0, 0, PAGE.width, 4).fill(COLORS.gold);
  
  // TOP SECRET banner
  const bannerY = 80;
  doc.rect(0, bannerY, PAGE.width, 40).fill('#1A1A1A');
  doc.strokeColor(COLORS.gold).lineWidth(1)
     .moveTo(0, bannerY).lineTo(PAGE.width, bannerY).stroke()
     .moveTo(0, bannerY + 40).lineTo(PAGE.width, bannerY + 40).stroke();
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(20)
     .text('TOP SECRET', 0, bannerY + 12, { align: 'center', width: PAGE.width });

  // Logo - PRIORITIZE LOADING FROM FILE
  const logoY = 160;
  let logoLoaded = false;
  
  if (logoData) {
    try {
      if (Buffer.isBuffer(logoData)) {
        // Buffer provided
        doc.image(logoData, centerX - 100, logoY, { width: 200 });
        logoLoaded = true;
        console.log('[Crypto PDF] Logo loaded from buffer');
      } else if (typeof logoData === 'string') {
        if (logoData.startsWith('data:image')) {
          // Base64 data URL
          const base64Data = logoData.split(',')[1];
          const buffer = Buffer.from(base64Data, 'base64');
          doc.image(buffer, centerX - 100, logoY, { width: 200 });
          logoLoaded = true;
          console.log('[Crypto PDF] Logo loaded from base64');
        } else if (fs.existsSync(logoData)) {
          // File path
          doc.image(logoData, centerX - 100, logoY, { width: 200 });
          logoLoaded = true;
          console.log(`[Crypto PDF] Logo loaded from file: ${logoData}`);
        }
      }
    } catch (e) {
      console.log('[Crypto PDF] Logo load failed:', e.message);
    }
  }
  
  // Fallback text if no logo
  if (!logoLoaded) {
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(32)
       .text('FINOTAUR', 0, logoY + 80, { align: 'center', width: PAGE.width });
    console.log('[Crypto PDF] Using text fallback for logo');
  }

  // Title section
  const titleY = logoY + 260;
  
  doc.fillColor(COLORS.white)
     .font(FONTS.title)
     .fontSize(SIZES.coverTitle)
     .text('CRYPTO INTELLIGENCE', 0, titleY, { align: 'center', width: PAGE.width });

  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.coverSubtitle)
     .text('MARKET ANALYSIS REPORT', 0, titleY + 35, { align: 'center', width: PAGE.width });

  // Gold divider
  doc.strokeColor(COLORS.gold)
     .lineWidth(2)
     .moveTo(centerX - 140, titleY + 70)
     .lineTo(centerX + 140, titleY + 70)
     .stroke();

  // Date
  doc.fillColor(COLORS.white)
     .font(FONTS.body)
     .fontSize(SIZES.coverDate)
     .text(reportDate, 0, titleY + 90, { align: 'center', width: PAGE.width });

  // Tagline - Updated for PM-Grade
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.coverTagline)
     .text('PM-Grade Decision Framework', 0, titleY + 120, { 
       align: 'center', width: PAGE.width 
     });

  // Gold bottom border
  doc.rect(0, PAGE.height - 4, PAGE.width, 4).fill(COLORS.gold);

  // Copyright
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.footer)
     .text(COPYRIGHT, 0, PAGE.height - 25, { align: 'center', width: PAGE.width });
}

// ============ PAGE HEADER ============
function drawPageHeader(doc, reportDate, logoData) {
  // Logo in header (small version)
  let logoWidth = 60;
  let logoHeight = 20;
  
  if (logoData) {
    try {
      if (typeof logoData === 'string' && fs.existsSync(logoData)) {
        doc.image(logoData, PAGE.marginLeft, 25, { height: 20 });
      } else if (Buffer.isBuffer(logoData)) {
        doc.image(logoData, PAGE.marginLeft, 25, { height: 20 });
      } else {
        // Fallback to text
        doc.fillColor(COLORS.gold)
           .font(FONTS.bold)
           .fontSize(10)
           .text('FINOTAUR', PAGE.marginLeft, 30, { lineBreak: false });
      }
    } catch (e) {
      // Fallback to text
      doc.fillColor(COLORS.gold)
         .font(FONTS.bold)
         .fontSize(10)
         .text('FINOTAUR', PAGE.marginLeft, 30, { lineBreak: false });
    }
  } else {
    // Text fallback
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(10)
       .text('FINOTAUR', PAGE.marginLeft, 30, { lineBreak: false });
  }
  
  // TOP SECRET tag
  doc.fillColor(COLORS.gold)
     .fontSize(8)
     .text('TOP SECRET', PAGE.marginLeft + 70, 31, { lineBreak: false });

  // Date
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.small)
     .text(reportDate, PAGE.width - PAGE.marginRight - 150, 30, { 
       width: 150, align: 'right', lineBreak: false 
     });

  // Header line
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .moveTo(PAGE.marginLeft, 50)
     .lineTo(PAGE.width - PAGE.marginRight, 50)
     .stroke();
}

// ============ TOP SECRET DISCLAIMER ============
function addTopSecretDisclaimer(doc, y) {
  doc.fillColor('#FEF2F2')
     .rect(PAGE.marginLeft, y, PAGE.contentWidth, 35)
     .fill();
  
  doc.strokeColor('#DC2626')
     .lineWidth(1)
     .rect(PAGE.marginLeft, y, PAGE.contentWidth, 35)
     .stroke();
  
  doc.fillColor('#991B1B')
     .font(FONTS.bold)
     .fontSize(9)
     .text('TOP SECRET — FOR AUTHORIZED PERSONNEL ONLY', 
           PAGE.marginLeft, y + 8, { align: 'center', width: PAGE.contentWidth });
  
  doc.fillColor('#7F1D1D')
     .font(FONTS.body)
     .fontSize(8)
     .text('This document contains proprietary analysis. Do not distribute.', 
           PAGE.marginLeft, y + 21, { align: 'center', width: PAGE.contentWidth });
  
  return y + 50;
}

// ============ MARKDOWN PARSER ============
function parseMarkdownSections(markdown) {
  const lines = markdown.split('\n');
  const sections = [];
  let currentSection = null;
  
for (const line of lines) {
    // Skip metadata lines
    if (isMetadataLine(line)) continue;
    
    // Skip separator lines
    if (line.trim() === '---') continue;
    
    // Main chapter header (# ...) - both "# Page X:" and "# Title" formats
    // This includes: "# Market Regime", "# Executive Summary", "# Page 1: ...", etc.
    if (line.match(/^# /) && !line.match(/^## /)) {
      if (currentSection) sections.push(currentSection);
      let title = cleanTitle(line.replace(/^#\s*/, ''));
      // Remove "Page X:" prefix if present
      title = title.replace(/^Page \d+:\s*/, '');
      currentSection = {
        type: 'page',
        title: title,
        content: [],
        forceNewPage: true  // Flag to force new page
      };
    }
    // Section header (## ...)
    else if (line.startsWith('## ')) {
      if (currentSection) sections.push(currentSection);
      currentSection = {
        type: 'section',
        title: cleanTitle(line.replace(/^##\s*/, '')),
        content: []
      };
    }
    // Subsection header (### ...)
    else if (line.startsWith('### ')) {
      if (currentSection) {
        currentSection.content.push({
          type: 'subsection',
          text: cleanTitle(line.replace(/^###\s*/, ''))
        });
      }
    }
    // Table
    else if (line.startsWith('|') && line.includes('|')) {
      if (currentSection) {
        // Check if this is a header row or separator
        if (line.match(/^\|[\s-:|]+\|$/)) {
          // Skip separator rows
          continue;
        }
        currentSection.content.push({
          type: 'table_row',
          cells: line.split('|').filter(c => c.trim()).map(c => cleanText(c.trim()))
        });
      }
    }
    // Bullet point
    else if (line.match(/^[-*]\s/)) {
      if (currentSection) {
        currentSection.content.push({
          type: 'bullet',
          text: cleanText(line.replace(/^[-*]\s*/, ''))
        });
      }
    }
    // Regular paragraph
    else if (line.trim()) {
      if (currentSection) {
        currentSection.content.push({
          type: 'paragraph',
          text: cleanText(line)
        });
      }
    }
  }
  
  if (currentSection) sections.push(currentSection);
  
  return sections;
}

// ============ SECTION RENDERER ============
function drawSection(doc, section, y, newPageCallback, charts = null, chartsInserted = null) {
  // Section title with orphan prevention
  if (section.title) {
    const titleColor = section.type === 'page' ? COLORS.gold : COLORS.darkText;
    // Make chapter titles significantly bigger
    const titleSize = section.type === 'page' ? SIZES.sectionTitle + 4 : SIZES.subSection;
    const titleHeight = section.type === 'page' ? 50 : 30;
    
    // ★★★ IRON RULE: Check if title can stay with first paragraph ★★★
    const upcomingContentHeight = estimateUpcomingContentHeight(section.content, 0);
    if (shouldBreakBeforeTitle(y, titleHeight, upcomingContentHeight)) {
      console.log(`[Crypto PDF] 📄 Moving section "${section.title}" to new page (orphan prevention)`);
      y = newPageCallback();
    }
    
    doc.fillColor(titleColor)
       .font(FONTS.bold)
       .fontSize(titleSize)
       .text(section.title, PAGE.marginLeft, y, { width: PAGE.contentWidth });
    
    y += doc.heightOfString(section.title, { width: PAGE.contentWidth }) + 10;
    
    // Underline for page headers (chapter titles)
    if (section.type === 'page') {
      doc.strokeColor(COLORS.gold)
         .lineWidth(2)
         .moveTo(PAGE.marginLeft, y - 3)
         .lineTo(PAGE.marginLeft + 150, y - 3)
         .stroke();
      y += 15;
    }
  }
  
  // Content
  let tableBuffer = [];
  
  for (const item of section.content) {
    // Check for page break
    if (needsPageBreak(y, 60)) {
      // Flush table buffer first
      if (tableBuffer.length > 0) {
        y = drawTable(doc, tableBuffer, y);
        tableBuffer = [];
      }
      y = newPageCallback();
    }
    
if (item.type === 'subsection') {
      // Flush table buffer
      if (tableBuffer.length > 0) {
        y = drawTable(doc, tableBuffer, y);
        tableBuffer = [];
        y += 8;
      }
      
      // ★★★ ORPHAN TITLE PREVENTION - IRON RULE (v3.2) ★★★
      // Check if there's enough space for title + minimum content
      const titleHeight = 40; // Title + underline + spacing
      const upcomingContentHeight = estimateUpcomingContentHeight(section.content, section.content.indexOf(item) + 1);
      
      // Use the stricter shouldBreakBeforeTitle function
      if (shouldBreakBeforeTitle(y, titleHeight, upcomingContentHeight)) {
        console.log(`[Crypto PDF] 📄 Moving "${item.text}" to new page (orphan prevention - iron rule)`);
        y = newPageCallback();
      }
      
      // רשימת כל הכותרות שצריכות קו תחתון שחור
const BLACK_UNDERLINE_SECTIONS = [
        '1.1 The Regime Call',
        '1.2 What This Regime Historically Means',
        '1.3 What Would Flip This Regime',
        'The Three Forces Driving This View',
        'Key Takeaways',
        'BTC/ETH Positioning at a Glance',
        'Whale Activity Summary',
        'What Would Prove Us Wrong',
        'US Market Dashboard',  // Updated from "Market Dashboard"
        '3.1 Positioning Reality',
        '3.2 Funding + OI Fragility',
        '3.2 Funding + OI = Fragility',
        '3.3 Where Pressure Builds, Behavior Changes',
        '4.1 Liquidity Conditions',
        '4.2 What We Can See vs What We Can\'t',
        '4.3 The Reality Check',
        '5.1 Whale Signal Quality',
        '5.2 What Whales Are NOT Doing',
        '5.3 Common Whale Traps',
        '6.1 Signal vs Noise',
        '6.2 Headlines This Week',
        '6.3 Technology & Infrastructure',
        'Base Case',
        'Upside Case',
        'Downside Case',
        'Risk Checklist',
        'Recommended Allocation',
        'Structure',
        'Funding & Positioning',
        'Liquidity',
        'What tends to work',
        'What usually fails',
        'Who gets hurt, who benefits',
      ];
      
      // בדיקה אם הכותרת צריכה קו תחתון שחור
      const needsBlackUnderline = BLACK_UNDERLINE_SECTIONS.some(section => 
        item.text.includes(section) || section.includes(item.text)
      ) || /^\d+\.\d+/.test(item.text);
      
      // סטיילינג
      const textColor = needsBlackUnderline ? COLORS.darkText : COLORS.mediumGray;
      const fontSize = SIZES.body + 1;
      
      doc.fillColor(textColor)
         .font(FONTS.bold)
         .fontSize(fontSize)
         .text(item.text, PAGE.marginLeft, y, { width: PAGE.contentWidth });
      
      y += doc.heightOfString(item.text, { width: PAGE.contentWidth }) + 4;
      
      // קו תחתון שחור לכותרות הרלוונטיות
      if (needsBlackUnderline) {
        const lineLength = Math.min(200, doc.widthOfString(item.text) + 20);
        doc.strokeColor(COLORS.black)
           .lineWidth(1)
           .moveTo(PAGE.marginLeft, y)
           .lineTo(PAGE.marginLeft + lineLength, y)
           .stroke();
        y += 8;
      } else {
        y += 4;
      }
      
      // ========== CHART INSERTION AFTER SPECIFIC SUBSECTIONS ==========
      // PM-Grade Charts take priority over legacy charts
      if (chartsInserted) {
        const subsectionTitle = item.text.toLowerCase();
        
        // ==========================================
        // PM-GRADE CHART 1: Market Regime Gauge
        // After "The Bottom Line"
        // ==========================================
        if (!chartsInserted.marketRegimeGauge && 
            charts?.pmGrade?.marketRegimeGauge?.success &&
            subsectionTitle.includes('bottom line')) {
          console.log('[Crypto PDF] 📊 PM-Grade: Market Regime Gauge after "The Bottom Line"');
          y += 15;
          y = drawChart(doc, charts.pmGrade.marketRegimeGauge, y, CHART_CAPTIONS.marketRegimeGauge, newPageCallback);
          chartsInserted.marketRegimeGauge = true;
        }
        // Fallback to legacy regime gauge
        else if (!chartsInserted.regimeGauge && 
                 !chartsInserted.marketRegimeGauge &&
                 charts?.keySignal?.regimeGauge?.success &&
                 subsectionTitle.includes('bottom line')) {
          console.log('[Crypto PDF] 📊 Legacy: Regime Gauge after "The Bottom Line"');
          y += 15;
          y = drawChart(doc, charts.keySignal.regimeGauge, y, CHART_CAPTIONS.regimeGauge, newPageCallback);
          chartsInserted.regimeGauge = true;
        }
        
        // ==========================================
        // PM-GRADE CHART 2: Volatility Compression
        // After "Volatility Regime"
        // ==========================================
        if (!chartsInserted.volatilityCompression && 
            charts?.pmGrade?.volatilityCompression?.success &&
            subsectionTitle.includes('volatility regime')) {
          console.log('[Crypto PDF] 📊 PM-Grade: Volatility Compression after "Volatility Regime"');
          y += 15;
          y = drawChart(doc, charts.pmGrade.volatilityCompression, y, CHART_CAPTIONS.volatilityCompression, newPageCallback);
          chartsInserted.volatilityCompression = true;
        }
        
        // ==========================================
        // PM-GRADE CHARTS 3 & 4: Stablecoin Supply + ETF Flows
        // v3.2: Appears AFTER the ETF Flows subsection/table
        // Trigger: "etf flows" or "etf" subsection title
        // ==========================================
        if (!chartsInserted.stablecoinSupplyPM && 
            !chartsInserted.etfFlows &&
            charts?.pmGrade?.stablecoinSupply?.success &&
            charts?.pmGrade?.etfFlows?.success &&
            (subsectionTitle.includes('etf flow') || subsectionTitle.includes('etf 14d') || 
             (subsectionTitle.includes('etf') && !subsectionTitle.includes('what')))) {
          console.log('[Crypto PDF] 📊 PM-Grade: Stablecoin + ETF Flows SIDE BY SIDE after ETF section');
          y += 15;
          
          // Use enhanced drawChartsSideBySide - NO extra title/intro since text is already above
          y = drawChartsSideBySide(
            doc, 
            charts.pmGrade.stablecoinSupply, 
            charts.pmGrade.etfFlows, 
            y, 
            newPageCallback,
            {
              title: null, // No title - text already above
              introText: null, // No intro - text already above
            }
          );
          
          chartsInserted.stablecoinSupplyPM = true;
          chartsInserted.etfFlows = true;
        }
        // Fallback: Single stablecoin chart if ETF not available
        else if (!chartsInserted.stablecoinSupplyPM && 
            charts?.pmGrade?.stablecoinSupply?.success &&
            subsectionTitle.includes('stablecoin supply')) {
          console.log('[Crypto PDF] 📊 PM-Grade: Stablecoin Supply (single)');
          y += 15;
          y = drawChart(doc, charts.pmGrade.stablecoinSupply, y, CHART_CAPTIONS.stablecoinSupply, newPageCallback);
          chartsInserted.stablecoinSupplyPM = true;
        }
        // Fallback to legacy liquidity/leverage
        else if (!chartsInserted.liquidityLeverage && 
                 !chartsInserted.stablecoinSupplyPM &&
                 charts?.keySignal?.liquidityLeverage?.success &&
                 subsectionTitle.includes('stablecoin supply')) {
          console.log('[Crypto PDF] 📊 Legacy: Liquidity/Leverage after "Stablecoin Supply"');
          y += 15;
          y = drawChart(doc, charts.keySignal.liquidityLeverage, y, CHART_CAPTIONS.liquidityLeverage, newPageCallback);
          chartsInserted.liquidityLeverage = true;
        }
        
        // ==========================================
        // PM-GRADE CHART 4: ETF Net Flows (standalone fallback)
        // After "ETF Flows" or "Institutional Flows"
        // ==========================================
        if (!chartsInserted.etfFlows && 
            charts?.pmGrade?.etfFlows?.success &&
            (subsectionTitle.includes('etf') || subsectionTitle.includes('institutional flows'))) {
          console.log('[Crypto PDF] 📊 PM-Grade: ETF Flows');
          y += 15;
          y = drawChart(doc, charts.pmGrade.etfFlows, y, CHART_CAPTIONS.etfFlows, newPageCallback);
          chartsInserted.etfFlows = true;
        }
        
        // ==========================================
        // LEGACY: Price vs Funding Divergence
        // After "Key Signal"
        // ==========================================
        if (!chartsInserted.priceFundingDivergence && 
            charts?.keySignal?.priceFundingDivergence?.success &&
            subsectionTitle.includes('key signal')) {
          console.log('[Crypto PDF] 📊 Legacy: Price/Funding after "Key Signal"');
          y += 15;
          y = drawChart(doc, charts.keySignal.priceFundingDivergence, y, CHART_CAPTIONS.priceFundingDivergence, newPageCallback);
          chartsInserted.priceFundingDivergence = true;
        }
        
        // ==========================================
        // LEGACY: BTC/ETH Price Action
        // After "Bitcoin and Ethereum"
        // ==========================================
        if (!chartsInserted.btcEthCorrelation && 
            charts?.keySignal?.btcEthCorrelation?.success &&
            subsectionTitle.includes('bitcoin and ethereum')) {
          console.log('[Crypto PDF] 📊 Legacy: BTC/ETH after "Bitcoin and Ethereum"');
          y += 15;
          y = drawChart(doc, charts.keySignal.btcEthCorrelation, y, CHART_CAPTIONS.btcEthCorrelation, newPageCallback);
          chartsInserted.btcEthCorrelation = true;
        }
      }
    }
    else if (item.type === 'table_row') {
      tableBuffer.push(item.cells);
      
      // Track if this might be an ETF table (for later chart insertion)
      const rowText = item.cells.join(' ').toLowerCase();
      if (rowText.includes('etf') || rowText.includes('outflow') || rowText.includes('inflow')) {
        tableBuffer.isETFTable = true;
      }
    }
    else if (item.type === 'bullet') {
      // Flush table buffer
      if (tableBuffer.length > 0) {
        const wasETFTable = tableBuffer.isETFTable;
        y = drawTable(doc, tableBuffer, y);
        tableBuffer = [];
        y += 5;
        
        // ★★★ INSERT SIDE-BY-SIDE CHARTS AFTER ETF TABLE ★★★
        if (wasETFTable && chartsInserted && 
            !chartsInserted.stablecoinSupplyPM && 
            !chartsInserted.etfFlows &&
            charts?.pmGrade?.stablecoinSupply?.success &&
            charts?.pmGrade?.etfFlows?.success) {
          console.log('[Crypto PDF] 📊 PM-Grade: Stablecoin + ETF Flows SIDE BY SIDE after ETF table');
          y += 15;
          y = drawChartsSideBySide(
            doc, 
            charts.pmGrade.stablecoinSupply, 
            charts.pmGrade.etfFlows, 
            y, 
            newPageCallback,
            { title: null, introText: null }
          );
          chartsInserted.stablecoinSupplyPM = true;
          chartsInserted.etfFlows = true;
        }
      }
      
      // Draw bullet
      doc.fillColor(COLORS.gold)
         .font(FONTS.body)
         .fontSize(SIZES.body)
         .text('•', PAGE.marginLeft, y, { lineBreak: false });
      
      doc.fillColor(COLORS.darkText)
         .text(item.text, PAGE.marginLeft + 15, y, { width: PAGE.contentWidth - 15 });
      
      y += doc.heightOfString(item.text, { width: PAGE.contentWidth - 15 }) + 5;
    }
    else if (item.type === 'paragraph') {
      // Flush table buffer
      if (tableBuffer.length > 0) {
        const wasETFTable = tableBuffer.isETFTable;
        y = drawTable(doc, tableBuffer, y);
        tableBuffer = [];
        y += 5;
        
        // ★★★ INSERT SIDE-BY-SIDE CHARTS AFTER ETF TABLE ★★★
        if (wasETFTable && chartsInserted && 
            !chartsInserted.stablecoinSupplyPM && 
            !chartsInserted.etfFlows &&
            charts?.pmGrade?.stablecoinSupply?.success &&
            charts?.pmGrade?.etfFlows?.success) {
          console.log('[Crypto PDF] 📊 PM-Grade: Stablecoin + ETF Flows SIDE BY SIDE after ETF table (paragraph flush)');
          y += 15;
          y = drawChartsSideBySide(
            doc, 
            charts.pmGrade.stablecoinSupply, 
            charts.pmGrade.etfFlows, 
            y, 
            newPageCallback,
            { title: null, introText: null }
          );
          chartsInserted.stablecoinSupplyPM = true;
          chartsInserted.etfFlows = true;
        }
      }
      
      // Check for special formatting
      if (item.text.startsWith('**') && item.text.endsWith('**')) {
        doc.fillColor(COLORS.darkText)
           .font(FONTS.bold)
           .fontSize(SIZES.body);
        item.text = item.text.replace(/\*\*/g, '');
      } else {
        doc.fillColor(COLORS.darkText)
           .font(FONTS.body)
           .fontSize(SIZES.body);
      }
      
      // Handle data tags
      y = renderLineWithTags(doc, item.text, y);
      
      // ========== CHART INSERTION AFTER SPECIFIC PARAGRAPH TITLES ==========
      // PM-Grade charts take priority, then fallback to legacy charts
      if (chartsInserted) {
        const paragraphText = item.text.toLowerCase();
        
        // PM-GRADE: Market Regime Gauge - After "The Bottom Line" paragraph
        if (!chartsInserted.marketRegimeGauge && 
            charts?.pmGrade?.marketRegimeGauge?.success &&
            (paragraphText === 'the bottom line' || paragraphText.includes('bottom line:'))) {
          console.log('[Crypto PDF] 📊 PM-Grade: Market Regime Gauge (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.pmGrade.marketRegimeGauge, y, CHART_CAPTIONS.marketRegimeGauge, newPageCallback);
          chartsInserted.marketRegimeGauge = true;
        }
        // Legacy fallback
        else if (!chartsInserted.regimeGauge && 
                 !chartsInserted.marketRegimeGauge &&
                 charts?.keySignal?.regimeGauge?.success &&
                 (paragraphText === 'the bottom line' || paragraphText.includes('bottom line:'))) {
          console.log('[Crypto PDF] 📊 Legacy: Regime Gauge (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.keySignal.regimeGauge, y, CHART_CAPTIONS.regimeGauge, newPageCallback);
          chartsInserted.regimeGauge = true;
        }
        
        // PM-GRADE: Volatility Compression - After "Volatility" paragraph
        if (!chartsInserted.volatilityCompression && 
            charts?.pmGrade?.volatilityCompression?.success &&
            paragraphText.includes('volatility regime')) {
          console.log('[Crypto PDF] 📊 PM-Grade: Volatility Compression (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.pmGrade.volatilityCompression, y, CHART_CAPTIONS.volatilityCompression, newPageCallback);
          chartsInserted.volatilityCompression = true;
        }
        
        // PM-GRADE: Stablecoin Supply - After "Stablecoin Supply" paragraph
        if (!chartsInserted.stablecoinSupplyPM && 
            charts?.pmGrade?.stablecoinSupply?.success &&
            (paragraphText === 'stablecoin supply' || paragraphText.includes('stablecoin supply:'))) {
          console.log('[Crypto PDF] 📊 PM-Grade: Stablecoin Supply (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.pmGrade.stablecoinSupply, y, CHART_CAPTIONS.stablecoinSupply, newPageCallback);
          chartsInserted.stablecoinSupplyPM = true;
        }
        // Legacy fallback
        else if (!chartsInserted.liquidityLeverage && 
                 !chartsInserted.stablecoinSupplyPM &&
                 charts?.keySignal?.liquidityLeverage?.success &&
                 (paragraphText === 'stablecoin supply' || paragraphText.includes('stablecoin supply:'))) {
          console.log('[Crypto PDF] 📊 Legacy: Liquidity/Leverage (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.keySignal.liquidityLeverage, y, CHART_CAPTIONS.liquidityLeverage, newPageCallback);
          chartsInserted.liquidityLeverage = true;
        }
        
        // PM-GRADE: ETF Flows - After "ETF" paragraph
        if (!chartsInserted.etfFlows && 
            charts?.pmGrade?.etfFlows?.success &&
            paragraphText.includes('etf')) {
          console.log('[Crypto PDF] 📊 PM-Grade: ETF Flows (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.pmGrade.etfFlows, y, CHART_CAPTIONS.etfFlows, newPageCallback);
          chartsInserted.etfFlows = true;
        }
        
        // Legacy: Price vs Funding
        if (!chartsInserted.priceFundingDivergence && 
            charts?.keySignal?.priceFundingDivergence?.success &&
            (paragraphText.includes('key signal') && paragraphText.includes('positioning'))) {
          console.log('[Crypto PDF] 📊 Legacy: Price/Funding (paragraph fallback)');
          y += 10;
          y = drawChart(doc, charts.keySignal.priceFundingDivergence, y, CHART_CAPTIONS.priceFundingDivergence, newPageCallback);
          chartsInserted.priceFundingDivergence = true;
        }
      }
    }
  }
  
  // Flush any remaining table buffer
  if (tableBuffer.length > 0) {
    y = drawTable(doc, tableBuffer, y);
  }
  
  // ========== SECTION-LEVEL CHART INSERTION ==========
  // Insert PM-Grade charts at section level (for Sector Rotation)
  if (chartsInserted && section.title) {
    const sectionTitle = section.title.toLowerCase();
    
    // PM-GRADE CHART 5: Sector Heatmap - In "Sector Rotation" section
    if (!chartsInserted.sectorHeatmap && 
        charts?.pmGrade?.sectorHeatmap?.success &&
        sectionTitle.includes('sector')) {
      console.log('[Crypto PDF] 📊 PM-Grade: Sector Heatmap in section:', section.title);
      y += 15;
      y = drawChart(doc, charts.pmGrade.sectorHeatmap, y, CHART_CAPTIONS.sectorHeatmap, newPageCallback);
      chartsInserted.sectorHeatmap = true;
    }
    
    // FALLBACK: Insert any remaining PM-Grade charts at end of relevant sections
    
    // Market Regime Gauge - fallback in Executive Brief
    if (!chartsInserted.marketRegimeGauge && 
        !chartsInserted.regimeGauge &&
        charts?.pmGrade?.marketRegimeGauge?.success &&
        sectionTitle.includes('executive')) {
      console.log('[Crypto PDF] 📊 PM-Grade FALLBACK: Market Regime Gauge in Executive section');
      y += 15;
      y = drawChart(doc, charts.pmGrade.marketRegimeGauge, y, CHART_CAPTIONS.marketRegimeGauge, newPageCallback);
      chartsInserted.marketRegimeGauge = true;
    }
    
    // Volatility Compression - fallback in Liquidity & Risk section
    if (!chartsInserted.volatilityCompression && 
        charts?.pmGrade?.volatilityCompression?.success &&
        (sectionTitle.includes('liquidity') || sectionTitle.includes('risk'))) {
      console.log('[Crypto PDF] 📊 PM-Grade FALLBACK: Volatility Compression in Liquidity section');
      y += 15;
      y = drawChart(doc, charts.pmGrade.volatilityCompression, y, CHART_CAPTIONS.volatilityCompression, newPageCallback);
      chartsInserted.volatilityCompression = true;
    }
    
    // ==========================================
    // PM-GRADE CHARTS 3 & 4: Stablecoin + ETF SIDE BY SIDE
    // Insert AFTER "Liquidity Backdrop" section (which is the last subsection of Flows & Supply)
    // This ensures charts appear AFTER all the text content
    // IMPORTANT: Must match EXACTLY "liquidity backdrop" to avoid matching "Liquidity & Risk"
    // ==========================================
    if (!chartsInserted.stablecoinSupplyPM && 
        !chartsInserted.etfFlows &&
        charts?.pmGrade?.stablecoinSupply?.success &&
        charts?.pmGrade?.etfFlows?.success &&
        sectionTitle.includes('liquidity backdrop')) {
      console.log('[Crypto PDF] 📊 PM-Grade: Stablecoin + ETF Flows SIDE BY SIDE after Liquidity Backdrop');
      y += 15;
      y = drawChartsSideBySide(
        doc, 
        charts.pmGrade.stablecoinSupply, 
        charts.pmGrade.etfFlows, 
        y, 
        newPageCallback,
        { title: null, introText: null }
      );
      chartsInserted.stablecoinSupplyPM = true;
      chartsInserted.etfFlows = true;
    }
    // Fallback: Single stablecoin chart if ETF not available
    else if (!chartsInserted.stablecoinSupplyPM && 
        charts?.pmGrade?.stablecoinSupply?.success &&
        sectionTitle.includes('liquidity backdrop')) {
      console.log('[Crypto PDF] 📊 PM-Grade FALLBACK: Stablecoin Supply (single) after Liquidity Backdrop');
      y += 15;
      y = drawChart(doc, charts.pmGrade.stablecoinSupply, y, CHART_CAPTIONS.stablecoinSupply, newPageCallback);
      chartsInserted.stablecoinSupplyPM = true;
    }
    // Fallback: Single ETF chart if Stablecoin not available
    else if (!chartsInserted.etfFlows && 
        charts?.pmGrade?.etfFlows?.success &&
        sectionTitle.includes('liquidity backdrop')) {
      console.log('[Crypto PDF] 📊 PM-Grade FALLBACK: ETF Flows (single) after Liquidity Backdrop');
      y += 15;
      y = drawChart(doc, charts.pmGrade.etfFlows, y, CHART_CAPTIONS.etfFlows, newPageCallback);
      chartsInserted.etfFlows = true;
    }
    
    // ========== LEGACY CHART FALLBACKS ==========
    if (!chartsInserted.regimeGauge && 
        !chartsInserted.marketRegimeGauge &&
        charts?.keySignal?.regimeGauge?.success &&
        sectionTitle.includes('bottom line')) {
      console.log('[Crypto PDF] 📊 Legacy FALLBACK: Regime Gauge');
      y += 10;
      y = drawChart(doc, charts.keySignal.regimeGauge, y, CHART_CAPTIONS.regimeGauge, newPageCallback);
      chartsInserted.regimeGauge = true;
    }
    
    if (!chartsInserted.priceFundingDivergence && 
        charts?.keySignal?.priceFundingDivergence?.success &&
        sectionTitle.includes('key signal')) {
      console.log('[Crypto PDF] 📊 Legacy FALLBACK: Price/Funding');
      y += 10;
      y = drawChart(doc, charts.keySignal.priceFundingDivergence, y, CHART_CAPTIONS.priceFundingDivergence, newPageCallback);
      chartsInserted.priceFundingDivergence = true;
    }
    
    if (!chartsInserted.btcEthCorrelation && 
        charts?.keySignal?.btcEthCorrelation?.success &&
        sectionTitle.includes('bitcoin and ethereum')) {
      console.log('[Crypto PDF] 📊 Legacy FALLBACK: BTC/ETH');
      y += 10;
      y = drawChart(doc, charts.keySignal.btcEthCorrelation, y, CHART_CAPTIONS.btcEthCorrelation, newPageCallback);
      chartsInserted.btcEthCorrelation = true;
    }
    
    if (!chartsInserted.liquidityLeverage && 
        !chartsInserted.stablecoinSupplyPM &&
        charts?.keySignal?.liquidityLeverage?.success &&
        sectionTitle.includes('stablecoin supply')) {
      console.log('[Crypto PDF] 📊 Legacy FALLBACK: Liquidity/Leverage');
      y += 10;
      y = drawChart(doc, charts.keySignal.liquidityLeverage, y, CHART_CAPTIONS.liquidityLeverage, newPageCallback);
      chartsInserted.liquidityLeverage = true;
    }
  }
  
  return y;
}


// ============ RENDER LINE WITH DATA TAGS ============
function renderLineWithTags(doc, line, y) {
  let x = PAGE.marginLeft;
  let remaining = line;
  
  // Check each tag
  for (const [tag, style] of Object.entries(TAG_STYLES)) {
    if (remaining.includes(tag)) {
      const parts = remaining.split(tag);
      
      // Text before tag
      if (parts[0].trim()) {
        doc.fillColor(COLORS.darkText)
           .font(FONTS.body)
           .fontSize(SIZES.body)
           .text(parts[0].trim() + ' ', x, y, { continued: true });
        x += doc.widthOfString(parts[0].trim() + ' ');
      }
      
      // Tag box
      const tagWidth = doc.widthOfString(style.label) + 8;
      doc.fillColor(style.bg)
         .rect(x, y - 1, tagWidth, 12)
         .fill();
      
      doc.fillColor(style.text)
         .font(FONTS.bold)
         .fontSize(SIZES.tag)
         .text(style.label, x + 4, y + 1, { lineBreak: false });
      
      x += tagWidth + 4;
      remaining = parts.slice(1).join('');
    }
  }
  
  // Remaining text
  if (remaining.trim()) {
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(remaining.trim(), x, y, { width: PAGE.contentWidth - (x - PAGE.marginLeft) });
    
    const textHeight = doc.heightOfString(remaining.trim(), { 
      width: PAGE.contentWidth - (x - PAGE.marginLeft) 
    });
    return y + Math.max(textHeight, 14) + 4;
  }
  
  return y + 16;
}

// ============ TABLE RENDERER ============
function drawTable(doc, rows, y) {
  if (!rows || rows.length === 0) return y;
  if (!rows[0] || rows[0].length === 0) return y;
  
  const colCount = rows[0].length;
  
  // Optimized column widths for cleaner tables
  let colWidths = [];
  if (colCount === 1) {
    colWidths = [PAGE.contentWidth];
  } else if (colCount === 2) {
    // Two column tables: even split
    colWidths = [PAGE.contentWidth * 0.4, PAGE.contentWidth * 0.6];
  } else if (colCount === 3) {
    // Three column tables: first column wider
    colWidths = [PAGE.contentWidth * 0.35, PAGE.contentWidth * 0.35, PAGE.contentWidth * 0.30];
  } else if (colCount === 4) {
    // Four column tables: optimized for BTC/ETH table
    colWidths = [PAGE.contentWidth * 0.20, PAGE.contentWidth * 0.25, PAGE.contentWidth * 0.25, PAGE.contentWidth * 0.30];
  } else if (colCount === 5) {
    // Five column tables: Market Dashboard style
    colWidths = [PAGE.contentWidth * 0.20, PAGE.contentWidth * 0.18, PAGE.contentWidth * 0.17, PAGE.contentWidth * 0.17, PAGE.contentWidth * 0.28];
  } else if (colCount === 6) {
    // Six column tables
    colWidths = Array(6).fill(PAGE.contentWidth / 6);
  } else {
    // Fallback: equal width for any number of columns
    colWidths = Array(colCount).fill(PAGE.contentWidth / colCount);
  }
  
  // Safety check: ensure all widths are valid numbers
  colWidths = colWidths.map(w => {
    const width = parseFloat(w);
    return isNaN(width) || width <= 0 ? PAGE.contentWidth / colCount : width;
  });
  
  const cellPadding = 5;
  const headerHeight = 22;
  
  // Header row
  doc.fillColor('#F8F9FA')
     .rect(PAGE.marginLeft, y, PAGE.contentWidth, headerHeight)
     .fill();
  
  doc.strokeColor(COLORS.veryLightGray)
     .lineWidth(0.5)
     .rect(PAGE.marginLeft, y, PAGE.contentWidth, headerHeight)
     .stroke();
  
  let x = PAGE.marginLeft;
  rows[0].forEach((cell, i) => {
    const cellWidth = colWidths[i] || (PAGE.contentWidth / colCount);
    const textWidth = Math.max(cellWidth - cellPadding * 2, 10);
    const cellText = String(cell || '');
    
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text(cellText, x + cellPadding, y + 6, { 
         width: textWidth,
         align: i === 0 ? 'left' : 'center',
         lineBreak: false
       });
    x += cellWidth;
  });
  
  y += headerHeight;
  
  // Data rows
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    x = PAGE.marginLeft;
    
    // Calculate row height
    let maxCellHeight = 18;
    row.forEach((cell, i) => {
      const cellWidth = colWidths[i] || (PAGE.contentWidth / colCount);
      const textWidth = Math.max(cellWidth - cellPadding * 2, 10);
      const cellText = String(cell || '');
      const h = doc.heightOfString(cellText, { width: textWidth });
      if (h + 8 > maxCellHeight) maxCellHeight = h + 8;
    });
    
    // Alternating row background
    if (r % 2 === 0) {
      doc.fillColor('#FCFCFC')
         .rect(PAGE.marginLeft, y, PAGE.contentWidth, maxCellHeight)
         .fill();
    }
    
    // Draw cells
    row.forEach((cell, i) => {
      const cellText = String(cell || '');
      const cellWidth = colWidths[i] || (PAGE.contentWidth / colCount);
      const textWidth = Math.max(cellWidth - cellPadding * 2, 10);
      
      let textColor = COLORS.darkText;
      let fontStyle = FONTS.body;
      
      // Bold for important cells
      if (cellText.includes('RISK-ON') || cellText.includes('RISK-OFF') || cellText.includes('CROWDED')) {
        fontStyle = FONTS.bold;
      }
      
      // Color coding
      if (cellText.includes('BULLISH') || cellText.includes('PASS') || cellText === 'High') {
        textColor = COLORS.bullish;
      } else if (cellText.includes('BEARISH') || cellText.includes('FAIL') || cellText === 'Low') {
        textColor = COLORS.bearish;
      } else if (cellText.includes('NEUTRAL') || cellText === 'Medium') {
        textColor = COLORS.neutral;
      }
      
      doc.fillColor(textColor)
         .font(fontStyle)
         .fontSize(SIZES.small)
         .text(cellText, x + cellPadding, y + 4, { 
           width: textWidth,
           align: i === 0 ? 'left' : 'center',
           lineBreak: true
         });
      
      x += cellWidth;
    });
    
    // Bottom border
    doc.strokeColor('#E5E7EB')
       .lineWidth(0.3)
       .moveTo(PAGE.marginLeft, y + maxCellHeight)
       .lineTo(PAGE.marginLeft + PAGE.contentWidth, y + maxCellHeight)
       .stroke();
    
    y += maxCellHeight;
  }
  
  return y + 6;
}

// ============ DISCLAIMER WITH GOLD+BLACK FRAME (ISM STYLE) ============
function generateDisclaimerSection(doc, logoData) {
  doc.addPage();
  
  // BLACK BACKGROUND
  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  
  const frameMargin = 25;
  const frameWidth = PAGE.width - (frameMargin * 2);
  const frameHeight = PAGE.height - (frameMargin * 2);
  
  // OUTER GOLD BORDER (thick)
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .rect(frameMargin, frameMargin, frameWidth, frameHeight)
     .stroke();
  
  // INNER GOLD BORDER (thin - creates double frame effect)
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .rect(frameMargin + 8, frameMargin + 8, frameWidth - 16, frameHeight - 16)
     .stroke();
  
  let y = frameMargin + 35;
  const centerX = PAGE.width / 2;
  const contentMargin = frameMargin + 35;
  const contentWidth = frameWidth - 70;
  
  // ═══════════════════════════════════════════════════════════════════
  // FINOTAUR TEXT
  // ═══════════════════════════════════════════════════════════════════
  doc.fillColor(COLORS.gold)
     .fontSize(28)
     .font(FONTS.bold)
     .text('FINOTAUR', 0, y, { align: 'center', width: PAGE.width });
  
  y += 40;
  
  // LOGO under FINOTAUR text
  if (logoData) {
    try {
      const logoWidth = 120;
      const logoX = (PAGE.width - logoWidth) / 2;
      if (Buffer.isBuffer(logoData)) {
        doc.image(logoData, logoX, y, { width: logoWidth });
        y += 70;
      } else if (typeof logoData === 'string' && fs.existsSync(logoData)) {
        doc.image(logoData, logoX, y, { width: logoWidth });
        y += 70;
      } else {
        y += 10;
      }
    } catch (e) {
      y += 10;
    }
  } else {
    y += 10;
  }
  
  // Gold decorative line
  doc.strokeColor(COLORS.gold)
     .lineWidth(1.5)
     .moveTo(centerX - 80, y)
     .lineTo(centerX + 80, y)
     .stroke();
  
  y += 25;
  
  // ═══════════════════════════════════════════════════════════════════
  // IMPORTANT DISCLAIMER TITLE
  // ═══════════════════════════════════════════════════════════════════
  doc.fillColor(COLORS.gold)
     .fontSize(18)
     .font(FONTS.bold)
     .text('IMPORTANT DISCLAIMER', 0, y, { align: 'center', width: PAGE.width });
  
  y += 30;
  
  // Gold line under title
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .moveTo(centerX - 100, y)
     .lineTo(centerX + 100, y)
     .stroke();
  
  y += 25;
  
  // ═══════════════════════════════════════════════════════════════════
  // DISCLAIMER SECTIONS
  // ═══════════════════════════════════════════════════════════════════
  const disclaimerSections = [
    {
      title: 'GENERAL INFORMATION ONLY',
      content: 'This report is produced by Finotaur for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.'
    },
    {
      title: 'NOT INVESTMENT ADVICE',
      content: 'This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. Finotaur is NOT a registered investment adviser or broker-dealer.'
    },
    {
      title: 'RISK DISCLOSURE',
      content: 'Trading and investing in cryptocurrencies involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital. Crypto assets are highly volatile and speculative.'
    },
    {
      title: 'NO GUARANTEES',
      content: 'Finotaur makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.'
    },
    {
      title: 'YOUR RESPONSIBILITY',
      content: 'You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.'
    },
    {
      title: 'LIMITATION OF LIABILITY',
      content: 'Finotaur shall NOT be liable for any damages arising from your use of or reliance on this report.'
    }
  ];
  
  for (const section of disclaimerSections) {
    if (y > PAGE.height - 200) break;
    
    // Section title in GOLD with line underneath
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(9)
       .text(section.title, contentMargin, y);
    
    y += 12;
    
    // Small gold line under section title
    doc.strokeColor(COLORS.gold)
       .lineWidth(0.5)
       .moveTo(contentMargin, y)
       .lineTo(contentMargin + 120, y)
       .stroke();
    
    y += 8;
    
    // Section content in WHITE
    doc.fillColor('#FFFFFF')
       .font(FONTS.body)
       .fontSize(8.5)
       .text(section.content, contentMargin, y, { width: contentWidth, align: 'justify' });
    
    y += doc.heightOfString(section.content, { width: contentWidth }) + 12;
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // COPYRIGHT WARNING - RED BOX
  // ═══════════════════════════════════════════════════════════════════
  
  y = PAGE.height - frameMargin - 135;
  
  // Red warning box
  const warningBoxX = contentMargin - 8;
  const warningBoxWidth = contentWidth + 16;
  const warningBoxHeight = 75;
  
  // Dark red background
  doc.rect(warningBoxX, y, warningBoxWidth, warningBoxHeight)
     .fill('#330000');
  
  // Red border
  doc.strokeColor('#CC0000')
     .lineWidth(2)
     .rect(warningBoxX, y, warningBoxWidth, warningBoxHeight)
     .stroke();
  
  y += 10;
  
  // Warning title in RED
  doc.fillColor('#FF3333')
     .font(FONTS.bold)
     .fontSize(10)
     .text('COPYRIGHT WARNING', contentMargin, y, { width: contentWidth, align: 'center' });
  
  y += 16;
  
  // Warning text in lighter red
  const copyrightWarning = 'This report is the exclusive intellectual property of FINOTAUR. Unauthorized reproduction, distribution, transmission, display, or publication of this report, in whole or in part, without the prior written consent of FINOTAUR is strictly prohibited and constitutes a violation of copyright law. Violators will be subject to legal action and may be liable for statutory damages.';
  
  doc.fillColor('#FF6666')
     .font(FONTS.body)
     .fontSize(7.5)
     .text(copyrightWarning, contentMargin, y, { width: contentWidth, align: 'justify' });
  
  // ═══════════════════════════════════════════════════════════════════
  // BOTTOM - Copyright and acknowledgment
  // ═══════════════════════════════════════════════════════════════════
  
  y = PAGE.height - frameMargin - 40;
  
  // Thin gold line
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .moveTo(contentMargin, y)
     .lineTo(contentMargin + contentWidth, y)
     .stroke();
  
  y += 12;
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.body)
     .fontSize(8)
     .text(`© ${new Date().getFullYear()} Finotaur. All Rights Reserved.`, 
           contentMargin, y, { width: contentWidth, align: 'center' });
  
  y += 12;
  
  doc.fillColor('#888888')
     .font(FONTS.body)
     .fontSize(7)
     .text('By reading this report, you acknowledge and agree to the terms above.', 
           contentMargin, y, { width: contentWidth, align: 'center' });
}

// ============ FILE-BASED GENERATION ============
export async function generateCryptoReportPDFToFile(reportMarkdown, options = {}, outputPath) {
  const buffer = await generateCryptoReportPDF(reportMarkdown, options);
  fs.writeFileSync(outputPath, buffer);
  return {
    path: outputPath,
    filename: path.basename(outputPath),
    size: buffer.length,
  };
}

export default {
  generateCryptoReportPDF,
  generateCryptoReportPDFToFile,
};