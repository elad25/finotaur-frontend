// =====================================================
// AI SERVICE v10.0 - INSTITUTIONAL PM-GRADE PROMPTS
// =====================================================
// IMPROVEMENTS FROM FEEDBACK:
// - Action-oriented takeaways (not descriptive)
// - Binary regime flip triggers
// - Explicit "Who is impacted" (Spot/Leverage/Funds/Retail)
// - Acceptance vs Rejection for every level
// - One-liner conclusions per subsection
// - Forced Actor analysis
// - Signal vs Confirmation separation
// - False positives section for whales
// - % of ADV for unlocks
// - Base-Rate Reminders
// - Impact Direction + Time Decay for catalysts
// =====================================================

import Anthropic from '@anthropic-ai/sdk';
import { DATA_TAGS } from './CryptoAgents.js';

class CryptoAIService {
  constructor(apiKey) {
    this.client = new Anthropic({ apiKey });
    this.model = 'claude-sonnet-4-20250514';
  }

  // ============================================
  // SYSTEM PROMPTS - PM-GRADE
  // ============================================

  getBaseSystemPrompt() {
    return `You are an institutional crypto analyst producing Delphi Digital / K33 Research quality reports.

CRITICAL RULES FOR PM-GRADE OUTPUT:

1. DECISION-FORCING LANGUAGE:
   - Every observation must answer: "What do I do differently?"
   - No descriptive statements without actionable conclusion
   - Replace "Mixed signals" with "Directional bets have negative expectancy until X"
   - Replace "Watch for reversal" with specific binary condition

2. DATA RELIABILITY TAGS (use when needed):
   - ${DATA_TAGS.DATA_REQUIRED} — Data not available
   - ${DATA_TAGS.ON_CHAIN_LIMITATION} — Requires Glassnode/CryptoQuant
   - ${DATA_TAGS.INFERRED} — Behavioral inference from price/volume
   - ${DATA_TAGS.TIMING_UNCERTAIN} — Date/time not confirmed
   - ${DATA_TAGS.OPTIONS_REQUIRED} — Needs Deribit API

3. WHO IS IMPACTED (always explicit):
   - Spot holders (accumulating, not trading)
   - Leveraged longs (perps, margin)
   - Leveraged shorts (perps, margin)
   - Funds/Institutions (allocation-driven)
   - Retail (sentiment-driven, late)
   - Miners (cost-basis driven)

4. LEVEL ANALYSIS (always include):
   - Acceptance: Price held above/below for X hours with volume
   - Rejection: Wicked through but closed opposite side
   - Never just list levels without acceptance/rejection context

5. FORCED ACTORS:
   - Who MUST act (not "may act")
   - Estimated $ at risk
   - What triggers forced action

6. FUNDING MATH (CRITICAL):
   8h rate × 3 × 365 = annualized
   Example: 0.01% × 3 × 365 = 10.95% annualized

7. FEAR & GREED SCALE:
   - 0-24 = Extreme Fear (CONTRARIAN BUY zone)
   - 25-44 = Fear
   - 45-54 = Neutral
   - 55-74 = Greed
   - 75-100 = Extreme Greed (CONTRARIAN SELL zone)

8. BASE-RATE REMINDERS:
   - Most breakouts fail without follow-through (60%+)
   - Most range-bound periods resolve in direction of prior trend
   - Include these where relevant

9. OUTPUT FORMATTING (CRITICAL):
   - NO EMOJI OR SPECIAL SYMBOLS - output plain text only
   - No 🔴🟡🟢📈📉⚠️🎯 or any other unicode symbols
   - Use words: BEARISH, NEUTRAL, BULLISH instead of colored circles
   - Use words: WARNING, TARGET, UP, DOWN instead of symbols`;
  }

  // ============================================
  // TAKEAWAY GENERATION - ACTION-ORIENTED
  // ============================================

  async generateTakeaways(marketData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Generate exactly 5 PM-GRADE ACTION-ORIENTED takeaways.

CRITICAL: Each takeaway must force a decision. PM asks: "What do I do differently?"

EACH TAKEAWAY STRUCTURE:
{
  "observation": "What we observed (factual, one sentence)",
  "implication": "Therefore... (the SO WHAT - positioning-centric)",
  "whoIsImpacted": {
    "primary": "Specific group (leveraged longs / spot holders / etc)",
    "secondary": "Other affected groups",
    "notAffected": "Who can ignore this"
  },
  "action": {
    "do": "Specific action to take NOW",
    "avoid": "What NOT to do",
    "trigger": "Binary condition: If X, then Y"
  },
  "signal": "bullish | neutral | bearish",
  "confidence": "High | Medium | Low",
  "expiry": "When this takeaway becomes stale (hours/days)"
}

BAD EXAMPLE (descriptive, useless):
"Mixed signals, no clear trend dominance"

GOOD EXAMPLE (action-forcing):
{
  "observation": "BTC range-bound $84K-$91K for 12 days, funding neutral",
  "implication": "Positioning remains unresolved → directional bets have negative expectancy until catalyst breaks range",
  "whoIsImpacted": {
    "primary": "Leveraged traders (funding drag eroding capital)",
    "secondary": "Funds (forced to stay underweight)",
    "notAffected": "Spot holders with 6+ month horizon"
  },
  "action": {
    "do": "Set limit orders at range boundaries: buy $84.5K, sell $90.5K",
    "avoid": "Market orders or adding leverage mid-range",
    "trigger": "If daily close >$91K with rising OI → flip to momentum long"
  },
  "signal": "neutral",
  "confidence": "High",
  "expiry": "Valid until range breaks (est. 3-7 days)"
}

Return JSON array of exactly 5 takeaways.`;

    const userPrompt = `Market Data:
${JSON.stringify(marketData, null, 2)}

Generate 5 PM-grade action-oriented takeaways.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 5000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse takeaways JSON');
    } catch (error) {
      console.error('Takeaways generation error:', error);
      return this.getDefaultTakeaways(marketData);
    }
  }

  getDefaultTakeaways(marketData) {
    return [
      {
        observation: `BTC at ${marketData?.marketData?.btc?.price || '[DATA REQUIRED]'}`,
        implication: 'Price determines portfolio heat - adjust exposure accordingly',
        whoIsImpacted: { primary: 'All participants', secondary: 'N/A', notAffected: 'None' },
        action: { do: 'Check position sizing', avoid: 'Overleveraging', trigger: 'If >20% drawdown, reduce' },
        signal: 'neutral',
        confidence: 'Medium',
        expiry: '24h'
      }
    ];
  }

  // ============================================
  // REGIME ANALYSIS - BINARY FLIP TRIGGERS
  // ============================================

  async analyzeRegime(marketData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze market regime with BINARY FLIP CONDITIONS.

CRITICAL: Regime flip trigger must be unambiguous, not "watch for reversal signals".

REQUIRED OUTPUT:
{
  "regime": "RISK-ON | TRANSITIONAL-BULLISH | NEUTRAL | TRANSITIONAL-BEARISH | RISK-OFF",
  "score": 0-100,
  "confidence": "High | Medium | Low",
  
  "input1_structure": {
    "btcTrend": "uptrend | range | downtrend",
    "btcAcceptance": "Accepted above $X (closed Y days above)" | "Rejected at $X (wicked but closed below)",
    "ethBtcRatio": "X.XXXX (rising/falling/flat)",
    "interpretation": "One sentence - positioning centric"
  },
  
  "input2_fundingOI": {
    "funding8h": "X.XXXX%",
    "fundingAnnualized": "XX.X% (show math: X × 3 × 365)",
    "oiLevel": "$XXB",
    "oiVsPrice": "rising_together | oi_high_price_falling | price_up_oi_falling",
    "fragility": "FRAGILE (longs paying, no trend) | SQUEEZE_FUEL (shorts bleeding) | BALANCED",
    "interpretation": "One sentence - who is exposed"
  },
  
  "input3_flows": {
    "stablecoinDelta7d": "+X.X% or -X.X%",
    "etfFlowsWeek": "+$XXM or -$XXM or [DATA REQUIRED]",
    "exchangeBalance": "decreasing (bullish) | increasing (bearish) | stable",
    "interpretation": "Who deploys first when conditions align"
  },
  
  "regimeFlipTrigger": {
    "toRiskOn": "BTC daily close >$X with OI rising and funding <0.03%",
    "toRiskOff": "BTC daily close <$X OR funding >0.08% with flat price",
    "currentDistance": "X% away from flip condition"
  },
  
  "macroCorrelation": {
    "btcSpxCorrelation": "X.XX (30d rolling)",
    "correlationOnRedDays": "Higher | Lower | Same (vs green days)",
    "correlationOnGreenDays": "Higher | Lower | Same (vs red days)",
    "institutionalImplication": "Crypto is risk-on proxy | Crypto is uncorrelated | Mixed behavior",
    "conclusion": "ONE SENTENCE: what correlation tells allocators"
  },
  
  "flipType": {
    "likely": "price-led | positioning-led | flow-led",
    "explanation": "Why this type (institutional edge)"
  },
  
  "netEffect": "One sentence: What this regime means for sizing and direction"
}

Return valid JSON only.`;

    const userPrompt = `Analyze regime from this data:
${JSON.stringify(marketData, null, 2)}`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse regime JSON');
    } catch (error) {
      console.error('Regime analysis error:', error);
      return null;
    }
  }

  // ============================================
  // WHALE BEHAVIOR - WITH FALSE POSITIVES
  // ============================================

  async analyzeWhaleBehavior(marketData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze whale behavior with FALSE POSITIVE awareness.

CRITICAL: Lead with what we DON'T know. Accumulation at support ≠ accumulation at resistance.

REQUIRED OUTPUT:
{
  "dataLimitations": {
    "whatWeCannotSee": [
      "Individual wallet movements (no Glassnode)",
      "OTC desk flow (private)",
      "Cold storage rotations"
    ],
    "confidence": "LOW - all inferences are behavioral"
  },
  
  "buckets": [
    {
      "bucket": "ETF/Institutional Flow",
      "observable": true,
      "status": "+$XXM or -$XXM this week",
      "behavior": "accumulating | distributing | neutral",
      "context": "At support (bullish) | At resistance (could be exit liquidity)",
      "confidence": "High"
    },
    {
      "bucket": "Exchange Balance Proxy",
      "observable": false,
      "status": "${DATA_TAGS.ON_CHAIN_LIMITATION}",
      "behaviorInference": "Based on volume patterns only",
      "confidence": "Low"
    },
    {
      "bucket": "Stablecoin Whales",
      "observable": true,
      "status": "Supply +/-X.X% 7d",
      "behavior": "dry powder building | deploying | neutral",
      "confidence": "Medium"
    },
    {
      "bucket": "Volume-Inferred",
      "observable": true,
      "status": "Volume XXX% of 20D avg",
      "behavior": "large_buyer | large_seller | mixed | low_conviction",
      "method": "Inferred from price impact and volume clusters",
      "confidence": "Medium",
      "tag": "${DATA_TAGS.INFERRED}"
    }
  ],
  
  "falsePositives": {
    "warning": "Historical false signals to remember",
    "examples": [
      {
        "signal": "Whale accumulation at resistance",
        "reality": "Often distribution/exit liquidity, not accumulation",
        "howToDistinguish": "Check if price breaks or rejects within 48h"
      },
      {
        "signal": "Exchange deposits = selling",
        "reality": "Could be derivatives collateral or internal transfers",
        "howToDistinguish": "Correlate with OI changes"
      },
      {
        "signal": "Large OTC blocks",
        "reality": "Already executed, may be old news by the time reported",
        "howToDistinguish": "Check if price already moved"
      }
    ]
  },
  
  "netAssessment": {
    "behavior": "accumulation_inferred | distribution_inferred | neutral | insufficient_data",
    "confidence": "High | Medium | Low",
    "keyEvidence": ["Point 1", "Point 2"],
    "contraryEvidence": ["What argues against this view"],
    "actionableInsight": "One sentence: what to do with this information"
  }
}

Return valid JSON only.`;

    const userPrompt = `Analyze whale behavior from:
${JSON.stringify(marketData, null, 2)}`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse whale behavior JSON');
    } catch (error) {
      console.error('Whale analysis error:', error);
      return null;
    }
  }

  // ============================================
  // CATALYST RADAR - WITH IMPACT DIRECTION & TIME DECAY
  // ============================================

  async analyzeCatalysts(marketData, newsItems = []) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze catalysts with IMPACT DIRECTION and TIME DECAY.

CRITICAL: Each catalyst must answer "Did this force positioning change?"

REQUIRED OUTPUT:
{
  "activeCatalysts": [
    {
      "catalyst": "Description",
      "impactDirection": "BULLISH | BEARISH | VOLATILITY_EXPANDING | NEUTRAL",
      "magnitude": "HIGH | MEDIUM | LOW",
      "whoForcedToAct": ["Shorts above $X", "Funds underweight crypto"],
      "timeDecay": {
        "expiresIn": "X days",
        "condition": "Expires if not realized by DATE or if CONDITION",
        "staleness": "Fresh (0-24h) | Aging (1-7d) | Stale (>7d)"
      },
      "priceReaction": "Already moved X% | Not yet priced | Partially priced",
      "positioning": "Add on dip | Fade the move | Wait for confirmation"
    }
  ],
  
  "upcomingCatalysts": [
    {
      "event": "Description",
      "date": "DATE or ${DATA_TAGS.TIMING_UNCERTAIN}",
      "impactDirection": "BULLISH | BEARISH | VOLATILITY_EXPANDING",
      "probability": "X% chance of market-moving outcome",
      "setupAction": "How to position ahead",
      "source": "Official | Rumor | ${DATA_TAGS.SOURCE_REQUIRED}"
    }
  ],
  
  "marketIgnoring": [
    {
      "development": "What market isn't pricing",
      "whyIgnored": "Too early | Low probability | Not understood",
      "potentialImpact": "Could move market X% if realized",
      "timeframe": "When it might matter"
    }
  ],
  
  "noise": [
    {
      "headline": "Noise item",
      "whyNoise": "No positioning change | Already priced | Irrelevant"
    }
  ],
  
  "netCatalystBias": "NET_BULLISH | NET_BEARISH | BALANCED | VOLATILITY_BIASED",
  "actionSummary": "One sentence: how to position for catalyst environment"
}

Return valid JSON only.`;

    const userPrompt = `Market Data:
${JSON.stringify(marketData, null, 2)}

News Items:
${JSON.stringify(newsItems, null, 2)}

Analyze catalysts.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse catalyst JSON');
    } catch (error) {
      console.error('Catalyst analysis error:', error);
      return null;
    }
  }

  // ============================================
  // TOKEN UNLOCKS - WITH % OF ADV
  // ============================================

  async analyzeTokenUnlocks(unlockData = [], volumeData = {}) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze token unlocks with % OF AVERAGE DAILY VOLUME (institutional metric).

FOR EACH UNLOCK:
1. % of circulating supply
2. % of Average Daily Volume (ADV) - THIS IS KEY
3. Days to absorb (unlock $ / ADV)
4. Verdict based on absorption capacity

% OF ADV INTERPRETATION:
- <50% ADV = Easily absorbed, minimal impact
- 50-200% ADV = Watch closely, may pressure price
- 200-500% ADV = High risk, likely selling pressure
- >500% ADV = Severe risk, avoid or short

REQUIRED OUTPUT:
{
  "unlocks": [
    {
      "token": "SYMBOL",
      "date": "DATE or ${DATA_TAGS.TIMING_UNCERTAIN}",
      "unlockAmount": "XX.XM tokens",
      "dollarValue": "$XXM",
      "percentOfCirculating": "X.XX%",
      "avgDailyVolume": "$XXM",
      "percentOfADV": "XXX%",
      "daysToAbsorb": "X.X days",
      "recipient": "Team | Investors | Ecosystem | ${DATA_TAGS.DATA_REQUIRED}",
      "recipientLikelyAction": "Sell immediately | Gradual sale | Hold | Unknown",
      "verdict": "SAFE (<50% ADV) | WATCH (50-200%) | AVOID (>200%)",
      "math": "Show calculation",
      "source": "TokenUnlocks.app or ${DATA_TAGS.SOURCE_REQUIRED}"
    }
  ],
  
  "summary": {
    "highRiskUnlocks": ["Tokens with >200% ADV unlock in next 14 days"],
    "moderateRiskUnlocks": ["Tokens with 50-200% ADV"],
    "safeUnlocks": ["Tokens with <50% ADV"],
    "totalUnlockValue7d": "$XXM",
    "marketImpact": "Significant | Moderate | Minimal"
  },
  
  "tradingImplication": "One sentence: what to do with unlock calendar"
}

Return valid JSON only.`;

    const userPrompt = `Unlock Data:
${JSON.stringify(unlockData, null, 2)}

Volume Data:
${JSON.stringify(volumeData, null, 2)}

Analyze with ADV metrics.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse unlock analysis JSON');
    } catch (error) {
      console.error('Unlock analysis error:', error);
      return null;
    }
  }

  // ============================================
  // MARKET STRUCTURE - WITH FORCED ACTORS
  // ============================================

  async generateMarketStructureTable(marketData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Generate market structure table with FORCED ACTOR column.

CRITICAL: Each level must identify WHO IS FORCED TO ACT and WHAT TRIGGERS IT.

REQUIRED OUTPUT:
{
  "levels": [
    {
      "price": "$XXX,XXX",
      "distancePercent": "+X% or -X%",
      "levelType": "resistance | support | liquidation_cluster | psychological",
      "acceptance": "Needs: 4h close above with volume" | "Confirmed: held X days",
      "rejection": "Wicked X times, no close above",
      "sideTrapped": "SHORTS | LONGS | NONE",
      "estimatedAtRisk": "$XXM or ${DATA_TAGS.DATA_REQUIRED}",
      "forcedActor": {
        "who": "Leveraged shorts | Late longs | Passive holders | Market makers",
        "trigger": "Price sustains above/below for X hours",
        "action": "Stop hunt → cascade | Forced to cover | Margin call"
      },
      "confirmation": "What confirms the level is broken (not just wicked)"
    }
  ],
  
  "currentPrice": "$XX,XXX",
  
  "asymmetry": {
    "moreExposed": "LONGS | SHORTS | BALANCED",
    "longsAtRisk": "$XXM (at which levels)",
    "shortsAtRisk": "$XXM (at which levels)",
    "reasoning": "Why one side is more exposed",
    "cascadeRisk": "HIGH | MEDIUM | LOW"
  },
  
  "baseRateReminder": "Most breakouts (60%+) fail without follow-through. Require confirmation before chasing.",
  
  "tradingImplication": "One sentence: which side to favor or stay neutral"
}

Return valid JSON only.`;

    const userPrompt = `Market Data:
${JSON.stringify(marketData, null, 2)}

Generate market structure with forced actors.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse market structure JSON');
    } catch (error) {
      console.error('Market structure error:', error);
      return null;
    }
  }

  // ============================================
  // DERIVATIVES - SIGNAL VS CONFIRMATION
  // ============================================

  async analyzeDerivatives(derivativesData, priceData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze derivatives with SIGNAL vs CONFIRMATION separation.

CRITICAL: Distinguish between early signals and confirmed setups.

FUNDING MATH: 8h rate × 3 × 365 = annualized

INTERPRETATION RULES:
1. Funding >0.03% + price flat = FRAGILE (longs paying for nothing)
2. Funding <-0.01% + price stable = SQUEEZE FUEL (shorts bleeding)
3. Funding >30% ann + rising price = CROWDED TOP RISK
4. L/S >1.8 = LOPSIDED LONG (cascade risk below)
5. L/S <0.6 = LOPSIDED SHORT (squeeze risk above)

REQUIRED OUTPUT:
{
  "funding": {
    "btc8h": "0.XXXX%",
    "btcAnnualized": "XX.X% (math: X × 3 × 365 = Y)",
    "eth8h": "0.XXXX%",
    "ethAnnualized": "XX.X%",
    "solAnnualized": "XX.X%"
  },
  
  "signals": {
    "type": "SIGNAL - early indication, not confirmation",
    "active": [
      {
        "rule": "Which rule triggered",
        "reading": "Current value",
        "implication": "What it suggests",
        "falsePositiveRate": "How often this signal fails (estimate)"
      }
    ]
  },
  
  "confirmations": {
    "type": "CONFIRMATION - actionable setup",
    "active": [
      {
        "setup": "What is confirmed",
        "trigger": "What triggered confirmation",
        "action": "What to do",
        "invalidation": "What kills this setup"
      }
    ],
    "pending": ["Setups waiting for confirmation"]
  },
  
  "openInterest": {
    "btcOI": "$XXB",
    "ethOI": "$XXB",
    "oiChange7d": "+/-X%",
    "oiVsPrice": "interpretation",
    "fragility": "FRAGILE | BALANCED | SQUEEZE_SETUP"
  },
  
  "longShortRatio": {
    "btc": "X.XX",
    "interpretation": "What positioning means"
  },
  
  "riskThisWeek": {
    "upsideFragility": "LOW | MEDIUM | HIGH (shorts squeezed)",
    "downsideFragility": "LOW | MEDIUM | HIGH (longs liquidated)",
    "moreExposed": "UPSIDE | DOWNSIDE | BALANCED"
  },
  
  "netEffect": "One sentence: what derivatives tell us to do"
}

Return valid JSON only.`;

    const userPrompt = `Derivatives Data:
${JSON.stringify(derivativesData, null, 2)}

Price Data:
${JSON.stringify(priceData, null, 2)}

Analyze with signal vs confirmation.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse derivatives JSON');
    } catch (error) {
      console.error('Derivatives analysis error:', error);
      return null;
    }
  }

  // ============================================
  // SCENARIOS - WITH OPERATIONAL CHECKLIST
  // ============================================

  async generateScenarios(marketData, regimeInfo) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Generate scenarios with YES/NO OPERATIONAL CHECKLIST.

CRITICAL: No gray zones. Binary conditions for each scenario.

REQUIRED OUTPUT:
{
  "baseCase": {
    "probability": "XX%",
    "scenario": "Description",
    "priceRange": "$XX,XXX - $XX,XXX",
    "triggers": ["Binary trigger 1", "Binary trigger 2"],
    "whoForcedToAct": {
      "longs": "What longs must do",
      "shorts": "What shorts must do",
      "funds": "What funds must do"
    },
    "strategy": "Specific action",
    "checklist": {
      "q1": {"question": "Is funding <0.05%?", "answer": "YES | NO", "implication": "If NO, reduce size"},
      "q2": {"question": "Is OI stable or rising?", "answer": "YES | NO", "implication": "If NO, expect volatility"},
      "q3": {"question": "Did ETF flows turn positive?", "answer": "YES | NO | DATA MISSING", "implication": ""}
    }
  },
  
  "upsideCase": {
    "probability": "XX%",
    "scenario": "Description",
    "target": "$XX,XXX",
    "triggers": ["Binary trigger 1", "Binary trigger 2"],
    "invalidation": "Daily close below $XX,XXX",
    "whoForcedToAct": {
      "shorts": "$XXM liquidated between $X-$Y",
      "funds": "Underweight managers forced to chase",
      "marketMakers": "Hedge short gamma → acceleration"
    },
    "strategy": "Specific action",
    "entryTrigger": "Exact condition to enter"
  },
  
  "downsideCase": {
    "probability": "XX%",
    "scenario": "Description",
    "target": "$XX,XXX",
    "triggers": ["Binary trigger 1", "Binary trigger 2"],
    "invalidation": "Daily close above $XX,XXX",
    "whoForcedToAct": {
      "longs": "$XXM liquidated between $X-$Y",
      "funds": "Meet redemptions via forced selling",
      "miners": "Sell if below cost basis (~$XX,XXX)"
    },
    "strategy": "Specific action",
    "hedgeTrigger": "Exact condition to hedge"
  },
  
  "baseRateReminder": {
    "note": "Most breakouts fail without follow-through",
    "successRate": "~40% of breakouts sustain",
    "implication": "Require confirmation, don't chase"
  },
  
  "decisionTree": "IF [condition] THEN [action]. IF [other condition] THEN [other action]."
}

Probabilities must sum to 100%.

Return valid JSON only.`;

    const userPrompt = `Market Data:
${JSON.stringify(marketData, null, 2)}

Regime: ${JSON.stringify(regimeInfo, null, 2)}

Generate scenarios with checklist.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 4000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse scenarios JSON');
    } catch (error) {
      console.error('Scenarios error:', error);
      return null;
    }
  }

  // ============================================
  // BTC SUPPLY - SIGNAL VS CONFIRMATION
  // ============================================

  async analyzeBTCSupply(onchainData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze BTC supply with SIGNAL vs CONFIRMATION separation.

CRITICAL: Proxy ≠ Conclusion. Clearly separate what we observe from what it means.

REQUIRED OUTPUT:
{
  "dataAvailable": {
    "fromOurAPIs": ["Stablecoin supply", "Exchange volume", "Futures OI"],
    "notAvailable": ["Glassnode metrics", "Wallet-level data", "Miner reserves"]
  },
  
  "signals": {
    "note": "SIGNALS - observations, not conclusions",
    "items": [
      {
        "metric": "Exchange volume trend",
        "observation": "What we see",
        "possibleMeanings": ["Bullish interpretation", "Bearish interpretation"],
        "confidence": "Low - proxy only"
      }
    ]
  },
  
  "confirmations": {
    "note": "CONFIRMATIONS - multiple signals aligning",
    "items": [
      {
        "thesis": "What multiple signals suggest",
        "supportingSignals": ["Signal 1", "Signal 2"],
        "confidence": "Medium",
        "caveat": "Still inference-based"
      }
    ]
  },
  
  "lthProxy": {
    "status": "${DATA_TAGS.ON_CHAIN_LIMITATION}",
    "inference": "Based on price stability: likely holding | likely distributing | unclear",
    "confidence": "Low"
  },
  
  "sthProxy": {
    "costBasisEstimate": "$XX,XXX (${DATA_TAGS.INFERRED} from recent price action)",
    "profitStatus": "XX% estimated in profit",
    "behavior": "Likely taking profit | Likely holding | Underwater"
  },
  
  "minerProxy": {
    "status": "${DATA_TAGS.ON_CHAIN_LIMITATION}",
    "hashRateTrend": "Stable | Growing | Declining",
    "stressIndicator": "No stress | Moderate stress | High stress (hashrate dropping)",
    "implication": "What this means for supply"
  },
  
  "netAssessment": {
    "supplyPressure": "TIGHT | NEUTRAL | LOOSE",
    "confidence": "Low - all proxies, no direct data",
    "actionableInsight": "What to do with this (or ignore due to low confidence)"
  }
}

Return valid JSON only.`;

    const userPrompt = `On-Chain Data:
${JSON.stringify(onchainData, null, 2)}

Analyze BTC supply with signal vs confirmation.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse BTC supply JSON');
    } catch (error) {
      console.error('BTC supply analysis error:', error);
      return null;
    }
  }

  // ============================================
  // ETH ANALYSIS - ALLOCATOR BEHAVIOR FOCUS
  // ============================================

  async analyzeETH(ethData, btcData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze ETH with ALLOCATOR BEHAVIOR focus.

CRITICAL: ETH/BTC ratio is about allocator behavior, not narrative. Why does it matter NOW?

REQUIRED OUTPUT:
{
  "ethBtcRatio": {
    "current": "0.XXXX",
    "trend30d": "rising | falling | flat",
    "allocatorSignal": "Funds rotating INTO ETH | OUT OF ETH | Neutral",
    "whyNow": "Why this matters this week specifically",
    "historicalContext": "Where we are vs historical range"
  },
  
  "networkEconomics": {
    "feeRevenue24h": "$XXM",
    "feesTrend": "Rising | Falling | Stable",
    "burnRate": "XX ETH/day",
    "issuanceRate": "XX ETH/day",
    "netIssuance": "Inflationary +XX | Deflationary -XX",
    "implication": "What net issuance means for price"
  },
  
  "stakingDynamics": {
    "totalStaked": "XXM ETH (XX%)",
    "stakingAPY": "X.X%",
    "queueStatus": "Entry queue X days | Exit queue X days | Balanced",
    "concentration": {
      "lidoShare": "XX%",
      "risk": "High concentration risk | Acceptable | Diversified"
    },
    "implication": "What staking dynamics mean"
  },
  
  "l2Ecosystem": {
    "totalL2TVL": "$XXB",
    "dominant": "Which L2 leads",
    "trend": "Growing | Stable | Shrinking",
    "ethImpact": "Fee capture | Cannibalization | Both",
    "winner": "Which L2 is winning and why"
  },
  
  "catalysts": {
    "near": ["Catalyst within 30 days"],
    "medium": ["Catalyst 1-3 months"],
    "missing": "What catalyst would change the trend"
  },
  
  "vsCompetitors": {
    "solanaComparison": "SOL taking share because...",
    "mindshareIssue": "Why ETH losing attention",
    "reversalCondition": "What would flip narrative back to ETH"
  },
  
  "netAssessment": {
    "stance": "ACCUMULATE | HOLD | REDUCE | AVOID",
    "sizing": "Core position | Tactical only | Underweight",
    "trigger": "What would change this view",
    "timeframe": "How long this view is valid"
  }
}

Return valid JSON only.`;

    const userPrompt = `ETH Data:
${JSON.stringify(ethData, null, 2)}

BTC Data for comparison:
${JSON.stringify(btcData, null, 2)}

Analyze ETH with allocator focus.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse ETH analysis JSON');
    } catch (error) {
      console.error('ETH analysis error:', error);
      return null;
    }
  }

  // ============================================
  // EXECUTIVE SUMMARY - PM-GRADE
  // ============================================

  async generateExecutiveSummary(allAnalyses) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Generate PM-grade executive summary.

CRITICAL: Every sentence must be actionable or eliminated.

REQUIRED STRUCTURE (under 250 words):

1. THE CALL (one sentence):
   "We are [BULLISH/BEARISH/NEUTRAL] with [HIGH/MEDIUM/LOW] conviction because [one reason]."

2. REGIME:
   "[REGIME NAME] (XX% confidence). Flips to [other regime] if [binary condition]."

3. THIS WEEK'S ACTIONS (exactly 3, each with WHO):
   - "[Action 1] — affects [who]"
   - "[Action 2] — affects [who]"
   - "[Action 3] — affects [who]"

4. KEY RISKS (exactly 3, each with trigger):
   - "[Risk 1] — triggered if [condition]"
   - "[Risk 2] — triggered if [condition]"
   - "[Risk 3] — triggered if [condition]"

5. KEY LEVELS:
   - BTC: Support $XX,XXX (acceptance/rejection status) | Resistance $XX,XXX
   - ETH: Support $X,XXX | Resistance $X,XXX

6. BASE-RATE REMINDER:
   "Remember: [relevant statistical base rate for current setup]"

Return plain text matching this exact structure.`;

    const userPrompt = `All Analyses:
${JSON.stringify(allAnalyses, null, 2)}

Generate PM-grade executive summary.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      return response.content[0].text;
    } catch (error) {
      console.error('Executive summary error:', error);
      return 'Executive summary generation failed.';
    }
  }

  // ============================================
  // PROTOCOL CHANGES - WHO PAYS THE COST
  // ============================================

  async analyzeProtocolChanges(protocolData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Analyze protocol changes with WHO PAYS THE COST.

CRITICAL: Every upgrade creates winners and losers. Identify both.

REQUIRED OUTPUT:
{
  "changes": [
    {
      "protocol": "Name",
      "change": "Description",
      "date": "DATE or ${DATA_TAGS.TIMING_UNCERTAIN}",
      "winners": ["Who benefits and how"],
      "losers": ["Who pays the cost and how"],
      "tokenImpact": "BULLISH | BEARISH | NEUTRAL for token",
      "tradingImplication": "How to position",
      "source": "Official announcement or ${DATA_TAGS.SOURCE_REQUIRED}"
    }
  ],
  
  "majorUpcoming": [
    {
      "protocol": "Name",
      "upgrade": "Description",
      "expectedDate": "Date",
      "marketExpectation": "Priced in | Not priced | Partially priced",
      "setupOpportunity": "How to trade this"
    }
  ],
  
  "summary": "One sentence: net protocol environment"
}

Return valid JSON only.`;

    const userPrompt = `Protocol Data:
${JSON.stringify(protocolData, null, 2)}

Analyze with winners/losers.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 2000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse protocol changes JSON');
    } catch (error) {
      console.error('Protocol changes error:', error);
      return null;
    }
  }

  // ============================================
  // MARKET DASHBOARD - WITH 14D Δ
  // ============================================

  async generateMarketDashboard(allData) {
    const systemPrompt = `${this.getBaseSystemPrompt()}

TASK: Generate Market Dashboard with Value + 14D Change + Interpretation.

CRITICAL: Every metric needs three components:
1. Current Value
2. 14D Δ (change from 14 days ago)  
3. Interpretation (positioning-centric, not descriptive)

REQUIRED OUTPUT:
{
  "dashboard": [
    {
      "metric": "BTC Price",
      "value": "$XX,XXX",
      "delta14d": "+X.X% | -X.X%",
      "interpretation": "ONE SENTENCE - positioning implication"
    },
    {
      "metric": "ETH/BTC Ratio",
      "value": "0.XXXX",
      "delta14d": "+X.X% | -X.X%",
      "interpretation": "Allocators rotating IN | OUT | STABLE"
    },
    {
      "metric": "BTC Dominance",
      "value": "XX.X%",
      "delta14d": "+X.Xpp | -X.Xpp",
      "interpretation": "Risk-on rotation | Flight to quality | Neutral"
    },
    {
      "metric": "Total Crypto MCap",
      "value": "$X.XXT",
      "delta14d": "+X.X% | -X.X%",
      "interpretation": "New capital entering | Capital leaving | Redistribution"
    },
    {
      "metric": "Stablecoin Supply",
      "value": "$XXXB",
      "delta14d": "+$X.XB | -$X.XB",
      "interpretation": "Dry powder building | Exiting | Deployed"
    },
    {
      "metric": "BTC Funding Rate (8h)",
      "value": "X.XXX%",
      "delta14d": "+Xbps | -Xbps",
      "interpretation": "Longs crowded | Shorts crowded | Balanced"
    },
    {
      "metric": "BTC Open Interest",
      "value": "$XXB",
      "delta14d": "+X.X% | -X.X%",
      "interpretation": "Leverage building | Deleveraging | Stable positioning"
    },
    {
      "metric": "Fear & Greed Index",
      "value": "XX",
      "delta14d": "+X | -X",
      "interpretation": "Contrarian BUY zone | Contrarian SELL zone | Neutral"
    },
    {
      "metric": "ETF Net Flow (14d)",
      "value": "+$XXXM | -$XXXM",
      "delta14d": "vs prior 14d: +X% | -X%",
      "interpretation": "Institutional accumulating | Distributing | Flat"
    },
    {
      "metric": "DeFi TVL",
      "value": "$XXB",
      "delta14d": "+X.X% | -X.X%",
      "interpretation": "Capital deployed on-chain | Exiting DeFi | Stable"
    }
  ],
  
  "keySignals": {
    "bullish": ["Metric X at Y implies Z"],
    "bearish": ["Metric X at Y implies Z"],
    "neutral": ["Metric X at Y implies Z"]
  },
  
  "dashboardVerdict": "ONE SENTENCE: What the dashboard tells us to do"
}

Return valid JSON only.`;

    const userPrompt = `All Market Data:
${JSON.stringify(allData, null, 2)}

Generate dashboard with 14D changes.`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 3000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      });

      const text = response.content[0].text;
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Failed to parse dashboard JSON');
    } catch (error) {
      console.error('Dashboard error:', error);
      return null;
    }
  }
}

export { CryptoAIService };