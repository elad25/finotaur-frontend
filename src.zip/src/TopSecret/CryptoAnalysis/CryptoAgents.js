// =====================================================
// CRYPTO ANALYSIS AGENTS v6.0 - PERFECT INSTITUTIONAL REPORT
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/CryptoAgents.js
//
// מבנה הדוח המושלם (דו־שבועי, 8–12 עמודים / 10–15 דקות קריאה)
// 
// IMPLEMENTS 13-SECTION INSTITUTIONAL REPORT FORMAT:
// Section 0:  Cover - Report name, date, promise, disclaimer
// Section 1:  Executive Decision Brief - Regime, flip triggers, top 5 takeaways
// Section 2:  Price & Structure Snapshot - BTC/ETH 14D, dominance, key levels
// Section 3:  Liquidity & Risk Dashboard - Volatility, stablecoins, stress signals
// Section 4:  Derivatives & Positioning - Funding, OI, liquidations, basis
// Section 5:  Flows & Supply Pressure - Exchange flows, ETF, unlocks
// Section 6:  Sector Rotation Map - L1/L2/DeFi/AI/Gaming/Memes performance
// Section 7:  Narratives That Moved Price - Signal vs noise analysis
// Section 8:  Catalyst Calendar (14D Forward) - Macro, crypto, unlocks
// Section 9:  Trade Setup Playbook - 3-7 ideas with thesis & invalidation
// Section 10: Risk Management & Psychology - Mistakes, sizing, checklist
// Section 11: Watchlist - 10-20 assets by category
// Section 12: Data Appendix - Sources, definitions, methodology
// Section 13: Legal Disclaimer - Not financial advice
//
// STRUCTURE RULES:
// - Every section ends with "So what" (actionable)
// - Consistent template across reports
// - No invented precision - use [DATA NOT AVAILABLE FREE] if missing
// - Use proxies where direct data unavailable
// =====================================================

import { PHASES, TOP_CRYPTO_ASSETS, ALTCOIN_DD_CHECKLIST, CRYPTO_SECTORS } from './config.js';

// ============================================
// DATA TAGS - שקיפות לגבי מקור הנתונים
// ============================================

const DATA_TAGS = {
  DATA_REQUIRED: '[DATA REQUIRED]',
  SOURCE_REQUIRED: '[SOURCE REQUIRED]',
  ON_CHAIN_LIMITATION: '[ON-CHAIN LIMITATION]',
  INFERRED: '[INFERRED]',
  TIMING_UNCERTAIN: '[TIMING UNCERTAIN]',
  OPTIONS_REQUIRED: '[OPTIONS DATA REQUIRED]',
  ANALYSIS_REQUIRED: '[ANALYSIS REQUIRED]',
  FREE_DATA_UNAVAILABLE: '[FREE DATA UNAVAILABLE]',
  PROXY_USED: '[PROXY]',
  ETF_FROM_NEWS: '[ETF DATA FROM NEWS SOURCES]',
  DELAYED_DATA: '[DATA MAY BE DELAYED]',
};

// ============================================
// SYSTEM PROMPTS - הנחיות מערכת לכל הסוכנים
// ============================================

const SYSTEM_PROMPTS = {
  BASE: `You are an institutional-grade crypto analyst writing for sophisticated traders and portfolio managers.
Your analysis must be:
- Data-driven: Every claim backed by specific numbers from the provided data
- Actionable: Every section ends with "So what" - a concrete action item
- Honest about limitations: Use [FREE DATA UNAVAILABLE] or [PROXY] tags when appropriate
- No hype, no FUD: Balanced, professional tone
- Precise but not false precision: Round appropriately, don't invent decimal places
- Hebrew-friendly: Asset names in English, analysis can mix`,

  FORMATTING: `Output ONLY valid JSON. No markdown, no explanations, no preamble.
If a field cannot be determined from available data, use null or the appropriate DATA TAG.
Numbers should be formatted consistently: percentages with 1-2 decimals, USD with appropriate precision.`,

  REGIME_SCORING: `REGIME SCORING METHODOLOGY:
Score 0-100 based on weighted inputs:
- Price Structure (30%): Trend, key levels, momentum
- Positioning (35%): Funding, OI, long/short ratio  
- Flows (20%): Stablecoins, ETF flows (if available)
- Sentiment (15%): Fear & Greed, social metrics

REGIME LABELS:
- RISK-ON (70-100): Strong bullish, increasing risk appetite
- TRANSITIONAL-BULLISH (55-69): Improving conditions, cautious optimism
- NEUTRAL (45-54): Range-bound, no clear direction
- TRANSITIONAL-BEARISH (30-44): Deteriorating, increasing caution
- RISK-OFF (0-29): Bearish, risk aversion, deleveraging`,
};

// ============================================
// AGENT DEFINITIONS (25 Agents)
// ============================================

const AGENT_DEFINITIONS = [
  // ========== PHASE 1: DATA ACQUISITION (3 agents) ==========
  {
    id: 'market_data_fetcher',
    name: 'Market Data Fetcher',
    description: 'Fetches price, volume, market cap, 14D changes from CoinGecko + Binance',
    phase: PHASES.DATA_ACQUISITION,
    order: 1,
    dependencies: [],
    estimatedSeconds: 20,
    usesAI: false,
    section: null, // Data layer
  },
  {
    id: 'onchain_data_fetcher',
    name: 'On-Chain Data Fetcher',
    description: 'Fetches stablecoin supply, DeFi TVL, Bitcoin metrics from DeFiLlama',
    phase: PHASES.DATA_ACQUISITION,
    order: 2,
    dependencies: [],
    estimatedSeconds: 25,
    usesAI: false,
    section: null,
  },
  {
    id: 'derivatives_data_fetcher',
    name: 'Derivatives Data Fetcher',
    description: 'Fetches funding rates, OI, liquidations, long/short ratios from Binance Futures',
    phase: PHASES.DATA_ACQUISITION,
    order: 3,
    dependencies: [],
    estimatedSeconds: 20,
    usesAI: false,
    section: null,
  },

  // ========== PHASE 2: EXECUTIVE BRIEF - Section 1 (3 agents) ==========
  {
    id: 'regime_detector',
    name: 'Market Regime Detector',
    description: 'Identifies current regime: Risk-On/Risk-Off/Transitional/Distribution with confidence score',
    phase: PHASES.EXECUTIVE_BRIEF,
    order: 4,
    dependencies: ['market_data_fetcher', 'derivatives_data_fetcher', 'onchain_data_fetcher'],
    estimatedSeconds: 35,
    usesAI: true,
    section: 1,
  },
  {
    id: 'regime_flip_analyzer',
    name: 'Regime Flip Trigger Analyzer',
    description: 'Identifies specific binary conditions that would flip the regime',
    phase: PHASES.EXECUTIVE_BRIEF,
    order: 5,
    dependencies: ['regime_detector', 'market_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 1,
  },
  {
    id: 'top5_takeaways_generator',
    name: 'Top 5 Takeaways Generator',
    description: 'Generates top 5 PM-grade takeaways in fixed format: Observation→So what→Who→Watch',
    phase: PHASES.EXECUTIVE_BRIEF,
    order: 6,
    dependencies: ['regime_detector', 'market_data_fetcher', 'derivatives_data_fetcher'],
    estimatedSeconds: 40,
    usesAI: true,
    section: 1,
  },

  // ========== PHASE 3: PRICE & STRUCTURE - Section 2 (2 agents) ==========
  {
    id: 'price_structure_analyzer',
    name: 'Price & Structure Snapshot',
    description: 'BTC/ETH 14D return, range, ATR proxy, trend state, key support/resistance levels',
    phase: PHASES.PRICE_STRUCTURE,
    order: 7,
    dependencies: ['market_data_fetcher'],
    estimatedSeconds: 35,
    usesAI: true,
    section: 2,
  },
  {
    id: 'dominance_analyzer',
    name: 'Dominance & Alt Index Analyzer',
    description: 'BTC.D, ETH.D 14D changes, top 30 alts median return, rotation signals',
    phase: PHASES.PRICE_STRUCTURE,
    order: 8,
    dependencies: ['market_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 2,
  },

  // ========== PHASE 4: LIQUIDITY & RISK - Section 3 (2 agents) ==========
  {
    id: 'volatility_regime_analyzer',
    name: 'Volatility Regime Analyzer',
    description: 'Realized vol, ATR proxies, vol regime classification, compression/expansion signals',
    phase: PHASES.LIQUIDITY_RISK,
    order: 9,
    dependencies: ['market_data_fetcher', 'derivatives_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 3,
  },
  {
    id: 'liquidity_stress_analyzer',
    name: 'Liquidity Stress Signal Analyzer',
    description: 'Stablecoins pulse, funding spikes, liquidation clusters, OI/price divergence, market health score',
    phase: PHASES.LIQUIDITY_RISK,
    order: 10,
    dependencies: ['onchain_data_fetcher', 'derivatives_data_fetcher'],
    estimatedSeconds: 35,
    usesAI: true,
    section: 3,
  },

  // ========== PHASE 5: DERIVATIVES & POSITIONING - Section 4 (3 agents) ==========
  {
    id: 'funding_analyzer',
    name: 'Funding Rate Analyzer',
    description: 'BTC/ETH/SOL funding with annualized rates, trend, crowded signal detection',
    phase: PHASES.DERIVATIVES_POSITIONING,
    order: 11,
    dependencies: ['derivatives_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 4,
  },
  {
    id: 'oi_analyzer',
    name: 'Open Interest Analyzer',
    description: 'OI trends, OI/Price divergence analysis, leverage fragility assessment',
    phase: PHASES.DERIVATIVES_POSITIONING,
    order: 12,
    dependencies: ['derivatives_data_fetcher', 'market_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 4,
  },
  {
    id: 'liquidation_mapper',
    name: 'Liquidation Mapper',
    description: 'Liquidation zones, forced actor analysis, cascade risk assessment',
    phase: PHASES.DERIVATIVES_POSITIONING,
    order: 13,
    dependencies: ['derivatives_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 4,
  },

  // ========== PHASE 6: FLOWS & SUPPLY - Section 5 (2 agents) ==========
  {
    id: 'flows_analyzer',
    name: 'Flows Analyzer',
    description: 'Exchange reserves proxy, ETF flows (from news), stablecoin deployment patterns',
    phase: PHASES.FLOWS_SUPPLY,
    order: 14,
    dependencies: ['onchain_data_fetcher', 'market_data_fetcher'],
    estimatedSeconds: 35,
    usesAI: true,
    section: 5,
  },
  {
    id: 'token_unlocks_analyzer',
    name: 'Token Unlocks Analyzer',
    description: '14-day unlock calendar with % of ADV impact, supply pressure assessment',
    phase: PHASES.FLOWS_SUPPLY,
    order: 15,
    dependencies: ['market_data_fetcher'],
    estimatedSeconds: 30,
    usesAI: true,
    section: 5,
  },

  // ========== PHASE 7: SECTOR ROTATION - Section 6 (2 agents) ==========
  {
    id: 'sector_performance_analyzer',
    name: 'Sector Performance Analyzer',
    description: 'L1/L2/DeFi/AI/Gaming/Memes 14D performance table with narrative drivers',
    phase: PHASES.SECTOR_ROTATION,
    order: 16,
    dependencies: ['market_data_fetcher'],
    estimatedSeconds: 40,
    usesAI: true,
    section: 6,
  },
  {
    id: 'rotation_signal_analyzer',
    name: 'Rotation Signal Analyzer',
    description: 'Identifies sector rotation direction, strength, and what would change it',
    phase: PHASES.SECTOR_ROTATION,
    order: 17,
    dependencies: ['sector_performance_analyzer', 'market_data_fetcher'],
    estimatedSeconds: 35,
    usesAI: true,
    section: 6,
  },

  // ========== PHASE 8: NARRATIVES - Section 7 (1 agent) ==========
  {
    id: 'narratives_analyzer',
    name: 'Narratives That Moved Price',
    description: 'Identifies 3-5 narratives that ACTUALLY caused price movement with data evidence',
    phase: PHASES.NARRATIVES,
    order: 18,
    dependencies: ['market_data_fetcher', 'sector_performance_analyzer'],
    estimatedSeconds: 45,
    usesAI: true,
    section: 7,
  },

  // ========== PHASE 9: CATALYST CALENDAR - Section 8 (1 agent) ==========
  {
    id: 'catalyst_calendar_generator',
    name: 'Catalyst Calendar Generator (14D)',
    description: 'Macro events, crypto upgrades, governance votes, unlocks, regulatory hearings with impact scores',
    phase: PHASES.CATALYST_CALENDAR,
    order: 19,
    dependencies: ['token_unlocks_analyzer', 'market_data_fetcher'],
    estimatedSeconds: 40,
    usesAI: true,
    section: 8,
  },

  // ========== PHASE 10: TRADE PLAYBOOK - Section 9-10 (2 agents) ==========
  {
    id: 'trade_idea_generator',
    name: 'Trade Idea Generator',
    description: 'Generates 3-7 trade ideas with thesis, entry conditions, invalidation, timing, risk note',
    phase: PHASES.TRADE_PLAYBOOK,
    order: 20,
    dependencies: ['regime_detector', 'price_structure_analyzer', 'sector_performance_analyzer', 'derivatives_data_fetcher'],
    estimatedSeconds: 50,
    usesAI: true,
    section: 9,
  },
  {
    id: 'risk_psychology_advisor',
    name: 'Risk Management & Psychology Advisor',
    description: 'Top 5 mistakes in current regime, position sizing, pre-entry checklist',
    phase: PHASES.TRADE_PLAYBOOK,
    order: 21,
    dependencies: ['regime_detector', 'volatility_regime_analyzer'],
    estimatedSeconds: 35,
    usesAI: true,
    section: 10,
  },

  // ========== PHASE 11: WATCHLIST - Section 11 (1 agent) ==========
  {
    id: 'watchlist_generator',
    name: 'Watchlist Generator',
    description: '10-20 assets divided: Momentum leaders, Mean reversion, Catalyst-driven',
    phase: PHASES.WATCHLIST,
    order: 22,
    dependencies: ['sector_performance_analyzer', 'catalyst_calendar_generator', 'market_data_fetcher'],
    estimatedSeconds: 40,
    usesAI: true,
    section: 11,
  },

  // ========== PHASE 12: QUALITY ASSURANCE (3 agents) ==========
  {
    id: 'coherence_checker',
    name: 'Coherence Checker',
    description: 'Checks for conflicting signals, data consistency, aligned signals',
    phase: PHASES.QUALITY_ASSURANCE,
    order: 23,
    dependencies: ['regime_detector', 'trade_idea_generator', 'funding_analyzer', 'flows_analyzer'],
    estimatedSeconds: 30,
    usesAI: true,
    section: null, // QA layer
  },
  {
    id: 'executive_summary_writer',
    name: 'Executive Summary Writer',
    description: 'Writes final executive brief synthesizing all analysis into coherent narrative',
    phase: PHASES.QUALITY_ASSURANCE,
    order: 24,
    dependencies: ['coherence_checker', 'top5_takeaways_generator', 'regime_flip_analyzer'],
    estimatedSeconds: 40,
    usesAI: true,
    section: 1, // Back to Executive Brief
  },
  {
    id: 'data_appendix_generator',
    name: 'Data Appendix Generator',
    description: 'Generates data sources list, definitions, methodology explanation, limitations',
    phase: PHASES.QUALITY_ASSURANCE,
    order: 25,
    dependencies: ['market_data_fetcher', 'derivatives_data_fetcher', 'onchain_data_fetcher'],
    estimatedSeconds: 15,
    usesAI: false,
    section: 12,
  },
];

// ============================================
// AGENT EXECUTOR FUNCTIONS
// ============================================

// ============================================
// Agent 1: Market Data Fetcher (No AI)
// ============================================
async function executeMarketDataFetcher(context) {
  const startTime = Date.now();
  try {
    const { dataService } = context;
    const data = await dataService.fetchAllMarketData();
    
    return {
      success: true,
      data,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { 
      success: false, 
      data: null, 
      error: error.message, 
      duration: Date.now() - startTime 
    };
  }
}

// ============================================
// Agent 2: On-Chain Data Fetcher (No AI)
// ============================================
async function executeOnchainDataFetcher(context) {
  const startTime = Date.now();
  try {
    const { dataService } = context;
    
    const [stablecoins, tvl, bitcoinOnChain] = await Promise.all([
      dataService.fetchDefiLlamaStablecoins(),
      dataService.fetchDefiLlamaTVL(),
      dataService.fetchBitcoinOnChainData(),
    ]);
    
    return {
      success: true,
      data: {
        stablecoins,
        tvl,
        bitcoinOnChain,
        source: 'DeFiLlama + Blockchain.com',
        fetchedAt: new Date().toISOString(),
      },
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { 
      success: false, 
      data: null, 
      error: error.message, 
      duration: Date.now() - startTime 
    };
  }
}

// ============================================
// Agent 3: Derivatives Data Fetcher (No AI)
// ============================================
async function executeDerivativesDataFetcher(context) {
  const startTime = Date.now();
  try {
    const { dataService } = context;
    const data = await dataService.fetchAllDerivativesData();
    
    return {
      success: true,
      data,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { 
      success: false, 
      data: null, 
      error: error.message, 
      duration: Date.now() - startTime 
    };
  }
}

// ============================================
// Agent 4: Market Regime Detector (AI)
// Section 1: Executive Decision Brief
// ============================================
async function executeRegimeDetector(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const marketData = context.results.market_data_fetcher?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    const onchainData = context.results.onchain_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

${SYSTEM_PROMPTS.REGIME_SCORING}

TASK: Analyze current market regime based on the following data.

=== MARKET DATA (14-Day Window: ${windowStart} to ${windowEnd}) ===
${JSON.stringify(marketData, null, 2)}

=== DERIVATIVES DATA ===
${JSON.stringify(derivativesData, null, 2)}

=== ON-CHAIN DATA ===
${JSON.stringify(onchainData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "regime": "RISK-ON | TRANSITIONAL-BULLISH | NEUTRAL | TRANSITIONAL-BEARISH | RISK-OFF",
  "score": <0-100>,
  "confidence": "High | Medium | Low",
  "confidenceReason": "Why this confidence level",
  
  "inputs": {
    "priceStructure": {
      "weight": 30,
      "btcTrend": "uptrend | range | downtrend",
      "btc14dReturn": "+X.X%",
      "btcVsATH": "X% from ATH",
      "ethTrend": "uptrend | range | downtrend",
      "eth14dReturn": "+X.X%",
      "signal": "bullish | neutral | bearish",
      "score": <0-100>
    },
    "positioning": {
      "weight": 35,
      "btcFunding8h": "X.XXXX%",
      "btcFundingAnnualized": "XX.X%",
      "oiTrend": "rising | falling | flat",
      "oi14dChange": "+X.X%",
      "longShortRatio": "X.XX",
      "signal": "crowded long | crowded short | balanced",
      "score": <0-100>
    },
    "flows": {
      "weight": 20,
      "stablecoinChange14d": "+X.X%",
      "stablecoinTotalB": "$XXXB",
      "etfFlows14d": "+$XXM or [ETF DATA FROM NEWS SOURCES]",
      "signal": "inflows | outflows | neutral",
      "score": <0-100>
    },
    "sentiment": {
      "weight": 15,
      "fearGreedIndex": <0-100>,
      "fearGreedLabel": "Extreme Fear | Fear | Neutral | Greed | Extreme Greed",
      "socialSentiment": "bullish | neutral | bearish or [FREE DATA UNAVAILABLE]",
      "score": <0-100>
    }
  },
  
  "regimeHistory": {
    "currentDuration": "X days in current regime",
    "previousRegime": "Previous regime before this",
    "transitionDate": "Approximate date regime changed"
  },
  
  "interpretation": "2-3 sentences explaining the regime and why. Be specific about which inputs are most influential.",
  
  "soWhat": "ONE actionable sentence: what should traders do in this specific regime. Be specific."
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 5: Regime Flip Trigger Analyzer (AI)
// Section 1: Executive Decision Brief
// ============================================
async function executeRegimeFlipAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const regime = context.results.regime_detector?.data;
    const marketData = context.results.market_data_fetcher?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Identify BINARY (yes/no) conditions that would flip the current market regime.
"What would flip the regime" - תנאים בינאריים ברורים שאם יתקיימו, התזה מתהפכת.

CRITICAL RULES:
- Triggers must be BINARY (yes/no), not vague like "watch for reversal"
- Include specific price levels, percentages, or measurable conditions
- Each trigger should be verifiable within 24-48 hours of occurring

CURRENT REGIME:
${JSON.stringify(regime, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

DERIVATIVES DATA:
${JSON.stringify(derivativesData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "currentRegime": "${regime?.regime || 'UNKNOWN'}",
  "currentScore": ${regime?.score || 50},
  
  "flipToRiskOn": {
    "targetRegime": "RISK-ON or TRANSITIONAL-BULLISH",
    "primaryCondition": "BTC daily close > $XXK AND [specific condition]",
    "secondaryConditions": [
      "Funding rate stays below X%",
      "OI continues building without liquidation cascade"
    ],
    "currentDistance": "X% away from primary condition",
    "likelihood": "High | Medium | Low",
    "likelihoodReason": "Why this likelihood",
    "timeframe": "Could occur within X days if momentum continues"
  },
  
  "flipToRiskOff": {
    "targetRegime": "RISK-OFF or TRANSITIONAL-BEARISH",
    "primaryCondition": "BTC daily close < $XXK OR [specific condition]",
    "secondaryConditions": [
      "Funding rate spikes above X%",
      "Major liquidation cascade > $XXM"
    ],
    "currentDistance": "X% away from primary condition",
    "likelihood": "High | Medium | Low",
    "likelihoodReason": "Why this likelihood",
    "timeframe": "Could occur within X days if conditions deteriorate"
  },
  
  "triggerList": [
    {
      "id": 1,
      "trigger": "Specific binary condition with numbers",
      "direction": "bullish | bearish",
      "impact": "Would flip regime from X to Y",
      "monitoringMetric": "What to watch",
      "currentValue": "Current value of the metric"
    },
    {
      "id": 2,
      "trigger": "Another specific condition",
      "direction": "bullish | bearish",
      "impact": "Description",
      "monitoringMetric": "What to watch",
      "currentValue": "Current value"
    },
    {
      "id": 3,
      "trigger": "Third condition",
      "direction": "bullish | bearish",
      "impact": "Description",
      "monitoringMetric": "What to watch",
      "currentValue": "Current value"
    }
  ],
  
  "nearTermOutlook": {
    "mostLikelyScenario": "Description of most likely path",
    "probability": "X%",
    "alternativeScenario": "What could derail this",
    "alternativeProbability": "X%"
  },
  
  "soWhat": "ONE sentence: what specific price level or event should traders watch most closely for regime change"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 6: Top 5 Takeaways Generator (AI)
// Section 1: Executive Decision Brief
// ============================================
async function executeTop5TakeawaysGenerator(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const regime = context.results.regime_detector?.data;
    const marketData = context.results.market_data_fetcher?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Generate exactly 5 PM-GRADE takeaways in FIXED FORMAT.
These are the top 5 things a portfolio manager needs to know from the last 14 days.

FIXED FORMAT FOR EACH TAKEAWAY (חובה):
1. Observation: What we saw (factual, specific, one sentence with numbers)
2. So what: Why it matters (positioning-centric, actionable implication)
3. Who's impacted: Specific group (leveraged longs / spot holders / funds / retail / miners)
4. What to watch: Binary trigger to monitor next 14 days

WINDOW: ${windowStart} to ${windowEnd}

REGIME: ${JSON.stringify(regime, null, 2)}
MARKET: ${JSON.stringify(marketData, null, 2)}
DERIVATIVES: ${JSON.stringify(derivativesData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "takeaways": [
    {
      "number": 1,
      "observation": "Factual observation with specific numbers (e.g., 'BTC funding hit 0.08% 8h (87% annualized) on Tuesday before dropping 50%')",
      "soWhat": "Why this matters for positioning (e.g., 'Extreme funding historically precedes 5-15% corrections within 7 days')",
      "whosImpacted": "Specific group most affected (e.g., 'Leveraged longs opened above $100K are at highest risk')",
      "whatToWatch": "Binary condition to monitor (e.g., 'Daily close below $95K would confirm correction thesis')",
      "signal": "bullish | neutral | bearish",
      "importance": "critical | high | medium"
    },
    {
      "number": 2,
      "observation": "Second factual observation",
      "soWhat": "Why it matters",
      "whosImpacted": "Who's affected",
      "whatToWatch": "What to monitor",
      "signal": "bullish | neutral | bearish",
      "importance": "critical | high | medium"
    },
    {
      "number": 3,
      "observation": "Third factual observation",
      "soWhat": "Why it matters",
      "whosImpacted": "Who's affected",
      "whatToWatch": "What to monitor",
      "signal": "bullish | neutral | bearish",
      "importance": "critical | high | medium"
    },
    {
      "number": 4,
      "observation": "Fourth factual observation",
      "soWhat": "Why it matters",
      "whosImpacted": "Who's affected",
      "whatToWatch": "What to monitor",
      "signal": "bullish | neutral | bearish",
      "importance": "critical | high | medium"
    },
    {
      "number": 5,
      "observation": "Fifth factual observation",
      "soWhat": "Why it matters",
      "whosImpacted": "Who's affected",
      "whatToWatch": "What to monitor",
      "signal": "bullish | neutral | bearish",
      "importance": "critical | high | medium"
    }
  ],
  
  "oneChartThatMatters": {
    "chart": "Price + Funding overlay | OI vs Price | Liquidation heatmap | BTC.D | Other",
    "chartType": "line | bar | heatmap | area",
    "why": "One sentence why this specific chart is the most important to watch right now",
    "keyLevel": "Specific level or pattern to watch on the chart"
  },
  
  "summarySignal": {
    "overall": "bullish | neutral | bearish",
    "bullishCount": <number>,
    "bearishCount": <number>,
    "mostCritical": "Which takeaway is most time-sensitive"
  }
}`;

    const result = await aiService.complete(prompt, { temperature: 0.4 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 7: Price & Structure Snapshot (AI)
// Section 2: Price & Structure
// ============================================
async function executePriceStructureAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const marketData = context.results.market_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Generate Price & Structure Snapshot for Section 2.
מטרה: "איפה אנחנו נמצאים" בלי אינדיקטורים מיותרים.

PURPOSE: Give traders a clear picture of where we are structurally.
- Focus on key levels that matter for decision-making
- Include 14D range, ATR-like volatility proxy, trend state
- Identify breakout/breakdown levels

WINDOW: ${windowStart} to ${windowEnd}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "btc": {
    "currentPrice": "$XX,XXX",
    "return14d": "+X.X%",
    "return7d": "+X.X%",
    "range14d": {
      "high": "$XX,XXX",
      "low": "$XX,XXX",
      "rangePercent": "X.X%"
    },
    "atrProxy": {
      "value": "X.X%",
      "interpretation": "Average daily range suggesting volatility level"
    },
    "trendState": {
      "current": "UPTREND | RANGE | DOWNTREND",
      "strength": "Strong | Moderate | Weak",
      "duration": "X days in current trend"
    },
    "keyLevels": {
      "support1": {
        "level": "$XX,XXX",
        "reason": "Why this level matters (e.g., 14D low, previous resistance turned support)",
        "distance": "X.X% below current"
      },
      "support2": {
        "level": "$XX,XXX",
        "reason": "Secondary support",
        "distance": "X.X% below current"
      },
      "resistance1": {
        "level": "$XX,XXX",
        "reason": "Why this level matters",
        "distance": "X.X% above current"
      },
      "resistance2": {
        "level": "$XX,XXX",
        "reason": "Secondary resistance",
        "distance": "X.X% above current"
      },
      "breakoutLevel": {
        "level": "$XX,XXX",
        "whatHappensIfBroken": "Description of expected move if this level breaks"
      },
      "breakdownLevel": {
        "level": "$XX,XXX",
        "whatHappensIfBroken": "Description of expected move if this level breaks"
      }
    },
    "vsATH": {
      "ath": "$XX,XXX",
      "distance": "X.X% from ATH",
      "athDate": "YYYY-MM-DD"
    }
  },
  
  "eth": {
    "currentPrice": "$X,XXX",
    "return14d": "+X.X%",
    "return7d": "+X.X%",
    "ethBtcRatio": {
      "current": "0.XXXX",
      "change14d": "+X.X%",
      "trend": "ETH outperforming | underperforming | in line"
    },
    "trendState": {
      "current": "UPTREND | RANGE | DOWNTREND",
      "strength": "Strong | Moderate | Weak"
    },
    "keyLevels": {
      "support": "$X,XXX",
      "resistance": "$X,XXX",
      "ethBtcSupport": "0.XXXX",
      "ethBtcResistance": "0.XXXX"
    }
  },
  
  "dominance": {
    "btcD": {
      "current": "XX.X%",
      "change14d": "+X.Xpp",
      "trend": "Rising | Falling | Stable"
    },
    "ethD": {
      "current": "XX.X%",
      "change14d": "+X.Xpp",
      "trend": "Rising | Falling | Stable"
    },
    "othersShare": "XX.X%",
    "interpretation": "Flight to quality | Risk-on rotation to alts | Neutral"
  },
  
  "altIndex": {
    "method": "Top 30 alts by market cap, median 14D return",
    "medianReturn14d": "+X.X%",
    "vsBTC": "Alts outperforming BTC by X.X% | Alts lagging BTC by X.X% | In line",
    "dispersion": {
      "level": "High | Medium | Low",
      "meaning": "Explanation of what dispersion tells us"
    }
  },
  
  "structureSummary": {
    "primaryTrend": "Description of dominant structure",
    "keyObservation": "Most important structural observation",
    "risk": "Main structural risk"
  },
  
  "soWhat": "ONE sentence: what this price structure tells us to do (e.g., 'Structure favors buying dips to $XX,XXX with stops below $XX,XXX')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 8: Dominance & Alt Index Analyzer (AI)
// Section 2: Price & Structure
// ============================================
async function executeDominanceAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const marketData = context.results.market_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze dominance shifts and alt performance for rotation signals.

WINDOW: ${windowStart} to ${windowEnd}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "dominanceAnalysis": {
    "btcDominance": {
      "current": "XX.X%",
      "change14d": "+X.Xpp",
      "change30d": "+X.Xpp or [DATA NOT AVAILABLE]",
      "trend": "Rising | Falling | Stable",
      "trendStrength": "Strong | Moderate | Weak"
    },
    "ethDominance": {
      "current": "XX.X%",
      "change14d": "+X.Xpp",
      "trend": "Rising | Falling | Stable"
    },
    "stablecoinDominance": {
      "current": "XX.X%",
      "change14d": "+X.Xpp",
      "interpretation": "Cash on sidelines increasing | Capital deploying | Neutral"
    },
    "othersShare": {
      "current": "XX.X%",
      "change14d": "+X.Xpp"
    }
  },
  
  "altIndex": {
    "methodology": "Top 30 altcoins by market cap excluding stablecoins",
    "medianReturn14d": "+X.X%",
    "meanReturn14d": "+X.X%",
    "topPerformers": [
      {"token": "TOKEN1", "return14d": "+XX.X%", "reason": "Brief catalyst/reason"},
      {"token": "TOKEN2", "return14d": "+XX.X%", "reason": "Brief catalyst/reason"},
      {"token": "TOKEN3", "return14d": "+XX.X%", "reason": "Brief catalyst/reason"}
    ],
    "worstPerformers": [
      {"token": "TOKEN1", "return14d": "-XX.X%", "reason": "Brief reason"},
      {"token": "TOKEN2", "return14d": "-XX.X%", "reason": "Brief reason"},
      {"token": "TOKEN3", "return14d": "-XX.X%", "reason": "Brief reason"}
    ],
    "dispersion": {
      "level": "High | Medium | Low",
      "stdDev": "X.X%",
      "interpretation": "High dispersion = selective market | Low dispersion = risk-on/off broad move"
    }
  },
  
  "rotationSignal": {
    "detected": true | false,
    "direction": "Into BTC | Into ETH | Into large caps | Into small caps | Into alts broadly | No clear rotation",
    "strength": "Strong | Moderate | Weak",
    "evidence": [
      "Evidence point 1 with specific data",
      "Evidence point 2"
    ],
    "phase": "Early | Mid | Late | Exhaustion"
  },
  
  "cyclicalContext": {
    "btcDominanceCyclePhase": "Accumulation (BTC.D rising) | Alt season (BTC.D falling) | Transition",
    "typicalPattern": "Description of what typically happens from here in the cycle",
    "timeInPhase": "Approximately X weeks/months in current phase"
  },
  
  "soWhat": "ONE sentence: what dominance tells us about positioning (e.g., 'Rising BTC.D suggests staying in majors until BTC.D peaks above 60%')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 9: Volatility Regime Analyzer (AI)
// Section 3: Liquidity & Risk Dashboard
// ============================================
async function executeVolatilityRegimeAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const marketData = context.results.market_data_fetcher?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze volatility regime for Section 3 - Liquidity & Risk Dashboard.
מטרה: להבין אם זה שוק "בריא" או שוק "מלכודות".

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

DERIVATIVES:
${JSON.stringify(derivativesData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "volatilityRegime": {
    "state": "LOW_VOL | NORMAL | ELEVATED | EXTREME",
    "score": <0-100>,
    "realizedVol14d": {
      "btc": "XX.X% annualized",
      "eth": "XX.X% annualized"
    },
    "atrProxy": {
      "btc": "X.X% average daily range",
      "eth": "X.X% average daily range"
    },
    "trend": "Expanding | Contracting | Stable",
    "trendDuration": "Vol has been X for Y days"
  },
  
  "volComparison": {
    "vs30dAvg": "Current vol is X% above/below 30D average or [DATA NOT AVAILABLE]",
    "vs90dAvg": "Current vol is X% above/below 90D average or [DATA NOT AVAILABLE]",
    "percentile": "Current vol is in Xth percentile of last 90 days or [DATA NOT AVAILABLE]"
  },
  
  "volSignals": {
    "compression": {
      "detected": true | false,
      "evidence": "Description if detected",
      "meaning": "Vol compression often precedes large moves, direction unclear",
      "historicalOutcome": "Last X compressions led to Y% moves within Z days"
    },
    "expansion": {
      "detected": true | false,
      "evidence": "Description if detected",
      "meaning": "Vol expansion suggests trend likely to continue or exhaust",
      "exhaustionRisk": "High | Medium | Low"
    }
  },
  
  "impliedVsForecast": {
    "available": false,
    "note": "[OPTIONS DATA REQUIRED] - Implied vol from Deribit not available"
  },
  
  "implications": {
    "forDirectionalTraders": {
      "longs": "Specific implication for long positions",
      "shorts": "Specific implication for short positions"
    },
    "forRangeTraders": "Specific implication for range trading strategies",
    "positionSizing": "Suggested position size adjustment based on current vol"
  },
  
  "volRegimeHistory": {
    "daysInCurrentRegime": <number>,
    "previousRegime": "Previous vol regime",
    "transitionTrigger": "What caused the transition or [ANALYSIS REQUIRED]"
  },
  
  "soWhat": "ONE sentence: what volatility regime tells us about position sizing and strategy (e.g., 'Compressed vol suggests reducing position size and waiting for direction confirmation')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 10: Liquidity Stress Signal Analyzer (AI)
// Section 3: Liquidity & Risk Dashboard
// ============================================
async function executeLiquidityStressAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const onchainData = context.results.onchain_data_fetcher?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze liquidity conditions and stress signals.
מטרה: להבין אם זה שוק "בריא" או שוק "מלכודות".

ON-CHAIN DATA:
${JSON.stringify(onchainData, null, 2)}

DERIVATIVES:
${JSON.stringify(derivativesData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "stablecoinPulse": {
    "totalSupply": "$XXXB",
    "change14d": {
      "absolute": "+$X.XB",
      "percent": "+X.X%"
    },
    "breakdown": {
      "usdt": {"supply": "$XXB", "share": "XX%", "change14d": "+X.X%"},
      "usdc": {"supply": "$XXB", "share": "XX%", "change14d": "+X.X%"},
      "others": {"supply": "$XXB", "share": "XX%"}
    },
    "interpretation": "Dry powder building | Capital exiting | Deployed into risk | Stable",
    "significantMoves": "Any notable minting/burning events"
  },
  
  "liquidityStressSignals": {
    "fundingSpikes": {
      "detected": true | false,
      "severity": "None | Minor | Moderate | Severe",
      "details": "Description with specific numbers if detected",
      "peakFunding": "X.XX% 8h on DATE",
      "interpretation": "What this means for market structure"
    },
    "liquidationClusters": {
      "detected": true | false,
      "severity": "None | Minor | Moderate | Severe",
      "last24h": {
        "total": "$XXXM",
        "longs": "$XXXM",
        "shorts": "$XXXM"
      },
      "largest": "Largest single liquidation event with details",
      "interpretation": "What recent liquidations tell us"
    },
    "oiPriceDivergence": {
      "detected": true | false,
      "type": "None | OI up + Price flat (fragile) | OI down + Price up (healthy) | OI down + Price down (deleveraging)",
      "details": "Specific description",
      "risk": "High | Medium | Low",
      "interpretation": "What this divergence suggests"
    }
  },
  
  "marketHealth": {
    "score": <0-100>,
    "label": "HEALTHY | CAUTION | STRESSED | TRAP",
    "components": {
      "fundingHealth": {"score": <0-100>, "status": "Healthy | Elevated | Extreme"},
      "liquidityDepth": {"score": <0-100>, "status": "Deep | Adequate | Thin"},
      "leverageLevel": {"score": <0-100>, "status": "Low | Moderate | High | Extreme"}
    },
    "mainRisk": "Primary risk to current market structure",
    "secondaryRisk": "Secondary risk to watch"
  },
  
  "trapIndicators": {
    "bullTrap": {
      "risk": "High | Medium | Low",
      "evidence": "Description if risk is elevated"
    },
    "bearTrap": {
      "risk": "High | Medium | Low",
      "evidence": "Description if risk is elevated"
    },
    "squeezeRisk": {
      "longSqueeze": "High | Medium | Low",
      "shortSqueeze": "High | Medium | Low"
    }
  },
  
  "soWhat": "ONE sentence: is this a safe or dangerous market to trade (e.g., 'Elevated funding and OI divergence suggest reducing leverage and tightening stops')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 11: Funding Rate Analyzer (AI)
// Section 4: Derivatives & Positioning
// ============================================
async function executeFundingAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze funding rates for Section 4 - Derivatives & Positioning.
מטרה: להבין את המשחק של הלברג'.

CRITICAL FUNDING MATH:
8h rate × 3 × 365 = annualized rate
Example: 0.01% × 3 × 365 = 10.95% annualized
Example: 0.05% × 3 × 365 = 54.75% annualized (EXTREME)

THRESHOLDS:
- Extreme positive: > 0.05% 8h (> 55% annualized) = Crowded long, correction likely
- High positive: 0.03-0.05% 8h (33-55% annualized) = Getting crowded
- Neutral: -0.01% to 0.03% 8h = Balanced
- Negative: < -0.01% 8h = Shorts paying, bullish signal

DERIVATIVES DATA:
${JSON.stringify(derivativesData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "funding": {
    "btc": {
      "current8h": "X.XXXX%",
      "annualized": "XX.X%",
      "trend14d": "Rising | Falling | Stable",
      "avg14d": "X.XXXX% 8h",
      "peak14d": {"rate": "X.XXXX%", "date": "YYYY-MM-DD"},
      "trough14d": {"rate": "X.XXXX%", "date": "YYYY-MM-DD"},
      "signal": "CROWDED LONG | GETTING CROWDED | BALANCED | SHORTS PAYING"
    },
    "eth": {
      "current8h": "X.XXXX%",
      "annualized": "XX.X%",
      "trend14d": "Rising | Falling | Stable",
      "avg14d": "X.XXXX% 8h",
      "signal": "CROWDED LONG | GETTING CROWDED | BALANCED | SHORTS PAYING"
    },
    "sol": {
      "current8h": "X.XXXX%",
      "annualized": "XX.X%",
      "trend14d": "Rising | Falling | Stable",
      "signal": "CROWDED LONG | GETTING CROWDED | BALANCED | SHORTS PAYING"
    },
    "topAlt": {
      "token": "TOKEN with highest funding",
      "current8h": "X.XXXX%",
      "annualized": "XX.X%",
      "note": "Why this is notable"
    }
  },
  
  "extremeCheck": {
    "isExtreme": true | false,
    "direction": "Positive | Negative | None",
    "assets": ["List of assets with extreme funding"],
    "interpretation": "What extreme funding means for positioning",
    "historicalContext": "What typically happens after similar funding levels"
  },
  
  "fundingVsPrice": {
    "divergence": {
      "detected": true | false,
      "type": "Rising funding + flat price (bearish) | Falling funding + rising price (healthy) | None",
      "interpretation": "What this means"
    },
    "correlation14d": "Positive | Negative | Weak"
  },
  
  "interpretationTable": [
    {
      "scenario": "Current scenario from data",
      "setup": "Funding X + OI Y + Price Z",
      "meaning": "What this combination tells us",
      "historicalOutcome": "What typically follows",
      "applies": true | false
    }
  ],
  
  "fundingArbitrage": {
    "opportunity": true | false,
    "spread": "X.XX% annualized between venues or [SINGLE VENUE DATA]",
    "note": "Notes on arb opportunity if any"
  },
  
  "soWhat": "ONE sentence: what funding tells us about who is paying whom and what to expect (e.g., 'Longs paying 45% annualized suggests taking profits on leveraged longs and waiting for reset')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 12: Open Interest Analyzer (AI)
// Section 4: Derivatives & Positioning
// ============================================
async function executeOIAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    const marketData = context.results.market_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze Open Interest for Section 4 - Derivatives & Positioning.

OI INTERPRETATION FRAMEWORK:
- OI ↑ + Price ↑ = Trend confirmation, new money entering longs
- OI ↑ + Price ↓ = New shorts entering, trend confirmation for bears
- OI ↑ + Price → = Building tension, fragile, big move coming
- OI ↓ + Price ↑ = Short covering rally, potentially weak
- OI ↓ + Price ↓ = Long liquidation, potentially near bottom
- OI ↓ + Price → = Position reduction, uncertainty

WINDOW: ${windowStart} to ${windowEnd}

DERIVATIVES DATA:
${JSON.stringify(derivativesData, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "openInterest": {
    "btc": {
      "current": "$XX.XB",
      "change14d": {
        "absolute": "+$X.XB",
        "percent": "+X.X%"
      },
      "trend": "Building | Declining | Stable",
      "peak14d": {"value": "$XX.XB", "date": "YYYY-MM-DD"},
      "trough14d": {"value": "$XX.XB", "date": "YYYY-MM-DD"},
      "vsHistorical": "Xth percentile of last 90 days or [DATA NOT AVAILABLE]"
    },
    "eth": {
      "current": "$XX.XB",
      "change14d": {
        "absolute": "+$X.XB",
        "percent": "+X.X%"
      },
      "trend": "Building | Declining | Stable"
    },
    "total": {
      "current": "$XX.XB",
      "change14d": "+X.X%"
    }
  },
  
  "oiPriceDivergence": {
    "btc": {
      "oiDirection": "Up | Down | Flat",
      "oiChange": "+X.X%",
      "priceDirection": "Up | Down | Flat",
      "priceChange": "+X.X%",
      "pattern": "OI up + Price up | OI up + Price flat | etc",
      "interpretation": "Detailed interpretation of what this means",
      "tradingImplication": "What to do based on this"
    },
    "eth": {
      "oiDirection": "Up | Down | Flat",
      "priceDirection": "Up | Down | Flat",
      "pattern": "Description",
      "interpretation": "Description"
    }
  },
  
  "leverageFragility": {
    "score": <0-100>,
    "label": "LOW | MODERATE | HIGH | EXTREME",
    "factors": [
      "Factor contributing to fragility assessment",
      "Another factor"
    ],
    "cascadeRisk": {
      "upside": "Risk of short squeeze - High | Medium | Low",
      "downside": "Risk of long liquidation cascade - High | Medium | Low"
    }
  },
  
  "interpretationTable": [
    {
      "scenario": "Funding↑ + OI↑ + Price↑",
      "meaning": "Leveraged longs driving, sustainable if funding stays moderate",
      "risk": "Crowded if funding gets extreme",
      "currentlyApplies": true | false
    },
    {
      "scenario": "Funding↓ + OI↑ + Price↓",
      "meaning": "Shorts piling in",
      "risk": "Short squeeze if price reverses",
      "currentlyApplies": true | false
    },
    {
      "scenario": "Funding→ + OI↑ + Price→",
      "meaning": "Building tension, big move coming",
      "risk": "Direction unclear, reduce size",
      "currentlyApplies": true | false
    },
    {
      "scenario": "OI↓ + Price↑",
      "meaning": "Short covering, weak rally",
      "risk": "Fades easily without new buyers",
      "currentlyApplies": true | false
    }
  ],
  
  "soWhat": "ONE sentence: what OI tells us about leverage fragility and positioning (e.g., 'OI building into resistance with elevated funding suggests high liquidation risk above $XXK')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 13: Liquidation Mapper (AI)
// Section 4: Derivatives & Positioning
// ============================================
async function executeLiquidationMapper(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    const marketData = context.results.market_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Map liquidation zones with FORCED ACTOR analysis.
מטרה: להבין איפה יש forced selling/buying שיכול להאיץ את המחיר.

DERIVATIVES DATA:
${JSON.stringify(derivativesData, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "liquidations24h": {
    "total": "$XXXM",
    "longs": {
      "amount": "$XXXM",
      "percent": "XX%"
    },
    "shorts": {
      "amount": "$XXXM",
      "percent": "XX%"
    },
    "dominant": "Longs | Shorts | Balanced",
    "interpretation": "What recent liquidations tell us about positioning"
  },
  
  "liquidations7d": {
    "total": "$XXXM",
    "longsPercent": "XX%",
    "shortsPercent": "XX%",
    "largestDay": {
      "date": "YYYY-MM-DD",
      "amount": "$XXXM",
      "trigger": "What caused it"
    }
  },
  
  "forcedActors": {
    "longsAtRisk": {
      "estimatedUSD": "$XXM or [DATA NOT AVAILABLE]",
      "triggerLevel": "$XX,XXX (price that triggers cascade)",
      "whoIsForced": "Leveraged longs opened above $XX,XXX in last X days",
      "avgEntryEstimate": "$XX,XXX or [PROXY]",
      "stopCluster": "Estimated stop cluster around $XX,XXX"
    },
    "shortsAtRisk": {
      "estimatedUSD": "$XXM or [DATA NOT AVAILABLE]",
      "triggerLevel": "$XX,XXX (price that triggers cascade)",
      "whoIsForced": "Leveraged shorts opened below $XX,XXX",
      "avgEntryEstimate": "$XX,XXX or [PROXY]",
      "stopCluster": "Estimated stop cluster around $XX,XXX"
    }
  },
  
  "liquidationZones": {
    "btc": {
      "majorLongLiquidation": {
        "zone": "$XX,XXX - $XX,XXX",
        "estimatedSize": "$XXXM or [PROXY]",
        "distanceFromCurrent": "X.X% below"
      },
      "majorShortLiquidation": {
        "zone": "$XX,XXX - $XX,XXX",
        "estimatedSize": "$XXXM or [PROXY]",
        "distanceFromCurrent": "X.X% above"
      }
    },
    "cascadeRisk": {
      "level": "High | Medium | Low",
      "direction": "More liquidation risk to downside | upside | balanced",
      "reasoning": "Why"
    }
  },
  
  "recentFlush": {
    "occurred": true | false,
    "date": "YYYY-MM-DD or N/A",
    "side": "Longs | Shorts | Both",
    "size": "$XXXM",
    "priceMove": "X.X% move that triggered it",
    "meaning": "What the flush tells us about positioning now",
    "isPositionClean": "Are positions now cleaner after flush?"
  },
  
  "heatmapSummary": {
    "highDensityZones": [
      {"level": "$XX,XXX", "type": "Long liquidations", "size": "Large | Medium | Small"},
      {"level": "$XX,XXX", "type": "Short liquidations", "size": "Large | Medium | Small"}
    ],
    "cleanZones": "Price ranges with low liquidation density"
  },
  
  "soWhat": "ONE sentence: where forced selling/buying could accelerate price (e.g., 'Large long liquidation cluster at $92K means a break below $93K could cascade to $90K')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 14: Flows Analyzer (AI)
// Section 5: Flows & Supply Pressure
// ============================================
async function executeFlowsAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const onchainData = context.results.onchain_data_fetcher?.data;
    const marketData = context.results.market_data_fetcher?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze flows and supply pressure for Section 5.
מטרה: האם יש "לחץ מכירה/קנייה" אמיתי.

IMPORTANT DATA LIMITATIONS:
- We don't have Glassnode/CryptoQuant for direct exchange flows
- Use stablecoin supply as proxy for capital movement
- ETF flows from news sources only (may be delayed)
- Mark unavailable data with [FREE DATA UNAVAILABLE]

ON-CHAIN DATA:
${JSON.stringify(onchainData, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "exchangeReserves": {
    "available": false,
    "note": "[ON-CHAIN LIMITATION] No direct exchange flow data from Glassnode/CryptoQuant",
    "proxy": {
      "method": "Using stablecoin supply changes as proxy for capital movement",
      "interpretation": "Description based on stablecoin data"
    }
  },
  
  "etfFlows": {
    "dataSource": "News sources - may be delayed",
    "btcEtf": {
      "flow14d": "+$XXXM or [ETF DATA FROM NEWS SOURCES]",
      "trend": "Inflows | Outflows | Mixed",
      "largestDay": {
        "date": "YYYY-MM-DD",
        "amount": "$XXXM",
        "direction": "Inflow | Outflow"
      },
      "cumulativeAUM": "$XXB or [DATA NOT AVAILABLE]"
    },
    "ethEtf": {
      "flow14d": "+$XXXM or [ETF DATA FROM NEWS SOURCES]",
      "trend": "Inflows | Outflows | Mixed",
      "note": "Status of ETH ETF availability"
    },
    "interpretation": "Institutional accumulating | Distributing | Flat | Mixed signals",
    "reliability": "High | Medium | Low - based on data freshness"
  },
  
  "stablecoinDeployment": {
    "totalSupply": "$XXXB",
    "change14d": {
      "absolute": "+$X.XB",
      "percent": "+X.X%"
    },
    "velocity": {
      "observation": "How actively stablecoins are moving",
      "interpretation": "Capital deploying | Sitting idle | Exiting"
    },
    "defiDeployed": {
      "amount": "$XXB or [DATA NOT AVAILABLE]",
      "percentOfTotal": "XX%",
      "change14d": "+X.X%"
    },
    "interpretation": "Dry powder building | Capital deployed | Capital exiting"
  },
  
  "supplyPressure": {
    "nearTermRisk": "High | Medium | Low",
    "factors": [
      {
        "factor": "Factor name",
        "direction": "Bullish | Bearish",
        "magnitude": "High | Medium | Low",
        "timing": "Immediate | This week | Next 2 weeks"
      }
    ],
    "mitigation": "What could offset the pressure"
  },
  
  "whaleActivity": {
    "available": false,
    "note": "[FREE DATA UNAVAILABLE] Whale tracking requires premium on-chain data",
    "proxy": "Large liquidations and OI changes as proxy for large player activity"
  },
  
  "minerPressure": {
    "btc": {
      "estimate": "Low | Moderate | High or [DATA NOT AVAILABLE]",
      "note": "Based on available public data",
      "hashrate": "Description if available"
    }
  },
  
  "flowSummary": {
    "netDirection": "Net inflows | Net outflows | Neutral",
    "confidence": "High | Medium | Low",
    "mainDriver": "Primary factor driving flows"
  },
  
  "soWhat": "ONE sentence: is there real buying/selling pressure (e.g., 'Growing stablecoin supply + ETF inflows suggest dry powder available for next leg up')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 15: Token Unlocks Analyzer (AI)
// Section 5: Flows & Supply Pressure
// ============================================
async function executeTokenUnlocksAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService, reportDate, windowEnd } = context;
    const marketData = context.results.market_data_fetcher?.data;
    
    // Calculate 14-day forward window
    const endDate = new Date(windowEnd || reportDate);
    const forward14d = new Date(endDate);
    forward14d.setDate(forward14d.getDate() + 14);
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze token unlocks for the next 14 days.
מטרה: הבנת "סיכון היצע" לשבועיים קדימה.

CRITICAL METRICS:
- % of ADV (Average Daily Volume) - unlocks > 100% of ADV are significant
- % of Circulating Supply - unlocks > 1% are notable
- Recipient matters: Team/Investor unlocks more likely to sell than Community/Ecosystem

FORWARD WINDOW: ${endDate.toISOString().split('T')[0]} to ${forward14d.toISOString().split('T')[0]}

MARKET DATA (for volume context):
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "unlocks14d": [
    {
      "token": "TOKEN",
      "date": "YYYY-MM-DD",
      "amount": {
        "tokens": "XXM tokens",
        "usd": "$XXM"
      },
      "percentOfCirculating": "X.X%",
      "percentOfADV": "XXX% of average daily volume",
      "impactRisk": "High | Medium | Low",
      "recipient": "Team | Investors | Community | Treasury | Ecosystem",
      "vestingSchedule": "Linear | Cliff | One-time",
      "historicalPattern": "How previous unlocks affected price or [NO HISTORY]",
      "tradingImplication": "Specific trading implication"
    }
  ],
  
  "majorUnlocks": [
    {
      "rank": 1,
      "token": "TOKEN",
      "date": "YYYY-MM-DD",
      "usdValue": "$XXM",
      "why": "Why this unlock matters most",
      "prepStrategy": "How to position ahead of this unlock"
    }
  ],
  
  "totalSupplyPressure": {
    "week1": {
      "total": "$XXXM worth of unlocks",
      "majorEvents": <number>,
      "highestRisk": "TOKEN"
    },
    "week2": {
      "total": "$XXXM worth of unlocks",
      "majorEvents": <number>,
      "highestRisk": "TOKEN"
    },
    "riskAssessment": "Elevated | Normal | Low",
    "riskReason": "Why this assessment"
  },
  
  "sectorExposure": {
    "mostAffectedSector": "L1 | L2 | DeFi | AI | Gaming | Other",
    "tokens": ["Tokens in that sector with unlocks"],
    "implication": "Sector-level implication"
  },
  
  "unlockCalendar": [
    {
      "date": "YYYY-MM-DD",
      "events": [
        {"token": "TOKEN", "value": "$XXM", "risk": "H|M|L"}
      ],
      "dayRisk": "High | Medium | Low"
    }
  ],
  
  "dataConfidence": {
    "level": "High | Medium | Low",
    "note": "Unlock schedules may change. Verify with official sources.",
    "source": "TokenUnlocks / Tokenomist / Public announcements"
  },
  
  "soWhat": "ONE sentence: which unlocks could move prices (e.g., 'ARB $150M unlock on DATE represents 200% of daily volume - expect selling pressure')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 16: Sector Performance Analyzer (AI)
// Section 6: Sector Rotation Map
// ============================================
async function executeSectorPerformanceAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const marketData = context.results.market_data_fetcher?.data;
    
    const sectorDefs = JSON.stringify(CRYPTO_SECTORS, null, 2);
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze sector rotation map for Section 6.
מטרה: להראות איפה הכסף זז.

SECTORS TO ANALYZE:
- L1 (Layer 1): ETH, SOL, AVAX, ADA, DOT, NEAR, etc.
- L2 (Layer 2): ARB, OP, MATIC, BASE tokens, etc.
- DeFi: UNI, AAVE, MKR, CRV, LDO, etc.
- AI/Compute: TAO, RNDR, FET, AGIX, etc.
- Gaming/Metaverse: AXS, SAND, MANA, IMX, GALA, etc.
- Memes: DOGE, SHIB, PEPE, WIF, BONK, etc.
- RWA: ONDO, MKR (RWA), tokenized assets
- Perps/DeFi Derivatives: GMX, DYDX, SNX, etc.

WINDOW: ${windowStart} to ${windowEnd}

SECTOR DEFINITIONS:
${sectorDefs}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "sectorTable": [
    {
      "sector": "L1",
      "performance14d": "+X.X%",
      "performance7d": "+X.X%",
      "volatility": "High | Medium | Low",
      "volatilityValue": "XX% realized",
      "narrativeDriver": "One sentence explaining what's driving this sector",
      "momentum": "Accelerating | Stable | Decelerating",
      "topPerformer": {
        "token": "TOKEN",
        "return": "+XX.X%",
        "catalyst": "Brief reason"
      },
      "bottomPerformer": {
        "token": "TOKEN",
        "return": "-XX.X%",
        "reason": "Brief reason"
      },
      "outlook": "Bullish | Neutral | Bearish for next 14D"
    },
    {
      "sector": "L2",
      "performance14d": "+X.X%",
      "performance7d": "+X.X%",
      "volatility": "High | Medium | Low",
      "narrativeDriver": "Description",
      "momentum": "Accelerating | Stable | Decelerating",
      "topPerformer": {"token": "TOKEN", "return": "+XX.X%", "catalyst": "Reason"},
      "bottomPerformer": {"token": "TOKEN", "return": "-XX.X%", "reason": "Reason"},
      "outlook": "Bullish | Neutral | Bearish"
    },
    {
      "sector": "DeFi",
      "performance14d": "+X.X%",
      "performance7d": "+X.X%",
      "volatility": "High | Medium | Low",
      "narrativeDriver": "Description",
      "momentum": "Accelerating | Stable | Decelerating",
      "topPerformer": {"token": "TOKEN", "return": "+XX.X%", "catalyst": "Reason"},
      "bottomPerformer": {"token": "TOKEN", "return": "-XX.X%", "reason": "Reason"},
      "outlook": "Bullish | Neutral | Bearish"
    },
    {
      "sector": "AI",
      "performance14d": "+X.X%",
      "performance7d": "+X.X%",
      "volatility": "High | Medium | Low",
      "narrativeDriver": "Description",
      "momentum": "Accelerating | Stable | Decelerating",
      "topPerformer": {"token": "TOKEN", "return": "+XX.X%", "catalyst": "Reason"},
      "bottomPerformer": {"token": "TOKEN", "return": "-XX.X%", "reason": "Reason"},
      "outlook": "Bullish | Neutral | Bearish"
    },
    {
      "sector": "Gaming",
      "performance14d": "+X.X%",
      "performance7d": "+X.X%",
      "volatility": "High | Medium | Low",
      "narrativeDriver": "Description",
      "momentum": "Accelerating | Stable | Decelerating",
      "topPerformer": {"token": "TOKEN", "return": "+XX.X%", "catalyst": "Reason"},
      "bottomPerformer": {"token": "TOKEN", "return": "-XX.X%", "reason": "Reason"},
      "outlook": "Bullish | Neutral | Bearish"
    },
    {
      "sector": "Memes",
      "performance14d": "+X.X%",
      "performance7d": "+X.X%",
      "volatility": "High | Medium | Low",
      "narrativeDriver": "Description",
      "momentum": "Accelerating | Stable | Decelerating",
      "topPerformer": {"token": "TOKEN", "return": "+XX.X%", "catalyst": "Reason"},
      "bottomPerformer": {"token": "TOKEN", "return": "-XX.X%", "reason": "Reason"},
      "outlook": "Bullish | Neutral | Bearish"
    }
  ],
  
  "leaderboard": {
    "top3Sectors": [
      {"sector": "Sector1", "return14d": "+XX.X%", "driver": "Key driver"},
      {"sector": "Sector2", "return14d": "+XX.X%", "driver": "Key driver"},
      {"sector": "Sector3", "return14d": "+XX.X%", "driver": "Key driver"}
    ],
    "bottom3Sectors": [
      {"sector": "Sector1", "return14d": "-XX.X%", "reason": "Key reason"},
      {"sector": "Sector2", "return14d": "-XX.X%", "reason": "Key reason"},
      {"sector": "Sector3", "return14d": "-XX.X%", "reason": "Key reason"}
    ]
  },
  
  "sectorDispersion": {
    "spread": "XX.X% (best sector - worst sector)",
    "interpretation": "High dispersion = selective market | Low dispersion = broad risk-on/off"
  },
  
  "emergingThemes": [
    {
      "theme": "Description of emerging theme",
      "sectors": ["Affected sectors"],
      "tokens": ["Key tokens"],
      "maturity": "Early | Mid | Late"
    }
  ],
  
  "soWhat": "ONE sentence: where is money rotating (e.g., 'Money rotating from Memes to AI suggests risk appetite still present but becoming more selective')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 17: Rotation Signal Analyzer (AI)
// Section 6: Sector Rotation Map
// ============================================
async function executeRotationSignalAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const sectorData = context.results.sector_performance_analyzer?.data;
    const marketData = context.results.market_data_fetcher?.data;
    const dominanceData = context.results.dominance_analyzer?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Analyze rotation signals and identify what would change the rotation.

SECTOR DATA:
${JSON.stringify(sectorData, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

DOMINANCE DATA:
${JSON.stringify(dominanceData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "rotationDetected": true | false,
  
  "rotationDetails": {
    "from": {
      "sectors": ["Sector(s) money is leaving"],
      "evidence": "Specific data showing outflows"
    },
    "to": {
      "sectors": ["Sector(s) money is flowing into"],
      "evidence": "Specific data showing inflows"
    },
    "strength": "Strong | Moderate | Weak",
    "phase": "Early | Mid | Late | Exhaustion",
    "duration": "Rotation has been ongoing for X days/weeks"
  },
  
  "rotationType": {
    "type": "Risk-on rotation | Risk-off rotation | Quality rotation | Narrative rotation | Sector-specific",
    "description": "Detailed description of the rotation type"
  },
  
  "whatChangesIt": {
    "bullishRotation": {
      "condition": "If X happens, rotation accelerates to more risk-on sectors",
      "targetSectors": ["Sectors that would benefit"],
      "trigger": "Specific trigger to watch"
    },
    "bearishRotation": {
      "condition": "If Y happens, rotation reverses to defensive",
      "targetSectors": ["Sectors that would benefit"],
      "trigger": "Specific trigger to watch"
    }
  },
  
  "narrativeDrivers": [
    {
      "narrative": "Description of narrative",
      "sectors": ["Affected sectors"],
      "tokens": ["Key tokens"],
      "isNew": true | false,
      "age": "X days/weeks old",
      "strength": "Growing | Stable | Fading",
      "catalyst": "What's driving this narrative"
    }
  ],
  
  "flowAnalysis": {
    "primaryFlow": "Description of main capital flow",
    "secondaryFlow": "Description of secondary flow",
    "contraFlow": "Any counter-rotation happening"
  },
  
  "historicalContext": {
    "similarPeriod": "When we've seen similar rotation before",
    "outcome": "What happened then",
    "applicability": "High | Medium | Low - how applicable is history"
  },
  
  "soWhat": "ONE sentence: what rotation tells us about positioning (e.g., 'Early-stage rotation into AI suggests adding exposure before narrative matures')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 18: Narratives That Moved Price (AI)
// Section 7: Narratives
// ============================================
async function executeNarrativesAnalyzer(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const marketData = context.results.market_data_fetcher?.data;
    const sectorData = context.results.sector_performance_analyzer?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Identify 3-5 narratives that ACTUALLY moved price (not noise).
מטרה: לסנן רעש ולהבין "למה זה זז".

CRITICAL: Only include narratives where you can point to data showing price moved.
- Need to show specific price impact with numbers
- Need volume/funding/TVL confirmation
- Filter out noise - announcements that didn't move markets

WINDOW: ${windowStart} to ${windowEnd}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

SECTOR DATA:
${JSON.stringify(sectorData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "narratives": [
    {
      "rank": 1,
      "narrative": "Clear description of what happened",
      "category": "Regulatory | Institutional | Technical | Macro | Protocol | Social | Other",
      "date": "YYYY-MM-DD or date range",
      
      "whatHappened": {
        "event": "Specific event/news that triggered it",
        "source": "Where this originated",
        "keyActors": ["Who was involved"]
      },
      
      "dataEvidence": {
        "priceImpact": {
          "asset": "TOKEN",
          "move": "+XX.X%",
          "timeframe": "Within X hours/days",
          "sustainedOrFaded": "Price held | Faded back"
        },
        "volumeSpike": {
          "detected": true | false,
          "magnitude": "Volume was XXX% above average",
          "duration": "Lasted X hours/days"
        },
        "derivativesImpact": {
          "funding": "Funding spiked to XX% or N/A",
          "oi": "OI changed by XX% or N/A",
          "liquidations": "$XXM liquidated or N/A"
        },
        "tvlImpact": {
          "change": "TVL increased/decreased by $XXM or N/A",
          "protocol": "Which protocol(s)"
        }
      },
      
      "winners": {
        "tokens": ["TOKEN1", "TOKEN2"],
        "who": "Description of who benefited"
      },
      "losers": {
        "tokens": ["TOKEN1", "TOKEN2"],
        "who": "Description of who was hurt"
      },
      
      "trendAnalysis": {
        "isNewTrend": true | false,
        "continuation": "If not new, what existing trend this continues",
        "expectedDuration": "How long this narrative might persist"
      },
      
      "tradingImplication": "How traders should have positioned / can still position"
    }
  ],
  
  "noiseFiltered": [
    {
      "item": "News/announcement that looked important",
      "whyNoise": "Why it didn't move price",
      "lesson": "What this tells us about market focus"
    }
  ],
  
  "narrativeHeatmap": {
    "hottest": "Narrative with most momentum",
    "warming": "Narrative gaining attention",
    "cooling": "Narrative losing steam",
    "cold": "Previously hot narrative now ignored"
  },
  
  "attentionAnalysis": {
    "marketFocus": "What the market is most focused on right now",
    "underappreciated": "Important development market is ignoring",
    "overHyped": "Something getting more attention than it deserves"
  },
  
  "soWhat": "ONE sentence: what narratives tell us about market attention (e.g., 'Market rewarding AI narratives over DeFi suggests positioning in AI tokens before institutional focus shifts')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.4 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 19: Catalyst Calendar Generator (AI)
// Section 8: Catalyst Calendar (14D Forward)
// ============================================
async function executeCatalystCalendarGenerator(context) {
  const startTime = Date.now();
  try {
    const { aiService, reportDate, windowEnd } = context;
    const unlocksData = context.results.token_unlocks_analyzer?.data;
    const marketData = context.results.market_data_fetcher?.data;
    
    // Calculate 14-day forward window
    const startDate = new Date(windowEnd || reportDate);
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + 14);
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Generate 14-day catalyst calendar from ${startDate.toISOString().split('T')[0]}.
מטרה: להפוך את הדוח לכלי שימושי.

INCLUDE:
- Macro events: CPI, FOMC, Jobs reports, GDP (official dates)
- Crypto-specific: Major upgrades, governance votes, token unlocks
- Regulatory: Court hearings, regulatory deadlines
- Listings: Major exchange listings (confirmed only)

RULES:
- Only include from OFFICIAL sources
- Mark uncertain dates as [TIMING UNCERTAIN]
- Impact score 1-5 (5 = market-moving)

FORWARD WINDOW: ${startDate.toISOString().split('T')[0]} to ${endDate.toISOString().split('T')[0]}

UNLOCKS DATA:
${JSON.stringify(unlocksData, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "calendar": [
    {
      "date": "YYYY-MM-DD",
      "event": "Event description",
      "category": "MACRO | CRYPTO_UPGRADE | GOVERNANCE | TOKEN_UNLOCK | LISTING | REGULATORY",
      "assets": ["Affected assets - use 'MARKET' for broad impact"],
      "impactScore": <1-5>,
      "impactDescription": "Why this impact level",
      "expectedOutcome": {
        "bullish": "What outcome would be bullish",
        "bearish": "What outcome would be bearish"
      },
      "howToPrepare": "One sentence on positioning",
      "source": "Official source or [TIMING UNCERTAIN]",
      "confidence": "High | Medium | Low"
    }
  ],
  
  "weekSummary": {
    "week1": {
      "dates": "MM/DD - MM/DD",
      "highImpactEvents": [
        {"date": "MM/DD", "event": "Event name", "impact": <1-5>}
      ],
      "riskLevel": "High | Medium | Low",
      "tradingAdvice": "Brief advice for the week"
    },
    "week2": {
      "dates": "MM/DD - MM/DD",
      "highImpactEvents": [
        {"date": "MM/DD", "event": "Event name", "impact": <1-5>}
      ],
      "riskLevel": "High | Medium | Low",
      "tradingAdvice": "Brief advice for the week"
    }
  },
  
  "macroCalendar": [
    {
      "date": "YYYY-MM-DD",
      "event": "CPI | FOMC | NFP | GDP | Other",
      "previousValue": "Previous reading if applicable",
      "expectedValue": "Consensus expectation if available",
      "marketExpectation": "What's priced in",
      "cryptoImpact": "Risk-on if X, Risk-off if Y",
      "tradingWindow": "Consider reducing risk X hours before"
    }
  ],
  
  "cryptoCalendar": [
    {
      "date": "YYYY-MM-DD",
      "event": "Description",
      "asset": "TOKEN",
      "type": "Upgrade | Vote | Unlock | Launch | Other",
      "details": "Specific details",
      "tradingImplication": "How to position"
    }
  ],
  
  "quietPeriods": {
    "dates": ["Dates with no major catalysts"],
    "implication": "Good for X type of trading"
  },
  
  "riskyPeriods": {
    "dates": ["Dates with multiple catalysts or high uncertainty"],
    "advice": "Consider reduced exposure"
  },
  
  "soWhat": "ONE sentence: which events to watch most closely (e.g., 'FOMC on DATE is the key event - reduce leverage 24h before if positioned directionally')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 20: Trade Idea Generator (AI)
// Section 9: Trade Setup Playbook
// ============================================
async function executeTradeIdeaGenerator(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const regime = context.results.regime_detector?.data;
    const priceStructure = context.results.price_structure_analyzer?.data;
    const sectorData = context.results.sector_performance_analyzer?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    const catalystData = context.results.catalyst_calendar_generator?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Generate 3-7 trade ideas for Section 9 - Trade Setup Playbook.
החלק שמוכר - תזות לסוחר בלי להבטיח תשואה.

CRITICAL REQUIREMENTS FOR EACH IDEA:
1. Thesis: 2-3 sentences explaining WHY this trade
2. What must be true: Entry conditions (binary)
3. Invalidation: Clear stop level and condition
4. Catalyst/Timing: What could accelerate + time window
5. Risk note: Honest assessment of what could go wrong
6. Execution notes: Spot vs Perp, leverage guidance

NOT FINANCIAL ADVICE - Educational only.

REGIME:
${JSON.stringify(regime, null, 2)}

PRICE STRUCTURE:
${JSON.stringify(priceStructure, null, 2)}

SECTOR DATA:
${JSON.stringify(sectorData, null, 2)}

DERIVATIVES:
${JSON.stringify(derivativesData, null, 2)}

CATALYSTS:
${JSON.stringify(catalystData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "tradeIdeas": [
    {
      "id": 1,
      "asset": "BTC | ETH | TOKEN",
      "direction": "Long | Short",
      "type": "Spot | Perp | Range Trade | Breakout | Mean Reversion | Momentum | Catalyst Play",
      "conviction": "High | Medium | Low",
      
      "thesis": {
        "summary": "2-3 sentences explaining the trade logic",
        "keyInsight": "The ONE insight that makes this trade attractive",
        "regime fit": "How this fits current market regime"
      },
      
      "whatMustBeTrue": [
        "Condition 1 for entry (binary, verifiable)",
        "Condition 2 for entry",
        "Condition 3 for entry (if applicable)"
      ],
      
      "entryZone": {
        "ideal": "$XX,XXX - $XX,XXX",
        "aggressive": "$XX,XXX",
        "conservative": "$XX,XXX"
      },
      
      "targetZone": {
        "target1": {"level": "$XX,XXX", "rationale": "Why this level"},
        "target2": {"level": "$XX,XXX", "rationale": "Why this level"},
        "targetExtended": {"level": "$XX,XXX", "condition": "If momentum continues"}
      },
      
      "invalidation": {
        "hardStop": "$XX,XXX",
        "condition": "Binary condition that kills the trade",
        "whyInvalidates": "Why this level matters",
        "maxLoss": "X% of position"
      },
      
      "catalyst": {
        "primary": "What could accelerate this trade",
        "timing": "When the catalyst might hit",
        "impact": "Expected impact on position"
      },
      
      "timingWindow": {
        "duration": "1-3 days | 1-2 weeks | 2-4 weeks",
        "bestEntry": "Description of ideal entry timing",
        "avoid": "When NOT to enter"
      },
      
      "riskNote": {
        "primaryRisk": "Main thing that could go wrong",
        "secondaryRisk": "Secondary risk",
        "mitigant": "How to mitigate"
      },
      
      "executionNotes": {
        "preferredVehicle": "Spot | Perp",
        "leverageGuidance": "1x (spot) | 2-3x max | Not recommended for leverage",
        "scalingStrategy": "Scale in on dips | Full position | DCA over X days",
        "positionSize": "X% of portfolio (given current regime)"
      },
      
      "riskReward": {
        "ratio": "1:2 | 1:3 | etc",
        "winRate": "Estimated based on setup quality",
        "expectedValue": "Positive | Marginal | Speculative"
      }
    }
  ],
  
  "noTradeScenario": {
    "condition": "When to not trade at all",
    "currentlyApplies": true | false,
    "reasoning": "Why or why not"
  },
  
  "portfolioView": {
    "idealMix": "Description of ideal portfolio allocation given these setups",
    "hedges": "Suggested hedges if any",
    "correlation": "Correlation between ideas (don't double down on same risk)"
  },
  
  "disclaimer": "NOT FINANCIAL ADVICE. Educational analysis only. Always do your own research.",
  
  "soWhat": "ONE sentence: best risk-adjusted opportunity right now (e.g., 'BTC pullback to $XX,XXX offers best R:R with clear invalidation at $XX,XXX')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.4 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 21: Risk Management & Psychology Advisor (AI)
// Section 10: Risk Management & Psychology
// ============================================
async function executeRiskPsychologyAdvisor(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const regime = context.results.regime_detector?.data;
    const volatility = context.results.volatility_regime_analyzer?.data;
    const liquidationData = context.results.liquidation_mapper?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Generate Risk Management & Trader Psychology section (Section 10).
מטרה: לשפר את ה-PnL דרך מניעת טעויות.

REGIME:
${JSON.stringify(regime, null, 2)}

VOLATILITY:
${JSON.stringify(volatility, null, 2)}

LIQUIDATION DATA:
${JSON.stringify(liquidationData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "top5Mistakes": [
    {
      "rank": 1,
      "mistake": "Description of common mistake in THIS specific regime",
      "whyItHappens": "Psychology behind why traders make this mistake",
      "recentExample": "Example from recent price action if applicable",
      "howToAvoid": {
        "rule": "Concrete rule to follow",
        "implementation": "How to implement this rule",
        "checklist": "Quick check before making this mistake"
      }
    },
    {
      "rank": 2,
      "mistake": "Second common mistake",
      "whyItHappens": "Psychology",
      "howToAvoid": {
        "rule": "Rule",
        "implementation": "Implementation",
        "checklist": "Check"
      }
    },
    {
      "rank": 3,
      "mistake": "Third common mistake",
      "whyItHappens": "Psychology",
      "howToAvoid": {
        "rule": "Rule",
        "implementation": "Implementation",
        "checklist": "Check"
      }
    },
    {
      "rank": 4,
      "mistake": "Fourth common mistake",
      "whyItHappens": "Psychology",
      "howToAvoid": {
        "rule": "Rule",
        "implementation": "Implementation",
        "checklist": "Check"
      }
    },
    {
      "rank": 5,
      "mistake": "Fifth common mistake",
      "whyItHappens": "Psychology",
      "howToAvoid": {
        "rule": "Rule",
        "implementation": "Implementation",
        "checklist": "Check"
      }
    }
  ],
  
  "positionSizing": {
    "currentRegime": "${regime?.regime || 'UNKNOWN'}",
    "volatilityState": "${volatility?.volatilityRegime?.state || 'UNKNOWN'}",
    "recommendations": {
      "maxRiskPerTrade": "X% of portfolio",
      "maxPortfolioRisk": "X% total exposure",
      "maxConcurrentPositions": <number>,
      "leverageGuidance": {
        "spot": "Recommended",
        "lowLeverage": "2-3x acceptable for X type of trades",
        "highLeverage": "Avoid | Only for scalps | etc",
        "maxRecommended": "Xx"
      }
    },
    "adjustmentFromNormal": {
      "direction": "Increase | Decrease | Maintain",
      "percent": "By X%",
      "reason": "Why this adjustment"
    }
  },
  
  "preEntryChecklist": [
    {
      "category": "Liquidity",
      "question": "Is liquidity sufficient for my position size?",
      "check": "24h volume > 10x position size",
      "redFlag": "Volume < 5x position = reduce size",
      "priority": "Critical"
    },
    {
      "category": "Volatility",
      "question": "Is volatility regime acceptable for this trade?",
      "check": "ATR < XX% or position size adjusted",
      "redFlag": "Extreme vol = half position size",
      "priority": "Critical"
    },
    {
      "category": "Funding",
      "question": "Is funding sustainable for my direction?",
      "check": "Annualized < XX% for longs, > -XX% for shorts",
      "redFlag": "Extreme funding = wait for reset",
      "priority": "High"
    },
    {
      "category": "Catalyst",
      "question": "Any major catalyst in next 24-48h?",
      "check": "Check calendar, reduce size pre-event",
      "redFlag": "FOMC/CPI = reduce leverage",
      "priority": "High"
    },
    {
      "category": "Invalidation",
      "question": "Is my stop loss defined and acceptable?",
      "check": "Stop set BEFORE entry, loss < X% of portfolio",
      "redFlag": "No clear invalidation = no trade",
      "priority": "Critical"
    },
    {
      "category": "Correlation",
      "question": "Am I already exposed to this risk elsewhere?",
      "check": "Check existing positions for correlation",
      "redFlag": "Multiple correlated bets = reduce",
      "priority": "Medium"
    }
  ],
  
  "psychologyNote": {
    "currentMarketPsychology": "Description of prevailing market psychology",
    "traderPitfalls": "Common emotional traps in this environment",
    "mentalFramework": "How to think about the market right now",
    "actionableAdvice": "Specific psychological advice for current conditions"
  },
  
  "regimeSpecificRules": [
    {
      "rule": "Regime-specific rule 1",
      "rationale": "Why this rule matters now"
    },
    {
      "rule": "Regime-specific rule 2",
      "rationale": "Why this rule matters now"
    },
    {
      "rule": "Regime-specific rule 3",
      "rationale": "Why this rule matters now"
    }
  ],
  
  "soWhat": "ONE sentence: most important risk management action right now (e.g., 'In this elevated-funding regime, prioritize taking profits over adding to winners')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.4 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 22: Watchlist Generator (AI)
// Section 11: Watchlist
// ============================================
async function executeWatchlistGenerator(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const sectorData = context.results.sector_performance_analyzer?.data;
    const catalystData = context.results.catalyst_calendar_generator?.data;
    const marketData = context.results.market_data_fetcher?.data;
    const narrativesData = context.results.narratives_analyzer?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Generate watchlist with 10-20 assets for Section 11.
מטרה: לספק "רשימת מעקב עם סיבה".

CATEGORIES:
1. Momentum Leaders - Assets with strong upward momentum to ride
2. Mean Reversion Candidates - Oversold/overbought assets for reversal plays  
3. Catalyst-Driven - Assets with upcoming events that could move price

SECTOR DATA:
${JSON.stringify(sectorData, null, 2)}

CATALYST DATA:
${JSON.stringify(catalystData, null, 2)}

MARKET DATA:
${JSON.stringify(marketData, null, 2)}

NARRATIVES:
${JSON.stringify(narrativesData, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "watchlist": {
    "momentumLeaders": [
      {
        "rank": 1,
        "asset": "TOKEN",
        "currentPrice": "$XX.XX",
        "return14d": "+XX.X%",
        "reason": "One line: why it's showing momentum",
        "momentum": {
          "strength": "Strong | Moderate",
          "duration": "X days/weeks in uptrend",
          "volume": "Volume trend"
        },
        "whatToWatch": "Binary trigger or level to watch",
        "entryZone": "$XX - $XX",
        "invalidation": "$XX (momentum broken if below)",
        "riskLevel": "High | Medium | Low"
      }
    ],
    
    "meanReversionCandidates": [
      {
        "rank": 1,
        "asset": "TOKEN",
        "currentPrice": "$XX.XX",
        "return14d": "-XX.X% or +XX.X%",
        "condition": "Oversold | Overbought",
        "reason": "One line: why it's a mean reversion candidate",
        "technicals": {
          "distanceFromMean": "X% below/above 20d MA",
          "rsi": "XX or [DATA NOT AVAILABLE]",
          "support": "$XX"
        },
        "whatToWatch": "Level or condition for entry",
        "targetBounce": "$XX (X% potential)",
        "invalidation": "$XX (no bounce if below)",
        "riskLevel": "High | Medium | Low"
      }
    ],
    
    "catalystDriven": [
      {
        "rank": 1,
        "asset": "TOKEN",
        "currentPrice": "$XX.XX",
        "catalyst": {
          "event": "What event could move it",
          "date": "Date or timing",
          "expectedImpact": "Bullish | Bearish | Binary outcome"
        },
        "reason": "Why this catalyst matters",
        "whatToWatch": "How to position ahead",
        "strategy": {
          "preEvent": "Buy before | Wait for confirmation | etc",
          "postEvent": "Exit plan"
        },
        "riskLevel": "High | Medium | Low"
      }
    ]
  },
  
  "removed": [
    {
      "asset": "TOKEN",
      "previousCategory": "Category",
      "whyRemoved": "Why it's no longer on watchlist"
    }
  ],
  
  "summary": {
    "totalAssets": <number>,
    "momentumCount": <number>,
    "reversionCount": <number>,
    "catalystCount": <number>,
    "biasDirection": "Bullish | Bearish | Neutral bias in watchlist",
    "riskProfile": "Aggressive | Balanced | Conservative"
  },
  
  "topPicks": {
    "best RR": {
      "token": "TOKEN",
      "reason": "One sentence why"
    },
    "highestConviction": {
      "token": "TOKEN",
      "reason": "One sentence why"
    },
    "speculative": {
      "token": "TOKEN",
      "reason": "One sentence why (high risk/reward)"
    }
  },
  
  "avoidList": [
    {
      "asset": "TOKEN",
      "reason": "Why to avoid this asset right now"
    }
  ],
  
  "soWhat": "ONE sentence: what the watchlist tells us about opportunity set (e.g., 'Heavy momentum list suggests riding trends over picking bottoms')"
}`;

    const result = await aiService.complete(prompt, { temperature: 0.4 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 23: Coherence Checker (AI)
// Quality Assurance
// ============================================
async function executeCoherenceChecker(context) {
  const startTime = Date.now();
  try {
    const { aiService } = context;
    const regime = context.results.regime_detector?.data;
    const trades = context.results.trade_idea_generator?.data;
    const priceStructure = context.results.price_structure_analyzer?.data;
    const funding = context.results.funding_analyzer?.data;
    const flows = context.results.flows_analyzer?.data;
    const oi = context.results.oi_analyzer?.data;
    const watchlist = context.results.watchlist_generator?.data;
    
    const allResults = {
      regime,
      trades,
      priceStructure,
      funding,
      flows,
      oi,
      watchlist,
    };
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Check for coherence, conflicts, and data quality across all analysis.
This is the quality assurance step before final report generation.

ALL ANALYSIS:
${JSON.stringify(allResults, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "coherenceScore": <0-100>,
  "grade": "A | B | C | D | F",
  
  "conflicts": [
    {
      "id": 1,
      "signal1": {
        "source": "Which analysis",
        "claim": "What it says"
      },
      "signal2": {
        "source": "Which analysis",
        "claim": "What it says (conflicting)"
      },
      "severity": "High | Medium | Low",
      "resolution": "How to reconcile or which to prioritize",
      "recommendation": "What to do about this conflict"
    }
  ],
  
  "alignedSignals": [
    {
      "signal": "Description of aligned signal",
      "sources": ["Analysis 1", "Analysis 2", "Analysis 3"],
      "confidence": "High | Medium",
      "implication": "What this alignment means"
    }
  ],
  
  "dataGaps": [
    {
      "missing": "What data is missing",
      "impact": "How it affects analysis confidence",
      "proxy": "What proxy was used if any",
      "recommendation": "How to handle in report"
    }
  ],
  
  "qualityChecks": {
    "regimeTradeAlignment": {
      "aligned": true | false,
      "issue": "Description if not aligned",
      "recommendation": "How to fix"
    },
    "watchlistRegimeAlignment": {
      "aligned": true | false,
      "issue": "Description if not aligned",
      "recommendation": "How to fix"
    },
    "fundingPositionAlignment": {
      "aligned": true | false,
      "issue": "Description if not aligned",
      "recommendation": "How to fix"
    },
    "dataFreshness": {
      "acceptable": true | false,
      "oldestData": "What's the oldest data point",
      "impact": "How this affects analysis"
    }
  },
  
  "narrativeCoherence": {
    "mainStory": "The main narrative thread across all analysis",
    "supportingPoints": ["Point 1", "Point 2", "Point 3"],
    "weakPoints": ["Where narrative is weakest"]
  },
  
  "confidenceAssessment": {
    "overall": "High | Medium | Low",
    "bySection": {
      "regime": "High | Medium | Low",
      "priceStructure": "High | Medium | Low",
      "derivatives": "High | Medium | Low",
      "flows": "High | Medium | Low",
      "tradeIdeas": "High | Medium | Low"
    }
  },
  
  "recommendations": [
    {
      "priority": 1,
      "recommendation": "Most important thing to address",
      "impact": "How it affects report quality"
    }
  ],
  
  "overallAssessment": "One paragraph on analysis quality, coherence, and confidence. Be honest about limitations."
}`;

    const result = await aiService.complete(prompt, { temperature: 0.3 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 24: Executive Summary Writer (AI)
// Final synthesis for Section 1
// ============================================
async function executeExecutiveSummaryWriter(context) {
  const startTime = Date.now();
  try {
    const { aiService, windowStart, windowEnd } = context;
    const coherence = context.results.coherence_checker?.data;
    const takeaways = context.results.top5_takeaways_generator?.data;
    const flipTriggers = context.results.regime_flip_analyzer?.data;
    const regime = context.results.regime_detector?.data;
    const priceStructure = context.results.price_structure_analyzer?.data;
    
    const prompt = `${SYSTEM_PROMPTS.BASE}

TASK: Write final Executive Decision Brief synthesizing all analysis.
This is the opening section (Section 1) that PMs read first.

WINDOW: ${windowStart} to ${windowEnd}

COHERENCE CHECK:
${JSON.stringify(coherence, null, 2)}

TAKEAWAYS:
${JSON.stringify(takeaways, null, 2)}

FLIP TRIGGERS:
${JSON.stringify(flipTriggers, null, 2)}

REGIME:
${JSON.stringify(regime, null, 2)}

PRICE STRUCTURE:
${JSON.stringify(priceStructure, null, 2)}

${SYSTEM_PROMPTS.FORMATTING}

Return JSON:
{
  "executiveBrief": {
    "regime": {
      "label": "${regime?.regime || 'UNKNOWN'}",
      "score": ${regime?.score || 50},
      "confidence": "${regime?.confidence || 'Medium'}",
      "summary": "One sentence regime summary"
    },
    "oneLineCall": "THE single most important thing to know from this report - make it memorable and actionable",
    "bigPicture": "2-3 sentences: what's happening in the market at the highest level"
  },
  
  "whatFlipsTheRegime": {
    "toRiskOn": {
      "condition": "Binary condition with specific levels",
      "likelihood": "High | Medium | Low",
      "timeframe": "Could happen within X"
    },
    "toRiskOff": {
      "condition": "Binary condition with specific levels",
      "likelihood": "High | Medium | Low",
      "timeframe": "Could happen within X"
    }
  },
  
  "top5Takeaways": [
    {
      "number": 1,
      "observation": "What we saw",
      "soWhat": "Why it matters",
      "whosImpacted": "Who",
      "whatToWatch": "Next 14 days",
      "signal": "bullish | neutral | bearish"
    },
    {
      "number": 2,
      "observation": "Observation",
      "soWhat": "Implication",
      "whosImpacted": "Who",
      "whatToWatch": "What to watch",
      "signal": "bullish | neutral | bearish"
    },
    {
      "number": 3,
      "observation": "Observation",
      "soWhat": "Implication",
      "whosImpacted": "Who",
      "whatToWatch": "What to watch",
      "signal": "bullish | neutral | bearish"
    },
    {
      "number": 4,
      "observation": "Observation",
      "soWhat": "Implication",
      "whosImpacted": "Who",
      "whatToWatch": "What to watch",
      "signal": "bullish | neutral | bearish"
    },
    {
      "number": 5,
      "observation": "Observation",
      "soWhat": "Implication",
      "whosImpacted": "Who",
      "whatToWatch": "What to watch",
      "signal": "bullish | neutral | bearish"
    }
  ],
  
  "oneChartThatMatters": {
    "chart": "Which chart type",
    "description": "What it shows",
    "why": "One sentence why this chart is most important right now",
    "keyLevel": "What to watch on this chart"
  },
  
  "closingStatement": {
    "synthesis": "2-3 sentences: final synthesis bringing it all together",
    "actionRecommendation": "One clear action recommendation for the coming 2 weeks",
    "riskWarning": "Key risk to be aware of"
  },
  
  "reportQuality": {
    "coherenceScore": ${coherence?.coherenceScore || 0},
    "grade": "${coherence?.grade || 'B'}",
    "dataConfidence": "${coherence?.confidenceAssessment?.overall || 'Medium'}",
    "limitations": "Brief note on any significant limitations"
  }
}`;

    const result = await aiService.complete(prompt, { temperature: 0.4 });
    if (!result.success) {
      return { success: false, data: null, error: result.error, duration: Date.now() - startTime };
    }
    
    return {
      success: true,
      data: result.data,
      aiTokens: result.usage?.total_tokens,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// Agent 25: Data Appendix Generator (No AI)
// Section 12: Data Appendix
// ============================================
async function executeDataAppendixGenerator(context) {
  const startTime = Date.now();
  try {
    const marketData = context.results.market_data_fetcher?.data;
    const derivativesData = context.results.derivatives_data_fetcher?.data;
    const onchainData = context.results.onchain_data_fetcher?.data;
    const coherence = context.results.coherence_checker?.data;
    
    const appendix = {
      // Data Sources
      sources: [
        {
          name: 'CoinGecko',
          type: 'Market Data',
          endpoint: 'api.coingecko.com/api/v3',
          dataProvided: ['Prices', 'Market caps', 'Volume', 'Historical data'],
          limitations: 'Rate limited (30 req/min free tier)',
          reliability: 'High',
        },
        {
          name: 'Binance Futures',
          type: 'Derivatives',
          endpoint: 'fapi.binance.com',
          dataProvided: ['Funding rates', 'Open interest', 'Liquidations', 'Long/short ratios'],
          limitations: 'Public endpoints only, no historical liquidation data',
          reliability: 'High',
        },
        {
          name: 'DeFiLlama',
          type: 'On-Chain / DeFi',
          endpoint: 'api.llama.fi',
          dataProvided: ['TVL by chain/protocol', 'Stablecoin supply'],
          limitations: 'TVL methodology varies by protocol',
          reliability: 'High',
        },
        {
          name: 'Alternative.me',
          type: 'Sentiment',
          endpoint: 'api.alternative.me/fng',
          dataProvided: ['Fear & Greed Index'],
          limitations: 'Daily updates only, methodology opaque',
          reliability: 'Medium',
        },
        {
          name: 'Blockchain.com',
          type: 'Bitcoin On-Chain',
          endpoint: 'blockchain.info/charts',
          dataProvided: ['Hash rate', 'Transaction count', 'Basic metrics'],
          limitations: 'Limited metrics, no advanced on-chain',
          reliability: 'Medium',
        },
      ],
      
      // Definitions
      definitions: {
        fundingRate: {
          term: 'Funding Rate',
          definition: 'Periodic payment between long and short perpetual futures traders. Positive = longs pay shorts.',
          calculation: '8-hour rate × 3 × 365 = annualized rate',
          interpretation: '>0.05% 8h (55% ann.) = extreme, correction likely',
        },
        openInterest: {
          term: 'Open Interest (OI)',
          definition: 'Total value of outstanding futures contracts. Measures leverage in the system.',
          interpretation: 'OI↑ + Price↑ = trend confirmation; OI↑ + Price→ = fragility',
        },
        dominance: {
          term: 'Dominance (BTC.D, ETH.D)',
          definition: "Asset's market cap as percentage of total crypto market cap.",
          interpretation: 'Rising BTC.D = flight to quality; Falling BTC.D = alt season',
        },
        tvl: {
          term: 'Total Value Locked (TVL)',
          definition: 'Total value of assets deposited in DeFi protocols.',
          interpretation: 'TVL growth indicates DeFi adoption and capital deployment',
        },
        atr: {
          term: 'ATR (Average True Range)',
          definition: 'Measure of volatility based on price range over a period.',
          interpretation: 'Higher ATR = more volatile, adjust position size accordingly',
        },
        liquidation: {
          term: 'Liquidation',
          definition: 'Forced closing of leveraged position when margin is insufficient.',
          interpretation: 'Large liquidations can cascade and accelerate price moves',
        },
        longShortRatio: {
          term: 'Long/Short Ratio',
          definition: 'Ratio of long to short positions. >1 = more longs, <1 = more shorts.',
          interpretation: '>1.5 = crowded long (bearish); <0.7 = crowded short (bullish)',
        },
      },
      
      // Regime Scoring Methodology
      methodology: {
        regime: {
          title: 'Market Regime Scoring',
          description: 'Regime score (0-100) based on weighted inputs from multiple data sources.',
          weights: {
            priceStructure: '30% - Trend direction, key levels, momentum',
            positioning: '35% - Funding, OI, long/short ratio',
            flows: '20% - Stablecoins, ETF flows (if available)',
            sentiment: '15% - Fear & Greed, social metrics',
          },
          scoring: {
            'RISK-ON': '70-100',
            'TRANSITIONAL-BULLISH': '55-69',
            'NEUTRAL': '45-54',
            'TRANSITIONAL-BEARISH': '30-44',
            'RISK-OFF': '0-29',
          },
        },
      },
      
      // Known Limitations
      limitations: [
        {
          category: 'On-Chain Data',
          limitation: 'No Glassnode/CryptoQuant access',
          impact: 'Cannot provide exchange flow data, whale tracking, SOPR, NUPL',
          mitigation: 'Using stablecoin supply as proxy for capital flows',
        },
        {
          category: 'Options Data',
          limitation: 'No Deribit options data',
          impact: 'Cannot provide implied volatility, put/call ratio, max pain',
          mitigation: 'Using realized volatility from spot prices',
        },
        {
          category: 'ETF Flows',
          limitation: 'ETF flow data from news sources',
          impact: 'May be delayed or incomplete',
          mitigation: 'Marked with [ETF DATA FROM NEWS SOURCES] tag',
        },
        {
          category: 'Exchange Coverage',
          limitation: 'Primarily Binance data for derivatives',
          impact: 'May not capture full market positioning',
          mitigation: 'Binance represents ~50% of derivatives market',
        },
        {
          category: 'Token Unlocks',
          limitation: 'Unlock schedules from public sources',
          impact: 'Schedules may change, some unlocks not tracked',
          mitigation: 'Recommend verifying with official sources before trading',
        },
      ],
      
      // Data Tags Used
      dataTags: {
        '[FREE DATA UNAVAILABLE]': 'Data requires paid subscription not available',
        '[ON-CHAIN LIMITATION]': 'On-chain data limited without Glassnode/CryptoQuant',
        '[PROXY]': 'Using proxy metric instead of direct data',
        '[ETF DATA FROM NEWS SOURCES]': 'ETF flows from news, may be delayed',
        '[TIMING UNCERTAIN]': 'Event date not confirmed from official source',
        '[DATA NOT AVAILABLE]': 'Data point not available from any source',
      },
      
      // Report Metadata
      metadata: {
        generatedAt: new Date().toISOString(),
        version: '6.0.0',
        agentCount: 25,
        aiModel: 'Claude Sonnet 4',
        dataFreshness: {
          marketData: marketData?.fetchedAt || 'Unknown',
          derivatives: derivativesData?.fetchedAt || 'Unknown',
          onchain: onchainData?.fetchedAt || 'Unknown',
        },
        qualityScore: coherence?.coherenceScore || null,
        qualityGrade: coherence?.grade || null,
      },
      
      // Disclaimer
      disclaimer: {
        isFinancialAdvice: false,
        purpose: 'Educational and informational purposes only',
        riskWarning: 'Cryptocurrency trading involves substantial risk of loss. Past performance does not guarantee future results.',
        dataDisclaimer: 'Data sourced from third-party providers. No guarantee of accuracy or completeness.',
        noLiability: 'Authors and publishers assume no liability for any losses incurred.',
      },
    };
    
    return {
      success: true,
      data: appendix,
      duration: Date.now() - startTime,
    };
  } catch (error) {
    return { success: false, data: null, error: error.message, duration: Date.now() - startTime };
  }
}

// ============================================
// AGENT EXECUTOR MAP
// ============================================

const AGENT_EXECUTORS = {
  // Phase 1: Data Acquisition
  market_data_fetcher: executeMarketDataFetcher,
  onchain_data_fetcher: executeOnchainDataFetcher,
  derivatives_data_fetcher: executeDerivativesDataFetcher,
  
  // Phase 2: Executive Brief (Section 1)
  regime_detector: executeRegimeDetector,
  regime_flip_analyzer: executeRegimeFlipAnalyzer,
  top5_takeaways_generator: executeTop5TakeawaysGenerator,
  
  // Phase 3: Price & Structure (Section 2)
  price_structure_analyzer: executePriceStructureAnalyzer,
  dominance_analyzer: executeDominanceAnalyzer,
  
  // Phase 4: Liquidity & Risk (Section 3)
  volatility_regime_analyzer: executeVolatilityRegimeAnalyzer,
  liquidity_stress_analyzer: executeLiquidityStressAnalyzer,
  
  // Phase 5: Derivatives & Positioning (Section 4)
  funding_analyzer: executeFundingAnalyzer,
  oi_analyzer: executeOIAnalyzer,
  liquidation_mapper: executeLiquidationMapper,
  
  // Phase 6: Flows & Supply (Section 5)
  flows_analyzer: executeFlowsAnalyzer,
  token_unlocks_analyzer: executeTokenUnlocksAnalyzer,
  
  // Phase 7: Sector Rotation (Section 6)
  sector_performance_analyzer: executeSectorPerformanceAnalyzer,
  rotation_signal_analyzer: executeRotationSignalAnalyzer,
  
  // Phase 8: Narratives (Section 7)
  narratives_analyzer: executeNarrativesAnalyzer,
  
  // Phase 9: Catalyst Calendar (Section 8)
  catalyst_calendar_generator: executeCatalystCalendarGenerator,
  
  // Phase 10: Trade Playbook (Section 9-10)
  trade_idea_generator: executeTradeIdeaGenerator,
  risk_psychology_advisor: executeRiskPsychologyAdvisor,
  
  // Phase 11: Watchlist (Section 11)
  watchlist_generator: executeWatchlistGenerator,
  
  // Phase 12: Quality Assurance
  coherence_checker: executeCoherenceChecker,
  executive_summary_writer: executeExecutiveSummaryWriter,
  data_appendix_generator: executeDataAppendixGenerator,
};

// ============================================
// EXPORTS
// ============================================

export {
  AGENT_DEFINITIONS,
  AGENT_EXECUTORS,
  DATA_TAGS,
  SYSTEM_PROMPTS,
};