// =====================================================
// CRYPTO DATA TRANSFORMER v1.1 - FIXED N/A ISSUES
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/data-transformer.js
//
// מתרגם את הנתונים הגולמיים מ-APIs למבנה שה-report-generator מצפה לו
// 
// FIXES in v1.1:
// - Fixed formatPercent for small values (0.003% was showing as N/A)
// - Lowered thresholds for momentum/mean reversion
// - Added sector calculation from coin data
// - Added quality score calculation
// - Fixed truthy checks to explicit null checks
// =====================================================

// ============================================
// FORMATTING UTILITIES
// ============================================

function formatPrice(price) {
  if (price === null || price === undefined || isNaN(price)) return null;
  return parseFloat(price);
}

/**
 * Format percent with appropriate precision
 * Small values get more decimal places
 */
function formatPercent(val) {
  if (val === null || val === undefined) return null;
  const num = parseFloat(val);
  if (isNaN(num)) return null;
  
  // For very small values, use more precision
  if (Math.abs(num) < 0.01) {
    return parseFloat(num.toFixed(4));
  }
  if (Math.abs(num) < 0.1) {
    return parseFloat(num.toFixed(3));
  }
  return parseFloat(num.toFixed(2));
}

/**
 * Format percent as string with % sign
 * Handles small values appropriately
 */
function formatPercentString(val) {
  if (val === null || val === undefined) return null;
  const num = parseFloat(val);
  if (isNaN(num)) return null;
  
  // For very small values, use more precision
  if (Math.abs(num) < 0.01) {
    return `${num.toFixed(4)}%`;
  }
  if (Math.abs(num) < 0.1) {
    return `${num.toFixed(3)}%`;
  }
  return `${num.toFixed(2)}%`;
}

function formatLargeNumber(num) {
  if (num === null || num === undefined || isNaN(num)) return null;
  return parseFloat(num);
}

function safeGet(obj, path, defaultVal = null) {
  try {
    const result = path.split('.').reduce((o, k) => (o || {})[k], obj);
    return result !== undefined && result !== null ? result : defaultVal;
  } catch {
    return defaultVal;
  }
}

// ============================================
// REGIME CALCULATION
// ============================================

function calculateMarketRegime(marketData, derivativesData, onchainData) {
  let score = 50; // Start neutral
  let confidence = 'Medium';
  const components = {};
  
  // 1. Fear & Greed (15% weight)
  const fearGreed = safeGet(marketData, 'fearGreed.value', 50);
  const fgScore = (parseInt(fearGreed) - 50) * 0.3; // -15 to +15
  score += fgScore;
  components.fearGreed = { value: fearGreed, contribution: fgScore };
  
  // 2. Price Momentum - BTC 7D change (30% weight)
  const btc7d = safeGet(marketData, 'btc.change7d', 0) || 
                safeGet(marketData, 'btc.price_change_percentage_7d_in_currency', 0);
  const momentumScore = Math.max(-15, Math.min(15, btc7d * 1.5));
  score += momentumScore;
  components.momentum = { btc7d, contribution: momentumScore };
  
  // 3. Funding Rate (15% weight)
  const btcFunding = safeGet(derivativesData, 'fundingRates.btc', 0) || 
                     safeGet(derivativesData, 'funding.BTC', 0);
  let fundingScore = 0;
  if (btcFunding > 0.0005) fundingScore = -5; // Overheated longs
  else if (btcFunding < -0.0005) fundingScore = 5; // Squeeze potential
  score += fundingScore;
  components.funding = { rate: btcFunding, contribution: fundingScore };
  
  // 4. Open Interest (10% weight)
  const oiChange = safeGet(derivativesData, 'openInterestHistory.btcChange14d', 0);
  const priceChange = btc7d;
  let oiScore = 0;
  if (oiChange > 0 && priceChange > 0) oiScore = 5;
  if (oiChange > 0 && priceChange < 0) oiScore = -5;
  score += oiScore;
  components.openInterest = { change: oiChange, contribution: oiScore };
  
  // 5. Long/Short Ratio (10% weight)
  const lsRatio = safeGet(derivativesData, 'longShortRatio.btc', 1);
  let lsScore = 0;
  if (lsRatio > 1.5) lsScore = -5; // Crowded longs
  else if (lsRatio < 0.7) lsScore = 5; // Crowded shorts
  score += lsScore;
  components.longShort = { ratio: lsRatio, contribution: lsScore };
  
  // 6. Stablecoin Flow (10% weight)
  const stableChange = safeGet(onchainData, 'stablecoins.change14d', 0) ||
                       safeGet(marketData, 'stablecoins.change14d', 0);
  let stableScore = 0;
  if (stableChange > 2) stableScore = 5;
  else if (stableChange < -2) stableScore = -5;
  score += stableScore;
  components.stablecoins = { change14d: stableChange, contribution: stableScore };
  
  // 7. 24h price action (10% weight)
  const btc24h = safeGet(marketData, 'btc.change24h', 0) ||
                 safeGet(marketData, 'btc.price_change_percentage_24h', 0);
  const shortTermScore = Math.max(-5, Math.min(5, btc24h * 0.5));
  score += shortTermScore;
  components.shortTerm = { btc24h, contribution: shortTermScore };
  
  // Normalize score to 0-100
  score = Math.max(0, Math.min(100, score));
  
  // Determine regime label
  let label, emoji, summary;
  if (score >= 70) {
    label = 'RISK-ON';
    emoji = '🟢';
    confidence = 'High';
    summary = 'Strong bullish momentum with increasing risk appetite across the market.';
  } else if (score >= 55) {
    label = 'TRANSITIONAL-BULLISH';
    emoji = '🟡';
    confidence = 'Medium';
    summary = 'Improving conditions suggest cautious optimism. Watch for confirmation.';
  } else if (score >= 45) {
    label = 'NEUTRAL';
    emoji = '⚪';
    confidence = 'Medium';
    summary = 'Range-bound market with no clear directional bias. Selective positioning advised.';
  } else if (score >= 30) {
    label = 'TRANSITIONAL-BEARISH';
    emoji = '🟠';
    confidence = 'Medium';
    summary = 'Deteriorating conditions warrant increased caution and reduced exposure.';
  } else {
    label = 'RISK-OFF';
    emoji = '🔴';
    confidence = 'High';
    summary = 'Bearish conditions with risk aversion and deleveraging in progress.';
  }
  
  return {
    label,
    emoji,
    score: Math.round(score),
    confidence,
    summary,
    components,
  };
}

// ============================================
// KEY LEVELS CALCULATION
// ============================================

function calculateKeyLevels(price, high14d, low14d, volatility = 0.08) {
  if (!price) return null;
  
  const roundToSignificant = (p) => {
    if (p > 50000) return Math.round(p / 1000) * 1000;
    if (p > 10000) return Math.round(p / 500) * 500;
    if (p > 1000) return Math.round(p / 50) * 50;
    if (p > 100) return Math.round(p / 10) * 10;
    if (p > 10) return Math.round(p / 1) * 1;
    return Math.round(p * 100) / 100;
  };
  
  const supports = [];
  const resistances = [];
  
  // Use actual high/low if available
  if (high14d && high14d > price) {
    resistances.push({ price: roundToSignificant(high14d), significance: '14D High' });
  }
  if (low14d && low14d < price) {
    supports.push({ price: roundToSignificant(low14d), significance: '14D Low' });
  }
  
  // Calculate additional levels
  const s1 = roundToSignificant(price * (1 - volatility * 0.5));
  const s2 = roundToSignificant(price * (1 - volatility));
  const r1 = roundToSignificant(price * (1 + volatility * 0.5));
  const r2 = roundToSignificant(price * (1 + volatility));
  
  if (s1 < price && !supports.find(s => Math.abs(s.price - s1) < s1 * 0.02)) {
    supports.push({ price: s1, significance: 'Support 1 (-4%)' });
  }
  if (s2 < price && !supports.find(s => Math.abs(s.price - s2) < s2 * 0.02)) {
    supports.push({ price: s2, significance: 'Support 2 (-8%)' });
  }
  if (r1 > price && !resistances.find(r => Math.abs(r.price - r1) < r1 * 0.02)) {
    resistances.push({ price: r1, significance: 'Resistance 1 (+4%)' });
  }
  if (r2 > price && !resistances.find(r => Math.abs(r.price - r2) < r2 * 0.02)) {
    resistances.push({ price: r2, significance: 'Resistance 2 (+8%)' });
  }
  
  return {
    supports: supports.sort((a, b) => b.price - a.price).slice(0, 3),
    resistances: resistances.sort((a, b) => a.price - b.price).slice(0, 3),
    breakoutLevel: resistances[0]?.price || r1,
    breakdownLevel: supports[0]?.price || s1,
  };
}

// ============================================
// TREND DETERMINATION
// ============================================

function determineTrend(change24h, change7d, change14d) {
  const shortTerm = change24h || 0;
  const mediumTerm = change7d || 0;
  const longTerm = change14d || change7d || 0;
  
  // All positive = uptrend
  if (shortTerm > 1 && mediumTerm > 3 && longTerm > 5) return 'UPTREND';
  // All negative = downtrend
  if (shortTerm < -1 && mediumTerm < -3 && longTerm < -5) return 'DOWNTREND';
  // Mixed or flat
  if (Math.abs(mediumTerm) < 3 && Math.abs(longTerm) < 5) return 'SIDEWAYS';
  // Recovery
  if (shortTerm > 2 && longTerm < -3) return 'RECOVERING';
  // Pullback
  if (shortTerm < -2 && longTerm > 3) return 'PULLBACK';
  
  return 'MIXED';
}

// ============================================
// VOLATILITY ANALYSIS
// ============================================

function analyzeVolatility(high14d, low14d, currentPrice, btc24hChange) {
  if (!high14d || !low14d || !currentPrice) {
    return {
      state: 'NORMAL',
      score: 50,
      realized14d: null,
      atrProxy: null,
      trend: 'Unknown',
    };
  }
  
  // Calculate 14D range as volatility proxy
  const range14d = ((high14d - low14d) / low14d) * 100;
  
  // ATR proxy from daily moves
  const atrProxy = Math.abs(btc24hChange || 2);
  
  let state, score;
  if (range14d > 25) {
    state = 'HIGH';
    score = 80;
  } else if (range14d > 15) {
    state = 'ELEVATED';
    score = 65;
  } else if (range14d > 8) {
    state = 'NORMAL';
    score = 50;
  } else {
    state = 'LOW';
    score = 30;
  }
  
  // Trend detection
  const trend = range14d > 20 && atrProxy > 3 ? 'EXPANDING' : 
                range14d < 10 && atrProxy < 2 ? 'COMPRESSING' : 'STABLE';
  
  return {
    state,
    score,
    realized14d: formatPercent(range14d),
    atrProxy: formatPercent(atrProxy),
    trend,
  };
}

// ============================================
// FUNDING RATE ANALYSIS - FIXED FOR SMALL VALUES
// ============================================

function analyzeFunding(rate8h) {
  // FIXED: Use explicit null check instead of truthy check
  if (rate8h === null || rate8h === undefined) {
    return { rate8h: null, annualized: null, trend: 'Unknown', signal: 'Unknown' };
  }
  
  const numRate = parseFloat(rate8h);
  if (isNaN(numRate)) {
    return { rate8h: null, annualized: null, trend: 'Unknown', signal: 'Unknown' };
  }
  
  const annualized = numRate * 3 * 365 * 100; // Convert to annual %
  
  let signal, trend;
  if (numRate > 0.001) {
    signal = 'EXTREME_POSITIVE';
    trend = 'Overheated longs - correction likely';
  } else if (numRate > 0.0005) {
    signal = 'POSITIVE';
    trend = 'Bullish bias, elevated leverage';
  } else if (numRate > 0) {
    signal = 'NEUTRAL_POSITIVE';
    trend = 'Mild bullish bias';
  } else if (numRate > -0.0003) {
    signal = 'NEUTRAL_NEGATIVE';
    trend = 'Mild bearish bias';
  } else {
    signal = 'NEGATIVE';
    trend = 'Bearish bias - short squeeze potential';
  }
  
  // FIXED: Return the rate as percentage with appropriate precision
  // rate8h is in decimal form (e.g., 0.0001 = 0.01%)
  const rate8hPercent = numRate * 100;
  
  return {
    rate8h: formatPercent(rate8hPercent), // Now returns small values correctly
    rate8hString: formatPercentString(rate8hPercent), // e.g., "0.0033%"
    annualized: formatPercent(annualized),
    annualizedString: formatPercentString(annualized),
    trend,
    signal,
  };
}

// ============================================
// LIQUIDATION ANALYSIS
// ============================================

function analyzeLiquidations(total24h, long24h, short24h) {
  if (!total24h) {
    return {
      total24h: null,
      long24h: null,
      short24h: null,
      longPercent: null,
      shortPercent: null,
      dominant: 'Balanced',
      signal: 'Unknown',
    };
  }
  
  const longPct = long24h ? (long24h / total24h) * 100 : 50;
  const shortPct = short24h ? (short24h / total24h) * 100 : 50;
  
  let dominant, signal;
  if (longPct > 65) {
    dominant = 'LONGS';
    signal = 'Long squeeze in progress - potential bottom forming';
  } else if (shortPct > 65) {
    dominant = 'SHORTS';
    signal = 'Short squeeze in progress - potential top forming';
  } else {
    dominant = 'BALANCED';
    signal = 'No significant squeeze - normal market conditions';
  }
  
  return {
    total24h,
    long24h,
    short24h,
    longPercent: formatPercent(longPct),
    shortPercent: formatPercent(shortPct),
    dominant,
    signal,
  };
}

// ============================================
// MARKET HEALTH SCORE
// ============================================

function calculateMarketHealth(regime, volatility, funding, liquidations) {
  let score = 50;
  let factors = [];
  
  // Regime contribution
  if (regime?.score > 60) {
    score += 10;
    factors.push('Positive market regime');
  } else if (regime?.score < 40) {
    score -= 10;
    factors.push('Negative market regime');
  }
  
  // Volatility contribution
  if (volatility?.state === 'LOW' || volatility?.state === 'NORMAL') {
    score += 10;
    factors.push('Healthy volatility levels');
  } else if (volatility?.state === 'HIGH') {
    score -= 10;
    factors.push('Elevated volatility risk');
  }
  
  // Funding contribution
  if (funding?.signal === 'NEUTRAL_POSITIVE' || funding?.signal === 'NEUTRAL_NEGATIVE') {
    score += 10;
    factors.push('Balanced funding rates');
  } else if (funding?.signal === 'EXTREME_POSITIVE') {
    score -= 15;
    factors.push('Overheated leverage');
  }
  
  // Liquidation contribution
  if (liquidations?.total24h && liquidations.total24h > 500000000) {
    score -= 10;
    factors.push('Heavy liquidation activity');
  }
  
  score = Math.max(0, Math.min(100, score));
  
  let label;
  if (score >= 70) label = 'HEALTHY';
  else if (score >= 50) label = 'CAUTION';
  else label = 'STRESS';
  
  return { score, label, factors, mainRisk: factors[factors.length - 1] || 'None identified' };
}

// ============================================
// FORWARD SCENARIOS
// ============================================

function generateScenarios(regime, btcPrice, keyLevels) {
  if (!btcPrice || !keyLevels) return null;
  
  const regimeScore = regime?.score || 50;
  
  let basePct, upsidePct, downsidePct;
  
  if (regimeScore >= 70) {
    basePct = 30; upsidePct = 50; downsidePct = 20;
  } else if (regimeScore >= 55) {
    basePct = 40; upsidePct = 40; downsidePct = 20;
  } else if (regimeScore >= 45) {
    basePct = 50; upsidePct = 25; downsidePct = 25;
  } else if (regimeScore >= 30) {
    basePct = 40; upsidePct = 20; downsidePct = 40;
  } else {
    basePct = 30; upsidePct = 15; downsidePct = 55;
  }
  
  const support1 = keyLevels.supports?.[0]?.price || btcPrice * 0.95;
  const support2 = keyLevels.supports?.[1]?.price || btcPrice * 0.90;
  const resistance1 = keyLevels.resistances?.[0]?.price || btcPrice * 1.05;
  const resistance2 = keyLevels.resistances?.[1]?.price || btcPrice * 1.10;
  
  return {
    base: {
      probability: basePct,
      description: 'Consolidation within current range',
      range: { low: support1, high: resistance1 },
      triggers: ['Range-bound price action', 'Mixed signals', 'Low catalyst environment'],
    },
    upside: {
      probability: upsidePct,
      description: 'Breakout with momentum continuation',
      target: { low: resistance1, high: resistance2 },
      triggers: ['Break above key resistance', 'Positive macro catalyst', 'ETF inflows'],
    },
    downside: {
      probability: downsidePct,
      description: 'Correction to reset leverage and sentiment',
      target: { low: support2, high: support1 },
      triggers: ['Break below support', 'Negative macro news', 'Leverage flush'],
    },
  };
}

// ============================================
// TOP 5 TAKEAWAYS GENERATOR
// ============================================

function generateTakeaways(regime, marketData, derivativesData, onchainData) {
  const takeaways = [];
  
  // 1. Regime takeaway
  takeaways.push({
    observation: `Market regime is ${regime?.label || 'NEUTRAL'} with ${regime?.score || 50}/100 score`,
    soWhat: regime?.score > 55 ? 'Favor long positions, use dips to add' : 
            regime?.score < 45 ? 'Reduce exposure, focus on capital preservation' :
            'Selective positioning, avoid directional bets',
    whosImpacted: 'All crypto traders',
    whatToWatch: 'Regime flip triggers and key level breaks',
    signal: regime?.score > 55 ? 'bullish' : regime?.score < 45 ? 'bearish' : 'neutral',
  });
  
  // 2. BTC momentum
  const btc7d = safeGet(marketData, 'btc.change7d', 0);
  const btcTrend = btc7d > 5 ? 'bullish' : btc7d < -5 ? 'bearish' : 'neutral';
  takeaways.push({
    observation: `BTC ${btc7d > 0 ? 'up' : 'down'} ${Math.abs(btc7d || 0).toFixed(1)}% over 7 days`,
    soWhat: btcTrend === 'bullish' ? 'Momentum favors continuation, but watch for exhaustion' :
            btcTrend === 'bearish' ? 'Wait for stabilization before adding' :
            'Range trading opportunities, fade extremes',
    whosImpacted: 'BTC holders, spot traders',
    whatToWatch: btcTrend === 'bullish' ? 'Resistance tests and volume confirmation' :
                  'Support holds and reversal patterns',
    signal: btcTrend,
  });
  
  // 3. Derivatives positioning
  const funding = safeGet(derivativesData, 'fundingRates.btc', 0);
  const fundingLevel = funding > 0.0005 ? 'elevated' : funding < 0 ? 'negative' : 'neutral';
  takeaways.push({
    observation: `BTC funding ${fundingLevel} at ${formatPercentString(funding * 100) || '0%'} (8h)`,
    soWhat: fundingLevel === 'elevated' ? 'Long positioning is stretched — potential for unwind' :
            fundingLevel === 'negative' ? 'Short squeeze setup developing' :
            'Balanced positioning, healthy for continuation',
    whosImpacted: 'Futures traders, leverage positions',
    whatToWatch: 'Funding rate normalization or extremes',
    signal: fundingLevel === 'elevated' ? 'bearish' : fundingLevel === 'negative' ? 'bullish' : 'neutral',
  });
  
  // 4. Stablecoin liquidity
  const stableSupply = safeGet(onchainData, 'stablecoins.totalSupply', null) ||
                       safeGet(marketData, 'stablecoins.totalSupply', null);
  const stableChange = safeGet(onchainData, 'stablecoins.change14d', 0);
  takeaways.push({
    observation: `Stablecoin supply ${stableChange > 0 ? 'growing' : 'stable'} at $${stableSupply ? (stableSupply / 1e9).toFixed(1) + 'B' : 'N/A'}`,
    soWhat: stableChange > 2 ? 'Fresh capital entering, bullish for liquidity' :
            stableChange < -2 ? 'Capital exiting, watch for liquidity stress' :
            'Stable liquidity conditions',
    whosImpacted: 'All market participants',
    whatToWatch: 'USDT/USDC supply changes and ETF flows',
    signal: stableChange > 2 ? 'bullish' : stableChange < -2 ? 'bearish' : 'neutral',
  });
  
  // 5. Fear & Greed
  const fearGreed = safeGet(marketData, 'fearGreed.value', 50);
  const fgChange = safeGet(marketData, 'fearGreed.change14d', 0);
  takeaways.push({
    observation: `Fear & Greed at ${fearGreed} (${fearGreed > 60 ? 'Greed' : fearGreed < 40 ? 'Fear' : 'Neutral'})`,
    soWhat: fearGreed > 75 ? 'Extreme greed - consider taking profits' :
            fearGreed < 25 ? 'Extreme fear - potential accumulation zone' :
            'Balanced sentiment, follow price action',
    whosImpacted: 'Sentiment traders, contrarians',
    whatToWatch: fgChange > 10 ? 'Sentiment momentum continuation' : 'Potential sentiment reversal',
    signal: fearGreed > 60 ? 'bullish' : fearGreed < 40 ? 'bearish' : 'neutral',
  });
  
  return takeaways;
}

// ============================================
// WHAT FLIPS THE REGIME
// ============================================

function generateRegimeFlipTriggers(regime, marketData, derivativesData) {
  const btcPrice = safeGet(marketData, 'btc.price', 0) || safeGet(marketData, 'btc.current_price', 0);
  const keyResistance = btcPrice * 1.08;
  const keySupport = btcPrice * 0.92;
  
  const toRiskOn = {
    condition: regime?.score < 55 ? 
      `BTC breaks above $${Math.round(keyResistance).toLocaleString()} with volume, funding normalizes` :
      'Already in bullish regime - watch for confirmation',
    likelihood: regime?.score < 45 ? 'Low (30%)' : regime?.score < 55 ? 'Medium (45%)' : 'High (65%)',
    triggers: [
      `Price break above $${Math.round(keyResistance).toLocaleString()}`,
      'ETF inflows > $500M weekly',
      'Fear & Greed rises above 60',
    ],
  };
  
  const toRiskOff = {
    condition: regime?.score > 45 ?
      `BTC breaks below $${Math.round(keySupport).toLocaleString()}, funding spikes, stablecoin outflows` :
      'Already in bearish regime - watch for capitulation',
    likelihood: regime?.score > 55 ? 'Low (25%)' : regime?.score > 45 ? 'Medium (40%)' : 'High (60%)',
    triggers: [
      `Price break below $${Math.round(keySupport).toLocaleString()}`,
      'ETF outflows > $500M weekly',
      'Fear & Greed drops below 30',
    ],
  };
  
  return { toRiskOn, toRiskOff };
}

// ============================================
// SECTOR DATA - IMPROVED WITH COIN MAPPING
// ============================================

// Expanded sector mapping
const SECTOR_MAP = {
  // Layer 1
  'SOL': 'Layer 1', 'ADA': 'Layer 1', 'AVAX': 'Layer 1', 'DOT': 'Layer 1', 
  'NEAR': 'Layer 1', 'APT': 'Layer 1', 'SUI': 'Layer 1', 'ATOM': 'Layer 1',
  'FTM': 'Layer 1', 'XLM': 'Layer 1', 'HBAR': 'Layer 1', 'XTZ': 'Layer 1',
  // Layer 2
  'ARB': 'Layer 2', 'OP': 'Layer 2', 'MATIC': 'Layer 2', 'IMX': 'Layer 2',
  'STRK': 'Layer 2', 'MNT': 'Layer 2', 'METIS': 'Layer 2', 'ZK': 'Layer 2',
  // Infrastructure
  'LINK': 'Infrastructure', 'GRT': 'Infrastructure', 'FIL': 'Infrastructure',
  'PYTH': 'Infrastructure', 'AR': 'Infrastructure', 'STX': 'Infrastructure',
  // DeFi
  'UNI': 'DeFi', 'AAVE': 'DeFi', 'MKR': 'DeFi', 'CRV': 'DeFi',
  'INJ': 'DeFi', 'JUP': 'DeFi', 'LDO': 'DeFi', 'SNX': 'DeFi',
  'SUSHI': 'DeFi', 'COMP': 'DeFi', 'YFI': 'DeFi', 'DYDX': 'DeFi',
  // AI & Compute
  'RNDR': 'AI & Compute', 'FET': 'AI & Compute', 'TAO': 'AI & Compute',
  'THETA': 'AI & Compute', 'AGIX': 'AI & Compute', 'AKT': 'AI & Compute',
  'WLD': 'AI & Compute', 'OCEAN': 'AI & Compute',
  // Gaming
  'AXS': 'Gaming', 'SAND': 'Gaming', 'MANA': 'Gaming', 'ILV': 'Gaming',
  'GALA': 'Gaming', 'ENJ': 'Gaming', 'PRIME': 'Gaming',
  // Memes
  'DOGE': 'Memes', 'SHIB': 'Memes', 'PEPE': 'Memes', 'WIF': 'Memes',
  'BONK': 'Memes', 'FLOKI': 'Memes', 'MEME': 'Memes',
  // RWA
  'ONDO': 'RWA', 'MAPLE': 'RWA',
};

function generateSectorData(marketData) {
  // Initialize sectors
  const sectorsData = {
    'Layer 1': { returns: [], volatility: 'Medium', narrativeDriver: 'Scaling & adoption' },
    'Layer 2': { returns: [], volatility: 'High', narrativeDriver: 'ETH ecosystem growth' },
    'DeFi': { returns: [], volatility: 'High', narrativeDriver: 'TVL recovery, new protocols' },
    'AI & Compute': { returns: [], volatility: 'Very High', narrativeDriver: 'AI narrative, GPU demand' },
    'Gaming': { returns: [], volatility: 'High', narrativeDriver: 'AAA launches' },
    'Memes': { returns: [], volatility: 'Extreme', narrativeDriver: 'Social trends' },
    'RWA': { returns: [], volatility: 'Low', narrativeDriver: 'Tokenization narrative' },
    'Infrastructure': { returns: [], volatility: 'Medium', narrativeDriver: 'Network upgrades' },
  };
  
  // Get coins from various possible data structures
  const coins = safeGet(marketData, 'coins', []) || [];
  
  // Process each coin
  for (const coin of coins) {
    const symbol = (coin.symbol || coin.id || '').toUpperCase();
    const sectorName = SECTOR_MAP[symbol];
    
    if (sectorName && sectorsData[sectorName]) {
      // Get change data - try multiple formats
      const change7d = coin.price_change_percentage_7d_in_currency || 
                       coin.change7d || 
                       coin.priceChangePercent7d ||
                       null;
      const change24h = coin.price_change_percentage_24h || 
                        coin.change24h ||
                        coin.priceChangePercent24h ||
                        null;
      
      if (change7d !== null) {
        sectorsData[sectorName].returns.push({
          symbol,
          change7d: parseFloat(change7d),
          change24h: change24h ? parseFloat(change24h) : null,
        });
      }
    }
  }
  
  // Calculate sector averages and create output
  const sectors = [];
  for (const [name, data] of Object.entries(sectorsData)) {
    const returns = data.returns;
    let return7d = null;
    let return14d = null;
    let momentum = 'Neutral';
    
    if (returns.length > 0) {
      // Calculate average
      const sum7d = returns.reduce((acc, r) => acc + r.change7d, 0);
      return7d = sum7d / returns.length;
      return14d = return7d * 1.5; // Estimate 14D from 7D
      
      // Determine momentum
      if (return7d > 10) momentum = 'Strong Bullish';
      else if (return7d > 5) momentum = 'Bullish';
      else if (return7d > 0) momentum = 'Weak';
      else if (return7d > -5) momentum = 'Neutral';
      else if (return7d > -10) momentum = 'Weak';
      else momentum = 'Bearish';
    }
    
    sectors.push({
      sector: name,
      return14d: return14d !== null ? `${return14d > 0 ? '+' : ''}${return14d.toFixed(1)}%` : null,
      return7d: return7d !== null ? `${return7d > 0 ? '+' : ''}${return7d.toFixed(1)}%` : null,
      performance14d: return14d, // Raw number for sorting
      performance7d: return7d,  // Raw number for sorting
      volatility: data.volatility,
      momentum,
      narrativeDriver: data.narrativeDriver,
      coinCount: returns.length,
    });
  }
  
  return sectors;
}

// ============================================
// TRADE IDEAS GENERATOR
// ============================================

function generateTradeIdeas(regime, marketData, derivativesData, keyLevels) {
  const btcPrice = safeGet(marketData, 'btc.price', 0) || safeGet(marketData, 'btc.current_price', 0);
  const ethPrice = safeGet(marketData, 'eth.price', 0) || safeGet(marketData, 'eth.current_price', 0);
  const solPrice = safeGet(marketData, 'sol.price', 0) || 
                   safeGet(marketData, 'coins', []).find(c => c.symbol === 'SOL')?.current_price;
  
  const ideas = [];
  
  // Generate ideas based on regime
  if (regime?.score >= 55) {
    // Bullish ideas
    ideas.push({
      asset: 'BTC',
      direction: 'LONG',
      thesis: 'Bullish regime favors continuation. Look for pullbacks to key support.',
      whatMustBeTrue: ['BTC holds above $' + Math.round(btcPrice * 0.95).toLocaleString(), 'Funding stays below 0.05%', 'No negative macro catalyst'],
      invalidation: 'Break below $' + Math.round(btcPrice * 0.92).toLocaleString() + ' with volume',
      catalyst: 'Next ETF flow data or macro event',
      riskNote: 'Size appropriately - 1-2% portfolio risk max',
      execution: { type: 'SPOT', leverage: '1x', entry: 'Limit at $' + Math.round(btcPrice * 0.98).toLocaleString() },
    });
    
    if (solPrice) {
      ideas.push({
        asset: 'SOL',
        direction: 'LONG',
        thesis: 'Beta play on BTC strength. SOL outperforms in risk-on environment.',
        whatMustBeTrue: ['BTC maintains bullish structure', 'SOL/BTC ratio stable', 'L1 narrative intact'],
        invalidation: 'Break below $' + Math.round(solPrice * 0.88).toLocaleString(),
        catalyst: 'Ecosystem growth metrics, DeFi TVL on Solana',
        riskNote: 'Higher beta = higher risk. Reduce size vs BTC position.',
        execution: { type: 'SPOT', leverage: '1x', entry: 'DCA on 5% dips' },
      });
    }
  } else if (regime?.score <= 45) {
    // Bearish/defensive ideas
    ideas.push({
      asset: 'BTC',
      direction: 'REDUCE',
      thesis: 'Bearish regime suggests reducing exposure and waiting for better entry.',
      whatMustBeTrue: ['N/A - defensive positioning'],
      invalidation: 'Regime flips bullish (score > 55)',
      catalyst: 'Wait for capitulation or trend reversal',
      riskNote: 'Capital preservation priority',
      execution: { type: 'SPOT', leverage: 'N/A', entry: 'Scale out on bounces' },
    });
    
    ideas.push({
      asset: 'STABLECOIN',
      direction: 'HOLD',
      thesis: 'Park capital in stablecoins during risk-off environment.',
      whatMustBeTrue: ['Market structure remains bearish'],
      invalidation: 'Clear trend reversal with volume',
      catalyst: 'Deploy on capitulation or clear bottom formation',
      riskNote: 'Opportunity cost vs safety trade-off',
      execution: { type: 'STABLE', leverage: 'N/A', entry: 'Yield on USDC/USDT' },
    });
  } else {
    // Neutral ideas
    ideas.push({
      asset: 'BTC',
      direction: 'RANGE',
      thesis: 'Neutral regime favors range trading. Fade moves to extremes.',
      whatMustBeTrue: ['Range remains intact', 'No breakout/breakdown', 'Volume confirms range'],
      invalidation: 'Decisive break of range with volume',
      catalyst: 'Next catalyst could break the range',
      riskNote: 'Smaller position sizes in choppy markets',
      execution: { type: 'SPOT', leverage: '1x', entry: 'Buy support, sell resistance' },
    });
  }
  
  return ideas;
}

// ============================================
// WATCHLIST GENERATOR - FIXED THRESHOLDS
// ============================================

function generateWatchlist(regime, marketData) {
  const coins = safeGet(marketData, 'coins', []);
  
  const watchlist = {
    momentumLeaders: [],
    meanReversionCandidates: [],
    catalystDriven: [],
  };
  
  // Filter coins by performance - LOWERED THRESHOLDS
  for (const coin of coins) {
    const change7d = coin.price_change_percentage_7d_in_currency || coin.change7d || 0;
    const change24h = coin.price_change_percentage_24h || coin.change24h || 0;
    const symbol = coin.symbol?.toUpperCase() || coin.id;
    const price = coin.current_price || coin.price;
    
    if (!symbol || symbol === 'BTC' || symbol === 'ETH') continue;
    
    // FIXED: Lowered threshold from 15% to 8%
    if (change7d > 8) {
      watchlist.momentumLeaders.push({
        asset: symbol,
        price,
        return14d: `+${(change7d * 1.5).toFixed(1)}%`,
        change7d: `+${change7d.toFixed(1)}%`,
        reason: change7d > 15 ? 'Strong 7D momentum' : 'Positive 7D momentum',
        whatToWatch: regime?.score > 55 ? 'Consider adding on pullback' : 'Watch for exhaustion',
      });
    }
    
    // FIXED: Lowered threshold from -15% to -8% and 2% to 1%
    if (change7d < -8 && change24h > 1) {
      watchlist.meanReversionCandidates.push({
        asset: symbol,
        price,
        return14d: `${(change7d * 1.5).toFixed(1)}%`,
        change7d: `${change7d.toFixed(1)}%`,
        condition: 'Oversold bounce starting',
        whatToWatch: 'Watch for confirmation, tight stop',
      });
    }
  }
  
  // Sort by performance
  watchlist.momentumLeaders.sort((a, b) => parseFloat(b.change7d) - parseFloat(a.change7d));
  watchlist.meanReversionCandidates.sort((a, b) => parseFloat(a.change7d) - parseFloat(b.change7d));
  
  // Add some catalyst-driven manually
  watchlist.catalystDriven.push(
    { asset: 'ETH', catalyst: { event: 'Dencun impact', date: 'TBC' }, reason: 'L2 growth, ETF flows', strategy: { preEvent: 'Core holding' } },
    { asset: 'SOL', catalyst: { event: 'DeFi TVL growth', date: 'TBC' }, reason: 'Ecosystem expansion', strategy: { preEvent: 'Watch for entries' } },
    { asset: 'LINK', catalyst: { event: 'New integrations', date: 'TBC' }, reason: 'CCIP adoption', strategy: { preEvent: 'Accumulate weakness' } },
  );
  
  // Limit lists
  watchlist.momentumLeaders = watchlist.momentumLeaders.slice(0, 5);
  watchlist.meanReversionCandidates = watchlist.meanReversionCandidates.slice(0, 5);
  watchlist.catalystDriven = watchlist.catalystDriven.slice(0, 5);
  
  return watchlist;
}

// ============================================
// QUALITY SCORE CALCULATION
// ============================================

function calculateQualityScore(transformedData) {
  let score = 70; // Base score
  let issues = [];
  let strengths = [];
  
  // Check data completeness
  const btcPrice = safeGet(transformedData, 'priceStructure.btc.price');
  if (btcPrice) {
    score += 5;
    strengths.push('BTC price data available');
  } else {
    score -= 10;
    issues.push('Missing BTC price data');
  }
  
  const regime = safeGet(transformedData, 'executiveBrief.regime.label');
  if (regime) {
    score += 5;
    strengths.push('Regime calculated');
  }
  
  const funding = safeGet(transformedData, 'derivatives.funding.btc.annualized');
  if (funding !== null) {
    score += 5;
    strengths.push('Funding data available');
  } else {
    score -= 5;
    issues.push('Missing funding data');
  }
  
  const stablecoins = safeGet(transformedData, 'liquidityRisk.stablecoinPulse.totalSupply');
  if (stablecoins) {
    score += 5;
    strengths.push('Stablecoin data available');
  }
  
  const tradeIdeas = safeGet(transformedData, 'tradePlaybook.tradeIdeas', []);
  if (tradeIdeas.length > 0) {
    score += 5;
    strengths.push('Trade ideas generated');
  }
  
  // Cap score
  score = Math.max(0, Math.min(100, score));
  
  // Determine grade
  let grade;
  if (score >= 90) grade = 'A';
  else if (score >= 80) grade = 'B+';
  else if (score >= 70) grade = 'B';
  else if (score >= 60) grade = 'C';
  else grade = 'D';
  
  return {
    score,
    grade,
    passed: score >= 60,
    issues,
    strengths,
  };
}

// ============================================
// MAIN TRANSFORMER FUNCTION
// ============================================

/**
 * Transform raw API data into the report-generator format
 * @param {Object} rawData - Raw data from Binance, DefiLlama, etc.
 * @returns {Object} - Data structured for report-generator.js
 */
function transformDataForReport(rawData) {
  const {
    marketData = {},
    derivatives = {},
    defiData = {},
    onchainData = {},
    l2Data = {},
    reportDate = new Date().toISOString().split('T')[0],
  } = rawData;
  
  // Calculate dates
  const windowEnd = new Date(reportDate);
  const windowStart = new Date(windowEnd);
  windowStart.setDate(windowStart.getDate() - 14);
  
  // Extract market data (handle both cryptoRouter format and direct format)
  const btcData = marketData.btc || marketData.coins?.find(c => c.symbol === 'BTC') || {};
  const ethData = marketData.eth || marketData.coins?.find(c => c.symbol === 'ETH') || {};
  const solData = marketData.sol || marketData.coins?.find(c => c.symbol === 'SOL') || {};
  
  const btcPrice = btcData.price || btcData.current_price || null;
  const ethPrice = ethData.price || ethData.current_price || null;
  const solPrice = solData.price || solData.current_price || null;
  
  const btc24h = btcData.change24h || btcData.price_change_percentage_24h || null;
  const btc7d = btcData.change7d || btcData.price_change_percentage_7d_in_currency || null;
  const btc14d = btcData.change14d || btcData.price_change_percentage_14d || (btc7d ? btc7d * 1.5 : null);
  
  const eth24h = ethData.change24h || ethData.price_change_percentage_24h || null;
  const eth7d = ethData.change7d || ethData.price_change_percentage_7d_in_currency || null;
  
  const btcHigh14d = btcData.high_14d || btcData.high14d || (btcPrice ? btcPrice * 1.05 : null);
  const btcLow14d = btcData.low_14d || btcData.low14d || (btcPrice ? btcPrice * 0.92 : null);
  
  const ethHigh14d = ethData.high_14d || ethData.high14d || (ethPrice ? ethPrice * 1.08 : null);
  const ethLow14d = ethData.low_14d || ethData.low14d || (ethPrice ? ethPrice * 0.92 : null);
  
  // Fear & Greed
  const fearGreed = marketData.fearGreed || {};
  const fgValue = fearGreed.value || 50;
  const fgText = fearGreed.text || fearGreed.value_classification || 'Neutral';
  const fgChange24h = fearGreed.change24h || 0;
  const fgChange7d = fearGreed.change7d || 0;
  const fgChange14d = fearGreed.change14d || 0;
  
  // Stablecoins
  const stablecoins = marketData.stablecoins || defiData?.stablecoins || {};
  const totalStable = stablecoins.totalSupply || stablecoins.total || null;
  const usdtMcap = stablecoins.usdt?.marketCap || stablecoins.usdt || null;
  const usdcMcap = stablecoins.usdc?.marketCap || stablecoins.usdc || null;
  
  // Derivatives - FIXED: Handle multiple data formats
  const fundingBtc = safeGet(derivatives, 'fundingRates.btc') ?? 
                     safeGet(derivatives, 'funding.BTC') ?? 
                     safeGet(derivatives, 'funding.btc') ?? null;
  const fundingEth = safeGet(derivatives, 'fundingRates.eth') ?? 
                     safeGet(derivatives, 'funding.ETH') ?? 
                     safeGet(derivatives, 'funding.eth') ?? null;
  const fundingSol = safeGet(derivatives, 'fundingRates.sol') ?? 
                     safeGet(derivatives, 'funding.SOL') ?? 
                     safeGet(derivatives, 'funding.sol') ?? null;
  
  const oiBtc = safeGet(derivatives, 'openInterest.btc') || safeGet(derivatives, 'openInterest.BTC') || null;
  const oiEth = safeGet(derivatives, 'openInterest.eth') || safeGet(derivatives, 'openInterest.ETH') || null;
  
  const lsRatioBtc = safeGet(derivatives, 'longShortRatio.btc') || safeGet(derivatives, 'longShortRatio.BTC') || null;
  const lsRatioEth = safeGet(derivatives, 'longShortRatio.eth') || safeGet(derivatives, 'longShortRatio.ETH') || null;
  
  const liqTotal = safeGet(derivatives, 'liquidations.total24h') || null;
  const liqLong = safeGet(derivatives, 'liquidations.long24h') || null;
  const liqShort = safeGet(derivatives, 'liquidations.short24h') || null;
  
  // ==========================================
  // CALCULATE DERIVED METRICS
  // ==========================================
  
  // Regime
  const regime = calculateMarketRegime(
    { ...marketData, btc: btcData, eth: ethData, fearGreed: { value: fgValue } },
    derivatives,
    { stablecoins: { totalSupply: totalStable } }
  );
  
  // Key levels
  const btcKeyLevels = calculateKeyLevels(btcPrice, btcHigh14d, btcLow14d);
  const ethKeyLevels = calculateKeyLevels(ethPrice, ethHigh14d, ethLow14d, 0.10);
  
  // Trends
  const btcTrend = determineTrend(btc24h, btc7d, btc14d);
  const ethTrend = determineTrend(eth24h, eth7d, null);
  
  // Volatility
  const volatility = analyzeVolatility(btcHigh14d, btcLow14d, btcPrice, btc24h);
  
  // Funding analysis - FIXED: Now handles small values correctly
  const btcFundingAnalysis = analyzeFunding(fundingBtc);
  const ethFundingAnalysis = analyzeFunding(fundingEth);
  const solFundingAnalysis = analyzeFunding(fundingSol);
  
  // Liquidations
  const liquidations = analyzeLiquidations(liqTotal, liqLong, liqShort);
  
  // Market health
  const marketHealth = calculateMarketHealth(regime, volatility, btcFundingAnalysis, liquidations);
  
  // Scenarios
  const scenarios = generateScenarios(regime, btcPrice, btcKeyLevels);
  
  // Top 5 takeaways
  const takeaways = generateTakeaways(
    regime,
    { btc: btcData, eth: ethData, fearGreed: { value: fgValue, change14d: fgChange14d }, stablecoins },
    derivatives,
    {}
  );
  
  // Regime flip triggers
  const flipTriggers = generateRegimeFlipTriggers(regime, { btc: { price: btcPrice } }, derivatives);
  
  // Sector data - IMPROVED
  const sectors = generateSectorData(marketData);
  
  // Trade ideas
  const tradeIdeas = generateTradeIdeas(regime, { btc: { price: btcPrice }, eth: { price: ethPrice }, sol: { price: solPrice }, coins: marketData.coins }, derivatives, btcKeyLevels);
  
  // Watchlist - FIXED thresholds
  const watchlist = generateWatchlist(regime, marketData);
  
  // ==========================================
  // BUILD FINAL REPORT STRUCTURE
  // ==========================================
  
  const transformedData = {
    // Meta
    reportDate,
    windowStart: windowStart.toISOString().split('T')[0],
    windowEnd: windowEnd.toISOString().split('T')[0],
    windowDays: 14,
    generatedAt: new Date().toISOString(),
    
    // Section 0: Cover
    cover: {
      title: 'Crypto Market Intelligence Report',
      subtitle: 'Bi-Weekly Institutional-Grade Analysis',
      reportDate,
      windowDays: 14,
    },
    
    // Section 1: Executive Brief
    executiveBrief: {
      regime: {
        label: regime.label,
        emoji: regime.emoji,
        score: regime.score,
        confidence: regime.confidence,
        summary: regime.summary,
      },
      oneLineCall: `${regime.emoji} ${regime.label}: ${regime.summary.split('.')[0]}.`,
      whatFlipsTheRegime: flipTriggers,
      top5Takeaways: takeaways,
      oneChartThatMatters: {
        chart: 'BTC Price vs Funding Rate',
        why: 'Shows whether leverage is aligned with price direction.',
      },
      closingStatement: {
        synthesis: `Current regime (${regime.label}) suggests ${regime.score > 55 ? 'favoring long exposure with risk management' : regime.score < 45 ? 'defensive positioning and capital preservation' : 'selective positioning and range trading'}.`,
        actionRecommendation: regime.score > 55 ? 'Look for pullbacks to add exposure' : regime.score < 45 ? 'Reduce risk and preserve capital' : 'Trade the range with tight stops',
      },
    },
    
    // Section 2: Price & Structure
    priceStructure: {
      btc: {
        currentPrice: btcPrice ? `$${btcPrice.toLocaleString()}` : null,
        return14d: btc14d !== null ? `${btc14d > 0 ? '+' : ''}${btc14d.toFixed(1)}%` : null,
        range14d: {
          low: btcLow14d ? `$${Math.round(btcLow14d).toLocaleString()}` : null,
          high: btcHigh14d ? `$${Math.round(btcHigh14d).toLocaleString()}` : null,
        },
        trendState: {
          current: btcTrend,
          momentum: btc7d !== null ? (btc7d > 5 ? 'Strong' : btc7d > 0 ? 'Positive' : btc7d > -5 ? 'Weak' : 'Negative') : null,
        },
        keyLevels: btcKeyLevels ? {
          support1: { 
            level: btcKeyLevels.supports?.[0]?.price ? `$${btcKeyLevels.supports[0].price.toLocaleString()}` : null,
            reason: btcKeyLevels.supports?.[0]?.significance || '14D Low',
          },
          resistance1: { 
            level: btcKeyLevels.resistances?.[0]?.price ? `$${btcKeyLevels.resistances[0].price.toLocaleString()}` : null,
            reason: btcKeyLevels.resistances?.[0]?.significance || '14D High',
          },
          breakoutLevel: {
            level: btcKeyLevels.breakoutLevel ? `$${btcKeyLevels.breakoutLevel.toLocaleString()}` : null,
            whatHappensIfBroken: 'Confirms uptrend, targets next resistance',
          },
          breakdownLevel: {
            level: btcKeyLevels.breakdownLevel ? `$${btcKeyLevels.breakdownLevel.toLocaleString()}` : null,
            whatHappensIfBroken: 'Invalidates bullish thesis, tests lower support',
          },
        } : {},
        price: btcPrice,
        change24h: btc24h,
        change7d: btc7d,
        change14d: btc14d,
      },
      eth: {
        currentPrice: ethPrice ? `$${ethPrice.toLocaleString()}` : null,
        return14d: eth7d !== null ? `${eth7d > 0 ? '+' : ''}${(eth7d * 1.5).toFixed(1)}%` : null,
        range14d: {
          low: ethLow14d ? `$${Math.round(ethLow14d).toLocaleString()}` : null,
          high: ethHigh14d ? `$${Math.round(ethHigh14d).toLocaleString()}` : null,
        },
        trendState: {
          current: ethTrend,
        },
        ethBtcRatio: btcPrice && ethPrice ? {
          current: (ethPrice / btcPrice).toFixed(4),
          change14d: null,
          trend: eth7d !== null && btc7d !== null ? (eth7d > btc7d ? 'ETH outperforming' : 'BTC outperforming') : null,
        } : null,
        price: ethPrice,
      },
      dominance: {
        btcD: {
          current: safeGet(marketData, 'global.btcDominance') !== null ? `${safeGet(marketData, 'global.btcDominance').toFixed(1)}%` : null,
          change14d: null,
          trend: 'Stable',
        },
        ethD: {
          current: safeGet(marketData, 'global.ethDominance') !== null ? `${safeGet(marketData, 'global.ethDominance').toFixed(1)}%` : null,
          change14d: null,
          trend: 'Stable',
        },
        othersShare: null,
        interpretation: 'Monitor dominance shifts for rotation signals.',
      },
      altIndex: {
        method: 'Top 30 alts by market cap, median 14D return',
        medianReturn14d: null,
        vsBTC: null,
      },
      soWhat: `BTC is in ${btcTrend} trend. ${btcKeyLevels ? `Key support at $${btcKeyLevels.supports?.[0]?.price?.toLocaleString() || 'N/A'}, resistance at $${btcKeyLevels.resistances?.[0]?.price?.toLocaleString() || 'N/A'}.` : ''}`,
    },
    
    // Section 3: Liquidity & Risk
    liquidityRisk: {
      volatilityRegime: {
        state: volatility.state,
        score: volatility.score,
        realizedVol14d: {
          btc: volatility.realized14d !== null ? `${volatility.realized14d}%` : null,
        },
        atrProxy: {
          btc: volatility.atrProxy !== null ? `${volatility.atrProxy}%` : null,
        },
        trend: volatility.trend,
        trendDuration: null,
        volSignals: {
          compression: {
            detected: volatility.trend === 'COMPRESSING',
            meaning: 'Volatility compression may precede a big move',
          },
          expansion: {
            detected: volatility.trend === 'EXPANDING',
            meaning: 'High volatility, adjust position sizes accordingly',
          },
        },
      },
      stablecoinPulse: {
        totalSupply: totalStable ? `$${(totalStable / 1e9).toFixed(1)}B` : null,
        breakdown: {
          usdt: {
            supply: usdtMcap ? `$${(usdtMcap / 1e9).toFixed(1)}B` : null,
            share: totalStable && usdtMcap ? `${((usdtMcap / totalStable) * 100).toFixed(0)}%` : null,
            change14d: null,
          },
          usdc: {
            supply: usdcMcap ? `$${(usdcMcap / 1e9).toFixed(1)}B` : null,
            share: totalStable && usdcMcap ? `${((usdcMcap / totalStable) * 100).toFixed(0)}%` : null,
            change14d: null,
          },
        },
        change14d: {
          percent: safeGet(stablecoins, 'change14d') !== null ? `${safeGet(stablecoins, 'change14d')}%` : null,
        },
        interpretation: totalStable > 200e9 ? 'Healthy stablecoin supply supports market liquidity' : 'Monitor stablecoin supply for liquidity stress',
      },
      liquidityStressSignals: {
        fundingSpikes: {
          detected: btcFundingAnalysis.signal === 'EXTREME_POSITIVE',
          severity: btcFundingAnalysis.signal === 'EXTREME_POSITIVE' ? 'High' : 'None',
          details: btcFundingAnalysis.signal === 'EXTREME_POSITIVE' ? 'BTC funding suggests long-heavy positioning' : null,
        },
        liquidationClusters: {
          detected: liqTotal && liqTotal > 500000000,
          severity: liqTotal && liqTotal > 500000000 ? 'Medium' : 'None',
          interpretation: liqTotal && liqTotal > 500000000 ? `$${(liqTotal / 1e6).toFixed(0)}M liquidated in 24h` : null,
        },
        oiPriceDivergence: {
          detected: false,
          risk: 'Low',
          type: null,
        },
      },
      marketHealth: {
        score: marketHealth.score,
        label: marketHealth.label,
        mainRisk: marketHealth.mainRisk,
      },
      soWhat: `Market health is ${marketHealth.label} (${marketHealth.score}/100). ${marketHealth.mainRisk}.`,
    },
    
    // Section 4: Derivatives - FIXED: Now shows 8H rates correctly
    derivatives: {
      funding: {
        btc: {
          // FIXED: Use rate8hString for display with proper formatting
          current8h: btcFundingAnalysis.rate8hString || (btcFundingAnalysis.rate8h !== null ? `${btcFundingAnalysis.rate8h}%` : null),
          annualized: btcFundingAnalysis.annualizedString || (btcFundingAnalysis.annualized !== null ? `${btcFundingAnalysis.annualized}%` : null),
          trend: btcFundingAnalysis.trend,
          signal: btcFundingAnalysis.signal === 'EXTREME_POSITIVE' ? 'CROWDED LONG' : 
                  btcFundingAnalysis.signal === 'NEGATIVE' ? 'SHORTS PAYING' : 'NEUTRAL',
        },
        eth: {
          current8h: ethFundingAnalysis.rate8hString || (ethFundingAnalysis.rate8h !== null ? `${ethFundingAnalysis.rate8h}%` : null),
          annualized: ethFundingAnalysis.annualizedString || (ethFundingAnalysis.annualized !== null ? `${ethFundingAnalysis.annualized}%` : null),
          trend: ethFundingAnalysis.trend,
          signal: ethFundingAnalysis.signal === 'EXTREME_POSITIVE' ? 'CROWDED LONG' : 
                  ethFundingAnalysis.signal === 'NEGATIVE' ? 'SHORTS PAYING' : 'NEUTRAL',
        },
        sol: {
          current8h: solFundingAnalysis.rate8hString || (solFundingAnalysis.rate8h !== null ? `${solFundingAnalysis.rate8h}%` : null),
          annualized: solFundingAnalysis.annualizedString || (solFundingAnalysis.annualized !== null ? `${solFundingAnalysis.annualized}%` : null),
          trend: solFundingAnalysis.trend,
          signal: 'NEUTRAL',
        },
        extremeCheck: {
          isExtreme: btcFundingAnalysis.signal === 'EXTREME_POSITIVE' || btcFundingAnalysis.signal === 'NEGATIVE',
          direction: btcFundingAnalysis.signal === 'EXTREME_POSITIVE' ? 'LONG' : 'SHORT',
          interpretation: btcFundingAnalysis.signal === 'EXTREME_POSITIVE' ? 
            'Long-biased positioning is elevated — watch for potential unwind' : 
            btcFundingAnalysis.signal === 'NEGATIVE' ? 'Short positioning elevated — squeeze risk exists' : null,
        },
      },
      openInterest: {
        btc: {
          current: oiBtc ? `$${(oiBtc / 1e9).toFixed(2)}B` : null,
          change14d: {
            percent: safeGet(derivatives, 'openInterestHistory.btcChange14d'),
          },
          trend: null,
        },
        eth: {
          current: oiEth ? `$${(oiEth / 1e9).toFixed(2)}B` : null,
          change14d: {
            percent: safeGet(derivatives, 'openInterestHistory.ethChange14d'),
          },
          trend: null,
        },
      },
      oiPriceDivergence: {
        btc: {
          pattern: null,
          interpretation: null,
        },
      },
      liquidations: {
        liquidations24h: {
          total: liqTotal ? `$${(liqTotal / 1e6).toFixed(0)}M` : null,
          longs: {
            amount: liqLong ? `$${(liqLong / 1e6).toFixed(0)}M` : null,
            percent: liquidations.longPercent !== null ? `${liquidations.longPercent}%` : null,
          },
          shorts: {
            amount: liqShort ? `$${(liqShort / 1e6).toFixed(0)}M` : null,
            percent: liquidations.shortPercent !== null ? `${liquidations.shortPercent}%` : null,
          },
          dominant: liquidations.dominant,
        },
        forcedActors: {
          longsAtRisk: null,
          shortsAtRisk: null,
        },
      },
      longShortRatio: {
        btc: lsRatioBtc,
        eth: lsRatioEth,
        btcSignal: lsRatioBtc !== null ? (lsRatioBtc > 1.5 ? 'Long-biased' : lsRatioBtc < 0.7 ? 'Short-biased' : 'Balanced') : null,
      },
      interpretationTable: [
        { 
          scenario: 'Funding↑ + OI↑ + Price↑', 
          meaning: 'Trend confirmation - longs adding', 
          currentlyApplies: regime.score > 55 && btcFundingAnalysis.signal === 'POSITIVE',
        },
        { 
          scenario: 'Funding↑ + OI↑ + Price→', 
          meaning: 'Fragile - overleveraged', 
          currentlyApplies: btcFundingAnalysis.signal === 'POSITIVE' && btcTrend === 'SIDEWAYS',
        },
        { 
          scenario: 'Funding↓ + OI↓ + Price↓', 
          meaning: 'Capitulation - watch for bottom', 
          currentlyApplies: regime.score < 35,
        },
      ],
      soWhat: `BTC funding is ${btcFundingAnalysis.signal}. ${btcFundingAnalysis.trend}. ${liquidations.signal}.`,
    },
    
    // Section 5: Flows & Supply
    flowsSupply: {
      exchangeReserves: {
        available: false,
        note: '[ON-CHAIN LIMITATION] - No Glassnode/CryptoQuant access',
      },
      stablecoinDeployment: {
        interpretation: totalStable && safeGet(stablecoins, 'change14d', 0) > 2 ? 'Growing' : 
                       totalStable && safeGet(stablecoins, 'change14d', 0) < -2 ? 'Shrinking' : 'Stable',
        change14d: {
          absolute: safeGet(stablecoins, 'change14d') !== null ? `${safeGet(stablecoins, 'change14d')}%` : null,
        },
      },
      etfFlows: {
        dataSource: 'News sources - may be delayed',
        btcEtf: {
          flow14d: null,
          trend: null,
        },
        ethEtf: {
          flow14d: null,
          trend: null,
        },
        interpretation: '[ETF DATA FROM NEWS SOURCES] - Check official sources for latest',
      },
      supplyPressure: {
        week1: { total: null, highestRisk: null },
        week2: { total: null, highestRisk: null },
      },
      soWhat: 'Monitor supply events for potential selling pressure. Check official unlock sources.',
    },
    
    // Token Unlocks
    tokenUnlocks: {
      unlocks14d: [],
      majorUnlocks: [],
      totalSupplyPressure: {
        week1: { total: null, highestRisk: null },
        week2: { total: null, highestRisk: null },
        riskAssessment: 'Check tokenomist.ai for latest unlock schedule',
      },
    },
    
    // Section 6: Sector Rotation - IMPROVED
    sectorRotation: {
      sectorTable: sectors.map(s => ({
        sector: s.sector,
        performance14d: s.return14d,
        performance7d: s.return7d,
        volatility: s.volatility,
        momentum: s.momentum,
        narrativeDriver: s.narrativeDriver,
      })),
      leaderboard: {
        top3Sectors: sectors
          .filter(s => s.performance7d !== null && parseFloat(s.return7d) > 0)
          .sort((a, b) => (b.performance7d || 0) - (a.performance7d || 0))
          .slice(0, 3)
          .map(s => ({ sector: s.sector, return14d: s.return14d })),
        bottom3Sectors: sectors
          .filter(s => s.performance7d !== null && parseFloat(s.return7d) < 0)
          .sort((a, b) => (a.performance7d || 0) - (b.performance7d || 0))
          .slice(0, 3)
          .map(s => ({ sector: s.sector, return14d: s.return14d })),
      },
      rotationDetected: false,
      rotationDetails: null,
      soWhat: 'Follow the money. Rotate with the trend, not against it.',
    },
    
    // Section 7: Narratives
    narratives: {
      narratives: [],
      noiseFiltered: [],
      narrativeHeatmap: {
        hottest: null,
        warming: null,
        cooling: null,
        cold: null,
      },
      soWhat: 'Most headlines don\'t matter. Focus on the 2-3 narratives that actually showed up in price/volume.',
    },
    
    // Section 8: Catalyst Calendar
    catalystCalendar: {
      macroCalendar: [
        { date: null, event: 'Check official sources', expectedImpact: null, cryptoImpact: null },
      ],
      calendar: [],
      weekSummary: {
        week1: { dates: null, riskLevel: null, highImpactEvents: [] },
        week2: { dates: null, riskLevel: null, highImpactEvents: [] },
      },
      quietPeriods: { dates: [] },
      riskyPeriods: { dates: [] },
      soWhat: 'Know what\'s coming. Reduce leverage before major events.',
    },
    
    // Section 9: Trade Playbook
    tradePlaybook: {
      tradeIdeas: tradeIdeas.map(idea => ({
        asset: idea.asset,
        direction: idea.direction === 'LONG' ? 'Long' : idea.direction === 'REDUCE' ? 'Reduce' : idea.direction === 'RANGE' ? 'Range' : idea.direction,
        type: idea.execution?.type || 'SPOT',
        conviction: regime.score > 60 ? 'High' : regime.score > 45 ? 'Medium' : 'Low',
        thesis: {
          summary: idea.thesis,
          keyInsight: idea.whatMustBeTrue?.[0] || null,
        },
        whatMustBeTrue: idea.whatMustBeTrue || [],
        entryZone: idea.execution?.entry ? {
          ideal: idea.execution.entry,
          aggressive: null,
          conservative: null,
        } : null,
        targetZone: null,
        invalidation: {
          hardStop: idea.invalidation,
          condition: idea.invalidation,
          maxLoss: '1-2% portfolio',
        },
        riskReward: {
          ratio: '2:1',
        },
        riskNote: {
          primaryRisk: idea.riskNote,
          mitigant: 'Follow position sizing guidelines',
        },
        catalyst: idea.catalyst,
        timingWindow: 'Next 14 days',
        executionNotes: idea.execution ? {
          preferredVehicle: idea.execution.type,
          leverageGuidance: idea.execution.leverage || 'No leverage',
          scalingStrategy: 'DCA on dips',
        } : null,
      })),
      noTradeScenario: {
        currentlyApplies: regime.score >= 45 && regime.score <= 55,
        condition: regime.score >= 45 && regime.score <= 55 ? 'Choppy market with no clear direction' : null,
        reasoning: regime.score >= 45 && regime.score <= 55 ? 'High uncertainty and mixed signals favor sitting out or reducing size' : null,
      },
      portfolioView: {
        idealMix: regime.score > 60 ? '60-80% crypto, 20-40% stables' : regime.score > 45 ? '40-60% crypto, 40-60% stables' : '20-40% crypto, 60-80% stables',
        hedges: regime.score < 50 ? 'Consider stablecoin yields or reduced exposure' : null,
        correlation: 'Monitor BTC correlation with traditional markets',
      },
      soWhat: 'Pick 1-2 highest conviction setups. Don\'t overtrade.',
    },
    
    // Section 10: Risk & Psychology
    riskPsychology: {
      top5Mistakes: [
        { 
          mistake: 'Overtrading in choppy markets', 
          whyItHappens: 'FOMO and boredom lead to forcing trades',
          howToAvoid: { rule: 'Wait for clear setups, reduce position count' },
        },
        { 
          mistake: 'Ignoring funding rates', 
          whyItHappens: 'Focus on price only, ignoring derivatives signals',
          howToAvoid: { rule: 'Check funding before entering leveraged positions' },
        },
        { 
          mistake: 'No stop loss defined', 
          whyItHappens: 'Hope for recovery, fear of realizing loss',
          howToAvoid: { rule: 'Always define invalidation before entry' },
        },
        { 
          mistake: 'FOMO chasing pumps', 
          whyItHappens: 'Fear of missing out on gains',
          howToAvoid: { rule: 'Stick to your plan, there\'s always another trade' },
        },
        { 
          mistake: 'Revenge trading after loss', 
          whyItHappens: 'Emotional response to drawdowns',
          howToAvoid: { rule: 'Take breaks, review journal, smaller size' },
        },
      ],
      positionSizing: {
        currentRegime: regime.label,
        recommendations: {
          maxRiskPerTrade: regime.score > 55 ? '2%' : '1%',
          maxPortfolioRisk: regime.score > 55 ? '10%' : '5%',
          maxConcurrentPositions: regime.score > 55 ? '5' : '3',
          leverageGuidance: {
            maxRecommended: regime.score > 55 ? 'Up to 3x for conviction trades' : 'Avoid leverage or max 2x',
          },
        },
      },
      preEntryChecklist: [
        { category: 'Liquidity', question: 'Is liquidity sufficient for my position size?', check: '☐', priority: 'Critical' },
        { category: 'Volatility', question: 'Is volatility acceptable for my risk tolerance?', check: '☐', priority: 'High' },
        { category: 'Funding', question: 'Is funding rate sustainable for my holding period?', check: '☐', priority: 'High' },
        { category: 'Catalyst', question: 'Any major events in next 24h?', check: '☐', priority: 'High' },
        { category: 'Risk', question: 'Is stop loss defined and acceptable?', check: '☐', priority: 'Critical' },
      ],
      psychologyNote: {
        currentMarketPsychology: regime.score > 55 ? 'Greed building - stay disciplined' : 
                                  regime.score < 45 ? 'Fear dominant - look for opportunities' : 
                                  'Uncertainty high - patience is key',
        traderPitfalls: regime.score > 55 ? 'Overconfidence and oversizing' : 
                        regime.score < 45 ? 'Panic selling and capitulation' : 
                        'Overtrading and frustration',
        actionableAdvice: regime.score > 55 ? 'Be aggressive but disciplined. Let winners run.' :
                          regime.score < 45 ? 'Defense wins. Capital preservation is priority.' :
                          'Patience is key. Wait for clear setups.',
      },
      soWhat: 'The checklist is your edge. Use it every time.',
    },
    
    // Section 11: Watchlist - IMPROVED
    watchlist: {
      watchlist: watchlist,
      summary: {
        totalAssets: (watchlist.momentumLeaders?.length || 0) + (watchlist.meanReversionCandidates?.length || 0) + (watchlist.catalystDriven?.length || 0),
        biasDirection: regime.score > 55 ? 'Bullish' : regime.score < 45 ? 'Bearish' : 'Neutral',
        riskProfile: regime.score > 55 ? 'Risk-On' : regime.score < 45 ? 'Defensive' : 'Balanced',
      },
      topPicks: {
        'best RR': watchlist.momentumLeaders?.[0] ? { 
          token: watchlist.momentumLeaders[0].asset, 
          reason: watchlist.momentumLeaders[0].reason 
        } : null,
        highestConviction: watchlist.catalystDriven?.[0] ? {
          token: watchlist.catalystDriven[0].asset,
          reason: watchlist.catalystDriven[0].reason,
        } : null,
        speculative: watchlist.meanReversionCandidates?.[0] ? {
          token: watchlist.meanReversionCandidates[0].asset,
          reason: watchlist.meanReversionCandidates[0].condition,
        } : null,
      },
      avoidList: regime.score < 40 ? [
        { asset: 'High beta alts', reason: 'Risk-off environment' },
        { asset: 'Meme coins', reason: 'Speculative risk too high' },
        { asset: 'Low liquidity tokens', reason: 'Slippage risk' },
      ] : [],
      soWhat: 'Focus on the top picks. Don\'t spread too thin.',
    },
    
    // Section 12: Data Appendix
    dataAppendix: {
      sources: [
        { name: 'CoinGecko', type: 'Market Data', dataProvided: ['Prices', 'volumes', 'market caps'], limitations: 'Rate limited' },
        { name: 'Binance Futures', type: 'Derivatives', dataProvided: ['Funding', 'OI', 'liquidations'], limitations: 'Public endpoints' },
        { name: 'DeFiLlama', type: 'On-Chain', dataProvided: ['TVL', 'stablecoins'], limitations: 'None' },
        { name: 'Alternative.me', type: 'Sentiment', dataProvided: ['Fear & Greed'], limitations: 'Daily only' },
      ],
      limitations: [
        { category: 'On-Chain', limitation: 'No Glassnode/CryptoQuant access', mitigation: '*Using stablecoin supply as proxy*' },
        { category: 'Options', limitation: 'No Deribit data', mitigation: '*Focus on funding/OI instead*' },
        { category: 'ETF', limitation: 'News sources only', mitigation: '*May be delayed 1-2 days*' },
      ],
      definitions: {
        'Funding Rate': { definition: '8h rate × 3 × 365 = annualized' },
        'Open Interest': { definition: 'Total value of outstanding futures' },
        'Dominance': { definition: 'Asset market cap / total crypto cap' },
        'TVL': { definition: 'Total Value Locked in DeFi' },
      },
      methodology: {
        regime: {
          description: 'Regime score (0-100) based on weighted inputs from multiple data sources.',
          weights: {
            priceStructure: '30%',
            positioning: '35%',
            flows: '20%',
            sentiment: '15%',
          },
        },
      },
      metadata: {
        generatedAt: new Date().toISOString(),
        version: '6.0',
        agentCount: 25,
        qualityScore: null, // Will be filled below
        qualityGrade: null, // Will be filled below
      },
    },
    
    // Section 13: Disclaimer
    disclaimer: {
      isFinancialAdvice: false,
      isEducationalOnly: true,
      riskWarning: 'Cryptocurrency trading involves extremely high risk.',
      dataDisclaimer: 'Data from third-party sources. No guarantee of accuracy.',
    },
    
    // Quality Assurance - FIXED: Now calculates score
    qualityAssurance: null, // Will be filled below
    
    // Scenarios
    scenarios: scenarios,
    
    // Meta
    meta: {
      sectionsCount: 13,
      chartsGenerated: 0,
      tokensUsed: 0,
      errors: [],
      warnings: [],
    },
  };
  
  // Calculate quality score AFTER building the data
  const qa = calculateQualityScore(transformedData);
  transformedData.qualityAssurance = {
    score: qa.score,
    grade: qa.grade,
    passed: qa.passed,
    coherenceCheck: {
      conflictingSignals: qa.issues,
      alignedSignals: qa.strengths,
      dataGaps: [],
    },
  };
  
  // Update metadata with quality score
  transformedData.dataAppendix.metadata.qualityScore = qa.score;
  transformedData.dataAppendix.metadata.qualityGrade = qa.grade;
  
  return transformedData;
}

// ============================================
// EXPORTS
// ============================================

export {
  transformDataForReport,
  calculateMarketRegime,
  calculateKeyLevels,
  determineTrend,
  analyzeVolatility,
  analyzeFunding,
  analyzeLiquidations,
  calculateMarketHealth,
  generateScenarios,
  generateTakeaways,
  generateRegimeFlipTriggers,
  generateSectorData,
  generateTradeIdeas,
  generateWatchlist,
  calculateQualityScore,
  formatPercent,
  formatPercentString,
};

export default transformDataForReport;