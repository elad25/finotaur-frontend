// =====================================================
// CRYPTO SCHEDULER INITIALIZATION - FIXED v2.1
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/init-scheduler.js
//
// FIX v2.1: Added re-export of getCryptoScheduler
// This was causing: "getCryptoScheduler is not a function"
// =====================================================

import { createClient } from '@supabase/supabase-js';
import { 
  initCryptoScheduler, 
  getCryptoScheduler,
  CryptoReportScheduler,
  SCHEDULE_CONFIG,
} from './scheduler.js';

// ============================================
// CONFIGURATION
// ============================================

const config = {
  supabaseUrl: process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL,
  supabaseServiceKey: process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY,
  apiBaseUrl: process.env.API_BASE_URL || 'http://localhost:3000',
  openaiApiKey: process.env.OPENAI_API_KEY,
  coingeckoApiKey: process.env.COINGECKO_API_KEY,
};

// ============================================
// INITIALIZATION FUNCTION
// ============================================

/**
 * Initialize and start the crypto report scheduler
 * Call this from your server startup
 */
export async function startCryptoScheduler() {
  console.log('[CryptoInit] 🚀 Initializing Crypto Report Scheduler...');
  
  // Validate configuration
  if (!config.supabaseUrl || !config.supabaseServiceKey) {
    console.error('[CryptoInit] ❌ Missing Supabase configuration');
    console.error('[CryptoInit] Required: SUPABASE_URL and SUPABASE_SERVICE_KEY (or SUPABASE_SERVICE_ROLE_KEY)');
    return null;
  }
  
  try {
    // Create Supabase client with service key (for admin operations)
    const supabase = createClient(config.supabaseUrl, config.supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });
    
    // Test connection
    const { data, error } = await supabase
      .from('system_updates')
      .select('id')
      .limit(1);
    
    if (error && error.code !== 'PGRST116') {
      console.error('[CryptoInit] ❌ Supabase connection test failed:', error.message);
      console.error('[CryptoInit] Make sure the migration has been run');
      return null;
    }
    
    console.log('[CryptoInit] ✅ Supabase connection successful');
    
    // Initialize scheduler
    const scheduler = initCryptoScheduler(supabase, {
      apiBaseUrl: config.apiBaseUrl,
      openaiApiKey: config.openaiApiKey,
      coingeckoApiKey: config.coingeckoApiKey,
    });
    
    // Start the scheduler
    scheduler.start();
    
    // Log status
    const status = scheduler.getStatus();
    console.log('[CryptoInit] ✅ Crypto Scheduler initialized');
    console.log(`[CryptoInit] 📅 Schedule: ${status.scheduleDescription}`);
    console.log(`[CryptoInit] 📆 Next run: ${status.nextRun}`);
    console.log(`[CryptoInit] 🎯 Target: ${status.targetGroup} subscribers`);
    
    return scheduler;
    
  } catch (error) {
    console.error('[CryptoInit] ❌ Failed to initialize scheduler:', error);
    return null;
  }
}

/**
 * Stop the scheduler (for graceful shutdown)
 */
export function stopCryptoScheduler() {
  const scheduler = getCryptoScheduler();
  if (scheduler) {
    scheduler.stop();
    console.log('[CryptoInit] 🛑 Crypto Scheduler stopped');
  }
}

/**
 * Get scheduler status
 */
export function getSchedulerStatus() {
  const scheduler = getCryptoScheduler();
  return scheduler ? scheduler.getStatus() : null;
}

/**
 * Manually trigger report generation
 */
export async function triggerManualGeneration() {
  const scheduler = getCryptoScheduler();
  if (!scheduler) {
    return { success: false, error: 'Scheduler not initialized' };
  }
  return scheduler.triggerManual();
}

// ============================================
// EXPRESS ROUTES FOR SCHEDULER MANAGEMENT
// ============================================

/**
 * Add these routes to your Express app for scheduler management
 * 
 * Usage:
 *   import { addSchedulerRoutes } from './init-scheduler.js';
 *   addSchedulerRoutes(app);
 */
export function addSchedulerRoutes(app, requireAdmin = null) {
  // Middleware that does nothing if requireAdmin is null
  const authMiddleware = requireAdmin || ((req, res, next) => next());
  
  // Get scheduler status
  app.get('/api/crypto/scheduler/status', authMiddleware, (req, res) => {
    const status = getSchedulerStatus();
    if (!status) {
      return res.status(503).json({
        success: false,
        error: 'Scheduler not initialized',
      });
    }
    res.json({
      success: true,
      data: status,
    });
  });
  
  // Manually trigger generation
  app.post('/api/crypto/scheduler/trigger', authMiddleware, async (req, res) => {
    try {
      const result = await triggerManualGeneration();
      res.json({
        success: true,
        message: 'Manual generation triggered',
        data: result,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });
  
  // Start scheduler
  app.post('/api/crypto/scheduler/start', authMiddleware, (req, res) => {
    const scheduler = getCryptoScheduler();
    if (!scheduler) {
      return res.status(503).json({
        success: false,
        error: 'Scheduler not initialized',
      });
    }
    scheduler.start();
    res.json({
      success: true,
      message: 'Scheduler started',
      data: scheduler.getStatus(),
    });
  });
  
  // Stop scheduler
  app.post('/api/crypto/scheduler/stop', authMiddleware, (req, res) => {
    const scheduler = getCryptoScheduler();
    if (!scheduler) {
      return res.status(503).json({
        success: false,
        error: 'Scheduler not initialized',
      });
    }
    scheduler.stop();
    res.json({
      success: true,
      message: 'Scheduler stopped',
    });
  });
  
  console.log('[CryptoInit] 📡 Scheduler management routes added');
}

// ============================================
// RE-EXPORTS FROM scheduler.js
// ============================================
// ✅ FIX: These were missing and caused the error!

export { 
  getCryptoScheduler,
  initCryptoScheduler,
  CryptoReportScheduler,
  SCHEDULE_CONFIG,
};

// ============================================
// DEFAULT EXPORT
// ============================================

export default {
  // Initialization functions
  startCryptoScheduler,
  stopCryptoScheduler,
  getSchedulerStatus,
  triggerManualGeneration,
  addSchedulerRoutes,
  
  // Re-exported from scheduler.js
  getCryptoScheduler,
  initCryptoScheduler,
  CryptoReportScheduler,
  SCHEDULE_CONFIG,
};