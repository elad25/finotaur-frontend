/**
 * Binance Announcements Scraper
 * Fetches new cryptocurrency listings from Binance
 * 
 * Usage:
 *   import { getBinanceAnnouncements, getNewListings } from './binance-announcements.js';
 *   const listings = await getNewListings();
 */

import fetch from 'node-fetch';

// Binance CMS API endpoints (undocumented but functional)
const BINANCE_CMS_API = 'https://www.binance.com/bapi/composite/v1/public/cms/article/list/query';

// Catalog IDs for different announcement types
const CATALOG_IDS = {
  NEW_LISTINGS: 48,           // New Cryptocurrency Listing
  LATEST_NEWS: 49,            // Latest Binance News
  LAUNCHPAD: 128,             // Binance Launchpad
  LAUNCHPOOL: 162,            // Binance Launchpool
  API_UPDATES: 51,            // API Updates
  DELISTING: 161,             // Delisting
};

/**
 * Fetch announcements from Binance CMS API
 * @param {Object} options - Query options
 * @param {number} options.catalogId - Category ID (48 for new listings)
 * @param {number} options.pageNo - Page number (starts at 1)
 * @param {number} options.pageSize - Results per page (max 20)
 * @returns {Promise<Object>} Announcements data
 */
async function fetchBinanceAnnouncements(options = {}) {
  const {
    catalogId = CATALOG_IDS.NEW_LISTINGS,
    pageNo = 1,
    pageSize = 20,
  } = options;

  const url = new URL(BINANCE_CMS_API);
  url.searchParams.append('type', '1');
  url.searchParams.append('catalogId', catalogId.toString());
  url.searchParams.append('pageNo', pageNo.toString());
  url.searchParams.append('pageSize', pageSize.toString());

  try {
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://www.binance.com/en/support/announcement',
        'Origin': 'https://www.binance.com',
      },
    });

    if (!response.ok) {
      // If bapi is blocked, try alternative method
      console.log('[Binance] CMS API returned', response.status, '- trying RSS fallback');
      return await fetchFromRSS();
    }

    const data = await response.json();
    
    if (data.code !== '000000' || !data.data) {
      console.log('[Binance] API returned error:', data.message || 'Unknown error');
      return await fetchFromRSS();
    }

    return {
      success: true,
      total: data.data.total || 0,
      articles: (data.data.catalogs || []).map(parseArticle),
    };
  } catch (error) {
    console.error('[Binance] Error fetching announcements:', error.message);
    return await fetchFromRSS();
  }
}

/**
 * Parse article from Binance API response
 */
function parseArticle(article) {
  const releaseDate = article.releaseDate ? new Date(article.releaseDate) : null;
  
  return {
    id: article.id,
    code: article.code,
    title: article.title,
    releaseDate: releaseDate?.toISOString() || null,
    releaseDateFormatted: releaseDate?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }) || null,
    url: `https://www.binance.com/en/support/announcement/${article.code}`,
  };
}

/**
 * Fallback: Fetch from Binance RSS feed
 */
async function fetchFromRSS() {
  try {
    // Try to fetch the announcement page and parse it
    const response = await fetch('https://www.binance.com/en/support/announcement/new-cryptocurrency-listing?c=48&navId=48', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const html = await response.text();
    
    // Extract announcement data from Next.js __NEXT_DATA__
    const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">([^<]+)<\/script>/);
    
    if (nextDataMatch) {
      const nextData = JSON.parse(nextDataMatch[1]);
      const articles = nextData?.props?.pageProps?.articles || [];
      
      return {
        success: true,
        total: articles.length,
        articles: articles.map(a => ({
          id: a.id,
          code: a.code,
          title: a.title,
          releaseDate: a.releaseDate ? new Date(a.releaseDate).toISOString() : null,
          releaseDateFormatted: a.releaseDate ? new Date(a.releaseDate).toLocaleDateString('en-US', {
            year: 'numeric', month: 'short', day: 'numeric'
          }) : null,
          url: `https://www.binance.com/en/support/announcement/${a.code}`,
        })),
        source: 'html_parse',
      };
    }

    return { success: false, error: 'Could not parse page', articles: [] };
  } catch (error) {
    console.error('[Binance] RSS fallback failed:', error.message);
    return { success: false, error: error.message, articles: [] };
  }
}

/**
 * Extract token symbol from announcement title
 * @param {string} title - Announcement title
 * @returns {Object} Extracted token info
 */
function extractTokenInfo(title) {
  // Pattern: "Binance Will List XXX (SYMBOL)"
  const listPattern = /(?:Will List|Lists?)\s+([^(]+)\s*\(([A-Z0-9]+)\)/i;
  const match = title.match(listPattern);
  
  if (match) {
    return {
      name: match[1].trim(),
      symbol: match[2].toUpperCase(),
      type: 'spot_listing',
    };
  }

  // Pattern for Launchpool: "Introducing XXX (SYMBOL) on Binance Launchpool"
  const launchpoolPattern = /Introducing\s+([^(]+)\s*\(([A-Z0-9]+)\)/i;
  const lpMatch = title.match(launchpoolPattern);
  
  if (lpMatch) {
    return {
      name: lpMatch[1].trim(),
      symbol: lpMatch[2].toUpperCase(),
      type: 'launchpool',
    };
  }

  // Pattern for futures: "Binance Futures Will Launch USDⓈ-M XXX"
  const futuresPattern = /Futures\s+(?:Will\s+)?Launch[s]?\s+(?:USDⓈ?-M\s+)?([A-Z0-9]+)/i;
  const futMatch = title.match(futuresPattern);
  
  if (futMatch) {
    return {
      symbol: futMatch[1].toUpperCase(),
      type: 'futures_listing',
    };
  }

  return null;
}

/**
 * Get new cryptocurrency listings
 * @param {Object} options - Options
 * @param {number} options.days - Get listings from last N days (default: 14)
 * @param {number} options.limit - Max results (default: 20)
 * @returns {Promise<Array>} Array of new listings
 */
export async function getNewListings(options = {}) {
  const { days = 14, limit = 20 } = options;
  
  const result = await fetchBinanceAnnouncements({
    catalogId: CATALOG_IDS.NEW_LISTINGS,
    pageSize: Math.min(limit, 20),
  });

  if (!result.success || !result.articles) {
    return [];
  }

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  return result.articles
    .filter(article => {
      // Filter by date
      if (article.releaseDate) {
        return new Date(article.releaseDate) >= cutoffDate;
      }
      return true;
    })
    .map(article => {
      const tokenInfo = extractTokenInfo(article.title);
      return {
        ...article,
        token: tokenInfo,
      };
    })
    .filter(article => article.token !== null); // Only return actual listings
}

/**
 * Get Launchpool announcements
 * @param {Object} options - Options
 * @returns {Promise<Array>} Array of launchpool projects
 */
export async function getLaunchpoolProjects(options = {}) {
  const { days = 30, limit = 10 } = options;
  
  const result = await fetchBinanceAnnouncements({
    catalogId: CATALOG_IDS.LAUNCHPOOL,
    pageSize: Math.min(limit, 20),
  });

  if (!result.success || !result.articles) {
    return [];
  }

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  return result.articles
    .filter(article => {
      if (article.releaseDate) {
        return new Date(article.releaseDate) >= cutoffDate;
      }
      return true;
    })
    .map(article => {
      const tokenInfo = extractTokenInfo(article.title);
      return {
        ...article,
        token: tokenInfo,
      };
    });
}

/**
 * Get all Binance announcements
 * @param {Object} options - Options
 * @returns {Promise<Object>} All announcements by category
 */
export async function getBinanceAnnouncements(options = {}) {
  const { days = 14 } = options;

  const [listings, launchpool] = await Promise.all([
    getNewListings({ days, limit: 20 }),
    getLaunchpoolProjects({ days: 30, limit: 10 }),
  ]);

  return {
    fetchedAt: new Date().toISOString(),
    listings: {
      count: listings.length,
      items: listings,
    },
    launchpool: {
      count: launchpool.length,
      items: launchpool,
    },
  };
}

/**
 * Format listings for crypto report
 * @param {Array} listings - Listings from getNewListings
 * @returns {Object} Formatted for report
 */
export function formatListingsForReport(listings) {
  if (!listings || listings.length === 0) {
    return {
      hasUpcoming: false,
      summary: 'No new listings announced in the past two weeks.',
      table: null,
    };
  }

  const spotListings = listings.filter(l => l.token?.type === 'spot_listing');
  const futuresListings = listings.filter(l => l.token?.type === 'futures_listing');
  const launchpoolListings = listings.filter(l => l.token?.type === 'launchpool');

  let summary = '';
  if (spotListings.length > 0) {
    const symbols = spotListings.map(l => l.token.symbol).join(', ');
    summary += `New spot listings: ${symbols}. `;
  }
  if (futuresListings.length > 0) {
    const symbols = futuresListings.map(l => l.token.symbol).join(', ');
    summary += `New futures: ${symbols}. `;
  }
  if (launchpoolListings.length > 0) {
    const symbols = launchpoolListings.map(l => l.token.symbol).join(', ');
    summary += `Launchpool: ${symbols}. `;
  }

  // Create table data
  const tableRows = listings.slice(0, 5).map(l => ({
    date: l.releaseDateFormatted || 'TBD',
    token: l.token?.symbol || 'Unknown',
    name: l.token?.name || '',
    type: l.token?.type === 'spot_listing' ? 'Spot' : 
          l.token?.type === 'futures_listing' ? 'Futures' : 
          l.token?.type === 'launchpool' ? 'Launchpool' : 'Other',
  }));

  return {
    hasUpcoming: true,
    summary: summary.trim(),
    count: listings.length,
    table: tableRows,
  };
}

// ============ EXPORT FOR DIRECT USE ============
export default {
  getNewListings,
  getLaunchpoolProjects,
  getBinanceAnnouncements,
  formatListingsForReport,
  CATALOG_IDS,
};

// ============ CLI TEST ============
if (process.argv[1]?.includes('binance-announcements')) {
  console.log('[Binance] Testing announcements fetch...\n');
  
  getNewListings({ days: 30 })
    .then(listings => {
      console.log('='.repeat(60));
      console.log('NEW BINANCE LISTINGS (Last 30 Days)');
      console.log('='.repeat(60));
      
      if (listings.length === 0) {
        console.log('No listings found (API may be blocked)');
      } else {
        listings.forEach(l => {
          console.log(`\n📌 ${l.token?.symbol || 'Unknown'} - ${l.token?.name || ''}`);
          console.log(`   Type: ${l.token?.type || 'unknown'}`);
          console.log(`   Date: ${l.releaseDateFormatted || 'N/A'}`);
          console.log(`   URL: ${l.url}`);
        });
      }
      
      console.log('\n' + '='.repeat(60));
      console.log('\nFormatted for report:');
      console.log(JSON.stringify(formatListingsForReport(listings), null, 2));
    })
    .catch(err => {
      console.error('Error:', err);
    });
}