// =====================================================
// CRYPTO ANALYSIS REPORT CONFIGURATION v5.0
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/config.js
//
// ENHANCED: Perfect Report Structure (13 Sections)
// Based on institutional-grade bi-weekly format
// Full Binance Futures API support
// All 14D delta calculations enabled
// =====================================================

/**
 * API Endpoints Configuration
 * Required by data-service.js
 */
const API_ENDPOINTS = {
  // CoinGecko API
  COINGECKO: 'https://api.coingecko.com/api/v3',
  
  // Binance APIs
  BINANCE_SPOT: 'https://api.binance.com/api/v3',
  BINANCE_FUTURES: 'https://fapi.binance.com/fapi/v1',
  
  // Binance Futures Data API (for long/short ratios)
  BINANCE_FUTURES_DATA: 'https://fapi.binance.com/futures/data',
  
  // Fear & Greed Index
  FEAR_GREED: 'https://api.alternative.me/fng',
  
  // DeFiLlama (for stablecoin/TVL data)
  DEFILLAMA: 'https://api.llama.fi',
  
  // DeFiLlama Stablecoins API
  DEFILLAMA_STABLECOINS: 'https://stablecoins.llama.fi',
  
  // QuickChart API for chart generation
  QUICKCHART: 'https://quickchart.io/chart',
  
  // Token Unlocks API (free tier)
  TOKEN_UNLOCKS: 'https://api.tokenomist.ai/v1',
};

/**
 * Binance Futures Endpoints (all public, no API key required)
 */
const BINANCE_FUTURES_ENDPOINTS = {
  // Current funding rate
  FUNDING_RATE: '/fundingRate',
  
  // Current open interest
  OPEN_INTEREST: '/openInterest',
  
  // Open interest history (5m, 15m, 30m, 1h, 2h, 4h, 6h, 12h, 1d)
  OPEN_INTEREST_HIST: '/openInterestHist',
  
  // Premium index (mark price, index price, funding rate)
  PREMIUM_INDEX: '/premiumIndex',
  
  // Continuous klines for historical data
  CONTINUOUS_KLINES: '/continuousKlines',
  
  // 24hr ticker
  TICKER_24HR: '/ticker/24hr',
  
  // Forced orders (liquidations)
  FORCE_ORDERS: '/forceOrders',
};

/**
 * Binance Futures Data Endpoints (for positioning data)
 * Base: https://fapi.binance.com/futures/data
 */
const BINANCE_DATA_ENDPOINTS = {
  // Global long/short account ratio
  GLOBAL_LONG_SHORT: '/globalLongShortAccountRatio',
  
  // Top trader long/short ratio (accounts)
  TOP_LONG_SHORT_ACCOUNTS: '/topLongShortAccountRatio',
  
  // Top trader long/short ratio (positions)
  TOP_LONG_SHORT_POSITIONS: '/topLongShortPositionRatio',
  
  // Taker buy/sell volume ratio
  TAKER_LONG_SHORT: '/takerlongshortRatio',
};

/**
 * Timeframes for historical data
 */
const TIMEFRAMES = {
  // For 14-day calculations
  LOOKBACK_DAYS: 14,
  LOOKBACK_MS: 14 * 24 * 60 * 60 * 1000,
  
  // Binance kline intervals
  KLINE_1M: '1m',
  KLINE_5M: '5m',
  KLINE_15M: '15m',
  KLINE_1H: '1h',
  KLINE_4H: '4h',
  KLINE_1D: '1d',
  
  // Funding rate periods (8 hours each)
  FUNDING_PERIODS_14D: 42, // 14 days * 3 funding periods per day
  
  // OI history periods
  OI_PERIODS_14D: 336, // 14 days * 24 hours (hourly)
};

/**
 * Trading pairs for Binance
 */
const BINANCE_TRADING_PAIRS = {
  SPOT: ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'AVAXUSDT', 'DOGEUSDT', 'DOTUSDT', 'LINKUSDT'],
  FUTURES: ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'AVAXUSDT', 'DOGEUSDT', 'LINKUSDT', 'ARBUSDT', 'OPUSDT'],
};

/**
 * Rate Limiting Configuration
 */
const RATE_LIMITS = {
  COINGECKO: {
    requestsPerMinute: 30,
    minIntervalMs: 2000,
  },
  BINANCE: {
    requestsPerMinute: 1200,
    minIntervalMs: 100,
  },
  DEFILLAMA: {
    requestsPerMinute: 60,
    minIntervalMs: 1000,
  },
  QUICKCHART: {
    requestsPerMonth: 250, // Free tier limit
    minIntervalMs: 500,
  },
};

/**
 * Cache Configuration
 */
const CACHE_CONFIG = {
  DEFAULT_TTL: 60000, // 1 minute
  HISTORICAL_TTL: 300000, // 5 minutes for historical data
  STABLECOIN_TTL: 180000, // 3 minutes
  CHART_TTL: 600000, // 10 minutes for charts
};

/**
 * Report Generation Phases (11 phases for Perfect Report Structure)
 */
const PHASES = {
  DATA_ACQUISITION: 'DATA_ACQUISITION',
  EXECUTIVE_BRIEF: 'EXECUTIVE_BRIEF',
  PRICE_STRUCTURE: 'PRICE_STRUCTURE',
  LIQUIDITY_RISK: 'LIQUIDITY_RISK',
  DERIVATIVES_POSITIONING: 'DERIVATIVES_POSITIONING',
  FLOWS_SUPPLY: 'FLOWS_SUPPLY',
  SECTOR_ROTATION: 'SECTOR_ROTATION',
  NARRATIVES: 'NARRATIVES',
  CATALYST_CALENDAR: 'CATALYST_CALENDAR',
  TRADE_PLAYBOOK: 'TRADE_PLAYBOOK',
  WATCHLIST: 'WATCHLIST',
  QUALITY_ASSURANCE: 'QUALITY_ASSURANCE',
  CHART_GENERATION: 'CHART_GENERATION',
};

/**
 * Phase display information
 */
const PHASE_INFO = {
  [PHASES.DATA_ACQUISITION]: {
    label: 'Data Acquisition',
    color: '#3B82F6',
    order: 1,
    description: 'Fetching market data, on-chain metrics, and derivatives data',
    estimatedSeconds: 45,
  },
  [PHASES.EXECUTIVE_BRIEF]: {
    label: 'Executive Decision Brief',
    color: '#8B5CF6',
    order: 2,
    description: 'Market regime, top takeaways, regime flip triggers',
    estimatedSeconds: 60,
  },
  [PHASES.PRICE_STRUCTURE]: {
    label: 'Price & Structure Snapshot',
    color: '#10B981',
    order: 3,
    description: 'BTC/ETH structure, dominance, key levels',
    estimatedSeconds: 40,
  },
  [PHASES.LIQUIDITY_RISK]: {
    label: 'Liquidity & Risk Dashboard',
    color: '#F97316',
    order: 4,
    description: 'Volatility regime, stablecoins, liquidity stress signals',
    estimatedSeconds: 45,
  },
  [PHASES.DERIVATIVES_POSITIONING]: {
    label: 'Derivatives & Positioning',
    color: '#F59E0B',
    order: 5,
    description: 'Funding, OI, liquidations, basis analysis',
    estimatedSeconds: 50,
  },
  [PHASES.FLOWS_SUPPLY]: {
    label: 'Flows & Supply Pressure',
    color: '#6366F1',
    order: 6,
    description: 'Exchange flows, ETF flows, token unlocks',
    estimatedSeconds: 45,
  },
  [PHASES.SECTOR_ROTATION]: {
    label: 'Sector Rotation Map',
    color: '#EC4899',
    order: 7,
    description: 'Sector performance, rotation signals, narrative drivers',
    estimatedSeconds: 50,
  },
  [PHASES.NARRATIVES]: {
    label: 'Narratives That Moved Price',
    color: '#14B8A6',
    order: 8,
    description: 'Signal vs noise, actual price-moving events',
    estimatedSeconds: 45,
  },
  [PHASES.CATALYST_CALENDAR]: {
    label: 'Catalyst Calendar (14D)',
    color: '#06B6D4',
    order: 9,
    description: 'Upcoming macro, crypto events, unlocks',
    estimatedSeconds: 40,
  },
  [PHASES.TRADE_PLAYBOOK]: {
    label: 'Trade Setup Playbook',
    color: '#EF4444',
    order: 10,
    description: 'Trade ideas with thesis, invalidation, timing',
    estimatedSeconds: 60,
  },
  [PHASES.WATCHLIST]: {
    label: 'Watchlist Generation',
    color: '#84CC16',
    order: 11,
    description: 'Momentum, mean reversion, catalyst-driven assets',
    estimatedSeconds: 40,
  },
  [PHASES.QUALITY_ASSURANCE]: {
    label: 'Quality Assurance',
    color: '#22C55E',
    order: 12,
    description: 'Coherence checking, final QA, report compilation',
    estimatedSeconds: 30,
  },
  [PHASES.CHART_GENERATION]: {
    label: 'Chart Generation',
    color: '#8B5CF6',
    order: 13,
    description: 'Generating signature and contextual charts',
    estimatedSeconds: 15,
  },
};

// ============================================
// PERFECT REPORT SECTIONS (13 Sections)
// ============================================

/**
 * Perfect Report Section Configuration
 * Based on institutional-grade bi-weekly format
 */
const PERFECT_REPORT_SECTIONS = {
  COVER: {
    id: 'cover',
    order: 0,
    title: 'Cover',
    pageLength: 0.5,
    description: 'Report name, date, window, one-line promise, disclaimer',
  },
  EXECUTIVE_BRIEF: {
    id: 'executive_brief',
    order: 1,
    title: 'Executive Decision Brief',
    pageLength: 1,
    description: 'Market regime, flip triggers, top 5 takeaways, one chart that matters',
  },
  PRICE_STRUCTURE: {
    id: 'price_structure',
    order: 2,
    title: 'Price & Structure Snapshot',
    pageLength: 1,
    description: 'BTC/ETH 14D return, range, ATR, trend state, dominance, key levels',
  },
  LIQUIDITY_RISK: {
    id: 'liquidity_risk',
    order: 3,
    title: 'Liquidity & Risk Dashboard',
    pageLength: 1,
    description: 'Volatility regime, stablecoins pulse, liquidity stress signals',
  },
  DERIVATIVES_POSITIONING: {
    id: 'derivatives_positioning',
    order: 4,
    title: 'Derivatives & Positioning',
    pageLength: 1,
    description: 'Funding, OI, liquidations, basis, interpretation table',
  },
  FLOWS_SUPPLY: {
    id: 'flows_supply',
    order: 5,
    title: 'Flows & Supply Pressure',
    pageLength: 1,
    description: 'Exchange reserves, ETF flows, token unlocks, miner pressure',
  },
  SECTOR_ROTATION: {
    id: 'sector_rotation',
    order: 6,
    title: 'Sector Rotation Map',
    pageLength: 1,
    description: 'Sector performance table, heatmap, narrative drivers',
  },
  NARRATIVES: {
    id: 'narratives',
    order: 7,
    title: 'Narratives That Actually Moved Price',
    pageLength: 1,
    description: '3-5 narratives with data evidence and winners/losers',
  },
  CATALYST_CALENDAR: {
    id: 'catalyst_calendar',
    order: 8,
    title: 'Catalyst Calendar (14D Forward)',
    pageLength: 1,
    description: 'Macro events, crypto upgrades, governance, unlocks, listings',
  },
  TRADE_PLAYBOOK: {
    id: 'trade_playbook',
    order: 9,
    title: 'Trade Setup Playbook',
    pageLength: 2,
    description: '3-7 trade ideas with thesis, invalidation, timing, risk notes',
  },
  RISK_PSYCHOLOGY: {
    id: 'risk_psychology',
    order: 10,
    title: 'Risk Management & Trader Psychology',
    pageLength: 0.5,
    description: 'Top 5 mistakes, position sizing, pre-entry checklist',
  },
  WATCHLIST: {
    id: 'watchlist',
    order: 11,
    title: 'Watchlist',
    pageLength: 1,
    description: '10-20 assets: momentum, mean reversion, catalyst-driven',
  },
  DATA_APPENDIX: {
    id: 'data_appendix',
    order: 12,
    title: 'Data Appendix',
    pageLength: 1,
    description: 'Sources, definitions, methodology',
  },
  DISCLAIMER: {
    id: 'disclaimer',
    order: 13,
    title: 'Legal Disclaimer',
    pageLength: 1,
    description: 'Not financial advice, risk disclosure, data limitations',
  },
};

// ============================================
// CHART CONFIGURATION
// ============================================

/**
 * Chart Configuration for report generation
 */
const CHART_CONFIG = {
  // Signature Charts (always included)
  SIGNATURE: {
    PRICE_FUNDING: {
      id: 'priceFunding',
      name: 'BTC Price + Funding (Overlay)',
      section: 'EXECUTIVE_BRIEF',
      description: 'Shows price vs funding rate to identify crowded positioning',
      dimensions: { width: 800, height: 400 },
    },
    OI_PRICE: {
      id: 'oiPrice',
      name: 'Open Interest vs Price',
      section: 'DERIVATIVES_POSITIONING',
      description: 'Shows OI buildup relative to price - divergence = fragility',
      dimensions: { width: 800, height: 400 },
    },
    LIQUIDATION_ZONES: {
      id: 'liquidationZones',
      name: 'Liquidation Zones (Simplified)',
      section: 'DERIVATIVES_POSITIONING',
      description: 'Where major liquidation clusters exist',
      dimensions: { width: 800, height: 250 },
    },
  },
  
  // Contextual Charts (conditionally included)
  CONTEXTUAL: {
    BTC_ETH_RATIO: {
      id: 'btcEthRatio',
      name: 'BTC/ETH Relative Performance',
      trigger: 'rotation',
      section: 'PRICE_STRUCTURE',
      description: 'BTC/ETH ratio for rotation analysis',
      dimensions: { width: 800, height: 300 },
    },
    SECTOR_HEATMAP: {
      id: 'sectorHeatmap',
      name: 'Sector Performance Heatmap',
      trigger: 'always',
      section: 'SECTOR_ROTATION',
      description: '14D sector performance visualization',
      dimensions: { width: 800, height: 400 },
    },
    STABLECOIN_SUPPLY: {
      id: 'stablecoinSupply',
      name: 'Stablecoin Supply (Total)',
      trigger: 'always',
      section: 'LIQUIDITY_RISK',
      description: 'Total stablecoin supply trend',
      dimensions: { width: 800, height: 300 },
    },
  },
  
  // Chart Colors
  COLORS: {
    btcOrange: '#F7931A',
    ethPurple: '#627EEA',
    bullish: '#22C55E',
    bearish: '#EF4444',
    neutral: '#6B7280',
    fundingGreen: '#16A34A',
    fundingRed: '#DC2626',
    oiBlue: '#3B82F6',
    stablecoinBlue: '#0EA5E9',
    gridGray: '#E5E7EB',
    textGray: '#6B7280',
    backgroundWhite: '#FFFFFF',
  },
  
  // Font
  FONT_FAMILY: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
};

// ============================================
// MARKET REGIMES
// ============================================

/**
 * Market Regime Configuration
 */
const MARKET_REGIMES = {
  RISK_ON: {
    id: 'RISK_ON',
    label: 'Risk-On',
    color: '#22C55E',
    description: 'Bullish conditions, increasing risk appetite',
    scoreRange: [70, 100],
  },
  TRANSITIONAL_BULLISH: {
    id: 'TRANSITIONAL_BULLISH',
    label: 'Transitional-Bullish',
    color: '#84CC16',
    description: 'Improving conditions, cautious optimism',
    scoreRange: [55, 69],
  },
  NEUTRAL: {
    id: 'NEUTRAL',
    label: 'Neutral',
    color: '#F59E0B',
    description: 'Range-bound, no clear direction',
    scoreRange: [45, 54],
  },
  TRANSITIONAL_BEARISH: {
    id: 'TRANSITIONAL_BEARISH',
    label: 'Transitional-Bearish',
    color: '#F97316',
    description: 'Deteriorating conditions, increasing caution',
    scoreRange: [30, 44],
  },
  RISK_OFF: {
    id: 'RISK_OFF',
    label: 'Risk-Off',
    color: '#EF4444',
    description: 'Bearish conditions, risk aversion',
    scoreRange: [0, 29],
  },
};

// ============================================
// SECTOR DEFINITIONS
// ============================================

/**
 * Crypto Sector Categories
 */
const CRYPTO_SECTORS = {
  L1: {
    id: 'l1',
    name: 'Layer 1',
    description: 'Base layer blockchains',
    tokens: ['BTC', 'ETH', 'SOL', 'AVAX', 'ADA', 'DOT', 'ATOM', 'NEAR', 'APT', 'SUI', 'SEI'],
    coingeckoCategory: 'layer-1',
  },
  L2: {
    id: 'l2',
    name: 'Layer 2',
    description: 'Scaling solutions',
    tokens: ['ARB', 'OP', 'MATIC', 'IMX', 'STRK', 'ZK', 'MANTA'],
    coingeckoCategory: 'layer-2',
  },
  DEFI: {
    id: 'defi',
    name: 'DeFi',
    description: 'Decentralized finance protocols',
    tokens: ['UNI', 'AAVE', 'MKR', 'LDO', 'CRV', 'COMP', 'SNX', 'SUSHI', 'YFI', 'DYDX'],
    coingeckoCategory: 'decentralized-finance-defi',
  },
  PERPS: {
    id: 'perps',
    name: 'Perp DEXs',
    description: 'Decentralized derivatives exchanges',
    tokens: ['DYDX', 'GMX', 'GNS', 'KWENTA', 'VELA', 'HMX'],
    coingeckoCategory: 'decentralized-perpetuals',
  },
  AI: {
    id: 'ai',
    name: 'AI & Compute',
    description: 'AI and decentralized compute',
    tokens: ['FET', 'RNDR', 'TAO', 'AGIX', 'OCEAN', 'AKT', 'CTXC', 'NMR'],
    coingeckoCategory: 'artificial-intelligence',
  },
  RWA: {
    id: 'rwa',
    name: 'RWA',
    description: 'Real World Assets',
    tokens: ['MKR', 'ONDO', 'PROPS', 'RIO', 'TRU', 'CFG'],
    coingeckoCategory: 'real-world-assets-rwa',
  },
  GAMING: {
    id: 'gaming',
    name: 'Gaming',
    description: 'GameFi and metaverse',
    tokens: ['IMX', 'GALA', 'AXS', 'SAND', 'MANA', 'ENJ', 'ILV', 'BEAM', 'PRIME'],
    coingeckoCategory: 'gaming',
  },
  MEMES: {
    id: 'memes',
    name: 'Memes',
    description: 'Meme coins',
    tokens: ['DOGE', 'SHIB', 'PEPE', 'BONK', 'WIF', 'FLOKI', 'BRETT', 'NEIRO'],
    coingeckoCategory: 'meme-token',
  },
};

// ============================================
// TOP ASSETS CONFIGURATION
// ============================================

/**
 * Top Crypto Assets for Analysis
 */
const TOP_CRYPTO_ASSETS = [
  { symbol: 'BTC', name: 'Bitcoin', category: 'L1' },
  { symbol: 'ETH', name: 'Ethereum', category: 'L1' },
  { symbol: 'SOL', name: 'Solana', category: 'L1' },
  { symbol: 'BNB', name: 'BNB', category: 'L1' },
  { symbol: 'XRP', name: 'XRP', category: 'L1' },
  { symbol: 'ADA', name: 'Cardano', category: 'L1' },
  { symbol: 'AVAX', name: 'Avalanche', category: 'L1' },
  { symbol: 'DOGE', name: 'Dogecoin', category: 'MEMES' },
  { symbol: 'DOT', name: 'Polkadot', category: 'L1' },
  { symbol: 'LINK', name: 'Chainlink', category: 'DEFI' },
  { symbol: 'MATIC', name: 'Polygon', category: 'L2' },
  { symbol: 'ARB', name: 'Arbitrum', category: 'L2' },
  { symbol: 'OP', name: 'Optimism', category: 'L2' },
  { symbol: 'ATOM', name: 'Cosmos', category: 'L1' },
  { symbol: 'UNI', name: 'Uniswap', category: 'DEFI' },
  { symbol: 'APT', name: 'Aptos', category: 'L1' },
  { symbol: 'SUI', name: 'Sui', category: 'L1' },
  { symbol: 'NEAR', name: 'Near', category: 'L1' },
  { symbol: 'INJ', name: 'Injective', category: 'DEFI' },
  { symbol: 'RNDR', name: 'Render', category: 'AI' },
  { symbol: 'FET', name: 'Fetch.ai', category: 'AI' },
  { symbol: 'TAO', name: 'Bittensor', category: 'AI' },
  { symbol: 'TIA', name: 'Celestia', category: 'L1' },
  { symbol: 'SEI', name: 'Sei', category: 'L1' },
  { symbol: 'AAVE', name: 'Aave', category: 'DEFI' },
  { symbol: 'LDO', name: 'Lido DAO', category: 'DEFI' },
  { symbol: 'MKR', name: 'Maker', category: 'DEFI' },
  { symbol: 'CRV', name: 'Curve', category: 'DEFI' },
  { symbol: 'PEPE', name: 'Pepe', category: 'MEMES' },
  { symbol: 'WIF', name: 'Dogwifhat', category: 'MEMES' },
];

/**
 * Stablecoins Configuration
 */
const STABLECOINS = {
  USDT: { id: 'tether', name: 'Tether', symbol: 'USDT' },
  USDC: { id: 'usd-coin', name: 'USD Coin', symbol: 'USDC' },
  DAI: { id: 'dai', name: 'Dai', symbol: 'DAI' },
  FDUSD: { id: 'first-digital-usd', name: 'First Digital USD', symbol: 'FDUSD' },
  USDE: { id: 'ethena-usde', name: 'Ethena USDe', symbol: 'USDe' },
};

// ============================================
// TRADE CONFIGURATION
// ============================================

/**
 * Trade Types
 */
const TRADE_TYPES = {
  SPOT_LONG: {
    id: 'spot_long',
    label: 'Spot Long',
    description: 'Simple buy and hold position',
    riskLevel: 'base',
    leverageGuidance: '1x (no leverage)',
  },
  PERP_LONG: {
    id: 'perp_long',
    label: 'Perpetual Long',
    description: 'Leveraged long via perpetual futures',
    riskLevel: 'elevated',
    leverageGuidance: '2-3x max for most traders',
  },
  PERP_SHORT: {
    id: 'perp_short',
    label: 'Perpetual Short',
    description: 'Leveraged short via perpetual futures',
    riskLevel: 'elevated',
    leverageGuidance: '2-3x max, tight stops required',
  },
  RANGE_TRADE: {
    id: 'range_trade',
    label: 'Range Trade',
    description: 'Buy support, sell resistance within range',
    riskLevel: 'medium',
    leverageGuidance: 'Spot or low leverage (1-2x)',
  },
  BREAKOUT: {
    id: 'breakout',
    label: 'Breakout Trade',
    description: 'Enter on confirmed breakout with volume',
    riskLevel: 'medium',
    leverageGuidance: '1-2x, scale in on confirmation',
  },
  MEAN_REVERSION: {
    id: 'mean_reversion',
    label: 'Mean Reversion',
    description: 'Fade extremes, expect return to mean',
    riskLevel: 'elevated',
    leverageGuidance: 'Spot only, scale entry required',
  },
};

/**
 * Risk Levels
 */
const RISK_LEVELS = {
  CONSERVATIVE: {
    id: 'conservative',
    label: 'Conservative',
    maxLeverage: 1,
    maxSinglePosition: 5,
    cashBuffer: 30,
    description: 'Spot only, max 5% per position',
  },
  MODERATE: {
    id: 'moderate',
    label: 'Moderate',
    maxLeverage: 2,
    maxSinglePosition: 10,
    cashBuffer: 20,
    description: 'Low leverage allowed, max 10% per position',
  },
  AGGRESSIVE: {
    id: 'aggressive',
    label: 'Aggressive',
    maxLeverage: 5,
    maxSinglePosition: 15,
    cashBuffer: 10,
    description: 'Higher leverage, experienced traders only',
  },
};

// ============================================
// ALTCOIN DD CHECKLIST
// ============================================

/**
 * Altcoin Due Diligence Checklist
 */
const ALTCOIN_DD_CHECKLIST = [
  {
    id: 'tokenomics',
    name: 'Tokenomics',
    weight: 25,
    questions: [
      'What is circulating vs total vs max supply?',
      'What is the unlock schedule? Any cliffs?',
      'What % unlocks in next 14 days vs ADV?',
      'What is the allocation split (team/investors/community)?',
      'Is there real token utility beyond speculation?',
    ],
  },
  {
    id: 'product_market_fit',
    name: 'Product-Market Fit',
    weight: 30,
    questions: [
      'What problem does this solve?',
      'Why does it need blockchain/decentralization?',
      'What are the usage metrics (DAU, transactions, TVL)?',
      'Is there real revenue generation?',
      'What is the competitive moat?',
    ],
  },
  {
    id: 'team_governance',
    name: 'Team & Governance',
    weight: 15,
    questions: [
      'Who is the team? Track record?',
      'How fast are they shipping?',
      'Is decentralization real or theater?',
      'What are the admin key / upgrade risks?',
    ],
  },
  {
    id: 'security',
    name: 'Security',
    weight: 20,
    questions: [
      'How many audits? By whom?',
      'Is there an active bug bounty?',
      'Any bridge/oracle dependencies?',
      'What is the smart contract complexity?',
    ],
  },
  {
    id: 'liquidity',
    name: 'Liquidity & Structure',
    weight: 10,
    questions: [
      'What is the order book depth (2% depth)?',
      'Is volume real or wash trading?',
      'Exchange concentration risk?',
      'Who are the market makers?',
    ],
  },
];

/**
 * Altcoin Verdicts
 */
const ALTCOIN_VERDICTS = {
  ACCUMULATE: {
    id: 'accumulate',
    label: 'Accumulate',
    color: '#22C55E',
    description: 'Active buying opportunity. Build position on dips.',
  },
  HOLD: {
    id: 'hold',
    label: 'Hold',
    color: '#F59E0B',
    description: 'Maintain existing position. Do not add.',
  },
  AVOID: {
    id: 'avoid',
    label: 'Avoid',
    color: '#EF4444',
    description: 'Do not buy. Reduce exposure if held.',
  },
};

// ============================================
// ON-CHAIN METRICS
// ============================================

/**
 * On-Chain Metrics Configuration
 */
const ONCHAIN_METRICS = [
  {
    id: 'exchange_netflow',
    name: 'Exchange Netflow',
    source: 'proxy',
    bullish: 'negative (outflow)',
    bearish: 'positive (inflow)',
  },
  {
    id: 'stablecoin_supply',
    name: 'Stablecoin Supply Change',
    source: 'DeFiLlama',
    bullish: 'growing',
    bearish: 'shrinking',
  },
  {
    id: 'defi_tvl',
    name: 'DeFi TVL',
    source: 'DeFiLlama',
    bullish: 'growing',
    bearish: 'shrinking',
  },
  {
    id: 'active_addresses',
    name: 'Active Addresses',
    source: 'limited',
    bullish: 'growing',
    bearish: 'shrinking',
  },
];

/**
 * Derivatives Metrics Configuration
 */
const DERIVATIVES_METRICS = [
  {
    id: 'funding_rate',
    name: 'Funding Rate',
    source: 'Binance',
    extreme_positive: '> 0.05% (annualized > 55%)',
    extreme_negative: '< -0.01%',
    neutral: '-0.01% to 0.03%',
  },
  {
    id: 'open_interest',
    name: 'Open Interest',
    source: 'Binance',
    signal: 'Rising OI + rising price = trend confirmation',
    warning: 'Rising OI + flat price = fragility',
  },
  {
    id: 'long_short_ratio',
    name: 'Long/Short Ratio',
    source: 'Binance',
    crowded_long: '> 1.5',
    crowded_short: '< 0.7',
    balanced: '0.8 - 1.2',
  },
  {
    id: 'liquidations',
    name: 'Liquidations',
    source: 'Binance/CoinGlass',
    signal: 'Large liquidation cascade = potential reversal zone',
  },
];

// ============================================
// NEWS CATEGORIES
// ============================================

/**
 * News Categories for filtering
 */
const NEWS_CATEGORIES = {
  REGULATORY: {
    id: 'regulatory',
    label: 'Regulatory',
    impact: 'high',
    examples: ['SEC actions', 'legislation', 'court rulings'],
  },
  INSTITUTIONAL: {
    id: 'institutional',
    label: 'Institutional',
    impact: 'high',
    examples: ['ETF flows', 'corporate treasury', 'fund launches'],
  },
  PROTOCOL: {
    id: 'protocol',
    label: 'Protocol',
    impact: 'medium',
    examples: ['upgrades', 'forks', 'governance'],
  },
  MACRO: {
    id: 'macro',
    label: 'Macro',
    impact: 'high',
    examples: ['Fed decisions', 'inflation data', 'employment'],
  },
  PARTNERSHIP: {
    id: 'partnership',
    label: 'Partnership',
    impact: 'low-medium',
    examples: ['integrations', 'collaborations'],
  },
  HACK: {
    id: 'hack',
    label: 'Security',
    impact: 'high',
    examples: ['exploits', 'hacks', 'vulnerabilities'],
  },
};

// ============================================
// DATA SOURCES CONFIGURATION
// ============================================

/**
 * Data Sources Configuration
 */
const DATA_SOURCES = {
  MARKET_DATA: {
    primary: 'CoinGecko',
    fallback: 'CoinMarketCap',
    refreshInterval: 60,
  },
  DERIVATIVES: {
    primary: 'Binance',
    fallback: null,
    refreshInterval: 60,
  },
  ONCHAIN: {
    btc: 'Blockchain.com (limited)',
    eth: 'Etherscan (limited)',
    general: 'DeFiLlama',
    note: 'No Glassnode/CryptoQuant access',
    refreshInterval: 300,
  },
  STABLECOINS: {
    primary: 'DeFiLlama',
    fallback: 'CoinGecko',
    refreshInterval: 300,
  },
  TVL: {
    primary: 'DeFiLlama',
    refreshInterval: 300,
  },
  LIQUIDATIONS: {
    primary: 'CoinGlass (limited)',
    fallback: 'Binance forced orders',
    refreshInterval: 60,
  },
  SENTIMENT: {
    fearGreed: 'Alternative.me',
    refreshInterval: 3600,
  },
  CHARTS: {
    primary: 'QuickChart.io',
    refreshInterval: 600,
  },
};

// ============================================
// SCHEDULE CONFIGURATION
// ============================================

/**
 * Schedule Configuration
 */
const SCHEDULE_CONFIG = {
  // Bi-weekly crypto report - Sunday 6 PM UTC (before Asia session)
  weeklyCron: '0 18 * * 0',
  
  // Data refresh intervals
  dataRefreshMinutes: 15,
  
  // Timezone for scheduling
  timezone: 'UTC',
  
  // Retry configuration
  maxRetries: 3,
  retryDelayMs: 300000, // 5 minutes
  
  // Report window
  reportWindowDays: 14,
};

// ============================================
// MAIN REPORT CONFIGURATION
// ============================================

/**
 * Main Report Configuration
 */
const REPORT_CONFIG = {
  version: '5.0.0', // Perfect Report Structure
  name: 'Crypto Market Intelligence Report',
  subtitle: 'Bi-Weekly Institutional-Grade Analysis',
  
  // Structure
  totalPages: '8-12',
  readingTime: '10-15 minutes',
  windowDays: 14,
  
  // Agent counts
  agentCount: 25,
  estimatedDurationSeconds: 600, // ~10 minutes
  
  // Output formats
  outputFormats: ['markdown', 'html', 'pdf', 'json'],
  language: 'en',
  
  // Quality thresholds
  minQAScore: 70,
  targetQAScore: 85,
  
  // Chart generation
  generateCharts: true,
  signatureChartsCount: 3,
  contextualChartsMax: 3,
  
  // Style settings
  style: {
    useEmojis: false, // Institutional grade = no emojis
    useTables: true,
    useCodeBlocks: false,
    includeDataAppendix: true,
    useCharts: true,
    sectionFlow: 'continuous',
  },
  
  // Perfect Report Rules
  rules: {
    everySectionEndsWith: 'So what (actionable conclusion)',
    consistentTemplate: true,
    noInventedPrecision: true,
    proxyOrMissing: 'Use proxy or mark [DATA NOT AVAILABLE FREE]',
  },
};

/**
 * AI Model Configuration
 */
const AI_CONFIG = {
  model: 'claude-sonnet-4-20250514',
  fallbackModel: 'claude-sonnet-4-20250514',
  maxTokens: 4096,
  temperature: {
    analysis: 0.3,
    synthesis: 0.4,
    creative: 0.5,
  },
  retryAttempts: 2,
};

// ============================================
// EXPORTS (ES Modules)
// ============================================

export {
  // API Configuration
  API_ENDPOINTS,
  BINANCE_FUTURES_ENDPOINTS,
  BINANCE_DATA_ENDPOINTS,
  TIMEFRAMES,
  BINANCE_TRADING_PAIRS,
  RATE_LIMITS,
  CACHE_CONFIG,
  
  // Chart Configuration
  CHART_CONFIG,
  
  // Phases
  PHASES,
  PHASE_INFO,
  
  // Perfect Report Structure
  PERFECT_REPORT_SECTIONS,
  
  // Market Configuration
  MARKET_REGIMES,
  CRYPTO_SECTORS,
  TOP_CRYPTO_ASSETS,
  STABLECOINS,
  
  // Trade Configuration
  TRADE_TYPES,
  RISK_LEVELS,
  
  // Altcoin Configuration
  ALTCOIN_DD_CHECKLIST,
  ALTCOIN_VERDICTS,
  
  // Metrics
  ONCHAIN_METRICS,
  DERIVATIVES_METRICS,
  
  // News
  NEWS_CATEGORIES,
  
  // Data Sources
  DATA_SOURCES,
  
  // Scheduling
  SCHEDULE_CONFIG,
  
  // Main Config
  REPORT_CONFIG,
  AI_CONFIG,
};