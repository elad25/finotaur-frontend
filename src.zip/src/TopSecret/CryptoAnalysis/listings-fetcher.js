/**
 * Crypto Listings Fetcher
 * Fetches new and upcoming token listings from multiple sources
 * 
 * Sources:
 * 1. Binance Announcements API (primary)
 * 2. CoinGecko Recently Added (fallback/supplement)
 * 
 * Usage in crypto report:
 *   import { getUpcomingListings, formatForReport } from './listings-fetcher.js';
 *   const listings = await getUpcomingListings();
 */

import fetch from 'node-fetch';

// ============================================
// BINANCE ANNOUNCEMENTS
// ============================================

const BINANCE_CMS_API = 'https://www.binance.com/bapi/composite/v1/public/cms/article/list/query';

const CATALOG_IDS = {
  NEW_LISTINGS: 48,
  LAUNCHPOOL: 162,
  LAUNCHPAD: 128,
};

/**
 * Fetch from Binance CMS API
 */
async function fetchBinanceListings(options = {}) {
  const { catalogId = CATALOG_IDS.NEW_LISTINGS, pageSize = 20 } = options;
  
  const url = `${BINANCE_CMS_API}?type=1&catalogId=${catalogId}&pageNo=1&pageSize=${pageSize}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0',
        'Referer': 'https://www.binance.com/en/support/announcement',
      },
      timeout: 10000,
    });

    if (!response.ok) {
      console.log('[Binance] API returned', response.status);
      return { success: false, articles: [] };
    }

    const data = await response.json();
    
    if (data.code !== '000000' || !data.data?.catalogs) {
      return { success: false, articles: [] };
    }

    const articles = data.data.catalogs.map(article => {
      const tokenInfo = extractTokenFromTitle(article.title);
      return {
        source: 'binance',
        id: article.id,
        title: article.title,
        date: article.releaseDate ? new Date(article.releaseDate) : null,
        dateFormatted: article.releaseDate 
          ? new Date(article.releaseDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
          : null,
        url: `https://www.binance.com/en/support/announcement/${article.code}`,
        token: tokenInfo,
      };
    });

    return { success: true, articles };
  } catch (error) {
    console.error('[Binance] Fetch error:', error.message);
    return { success: false, articles: [], error: error.message };
  }
}

/**
 * Extract token symbol from Binance announcement title
 */
function extractTokenFromTitle(title) {
  // "Binance Will List XXX (SYMBOL)"
  const listMatch = title.match(/(?:Will List|Lists?)\s+([^(]+)\s*\(([A-Z0-9]+)\)/i);
  if (listMatch) {
    return { name: listMatch[1].trim(), symbol: listMatch[2].toUpperCase(), type: 'spot' };
  }

  // "Introducing XXX (SYMBOL) on Binance Launchpool"
  const launchMatch = title.match(/Introducing\s+([^(]+)\s*\(([A-Z0-9]+)\)/i);
  if (launchMatch) {
    return { name: launchMatch[1].trim(), symbol: launchMatch[2].toUpperCase(), type: 'launchpool' };
  }

  // "Binance Futures Will Launch XXX"
  const futuresMatch = title.match(/Futures\s+(?:Will\s+)?Launch[s]?\s+(?:USDⓈ?-M\s+)?([A-Z0-9]+)/i);
  if (futuresMatch) {
    return { symbol: futuresMatch[1].toUpperCase(), type: 'futures' };
  }

  return null;
}

// ============================================
// COINGECKO - Recently Added Coins
// ============================================

const COINGECKO_API = 'https://api.coingecko.com/api/v3';

/**
 * Fetch recently added coins from CoinGecko
 */
async function fetchCoinGeckoNewCoins(options = {}) {
  const { limit = 50 } = options;
  
  try {
    // Get coins sorted by newest first
    const url = `${COINGECKO_API}/coins/markets?vs_currency=usd&order=id_desc&per_page=${limit}&page=1&sparkline=false`;
    
    const response = await fetch(url, {
      headers: {
        'Accept': 'application/json',
      },
      timeout: 15000,
    });

    if (!response.ok) {
      console.log('[CoinGecko] API returned', response.status);
      return { success: false, coins: [] };
    }

    const coins = await response.json();
    
    // Filter for coins added in the last 30 days (estimated by low market cap rank or recent activity)
    const recentCoins = coins
      .filter(coin => coin.market_cap_rank > 500 || coin.market_cap_rank === null)
      .slice(0, 20)
      .map(coin => ({
        source: 'coingecko',
        id: coin.id,
        symbol: coin.symbol?.toUpperCase(),
        name: coin.name,
        price: coin.current_price,
        priceFormatted: coin.current_price 
          ? (coin.current_price < 0.01 ? `$${coin.current_price.toFixed(6)}` : `$${coin.current_price.toFixed(2)}`)
          : null,
        marketCap: coin.market_cap,
        marketCapFormatted: coin.market_cap 
          ? (coin.market_cap >= 1e9 ? `$${(coin.market_cap/1e9).toFixed(2)}B` : `$${(coin.market_cap/1e6).toFixed(1)}M`)
          : null,
        change24h: coin.price_change_percentage_24h,
        image: coin.image,
        url: `https://www.coingecko.com/en/coins/${coin.id}`,
      }));

    return { success: true, coins: recentCoins };
  } catch (error) {
    console.error('[CoinGecko] Fetch error:', error.message);
    return { success: false, coins: [], error: error.message };
  }
}

/**
 * Get trending coins from CoinGecko (often includes new listings)
 */
async function fetchCoinGeckoTrending() {
  try {
    const response = await fetch(`${COINGECKO_API}/search/trending`, {
      headers: { 'Accept': 'application/json' },
      timeout: 10000,
    });

    if (!response.ok) {
      return { success: false, coins: [] };
    }

    const data = await response.json();
    
    const trending = (data.coins || []).map(item => ({
      source: 'coingecko_trending',
      id: item.item.id,
      symbol: item.item.symbol?.toUpperCase(),
      name: item.item.name,
      marketCapRank: item.item.market_cap_rank,
      score: item.item.score,
      url: `https://www.coingecko.com/en/coins/${item.item.id}`,
    }));

    return { success: true, coins: trending };
  } catch (error) {
    console.error('[CoinGecko] Trending fetch error:', error.message);
    return { success: false, coins: [] };
  }
}

// ============================================
// COMBINED FETCHER
// ============================================

/**
 * Get all upcoming/recent listings from all sources
 * @param {Object} options
 * @param {number} options.days - Look back N days (default: 14)
 * @returns {Promise<Object>} Combined listings data
 */
export async function getUpcomingListings(options = {}) {
  const { days = 14 } = options;
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  // Fetch from all sources in parallel
  const [binanceResult, coingeckoResult, trendingResult] = await Promise.allSettled([
    fetchBinanceListings({ catalogId: CATALOG_IDS.NEW_LISTINGS }),
    fetchCoinGeckoNewCoins({ limit: 30 }),
    fetchCoinGeckoTrending(),
  ]);

  // Process Binance listings
  const binanceListings = binanceResult.status === 'fulfilled' && binanceResult.value.success
    ? binanceResult.value.articles.filter(a => a.token && (!a.date || a.date >= cutoffDate))
    : [];

  // Process CoinGecko new coins
  const coingeckoCoins = coingeckoResult.status === 'fulfilled' && coingeckoResult.value.success
    ? coingeckoResult.value.coins
    : [];

  // Process trending
  const trendingCoins = trendingResult.status === 'fulfilled' && trendingResult.value.success
    ? trendingResult.value.coins
    : [];

  return {
    fetchedAt: new Date().toISOString(),
    binance: {
      success: binanceResult.status === 'fulfilled' && binanceResult.value.success,
      count: binanceListings.length,
      listings: binanceListings,
    },
    coingecko: {
      success: coingeckoResult.status === 'fulfilled' && coingeckoResult.value.success,
      count: coingeckoCoins.length,
      newCoins: coingeckoCoins,
    },
    trending: {
      success: trendingResult.status === 'fulfilled' && trendingResult.value.success,
      count: trendingCoins.length,
      coins: trendingCoins,
    },
  };
}

/**
 * Format listings for the crypto report
 * @param {Object} data - Data from getUpcomingListings
 * @returns {Object} Formatted for report markdown
 */
export function formatForReport(data) {
  const result = {
    hasData: false,
    binanceSection: null,
    trendingSection: null,
    summary: '',
  };

  // Binance listings section
  if (data.binance?.listings?.length > 0) {
    result.hasData = true;
    const listings = data.binance.listings.slice(0, 5);
    
    result.binanceSection = {
      title: 'Recent Binance Listings',
      rows: listings.map(l => ({
        date: l.dateFormatted || 'Recent',
        token: l.token?.symbol || 'Unknown',
        name: l.token?.name || '',
        type: l.token?.type === 'spot' ? 'Spot' : 
              l.token?.type === 'futures' ? 'Futures' : 
              l.token?.type === 'launchpool' ? 'Launchpool' : 'Other',
      })),
    };

    const symbols = listings.map(l => l.token?.symbol).filter(Boolean).join(', ');
    result.summary += `Binance recently listed: ${symbols}. `;
  }

  // Trending section
  if (data.trending?.coins?.length > 0) {
    result.hasData = true;
    const trending = data.trending.coins.slice(0, 5);
    
    result.trendingSection = {
      title: 'Trending Tokens',
      rows: trending.map(t => ({
        rank: t.score + 1,
        symbol: t.symbol,
        name: t.name,
        marketCapRank: t.marketCapRank || 'Unranked',
      })),
    };
  }

  if (!result.hasData) {
    result.summary = 'No significant new listings in the past two weeks.';
  }

  return result;
}

/**
 * Generate markdown section for crypto report
 * @param {Object} data - Data from getUpcomingListings
 * @returns {string} Markdown string
 */
export function generateMarkdownSection(data) {
  const formatted = formatForReport(data);
  let md = '';

  if (formatted.binanceSection) {
    md += `### Recent Binance Listings\n\n`;
    md += `| Date | Token | Name | Type |\n`;
    md += `|------|-------|------|------|\n`;
    formatted.binanceSection.rows.forEach(row => {
      md += `| ${row.date} | ${row.token} | ${row.name} | ${row.type} |\n`;
    });
    md += `\n`;
  }

  if (formatted.trendingSection) {
    md += `### Trending Tokens (CoinGecko)\n\n`;
    md += `| # | Symbol | Name | MC Rank |\n`;
    md += `|---|--------|------|---------|\n`;
    formatted.trendingSection.rows.forEach(row => {
      md += `| ${row.rank} | ${row.symbol} | ${row.name} | ${row.marketCapRank} |\n`;
    });
    md += `\n`;
  }

  if (!formatted.hasData) {
    md += `No significant new listings in the past two weeks.\n\n`;
  }

  return md;
}

// ============================================
// EXPORTS
// ============================================

export default {
  getUpcomingListings,
  formatForReport,
  generateMarkdownSection,
  // Individual fetchers
  fetchBinanceListings,
  fetchCoinGeckoNewCoins,
  fetchCoinGeckoTrending,
};

// ============================================
// CLI TEST
// ============================================

if (process.argv[1]?.includes('listings-fetcher')) {
  console.log('[Listings] Testing fetcher...\n');
  
  getUpcomingListings({ days: 30 })
    .then(data => {
      console.log('='.repeat(60));
      console.log('CRYPTO LISTINGS REPORT');
      console.log('='.repeat(60));
      
      console.log('\n📢 BINANCE LISTINGS:');
      if (data.binance.success && data.binance.count > 0) {
        data.binance.listings.forEach(l => {
          console.log(`  • ${l.token?.symbol} - ${l.token?.name} (${l.token?.type}) - ${l.dateFormatted || 'Recent'}`);
        });
      } else {
        console.log('  No data (API may be blocked or no recent listings)');
      }

      console.log('\n🔥 TRENDING (CoinGecko):');
      if (data.trending.success && data.trending.count > 0) {
        data.trending.coins.slice(0, 5).forEach((c, i) => {
          console.log(`  ${i+1}. ${c.symbol} - ${c.name}`);
        });
      } else {
        console.log('  No trending data');
      }

      console.log('\n' + '='.repeat(60));
      console.log('\n📝 MARKDOWN OUTPUT:');
      console.log(generateMarkdownSection(data));
    })
    .catch(err => {
      console.error('Error:', err);
    });
}