// =====================================================
// CRYPTO ANALYSIS ORCHESTRATOR v6.0
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/orchestrator.js
//
// PERFECT REPORT STRUCTURE (13 Sections, Bi-Weekly, 8-12 pages)
// Manages execution of 25 AI agents in correct order
// Handles dependencies, progress tracking, and error recovery
// Chart generation phase after agent execution
//
// PHASES:
// 1)  Data Acquisition (3 agents)
// 2)  Executive Brief (3 agents)
// 3)  Price & Structure (2 agents)
// 4)  Liquidity & Risk (2 agents)
// 5)  Derivatives (3 agents)
// 6)  Flows & Supply (2 agents)
// 7)  Sector Rotation (2 agents)
// 8)  Narratives (1 agent)
// 9)  Catalyst Calendar (1 agent)
// 10) Trade Playbook (2 agents)
// 11) Watchlist (1 agent)
// 12) Quality Assurance (3 agents)
// 13) Chart Generation (post-agent phase)
// =====================================================

import { v4 as uuidv4 } from 'uuid';
import { AGENT_DEFINITIONS, AGENT_EXECUTORS, DATA_TAGS, SYSTEM_PROMPTS } from './CryptoAgents.js';
import { CryptoDataService } from './data-service.js';
import { CryptoAIService } from './ai-service.js';
import { PHASES, PHASE_INFO, REPORT_CONFIG, PERFECT_REPORT_SECTIONS, CRYPTO_SECTORS } from './config.js';
import { generateMarkdownReport, generateMarkdownReportAsync } from './report-generator.js';
import { generateAllCharts } from './chart-generator.js';
import { generateCryptoReportPDF } from './crypto-pdf-generator.js';

// ============================================
// PHASES DEFINITION (if not in config.js)
// ============================================

const ORCHESTRATOR_PHASES = {
  DATA_ACQUISITION: 'DATA_ACQUISITION',
  EXECUTIVE_BRIEF: 'EXECUTIVE_BRIEF',
  PRICE_STRUCTURE: 'PRICE_STRUCTURE',
  LIQUIDITY_RISK: 'LIQUIDITY_RISK',
  DERIVATIVES: 'DERIVATIVES',
  FLOWS_SUPPLY: 'FLOWS_SUPPLY',
  SECTOR_ROTATION: 'SECTOR_ROTATION',
  NARRATIVES: 'NARRATIVES',
  CATALYST_CALENDAR: 'CATALYST_CALENDAR',
  TRADE_PLAYBOOK: 'TRADE_PLAYBOOK',
  WATCHLIST: 'WATCHLIST',
  QUALITY_ASSURANCE: 'QUALITY_ASSURANCE',
  CHART_GENERATION: 'CHART_GENERATION',
};

// ============================================
// WORKFLOW MANAGER
// ============================================

class WorkflowManager {
  constructor() {
    this.activeWorkflows = new Map();
  }

  create(reportId) {
    const workflow = {
      reportId,
      status: 'pending',
      currentPhase: null,
      currentAgent: null,
      progress: 0,
      completedAgents: [],
      results: {},
      charts: null,
      errors: [],
      warnings: [],
      startedAt: null,
      completedAt: null,
      elapsedSeconds: 0,
      tokensUsed: 0,
    };
    this.activeWorkflows.set(reportId, workflow);
    return workflow;
  }

  get(reportId) {
    return this.activeWorkflows.get(reportId);
  }

  update(reportId, updates) {
    const workflow = this.activeWorkflows.get(reportId);
    if (workflow) {
      Object.assign(workflow, updates);
      // Calculate elapsed time
      if (workflow.startedAt) {
        workflow.elapsedSeconds = Math.floor((Date.now() - new Date(workflow.startedAt).getTime()) / 1000);
      }
    }
    return workflow;
  }

  complete(reportId, result) {
    const workflow = this.activeWorkflows.get(reportId);
    if (workflow) {
      workflow.status = 'completed';
      workflow.completedAt = new Date().toISOString();
      workflow.result = result;
      workflow.progress = 100;
    }
    return workflow;
  }

  fail(reportId, error) {
    const workflow = this.activeWorkflows.get(reportId);
    if (workflow) {
      workflow.status = 'error';
      workflow.error = error;
      workflow.completedAt = new Date().toISOString();
    }
    return workflow;
  }

  remove(reportId) {
    this.activeWorkflows.delete(reportId);
  }

  getActive() {
    return Array.from(this.activeWorkflows.values()).filter(w => w.status === 'running');
  }

  getAll() {
    return Array.from(this.activeWorkflows.values());
  }
}

const workflowManager = new WorkflowManager();

// ============================================
// ORCHESTRATOR CLASS
// ============================================

class CryptoAnalysisOrchestrator {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    this.options = {
      openaiApiKey: options.openaiApiKey || process.env.OPENAI_API_KEY,
      openaiModel: options.openaiModel || 'claude-sonnet-4-20250514',
      maxConcurrentAgents: options.maxConcurrentAgents || 1, // Sequential for dependency management
      retryAttempts: options.retryAttempts || 2,
      retryDelayMs: options.retryDelayMs || 2000,
      generateCharts: options.generateCharts !== false,
      reportWindow: options.reportWindow || 14, // 14-day bi-weekly window
      saveToDatabase: options.saveToDatabase !== false,
      ...options,
    };

    // Initialize services
    this.dataService = new CryptoDataService(supabase, options);
    this.aiService = new CryptoAIService({
      apiKey: this.options.openaiApiKey,
      model: this.options.openaiModel,
    });

    // Sort agents by phase and order
    this.agents = [...AGENT_DEFINITIONS].sort((a, b) => {
      if (a.phase !== b.phase) {
        return this.getPhaseOrder(a.phase) - this.getPhaseOrder(b.phase);
      }
      return a.order - b.order;
    });
    
    this.totalAgents = this.agents.length;
    
    console.log(`[CryptoOrchestrator] Initialized with ${this.totalAgents} agents`);
  }

  /**
   * Get numeric order for phase (for sorting)
   */
  getPhaseOrder(phase) {
    const phaseOrder = {
      'DATA_ACQUISITION': 1,
      'EXECUTIVE_BRIEF': 2,
      'PRICE_STRUCTURE': 3,
      'LIQUIDITY_RISK': 4,
      'DERIVATIVES': 5,
      'FLOWS_SUPPLY': 6,
      'SECTOR_ROTATION': 7,
      'NARRATIVES': 8,
      'CATALYST_CALENDAR': 9,
      'TRADE_PLAYBOOK': 10,
      'WATCHLIST': 11,
      'QUALITY_ASSURANCE': 12,
    };
    return phaseOrder[phase] || 99;
  }

  // ============================================
  // MAIN GENERATION METHOD
  // ============================================

  /**
   * Generate a complete crypto analysis report (13-section bi-weekly)
   */
  async generate(options = {}) {
    const reportId = options.reportId || uuidv4();
    const reportDate = options.reportDate || new Date().toISOString().split('T')[0];
    
    // Calculate 14-day window
    const windowEnd = new Date(reportDate);
    const windowStart = new Date(windowEnd);
    windowStart.setDate(windowStart.getDate() - this.options.reportWindow);
    
    console.log(`[CryptoOrchestrator] ========================================`);
    console.log(`[CryptoOrchestrator] Starting bi-weekly report generation`);
    console.log(`[CryptoOrchestrator] Report ID: ${reportId}`);
    console.log(`[CryptoOrchestrator] Date: ${reportDate}`);
    console.log(`[CryptoOrchestrator] Window: ${windowStart.toISOString().split('T')[0]} → ${windowEnd.toISOString().split('T')[0]}`);
    console.log(`[CryptoOrchestrator] Agents: ${this.totalAgents}`);
    console.log(`[CryptoOrchestrator] ========================================`);
    
    // Create workflow
    const workflow = workflowManager.create(reportId);
    workflow.status = 'running';
    workflow.startedAt = new Date().toISOString();

    // Create execution context
    const context = {
      reportId,
      reportDate,
      windowStart: windowStart.toISOString().split('T')[0],
      windowEnd: windowEnd.toISOString().split('T')[0],
      windowDays: this.options.reportWindow,
      dataService: this.dataService,
      aiService: this.aiService,
      results: {},
      errors: [],
      warnings: [],
      options,
    };

    try {
      // Calculate total steps (agents + optional chart generation)
      const totalSteps = this.options.generateCharts ? this.totalAgents + 1 : this.totalAgents;
      
      // ============================================
      // PHASE 1-12: EXECUTE AGENTS
      // ============================================
      
      let currentPhase = null;
      
      for (let i = 0; i < this.agents.length; i++) {
        const agent = this.agents[i];
        
        // Log phase change
        if (agent.phase !== currentPhase) {
          currentPhase = agent.phase;
          console.log(`\n[CryptoOrchestrator] ▶ Phase: ${currentPhase}`);
        }
        
        // Update workflow
        workflowManager.update(reportId, {
          currentPhase: agent.phase,
          currentAgent: agent.id,
          progress: Math.round((i / totalSteps) * 100),
        });

        // Check dependencies
        const dependenciesCheck = this.checkDependencies(agent, context.results);
        if (!dependenciesCheck.success) {
          console.warn(`[CryptoOrchestrator] ⚠️ Skipping ${agent.id}: ${dependenciesCheck.reason}`);
          workflow.warnings.push({
            agent: agent.id,
            warning: `Skipped: ${dependenciesCheck.reason}`,
            missingDeps: dependenciesCheck.missing,
          });
          
          // Store empty result so dependent agents can handle gracefully
          context.results[agent.id] = {
            success: false,
            skipped: true,
            error: dependenciesCheck.reason,
            data: null,
          };
          continue;
        }

        // Execute agent
        console.log(`[CryptoOrchestrator] [${i + 1}/${this.totalAgents}] ${agent.name}...`);
        const startTime = Date.now();
        
        const result = await this.executeAgent(agent, context);
        
        const duration = ((Date.now() - startTime) / 1000).toFixed(1);
        
        // Store result
        context.results[agent.id] = result;
        workflow.results[agent.id] = result;
        workflow.completedAgents.push(agent.id);

        // Track tokens
        if (result.tokensUsed) {
          workflow.tokensUsed += result.tokensUsed;
        }

        if (result.success) {
          console.log(`[CryptoOrchestrator] ✅ ${agent.id} completed (${duration}s)`);
        } else {
          console.warn(`[CryptoOrchestrator] ❌ ${agent.id} failed: ${result.error}`);
          workflow.errors.push({
            agent: agent.id,
            error: result.error,
            duration,
          });
        }

        // Progress callback
        if (options.onProgress) {
          options.onProgress({
            reportId,
            phase: agent.phase,
            agent: agent.id,
            agentName: agent.name,
            agentType: agent.type,
            progress: Math.round(((i + 1) / totalSteps) * 100),
            completedAgents: [...workflow.completedAgents],
            elapsedSeconds: workflow.elapsedSeconds,
            tokensUsed: workflow.tokensUsed,
            success: result.success,
          });
        }
      }

      // ============================================
      // PHASE 13: CHART GENERATION
      // ============================================
      
      let charts = null;
      
      if (this.options.generateCharts) {
        console.log(`\n[CryptoOrchestrator] ▶ Phase: CHART_GENERATION`);
        
        workflowManager.update(reportId, {
          currentPhase: ORCHESTRATOR_PHASES.CHART_GENERATION,
          currentAgent: 'chart_generator',
          progress: Math.round((this.totalAgents / totalSteps) * 100),
        });

        try {
          // Get market and derivatives data for charts
          const marketData = context.results.market_data_fetcher?.data || {};
          const derivativesData = context.results.derivatives_data_fetcher?.data || {};
          
          // Extract data for PM-Grade Decision Charts (5 key charts)
          const regimeData = context.results.regime_detector?.data || {};
          const liquidityStressData = context.results.liquidity_stress_analyzer?.data || {};
          const sectorData = context.results.sector_rotation_analyzer?.data || {};
          const flowsData = context.results.flows_supply_analyzer?.data || {};
          const volatilityData = liquidityStressData.volatilityRegime || {};
          
          // Build comprehensive executiveData for all 5 PM-Grade charts
          const executiveData = {
            // Chart 1: Market Regime Gauge
            regime: {
              score: regimeData.score || 50,
              label: regimeData.regime || 'TRANSITIONAL',
            },
            marketHealth: {
              score: liquidityStressData.marketHealth?.score || 
                     liquidityStressData.healthScore || 
                     50,
            },
            
            // Chart 2: Volatility Compression
            volatility: {
              current: volatilityData.realizedVol14d?.btc || volatilityData.score || 45,
              avg30d: volatilityData.avgVol30d || 55,
              history: volatilityData.history || [],
              compression: volatilityData.volSignals?.compression?.detected || false,
            },
            
            // Chart 3: Stablecoin Supply
            stablecoins: {
              totalSupply: flowsData.stablecoins?.totalSupply || marketData.stablecoins?.totalSupply,
              change14d: flowsData.stablecoins?.change14d?.percent || 0,
            },
            
            // Chart 4: ETF Flows
            etfFlows: {
              btcFlows: flowsData.etfFlows?.btc?.daily || [],
              ethFlows: flowsData.etfFlows?.eth?.daily || [],
              btcTotal14d: flowsData.etfFlows?.btc?.total14d || 0,
              ethTotal14d: flowsData.etfFlows?.eth?.total14d || 0,
            },
            
            // Chart 5: Sector Heatmap
            sectors: (sectorData.sectors || sectorData.sectorPerformance || []).map(s => ({
              name: s.sector || s.name,
              return14d: s.return14d || s.performance || 0,
            })),
          };
          
          charts = await generateAllCharts(marketData, derivativesData, executiveData);
          workflow.charts = charts;
          
          // Count successful charts (including pmGrade charts)
          const signatureCount = Object.values(charts.signature || {}).filter(c => c?.success).length;
          const contextualCount = Object.values(charts.contextual || {}).filter(c => c?.success).length;
          const keySignalCount = Object.values(charts.keySignal || {}).filter(c => c?.success).length;
          const pmGradeCount = Object.values(charts.pmGrade || {}).filter(c => c?.success).length;
          
          console.log(`[CryptoOrchestrator] ✅ Charts: PM-Grade ${pmGradeCount}/5, Signature ${signatureCount}/3, KeySignal ${keySignalCount}/4`);
          
        } catch (chartError) {
          console.error(`[CryptoOrchestrator] ❌ Chart generation failed:`, chartError.message);
          workflow.errors.push({
            agent: 'chart_generator',
            error: chartError.message,
          });
        }

        // Progress callback for charts
        if (options.onProgress) {
          options.onProgress({
            reportId,
            phase: ORCHESTRATOR_PHASES.CHART_GENERATION,
            agent: 'chart_generator',
            agentName: 'Chart Generator',
            progress: 95,
            completedAgents: [...workflow.completedAgents, 'chart_generator'],
            elapsedSeconds: workflow.elapsedSeconds,
          });
        }
      }

      // ============================================
      // COMPILE FINAL REPORT
      // ============================================
      
      console.log(`\n[CryptoOrchestrator] ▶ Compiling final report...`);
      
      const report = this.compileReport(context, charts);
      
      // Generate markdown
const markdownContent = await generateMarkdownReportAsync(report, charts);
      report.markdownContent = markdownContent;
      
      // Generate PDF with charts
      let pdfBuffer = null;
      try {
        console.log(`[CryptoOrchestrator] ▶ Generating PDF with charts...`);
        pdfBuffer = await generateCryptoReportPDF(markdownContent, {
          reportDate: reportDate,
          charts: charts,
        });
        report.pdfBuffer = pdfBuffer;
        console.log(`[CryptoOrchestrator] ✅ PDF generated: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);
      } catch (pdfError) {
        console.error(`[CryptoOrchestrator] ❌ PDF generation failed:`, pdfError.message);
        workflow.errors.push({
          agent: 'pdf_generator',
          error: pdfError.message,
        });
      }
      
      // Save to database
      let savedReport = report;
      if (this.options.saveToDatabase && this.supabase) {
        savedReport = await this.saveReport(report, markdownContent);
      }
      
      // Complete workflow
      workflowManager.complete(reportId, savedReport);
      
      const totalTime = workflow.elapsedSeconds;
      const successRate = ((workflow.completedAgents.length - workflow.errors.length) / workflow.completedAgents.length * 100).toFixed(0);
      
      console.log(`\n[CryptoOrchestrator] ========================================`);
      console.log(`[CryptoOrchestrator] ✅ REPORT COMPLETED`);
      console.log(`[CryptoOrchestrator] Report ID: ${reportId}`);
      console.log(`[CryptoOrchestrator] Duration: ${totalTime}s`);
      console.log(`[CryptoOrchestrator] Agents: ${workflow.completedAgents.length}/${this.totalAgents}`);
      console.log(`[CryptoOrchestrator] Success Rate: ${successRate}%`);
      console.log(`[CryptoOrchestrator] Tokens Used: ${workflow.tokensUsed}`);
      console.log(`[CryptoOrchestrator] Errors: ${workflow.errors.length}`);
      console.log(`[CryptoOrchestrator] ========================================`);
      
      return {
        success: true,
        reportId,
        report: savedReport,
        stats: {
          duration: totalTime,
          agentsCompleted: workflow.completedAgents.length,
          totalAgents: this.totalAgents,
          successRate: parseFloat(successRate),
          tokensUsed: workflow.tokensUsed,
          errors: workflow.errors.length,
          chartsGenerated: charts ? 
            Object.values(charts.signature || {}).filter(c => c?.success).length +
            Object.values(charts.contextual || {}).filter(c => c?.success).length +
            Object.values(charts.keySignal || {}).filter(c => c?.success).length : 0,
          pdfGenerated: pdfBuffer ? true : false,
        },
      };

    } catch (error) {
      console.error(`\n[CryptoOrchestrator] ❌ GENERATION FAILED:`, error);
      workflowManager.fail(reportId, error.message);
      
      return {
        success: false,
        reportId,
        error: error.message,
        stats: {
          duration: workflow.elapsedSeconds,
          agentsCompleted: workflow.completedAgents.length,
          errors: workflow.errors.length + 1,
        },
      };
    }
  }

  // ============================================
  // AGENT EXECUTION
  // ============================================

  /**
   * Execute a single agent with retry logic
   */
  async executeAgent(agent, context) {
    const executor = AGENT_EXECUTORS[agent.id];
    
    if (!executor) {
      return {
        success: false,
        error: `No executor found for agent: ${agent.id}`,
        data: null,
      };
    }

    // Retry logic
    let lastError = null;
    
    for (let attempt = 1; attempt <= this.options.retryAttempts; attempt++) {
      try {
        const result = await executor(context);
        
        if (result.success) {
          return result;
        }
        
        lastError = result.error;
        
        if (attempt < this.options.retryAttempts) {
          const delay = this.options.retryDelayMs * attempt;
          console.log(`[CryptoOrchestrator] Retry ${attempt + 1}/${this.options.retryAttempts} for ${agent.id} in ${delay}ms...`);
          await this.delay(delay);
        }
      } catch (error) {
        lastError = error.message;
        
        if (attempt < this.options.retryAttempts) {
          const delay = this.options.retryDelayMs * attempt;
          console.log(`[CryptoOrchestrator] Retry ${attempt + 1}/${this.options.retryAttempts} for ${agent.id} after error in ${delay}ms...`);
          await this.delay(delay);
        }
      }
    }

    return {
      success: false,
      error: lastError || 'Unknown error',
      data: null,
    };
  }

  /**
   * Check if agent dependencies are met
   */
  checkDependencies(agent, results) {
    if (!agent.dependencies || agent.dependencies.length === 0) {
      return { success: true };
    }

    const missing = [];
    const failed = [];
    
    for (const dep of agent.dependencies) {
      if (!results[dep]) {
        missing.push(dep);
      } else if (!results[dep].success && !results[dep].skipped) {
        failed.push(dep);
      }
    }

    if (missing.length > 0) {
      return {
        success: false,
        reason: `Missing dependencies: ${missing.join(', ')}`,
        missing,
      };
    }

    // Allow execution if dependencies exist but failed (agent should handle gracefully)
    if (failed.length > 0) {
      console.warn(`[CryptoOrchestrator] ⚠️ ${agent.id} has failed dependencies: ${failed.join(', ')}`);
    }

    return { success: true };
  }

  // ============================================
  // REPORT COMPILATION (13-Section Structure)
  // ============================================

  /**
   * Compile final report from all agent results
   * Maps agent outputs to the 13-section report structure
   */
  compileReport(context, charts = null) {
    const { results, reportId, reportDate, windowStart, windowEnd, windowDays } = context;
    
    // ========================================
    // EXTRACT AGENT RESULTS
    // ========================================
    
    // Data Acquisition agents
    const marketData = results.market_data_fetcher?.data || {};
    const onchainData = results.onchain_data_fetcher?.data || {};
    const derivativesRaw = results.derivatives_data_fetcher?.data || {};
    
    // Executive Brief agents
    const regime = results.regime_detector?.data || {};
    const flipTriggers = results.regime_flip_analyzer?.data || {};
    const top5Takeaways = results.top5_takeaways_generator?.data || {};
    
    // Price & Structure agents
    const priceStructure = results.price_structure_analyzer?.data || {};
    const dominance = results.dominance_analyzer?.data || {};
    
    // Liquidity & Risk agents
    const volatility = results.volatility_regime_analyzer?.data || {};
    const liquidityStress = results.liquidity_stress_analyzer?.data || {};
    
    // Derivatives agents
    const funding = results.funding_analyzer?.data || {};
    const oi = results.oi_analyzer?.data || {};
    const liquidations = results.liquidation_mapper?.data || {};
    
    // Flows & Supply agents
    const flows = results.flows_analyzer?.data || {};
    const unlocks = results.token_unlocks_analyzer?.data || {};
    
    // Sector Rotation agents
    const sectorPerformance = results.sector_performance_analyzer?.data || {};
    const rotationSignal = results.rotation_signal_analyzer?.data || {};
    
    // Narratives agent
    const narratives = results.narratives_analyzer?.data || {};
    
    // Catalyst Calendar agent
    const catalysts = results.catalyst_calendar_generator?.data || {};
    
    // Trade Playbook agents
    const tradeIdeas = results.trade_idea_generator?.data || {};
    const riskPsychology = results.risk_psychology_advisor?.data || {};
    
    // Watchlist agent
    const watchlist = results.watchlist_generator?.data || {};
    
    // Quality Assurance agents
    const coherence = results.coherence_checker?.data || {};
    const executiveSummary = results.executive_summary_writer?.data || {};
    const dataAppendix = results.data_appendix_generator?.data || {};
    
    // Count successful charts
    const chartsGenerated = charts ? 
      Object.values(charts.signature || {}).filter(c => c?.success).length + 
      Object.values(charts.contextual || {}).filter(c => c?.success).length : 0;

    // ========================================
    // BUILD 13-SECTION REPORT
    // ========================================
    
    const report = {
      // Metadata
      id: reportId,
      reportDate,
      windowStart,
      windowEnd,
      windowDays,
      generatedAt: new Date().toISOString(),
      version: '6.0',
      format: 'bi-weekly-institutional',
      
      // ========================================
      // SECTION 0: COVER
      // ========================================
      cover: {
        title: 'Bi-Weekly Crypto Intelligence Report',
        subtitle: 'Institutional-Grade Market Analysis',
        date: reportDate,
        window: `${windowStart} → ${windowEnd} (${windowDays} days)`,
        promise: executiveSummary.oneLinePromise || 'Data-first institutional-grade crypto analysis',
        method: 'Data-first, no hype. What we can\'t measure, we mark clearly.',
        regimeQuickView: regime.regime || 'TRANSITIONAL',
      },
      
      // ========================================
      // SECTION 1: EXECUTIVE DECISION BRIEF
      // ========================================
      executiveBrief: {
        // One-line call
        oneLineCall: executiveSummary.bigCall || regime.summary || '',
        
        // Market Regime
        regime: {
          label: regime.regime || 'TRANSITIONAL',
          score: regime.score || 50,
          confidence: regime.confidence || 'Medium',
          summary: regime.interpretation || '',
        },
        
        // What would flip the regime
        whatFlipsTheRegime: {
          toRiskOn: flipTriggers.toRiskOn || {},
          toRiskOff: flipTriggers.toRiskOff || {},
        },
        
        // Top 5 Takeaways
        top5Takeaways: top5Takeaways.takeaways || [],
        
        // One chart that matters
        oneChartThatMatters: executiveSummary.oneChartThatMatters || {
          chart: 'BTC Price vs Funding Rate',
          why: 'Shows leverage alignment with price direction',
        },
        
        // Closing
        closingStatement: {
          synthesis: executiveSummary.synthesis || '',
          actionRecommendation: executiveSummary.actionRecommendation || '',
        },
        
        soWhat: executiveSummary.soWhat || '',
      },
      
      // ========================================
      // SECTION 2: PRICE & STRUCTURE SNAPSHOT
      // ========================================
      priceStructure: {
        btc: priceStructure.btc || {},
        eth: priceStructure.eth || {},
        dominance: dominance || {},
        altIndex: priceStructure.altIndex || {},
        soWhat: priceStructure.soWhat || '',
      },
      
      // ========================================
      // SECTION 3: LIQUIDITY & RISK DASHBOARD
      // ========================================
      liquidityRisk: {
        volatilityRegime: volatility || {},
        stablecoinPulse: liquidityStress.stablecoinPulse || onchainData.stablecoins || {},
        liquidityStressSignals: {
          fundingSpikes: liquidityStress.fundingSpikes || {},
          liquidationClusters: liquidityStress.liquidationClusters || {},
          oiPriceDivergence: liquidityStress.oiPriceDivergence || {},
        },
        marketHealth: liquidityStress.marketHealth || {},
        soWhat: liquidityStress.soWhat || volatility.soWhat || '',
      },
      
      // ========================================
      // SECTION 4: DERIVATIVES & POSITIONING
      // ========================================
      derivatives: {
        funding: funding || {},
        openInterest: oi || {},
        liquidations: liquidations || {},
        oiPriceDivergence: oi.oiPriceDivergence || {},
        interpretationTable: funding.interpretationTable || oi.interpretationTable || [],
        soWhat: funding.soWhat || oi.soWhat || '',
      },
      
      // ========================================
      // SECTION 5: FLOWS & SUPPLY PRESSURE
      // ========================================
      flowsSupply: {
        exchangeReserves: flows.exchangeReserves || {
          available: false,
          note: DATA_TAGS?.ON_CHAIN_LIMITATION || '[ON-CHAIN LIMITATION]',
        },
        etfFlows: flows.etfFlows || {},
        stablecoinDeployment: flows.stablecoinDeployment || {},
        supplyPressure: flows.supplyPressure || {},
        soWhat: flows.soWhat || '',
      },
      
      // Token Unlocks (separate for report-generator)
      tokenUnlocks: {
        unlocks14d: unlocks.unlocks14d || unlocks.calendar || [],
        majorUnlocks: unlocks.majorUnlocks || [],
        totalSupplyPressure: unlocks.totalSupplyPressure || {},
        soWhat: unlocks.soWhat || '',
      },
      
      // ========================================
      // SECTION 6: SECTOR ROTATION MAP
      // ========================================
      sectorRotation: {
        sectorTable: sectorPerformance.sectorTable || sectorPerformance.sectors || [],
        leaderboard: {
          top3Sectors: rotationSignal.top3Sectors || sectorPerformance.top3 || [],
          bottom3Sectors: rotationSignal.bottom3Sectors || sectorPerformance.bottom3 || [],
        },
        rotationDetected: rotationSignal.rotationDetected || false,
        rotationDetails: rotationSignal.rotationDetails || {},
        soWhat: rotationSignal.soWhat || sectorPerformance.soWhat || '',
      },
      
      // ========================================
      // SECTION 7: NARRATIVES THAT MOVED PRICE
      // ========================================
      narratives: {
        narratives: narratives.narratives || [],
        noiseFiltered: narratives.noiseFiltered || [],
        narrativeHeatmap: narratives.heatmap || {},
        soWhat: narratives.soWhat || '',
      },
      
      // ========================================
      // SECTION 8: CATALYST CALENDAR
      // ========================================
      catalystCalendar: {
        calendar: catalysts.calendar || [],
        macroCalendar: catalysts.macroCalendar || catalysts.macro || [],
        weekSummary: catalysts.weekSummary || {},
        quietPeriods: catalysts.quietPeriods || {},
        riskyPeriods: catalysts.riskyPeriods || {},
        soWhat: catalysts.soWhat || '',
      },
      
      // ========================================
      // SECTION 9: TRADE SETUP PLAYBOOK
      // ========================================
      tradePlaybook: {
        tradeIdeas: tradeIdeas.tradeIdeas || tradeIdeas.ideas || [],
        noTradeScenario: tradeIdeas.noTradeScenario || {},
        portfolioView: tradeIdeas.portfolioView || {},
        soWhat: tradeIdeas.soWhat || '',
      },
      
      // ========================================
      // SECTION 10: RISK MANAGEMENT & PSYCHOLOGY
      // ========================================
      riskPsychology: {
        top5Mistakes: riskPsychology.top5Mistakes || riskPsychology.mistakes || [],
        positionSizing: riskPsychology.positionSizing || {},
        preEntryChecklist: riskPsychology.preEntryChecklist || riskPsychology.checklist || [],
        psychologyNote: riskPsychology.psychologyNote || {},
        soWhat: riskPsychology.soWhat || '',
      },
      
      // ========================================
      // SECTION 11: WATCHLIST
      // ========================================
      watchlist: {
        watchlist: {
          momentumLeaders: watchlist.momentumLeaders || [],
          meanReversionCandidates: watchlist.meanReversionCandidates || [],
          catalystDriven: watchlist.catalystDriven || [],
        },
        summary: watchlist.summary || {},
        topPicks: watchlist.topPicks || {},
        avoidList: watchlist.avoidList || [],
        soWhat: watchlist.soWhat || '',
      },
      
      // ========================================
      // SECTION 12: DATA APPENDIX
      // ========================================
      dataAppendix: {
        sources: dataAppendix.sources || [
          { name: 'CoinGecko', type: 'Free', dataProvided: ['Price', 'Market Cap', 'Volume'], limitations: 'Rate limited (30 req/min)' },
          { name: 'Binance Futures', type: 'Free', dataProvided: ['Funding', 'OI', 'Liquidations'], limitations: 'Public endpoints only' },
          { name: 'DeFiLlama', type: 'Free', dataProvided: ['TVL', 'Stablecoins'], limitations: 'None' },
          { name: 'Alternative.me', type: 'Free', dataProvided: ['Fear & Greed'], limitations: 'Daily updates only' },
        ],
        limitations: dataAppendix.limitations || [
          { category: 'On-Chain', limitation: 'No Glassnode/CryptoQuant', mitigation: 'Using proxies where possible' },
          { category: 'Options', limitation: 'No Deribit data', mitigation: 'Focus on funding/OI instead' },
          { category: 'ETF Flows', limitation: 'News sources only', mitigation: 'May be delayed 1-2 days' },
        ],
        definitions: dataAppendix.definitions || {},
        methodology: dataAppendix.methodology || {},
        metadata: {
          generatedAt: new Date().toISOString(),
          version: '6.0',
          agentCount: this.totalAgents,
          qualityScore: coherence.qualityScore || 0,
          qualityGrade: coherence.reportGrade || 'N/A',
        },
      },
      
      // ========================================
      // SECTION 13: LEGAL DISCLAIMER
      // ========================================
      disclaimer: {
        isFinancialAdvice: false,
        isEducationalOnly: true,
        riskWarning: 'Cryptocurrency trading involves extremely high risk. You may lose all invested capital.',
        dataDisclaimer: 'Data from third-party sources. No guarantee of accuracy.',
      },
      
      // ========================================
      // QUALITY ASSURANCE
      // ========================================
      qualityAssurance: {
        score: coherence.qualityScore || 0,
        grade: coherence.reportGrade || 'N/A',
        coherenceCheck: {
          conflictingSignals: coherence.conflictingSignals || [],
          alignedSignals: coherence.alignedSignals || [],
          dataGaps: coherence.dataGaps || [],
        },
      },
      
      // Charts
      charts: charts,
      
      // Meta
      meta: {
        agentCount: this.totalAgents,
        sectionsCount: 13,
        completedAgents: Object.keys(results).length,
        chartsGenerated,
        tokensUsed: context.tokensUsed || 0,
        errors: context.errors || [],
        warnings: context.warnings || [],
      },
    };

    return report;
  }

  // ============================================
  // DATABASE OPERATIONS
  // ============================================

  /**
   * Save report to database
   */
  async saveReport(report, markdownContent) {
    if (!this.supabase) {
      console.warn('[CryptoOrchestrator] No database configured, returning in-memory report');
      return report;
    }

    try {
      const { data, error } = await this.supabase
        .from('crypto_reports')
        .insert({
          id: report.id,
          report_date: report.reportDate,
          window_start: report.windowStart,
          window_end: report.windowEnd,
          window_days: report.windowDays,
          market_regime: report.executiveBrief?.regime?.label,
          regime_score: report.executiveBrief?.regime?.score,
          executive_summary: report.executiveBrief,
          sections: {
            cover: report.cover,
            executiveBrief: report.executiveBrief,
            priceStructure: report.priceStructure,
            liquidityRisk: report.liquidityRisk,
            derivatives: report.derivatives,
            flowsSupply: report.flowsSupply,
            tokenUnlocks: report.tokenUnlocks,
            sectorRotation: report.sectorRotation,
            narratives: report.narratives,
            catalystCalendar: report.catalystCalendar,
            tradePlaybook: report.tradePlaybook,
            riskPsychology: report.riskPsychology,
            watchlist: report.watchlist,
            dataAppendix: report.dataAppendix,
          },
          qa_score: report.qualityAssurance?.score,
          qa_grade: report.qualityAssurance?.grade,
          markdown_content: markdownContent,
          pdf_content: report.pdfBuffer ? report.pdfBuffer.toString('base64') : null,
          charts_generated: report.meta?.chartsGenerated || 0,
          tokens_used: report.meta?.tokensUsed || 0,
          agents_completed: report.meta?.completedAgents || 0,
          created_at: report.generatedAt,
        })
        .select()
        .single();

      if (error) {
        console.error('[CryptoOrchestrator] Database save error:', error);
        throw error;
      }

      console.log(`[CryptoOrchestrator] ✅ Report saved to database: ${report.id}`);
      return { ...report, dbRecord: data };
      
    } catch (error) {
      console.error('[CryptoOrchestrator] Failed to save report:', error);
      // Return report anyway (in-memory)
      return report;
    }
  }

  // ============================================
  // STATUS & CONTROL
  // ============================================

  /**
   * Get generation status
   */
  getStatus(reportId) {
    return workflowManager.get(reportId);
  }

  /**
   * Check if can generate (no active workflows)
   */
  async canGenerate() {
    const activeWorkflows = workflowManager.getActive();
    
    if (activeWorkflows.length > 0) {
      return {
        canGenerate: false,
        reason: 'Another report is currently being generated',
        activeWorkflow: activeWorkflows[0],
      };
    }

    return { canGenerate: true };
  }

  /**
   * Cancel generation
   */
  cancel(reportId) {
    const workflow = workflowManager.get(reportId);
    if (workflow && workflow.status === 'running') {
      workflowManager.fail(reportId, 'Cancelled by user');
      return { success: true };
    }
    return { success: false, error: 'No active generation to cancel' };
  }

  /**
   * Get all workflows
   */
  getAllWorkflows() {
    return workflowManager.getAll();
  }

  // ============================================
  // UTILITIES
  // ============================================

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============================================
// EXPORTS
// ============================================

export {
  CryptoAnalysisOrchestrator,
  WorkflowManager,
  workflowManager,
  ORCHESTRATOR_PHASES,
};

export default CryptoAnalysisOrchestrator;