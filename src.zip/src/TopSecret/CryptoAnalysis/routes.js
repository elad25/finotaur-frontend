// =====================================================
// CRYPTO ANALYSIS API ROUTES
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/routes.js
//
// Express routes for crypto analysis generation and retrieval
// Protected with admin authentication
// =====================================================

import express from 'express';
const router = express.Router();
import { CryptoAnalysisOrchestrator, workflowManager } from './orchestrator.js';
import { generateMarkdownReport } from './report-generator.js';

// ============================================
// MIDDLEWARE
// ============================================

// Admin authentication middleware
const requireAdmin = async (req, res, next) => {
  try {
    // Check if user is authenticated
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Check admin status
    const { data: profile, error } = await req.supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', req.user.id)
      .single();

    if (error || !profile?.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    next();
  } catch (error) {
    res.status(500).json({ error: 'Auth check failed' });
  }
};

// Create orchestrator instance
const getOrchestrator = (req) => {
  return new CryptoAnalysisOrchestrator(req.supabase, {
    openaiApiKey: process.env.OPENAI_API_KEY,
    coingeckoApiKey: process.env.COINGECKO_API_KEY,
    glassnodeApiKey: process.env.GLASSNODE_API_KEY,
    coinglassApiKey: process.env.COINGLASS_API_KEY,
  });
};

// ============================================
// ROUTES
// ============================================

/**
 * POST /api/crypto/generate
 * Start a new crypto analysis report generation
 */
router.post('/generate', requireAdmin, async (req, res) => {
  try {
    const orchestrator = getOrchestrator(req);
    
    // Check if we can generate
    const canGenerate = await orchestrator.canGenerate();
    if (!canGenerate.canGenerate) {
      return res.status(429).json({
        success: false,
        error: canGenerate.reason,
      });
    }

    // Start generation (async - don't await)
    const reportDate = req.body.reportDate || new Date().toISOString().split('T')[0];
    
    const generatePromise = orchestrator.generate({
      reportDate,
      onProgress: (progress) => {
        // Progress is tracked via workflow manager
        console.log(`[Crypto] ${progress.agentName}: ${progress.progress}%`);
      },
    });

    // Get the report ID from workflow
    const activeWorkflows = workflowManager.getActive();
    const currentWorkflow = activeWorkflows[0];

    if (!currentWorkflow) {
      return res.status(500).json({
        success: false,
        error: 'Failed to start generation',
      });
    }

    res.json({
      success: true,
      reportId: currentWorkflow.reportId,
      message: 'Crypto analysis generation started',
      status: 'running',
    });

  } catch (error) {
    console.error('[Crypto Routes] Generate error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/crypto/progress/:reportId
 * Get generation progress for a report
 */
router.get('/progress/:reportId', requireAdmin, async (req, res) => {
  try {
    const { reportId } = req.params;
    const workflow = workflowManager.get(reportId);

    if (!workflow) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }

    res.json({
      success: true,
      reportId,
      status: workflow.status,
      progress: workflow.progress,
      currentPhase: workflow.currentPhase,
      currentAgent: workflow.currentAgent,
      completedAgents: workflow.completedAgents,
      elapsedSeconds: workflow.elapsedSeconds,
      errors: workflow.errors,
    });

  } catch (error) {
    console.error('[Crypto Routes] Progress error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/crypto/cancel/:reportId
 * Cancel an in-progress generation
 */
router.post('/cancel/:reportId', requireAdmin, async (req, res) => {
  try {
    const { reportId } = req.params;
    const orchestrator = getOrchestrator(req);
    
    const result = orchestrator.cancel(reportId);

    res.json({
      success: result.success,
      error: result.error,
    });

  } catch (error) {
    console.error('[Crypto Routes] Cancel error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/crypto/reports
 * Get list of generated reports
 */
router.get('/reports', requireAdmin, async (req, res) => {
  try {
    const { limit = 20, offset = 0 } = req.query;

    const { data: reports, error, count } = await req.supabase
      .from('crypto_reports')
      .select('id, report_date, market_regime, qa_score, qa_grade, created_at', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    res.json({
      success: true,
      reports,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

  } catch (error) {
    console.error('[Crypto Routes] List error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/crypto/reports/:reportId
 * Get a specific report
 */
router.get('/reports/:reportId', requireAdmin, async (req, res) => {
  try {
    const { reportId } = req.params;
    const { format = 'json' } = req.query;

    const { data: report, error } = await req.supabase
      .from('crypto_reports')
      .select('*')
      .eq('id', reportId)
      .single();

    if (error) throw error;
    if (!report) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }

    // Return based on format
    if (format === 'markdown') {
      res.set('Content-Type', 'text/markdown');
      return res.send(report.markdown_content);
    }

    if (format === 'pdf') {
      // Return PDF if available
      if (report.pdf_content) {
        const pdfBuffer = Buffer.from(report.pdf_content, 'base64');
        res.set('Content-Type', 'application/pdf');
        res.set('Content-Disposition', `attachment; filename="Crypto_Report_${report.report_date}.pdf"`);
        return res.send(pdfBuffer);
      } else {
        return res.status(404).json({
          success: false,
          error: 'PDF not available for this report',
        });
      }
    }

    if (format === 'html') {
      res.set('Content-Type', 'text/html');
      // Return stored HTML or wrap markdown in basic HTML
      if (report.html_content) {
        return res.send(report.html_content);
      }
      // Basic HTML wrapper for markdown content
      const basicHtml = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Crypto Report</title>
<style>body{font-family:system-ui;max-width:900px;margin:0 auto;padding:20px;}</style>
</head><body><pre>${report.markdown_content || 'No content available'}</pre></body></html>`;
      return res.send(basicHtml);
    }

    res.json({
      success: true,
      report,
    });

  } catch (error) {
    console.error('[Crypto Routes] Get report error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/crypto/reports/latest
 * Get the most recent report
 */
router.get('/latest', requireAdmin, async (req, res) => {
  try {
    const { data: report, error } = await req.supabase
      .from('crypto_reports')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error && error.code !== 'PGRST116') throw error;

    if (!report) {
      return res.json({
        success: true,
        report: null,
        message: 'No reports available',
      });
    }

    res.json({
      success: true,
      report,
    });

  } catch (error) {
    console.error('[Crypto Routes] Latest error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/crypto/reports/:reportId
 * Delete a report
 */
router.delete('/reports/:reportId', requireAdmin, async (req, res) => {
  try {
    const { reportId } = req.params;

    const { error } = await req.supabase
      .from('crypto_reports')
      .delete()
      .eq('id', reportId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Report deleted',
    });

  } catch (error) {
    console.error('[Crypto Routes] Delete error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/crypto/status
 * Get system status (active workflows, last report, etc.)
 */
router.get('/status', requireAdmin, async (req, res) => {
  try {
    // Get active workflows
    const activeWorkflows = workflowManager.getActive();

    // Get last report
    const { data: lastReport } = await req.supabase
      .from('crypto_reports')
      .select('id, report_date, created_at')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    // Get report count
    const { count } = await req.supabase
      .from('crypto_reports')
      .select('id', { count: 'exact', head: true });

    res.json({
      success: true,
      status: {
        isGenerating: activeWorkflows.length > 0,
        activeWorkflow: activeWorkflows[0] || null,
        lastReport: lastReport || null,
        totalReports: count || 0,
        systemReady: true,
      },
    });

  } catch (error) {
    console.error('[Crypto Routes] Status error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// EXPORTS
// ============================================

export default router;