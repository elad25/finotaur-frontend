// =====================================================
// CRYPTO ANALYSIS SCHEDULER v2.0
// =====================================================
// Location: src/TopSecret/CryptoAnalysis/scheduler.js
//
// Manages automated BI-WEEKLY crypto report generation
// Runs on the 10th and 25th of each month at 18:00 UTC
// Publishes to Update Center for TOP SECRET subscribers
// =====================================================

import cron from 'node-cron';
import { v4 as uuidv4 } from 'uuid';

// ============================================
// CONFIGURATION
// ============================================

const SCHEDULE_CONFIG = {
  // Run on 10th and 25th of each month at 18:00 UTC
  cronExpression: '0 18 10,25 * *',
  
  // Alternative schedules for testing:
  // cronExpression: '0 */6 * * *',     // Every 6 hours
  // cronExpression: '*/5 * * * *',     // Every 5 minutes (testing)
  // cronExpression: '0 18 * * 0',      // Every Sunday at 18:00 UTC
  
  // Timezone
  timezone: 'UTC',
  
  // Retry settings
  maxRetries: 3,
  retryDelayMs: 5 * 60 * 1000, // 5 minutes
  
  // Report settings
  reportType: 'crypto_analysis',
  targetGroup: 'top_secret', // Only TOP SECRET subscribers
};

// ============================================
// SCHEDULER CLASS
// ============================================

class CryptoReportScheduler {
  constructor(supabase, options = {}) {
    this.supabase = supabase;
    this.options = {
      openaiApiKey: options.openaiApiKey || process.env.OPENAI_API_KEY,
      coingeckoApiKey: options.coingeckoApiKey || process.env.COINGECKO_API_KEY,
      apiBaseUrl: options.apiBaseUrl || process.env.API_BASE_URL || 'http://localhost:3000',
      ...options,
    };
    
    this.cronJob = null;
    this.isRunning = false;
    this.lastRun = null;
    this.lastError = null;
    this.lastReportId = null;
  }

  // ============================================
  // SCHEDULING METHODS
  // ============================================

  /**
   * Start the scheduled job
   */
  start() {
    if (this.cronJob) {
      console.log('[CryptoScheduler] Already running');
      return;
    }

    console.log(`[CryptoScheduler] 🚀 Starting with schedule: ${SCHEDULE_CONFIG.cronExpression}`);
    console.log(`[CryptoScheduler] 📅 Will run on the 10th and 25th of each month at 18:00 UTC`);

    this.cronJob = cron.schedule(
      SCHEDULE_CONFIG.cronExpression,
      async () => {
        console.log(`[CryptoScheduler] ⏰ Scheduled run triggered at ${new Date().toISOString()}`);
        await this.runScheduledGeneration();
      },
      {
        timezone: SCHEDULE_CONFIG.timezone,
        scheduled: true,
      }
    );

    console.log('[CryptoScheduler] ✅ Scheduler started successfully');
    console.log(`[CryptoScheduler] 📆 Next run: ${this.getNextRunTime()}`);
  }

  /**
   * Stop the scheduled job
   */
  stop() {
    if (this.cronJob) {
      this.cronJob.stop();
      this.cronJob = null;
      console.log('[CryptoScheduler] 🛑 Scheduler stopped');
    }
  }

  /**
   * Check if scheduler is active
   */
  isActive() {
    return this.cronJob !== null;
  }

  /**
   * Get scheduler status
   */
  getStatus() {
    return {
      isActive: this.isActive(),
      isGenerating: this.isRunning,
      schedule: SCHEDULE_CONFIG.cronExpression,
      scheduleDescription: '10th and 25th of each month at 18:00 UTC',
      timezone: SCHEDULE_CONFIG.timezone,
      lastRun: this.lastRun,
      lastError: this.lastError,
      lastReportId: this.lastReportId,
      nextRun: this.getNextRunTime(),
      targetGroup: SCHEDULE_CONFIG.targetGroup,
    };
  }

  /**
   * Calculate next run time (10th or 25th)
   */
  getNextRunTime() {
    if (!this.cronJob) return null;
    
    try {
      const now = new Date();
      const currentDay = now.getUTCDate();
      const currentMonth = now.getUTCMonth();
      const currentYear = now.getUTCFullYear();
      const currentHour = now.getUTCHours();
      
      let nextDate;
      
      if (currentDay < 10 || (currentDay === 10 && currentHour < 18)) {
        // Next run is 10th of current month
        nextDate = new Date(Date.UTC(currentYear, currentMonth, 10, 18, 0, 0));
      } else if (currentDay < 25 || (currentDay === 25 && currentHour < 18)) {
        // Next run is 25th of current month
        nextDate = new Date(Date.UTC(currentYear, currentMonth, 25, 18, 0, 0));
      } else {
        // Next run is 10th of next month
        nextDate = new Date(Date.UTC(currentYear, currentMonth + 1, 10, 18, 0, 0));
      }
      
      return nextDate.toISOString();
    } catch (error) {
      console.error('[CryptoScheduler] Error calculating next run:', error);
      return null;
    }
  }

  // ============================================
  // GENERATION METHODS
  // ============================================

  /**
   * Run scheduled generation with retry logic
   */
  async runScheduledGeneration() {
    if (this.isRunning) {
      console.log('[CryptoScheduler] ⚠️ Generation already in progress, skipping');
      return { success: false, reason: 'already_running' };
    }

    this.isRunning = true;
    this.lastRun = new Date().toISOString();
    this.lastError = null;

    console.log('[CryptoScheduler] 🎬 Starting scheduled generation');
    console.log(`[CryptoScheduler] 📅 Report date: ${new Date().toISOString().split('T')[0]}`);

    let attempt = 0;
    let success = false;
    let report = null;

    while (attempt < SCHEDULE_CONFIG.maxRetries && !success) {
      attempt++;
      console.log(`[CryptoScheduler] 🔄 Attempt ${attempt}/${SCHEDULE_CONFIG.maxRetries}`);

      try {
        const result = await this.generateReport();
        
        if (result.success) {
          success = true;
          report = result.report;
          this.lastReportId = result.reportId;
          console.log(`[CryptoScheduler] ✅ Report generated successfully: ${result.reportId}`);
          
          // Publish to Update Center for TOP SECRET subscribers
          await this.publishToUpdateCenter(result.report, result.reportId);
          
        } else {
          throw new Error(result.error || 'Generation failed');
        }

      } catch (error) {
        console.error(`[CryptoScheduler] ❌ Attempt ${attempt} failed:`, error.message);
        this.lastError = error.message;

        if (attempt < SCHEDULE_CONFIG.maxRetries) {
          console.log(`[CryptoScheduler] ⏳ Retrying in ${SCHEDULE_CONFIG.retryDelayMs / 1000}s...`);
          await this.delay(SCHEDULE_CONFIG.retryDelayMs);
        }
      }
    }

    if (!success) {
      console.error('[CryptoScheduler] 💥 All retry attempts failed');
      await this.notifyFailure();
    }

    this.isRunning = false;
    
    return { 
      success, 
      reportId: this.lastReportId,
      report,
      attempts: attempt,
    };
  }

  /**
   * Generate a crypto report via the API
   */
  async generateReport() {
    const reportDate = new Date().toISOString().split('T')[0];
    
    console.log(`[CryptoScheduler] 📊 Calling generate API...`);
    
    try {
      // Call the internal generate endpoint
      const response = await fetch(`${this.options.apiBaseUrl}/api/crypto/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          isScheduledRun: true,
          reportDate,
        }),
      });

      if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.success || !data.reportId) {
        throw new Error(data.error || 'No reportId returned');
      }

      console.log(`[CryptoScheduler] 📝 Report ID: ${data.reportId}`);
      
      // Wait for report to complete (poll progress)
      const completedReport = await this.waitForCompletion(data.reportId);
      
      return {
        success: true,
        reportId: data.reportId,
        report: completedReport,
      };
      
    } catch (error) {
      console.error('[CryptoScheduler] Generate API error:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Wait for report generation to complete
   */
  async waitForCompletion(reportId, maxWaitMs = 15 * 60 * 1000) {
    const startTime = Date.now();
    const pollInterval = 5000; // 5 seconds
    
    console.log(`[CryptoScheduler] ⏳ Waiting for report ${reportId} to complete...`);
    
    while (Date.now() - startTime < maxWaitMs) {
      try {
        const response = await fetch(`${this.options.apiBaseUrl}/api/crypto/progress/${reportId}`);
        const data = await response.json();
        
        if (!data.success) {
          throw new Error(data.error || 'Progress check failed');
        }
        
        const progress = data.data;
        
        console.log(`[CryptoScheduler] 📈 Progress: ${progress.progress}% - ${progress.currentPhase || 'processing'}`);
        
        if (progress.status === 'completed') {
          console.log(`[CryptoScheduler] ✅ Report completed in ${Math.round((Date.now() - startTime) / 1000)}s`);
          
          // Fetch the full report
          const reportResponse = await fetch(`${this.options.apiBaseUrl}/api/crypto/report/${reportId}`);
          const reportData = await reportResponse.json();
          
          return reportData.data || reportData;
        }
        
        if (progress.status === 'error') {
          throw new Error(progress.error || 'Report generation failed');
        }
        
        await this.delay(pollInterval);
        
      } catch (error) {
        console.error('[CryptoScheduler] Progress check error:', error.message);
        await this.delay(pollInterval);
      }
    }
    
    throw new Error(`Report generation timed out after ${maxWaitMs / 1000}s`);
  }

  /**
   * Publish report to Update Center for TOP SECRET subscribers
   */
  async publishToUpdateCenter(report, reportId) {
    try {
      const reportDate = report?.report_date || new Date().toISOString().split('T')[0];
      const regime = report?.market_regime || report?.executiveBrief?.regime?.label || 'N/A';
      const regimeScore = report?.regime_score || report?.executiveBrief?.regime?.score || null;
      const qaScore = report?.quality_metrics?.score || null;
      
      // Format the date nicely
      const dateObj = new Date(reportDate);
      const formattedDate = dateObj.toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      });
      
      // Build the PDF URL
      const pdfUrl = `${this.options.apiBaseUrl}/api/crypto/report/${reportId}/pdf`;
      
      // Create executive summary for the notification
      let executiveSummary = 'New bi-weekly crypto market analysis report is ready.';
      
      if (report?.executiveBrief?.regime) {
        const r = report.executiveBrief.regime;
        executiveSummary = `Market Regime: ${r.label} (Score: ${r.score}/100). `;
        
        if (report.executiveBrief?.keyTakeaways?.length > 0) {
          executiveSummary += report.executiveBrief.keyTakeaways[0];
        }
      }
      
      // Build metadata for the notification
      const metadata = {
        report_type: 'crypto_analysis',
        report_id: reportId,
        report_date: reportDate,
        pdf_url: pdfUrl,
        regime: regime,
        regime_score: regimeScore,
        qa_score: qaScore,
      };
      
      // Insert into system_updates table
      const { data, error } = await this.supabase
        .from('system_updates')
        .insert({
          id: uuidv4(),
          title: `🪙 Crypto Market Report - ${formattedDate}`,
          content: executiveSummary,
          type: 'announcement',
          target_group: SCHEDULE_CONFIG.targetGroup, // 'top_secret'
          is_active: true,
          is_pinned: true, // Pin new reports
          metadata: metadata,
          created_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) {
        throw error;
      }

      console.log(`[CryptoScheduler] 📢 Published to Update Center: ${data.id}`);
      console.log(`[CryptoScheduler] 🎯 Target group: ${SCHEDULE_CONFIG.targetGroup}`);
      console.log(`[CryptoScheduler] 📄 PDF URL: ${pdfUrl}`);
      
      // Unpin old reports (keep only the latest pinned)
      await this.unpinOldReports(data.id);
      
      return data;
      
    } catch (error) {
      console.error('[CryptoScheduler] ❌ Failed to publish to Update Center:', error);
      throw error;
    }
  }

  /**
   * Unpin old crypto reports (keep only the latest)
   */
  async unpinOldReports(currentUpdateId) {
    try {
      const { error } = await this.supabase
        .from('system_updates')
        .update({ is_pinned: false })
        .eq('target_group', SCHEDULE_CONFIG.targetGroup)
        .neq('id', currentUpdateId)
        .eq('is_pinned', true)
        .contains('metadata', { report_type: 'crypto_analysis' });

      if (error) {
        console.error('[CryptoScheduler] Failed to unpin old reports:', error);
      } else {
        console.log('[CryptoScheduler] 📌 Unpinned old crypto reports');
      }
    } catch (error) {
      console.error('[CryptoScheduler] Unpin error:', error);
    }
  }

  /**
   * Notify admin of generation failure
   */
  async notifyFailure() {
    try {
      const now = new Date();
      const formattedDate = now.toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
      
      // Log to admin_notifications table
      await this.supabase
        .from('admin_notifications')
        .insert({
          id: uuidv4(),
          type: 'crypto_generation_failed',
          title: '❌ Crypto Report Generation Failed',
          message: `All ${SCHEDULE_CONFIG.maxRetries} attempts failed on ${formattedDate}. Last error: ${this.lastError}`,
          severity: 'error',
          is_read: false,
          created_at: now.toISOString(),
        });

      console.log('[CryptoScheduler] 📧 Failure notification sent to admin');
      
      // Also create a system update for admins
      await this.supabase
        .from('system_updates')
        .insert({
          id: uuidv4(),
          title: '⚠️ Crypto Report Generation Failed',
          content: `Scheduled report generation failed after ${SCHEDULE_CONFIG.maxRetries} attempts. Error: ${this.lastError}`,
          type: 'warning',
          target_group: 'all', // Admins will see this
          is_active: true,
          is_pinned: false,
          metadata: {
            report_type: 'crypto_analysis_failure',
            error: this.lastError,
            attempts: SCHEDULE_CONFIG.maxRetries,
          },
          created_at: now.toISOString(),
        });
        
    } catch (error) {
      console.error('[CryptoScheduler] ❌ Failed to send failure notification:', error);
    }
  }

  // ============================================
  // MANUAL TRIGGER
  // ============================================

  /**
   * Manually trigger generation (for testing or on-demand)
   */
  async triggerManual() {
    console.log('[CryptoScheduler] 🔧 Manual trigger requested');
    return this.runScheduledGeneration();
  }

  // ============================================
  // UTILITIES
  // ============================================

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============================================
// SINGLETON INSTANCE
// ============================================

let schedulerInstance = null;

function initCryptoScheduler(supabase, options = {}) {
  if (!schedulerInstance) {
    schedulerInstance = new CryptoReportScheduler(supabase, options);
  }
  return schedulerInstance;
}

function getCryptoScheduler() {
  return schedulerInstance;
}
// ============================================
// EXPORTS
// ============================================

export {
  CryptoReportScheduler,
  initCryptoScheduler,
  getCryptoScheduler,
  SCHEDULE_CONFIG,
};

export default CryptoReportScheduler;