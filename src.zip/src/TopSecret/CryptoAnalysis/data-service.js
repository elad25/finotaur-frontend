// =====================================================
// CRYPTO DATA SERVICE v5.0 - ENHANCED
// =====================================================
// COMPLETE BINANCE API INTEGRATION
// All 14D delta calculations enabled
// NO MOCK DATA - Real API calls only
// =====================================================

import axios from 'axios';
import {
  API_ENDPOINTS,
  BINANCE_FUTURES_ENDPOINTS,
  BINANCE_DATA_ENDPOINTS,
  TIMEFRAMES,
  BINANCE_TRADING_PAIRS,
  RATE_LIMITS,
  CACHE_CONFIG,
} from './config.js';

// ============================================
// ID MAPPINGS
// ============================================

const COINGECKO_IDS = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  SOL: 'solana',
  BNB: 'binancecoin',
  XRP: 'ripple',
  ADA: 'cardano',
  AVAX: 'avalanche-2',
  DOGE: 'dogecoin',
  DOT: 'polkadot',
  LINK: 'chainlink',
  MATIC: 'matic-network',
  ARB: 'arbitrum',
  OP: 'optimism',
  ATOM: 'cosmos',
  UNI: 'uniswap',
  LTC: 'litecoin',
  APT: 'aptos',
  SUI: 'sui',
  NEAR: 'near',
  INJ: 'injective-protocol',
  JUP: 'jupiter-exchange-solana',
  RNDR: 'render-token',
  FET: 'fetch-ai',
  TIA: 'celestia',
  SEI: 'sei-network',
  AAVE: 'aave',
  LDO: 'lido-dao',
  MKR: 'maker',
  CRV: 'curve-dao-token',
  TAO: 'bittensor',
  FIL: 'filecoin',
  GRT: 'the-graph',
};

const BINANCE_SYMBOLS = {
  BTC: 'BTCUSDT',
  ETH: 'ETHUSDT',
  SOL: 'SOLUSDT',
  BNB: 'BNBUSDT',
  XRP: 'XRPUSDT',
  ADA: 'ADAUSDT',
  AVAX: 'AVAXUSDT',
  DOGE: 'DOGEUSDT',
  DOT: 'DOTUSDT',
  LINK: 'LINKUSDT',
  MATIC: 'MATICUSDT',
  ARB: 'ARBUSDT',
  OP: 'OPUSDT',
  ATOM: 'ATOMUSDT',
  UNI: 'UNIUSDT',
  LTC: 'LTCUSDT',
  APT: 'APTUSDT',
  SUI: 'SUIUSDT',
  NEAR: 'NEARUSDT',
  INJ: 'INJUSDT',
};

const STABLECOIN_IDS = {
  USDT: 'tether',
  USDC: 'usd-coin',
  DAI: 'dai',
  FDUSD: 'first-digital-usd',
  USDE: 'ethena-usde',
  TUSD: 'true-usd',
  FRAX: 'frax',
};

// ============================================
// DATA SERVICE CLASS
// ============================================

class CryptoDataService {
  constructor(options = {}) {
    this.options = {
      coingeckoApiKey: options.coingeckoApiKey || process.env.COINGECKO_API_KEY,
      timeout: options.timeout || 15000,
      retries: options.retries || 2,
      cacheTTL: options.cacheTTL || CACHE_CONFIG?.DEFAULT_TTL || 60000,
      ...options,
    };

    this.cache = new Map();
    this.requestCount = 0;
    this.lastCoinGeckoRequest = 0;
    this.lastBinanceRequest = 0;
  }

  // ============================================
  // CACHE HELPERS
  // ============================================

  cacheGet(key) {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < this.options.cacheTTL) {
      return cached.data;
    }
    return null;
  }

  cacheSet(key, data, ttl = null) {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.options.cacheTTL,
    });
  }

  clearCache() {
    this.cache.clear();
  }

  // ============================================
  // HTTP HELPERS
  // ============================================

  getCoinGeckoHeaders() {
    const headers = {
      Accept: 'application/json',
      'User-Agent': 'Finotaur/5.0',
    };
    if (this.options.coingeckoApiKey) {
      headers['x-cg-demo-api-key'] = this.options.coingeckoApiKey;
    }
    return headers;
  }

  async rateLimitWaitCoinGecko() {
    const minInterval = RATE_LIMITS?.COINGECKO?.minIntervalMs || 2000;
    const elapsed = Date.now() - this.lastCoinGeckoRequest;
    if (elapsed < minInterval) {
      await new Promise((r) => setTimeout(r, minInterval - elapsed));
    }
    this.lastCoinGeckoRequest = Date.now();
  }

  async rateLimitWaitBinance() {
    const minInterval = RATE_LIMITS?.BINANCE?.minIntervalMs || 100;
    const elapsed = Date.now() - this.lastBinanceRequest;
    if (elapsed < minInterval) {
      await new Promise((r) => setTimeout(r, minInterval - elapsed));
    }
    this.lastBinanceRequest = Date.now();
  }

  async fetchWithRetry(url, options = {}, maxRetries = 2) {
    let lastError;
    const shortUrl = url.split('?')[0].split('/').slice(-2).join('/');
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        this.requestCount++;
        const response = await axios.get(url, {
          timeout: this.options.timeout,
          ...options,
        });
        if (attempt > 0) {
          console.log(`[DataService] ✅ Success on retry ${attempt}: ${shortUrl}`);
        }
        return response.data;
      } catch (error) {
        lastError = error;
        const status = error.response?.status || 'NETWORK';
        const msg = error.response?.data?.error || error.response?.data?.msg || error.message;
        
        if (attempt < maxRetries) {
          const delay = Math.pow(2, attempt) * 500;
          console.log(`[DataService] ⚠️ Attempt ${attempt + 1} failed: ${shortUrl} (${status}) - retrying in ${delay}ms...`);
          await new Promise((r) => setTimeout(r, delay));
        }
      }
    }
    console.error(`[DataService] ❌ FAILED after ${maxRetries + 1} attempts: ${shortUrl}`, lastError?.message);
    return null;
  }

  // ============================================
  // COINGECKO: GLOBAL MARKET DATA
  // ============================================

  async fetchGlobalMarketData() {
    const cacheKey = 'global_market';
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitCoinGecko();
    const data = await this.fetchWithRetry(`${API_ENDPOINTS.COINGECKO}/global`, {
      headers: this.getCoinGeckoHeaders(),
    });

    if (!data?.data) return null;

    const g = data.data;
    const result = {
      totalMarketCap: g.total_market_cap?.usd || 0,
      totalVolume24h: g.total_volume?.usd || 0,
      btcDominance: g.market_cap_percentage?.btc || 0,
      ethDominance: g.market_cap_percentage?.eth || 0,
      marketCapChange24h: g.market_cap_change_percentage_24h_usd || 0,
      activeCryptos: g.active_cryptocurrencies || 0,
      markets: g.markets || 0,
      source: 'CoinGecko',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // COINGECKO: ASSET PRICES (with 14D data)
  // ============================================

  async fetchAssetPrices(assets = ['BTC', 'ETH', 'SOL']) {
    const cacheKey = `asset_prices_${assets.sort().join('_')}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    const ids = assets.map((a) => COINGECKO_IDS[a]).filter(Boolean).join(',');

    await this.rateLimitWaitCoinGecko();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.COINGECKO}/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&price_change_percentage=1h,24h,7d,14d,30d&sparkline=false`,
      { headers: this.getCoinGeckoHeaders() }
    );

    if (!data || !Array.isArray(data)) return null;

    const result = {};
    data.forEach((coin) => {
      const symbol = Object.keys(COINGECKO_IDS).find((k) => COINGECKO_IDS[k] === coin.id);
      if (symbol) {
        result[symbol.toLowerCase()] = {
          symbol,
          name: coin.name,
          price: coin.current_price,
          marketCap: coin.market_cap,
          volume24h: coin.total_volume,
          change1h: coin.price_change_percentage_1h_in_currency,
          change24h: coin.price_change_percentage_24h,
          change7d: coin.price_change_percentage_7d_in_currency,
          change14d: coin.price_change_percentage_14d_in_currency,
          change30d: coin.price_change_percentage_30d_in_currency,
          ath: coin.ath,
          athChange: coin.ath_change_percentage,
          circulatingSupply: coin.circulating_supply,
          totalSupply: coin.total_supply,
          maxSupply: coin.max_supply,
          rank: coin.market_cap_rank,
          source: 'CoinGecko',
        };
      }
    });

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // COINGECKO: STABLECOIN DATA
  // ============================================

  async fetchStablecoinData() {
    const cacheKey = 'stablecoins';
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    const ids = Object.values(STABLECOIN_IDS).join(',');

    await this.rateLimitWaitCoinGecko();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.COINGECKO}/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&price_change_percentage=24h,7d,14d`,
      { headers: this.getCoinGeckoHeaders() }
    );

    if (!data || !Array.isArray(data)) return null;

    let totalSupply = 0;
    const stables = {};

    data.forEach((coin) => {
      const symbol = Object.keys(STABLECOIN_IDS).find((k) => STABLECOIN_IDS[k] === coin.id);
      if (symbol) {
        const mcap = coin.market_cap || 0;
        stables[symbol.toLowerCase()] = {
          symbol: symbol,
          marketCap: mcap,
          volume24h: coin.total_volume,
          change24h: coin.price_change_percentage_24h_in_currency,
          change7d: coin.price_change_percentage_7d_in_currency,
          change14d: coin.price_change_percentage_14d_in_currency,
        };
        totalSupply += mcap;
      }
    });

    // Calculate 14D change as weighted average
    let weightedChange14d = 0;
    Object.values(stables).forEach((s) => {
      if (s.marketCap && s.change14d) {
        weightedChange14d += (s.marketCap / totalSupply) * s.change14d;
      }
    });

    const result = {
      usdt: stables.usdt?.marketCap || 0,
      usdc: stables.usdc?.marketCap || 0,
      dai: stables.dai?.marketCap || 0,
      fdusd: stables.fdusd?.marketCap || 0,
      totalSupply,
      change14d: weightedChange14d,
      usdtShare: totalSupply > 0 ? ((stables.usdt?.marketCap || 0) / totalSupply) * 100 : 0,
      usdcShare: totalSupply > 0 ? ((stables.usdc?.marketCap || 0) / totalSupply) * 100 : 0,
      usdtChange7d: stables.usdt?.change7d || 0,
      usdcChange7d: stables.usdc?.change7d || 0,
      usdtChange14d: stables.usdt?.change14d || 0,
      usdcChange14d: stables.usdc?.change14d || 0,
      details: stables,
      source: 'CoinGecko',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // DEFILLAMA: ENHANCED STABLECOIN DATA
  // ============================================

  async fetchDefiLlamaStablecoins() {
    const cacheKey = 'defillama_stablecoins';
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    try {
      const data = await this.fetchWithRetry(`${API_ENDPOINTS.DEFILLAMA_STABLECOINS}/stablecoins?includePrices=true`);

      if (!data?.peggedAssets) return null;

      const stables = data.peggedAssets.slice(0, 10);
      let totalSupply = 0;
      const details = {};

      stables.forEach((s) => {
        const mcap = s.circulating?.peggedUSD || 0;
        totalSupply += mcap;
        details[s.symbol?.toLowerCase()] = {
          symbol: s.symbol,
          name: s.name,
          marketCap: mcap,
          price: s.price || 1,
          pegMechanism: s.pegMechanism,
        };
      });

      const result = {
        totalSupply,
        topStables: details,
        source: 'DefiLlama',
        updatedAt: new Date().toISOString(),
      };

      this.cacheSet(cacheKey, result, CACHE_CONFIG?.STABLECOIN_TTL || 180000);
      return result;
    } catch (error) {
      console.error('[DataService] DefiLlama stablecoins error:', error.message);
      return null;
    }
  }

  // ============================================
  // BINANCE SPOT: TICKERS
  // ============================================

  async fetchBinanceSpotTicker(symbol = 'BTCUSDT') {
    const cacheKey = `binance_spot_${symbol}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(`${API_ENDPOINTS.BINANCE_SPOT}/ticker/24hr?symbol=${symbol}`);

    if (!data) return null;

    const result = {
      symbol: data.symbol,
      price: parseFloat(data.lastPrice),
      priceChange: parseFloat(data.priceChange),
      priceChangePercent: parseFloat(data.priceChangePercent),
      high24h: parseFloat(data.highPrice),
      low24h: parseFloat(data.lowPrice),
      volume24h: parseFloat(data.volume),
      quoteVolume24h: parseFloat(data.quoteVolume),
      openPrice: parseFloat(data.openPrice),
      trades24h: parseInt(data.count),
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  async fetchBinanceSpotTickers(symbols) {
    const cacheKey = `binance_spot_tickers_${symbols.sort().join('_')}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const symbolsParam = JSON.stringify(symbols);
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_SPOT}/ticker/24hr?symbols=${encodeURIComponent(symbolsParam)}`
    );

    if (!data || !Array.isArray(data)) return null;

    const result = {};
    data.forEach((ticker) => {
      result[ticker.symbol] = {
        symbol: ticker.symbol,
        price: parseFloat(ticker.lastPrice),
        priceChangePercent: parseFloat(ticker.priceChangePercent),
        high24h: parseFloat(ticker.highPrice),
        low24h: parseFloat(ticker.lowPrice),
        volume24h: parseFloat(ticker.volume),
        quoteVolume24h: parseFloat(ticker.quoteVolume),
        trades24h: parseInt(ticker.count),
        source: 'Binance',
      };
    });

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE SPOT: ORDER BOOK
  // ============================================

  async fetchBinanceOrderBook(symbol = 'BTCUSDT', limit = 20) {
    const cacheKey = `binance_depth_${symbol}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(`${API_ENDPOINTS.BINANCE_SPOT}/depth?symbol=${symbol}&limit=${limit}`);

    if (!data) return null;

    const sumOrders = (orders) =>
      orders.reduce((sum, o) => sum + parseFloat(o[0]) * parseFloat(o[1]), 0);

    const result = {
      symbol,
      bidDepth: sumOrders(data.bids || []),
      askDepth: sumOrders(data.asks || []),
      bidAskRatio: sumOrders(data.bids || []) / (sumOrders(data.asks || []) || 1),
      spread: data.asks?.[0] && data.bids?.[0] ? parseFloat(data.asks[0][0]) - parseFloat(data.bids[0][0]) : 0,
      spreadPercent:
        data.asks?.[0] && data.bids?.[0]
          ? ((parseFloat(data.asks[0][0]) - parseFloat(data.bids[0][0])) / parseFloat(data.bids[0][0])) * 100
          : 0,
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE SPOT: HISTORICAL KLINES (for 14D delta)
  // ============================================

  async fetchBinanceKlines(symbol = 'BTCUSDT', interval = '1d', limit = 15) {
    const cacheKey = `binance_klines_${symbol}_${interval}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_SPOT}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
    );

    if (!data || !Array.isArray(data)) return null;

    const klines = data.map((k) => ({
      openTime: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
      closeTime: k[6],
      quoteVolume: parseFloat(k[7]),
      trades: k[8],
    }));

    const oldest = klines[0];
    const latest = klines[klines.length - 1];
    const priceChange14d = oldest && latest ? ((latest.close - oldest.open) / oldest.open) * 100 : null;
    const volumeChange14d =
      oldest && latest && oldest.quoteVolume > 0
        ? ((latest.quoteVolume - oldest.quoteVolume) / oldest.quoteVolume) * 100
        : null;

    const result = {
      symbol,
      interval,
      klines,
      priceChange14d,
      volumeChange14d,
      price14dAgo: oldest?.open,
      currentPrice: latest?.close,
      high14d: Math.max(...klines.map((k) => k.high)),
      low14d: Math.min(...klines.map((k) => k.low)),
      avgVolume14d: klines.reduce((sum, k) => sum + k.quoteVolume, 0) / klines.length,
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: CURRENT FUNDING RATE
  // ============================================

  async fetchBinanceFundingRate(symbol = 'BTCUSDT') {
    const cacheKey = `binance_funding_${symbol}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES}${BINANCE_FUTURES_ENDPOINTS.FUNDING_RATE}?symbol=${symbol}&limit=1`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const latest = data[0];
    const rate = parseFloat(latest.fundingRate);

    const result = {
      symbol: latest.symbol,
      fundingRate: rate,
      fundingRatePercent: rate * 100,
      annualized: rate * 3 * 365 * 100,
      fundingTime: latest.fundingTime,
      signal: this.getFundingSignal(rate),
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: FUNDING RATE HISTORY (14D)
  // ============================================

  async fetchBinanceFundingRateHistory(symbol = 'BTCUSDT', limit = 42) {
    const cacheKey = `binance_funding_hist_${symbol}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES}${BINANCE_FUTURES_ENDPOINTS.FUNDING_RATE}?symbol=${symbol}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const rates = data.map((d) => ({
      rate: parseFloat(d.fundingRate),
      ratePercent: parseFloat(d.fundingRate) * 100,
      time: d.fundingTime,
    }));

    const avgRate = rates.reduce((sum, r) => sum + r.rate, 0) / rates.length;
    const latest = rates[rates.length - 1];
    const oldest = rates[0];

    const result = {
      symbol,
      periods: rates.length,
      currentRate: latest?.ratePercent,
      avgRate14d: avgRate * 100,
      avgAnnualized14d: avgRate * 3 * 365 * 100,
      maxRate14d: Math.max(...rates.map((r) => r.ratePercent)),
      minRate14d: Math.min(...rates.map((r) => r.ratePercent)),
      rateChange14d: latest && oldest ? (latest.ratePercent - oldest.ratePercent) : null,
      rates: rates,
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

  getFundingSignal(rate) {
    if (rate > 0.0005) return 'Longs paying (crowded)';
    if (rate > 0.0001) return 'Longs paying';
    if (rate < -0.0005) return 'Shorts paying (crowded)';
    if (rate < -0.0001) return 'Shorts paying';
    return 'Neutral';
  }

  // ============================================
  // BINANCE FUTURES: CURRENT OPEN INTEREST
  // ============================================

  async fetchBinanceOpenInterest(symbol = 'BTCUSDT') {
    const cacheKey = `binance_oi_${symbol}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES}${BINANCE_FUTURES_ENDPOINTS.OPEN_INTEREST}?symbol=${symbol}`
    );

    if (!data) return null;

    const ticker = await this.fetchBinanceSpotTicker(symbol);
    const price = ticker?.price || 0;

    const result = {
      symbol: data.symbol,
      openInterest: parseFloat(data.openInterest),
      openInterestUSD: parseFloat(data.openInterest) * price,
      price,
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: OPEN INTEREST HISTORY (14D)
  // ============================================

  async fetchBinanceOpenInterestHistory(symbol = 'BTCUSDT', period = '1h', limit = 336) {
    const cacheKey = `binance_oi_hist_${symbol}_${period}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES}${BINANCE_FUTURES_ENDPOINTS.OPEN_INTEREST_HIST}?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const history = data.map((d) => ({
      oi: parseFloat(d.sumOpenInterest),
      oiValue: parseFloat(d.sumOpenInterestValue),
      timestamp: d.timestamp,
    }));

    const oldest = history[0];
    const latest = history[history.length - 1];

    const result = {
      symbol,
      period,
      dataPoints: history.length,
      currentOI: latest?.oiValue,
      oi14dAgo: oldest?.oiValue,
      oiChange14d: oldest?.oiValue ? ((latest?.oiValue - oldest?.oiValue) / oldest?.oiValue) * 100 : null,
      oiChangeAbsolute: latest?.oiValue - oldest?.oiValue,
      maxOI14d: Math.max(...history.map((h) => h.oiValue)),
      minOI14d: Math.min(...history.map((h) => h.oiValue)),
      avgOI14d: history.reduce((sum, h) => sum + h.oiValue, 0) / history.length,
      history: history.slice(-48), // Last 48 data points for charts
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: LONG/SHORT RATIO (Top Traders)
  // ============================================

  async fetchBinanceLongShortRatio(symbol = 'BTCUSDT', period = '5m') {
    const cacheKey = `binance_ls_${symbol}_${period}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}${BINANCE_DATA_ENDPOINTS.TOP_LONG_SHORT_POSITIONS}?symbol=${symbol}&period=${period}&limit=1`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const latest = data[0];
    const ratio = parseFloat(latest.longShortRatio);

    const result = {
      symbol,
      longShortRatio: ratio,
      longAccount: parseFloat(latest.longAccount) * 100,
      shortAccount: parseFloat(latest.shortAccount) * 100,
      signal: this.getLSSignal(ratio),
      timestamp: latest.timestamp,
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: LONG/SHORT HISTORY (14D)
  // ============================================

  async fetchBinanceLongShortHistory(symbol = 'BTCUSDT', period = '4h', limit = 84) {
    const cacheKey = `binance_ls_hist_${symbol}_${period}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}${BINANCE_DATA_ENDPOINTS.TOP_LONG_SHORT_POSITIONS}?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const history = data.map((d) => ({
      ratio: parseFloat(d.longShortRatio),
      longAccount: parseFloat(d.longAccount) * 100,
      shortAccount: parseFloat(d.shortAccount) * 100,
      timestamp: d.timestamp,
    }));

    const oldest = history[0];
    const latest = history[history.length - 1];

    const result = {
      symbol,
      period,
      dataPoints: history.length,
      currentRatio: latest?.ratio,
      ratio14dAgo: oldest?.ratio,
      ratioChange14d: latest && oldest ? latest.ratio - oldest.ratio : null,
      avgRatio14d: history.reduce((sum, h) => sum + h.ratio, 0) / history.length,
      maxRatio14d: Math.max(...history.map((h) => h.ratio)),
      minRatio14d: Math.min(...history.map((h) => h.ratio)),
      currentLongPercent: latest?.longAccount,
      currentShortPercent: latest?.shortAccount,
      history: history.slice(-48),
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

getLSSignal(ratio) {
    if (ratio > 2) return 'Heavily long (contrarian bearish)';
    if (ratio > 1.5) return 'Long crowded';
    if (ratio < 0.5) return 'Heavily short (contrarian bullish)';
    if (ratio < 0.7) return 'Short crowded';
    return 'Balanced';
  }

  // ============================================
  // BINANCE FUTURES: TOP TRADERS ACCOUNT RATIO (WHALE DATA)
  // ============================================

  async fetchBinanceTopTradersAccountRatio(symbol = 'BTCUSDT', period = '5m', limit = 1) {
    const cacheKey = `binance_top_account_${symbol}_${period}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}/topLongShortAccountRatio?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const latest = data[0];
    const ratio = parseFloat(latest.longShortRatio);

    const result = {
      symbol,
      longShortRatio: ratio,
      longAccount: parseFloat(latest.longAccount) * 100,
      shortAccount: parseFloat(latest.shortAccount) * 100,
      signal: this.getWhaleAccountSignal(ratio),
      timestamp: latest.timestamp,
      source: 'Binance',
      dataType: 'Top Traders Accounts',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  async fetchBinanceTopTradersAccountHistory(symbol = 'BTCUSDT', period = '4h', limit = 84) {
    const cacheKey = `binance_top_account_hist_${symbol}_${period}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}/topLongShortAccountRatio?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const history = data.map((d) => ({
      ratio: parseFloat(d.longShortRatio),
      longAccount: parseFloat(d.longAccount) * 100,
      shortAccount: parseFloat(d.shortAccount) * 100,
      timestamp: d.timestamp,
    }));

    const oldest = history[0];
    const latest = history[history.length - 1];

    const recentAvg = history.slice(-12).reduce((sum, h) => sum + h.ratio, 0) / Math.min(12, history.length);
    const olderAvg = history.slice(0, 12).reduce((sum, h) => sum + h.ratio, 0) / Math.min(12, history.length);
    const trend = recentAvg > olderAvg * 1.05 ? 'increasingly_long' : recentAvg < olderAvg * 0.95 ? 'increasingly_short' : 'stable';

    const result = {
      symbol,
      period,
      dataPoints: history.length,
      currentRatio: latest?.ratio,
      ratio14dAgo: oldest?.ratio,
      ratioChange14d: latest && oldest ? latest.ratio - oldest.ratio : null,
      avgRatio14d: history.reduce((sum, h) => sum + h.ratio, 0) / history.length,
      maxRatio14d: Math.max(...history.map((h) => h.ratio)),
      minRatio14d: Math.min(...history.map((h) => h.ratio)),
      currentLongPercent: latest?.longAccount,
      currentShortPercent: latest?.shortAccount,
      trend,
      trendSignal: this.getWhaleTrendSignal(trend, latest?.ratio),
      history: history.slice(-48),
      source: 'Binance',
      dataType: 'Top Traders Accounts History',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

  getWhaleAccountSignal(ratio) {
    if (ratio > 2.5) return 'Whales extremely long (caution - Loss potential)';
    if (ratio > 1.8) return 'Whales heavily long';
    if (ratio > 1.3) return 'Whales leaning long';
    if (ratio < 0.4) return 'Whales extremely short (caution - potential bottom)';
    if (ratio < 0.55) return 'Whales heavily short';
    if (ratio < 0.75) return 'Whales leaning short';
    return 'Whales balanced';
  }

  getWhaleTrendSignal(trend, currentRatio) {
    if (trend === 'increasingly_long' && currentRatio > 1.5) {
      return 'Whales accumulating - getting crowded';
    }
    if (trend === 'increasingly_long' && currentRatio < 1.2) {
      return 'Whales starting to accumulate - early signal';
    }
    if (trend === 'increasingly_short' && currentRatio < 0.7) {
      return 'Whales de-risking - crowded short';
    }
    if (trend === 'increasingly_short' && currentRatio > 0.8) {
      return 'Whales reducing exposure - early warning';
    }
    return 'No clear whale trend';
  }

  // ============================================
  // BINANCE FUTURES: GLOBAL LONG/SHORT RATIO
  // ============================================

  async fetchBinanceGlobalLongShort(symbol = 'BTCUSDT', period = '5m', limit = 1) {
    const cacheKey = `binance_global_ls_${symbol}_${period}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}${BINANCE_DATA_ENDPOINTS.GLOBAL_LONG_SHORT}?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const latest = data[0];

    const result = {
      symbol,
      longShortRatio: parseFloat(latest.longShortRatio),
      longAccount: parseFloat(latest.longAccount) * 100,
      shortAccount: parseFloat(latest.shortAccount) * 100,
      timestamp: latest.timestamp,
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: TAKER BUY/SELL RATIO
  // ============================================

  async fetchBinanceTakerBuySellRatio(symbol = 'BTCUSDT', period = '5m', limit = 1) {
    const cacheKey = `binance_taker_${symbol}_${period}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}${BINANCE_DATA_ENDPOINTS.TAKER_LONG_SHORT}?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const latest = data[0];

    const result = {
      symbol,
      buySellRatio: parseFloat(latest.buySellRatio),
      buyVol: parseFloat(latest.buyVol),
      sellVol: parseFloat(latest.sellVol),
      timestamp: latest.timestamp,
      signal: parseFloat(latest.buySellRatio) > 1 ? 'Buy dominant' : 'Sell dominant',
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: TAKER BUY/SELL HISTORY (14D)
  // ============================================

  async fetchBinanceTakerHistory(symbol = 'BTCUSDT', period = '4h', limit = 84) {
    const cacheKey = `binance_taker_hist_${symbol}_${period}_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES_DATA}${BINANCE_DATA_ENDPOINTS.TAKER_LONG_SHORT}?symbol=${symbol}&period=${period}&limit=${limit}`
    );

    if (!data || !Array.isArray(data) || data.length === 0) return null;

    const history = data.map((d) => ({
      ratio: parseFloat(d.buySellRatio),
      buyVol: parseFloat(d.buyVol),
      sellVol: parseFloat(d.sellVol),
      timestamp: d.timestamp,
    }));

    const oldest = history[0];
    const latest = history[history.length - 1];

    const result = {
      symbol,
      period,
      dataPoints: history.length,
      currentRatio: latest?.ratio,
      ratio14dAgo: oldest?.ratio,
      ratioChange14d: latest && oldest ? latest.ratio - oldest.ratio : null,
      avgRatio14d: history.reduce((sum, h) => sum + h.ratio, 0) / history.length,
      buyDominantPeriods: history.filter((h) => h.ratio > 1).length,
      sellDominantPeriods: history.filter((h) => h.ratio <= 1).length,
      history: history.slice(-48),
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: PREMIUM INDEX (Mark vs Spot)
  // ============================================

  async fetchBinancePremiumIndex(symbol = 'BTCUSDT') {
    const cacheKey = `binance_premium_${symbol}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES}${BINANCE_FUTURES_ENDPOINTS.PREMIUM_INDEX}?symbol=${symbol}`
    );

    if (!data) return null;

    const markPrice = parseFloat(data.markPrice);
    const indexPrice = parseFloat(data.indexPrice);
    const basis = ((markPrice - indexPrice) / indexPrice) * 100;

    const result = {
      symbol: data.symbol,
      markPrice,
      indexPrice,
      basis, // Positive = contango, negative = backwardation
      basisAnnualized: basis * 365, // Rough annualized
      lastFundingRate: parseFloat(data.lastFundingRate),
      nextFundingTime: data.nextFundingTime,
      interestRate: parseFloat(data.interestRate),
      signal: basis > 0.1 ? 'Contango (bullish sentiment)' : basis < -0.1 ? 'Backwardation (bearish)' : 'Neutral',
      source: 'Binance',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // BINANCE FUTURES: 24H TICKER
  // ============================================

  async fetchBinanceFuturesTicker(symbol = 'BTCUSDT') {
    const cacheKey = `binance_futures_ticker_${symbol}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    await this.rateLimitWaitBinance();
    const data = await this.fetchWithRetry(
      `${API_ENDPOINTS.BINANCE_FUTURES}${BINANCE_FUTURES_ENDPOINTS.TICKER_24HR}?symbol=${symbol}`
    );

    if (!data) return null;

    const result = {
      symbol: data.symbol,
      price: parseFloat(data.lastPrice),
      priceChange: parseFloat(data.priceChange),
      priceChangePercent: parseFloat(data.priceChangePercent),
      volume24h: parseFloat(data.volume),
      quoteVolume24h: parseFloat(data.quoteVolume),
      high24h: parseFloat(data.highPrice),
      low24h: parseFloat(data.lowPrice),
      source: 'Binance Futures',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // LIQUIDATION ESTIMATES (Heuristic-based)
  // ============================================

  async fetchLiquidationsEstimate(symbol = 'BTCUSDT') {
    const cacheKey = `liquidations_estimate_${symbol}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    // Get current price and OI
    const [ticker, oi, funding] = await Promise.all([
      this.fetchBinanceSpotTicker(symbol),
      this.fetchBinanceOpenInterest(symbol),
      this.fetchBinanceFundingRate(symbol),
    ]);

    if (!ticker || !oi) return null;

    const price = ticker.price;
    const openInterestUSD = oi.openInterestUSD;

    // Estimate liquidation zones based on common leverage levels
    // Most retail uses 10-20x leverage
    // Liquidation typically happens at ~5-10% move against position
    const result = {
      symbol,
      currentPrice: price,
      openInterestUSD,

      // Long liquidation zones (price drops trigger)
      longLiqZone1: price * 0.95, // 5% drop - 20x longs
      longLiqZone2: price * 0.90, // 10% drop - 10x longs
      longLiqZone3: price * 0.85, // 15% drop - 6-7x longs

      // Short liquidation zones (price rises trigger)
      shortLiqZone1: price * 1.05, // 5% rise - 20x shorts
      shortLiqZone2: price * 1.10, // 10% rise - 10x shorts
      shortLiqZone3: price * 1.15, // 15% rise - 6-7x shorts

      // Estimated liquidation value (rough heuristic)
      // Assume 30% of OI is leveraged at 10x average
      estimatedLeveragedOI: openInterestUSD * 0.3,

      // If funding is very high, more liquidation risk
      liquidationRisk:
        funding?.annualized > 50
          ? 'HIGH'
          : funding?.annualized > 20
            ? 'MEDIUM'
            : 'LOW',

      fundingAnnualized: funding?.annualized,

      source: 'Binance (estimated)',
      note: 'Liquidation levels are estimates based on common leverage. Actual liquidations require on-chain data.',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }
// ============================================
// BLOCKCHAIN.COM: ON-CHAIN DATA (FREE)
// ============================================

async fetchBitcoinOnChainData() {
  const cacheKey = 'btc_onchain';
  const cached = this.cacheGet(cacheKey);
  if (cached) return cached;

  console.log('[DataService] Fetching Bitcoin on-chain data from Blockchain.com...');
  
  try {
    const [hashrate, difficulty, txCount, mempool] = await Promise.all([
      this.fetchWithRetry('https://api.blockchain.info/q/hashrate'),
      this.fetchWithRetry('https://api.blockchain.info/q/getdifficulty'),
      this.fetchWithRetry('https://api.blockchain.info/q/24hrtransactioncount'),
      this.fetchWithRetry('https://api.blockchain.info/q/unconfirmedcount'),
    ]);

    const result = {
      hashrate: hashrate ? parseFloat(hashrate) : null,
      difficulty: difficulty ? parseFloat(difficulty) : null,
      txCount24h: txCount ? parseInt(txCount) : null,
      mempoolSize: mempool ? parseInt(mempool) : null,
      networkHealth: this.calculateNetworkHealth(mempool, txCount),
      source: 'Blockchain.com',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, 300000);
    return result;
  } catch (error) {
    console.error('[DataService] Blockchain.com fetch failed:', error.message);
    return null;
  }
}

calculateNetworkHealth(mempool, txCount) {
  if (!mempool || !txCount) return { summary: 'Unknown' };
  const mempoolHealth = mempool < 50000 ? 'Healthy' : mempool < 150000 ? 'Moderate' : 'Congested';
  const activityLevel = txCount > 300000 ? 'High' : txCount > 200000 ? 'Normal' : 'Low';
  return {
    mempool: mempoolHealth,
    activity: activityLevel,
    summary: `${activityLevel} activity, ${mempoolHealth.toLowerCase()} mempool`
  };
}

// ============================================
// COINGLASS: LIQUIDATIONS DATA (FREE)
// ============================================

async fetchCoinglassLiquidations() {
  const cacheKey = 'coinglass_liquidations';
  const cached = this.cacheGet(cacheKey);
  if (cached) return cached;

  console.log('[DataService] Fetching liquidations from CoinGlass...');
  
  try {
    const data = await this.fetchWithRetry(
      'https://open-api.coinglass.com/public/v2/liquidation_history?symbol=BTC&time_type=h24'
    );

    if (!data?.data) return null;

    const liquidations = data.data;
    const totalLong = liquidations.reduce((sum, item) => sum + (item.longLiquidationUsd || 0), 0);
    const totalShort = liquidations.reduce((sum, item) => sum + (item.shortLiquidationUsd || 0), 0);

    const result = {
      btc: {
        longLiquidations24h: totalLong,
        shortLiquidations24h: totalShort,
        total24h: totalLong + totalShort,
        ratio: totalLong > 0 ? (totalShort / totalLong).toFixed(2) : 0,
        dominantSide: totalLong > totalShort ? 'LONGS' : 'SHORTS',
        signal: this.getLiquidationSignal(totalLong, totalShort),
      },
      source: 'CoinGlass',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, 60000);
    return result;
  } catch (error) {
    console.error('[DataService] CoinGlass fetch failed:', error.message);
    return null;
  }
}

getLiquidationSignal(longLiq, shortLiq) {
  const total = longLiq + shortLiq;
  const ratio = longLiq / (shortLiq || 1);
  
  if (total > 500000000) {
    return ratio > 2 ? 'Heavy long flush - potential bottom' : 
           ratio < 0.5 ? 'Heavy short squeeze - potential top' : 
           'Massive deleveraging both sides';
  }
  if (total > 200000000) {
    return ratio > 1.5 ? 'Longs getting flushed' : 
           ratio < 0.67 ? 'Shorts getting squeezed' : 
           'Balanced deleveraging';
  }
  return 'Normal liquidation levels';
}

// ============================================
// DEFILLAMA: TVL DATA (FREE)
// ============================================

async fetchDefiLlamaTVL() {
  const cacheKey = 'defillama_tvl';
  const cached = this.cacheGet(cacheKey);
  if (cached) return cached;

  console.log('[DataService] Fetching TVL from DeFiLlama...');
  
  try {
    const chains = await this.fetchWithRetry('https://api.llama.fi/v2/chains');
    if (!chains) return null;

    const sortedChains = chains.sort((a, b) => (b.tvl || 0) - (a.tvl || 0)).slice(0, 10);
    const totalTVL = chains.reduce((sum, c) => sum + (c.tvl || 0), 0);
    const ethTVL = chains.find(c => c.name === 'Ethereum')?.tvl || 0;

// Calculate weighted average 7d change
    const tvlChange7d = sortedChains.reduce((sum, c) => {
      const weight = (c.tvl || 0) / totalTVL;
      return sum + (weight * (c.change_7d || 0));
    }, 0);

    const result = {
      totalTVL,
      tvlChange7d,
      signal: this.getTVLSignal(tvlChange7d),
      topChains: sortedChains.map(c => ({ name: c.name, tvl: c.tvl, change7d: c.change_7d })),
      ethereumTVL: ethTVL,
      ethereumDominance: (ethTVL / totalTVL * 100).toFixed(1),
      source: 'DeFiLlama',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, 300000);
    return result;
  } catch (error) {
    console.error('[DataService] DeFiLlama TVL fetch failed:', error.message);
    return null;
  }
}
 

getTVLSignal(change7d) {
  if (change7d === null) return 'No data';
  if (change7d > 5) return 'Strong capital inflow to DeFi';
  if (change7d > 2) return 'Healthy TVL growth';
  if (change7d > -2) return 'TVL stable';
  if (change7d > -5) return 'Capital leaving DeFi';
  return 'Significant TVL decline - risk off';
}

  // ============================================
  // FEAR & GREED INDEX
  // ============================================

  async fetchFearGreedIndex() {
    const cacheKey = 'fear_greed';
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    const data = await this.fetchWithRetry(`${API_ENDPOINTS.FEAR_GREED}/?limit=2`);

    if (!data?.data || !Array.isArray(data.data)) return null;

    const current = data.data[0];
    const previous = data.data[1];

    const result = {
      value: parseInt(current.value),
      classification: current.value_classification,
      previousValue: previous ? parseInt(previous.value) : null,
      change24h: previous ? parseInt(current.value) - parseInt(previous.value) : 0,
      timestamp: current.timestamp,
      source: 'Alternative.me',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result);
    return result;
  }

  // ============================================
  // FEAR & GREED HISTORY (14D)
  // ============================================

  async fetchFearGreedHistory(limit = 15) {
    const cacheKey = `fear_greed_hist_${limit}`;
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    const data = await this.fetchWithRetry(`${API_ENDPOINTS.FEAR_GREED}/?limit=${limit}`);

    if (!data?.data || !Array.isArray(data.data)) return null;

    const history = data.data.map((d) => ({
      value: parseInt(d.value),
      classification: d.value_classification,
      timestamp: d.timestamp,
    }));

    const current = history[0];
    const oldest = history[history.length - 1];

    const result = {
      current: current.value,
      currentClassification: current.classification,
      value14dAgo: oldest?.value,
      change14d: current.value - (oldest?.value || current.value),
      avgValue14d: history.reduce((sum, h) => sum + h.value, 0) / history.length,
      maxValue14d: Math.max(...history.map((h) => h.value)),
      minValue14d: Math.min(...history.map((h) => h.value)),
      history,
      source: 'Alternative.me',
      updatedAt: new Date().toISOString(),
    };

    this.cacheSet(cacheKey, result, CACHE_CONFIG?.HISTORICAL_TTL || 300000);
    return result;
  }

  // ============================================
  // CRYPTO NEWS FROM CRYPTOCOMPARE (FREE)
  // ============================================

  async fetchCryptoNews() {
    const cacheKey = 'crypto_news';
    const cached = this.cacheGet(cacheKey);
    if (cached) return cached;

    try {
      const data = await this.fetchWithRetry(
        'https://min-api.cryptocompare.com/data/v2/news/?lang=EN&sortOrder=popular'
      );

      if (!data?.Data || !Array.isArray(data.Data)) return null;

      const symbols = ['BTC', 'ETH', 'SOL', 'ADA', 'XRP', 'AVAX'];
      const twoWeeksAgo = Math.floor(Date.now() / 1000) - (14 * 24 * 60 * 60);

      const relevantNews = data.Data
        .filter(article => {
          const publishedAt = article.published_on || 0;
          const title = (article.title || '').toUpperCase();
          const body = (article.body || '').toUpperCase();
          
          if (publishedAt < twoWeeksAgo) return false;
          
          return symbols.some(s => title.includes(s) || body.includes(s));
        })
        .slice(0, 3)
        .map(article => ({
          title: article.title,
          source: article.source_info?.name || article.source || 'CryptoCompare',
          url: article.url,
          publishedAt: new Date(article.published_on * 1000).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          }),
          relevantCoins: symbols.filter(s => 
            (article.title || '').toUpperCase().includes(s) ||
            (article.body || '').toUpperCase().includes(s)
          )
        }));

      const result = {
        articles: relevantNews,
        totalFound: relevantNews.length,
        source: 'CryptoCompare',
        updatedAt: new Date().toISOString(),
      };

      this.cacheSet(cacheKey, result, 3600000);
      return result;
    } catch (error) {
      console.error('[DataService] News fetch error:', error.message);
      return null;
    }
  }
  // ============================================
  // AGGREGATED DATA FETCHERS
  // ============================================

  async fetchAllMarketData() {
    console.log('[DataService] 🚀 Fetching market data from BINANCE (not CoinGecko)...');
    const startTime = Date.now();

    // Core assets to fetch from Binance
    const binanceSymbols = [
      'BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'LINKUSDT', 'ARBUSDT', 
      'OPUSDT', 'AVAXUSDT', 'DOGEUSDT', 'ADAUSDT', 'DOTUSDT',
      'NEARUSDT', 'APTUSDT', 'SUIUSDT', 'BNBUSDT', 'XRPUSDT'
    ];

    try {
      // Fetch all data in parallel
      const [
        binanceTickers,
        btcKlines,
        ethKlines,
        solKlines,
        fearGreed,
        fearGreedHistory,
        stablecoinData,
      ] = await Promise.all([
        this.fetchBinanceSpotTickers(binanceSymbols),
        this.fetchBinanceKlines('BTCUSDT', '1d', 15),
        this.fetchBinanceKlines('ETHUSDT', '1d', 15),
        this.fetchBinanceKlines('SOLUSDT', '1d', 15),
        this.fetchFearGreedIndex(),
        this.fetchFearGreedHistory(15),
        this.fetchStablecoinData(),
      ]);

      // Log what we got
      console.log(`[DataService] ✅ Binance tickers: ${binanceTickers ? Object.keys(binanceTickers).length : 0} assets`);
      console.log(`[DataService] ✅ BTC klines: ${btcKlines?.klines?.length || 0} candles`);
      console.log(`[DataService] ✅ Fear & Greed: ${fearGreed?.value || 'N/A'}`);

      // Transform Binance data to expected format
      const transformAsset = (symbol, ticker, klines) => {
        if (!ticker) return null;
        const baseSymbol = symbol.replace('USDT', '');
        
        // Calculate 7d change from klines if available
        let change7d = null;
        if (klines?.klines && klines.klines.length >= 8) {
          const price7dAgo = klines.klines[klines.klines.length - 8]?.open;
          const currentPrice = klines.currentPrice;
          if (price7dAgo && currentPrice) {
            change7d = ((currentPrice - price7dAgo) / price7dAgo) * 100;
          }
        }
        
        return {
          symbol: baseSymbol,
          name: this.getAssetName(baseSymbol),
          price: ticker.price,
          marketCap: null, // Binance doesn't provide market cap
          volume24h: ticker.quoteVolume24h,
          change1h: null, // Not available from 24h ticker
          change24h: ticker.priceChangePercent,
          change7d: change7d,
          change14d: klines?.priceChange14d || null,
          change30d: null,
          high24h: ticker.high24h,
          low24h: ticker.low24h,
          high14d: klines?.high14d || null,
          low14d: klines?.low14d || null,
          ath: null,
          athChange: null,
          trades24h: ticker.trades24h,
          source: 'Binance',
        };
      };

      // Build asset data
      const btc = transformAsset('BTCUSDT', binanceTickers?.BTCUSDT, btcKlines);
      const eth = transformAsset('ETHUSDT', binanceTickers?.ETHUSDT, ethKlines);
      const sol = transformAsset('SOLUSDT', binanceTickers?.SOLUSDT, solKlines);

      // Build allAssets object
      const allAssets = {};
      for (const symbol of binanceSymbols) {
        const baseSymbol = symbol.replace('USDT', '').toLowerCase();
        const ticker = binanceTickers?.[symbol];
        if (ticker) {
          allAssets[baseSymbol] = transformAsset(symbol, ticker, null);
        }
      }

      // Calculate approximate global data from Binance volume
      const totalVolume = Object.values(binanceTickers || {})
        .reduce((sum, t) => sum + (t?.quoteVolume24h || 0), 0);

      const globalData = {
        totalMarketCap: null, // Would need CMC/CoinGecko for this
        totalVolume24h: totalVolume,
        btcDominance: null, // Would need full market data
        ethDominance: null,
        marketCapChange24h: null,
        source: 'Binance (partial)',
        updatedAt: new Date().toISOString(),
      };

      const result = {
        global: globalData,
        btc,
        eth,
        sol,
        link: transformAsset('LINKUSDT', binanceTickers?.LINKUSDT, null),
        arb: transformAsset('ARBUSDT', binanceTickers?.ARBUSDT, null),
        op: transformAsset('OPUSDT', binanceTickers?.OPUSDT, null),
        allAssets,
        stablecoins: stablecoinData,
        fearGreed,
        fearGreedHistory,
        fetchDuration: Date.now() - startTime,
        source: 'Binance',
        updatedAt: new Date().toISOString(),
      };

      // Summary log
      console.log(`[DataService] 📊 MARKET DATA SUMMARY (BINANCE):`);
      console.log(`  - BTC: ${btc?.price ? `✅ $${btc.price.toLocaleString()}` : '❌ NULL'}`);
      console.log(`  - ETH: ${eth?.price ? `✅ $${eth.price.toLocaleString()}` : '❌ NULL'}`);
      console.log(`  - SOL: ${sol?.price ? `✅ $${sol.price.toLocaleString()}` : '❌ NULL'}`);
      console.log(`  - Fear&Greed: ${fearGreed?.value ? `✅ ${fearGreed.value} (${fearGreed.classification})` : '❌ NULL'}`);
      console.log(`  - Total Volume: $${(totalVolume / 1e9).toFixed(2)}B`);
      console.log(`[DataService] ✅ Market data fetched in ${result.fetchDuration}ms`);

      return result;

    } catch (error) {
      console.error('[DataService] ❌ Error fetching market data:', error.message);
      return {
        global: null,
        btc: null,
        eth: null,
        sol: null,
        allAssets: {},
        stablecoins: null,
        fearGreed: null,
        fearGreedHistory: null,
        fetchDuration: Date.now() - startTime,
        source: 'Binance (failed)',
        error: error.message,
        updatedAt: new Date().toISOString(),
      };
    }
  }

  // Helper to get asset names
  getAssetName(symbol) {
    const names = {
      BTC: 'Bitcoin', ETH: 'Ethereum', SOL: 'Solana', LINK: 'Chainlink',
      ARB: 'Arbitrum', OP: 'Optimism', AVAX: 'Avalanche', DOGE: 'Dogecoin',
      ADA: 'Cardano', DOT: 'Polkadot', NEAR: 'NEAR Protocol', APT: 'Aptos',
      SUI: 'Sui', BNB: 'BNB', XRP: 'XRP', MATIC: 'Polygon',
    };
    return names[symbol] || symbol;
  }

  async fetchAllDerivativesData() {
    console.log('[DataService] Fetching derivatives data from Binance...');
    const startTime = Date.now();
const [
      // Current funding rates
      btcFunding,
      ethFunding,
      solFunding,
      // Funding history (14D)
      btcFundingHist,
      ethFundingHist,
      // Current OI
      btcOI,
      ethOI,
      solOI,
      // OI history (14D)
      btcOIHist,
      ethOIHist,
      // Long/Short ratios
      btcLS,
      ethLS,
      // Long/Short history (14D)
      btcLSHist,
      ethLSHist,
      // Global long/short
      btcGlobalLS,
      ethGlobalLS,
      // Taker buy/sell
      btcTaker,
      ethTaker,
      // Taker history
      btcTakerHist,
      // Premium index
      btcPremium,
      ethPremium,
      // Liquidation estimates
      btcLiqEst,
      ethLiqEst,
      // Top Traders Account Ratio (WHALE DATA)
      btcTopAccount,
      ethTopAccount,
      btcTopAccountHist,
      ethTopAccountHist,
    ] = await Promise.all([
      this.fetchBinanceFundingRate('BTCUSDT'),
      this.fetchBinanceFundingRate('ETHUSDT'),
      this.fetchBinanceFundingRate('SOLUSDT'),
      this.fetchBinanceFundingRateHistory('BTCUSDT', 42),
      this.fetchBinanceFundingRateHistory('ETHUSDT', 42),
      this.fetchBinanceOpenInterest('BTCUSDT'),
      this.fetchBinanceOpenInterest('ETHUSDT'),
      this.fetchBinanceOpenInterest('SOLUSDT'),
      this.fetchBinanceOpenInterestHistory('BTCUSDT', '1h', 336),
      this.fetchBinanceOpenInterestHistory('ETHUSDT', '1h', 336),
      this.fetchBinanceLongShortRatio('BTCUSDT'),
      this.fetchBinanceLongShortRatio('ETHUSDT'),
      this.fetchBinanceLongShortHistory('BTCUSDT', '4h', 84),
      this.fetchBinanceLongShortHistory('ETHUSDT', '4h', 84),
      this.fetchBinanceGlobalLongShort('BTCUSDT'),
      this.fetchBinanceGlobalLongShort('ETHUSDT'),
      this.fetchBinanceTakerBuySellRatio('BTCUSDT'),
      this.fetchBinanceTakerBuySellRatio('ETHUSDT'),
      this.fetchBinanceTakerHistory('BTCUSDT', '4h', 84),
      this.fetchBinancePremiumIndex('BTCUSDT'),
      this.fetchBinancePremiumIndex('ETHUSDT'),
      this.fetchLiquidationsEstimate('BTCUSDT'),
      this.fetchLiquidationsEstimate('ETHUSDT'),
      this.fetchBinanceTopTradersAccountRatio('BTCUSDT'),
      this.fetchBinanceTopTradersAccountRatio('ETHUSDT'),
      this.fetchBinanceTopTradersAccountHistory('BTCUSDT', '4h', 84),
      this.fetchBinanceTopTradersAccountHistory('ETHUSDT', '4h', 84),
    ]);

    const result = {
      fundingRates: {
        btc: btcFunding?.fundingRatePercent || null,
        eth: ethFunding?.fundingRatePercent || null,
        sol: solFunding?.fundingRatePercent || null,
        btcAnnualized: btcFunding?.annualized || null,
        ethAnnualized: ethFunding?.annualized || null,
        solAnnualized: solFunding?.annualized || null,
        btcSignal: btcFunding?.signal || 'Unknown',
        ethSignal: ethFunding?.signal || 'Unknown',
        solSignal: solFunding?.signal || 'Unknown',
        raw: { btc: btcFunding, eth: ethFunding, sol: solFunding },
      },
      fundingHistory: {
        btc: btcFundingHist,
        eth: ethFundingHist,
        btcAvg14d: btcFundingHist?.avgAnnualized14d,
        ethAvg14d: ethFundingHist?.avgAnnualized14d,
        btcChange14d: btcFundingHist?.rateChange14d,
        ethChange14d: ethFundingHist?.rateChange14d,
      },
      openInterest: {
        btc: btcOI?.openInterestUSD || null,
        eth: ethOI?.openInterestUSD || null,
        sol: solOI?.openInterestUSD || null,
        btcRaw: btcOI?.openInterest || null,
        ethRaw: ethOI?.openInterest || null,
        solRaw: solOI?.openInterest || null,
        total: (btcOI?.openInterestUSD || 0) + (ethOI?.openInterestUSD || 0) + (solOI?.openInterestUSD || 0),
      },
      openInterestHistory: {
        btc: btcOIHist,
        eth: ethOIHist,
        btcChange14d: btcOIHist?.oiChange14d,
        ethChange14d: ethOIHist?.oiChange14d,
      },
      longShortRatio: {
        btc: btcLS?.longShortRatio || null,
        eth: ethLS?.longShortRatio || null,
        btcLongPercent: btcLS?.longAccount || null,
        btcShortPercent: btcLS?.shortAccount || null,
        ethLongPercent: ethLS?.longAccount || null,
        ethShortPercent: ethLS?.shortAccount || null,
        btcSignal: btcLS?.signal || 'Unknown',
        ethSignal: ethLS?.signal || 'Unknown',
      },
      longShortHistory: {
        btc: btcLSHist,
        eth: ethLSHist,
        btcChange14d: btcLSHist?.ratioChange14d,
        ethChange14d: ethLSHist?.ratioChange14d,
        btcAvg14d: btcLSHist?.avgRatio14d,
        ethAvg14d: ethLSHist?.avgRatio14d,
      },
      globalLongShort: {
        btc: btcGlobalLS,
        eth: ethGlobalLS,
      },
      takerBuySell: {
        btc: btcTaker,
        eth: ethTaker,
        btcRatio: btcTaker?.buySellRatio,
        ethRatio: ethTaker?.buySellRatio,
      },
      takerHistory: {
        btc: btcTakerHist,
      },
      premiumIndex: {
        btc: btcPremium,
        eth: ethPremium,
        btcBasis: btcPremium?.basis,
        ethBasis: ethPremium?.basis,
        btcSignal: btcPremium?.signal,
        ethSignal: ethPremium?.signal,
      },
liquidationEstimates: {
        btc: btcLiqEst,
        eth: ethLiqEst,
      },
      whaleData: {
        btcTopAccount: btcTopAccount,
        ethTopAccount: ethTopAccount,
        btcTopAccountHistory: btcTopAccountHist,
        ethTopAccountHistory: ethTopAccountHist,
        btcWhaleRatio: btcTopAccount?.longShortRatio,
        ethWhaleRatio: ethTopAccount?.longShortRatio,
        btcWhaleSignal: btcTopAccount?.signal,
        ethWhaleSignal: ethTopAccount?.signal,
        btcWhaleTrend: btcTopAccountHist?.trend,
        ethWhaleTrend: ethTopAccountHist?.trend,
        btcWhaleTrendSignal: btcTopAccountHist?.trendSignal,
        ethWhaleTrendSignal: ethTopAccountHist?.trendSignal,
        btcWhaleVsRetail: btcTopAccount && btcGlobalLS ? {
          whaleRatio: btcTopAccount.longShortRatio,
          retailRatio: btcGlobalLS.longShortRatio,
          divergence: (btcTopAccount.longShortRatio - btcGlobalLS.longShortRatio).toFixed(2),
          signal: Math.abs(btcTopAccount.longShortRatio - btcGlobalLS.longShortRatio) > 0.3 
            ? (btcTopAccount.longShortRatio > btcGlobalLS.longShortRatio ? 'Whales more bullish than retail' : 'Whales more bearish than retail')
            : 'Whales aligned with retail'
        } : null,
        ethWhaleVsRetail: ethTopAccount && ethGlobalLS ? {
          whaleRatio: ethTopAccount.longShortRatio,
          retailRatio: ethGlobalLS.longShortRatio,
          divergence: (ethTopAccount.longShortRatio - ethGlobalLS.longShortRatio).toFixed(2),
          signal: Math.abs(ethTopAccount.longShortRatio - ethGlobalLS.longShortRatio) > 0.3 
            ? (ethTopAccount.longShortRatio > ethGlobalLS.longShortRatio ? 'Whales more bullish than retail' : 'Whales more bearish than retail')
            : 'Whales aligned with retail'
        } : null,
      },
      source: 'Binance',
      fetchDuration: Date.now() - startTime,
      updatedAt: new Date().toISOString(),
    };

    console.log(`[DataService] Derivatives data fetched in ${result.fetchDuration}ms`);
    return result;
  }

  async fetchBinanceSpotData() {
    console.log('[DataService] Fetching spot data from Binance...');
    const startTime = Date.now();

    const symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'LINKUSDT', 'ARBUSDT'];

    const [tickers, btcDepth, ethDepth, btcKlines, ethKlines, solKlines] = await Promise.all([
      this.fetchBinanceSpotTickers(symbols),
      this.fetchBinanceOrderBook('BTCUSDT', 20),
      this.fetchBinanceOrderBook('ETHUSDT', 20),
      this.fetchBinanceKlines('BTCUSDT', '1d', 15),
      this.fetchBinanceKlines('ETHUSDT', '1d', 15),
      this.fetchBinanceKlines('SOLUSDT', '1d', 15),
    ]);

    const result = {
      tickers,
      orderBook: {
        btc: btcDepth,
        eth: ethDepth,
      },
      historicalKlines: {
        btc: btcKlines,
        eth: ethKlines,
        sol: solKlines,
        btcPriceChange14d: btcKlines?.priceChange14d,
        ethPriceChange14d: ethKlines?.priceChange14d,
        solPriceChange14d: solKlines?.priceChange14d,
        btcVolumeChange14d: btcKlines?.volumeChange14d,
        ethVolumeChange14d: ethKlines?.volumeChange14d,
      },
      source: 'Binance',
      fetchDuration: Date.now() - startTime,
      updatedAt: new Date().toISOString(),
    };

    console.log(`[DataService] Spot data fetched in ${result.fetchDuration}ms`);
    return result;
  }

  // ============================================
  // MAIN AGGREGATOR
  // ============================================

async fetchAllData() {
  console.log('[DataService] Fetching all data for report...');
  console.log('[DataService] Sources: CoinGecko + Binance + DefiLlama + Blockchain.com + CoinGlass (NO MOCK DATA)');
  const startTime = Date.now();

  const [marketData, derivativesData, spotData, defiLlamaStables, onChainData, liquidationsData, tvlData] = await Promise.all([
    this.fetchAllMarketData(),
    this.fetchAllDerivativesData(),
    this.fetchBinanceSpotData(),
    this.fetchDefiLlamaStablecoins(),
    this.fetchBitcoinOnChainData(),
    this.fetchCoinglassLiquidations(),
    this.fetchDefiLlamaTVL(),
  ]);
const result = {
  marketData,
  derivatives: derivativesData,
  spot: spotData,
  liquidity: {
    stablecoins: marketData?.stablecoins || null,
    defiLlamaStablecoins: defiLlamaStables,
    totalStableSupply: marketData?.stablecoins?.totalSupply || defiLlamaStables?.totalSupply || null,
    stablecoinChange14d: marketData?.stablecoins?.change14d || null,
  },
  onChain: {
    bitcoin: onChainData,
    networkHealth: onChainData?.networkHealth || null,
  },
  liquidations: {
    coinglass: liquidationsData,
    btcLiquidations24h: liquidationsData?.btc?.total24h || null,
    dominantSide: liquidationsData?.btc?.dominantSide || null,
    signal: liquidationsData?.btc?.signal || null,
  },
  tvl: {
    defiLlama: tvlData,
    totalTVL: tvlData?.totalTVL || null,
    tvlChange7d: tvlData?.tvlChange7d || null,
    signal: tvlData?.signal || null,
  },
      historical: {
        btcPriceChange14d: spotData?.historicalKlines?.btcPriceChange14d,
        ethPriceChange14d: spotData?.historicalKlines?.ethPriceChange14d,
        solPriceChange14d: spotData?.historicalKlines?.solPriceChange14d,
        btcFundingAvg14d: derivativesData?.fundingHistory?.btcAvg14d,
        ethFundingAvg14d: derivativesData?.fundingHistory?.ethAvg14d,
        btcOIChange14d: derivativesData?.openInterestHistory?.btcChange14d,
        ethOIChange14d: derivativesData?.openInterestHistory?.ethChange14d,
        btcLSChange14d: derivativesData?.longShortHistory?.btcChange14d,
        ethLSChange14d: derivativesData?.longShortHistory?.ethChange14d,
        fearGreedChange14d: marketData?.fearGreedHistory?.change14d,
      },
sources: ['CoinGecko', 'Binance', 'DefiLlama', 'Alternative.me', 'Blockchain.com', 'CoinGlass'],
      requestCount: this.requestCount,
      fetchDuration: Date.now() - startTime,
      updatedAt: new Date().toISOString(),
    };

    console.log(`[DataService] All data fetched in ${result.fetchDuration}ms (${this.requestCount} requests)`);
    return result;
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  getStats() {
    return {
      cacheSize: this.cache.size,
      requestCount: this.requestCount,
      lastCoinGeckoRequest: this.lastCoinGeckoRequest,
      lastBinanceRequest: this.lastBinanceRequest,
    };
  }
}

// ============================================
// EXPORTS
// ============================================

export {
  CryptoDataService,
  COINGECKO_IDS,
  BINANCE_SYMBOLS,
  STABLECOIN_IDS,
};