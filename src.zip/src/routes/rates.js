// src/routes/rates.js — Central Bank Rates with SMART CACHING
// Production-ready: Fetches once per day, serves all users from cache
// Saves API calls to FRED and Yahoo Finance

import { Router } from 'express';
import { createClient } from '@supabase/supabase-js';

const router = Router();

// ============================================================
// CONFIGURATION
// ============================================================

const FRED_API_KEY = process.env.FRED_API_KEY || '';
const CACHE_DURATION_HOURS = 24; // Central bank rates - refresh once per day
const YIELDS_CACHE_HOURS = 1;   // Yields - refresh every hour (markets move)

// Supabase for persistent cache
const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;
let supabase = null;

function getSupabase() {
  if (!supabase && SUPABASE_URL && SUPABASE_KEY) {
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
  }
  return supabase;
}

// In-memory cache for ultra-fast responses (no DB hit needed)
const memoryCache = {
  centralBanks: { data: null, timestamp: 0 },
  yields: { data: null, timestamp: 0 },
};

// ============================================================
// FALLBACK DATA - December 2024 (Used when APIs unavailable)
// ============================================================

const FALLBACK_BANKS = [
  {
    id: 'fed',
    name: 'Federal Reserve',
    shortName: 'Fed',
    currency: 'USD',
    country: 'United States',
    currentRate: 4.50,
    lastChange: -0.25,
    lastChangeDate: '2024-12-18',
    decisions: [
      { date: '2024-12-18', rate: 4.50, change: -0.25 },
      { date: '2024-11-07', rate: 4.75, change: -0.25 },
      { date: '2024-09-18', rate: 5.00, change: -0.50 },
      { date: '2024-07-31', rate: 5.50, change: 0 },
      { date: '2024-06-12', rate: 5.50, change: 0 },
      { date: '2024-05-01', rate: 5.50, change: 0 },
    ],
  },
  {
    id: 'ecb',
    name: 'European Central Bank',
    shortName: 'ECB',
    currency: 'EUR',
    country: 'Eurozone',
    currentRate: 3.15,
    lastChange: -0.25,
    lastChangeDate: '2024-12-12',
    decisions: [
      { date: '2024-12-12', rate: 3.15, change: -0.25 },
      { date: '2024-10-17', rate: 3.40, change: -0.25 },
      { date: '2024-09-12', rate: 3.65, change: -0.25 },
      { date: '2024-07-18', rate: 3.75, change: 0 },
      { date: '2024-06-06', rate: 3.75, change: -0.25 },
      { date: '2024-04-11', rate: 4.00, change: 0 },
    ],
  },
  {
    id: 'boj',
    name: 'Bank of Japan',
    shortName: 'BOJ',
    currency: 'JPY',
    country: 'Japan',
    currentRate: 0.25,
    lastChange: 0,
    lastChangeDate: '2024-12-19',
    decisions: [
      { date: '2024-12-19', rate: 0.25, change: 0 },
      { date: '2024-10-31', rate: 0.25, change: 0 },
      { date: '2024-09-20', rate: 0.25, change: 0 },
      { date: '2024-07-31', rate: 0.25, change: 0.15 },
      { date: '2024-06-14', rate: 0.10, change: 0 },
      { date: '2024-03-19', rate: 0.10, change: 0.10 },
    ],
  },
  {
    id: 'boe',
    name: 'Bank of England',
    shortName: 'BOE',
    currency: 'GBP',
    country: 'United Kingdom',
    currentRate: 4.75,
    lastChange: 0,
    lastChangeDate: '2024-12-19',
    decisions: [
      { date: '2024-12-19', rate: 4.75, change: 0 },
      { date: '2024-11-07', rate: 4.75, change: -0.25 },
      { date: '2024-09-19', rate: 5.00, change: 0 },
      { date: '2024-08-01', rate: 5.00, change: -0.25 },
      { date: '2024-06-20', rate: 5.25, change: 0 },
      { date: '2024-05-09', rate: 5.25, change: 0 },
    ],
  },
  {
    id: 'rba',
    name: 'Reserve Bank of Australia',
    shortName: 'RBA',
    currency: 'AUD',
    country: 'Australia',
    currentRate: 4.35,
    lastChange: 0,
    lastChangeDate: '2024-12-10',
    decisions: [
      { date: '2024-12-10', rate: 4.35, change: 0 },
      { date: '2024-11-05', rate: 4.35, change: 0 },
      { date: '2024-09-24', rate: 4.35, change: 0 },
      { date: '2024-08-06', rate: 4.35, change: 0 },
      { date: '2024-06-18', rate: 4.35, change: 0 },
      { date: '2024-05-07', rate: 4.35, change: 0 },
    ],
  },
  {
    id: 'rbnz',
    name: 'Reserve Bank of New Zealand',
    shortName: 'RBNZ',
    currency: 'NZD',
    country: 'New Zealand',
    currentRate: 4.25,
    lastChange: -0.50,
    lastChangeDate: '2024-11-27',
    decisions: [
      { date: '2024-11-27', rate: 4.25, change: -0.50 },
      { date: '2024-10-09', rate: 4.75, change: -0.50 },
      { date: '2024-08-14', rate: 5.25, change: -0.25 },
      { date: '2024-07-10', rate: 5.50, change: 0 },
      { date: '2024-05-22', rate: 5.50, change: 0 },
      { date: '2024-04-10', rate: 5.50, change: 0 },
    ],
  },
  {
    id: 'boc',
    name: 'Bank of Canada',
    shortName: 'BOC',
    currency: 'CAD',
    country: 'Canada',
    currentRate: 3.25,
    lastChange: -0.50,
    lastChangeDate: '2024-12-11',
    decisions: [
      { date: '2024-12-11', rate: 3.25, change: -0.50 },
      { date: '2024-10-23', rate: 3.75, change: -0.50 },
      { date: '2024-09-04', rate: 4.25, change: -0.25 },
      { date: '2024-07-24', rate: 4.50, change: -0.25 },
      { date: '2024-06-05', rate: 4.75, change: -0.25 },
      { date: '2024-04-10', rate: 5.00, change: 0 },
    ],
  },
  {
    id: 'snb',
    name: 'Swiss National Bank',
    shortName: 'SNB',
    currency: 'CHF',
    country: 'Switzerland',
    currentRate: 0.50,
    lastChange: -0.50,
    lastChangeDate: '2024-12-12',
    decisions: [
      { date: '2024-12-12', rate: 0.50, change: -0.50 },
      { date: '2024-09-26', rate: 1.00, change: -0.25 },
      { date: '2024-06-20', rate: 1.25, change: -0.25 },
      { date: '2024-03-21', rate: 1.50, change: -0.25 },
    ],
  },
];

// Meeting schedules 2025
const MEETING_SCHEDULES = {
  fed: ['2025-01-29', '2025-03-19', '2025-05-07', '2025-06-18', '2025-07-30', '2025-09-17', '2025-11-05', '2025-12-17'],
  ecb: ['2025-01-30', '2025-03-06', '2025-04-17', '2025-06-05', '2025-07-17', '2025-09-11', '2025-10-30', '2025-12-18'],
  boj: ['2025-01-24', '2025-03-14', '2025-05-01', '2025-06-17', '2025-07-31', '2025-09-19', '2025-10-31', '2025-12-19'],
  boe: ['2025-02-06', '2025-03-20', '2025-05-08', '2025-06-19', '2025-08-07', '2025-09-18', '2025-11-06', '2025-12-18'],
  rba: ['2025-02-18', '2025-04-01', '2025-05-20', '2025-07-08', '2025-08-12', '2025-09-30', '2025-11-04', '2025-12-09'],
  rbnz: ['2025-02-19', '2025-04-09', '2025-05-28', '2025-07-09', '2025-08-20', '2025-10-08', '2025-11-26'],
  boc: ['2025-01-29', '2025-03-12', '2025-04-16', '2025-06-04', '2025-07-30', '2025-09-17', '2025-10-29', '2025-12-10'],
  snb: ['2025-03-20', '2025-06-19', '2025-09-18', '2025-12-11'],
};

// FRED Series IDs
const FRED_SERIES = {
  fed: { seriesId: 'DFEDTARU', alternateSeriesId: 'FEDFUNDS' },
  ecb: { seriesId: 'ECBMRRFR', alternateSeriesId: 'ECBDFR' },
  boe: { seriesId: 'BOABORIR' },
  boj: { seriesId: 'IRSTCI01JPM156N', alternateSeriesId: 'INTDSRJPM193N' },
  rba: { seriesId: 'RBATCTR' },
  boc: { seriesId: 'IRSTCI01CAM156N' },
  snb: { seriesId: 'IRSTCI01CHM156N' },
  rbnz: { seriesId: 'IRSTCI01NZM156N' },
};

const YIELD_SYMBOLS = {
  us3m: { symbol: '^IRX', name: 'US 3-Month T-Bill', maturity: '3M' },
  us5y: { symbol: '^FVX', name: 'US 5-Year Yield', maturity: '5Y' },
  us10y: { symbol: '^TNX', name: 'US 10-Year Yield', maturity: '10Y' },
  us30y: { symbol: '^TYX', name: 'US 30-Year Yield', maturity: '30Y' },
};

// ============================================================
// CACHE HELPERS
// ============================================================

function isCacheValid(cacheEntry, maxAgeHours) {
  if (!cacheEntry || !cacheEntry.timestamp) return false;
  const ageMs = Date.now() - cacheEntry.timestamp;
  const maxAgeMs = maxAgeHours * 60 * 60 * 1000;
  return ageMs < maxAgeMs;
}

function formatCacheAge(timestamp) {
  if (!timestamp) return 'never';
  const ageMs = Date.now() - timestamp;
  const hours = Math.floor(ageMs / (60 * 60 * 1000));
  const minutes = Math.floor((ageMs % (60 * 60 * 1000)) / (60 * 1000));
  if (hours > 0) return `${hours}h ${minutes}m ago`;
  return `${minutes}m ago`;
}

// ============================================================
// SUPABASE CACHE (Persistent across restarts)
// ============================================================

async function saveToSupabaseCache(key, data) {
  const sb = getSupabase();
  if (!sb) return false;
  
  try {
    const { error } = await sb.from('rates_cache').upsert({
      id: key,
      data: JSON.stringify(data),
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' });
    
    if (error) throw error;
    console.log(`[rates] 💾 Saved to Supabase cache: ${key}`);
    return true;
  } catch (e) {
    console.error('[rates] Supabase cache save error:', e.message);
    return false;
  }
}

async function loadFromSupabaseCache(key) {
  const sb = getSupabase();
  if (!sb) return null;
  
  try {
    const { data, error } = await sb
      .from('rates_cache')
      .select('*')
      .eq('id', key)
      .single();
    
    if (error || !data) return null;
    
    return {
      data: JSON.parse(data.data),
      timestamp: new Date(data.updated_at).getTime(),
    };
  } catch (e) {
    console.error('[rates] Supabase cache load error:', e.message);
    return null;
  }
}

// ============================================================
// API FETCHERS
// ============================================================

async function fetchFREDSeries(seriesId, limit = 100) {
  if (!FRED_API_KEY) return null;
  
  try {
    const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&api_key=${FRED_API_KEY}&file_type=json&sort_order=desc&limit=${limit}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    
    return (data?.observations || [])
      .filter(o => o.value !== '.')
      .map(o => ({ date: o.date, value: parseFloat(o.value) }));
  } catch (e) {
    console.error(`[rates] FRED error for ${seriesId}:`, e.message);
    return null;
  }
}

async function fetchYahooYield(symbol, range = '3mo') {
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1d&range=${range}`;
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    
    const result = data?.chart?.result?.[0];
    if (!result) return null;
    
    const meta = result.meta;
    const timestamps = result.timestamp || [];
    const closes = result.indicators?.quote?.[0]?.close || [];
    
    const history = timestamps.map((ts, i) => ({
      date: new Date(ts * 1000).toISOString().split('T')[0],
      value: closes[i] !== null ? closes[i] : null,
    })).filter(h => h.value !== null);
    
    return {
      current: meta.regularMarketPrice,
      previousClose: meta.previousClose,
      change: meta.regularMarketPrice - meta.previousClose,
      changePercent: meta.previousClose ? ((meta.regularMarketPrice - meta.previousClose) / meta.previousClose) * 100 : 0,
      history,
    };
  } catch (e) {
    console.error(`[rates] Yahoo error for ${symbol}:`, e.message);
    return null;
  }
}

// ============================================================
// ANALYTICS FUNCTIONS
// ============================================================

function computeDecisionsFromHistory(history) {
  if (!history || history.length < 2) return [];
  
  const decisions = [];
  let prevRate = null;
  const chronological = [...history].reverse();
  
  for (const curr of chronological) {
    if (prevRate !== null && curr.value !== prevRate) {
      decisions.push({
        date: curr.date,
        rate: curr.value,
        change: parseFloat((curr.value - prevRate).toFixed(2)),
      });
    }
    prevRate = curr.value;
  }
  
  return decisions.reverse().slice(0, 10);
}

function computePolicyBias(decisions) {
  if (!decisions?.length) return 'Neutral';
  
  const recent = decisions.slice(0, 4);
  const avgChange = recent.reduce((sum, d) => sum + (d.change || 0), 0) / recent.length;
  
  if (avgChange < -0.15) return 'Strongly Dovish';
  if (avgChange < -0.05) return 'Dovish';
  if (avgChange < 0) return 'Slightly Dovish';
  if (avgChange === 0) return 'Neutral';
  if (avgChange < 0.05) return 'Slightly Hawkish';
  if (avgChange < 0.15) return 'Hawkish';
  return 'Strongly Hawkish';
}

function computeMomentumScore(decisions) {
  if (!decisions?.length) return 50;
  
  let score = 50;
  decisions.slice(0, 6).forEach((d, i) => {
    const weight = (6 - i) / 6;
    if (d.change < 0) score += 10 * weight;
    else if (d.change > 0) score -= 10 * weight;
  });
  
  return Math.max(0, Math.min(100, Math.round(score)));
}

function computeCyclePhase(decisions) {
  if (!decisions || decisions.length < 3) return 'Unknown';
  
  const changes = decisions.slice(0, 4).map(d => d.change || 0);
  const allCutting = changes.every(c => c <= 0) && changes.some(c => c < 0);
  const allHiking = changes.every(c => c >= 0) && changes.some(c => c > 0);
  const allPaused = changes.every(c => c === 0);
  
  // Check for reversal
  if (changes.length >= 3) {
    const first = changes.slice(0, 2);
    const last = changes.slice(-2);
    if ((first.some(c => c > 0) && last.some(c => c < 0)) ||
        (first.some(c => c < 0) && last.some(c => c > 0))) {
      return 'Reversal Detected';
    }
  }
  
  if (allCutting) return 'Easing Cycle';
  if (allHiking) return 'Hiking Cycle';
  if (allPaused) return 'Paused';
  return 'End-of-Cycle';
}

function computeSixMeetingTrend(decisions) {
  return (decisions || []).slice(0, 6).map(d => 
    d.change > 0 ? 'up' : d.change < 0 ? 'down' : 'neutral'
  );
}

function getNextMeeting(bankId) {
  const schedule = MEETING_SCHEDULES[bankId];
  if (!schedule) return null;
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  for (const dateStr of schedule) {
    if (new Date(dateStr) >= today) return dateStr;
  }
  return schedule[0];
}

function getDaysUntil(dateStr) {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
}

function enrichBankData(bank) {
  const nextMeeting = getNextMeeting(bank.id);
  return {
    ...bank,
    nextMeeting,
    daysUntilMeeting: getDaysUntil(nextMeeting),
    policyBias: computePolicyBias(bank.decisions),
    momentumScore: computeMomentumScore(bank.decisions),
    cyclePhase: computeCyclePhase(bank.decisions),
    sixMeetingTrend: computeSixMeetingTrend(bank.decisions),
  };
}

function computeRateDifferentials(banks) {
  const pairs = [
    { base: 'fed', quote: 'boj', pair: 'USD/JPY' },
    { base: 'rbnz', quote: 'boj', pair: 'NZD/JPY' },
    { base: 'rba', quote: 'boj', pair: 'AUD/JPY' },
    { base: 'boe', quote: 'boj', pair: 'GBP/JPY' },
    { base: 'ecb', quote: 'fed', pair: 'EUR/USD' },
    { base: 'boe', quote: 'fed', pair: 'GBP/USD' },
    { base: 'rba', quote: 'fed', pair: 'AUD/USD' },
    { base: 'fed', quote: 'snb', pair: 'USD/CHF' },
    { base: 'ecb', quote: 'snb', pair: 'EUR/CHF' },
    { base: 'fed', quote: 'boc', pair: 'USD/CAD' },
  ];
  
  return pairs.map(p => {
    const baseBank = banks.find(b => b.id === p.base);
    const quoteBank = banks.find(b => b.id === p.quote);
    if (!baseBank?.currentRate || !quoteBank?.currentRate) return null;
    
    const differential = baseBank.currentRate - quoteBank.currentRate;
    const baseChange = baseBank.decisions?.[0]?.change || 0;
    const quoteChange = quoteBank.decisions?.[0]?.change || 0;
    const diffChange = baseChange - quoteChange;
    
    const trend = diffChange > 0.1 ? 'up' : diffChange < -0.1 ? 'down' : 'neutral';
    const momentum = Math.abs(differential) > 3 ? 'Strong' : 
                     Math.abs(differential) > 1.5 ? 'Stable' : 
                     Math.abs(differential) > 0.5 ? 'Weak' : 'Neutral';
    
    const tradeBias = differential > 1 && momentum !== 'Weak' ? 'Long' :
                      differential < -1 && momentum !== 'Weak' ? 'Short' : 'None';
    
    const carryScore = Math.min(100, Math.max(0,
      Math.round(50 + (differential * 10) + (momentum === 'Strong' ? 15 : momentum === 'Stable' ? 5 : -5))
    ));
    
    return {
      pair: p.pair,
      baseCurrency: baseBank.currency,
      quoteCurrency: quoteBank.currency,
      differential: parseFloat(differential.toFixed(2)),
      trend,
      momentum,
      tradeBias,
      volatility: Math.abs(differential) > 4 ? 'High' : Math.abs(differential) > 2 ? 'Medium' : 'Low',
      carryScore,
    };
  }).filter(Boolean);
}

function computeGlobalMetrics(banks, differentials) {
  const avgRate = banks.reduce((sum, b) => sum + (b.currentRate || 0), 0) / banks.length;
  const cuttingCount = banks.filter(b => b.cyclePhase === 'Easing Cycle').length;
  const hikingCount = banks.filter(b => b.cyclePhase === 'Hiking Cycle' || b.policyBias?.includes('Hawkish')).length;
  
  const momentum = cuttingCount > hikingCount + 2 ? 'Easing' :
                   hikingCount > cuttingCount + 2 ? 'Tightening' : 'Mixed';
  
  const avgCarryScore = differentials.length > 0 
    ? differentials.reduce((sum, d) => sum + d.carryScore, 0) / differentials.length 
    : 50;
  
  return {
    momentum,
    averageRate: parseFloat(avgRate.toFixed(2)),
    cuttingCount,
    hikingCount,
    pausedCount: banks.length - cuttingCount - hikingCount,
    carryOpportunityScore: Math.round(avgCarryScore),
  };
}

// ============================================================
// MAIN DATA FETCHER (Called once per day)
// ============================================================

async function fetchFreshCentralBanksData() {
  console.log('[rates] 🔄 Fetching fresh data from FRED...');
  const banks = [];
  
  for (const fallbackBank of FALLBACK_BANKS) {
    const fredConfig = FRED_SERIES[fallbackBank.id];
    
    if (FRED_API_KEY && fredConfig) {
      let history = await fetchFREDSeries(fredConfig.seriesId, 100);
      if (!history?.length && fredConfig.alternateSeriesId) {
        history = await fetchFREDSeries(fredConfig.alternateSeriesId, 100);
      }
      
      if (history?.length) {
        const decisions = computeDecisionsFromHistory(history);
        banks.push(enrichBankData({
          ...fallbackBank,
          currentRate: history[0].value,
          decisions: decisions.length > 0 ? decisions : fallbackBank.decisions,
          lastChange: decisions[0]?.change || fallbackBank.lastChange,
          lastChangeDate: decisions[0]?.date || fallbackBank.lastChangeDate,
        }));
        continue;
      }
    }
    
    // Use fallback
    banks.push(enrichBankData(fallbackBank));
  }
  
  const differentials = computeRateDifferentials(banks);
  const globalMetrics = computeGlobalMetrics(banks, differentials);
  
  return { banks, differentials, globalMetrics };
}

async function fetchFreshYieldsData() {
  console.log('[rates] 🔄 Fetching fresh yields from Yahoo...');
  
  const results = await Promise.all(
    Object.entries(YIELD_SYMBOLS).map(async ([key, config]) => {
      const data = await fetchYahooYield(config.symbol, '3mo');
      return { id: key, ...config, ...data };
    })
  );
  
  const valid = results.filter(r => r.current !== undefined);
  
  // If Yahoo failed, return fallback
  if (valid.length === 0) {
    return [
      { id: 'us3m', symbol: '^IRX', name: 'US 3-Month T-Bill', maturity: '3M', current: 4.35, change: -0.02, history: [] },
      { id: 'us5y', symbol: '^FVX', name: 'US 5-Year Yield', maturity: '5Y', current: 4.25, change: 0.03, history: [] },
      { id: 'us10y', symbol: '^TNX', name: 'US 10-Year Yield', maturity: '10Y', current: 4.40, change: 0.02, history: [] },
      { id: 'us30y', symbol: '^TYX', name: 'US 30-Year Yield', maturity: '30Y', current: 4.55, change: 0.01, history: [] },
    ];
  }
  
  return valid;
}

// ============================================================
// SMART CACHE GETTERS (Check memory -> Supabase -> Fetch)
// ============================================================

async function getCentralBanksData(forceRefresh = false) {
  // 1. Check memory cache first (fastest)
  if (!forceRefresh && isCacheValid(memoryCache.centralBanks, CACHE_DURATION_HOURS)) {
    console.log('[rates] ⚡ Serving from memory cache');
    return {
      ...memoryCache.centralBanks.data,
      source: 'memory_cache',
      cacheAge: formatCacheAge(memoryCache.centralBanks.timestamp),
    };
  }
  
  // 2. Check Supabase cache (persists across restarts)
  if (!forceRefresh) {
    const supabaseCache = await loadFromSupabaseCache('central_banks_v2');
    if (supabaseCache && isCacheValid(supabaseCache, CACHE_DURATION_HOURS)) {
      console.log('[rates] 💾 Serving from Supabase cache');
      // Update memory cache
      memoryCache.centralBanks = supabaseCache;
      return {
        ...supabaseCache.data,
        source: 'supabase_cache',
        cacheAge: formatCacheAge(supabaseCache.timestamp),
      };
    }
  }
  
  // 3. Fetch fresh data (once per day)
  console.log('[rates] 🌐 Cache expired or force refresh - fetching fresh data...');
  const freshData = await fetchFreshCentralBanksData();
  
  // Update both caches
  const cacheEntry = { data: freshData, timestamp: Date.now() };
  memoryCache.centralBanks = cacheEntry;
  await saveToSupabaseCache('central_banks_v2', freshData);
  
  return {
    ...freshData,
    source: FRED_API_KEY ? 'fred_api' : 'fallback_data',
    cacheAge: 'just now',
  };
}

async function getYieldsData(forceRefresh = false) {
  // 1. Check memory cache
  if (!forceRefresh && isCacheValid(memoryCache.yields, YIELDS_CACHE_HOURS)) {
    return {
      yields: memoryCache.yields.data,
      source: 'memory_cache',
      cacheAge: formatCacheAge(memoryCache.yields.timestamp),
    };
  }
  
  // 2. Check Supabase cache
  if (!forceRefresh) {
    const supabaseCache = await loadFromSupabaseCache('yields_v2');
    if (supabaseCache && isCacheValid(supabaseCache, YIELDS_CACHE_HOURS)) {
      memoryCache.yields = supabaseCache;
      return {
        yields: supabaseCache.data,
        source: 'supabase_cache',
        cacheAge: formatCacheAge(supabaseCache.timestamp),
      };
    }
  }
  
  // 3. Fetch fresh
  const freshYields = await fetchFreshYieldsData();
  const cacheEntry = { data: freshYields, timestamp: Date.now() };
  memoryCache.yields = cacheEntry;
  await saveToSupabaseCache('yields_v2', freshYields);
  
  return {
    yields: freshYields,
    source: 'yahoo_finance',
    cacheAge: 'just now',
  };
}

// ============================================================
// API ENDPOINTS
// ============================================================

// GET /api/rates/central-banks - Main endpoint (cached 24h)
router.get('/rates/central-banks', async (req, res) => {
  try {
    const forceRefresh = req.query.refresh === 'true';
    const data = await getCentralBanksData(forceRefresh);
    
    res.json({
      timestamp: new Date().toISOString(),
      ...data,
    });
  } catch (e) {
    console.error('[rates] central-banks error:', e);
    
    // Emergency fallback
    const banks = FALLBACK_BANKS.map(enrichBankData);
    const differentials = computeRateDifferentials(banks);
    
    res.json({
      timestamp: new Date().toISOString(),
      source: 'emergency_fallback',
      warning: e.message,
      globalMetrics: computeGlobalMetrics(banks, differentials),
      banks,
      differentials,
    });
  }
});

// GET /api/rates/yields - Treasury yields (cached 1h)
router.get('/rates/yields', async (req, res) => {
  try {
    const forceRefresh = req.query.refresh === 'true';
    const data = await getYieldsData(forceRefresh);
    
    res.json({
      timestamp: new Date().toISOString(),
      range: '3mo',
      ...data,
    });
  } catch (e) {
    console.error('[rates] yields error:', e);
    res.status(500).json({ error: 'yields_error', message: e.message });
  }
});

// GET /api/rates/bank/:bankId - Single bank
router.get('/rates/bank/:bankId', async (req, res) => {
  try {
    const bankId = req.params.bankId.toLowerCase();
    const { banks } = await getCentralBanksData();
    const bank = banks.find(b => b.id === bankId);
    
    if (!bank) {
      return res.status(404).json({ error: 'bank_not_found', bankId });
    }
    
    res.json({ timestamp: new Date().toISOString(), bank });
  } catch (e) {
    console.error('[rates] bank error:', e);
    res.status(500).json({ error: 'bank_error', message: e.message });
  }
});

// GET /api/rates/differentials - Rate differentials only
router.get('/rates/differentials', async (req, res) => {
  try {
    const { differentials } = await getCentralBanksData();
    res.json({ timestamp: new Date().toISOString(), differentials });
  } catch (e) {
    console.error('[rates] differentials error:', e);
    res.status(500).json({ error: 'differentials_error', message: e.message });
  }
});

// POST /api/rates/refresh - Force refresh (admin)
router.post('/rates/refresh', async (req, res) => {
  try {
    console.log('[rates] 🔄 Force refresh requested...');
    
    const [banksData, yieldsData] = await Promise.all([
      getCentralBanksData(true),
      getYieldsData(true),
    ]);
    
    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      banksSource: banksData.source,
      yieldsSource: yieldsData.source,
      banksCount: banksData.banks?.length || 0,
      yieldsCount: yieldsData.yields?.length || 0,
    });
  } catch (e) {
    console.error('[rates] refresh error:', e);
    res.status(500).json({ error: 'refresh_error', message: e.message });
  }
});

// GET /api/rates/cache-status - Cache health check
router.get('/rates/cache-status', async (req, res) => {
  const memoryBanksAge = memoryCache.centralBanks.timestamp 
    ? formatCacheAge(memoryCache.centralBanks.timestamp) 
    : 'empty';
  const memoryYieldsAge = memoryCache.yields.timestamp 
    ? formatCacheAge(memoryCache.yields.timestamp) 
    : 'empty';
  
  res.json({
    memoryCacheStatus: {
      centralBanks: memoryBanksAge,
      yields: memoryYieldsAge,
    },
    cacheConfig: {
      centralBanksCacheDuration: `${CACHE_DURATION_HOURS} hours`,
      yieldsCacheDuration: `${YIELDS_CACHE_HOURS} hours`,
    },
    fredApiConfigured: !!FRED_API_KEY,
    supabaseConfigured: !!(SUPABASE_URL && SUPABASE_KEY),
  });
});

export default router;