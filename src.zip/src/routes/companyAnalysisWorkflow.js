// ============================================================================
// routes/companyAnalysisWorkflow.js — Finotaur Company Analysis v2.0
// ============================================================================
// ARCHITECTURE: 5-Phase, 16-Agent System for Company Deep Dive
// STANDARD: "Insider Intel" institutional quality analysis
// OUTPUT: Comprehensive company analysis report in ENGLISH
// DATA SOURCES: SEC EDGAR (filings), Yahoo Finance (news), Finnhub (market data)
// ============================================================================

import express from "express";
import { Agent, Runner } from "@openai/agents";

const router = express.Router();

// ============================================================================
// CONFIGURATION
// ============================================================================
const AGENT_MODEL = "gpt-4o";
const AGENT_DELAY = 300;
const BATCH_DELAY = 1000;
const QA_PASS_THRESHOLD = 85;
const MAX_RETRY_ATTEMPTS = 3;
const VERSION = "v2.0";
const DEBUG = process.env.DEBUG === 'true';
const log = (...args) => DEBUG && console.log(...args);

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ============================================================================
// SIMPLE IN-MEMORY CACHE
// ============================================================================
const cache = {
  data: new Map(),
  set(key, value, ttlMs = 60000) {
    this.data.set(key, { value, expires: Date.now() + ttlMs });
  },
  get(key) {
    const item = this.data.get(key);
    if (!item) return null;
    if (Date.now() > item.expires) { this.data.delete(key); return null; }
    return item.value;
  },
  clear() { this.data.clear(); }
};

// ============================================================================
// WORKFLOW STATUS TRACKING
// ============================================================================
const workflowStatus = {
  isRunning: false, currentPhase: null, currentStep: null, currentAgent: null,
  progress: 0, startTime: null, estimatedTotal: 180, completedAgents: [],
  logs: [], error: null, lastUpdate: null, companyTicker: null, companyName: null
};

function updateStatus(phase, step, progress, agentName = null, logMsg = null) {
  workflowStatus.currentPhase = phase;
  workflowStatus.currentStep = step;
  workflowStatus.progress = progress;
  workflowStatus.currentAgent = agentName;
  workflowStatus.lastUpdate = new Date().toISOString();
  if (agentName && !workflowStatus.completedAgents.includes(agentName)) {
    workflowStatus.completedAgents.push(agentName);
  }
  if (logMsg) {
    workflowStatus.logs.push({ time: new Date().toISOString(), phase, step, agent: agentName, message: logMsg });
    if (workflowStatus.logs.length > 100) workflowStatus.logs.shift();
  }
  console.log(`[${progress}%] ${phase} - ${step}${agentName ? ` (${agentName})` : ''}`);
}

function resetStatus() {
  Object.assign(workflowStatus, {
    isRunning: false, currentPhase: null, currentStep: null, currentAgent: null,
    progress: 0, startTime: null, completedAgents: [], logs: [], error: null,
    lastUpdate: null, companyTicker: null, companyName: null
  });
}

function getWorkflowStatus() {
  const elapsed = workflowStatus.startTime ? Math.floor((Date.now() - workflowStatus.startTime) / 1000) : 0;
  return {
    ...workflowStatus, elapsedSeconds: elapsed,
    elapsedFormatted: `${Math.floor(elapsed / 60)}:${(elapsed % 60).toString().padStart(2, '0')}`,
    estimatedRemaining: Math.max(0, workflowStatus.estimatedTotal - elapsed),
    completedAgentCount: workflowStatus.completedAgents.length,
    recentLogs: workflowStatus.logs.slice(-15)
  };
}

// ============================================================================
// RATE LIMITER
// ============================================================================
class RateLimiter {
  constructor(maxRequests, windowMs) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    this.requests = [];
  }
  async acquire() {
    const now = Date.now();
    this.requests = this.requests.filter(t => now - t < this.windowMs);
    if (this.requests.length >= this.maxRequests) {
      const waitTime = this.windowMs - (now - this.requests[0]);
      await sleep(waitTime);
      return this.acquire();
    }
    this.requests.push(now);
    return true;
  }
}

const polygonLimiter = new RateLimiter(5, 1000);
const finnhubLimiter = new RateLimiter(30, 60000);
const secLimiter = new RateLimiter(10, 1000);
const yahooLimiter = new RateLimiter(5, 1000);

// ============================================================================
// DATA SOURCE: POLYGON
// ============================================================================
async function polygonGet(endpoint) {
  const apiKey = process.env.POLYGON_API_KEY;
  if (!apiKey) return null;
  const cacheKey = `polygon:${endpoint}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;
  try {
    await polygonLimiter.acquire();
    const url = `https://api.polygon.io${endpoint}${endpoint.includes("?") ? "&" : "?"}apiKey=${apiKey}`;
    const r = await fetch(url);
    if (!r.ok) return null;
    const data = await r.json();
    cache.set(cacheKey, data, 15000);
    return data;
  } catch (e) { console.error(`Polygon error: ${e.message}`); return null; }
}

// ============================================================================
// DATA SOURCE: FINNHUB
// ============================================================================
async function finnhubGet(endpoint) {
  const token = process.env.FINNHUB_API_KEY;
  if (!token) return null;
  const cacheKey = `finnhub:${endpoint}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;
  try {
    await finnhubLimiter.acquire();
    const url = `https://finnhub.io/api/v1/${endpoint}${endpoint.includes("?") ? "&" : "?"}token=${token}`;
    const r = await fetch(url);
    if (!r.ok) return null;
    const data = await r.json();
    cache.set(cacheKey, data, 60000);
    return data;
  } catch (e) { console.error(`Finnhub error: ${e.message}`); return null; }
}

// ============================================================================
// DATA SOURCE: SEC EDGAR
// ============================================================================
async function fetchSECCompanyInfo(ticker) {
  const cacheKey = `sec:company:${ticker}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;
  try {
    await secLimiter.acquire();
    const headers = { 'User-Agent': 'Finotaur Research contact@finotaur.com', 'Accept': 'application/json' };
    const tickerMapUrl = 'https://www.sec.gov/files/company_tickers.json';
    const tickerMapRes = await fetch(tickerMapUrl, { headers });
    const tickerMap = await tickerMapRes.json();
    let companyInfo = null;
    for (const key in tickerMap) {
      if (tickerMap[key].ticker === ticker.toUpperCase()) {
        companyInfo = tickerMap[key];
        break;
      }
    }
    if (!companyInfo) return null;
    const cik = String(companyInfo.cik_str).padStart(10, '0');
    cache.set(cacheKey, { ...companyInfo, cik }, 300000);
    return { ...companyInfo, cik };
  } catch (e) { console.error(`SEC company info error: ${e.message}`); return null; }
}

async function fetchSECFilings(ticker, formTypes = ['10-K', '10-Q', '8-K']) {
  const cacheKey = `sec:filings:${ticker}:${formTypes.join(',')}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;
  try {
    const companyInfo = await fetchSECCompanyInfo(ticker);
    if (!companyInfo) return { companyInfo: null, filings: [], companyFacts: null };
    await secLimiter.acquire();
    const headers = { 'User-Agent': 'Finotaur Research contact@finotaur.com', 'Accept': 'application/json' };
    const filingsUrl = `https://data.sec.gov/submissions/CIK${companyInfo.cik}.json`;
    const filingsRes = await fetch(filingsUrl, { headers });
    if (!filingsRes.ok) { console.error(`SEC filings fetch failed: ${filingsRes.status}`); return { companyInfo: null, filings: [], companyFacts: null }; }
    const filingsData = await filingsRes.json();
    const recentFilings = filingsData.filings?.recent || {};
    const filings = [];
    const forms = recentFilings.form || [];
    const dates = recentFilings.filingDate || [];
    const accessionNumbers = recentFilings.accessionNumber || [];
    const primaryDocuments = recentFilings.primaryDocument || [];
    for (let i = 0; i < Math.min(forms.length, 50); i++) {
      if (formTypes.includes(forms[i])) {
        const accession = accessionNumbers[i].replace(/-/g, '');
        filings.push({
          form: forms[i], filingDate: dates[i], accessionNumber: accessionNumbers[i],
          primaryDocument: primaryDocuments[i],
          url: `https://www.sec.gov/Archives/edgar/data/${companyInfo.cik_str}/${accession}/${primaryDocuments[i]}`,
          viewerUrl: `https://www.sec.gov/cgi-bin/viewer?action=view&cik=${companyInfo.cik_str}&accession_number=${accessionNumbers[i]}`
        });
      }
    }
    let companyFacts = null;
    try {
      await secLimiter.acquire();
      const factsUrl = `https://data.sec.gov/api/xbrl/companyfacts/CIK${companyInfo.cik}.json`;
      const factsRes = await fetch(factsUrl, { headers });
      if (factsRes.ok) companyFacts = await factsRes.json();
    } catch (e) { console.log('Could not fetch company facts:', e.message); }
    const result = {
      companyInfo: {
        name: filingsData.name, cik: companyInfo.cik_str, ticker: ticker, sic: filingsData.sic,
        sicDescription: filingsData.sicDescription, fiscalYearEnd: filingsData.fiscalYearEnd,
        stateOfIncorporation: filingsData.stateOfIncorporation, businessAddress: filingsData.addresses?.business,
        phone: filingsData.phone, website: filingsData.website
      },
      filings: filings.slice(0, 20),
      companyFacts
    };
    cache.set(cacheKey, result, 300000);
    return result;
  } catch (e) { console.error(`SEC filings error: ${e.message}`); return { companyInfo: null, filings: [], companyFacts: null }; }
}

function extractSECFinancials(companyFacts) {
  if (!companyFacts?.facts) return null;
  const usGaap = companyFacts.facts['us-gaap'] || {};
  const getLatestValue = (concept) => {
    const data = usGaap[concept]?.units?.USD || usGaap[concept]?.units?.shares || [];
    if (data.length === 0) return null;
    const annualData = data.filter(d => d.form === '10-K').sort((a, b) => new Date(b.end) - new Date(a.end));
    return annualData[0] || data.sort((a, b) => new Date(b.end) - new Date(a.end))[0];
  };
  const getHistoricalValues = (concept, limit = 5) => {
    const data = usGaap[concept]?.units?.USD || usGaap[concept]?.units?.shares || [];
    if (data.length === 0) return [];
    return data.filter(d => d.form === '10-K' && d.fp === 'FY').sort((a, b) => new Date(b.end) - new Date(a.end)).slice(0, limit).map(d => ({ value: d.val, period: d.end, filed: d.filed }));
  };
  return {
    revenue: getLatestValue('Revenues') || getLatestValue('RevenueFromContractWithCustomerExcludingAssessedTax'),
    revenueHistory: getHistoricalValues('Revenues').length > 0 ? getHistoricalValues('Revenues') : getHistoricalValues('RevenueFromContractWithCustomerExcludingAssessedTax'),
    netIncome: getLatestValue('NetIncomeLoss'), netIncomeHistory: getHistoricalValues('NetIncomeLoss'),
    grossProfit: getLatestValue('GrossProfit'), grossProfitHistory: getHistoricalValues('GrossProfit'),
    operatingIncome: getLatestValue('OperatingIncomeLoss'), operatingIncomeHistory: getHistoricalValues('OperatingIncomeLoss'),
    totalAssets: getLatestValue('Assets'), totalAssetsHistory: getHistoricalValues('Assets'),
    totalLiabilities: getLatestValue('Liabilities'), totalLiabilitiesHistory: getHistoricalValues('Liabilities'),
    stockholdersEquity: getLatestValue('StockholdersEquity'), stockholdersEquityHistory: getHistoricalValues('StockholdersEquity'),
    cashAndEquivalents: getLatestValue('CashAndCashEquivalentsAtCarryingValue'),
    longTermDebt: getLatestValue('LongTermDebt') || getLatestValue('LongTermDebtNoncurrent'),
    operatingCashFlow: getLatestValue('NetCashProvidedByUsedInOperatingActivities'),
    capitalExpenditures: getLatestValue('PaymentsToAcquirePropertyPlantAndEquipment'),
    sharesOutstanding: getLatestValue('CommonStockSharesOutstanding'),
    eps: getLatestValue('EarningsPerShareBasic'), epsDiluted: getLatestValue('EarningsPerShareDiluted'),
    researchAndDevelopment: getLatestValue('ResearchAndDevelopmentExpense'),
    sgaExpense: getLatestValue('SellingGeneralAndAdministrativeExpense'),
    costOfRevenue: getLatestValue('CostOfRevenue') || getLatestValue('CostOfGoodsAndServicesSold')
  };
}

// ============================================================================
// DATA SOURCE: YAHOO FINANCE NEWS
// ============================================================================
async function fetchYahooFinanceNews(ticker) {
  const cacheKey = `yahoo:rss:${ticker}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;
  try {
    await yahooLimiter.acquire();
    const rssUrl = `https://feeds.finance.yahoo.com/rss/2.0/headline?s=${ticker}&region=US&lang=en-US`;
    const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' };
    const rssRes = await fetch(rssUrl, { headers });
    if (!rssRes.ok) { console.error(`Yahoo RSS fetch failed: ${rssRes.status}`); return []; }
    const rssText = await rssRes.text();
    const news = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    const titleRegex = /<title><!\[CDATA\[(.*?)\]\]><\/title>|<title>(.*?)<\/title>/;
    const linkRegex = /<link>(.*?)<\/link>/;
    const pubDateRegex = /<pubDate>(.*?)<\/pubDate>/;
    const descRegex = /<description><!\[CDATA\[(.*?)\]\]><\/description>|<description>(.*?)<\/description>/;
    let match;
    while ((match = itemRegex.exec(rssText)) !== null) {
      const item = match[1];
      const titleMatch = titleRegex.exec(item);
      const title = titleMatch?.[1] || titleMatch?.[2] || '';
      const link = linkRegex.exec(item)?.[1] || '';
      const pubDate = pubDateRegex.exec(item)?.[1] || '';
      const descMatch = descRegex.exec(item);
      const description = descMatch?.[1] || descMatch?.[2] || '';
      if (title) {
        news.push({ title, link, publishedAt: pubDate ? new Date(pubDate).toISOString() : null, description: description.substring(0, 300), source: 'Yahoo Finance' });
      }
    }
    cache.set(cacheKey, news.slice(0, 20), 300000);
    return news.slice(0, 20);
  } catch (e) { console.error(`Yahoo RSS error: ${e.message}`); return []; }
}

// ============================================================================
// FETCH COMPANY DATA - COMPREHENSIVE
// ============================================================================
async function fetchCompanyData(ticker) {
  console.log(`\n📊 Fetching comprehensive data for ${ticker}...`);
  updateStatus('DATA_FETCH', 'Fetching company data', 5, null, `Starting data fetch for ${ticker}`);
  const startFetch = Date.now();

  console.log("   SEC EDGAR Filings & Financial Data...");
  const secData = await fetchSECFilings(ticker);
  const secFinancials = extractSECFinancials(secData.companyFacts);

  console.log("   Yahoo Finance News...");
  const yahooNews = await fetchYahooFinanceNews(ticker);

  console.log("   Company Profile...");
  const [profile, peers, recommendations, priceTarget] = await Promise.all([
    finnhubGet(`stock/profile2?symbol=${ticker}`),
    finnhubGet(`stock/peers?symbol=${ticker}`),
    finnhubGet(`stock/recommendation?symbol=${ticker}`),
    finnhubGet(`stock/price-target?symbol=${ticker}`)
  ]);

  console.log("   Financial Metrics...");
  const [basicFinancials, earnings, revenueEstimates] = await Promise.all([
    finnhubGet(`stock/metric?symbol=${ticker}&metric=all`),
    finnhubGet(`stock/earnings?symbol=${ticker}`),
    finnhubGet(`stock/revenue-estimate?symbol=${ticker}`)
  ]);

  console.log("   Insider Trading Data...");
  const [insiderTransactions, insiderSentiment] = await Promise.all([
    finnhubGet(`stock/insider-transactions?symbol=${ticker}`),
    finnhubGet(`stock/insider-sentiment?symbol=${ticker}`)
  ]);

  console.log("   Current Quote...");
  const quote = await finnhubGet(`quote?symbol=${ticker}`);

  console.log("   Analyst Actions...");
  const upgradeDowngrade = await finnhubGet(`stock/upgrade-downgrade?symbol=${ticker}`);

  console.log("   Earnings Calendar...");
  const earningsCalendar = await finnhubGet(`calendar/earnings?symbol=${ticker}`);

  const fetchDuration = ((Date.now() - startFetch) / 1000).toFixed(1);
  console.log(`\n✅ Company data fetch complete in ${fetchDuration}s`);

  return {
    ticker, timestamp: new Date().toISOString(),
    secCompanyInfo: secData.companyInfo,
    profile: {
      name: secData.companyInfo?.name || profile?.name || ticker,
      ticker: ticker, exchange: profile?.exchange,
      industry: secData.companyInfo?.sicDescription || profile?.finnhubIndustry,
      sector: profile?.sector, country: profile?.country,
      marketCap: profile?.marketCapitalization, sharesOutstanding: profile?.shareOutstanding,
      logo: profile?.logo, weburl: secData.companyInfo?.website || profile?.weburl,
      ipo: profile?.ipo, description: profile?.description,
      cik: secData.companyInfo?.cik, sic: secData.companyInfo?.sic,
      sicDescription: secData.companyInfo?.sicDescription,
      fiscalYearEnd: secData.companyInfo?.fiscalYearEnd,
      stateOfIncorporation: secData.companyInfo?.stateOfIncorporation,
      businessAddress: secData.companyInfo?.businessAddress
    },
    quote: {
      currentPrice: quote?.c, change: quote?.d, changePercent: quote?.dp,
      high: quote?.h, low: quote?.l, open: quote?.o, previousClose: quote?.pc, timestamp: quote?.t
    },
    secFinancials: secFinancials,
    financials: {
      peRatio: basicFinancials?.metric?.peNormalizedAnnual, peTTM: basicFinancials?.metric?.peTTM,
      pbRatio: basicFinancials?.metric?.pbAnnual, psRatio: basicFinancials?.metric?.psAnnual,
      evEbitda: basicFinancials?.metric?.evToEbitda,
      grossMargin: basicFinancials?.metric?.grossMarginTTM, operatingMargin: basicFinancials?.metric?.operatingMarginTTM,
      netMargin: basicFinancials?.metric?.netMarginTTM, roe: basicFinancials?.metric?.roeTTM,
      roa: basicFinancials?.metric?.roaTTM, roic: basicFinancials?.metric?.roicTTM,
      revenueGrowth: basicFinancials?.metric?.revenueGrowthTTMYoy, epsGrowth: basicFinancials?.metric?.epsGrowthTTMYoy,
      currentRatio: basicFinancials?.metric?.currentRatioAnnual, quickRatio: basicFinancials?.metric?.quickRatioAnnual,
      debtToEquity: basicFinancials?.metric?.totalDebtToEquityAnnual, debtToAssets: basicFinancials?.metric?.totalDebtToTotalAssetAnnual,
      dividendYield: basicFinancials?.metric?.dividendYieldIndicatedAnnual, payoutRatio: basicFinancials?.metric?.payoutRatioAnnual,
      eps: basicFinancials?.metric?.epsAnnual, epsTTM: basicFinancials?.metric?.epsTTM,
      bookValuePerShare: basicFinancials?.metric?.bookValuePerShareAnnual,
      week52High: basicFinancials?.metric?.['52WeekHigh'], week52Low: basicFinancials?.metric?.['52WeekLow'],
      week52HighDate: basicFinancials?.metric?.['52WeekHighDate'], week52LowDate: basicFinancials?.metric?.['52WeekLowDate'],
      beta: basicFinancials?.metric?.beta
    },
    earnings: {
      history: (earnings || []).slice(0, 8).map(e => ({ period: e.period, actual: e.actual, estimate: e.estimate, surprise: e.surprise, surprisePercent: e.surprisePercent })),
      beatRate: calculateBeatRate(earnings), avgSurprise: calculateAvgSurprise(earnings)
    },
    estimates: {
      revenue: revenueEstimates,
      priceTarget: { targetHigh: priceTarget?.targetHigh, targetLow: priceTarget?.targetLow, targetMean: priceTarget?.targetMean, targetMedian: priceTarget?.targetMedian, numberOfAnalysts: priceTarget?.numberOfAnalysts }
    },
    recommendations: {
      current: recommendations?.[0], trend: recommendations?.slice(0, 4),
      buyCount: recommendations?.[0]?.buy, holdCount: recommendations?.[0]?.hold, sellCount: recommendations?.[0]?.sell,
      strongBuyCount: recommendations?.[0]?.strongBuy, strongSellCount: recommendations?.[0]?.strongSell
    },
    insiders: {
      transactions: (insiderTransactions?.data || []).slice(0, 20).map(t => ({ name: t.name, share: t.share, change: t.change, transactionDate: t.transactionDate, transactionType: t.transactionType, transactionPrice: t.transactionPrice })),
      sentiment: insiderSentiment?.data,
      netBuying: calculateNetInsiderBuying(insiderTransactions?.data)
    },
    peers: peers || [],
    news: yahooNews.map(n => ({ headline: n.title, summary: n.description || '', source: n.source || 'Yahoo Finance', datetime: n.publishedAt, url: n.link })),
    secFilings: secData.filings || [],
    analystActions: (upgradeDowngrade || []).slice(0, 10).map(a => ({ symbol: a.symbol, firm: a.company, action: a.action, fromGrade: a.fromGrade, toGrade: a.toGrade, date: new Date(a.gradeTime * 1000).toISOString().split('T')[0] })),
    nextEarnings: earningsCalendar?.earningsCalendar?.find(e => e.symbol === ticker)
  };
}

function calculateBeatRate(earnings) {
  if (!earnings || earnings.length === 0) return null;
  const beats = earnings.filter(e => e.actual > e.estimate).length;
  return (beats / earnings.length * 100).toFixed(0);
}

function calculateAvgSurprise(earnings) {
  if (!earnings || earnings.length === 0) return null;
  const sum = earnings.reduce((acc, e) => acc + (e.surprisePercent || 0), 0);
  return (sum / earnings.length).toFixed(2);
}

function calculateNetInsiderBuying(transactions) {
  if (!transactions || transactions.length === 0) return { net: 0, buys: 0, sells: 0 };
  let buys = 0, sells = 0;
  transactions.forEach(t => {
    if (t.transactionType === 'P' || t.change > 0) buys += Math.abs(t.change || 0);
    if (t.transactionType === 'S' || t.change < 0) sells += Math.abs(t.change || 0);
  });
  return { net: buys - sells, buys, sells };
}

// ============================================================================
// LEGAL & CONTEXT FRAMEWORK
// ============================================================================
const LEGAL_CONTEXT = `
================================================================================
SYSTEM INSTRUCTION: COMPANY ANALYSIS TASK
================================================================================

You are a SENIOR EQUITY RESEARCH ANALYST writing institutional-grade company analysis.
This content is equivalent to what Goldman Sachs, Morgan Stanley, or JP Morgan publish.

YOUR ROLE: Lead equity analyst / company specialist
YOUR OUTPUT: Investment-grade company research report

CONTENT TYPE:
- This IS: Professional equity research, fundamental analysis
- This is NOT: Investment advice or recommendations to buy/sell

LANGUAGE: Output in ENGLISH only.

================================================================================
`;

const MASTER_WRITING_GUIDE = `
FINOTAUR COMPANY ANALYSIS STANDARD v2.0 - Insider Intel

===============================================================================
WRITING PRINCIPLES
===============================================================================

1. CLARITY OVER COMPLEXITY
   - Write as if the reader will only read one page
   - Every claim must include a number or fact
   - Avoid marketing language - write reality

2. EVERY CLAIM NEEDS EVIDENCE
   - NOT "the company is growing" → "Revenue grew 23% YoY to $4.5B"
   - NOT "attractive valuation" → "P/E 15x vs. sector average 22x"
   - NOT "strong management" → "CEO drove 40% revenue growth over 3 years"

3. STRUCTURE OVER STYLE
   - Each section stands alone
   - Don't repeat information between sections
   - Use consistent formatting throughout

4. FORMATTING
   - All headers in English
   - Numbers: $4.5B, 23%, 15x
   - Currency: $ for USD

===============================================================================
BANNED PHRASES
===============================================================================

❌ "represents an opportunity"
❌ "significant potential"
❌ "we expect"
❌ "in our view"
❌ "it is possible that..."
❌ "positive trend"

✅ USE INSTEAD:
- "Revenue grew X%"
- "Operating margin stands at Y%"
- "Valuation reflects Z"
- "The key risk is..."

===============================================================================
`;

// ============================================================================
// AGENT DEFINITIONS - COMPANY ANALYSIS (ENGLISH)
// ============================================================================

const createExecutiveSummaryAgent = () => new Agent({
  name: "Executive Summary",
  instructions: `${LEGAL_CONTEXT}

You write the Executive Summary - the most important page in the report.
If the reader only reads one page - this is it.

WORD LIMIT: 300 words

OUTPUT FORMAT:

Executive Summary
═══════════════════════════════════════════════════════════════════════════════

Company in One Sentence
────────────────────────────────────────
[What the company actually does, no buzzwords]

Why It's Interesting Now
────────────────────────────────────────
[The specific trigger that makes this relevant today]

Core Investment Thesis
────────────────────────────────────────
[BULLISH / BEARISH / NEUTRAL]
[2-3 sentences explaining why]

Key Competitive Advantages
────────────────────────────────────────
1. [Advantage + number that proves it]
2. [Advantage + number that proves it]
3. [Advantage + number that proves it]

Material Risks
────────────────────────────────────────
1. [Risk + what happens if it materializes]
2. [Risk + what happens if it materializes]

Investor Fit
────────────────────────────────────────
[Long-term investor / Trader / Not suitable now + brief explanation]

═══════════════════════════════════════════════════════════════════════════════

CRITICAL RULES:
- Every claim must include a number
- Don't use words like "potential", "might", "in our view"
- Write as if explaining to a sophisticated investor friend
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1200 }
});

const createBusinessRealityAgent = () => new Agent({
  name: "Business Reality",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "What the Company Actually Does" section - not the pitch, the reality.

WORD LIMIT: 400 words

OUTPUT FORMAT:

What the Company Actually Does
═══════════════════════════════════════════════════════════════════════════════

The Actual Product
────────────────────────────────────────
[Simple description of what the company sells]
[Who they sell to]
[How the sales process works]

The Real Customers
────────────────────────────────────────
[Customer breakdown - Enterprise / SMB / Consumer]
[Customer concentration - dependent on large customer?]
[Customer retention rate if relevant]

True Revenue Source
────────────────────────────────────────
[Recurring vs One-time]
[Pricing model]
[Key revenue unit - ARPU, ACV, etc.]

Where People Misunderstand
────────────────────────────────────────
[The marketing narrative]
[The reality]
[Why this matters for investors]

═══════════════════════════════════════════════════════════════════════════════

CRITICAL: Strip away "marketing narrative" from economic understanding. Focus on reality.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1500 }
});

const createRevenueMapAgent = () => new Agent({
  name: "Revenue Map",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Revenue & Profitability Map" - where the money actually works.

WORD LIMIT: 350 words

OUTPUT FORMAT:

Revenue & Profitability Map
═══════════════════════════════════════════════════════════════════════════════

Revenue Breakdown
────────────────────────────────────────

By Product/Segment:
[Product 1]: $X (Y% of total) — [Growing/Flat/Declining]
[Product 2]: $X (Y% of total) — [Growing/Flat/Declining]

By Geography:
[Region 1]: $X (Y% of total)
[Region 2]: $X (Y% of total)

Customer Concentration:
Top 10 customers: X% of revenue
Largest customer: Y% of revenue

Profitability by Segment
────────────────────────────────────────
[Segment 1]: Gross margin X%
[Segment 2]: Gross margin Y%

What's Growing, What's Declining
────────────────────────────────────────
📈 Growing: [Segments with growth + rate]
📉 Declining: [Segments declining + rate]
➡️ Flat: [Stable segments]

Where the Money Actually Works
────────────────────────────────────────
[One paragraph summarizing - where does the company actually profit vs where does it just look good]

═══════════════════════════════════════════════════════════════════════════════
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.4, maxTokens: 1200 }
});

const createGrowthDriversAgent = () => new Agent({
  name: "Growth Drivers",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Real Growth Drivers" section - what actually makes revenue grow.

WORD LIMIT: 350 words

OUTPUT FORMAT:

Real Growth Drivers
═══════════════════════════════════════════════════════════════════════════════

Growth Sources
────────────────────────────────────────

🔹 Price: [Is there pricing power? What happened in the last 12 months?]

🔹 Volume: [Are customer/unit counts growing? By how much?]

🔹 New Products: [What launched? Revenue contribution?]

🔹 New Markets: [Which markets entered? What's the potential?]

Market-Dependent vs Management-Controlled
────────────────────────────────────────
Market-dependent (outside management control):
- [Factor 1]
- [Factor 2]

Management-controlled:
- [Factor 1]
- [Factor 2]

Growth Story vs Growth Reality
────────────────────────────────────────
What the company says:
[The official narrative]

What the reality is:
[What actually drives growth + numbers]

═══════════════════════════════════════════════════════════════════════════════

IMPORTANT: Differentiate between "growth story" and "real growth". Be skeptical.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1200 }
});

const createCompetitionAgent = () => new Agent({
  name: "Competition Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Competition & Positioning" section - where the company stands vs competitors.

WORD LIMIT: 400 words

OUTPUT FORMAT:

Competition & Positioning
═══════════════════════════════════════════════════════════════════════════════

The Real Competitors
────────────────────────────────────────
[Not just what the company presents - who actually competes for the same customers]

Competitor 1: [Name]
- Size: $X revenue
- Key advantage: [What]
- Key weakness: [What]

Competitor 2: [Name]
- Size: $X revenue
- Key advantage: [What]
- Key weakness: [What]

Competitor 3: [Name]
- Size: $X revenue
- Key advantage: [What]
- Key weakness: [What]

Where the Company...
────────────────────────────────────────
💪 Stronger: [In what and why]
❌ Weaker: [In what and why]
🔄 Similar to others: [In which aspects]

Moat - Competitive Advantage
────────────────────────────────────────
Moat type: [Network Effects / Switching Costs / Brand / Cost Advantage / None]

Is it real or temporary?
[Explanation + evidence]

Ease of Replication
────────────────────────────────────────
How easy is it to replicate the company? [Easy / Medium / Hard]
What's the main barrier?
[Explanation]

Bottom Line: Is This a Business or a Trend?
────────────────────────────────────────
[One summarizing sentence]

═══════════════════════════════════════════════════════════════════════════════
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1500 }
});

const createManagementAgent = () => new Agent({
  name: "Management Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Management & Insiders" section.

WORD LIMIT: 350 words

OUTPUT FORMAT:

Management & Insiders
═══════════════════════════════════════════════════════════════════════════════

Who Makes Decisions
────────────────────────────────────────
CEO: [Name]
- Background: [Where they came from]
- In role since: [Date]
- Track Record: [Proven successes/failures]

CFO: [Name]
- Background: [Where they came from]
- In role since: [Date]

Management Track Record
────────────────────────────────────────
[What they promised vs what actually happened]
[Specific examples with numbers]

Insider Activity
────────────────────────────────────────
Recent Buys:
[Name] bought X shares at $Y (date)

Recent Sales:
[Name] sold X shares at $Y (date)

Overall Trend: [Buying / Selling / Mixed]

Incentives: How Are They Compensated?
────────────────────────────────────────
[Compensation structure - base, bonus, options]
[What goals are tied to compensation]

Are Their Interests Aligned with Ours?
────────────────────────────────────────
[Yes/No + explanation]
[Red flags if any]

═══════════════════════════════════════════════════════════════════════════════

CRITICAL: Management history matters more than presentations.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1200 }
});

const createFinancialAgent = () => new Agent({
  name: "Financial Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Numbers That Actually Matter" section - deep financial analysis.
Use the SEC filing data as the primary source for historical financials.

WORD LIMIT: 450 words

OUTPUT FORMAT:

The Numbers That Actually Matter
═══════════════════════════════════════════════════════════════════════════════

Revenue
────────────────────────────────────────
Annual Revenue: $X
YoY Growth: X%
Quarterly Run Rate: $X/quarter
Stability: [High/Medium/Low]
Revenue Quality: [Recurring X% / One-time Y%]

Margins
────────────────────────────────────────
Gross Margin: X% (vs industry avg Y%)
Operating Margin: X% (vs industry avg Y%)
Net Margin: X%
Trend: [Improving/Stable/Deteriorating] + explanation

Cash Flow vs Accounting Profit
────────────────────────────────────────
Net Income: $X
Operating Cash Flow: $X
Free Cash Flow: $X
Gap: [Explanation if there's a gap]

Debt & Liquidity
────────────────────────────────────────
Total Debt: $X
Cash: $X
Net Debt: $X
Debt/EBITDA: Xx
Debt Service Capacity: [Strong/Medium/Weak]

Is Growth "Burning Cash"?
────────────────────────────────────────
[Yes/No]
[Explanation with numbers - how much does it cost to generate growth]

Red Flags
────────────────────────────────────────
⚠️ [Accounting distortions if any]
⚠️ [Unexplained jumps]
⚠️ [Changes in accounting policy]

═══════════════════════════════════════════════════════════════════════════════

IMPORTANT: Look for distortions, accounting games, and unexplained jumps.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.4, maxTokens: 1500 }
});

const createValuationAgent = () => new Agent({
  name: "Valuation Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Valuation & Market Expectations" section.

WORD LIMIT: 400 words

OUTPUT FORMAT:

Valuation & Market Expectations
═══════════════════════════════════════════════════════════════════════════════

Current Market Pricing
────────────────────────────────────────
Current Price: $X
Market Cap: $X
Enterprise Value: $X

Multiples:
P/E: Xx (vs industry Yx)
P/S: Xx (vs industry Yx)
EV/EBITDA: Xx (vs industry Yx)
P/FCF: Xx

What the Market Expects to Happen
────────────────────────────────────────
[Reverse calculation - what needs to happen to justify current price]
- Required growth: X% per year
- Required margin: X%
- Is this realistic? [Yes/No + explanation]

"Everything Goes Well" Scenario
────────────────────────────────────────
What needs to happen:
[List of conditions]

Value in this case: $X (+Y% from today)

"Something Breaks" Scenario
────────────────────────────────────────
What could go wrong:
[List of conditions]

Value in this case: $X (-Y% from today)

Where's the Asymmetry
────────────────────────────────────────
Upside: +X%
Downside: -Y%
Risk/Reward: [Attractive / Neutral / Unattractive]

Not "Cheap or Expensive" - But "Why"
────────────────────────────────────────
[Paragraph explaining the logic behind the valuation]

═══════════════════════════════════════════════════════════════════════════════
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1400 }
});

const createCatalystsAgent = () => new Agent({
  name: "Catalysts Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "What Moves the Stock Short-Medium Term" section.

WORD LIMIT: 300 words

OUTPUT FORMAT:

What Moves the Stock Short-Medium Term
═══════════════════════════════════════════════════════════════════════════════

Upcoming Earnings Report
────────────────────────────────────────
Date: [Date]
Expectations: EPS $X, Revenue $X
What to Watch: [The most important number to track]
Expected Reaction: [What would cause rise/fall]

Regulatory
────────────────────────────────────────
[Expected regulatory decisions]
[Potential impact]

Relevant Macro
────────────────────────────────────────
[Which macro factors affect the company]
[Current situation]

Sentiment
────────────────────────────────────────
Short Interest: X% (vs avg Y%)
Days to Cover: X
Analyst Sentiment: X buys, Y holds, Z sells
Trend: [Improving/Deteriorating]

Flow & Positioning
────────────────────────────────────────
[Is there significant recent flow?]
[Institutional positions - buying/selling?]

Calendar Events
────────────────────────────────────────
📅 [Date]: [Event] — [Expected impact]
📅 [Date]: [Event] — [Expected impact]

═══════════════════════════════════════════════════════════════════════════════

IMPORTANT: This is where traders get value, not just investors.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1100 }
});

const createRisksAgent = () => new Agent({
  name: "Risk Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Real Risks" section - not legal boilerplate, actual risks.

WORD LIMIT: 350 words

OUTPUT FORMAT:

Real Risks
═══════════════════════════════════════════════════════════════════════════════

Business Model Risk
────────────────────────────────────────
[Can the business model break? How?]
Probability: [Low/Medium/High]
Impact: [Minor/Medium/Severe]

Customer/Supplier Dependency
────────────────────────────────────────
[Is there significant dependency? On whom?]
What happens if they leave?

Regulatory Risk
────────────────────────────────────────
[What regulation could hurt them?]
[What's the probability?]

Competitive Risk
────────────────────────────────────────
[Who could hurt them? How?]
[How fast could it happen?]

Leverage/Liquidity Risk
────────────────────────────────────────
[Is there a debt problem? Liquidity?]
[What happens in an extreme scenario?]

Narrative Risk
────────────────────────────────────────
[What story does the market believe?]
[What happens if the story breaks?]
Historical example: [Similar company this happened to]

The Risk Nobody's Talking About
────────────────────────────────────────
[One risk the market isn't pricing]

═══════════════════════════════════════════════════════════════════════════════

CRITICAL: If there are no risks - the report isn't serious. There are always risks.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1200 }
});

const createScenarioAgent = () => new Agent({
  name: "Scenario Analysis",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Forward Scenarios" section - Base, Bull, Bear.

WORD LIMIT: 400 words

OUTPUT FORMAT:

Forward Scenarios
═══════════════════════════════════════════════════════════════════════════════

Base Case (Probability: X%)
────────────────────────────────────────
What needs to happen:
- [Condition 1]
- [Condition 2]
- [Condition 3]

Expected numbers:
- Revenue: $X (Y% growth)
- EPS: $X
- Operating margin: X%

Target value: $X per share (+Y% from today)

Bull Case (Probability: X%)
────────────────────────────────────────
What needs to happen:
- [Condition 1]
- [Condition 2]
- [Condition 3]

Expected numbers:
- Revenue: $X (Y% growth)
- EPS: $X
- Operating margin: X%

Target value: $X per share (+Y% from today)

Bear Case (Probability: X%)
────────────────────────────────────────
What needs to happen:
- [Condition 1]
- [Condition 2]
- [Condition 3]

Expected numbers:
- Revenue: $X (Y% growth)
- EPS: $X
- Operating margin: X%

Target value: $X per share (Y% from today)

Expected Value
────────────────────────────────────────
Weighted average: $X per share
vs current price: $X
Gap: +/-X%

═══════════════════════════════════════════════════════════════════════════════

NOTE: This shows analyst thinking, not gambler thinking.
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1400 }
});

const createVerdictAgent = () => new Agent({
  name: "Final Verdict",
  instructions: `${LEGAL_CONTEXT}
${MASTER_WRITING_GUIDE}

You write the "Summary & Clear Verdict" section - the reader must leave with a position.

WORD LIMIT: 250 words

OUTPUT FORMAT:

Summary & Verdict
═══════════════════════════════════════════════════════════════════════════════

Is This an Opportunity?
────────────────────────────────────────
[Yes / No / It Depends]

[2-3 sentences summarizing the logic]

Who It's For
────────────────────────────────────────
✅ Suitable for: [What type of investor + why]
❌ Not suitable for: [What type of investor + why]

First Sign We're Wrong
────────────────────────────────────────
[What would be the first indicator that our thesis is wrong?]

What to Monitor Going Forward
────────────────────────────────────────
📊 Number to track: [The most important metric]
📅 Date to remember: [The next catalyst]
💰 Price level: [Entry / Exit price]

The Bottom Line
────────────────────────────────────────
[One sentence that sums it all up]

═══════════════════════════════════════════════════════════════════════════════

CRITICAL: The reader must leave with a position - even if it's "don't act".
`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 1000 }
});

const createDataValidatorAgent = () => new Agent({
  name: "Data Validator",
  instructions: `${LEGAL_CONTEXT}
You validate the data and identify gaps.
OUTPUT JSON:
{
  "dataQuality": "GOOD/ACCEPTABLE/ISSUES",
  "missingData": ["list of missing items"],
  "dataIssues": ["list of potential issues"],
  "recommendations": ["what to mention in report if data is missing"]
}`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.2, maxTokens: 500 }
});

const createStoryArchitectAgent = () => new Agent({
  name: "Story Architect",
  instructions: `${LEGAL_CONTEXT}
You identify the company's core investment narrative.
OUTPUT JSON:
{
  "primaryNarrative": "The main story in one sentence",
  "narrativeType": "Growth / Turnaround / Value / Quality / Fallen Angel / Other",
  "bullCase": "Why bulls are bullish in 2 sentences",
  "bearCase": "Why bears are bearish in 2 sentences",
  "keyQuestion": "The one question that determines the outcome",
  "investmentThesis": "BULLISH / BEARISH / NEUTRAL",
  "thesisExplanation": "2-3 sentences explaining the thesis"
}`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.5, maxTokens: 700 }
});

const createCoherenceCheckerAgent = () => new Agent({
  name: "Coherence Checker",
  instructions: `${LEGAL_CONTEXT}
Check report coherence:
1. Are all sections present
2. Are there contradictions between sections
3. Is there unnecessary repetition
4. Is data consistent
OUTPUT JSON:
{
  "coherenceScore": 0-100,
  "issues": ["list of issues"],
  "contradictions": ["list of contradictions"],
  "fixes": ["suggested fixes"]
}`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.2, maxTokens: 700 }
});

const createFinalQAAgent = () => new Agent({
  name: "Final QA",
  instructions: `${LEGAL_CONTEXT}
Give a final score to the report on 10 criteria:
1. Executive Summary (Is it clear? With numbers?)
2. Business Understanding (Does it explain what the company actually does?)
3. Revenue Map (Is it clear where the money is?)
4. Growth Drivers (Does it distinguish Story from Reality?)
5. Competition (Does it identify real competitors?)
6. Management (Does it examine Track Record?)
7. Financials (Does it identify distortions?)
8. Valuation (Does it explain expectations?)
9. Risks (Are there real risks?)
10. Verdict (Is there a clear position?)

OUTPUT:
FINOTAUR QA SCORECARD
==========================
1. Executive Summary: X/10
2. Business Understanding: X/10
3. Revenue Map: X/10
4. Growth Drivers: X/10
5. Competition: X/10
6. Management: X/10
7. Financials: X/10
8. Valuation: X/10
9. Risks: X/10
10. Verdict: X/10
==========================
TOTAL: XX/100
VERDICT: PASS/FAIL`,
  model: AGENT_MODEL,
  modelSettings: { temperature: 0.2, maxTokens: 800 }
});

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
async function runWithRetry(runner, agent, messages, agentName = "", retries = 0) {
  try {
    return await runner.run(agent, messages);
  } catch (error) {
    const isRateLimit = error.message?.includes('429') || error.message?.includes('Rate limit');
    if (isRateLimit && retries < MAX_RETRY_ATTEMPTS) {
      const waitTime = 15000 * (retries + 1);
      console.log(`   Rate limit on ${agentName}, waiting ${waitTime/1000}s...`);
      await sleep(waitTime);
      return runWithRetry(runner, agent, messages, agentName, retries + 1);
    }
    throw error;
  }
}

// ============================================================================
// CONTEXT BUILDERS
// ============================================================================
function buildCompanyContext(companyData) {
  const profile = companyData.profile || {};
  const quote = companyData.quote || {};
  const fin = companyData.financials || {};
  const secFin = companyData.secFinancials || {};
  const earn = companyData.earnings || {};
  const rec = companyData.recommendations || {};
  const ins = companyData.insiders || {};
  
  const formatNum = (n, decimals = 2) => n != null ? Number(n).toFixed(decimals) : 'N/A';
  const formatPct = (n) => n != null ? `${Number(n).toFixed(2)}%` : 'N/A';
  const formatMoney = (n) => {
    if (n == null) return 'N/A';
    if (n >= 1e12) return `$${(n/1e12).toFixed(2)}T`;
    if (n >= 1e9) return `$${(n/1e9).toFixed(2)}B`;
    if (n >= 1e6) return `$${(n/1e6).toFixed(2)}M`;
    return `$${n.toFixed(0)}`;
  };
  const formatSECValue = (item) => {
    if (!item) return 'N/A';
    return `${formatMoney(item.val)} (${item.end}, filed ${item.filed})`;
  };

  return `
================================================================================
COMPANY DATA - ${companyData.ticker}
================================================================================

PROFILE
────────────────────────────────────────
Name: ${profile.name}
Ticker: ${profile.ticker}
Exchange: ${profile.exchange}
Sector: ${profile.sector}
Industry: ${profile.industry}
Country: ${profile.country}
IPO Date: ${profile.ipo}
Website: ${profile.weburl}
Market Cap: ${formatMoney(profile.marketCap * 1e6)}
Shares Outstanding: ${formatNum(profile.sharesOutstanding, 0)}M

SEC COMPANY INFO
────────────────────────────────────────
CIK: ${profile.cik || 'N/A'}
SIC Code: ${profile.sic || 'N/A'} (${profile.sicDescription || 'N/A'})
Fiscal Year End: ${profile.fiscalYearEnd || 'N/A'}
State of Incorporation: ${profile.stateOfIncorporation || 'N/A'}

CURRENT QUOTE
────────────────────────────────────────
Price: $${formatNum(quote.currentPrice)}
Change: $${formatNum(quote.change)} (${formatPct(quote.changePercent)})
Open: $${formatNum(quote.open)}
High: $${formatNum(quote.high)}
Low: $${formatNum(quote.low)}
Previous Close: $${formatNum(quote.previousClose)}

================================================================================
SEC FINANCIAL DATA (From 10-K/10-Q Filings)
================================================================================

INCOME STATEMENT (From SEC Filings)
────────────────────────────────────────
Revenue: ${formatSECValue(secFin.revenue)}
Revenue History:
${secFin.revenueHistory?.map(r => `  ${r.period}: ${formatMoney(r.value)}`).join('\n') || '  N/A'}

Gross Profit: ${formatSECValue(secFin.grossProfit)}
Operating Income: ${formatSECValue(secFin.operatingIncome)}
Net Income: ${formatSECValue(secFin.netIncome)}
Net Income History:
${secFin.netIncomeHistory?.map(r => `  ${r.period}: ${formatMoney(r.value)}`).join('\n') || '  N/A'}

EPS (Basic): ${secFin.eps?.val ? `$${formatNum(secFin.eps.val)}` : 'N/A'}
EPS (Diluted): ${secFin.epsDiluted?.val ? `$${formatNum(secFin.epsDiluted.val)}` : 'N/A'}

BALANCE SHEET (From SEC Filings)
────────────────────────────────────────
Total Assets: ${formatSECValue(secFin.totalAssets)}
Total Liabilities: ${formatSECValue(secFin.totalLiabilities)}
Stockholders' Equity: ${formatSECValue(secFin.stockholdersEquity)}
Cash & Equivalents: ${formatSECValue(secFin.cashAndEquivalents)}
Long-term Debt: ${formatSECValue(secFin.longTermDebt)}

CASH FLOW (From SEC Filings)
────────────────────────────────────────
Operating Cash Flow: ${formatSECValue(secFin.operatingCashFlow)}
Capital Expenditures: ${formatSECValue(secFin.capitalExpenditures)}

OPERATING EXPENSES (From SEC Filings)
────────────────────────────────────────
R&D Expense: ${formatSECValue(secFin.researchAndDevelopment)}
SG&A Expense: ${formatSECValue(secFin.sgaExpense)}
Cost of Revenue: ${formatSECValue(secFin.costOfRevenue)}

================================================================================
MARKET DATA (From Finnhub)
================================================================================

VALUATION METRICS
────────────────────────────────────────
P/E Ratio: ${formatNum(fin.peRatio)}x
P/E TTM: ${formatNum(fin.peTTM)}x
P/B Ratio: ${formatNum(fin.pbRatio)}x
P/S Ratio: ${formatNum(fin.psRatio)}x
EV/EBITDA: ${formatNum(fin.evEbitda)}x

PROFITABILITY
────────────────────────────────────────
Gross Margin: ${formatPct(fin.grossMargin)}
Operating Margin: ${formatPct(fin.operatingMargin)}
Net Margin: ${formatPct(fin.netMargin)}
ROE: ${formatPct(fin.roe)}
ROA: ${formatPct(fin.roa)}
ROIC: ${formatPct(fin.roic)}

GROWTH
────────────────────────────────────────
Revenue Growth YoY: ${formatPct(fin.revenueGrowth)}
EPS Growth YoY: ${formatPct(fin.epsGrowth)}

FINANCIAL HEALTH
────────────────────────────────────────
Current Ratio: ${formatNum(fin.currentRatio)}
Quick Ratio: ${formatNum(fin.quickRatio)}
Debt/Equity: ${formatNum(fin.debtToEquity)}
Debt/Assets: ${formatPct(fin.debtToAssets)}

52-WEEK RANGE
────────────────────────────────────────
52W High: $${formatNum(fin.week52High)} (${fin.week52HighDate || 'N/A'})
52W Low: $${formatNum(fin.week52Low)} (${fin.week52LowDate || 'N/A'})
Current vs High: ${fin.week52High ? formatPct((quote.currentPrice / fin.week52High - 1) * 100) : 'N/A'}
Current vs Low: ${fin.week52Low ? formatPct((quote.currentPrice / fin.week52Low - 1) * 100) : 'N/A'}
Beta: ${formatNum(fin.beta)}

EARNINGS HISTORY (Last 8 Quarters)
────────────────────────────────────────
${earn.history?.map(e => `${e.period}: Actual $${formatNum(e.actual)} vs Est $${formatNum(e.estimate)} (${e.surprise > 0 ? '+' : ''}${formatPct(e.surprisePercent)} surprise)`).join('\n') || 'No earnings data'}

Beat Rate: ${earn.beatRate || 'N/A'}%
Avg Surprise: ${earn.avgSurprise || 'N/A'}%

ANALYST PRICE TARGET
────────────────────────────────────────
Target High: $${formatNum(companyData.estimates?.priceTarget?.targetHigh)}
Target Mean: $${formatNum(companyData.estimates?.priceTarget?.targetMean)}
Target Median: $${formatNum(companyData.estimates?.priceTarget?.targetMedian)}
Target Low: $${formatNum(companyData.estimates?.priceTarget?.targetLow)}
Number of Analysts: ${companyData.estimates?.priceTarget?.numberOfAnalysts || 'N/A'}
Upside to Mean: ${companyData.estimates?.priceTarget?.targetMean && quote.currentPrice ? formatPct((companyData.estimates.priceTarget.targetMean / quote.currentPrice - 1) * 100) : 'N/A'}

ANALYST RECOMMENDATIONS
────────────────────────────────────────
Strong Buy: ${rec.strongBuyCount || 0}
Buy: ${rec.buyCount || 0}
Hold: ${rec.holdCount || 0}
Sell: ${rec.sellCount || 0}
Strong Sell: ${rec.strongSellCount || 0}

INSIDER ACTIVITY
────────────────────────────────────────
Net Insider Buying: ${ins.netBuying?.net > 0 ? 'BUYING' : ins.netBuying?.net < 0 ? 'SELLING' : 'NEUTRAL'}
Total Buys: ${ins.netBuying?.buys?.toLocaleString() || 0} shares
Total Sells: ${ins.netBuying?.sells?.toLocaleString() || 0} shares
Net: ${ins.netBuying?.net?.toLocaleString() || 0} shares

Recent Transactions:
${ins.transactions?.slice(0, 5).map(t => `${t.transactionDate}: ${t.name} ${t.transactionType === 'P' ? 'BOUGHT' : 'SOLD'} ${Math.abs(t.change).toLocaleString()} shares @ $${formatNum(t.transactionPrice)}`).join('\n') || 'No recent transactions'}

PEERS
────────────────────────────────────────
${companyData.peers?.slice(0, 8).join(', ') || 'No peer data'}

RECENT ANALYST ACTIONS
────────────────────────────────────────
${companyData.analystActions?.slice(0, 5).map(a => `${a.date}: ${a.firm} - ${a.action} (${a.fromGrade || 'N/A'} → ${a.toGrade})`).join('\n') || 'No recent analyst actions'}

SEC FILINGS (Recent)
────────────────────────────────────────
${companyData.secFilings?.slice(0, 10).map(f => `${f.filingDate}: ${f.form} - ${f.url}`).join('\n') || 'No SEC filings data'}

RECENT NEWS (Yahoo Finance)
────────────────────────────────────────
${companyData.news?.slice(0, 10).map(n => `• ${n.headline} (${n.source}, ${n.datetime ? new Date(n.datetime).toLocaleDateString() : 'N/A'})`).join('\n') || 'No recent news'}

UPCOMING EARNINGS
────────────────────────────────────────
Date: ${companyData.nextEarnings?.date || 'N/A'}
EPS Estimate: $${formatNum(companyData.nextEarnings?.epsEstimate)}
Revenue Estimate: ${formatMoney(companyData.nextEarnings?.revenueEstimate)}

================================================================================
`;
}

function buildStoryContext(storyData) {
  return `
================================================================================
INVESTMENT NARRATIVE
================================================================================

Primary Story: ${storyData?.primaryNarrative || 'N/A'}
Narrative Type: ${storyData?.narrativeType || 'N/A'}

Bull Case: ${storyData?.bullCase || 'N/A'}
Bear Case: ${storyData?.bearCase || 'N/A'}

Key Question: ${storyData?.keyQuestion || 'N/A'}

Investment Thesis: ${storyData?.investmentThesis || 'N/A'}
${storyData?.thesisExplanation || ''}

================================================================================
`;
}

// ============================================================================
// MAIN WORKFLOW
// ============================================================================
async function runCompanyAnalysisWorkflow(ticker) {
  resetStatus();
  workflowStatus.isRunning = true;
  workflowStatus.startTime = Date.now();
  workflowStatus.companyTicker = ticker;
  
  console.log(`\n${'═'.repeat(70)}`);
  console.log(`   FINOTAUR COMPANY ANALYSIS v2.0`);
  console.log(`   Analyzing: ${ticker}`);
  console.log(`   Data Sources: SEC EDGAR, Yahoo Finance, Finnhub`);
  console.log(`   ${new Date().toLocaleString()}`);
  console.log(`${'═'.repeat(70)}\n`);
  
  updateStatus('INIT', 'Starting analysis', 1, null, `Starting analysis for ${ticker}`);
  
  const startTime = Date.now();
  const runner = new Runner();
  const outputs = {};

  try {
    // PHASE 1: Data Collection
    console.log("PHASE 1: Data Collection");
    updateStatus('PHASE_1', 'Fetching company data', 5, null, 'Fetching data');
    
    const companyData = await fetchCompanyData(ticker);
    workflowStatus.companyName = companyData.profile?.name || ticker;
    
    const companyContext = buildCompanyContext(companyData);
    
    // PHASE 2: Data Validation & Story Architecture
    console.log("\nPHASE 2: Data Validation & Story Architecture");
    updateStatus('PHASE_2', 'Validating data', 15, null, 'Validating data quality');
    
    const agents = {
      dataValidator: createDataValidatorAgent(),
      storyArchitect: createStoryArchitectAgent(),
      executiveSummary: createExecutiveSummaryAgent(),
      businessReality: createBusinessRealityAgent(),
      revenueMap: createRevenueMapAgent(),
      growthDrivers: createGrowthDriversAgent(),
      competition: createCompetitionAgent(),
      management: createManagementAgent(),
      financial: createFinancialAgent(),
      valuation: createValuationAgent(),
      catalysts: createCatalystsAgent(),
      risks: createRisksAgent(),
      scenario: createScenarioAgent(),
      verdict: createVerdictAgent(),
      coherenceChecker: createCoherenceCheckerAgent(),
      finalQA: createFinalQAAgent()
    };
    
    const [validatorResult, storyResult] = await Promise.all([
      runWithRetry(runner, agents.dataValidator, [{ role: "user", content: [{ type: "input_text", text: companyContext }] }], "DataValidator"),
      runWithRetry(runner, agents.storyArchitect, [{ role: "user", content: [{ type: "input_text", text: companyContext }] }], "StoryArchitect")
    ]);
    
    let dataQuality;
    try { dataQuality = JSON.parse(validatorResult.finalOutput); }
    catch { dataQuality = { dataQuality: "ACCEPTABLE" }; }
    
    let storyData;
    try { storyData = JSON.parse(storyResult.finalOutput); }
    catch { storyData = { primaryNarrative: "Company analysis", investmentThesis: "NEUTRAL" }; }
    
    console.log(`   Data Quality: ${dataQuality.dataQuality}`);
    console.log(`   Investment Thesis: ${storyData.investmentThesis}`);
    
    const storyContext = buildStoryContext(storyData);
    const fullContext = `${storyContext}\n\n${companyContext}`;
    
    // PHASE 3: Content Generation
    console.log("\nPHASE 3: Content Generation");
    updateStatus('PHASE_3', 'Generating content', 25, null, 'Starting content generation');
    
    // Batch 1
    console.log("   [Batch 1/4] Executive Summary, Business Reality, Revenue Map...");
    updateStatus('PHASE_3', 'Batch 1: Core sections', 30, 'ExecutiveSummary', 'Writing core sections');
    
    const [execResult, bizResult, revenueResult] = await Promise.all([
      runWithRetry(runner, agents.executiveSummary, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "ExecutiveSummary"),
      runWithRetry(runner, agents.businessReality, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "BusinessReality"),
      runWithRetry(runner, agents.revenueMap, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "RevenueMap")
    ]);
    
    outputs.executiveSummary = execResult.finalOutput;
    outputs.businessReality = bizResult.finalOutput;
    outputs.revenueMap = revenueResult.finalOutput;
    
    await sleep(BATCH_DELAY);
    
    // Batch 2
    console.log("   [Batch 2/4] Growth Drivers, Competition, Management...");
    updateStatus('PHASE_3', 'Batch 2: Growth & Competition', 45, 'GrowthDrivers', 'Writing growth sections');
    
    const [growthResult, compResult, mgmtResult] = await Promise.all([
      runWithRetry(runner, agents.growthDrivers, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "GrowthDrivers"),
      runWithRetry(runner, agents.competition, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Competition"),
      runWithRetry(runner, agents.management, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Management")
    ]);
    
    outputs.growthDrivers = growthResult.finalOutput;
    outputs.competition = compResult.finalOutput;
    outputs.management = mgmtResult.finalOutput;
    
    await sleep(BATCH_DELAY);
    
    // Batch 3
    console.log("   [Batch 3/4] Financial Analysis, Valuation, Catalysts...");
    updateStatus('PHASE_3', 'Batch 3: Financial Analysis', 60, 'Financial', 'Writing financial sections');
    
    const [finResult, valResult, catResult] = await Promise.all([
      runWithRetry(runner, agents.financial, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Financial"),
      runWithRetry(runner, agents.valuation, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Valuation"),
      runWithRetry(runner, agents.catalysts, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Catalysts")
    ]);
    
    outputs.financial = finResult.finalOutput;
    outputs.valuation = valResult.finalOutput;
    outputs.catalysts = catResult.finalOutput;
    
    await sleep(BATCH_DELAY);
    
    // Batch 4
    console.log("   [Batch 4/4] Risks, Scenarios, Final Verdict...");
    updateStatus('PHASE_3', 'Batch 4: Risks & Verdict', 75, 'Risks', 'Writing final sections');
    
    const [risksResult, scenarioResult, verdictResult] = await Promise.all([
      runWithRetry(runner, agents.risks, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Risks"),
      runWithRetry(runner, agents.scenario, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Scenario"),
      runWithRetry(runner, agents.verdict, [{ role: "user", content: [{ type: "input_text", text: fullContext }] }], "Verdict")
    ]);
    
    outputs.risks = risksResult.finalOutput;
    outputs.scenario = scenarioResult.finalOutput;
    outputs.verdict = verdictResult.finalOutput;
    
    // PHASE 4: Quality Assurance
    console.log("\nPHASE 4: Quality Assurance");
    updateStatus('PHASE_4', 'Quality Check', 90, null, 'Running QA');
    
    const draftReport = buildFinalCompanyReport(outputs, companyData, storyData);
    
    const qaResult = await runWithRetry(runner, agents.finalQA, [{ role: "user", content: [{ type: "input_text", text: draftReport }] }], "FinalQA");
    
    let qaScore = 85;
    const scoreMatch = qaResult.finalOutput.match(/TOTAL:\s*(\d+)/);
    if (scoreMatch) qaScore = parseInt(scoreMatch[1]);
    
    const qaPassed = qaScore >= QA_PASS_THRESHOLD;
    console.log(`   QA Score: ${qaScore}/100 (${qaPassed ? 'PASS' : 'NEEDS WORK'})`);
    
    updateStatus('COMPLETE', 'Analysis finished', 100, 'FinalQA', `QA Score: ${qaScore}/100`);
    
    const duration = ((Date.now() - startTime) / 1000).toFixed(1);
    
    console.log(`\n${'═'.repeat(70)}`);
    console.log(`   ANALYSIS COMPLETE - ${duration}s - Score: ${qaScore}/100`);
    console.log(`${'═'.repeat(70)}\n`);
    
    workflowStatus.isRunning = false;
    
    return {
      success: true, ticker,
      companyName: companyData.profile?.name,
      report: draftReport, qaScore, qaPassed,
      qaDetails: qaResult.finalOutput,
      duration: `${duration}s`, version: VERSION, storyData, dataQuality,
      companyData: {
        profile: companyData.profile, quote: companyData.quote,
        financials: companyData.financials, secFinancials: companyData.secFinancials,
        recommendations: companyData.recommendations,
        priceTarget: companyData.estimates?.priceTarget,
        secFilings: companyData.secFilings
      }
    };
    
  } catch (error) {
    console.error("Workflow error:", error);
    workflowStatus.isRunning = false;
    workflowStatus.error = error.message;
    updateStatus('ERROR', 'Workflow failed', workflowStatus.progress, null, `Error: ${error.message}`);
    throw error;
  }
}

// ============================================================================
// REPORT BUILDER
// ============================================================================
function buildFinalCompanyReport(outputs, companyData, storyData) {
  const profile = companyData.profile || {};
  const quote = companyData.quote || {};
  const fin = companyData.financials || {};
  
  const date = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
  });
  
  const formatNum = (n, decimals = 2) => n != null ? Number(n).toFixed(decimals) : 'N/A';
  const formatMoney = (n) => {
    if (n == null) return 'N/A';
    if (n >= 1e12) return `$${(n/1e12).toFixed(2)}T`;
    if (n >= 1e9) return `$${(n/1e9).toFixed(2)}B`;
    if (n >= 1e6) return `$${(n/1e6).toFixed(2)}M`;
    return `$${n.toFixed(0)}`;
  };

  return `
${'═'.repeat(80)}
FINOTAUR
Comprehensive Company Analysis
${'═'.repeat(80)}

${profile.name} (${profile.ticker})
${profile.sector} | ${profile.industry}
${date}

${'─'.repeat(80)}
Key Metrics
${'─'.repeat(80)}

Current Price: $${formatNum(quote.currentPrice)}
Daily Change: ${formatNum(quote.changePercent)}%
Market Cap: ${formatMoney((profile.marketCap || 0) * 1e6)}
P/E Ratio: ${formatNum(fin.peRatio)}x
Operating Margin: ${formatNum(fin.operatingMargin)}%

Data Sources: SEC EDGAR (Financial Statements), Yahoo Finance (News), Finnhub (Market Data)

${'═'.repeat(80)}

${outputs.executiveSummary || ''}

${'═'.repeat(80)}

${outputs.businessReality || ''}

${'═'.repeat(80)}

${outputs.revenueMap || ''}

${'═'.repeat(80)}

${outputs.growthDrivers || ''}

${'═'.repeat(80)}

${outputs.competition || ''}

${'═'.repeat(80)}

${outputs.management || ''}

${'═'.repeat(80)}

${outputs.financial || ''}

${'═'.repeat(80)}

${outputs.valuation || ''}

${'═'.repeat(80)}

${outputs.catalysts || ''}

${'═'.repeat(80)}

${outputs.risks || ''}

${'═'.repeat(80)}

${outputs.scenario || ''}

${'═'.repeat(80)}

${outputs.verdict || ''}

${'═'.repeat(80)}

Disclaimer
${'─'.repeat(80)}

This report is for informational and educational purposes only. It does not constitute investment advice.
Past performance is not indicative of future results. All trading involves significant risk of loss.
Consult with a licensed investment advisor before making investment decisions.

Data Sources: SEC EDGAR filings, Yahoo Finance news, Finnhub market data.

© Finotaur ${new Date().getFullYear()}. All rights reserved.

${'═'.repeat(80)}
`;
}

// ============================================================================
// ROUTES
// ============================================================================

router.get("/workflow-progress", (req, res) => {
  res.json({ success: true, ...getWorkflowStatus() });
});

router.post("/analyze-company", async (req, res) => {
  try {
    const { ticker } = req.body;
    if (!ticker) {
      return res.status(400).json({ success: false, error: "Missing ticker parameter" });
    }
    const result = await runCompanyAnalysisWorkflow(ticker.toUpperCase());
    res.json(result);
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: error.message });
  }
});

router.get("/company-data/:ticker", async (req, res) => {
  try {
    const { ticker } = req.params;
    const companyData = await fetchCompanyData(ticker.toUpperCase());
    res.json({ success: true, data: companyData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/workflow-status", async (req, res) => {
  res.json({
    version: VERSION,
    architecture: "5-Phase, 16-Agent System for Company Analysis",
    standard: "Insider Intel - Institutional Quality",
    dataSources: ["SEC EDGAR (10-K, 10-Q, 8-K filings)", "Yahoo Finance (News)", "Finnhub (Market Data)"],
    sections: [
      "Executive Summary",
      "What the Company Actually Does",
      "Revenue & Profitability Map",
      "Real Growth Drivers",
      "Competition & Positioning",
      "Management & Insiders",
      "The Numbers That Actually Matter",
      "Valuation & Market Expectations",
      "What Moves the Stock",
      "Real Risks",
      "Forward Scenarios",
      "Summary & Verdict"
    ],
    qaThreshold: QA_PASS_THRESHOLD
  });
});

router.post("/clear-cache", (req, res) => {
  cache.clear();
  res.json({ success: true, message: "Cache cleared" });
});

// ============================================================================
// EXPORTS
// ============================================================================

export default router;
export { 
  fetchCompanyData, 
  runCompanyAnalysisWorkflow, 
  getWorkflowStatus, 
  workflowStatus,
  fetchSECFilings,
  fetchYahooFinanceNews
};