// =====================================================
// NEWSLETTER REPORT API ROUTES
// =====================================================
// Location: src/routes/newsletterReport.js
// =====================================================

import { Router } from 'express';
import { supabase, getUserFromToken, isUserAdmin } from '../lib/supabaseServer.js';

const router = Router();

// ============================================
// MIDDLEWARE: Require Auth (not necessarily admin)
// ============================================

async function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid authorization header' });
    }
    
    const token = authHeader.replace('Bearer ', '');
    const user = await getUserFromToken(token);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    console.error('[AUTH] Error:', error);
    res.status(500).json({ error: 'Authentication error' });
  }
}

// ============================================
// HELPER: Check Newsletter Access
// ============================================

async function hasNewsletterAccess(userId) {
  const { data: profile, error } = await supabase
    .from('profiles')
    .select('newsletter_status, newsletter_enabled, account_type, subscription_status, role')
    .eq('id', userId)
    .single();
  
  if (error || !profile) {
    return false;
  }
  
  // Admins always have access
  if (['admin', 'super_admin'].includes(profile.role)) {
    return true;
  }
  
  // Active newsletter subscribers
  if (['active', 'trial'].includes(profile.newsletter_status) && profile.newsletter_enabled !== false) {
    return true;
  }
  
  // Premium subscribers (as perk)
  if (profile.account_type === 'premium' && profile.subscription_status === 'active') {
    return true;
  }
  
  return false;
}

// ============================================
// ROUTES
// ============================================

/**
 * GET /api/newsletter/latest
 * Get the latest newsletter report (for subscribers)
 */
router.get('/latest', requireAuth, async (req, res) => {
  try {
    // Check if user has access
    const hasAccess = await hasNewsletterAccess(req.user.id);
    
    if (!hasAccess) {
      return res.status(403).json({ 
        success: false, 
        error: 'No active newsletter subscription',
        requiresSubscription: true
      });
    }
    
    // Get the latest report
    const { data: report, error } = await supabase
      .from('newsletter_reports')
      .select('id, report_date, subject, preheader, content, html_content, generated_at')
      .order('report_date', { ascending: false })
      .limit(1)
      .single();
    
    if (error) {
      if (error.code === 'PGRST116') {
        // No rows returned
        return res.json({ 
          success: true, 
          data: null,
          message: 'No reports available yet'
        });
      }
      throw error;
    }
    
    res.json({ 
      success: true, 
      data: {
        id: report.id,
        date: report.report_date,
        subject: report.subject,
        preheader: report.preheader,
        content: report.content,
        html: report.html_content,
        generatedAt: report.generated_at,
      }
    });
    
  } catch (error) {
    console.error('[REPORT] Error fetching latest report:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * GET /api/newsletter/report/:date
 * Get a specific report by date (YYYY-MM-DD)
 */
router.get('/report/:date', requireAuth, async (req, res) => {
  try {
    const { date } = req.params;
    
    // Validate date format
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format. Use YYYY-MM-DD' });
    }
    
    // Check if user has access
    const hasAccess = await hasNewsletterAccess(req.user.id);
    
    if (!hasAccess) {
      return res.status(403).json({ 
        success: false, 
        error: 'No active newsletter subscription',
        requiresSubscription: true
      });
    }
    
    // Get the specific report
    const { data: report, error } = await supabase
      .from('newsletter_reports')
      .select('id, report_date, subject, preheader, content, html_content, generated_at')
      .eq('report_date', date)
      .single();
    
    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({ 
          success: false, 
          error: 'Report not found for this date'
        });
      }
      throw error;
    }
    
    res.json({ 
      success: true, 
      data: {
        id: report.id,
        date: report.report_date,
        subject: report.subject,
        preheader: report.preheader,
        content: report.content,
        html: report.html_content,
        generatedAt: report.generated_at,
      }
    });
    
  } catch (error) {
    console.error('[REPORT] Error fetching report:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * GET /api/newsletter/reports
 * List all available reports (with pagination)
 */
router.get('/reports', requireAuth, async (req, res) => {
  try {
    // Check if user has access
    const hasAccess = await hasNewsletterAccess(req.user.id);
    
    if (!hasAccess) {
      return res.status(403).json({ 
        success: false, 
        error: 'No active newsletter subscription',
        requiresSubscription: true
      });
    }
    
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 20));
    const offset = Math.max(0, parseInt(req.query.offset) || 0);
    
    // Get reports (without full HTML to reduce payload)
    const { data: reports, error, count } = await supabase
      .from('newsletter_reports')
      .select('id, report_date, subject, preheader, generated_at', { count: 'exact' })
      .order('report_date', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) throw error;
    
    res.json({ 
      success: true, 
      data: reports || [],
      pagination: {
        total: count || 0,
        limit,
        offset,
        hasMore: (offset + limit) < (count || 0)
      }
    });
    
  } catch (error) {
    console.error('[REPORT] Error listing reports:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * GET /api/newsletter/preview (PUBLIC - for non-authenticated preview)
 * Returns a sample/teaser of the latest report
 */
router.get('/preview', async (req, res) => {
  try {
    // Get the latest report
    const { data: report, error } = await supabase
      .from('newsletter_reports')
      .select('id, report_date, subject, preheader, content, generated_at')
      .order('report_date', { ascending: false })
      .limit(1)
      .single();
    
    if (error) {
      if (error.code === 'PGRST116') {
        return res.json({ 
          success: true, 
          data: null,
          message: 'No reports available yet'
        });
      }
      throw error;
    }
    
    // Return limited preview (no full content)
    res.json({ 
      success: true, 
      data: {
        id: report.id,
        date: report.report_date,
        subject: report.subject,
        preheader: report.preheader,
        // Only include summary from content
        summary: report.content?.summary || null,
        generatedAt: report.generated_at,
        isPreview: true,
      }
    });
    
  } catch (error) {
    console.error('[REPORT] Error fetching preview:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

export default router;