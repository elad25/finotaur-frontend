// routes/marketData.js — FULL VERSION WITH POLYGON + PREMARKET SUPPORT
// Sources: FRED + Finnhub + Polygon (Stocks, Options, FX)
// Features: 15-minute caching, market hours detection (including premarket/afterhours), fallback to previous close
// FIXED: Proper change calculation when market is closed or todaysChangePerc is 0
import express from "express";

const router = express.Router();

// ============ CACHE CONFIGURATION ============
const CACHE_DURATION_MS = 15 * 60 * 1000; // 15 minutes

class DataCache {
  constructor() {
    this.store = new Map();
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) return null;

    const age = Date.now() - entry.timestamp;
    const marketStatus = isUSMarketOpen();

    // If market is closed (not premarket/afterhours), cache is valid until next session
    if (marketStatus.session === 'closed' && entry.session === 'closed') {
      return entry.data;
    }

    // If same session and cache is still fresh (15 min)
    if (entry.session === marketStatus.session && age < CACHE_DURATION_MS) {
      return entry.data;
    }

    // Session changed - invalidate cache
    if (entry.session !== marketStatus.session) {
      return null;
    }

    // Cache expired
    if (age >= CACHE_DURATION_MS) {
      return null;
    }

    return entry.data;
  }

  set(key, data, session) {
    this.store.set(key, {
      data,
      timestamp: Date.now(),
      session
    });
  }

  getAge(key) {
    const entry = this.store.get(key);
    if (!entry) return null;
    return Date.now() - entry.timestamp;
  }

  clear() {
    this.store.clear();
  }
}

const dataCache = new DataCache();

// ============ MARKET HOURS UTILITY (WITH PREMARKET/AFTERHOURS) ============
function isUSMarketOpen() {
  const now = new Date();
  const nyTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = nyTime.getDay();
  const hours = nyTime.getHours();
  const minutes = nyTime.getMinutes();
  const currentMinutes = hours * 60 + minutes;

  // Market hours:
  // Pre-market: 4:00 AM - 9:30 AM ET (240-570 minutes)
  // Regular: 9:30 AM - 4:00 PM ET (570-960 minutes)
  // After-hours: 4:00 PM - 8:00 PM ET (960-1200 minutes)
  const premarketOpen = 4 * 60; // 4:00 AM
  const marketOpen = 9 * 60 + 30; // 9:30 AM
  const marketClose = 16 * 60; // 4:00 PM
  const afterHoursClose = 20 * 60; // 8:00 PM

  // Weekend check
  if (day === 0 || day === 6) {
    return { 
      isOpen: false, 
      session: 'closed',
      message: "Market closed (Weekend)" 
    };
  }

  // Before pre-market (before 4:00 AM)
  if (currentMinutes < premarketOpen) {
    return { 
      isOpen: false, 
      session: 'closed',
      message: "Market closed. Pre-market opens at 4:00 AM ET" 
    };
  }

  // Pre-market hours (4:00 AM - 9:30 AM)
  if (currentMinutes >= premarketOpen && currentMinutes < marketOpen) {
    return { 
      isOpen: true, 
      session: 'premarket',
      message: "Pre-market session. Regular opens at 9:30 AM ET" 
    };
  }

  // Regular market hours (9:30 AM - 4:00 PM)
  if (currentMinutes >= marketOpen && currentMinutes < marketClose) {
    return { 
      isOpen: true, 
      session: 'regular',
      message: "Market is open" 
    };
  }

  // After-hours (4:00 PM - 8:00 PM)
  if (currentMinutes >= marketClose && currentMinutes < afterHoursClose) {
    return { 
      isOpen: true, 
      session: 'afterhours',
      message: "After-hours trading session" 
    };
  }

  // After after-hours (after 8:00 PM)
  return { 
    isOpen: false, 
    session: 'closed',
    message: "Market closed. Pre-market opens tomorrow 4:00 AM ET" 
  };
}

// ============ HELPER: Calculate change from price and previousClose ============
function calculateChange(price, previousClose) {
  if (!previousClose || previousClose === 0 || !price || price === 0) {
    return { change: 0, changePercent: 0 };
  }
  const change = price - previousClose;
  const changePercent = (change / previousClose) * 100;
  return { 
    change: +change.toFixed(2), 
    changePercent: +changePercent.toFixed(2) 
  };
}

// ============ API HELPERS ============

// FRED API (Economic Data)
async function fredSeries(seriesId, apiKey) {
  const cacheKey = `fred_${seriesId}`;
  const cached = dataCache.get(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&api_key=${apiKey}&file_type=json&limit=2&sort_order=desc`;
    const r = await fetch(url);
    if (!r.ok) return null;
    const data = await r.json();
    const obs = data?.observations || [];
    if (!obs.length) return null;
    const current = parseFloat(obs[0]?.value);
    const previous = obs[1] ? parseFloat(obs[1]?.value) : null;
    const change = previous ? +(current - previous).toFixed(3) : null;
    const result = { seriesId, value: current, previous, change, date: obs[0]?.date };
    dataCache.set(cacheKey, result, 'closed');
    return result;
  } catch (e) {
    console.error("FRED error:", seriesId, e.message);
    return null;
  }
}

// Finnhub API with caching
async function finnhubGet(endpoint, token) {
  const cacheKey = `finnhub_${endpoint}`;
  const cached = dataCache.get(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://finnhub.io/api/v1/${endpoint}${endpoint.includes("?") ? "&" : "?"}token=${token}`;
    const r = await fetch(url);
    if (!r.ok) {
      console.error(`Finnhub ${r.status}:`, endpoint);
      return null;
    }
    const data = await r.json();
    dataCache.set(cacheKey, data, isUSMarketOpen().session);
    return data;
  } catch (e) {
    console.error("Finnhub error:", endpoint, e.message);
    return null;
  }
}

// Finnhub Quote
async function finnhubQuote(symbol, token) {
  try {
    const data = await finnhubGet(`quote?symbol=${symbol}`, token);
    if (!data || data.c === 0) return null;
    
    // Calculate change if dp is 0 but we have valid prices
    let changePercent = data.dp || 0;
    if (changePercent === 0 && data.pc > 0 && data.c > 0 && data.c !== data.pc) {
      const calculated = calculateChange(data.c, data.pc);
      changePercent = calculated.changePercent;
    }
    
    return {
      symbol,
      price: data.c,
      change: data.d || (data.c - data.pc),
      changePercent: changePercent,
      high: data.h,
      low: data.l,
      open: data.o,
      previousClose: data.pc,
      timestamp: new Date().toISOString()
    };
  } catch (e) {
    console.error("Finnhub quote error:", symbol, e.message);
    return null;
  }
}

// Polygon API with caching
async function polygonGet(endpoint, apiKey, cacheKeyOverride = null) {
  if (!apiKey) return null;

  const marketStatus = isUSMarketOpen();
  const cacheKey = cacheKeyOverride || `polygon_${endpoint}`;
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] ${cacheKey}`);
    return cached;
  }

  try {
    const baseUrl = "https://api.polygon.io";
    const separator = endpoint.includes("?") ? "&" : "?";
    const url = `${baseUrl}${endpoint}${separator}apiKey=${apiKey}`;
    
    console.log(`[Polygon API] Fetching: ${endpoint}`);
    const r = await fetch(url);
    
    if (!r.ok) {
      console.error(`Polygon ${r.status}:`, endpoint);
      return null;
    }
    
    const data = await r.json();
    dataCache.set(cacheKey, data, marketStatus.session);
    return data;
  } catch (e) {
    console.error("Polygon error:", endpoint, e.message);
    return null;
  }
}

// Polygon Snapshot with fallback to previous close
// FIXED: Always calculate change when todaysChangePerc is 0
async function polygonSnapshot(symbol, apiKey) {
  const marketStatus = isUSMarketOpen();
  const cacheKey = `snapshot_${symbol}_${marketStatus.session}`;
  const cached = dataCache.get(cacheKey);
  if (cached) return cached;

  try {
    // Try snapshot first (real-time during market hours)
    const data = await polygonGet(
      `/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}`,
      apiKey,
      cacheKey
    );
    
    if (data?.ticker) {
      const t = data.ticker;
      const prevClose = t.prevDay?.c || 0;
      
      // Determine current price based on session
      let currentPrice;
      let sessionData = {};
      
      if (marketStatus.session === 'premarket' || marketStatus.session === 'afterhours') {
        // During extended hours, use the most recent minute bar
        currentPrice = t.min?.c || t.day?.c || prevClose;
        const extendedChange = currentPrice - prevClose;
        const extendedChangePercent = prevClose > 0 ? (extendedChange / prevClose) * 100 : 0;
        
        sessionData = {
          extendedHoursPrice: currentPrice,
          extendedHoursChange: +extendedChange.toFixed(2),
          extendedHoursChangePercent: +extendedChangePercent.toFixed(2),
          lastTradeTime: t.min?.t ? new Date(t.min.t).toISOString() : null
        };
      } else {
        // Regular hours - use day data
        currentPrice = t.day?.c || prevClose;
      }
      
      // FIXED: Always try to calculate change if Polygon returns 0
      let change = t.todaysChange || 0;
      let changePercent = t.todaysChangePerc || 0;
      
      // If change is 0 but we have valid price data, calculate it ourselves
      if (changePercent === 0 && prevClose > 0 && currentPrice > 0 && currentPrice !== prevClose) {
        const calculated = calculateChange(currentPrice, prevClose);
        change = calculated.change;
        changePercent = calculated.changePercent;
        console.log(`[Polygon] Calculated change for ${symbol}: ${changePercent}% (price: ${currentPrice}, prevClose: ${prevClose})`);
      }
      
      const result = {
        symbol: t.ticker,
        price: currentPrice,
        change: change,
        changePercent: changePercent,
        open: t.day?.o,
        high: t.day?.h,
        low: t.day?.l,
        volume: t.day?.v,
        previousClose: prevClose,
        timestamp: new Date().toISOString(),
        session: marketStatus.session,
        dataSource: 'snapshot',
        ...sessionData
      };
      
      dataCache.set(cacheKey, result, marketStatus.session);
      return result;
    }

    // Fallback to previous day data
    const prevData = await polygonGet(`/v2/aggs/ticker/${symbol}/prev`, apiKey);
    if (prevData?.results?.[0]) {
      const r = prevData.results[0];
      const change = r.o ? ((r.c - r.o) / r.o) * 100 : 0;
      const result = {
        symbol,
        price: r.c,
        open: r.o,
        high: r.h,
        low: r.l,
        volume: r.v,
        previousClose: r.c,
        change: +(r.c - r.o).toFixed(2),
        changePercent: +change.toFixed(2),
        timestamp: new Date(r.t).toISOString(),
        session: marketStatus.session,
        dataSource: 'previousClose'
      };
      dataCache.set(cacheKey, result, 'closed');
      return result;
    }

    return null;
  } catch (e) {
    console.error("Polygon snapshot error:", symbol, e.message);
    return null;
  }
}

// Polygon FX Quote
async function polygonFX(pair, apiKey) {
  const cacheKey = `fx_${pair}`;
  const cached = dataCache.get(cacheKey);
  if (cached) return cached;

  try {
    const data = await polygonGet(`/v2/aggs/ticker/C:${pair}/prev`, apiKey);
    if (!data?.results?.[0]) return null;
    const r = data.results[0];
    const result = {
      pair,
      price: r.c,
      open: r.o,
      high: r.h,
      low: r.l,
      change: +(r.c - r.o).toFixed(5),
      changePercent: +(((r.c - r.o) / r.o) * 100).toFixed(3),
      timestamp: new Date(r.t).toISOString()
    };
    dataCache.set(cacheKey, result, isUSMarketOpen().session);
    return result;
  } catch (e) {
    console.error("Polygon FX error:", pair, e.message);
    return null;
  }
}

// ============================================================
// FIXED polygonBulkSnapshot function - WITH PROPER CHANGE CALCULATION
// ============================================================
// Problem: During closed market, Polygon's todaysChangePerc returns 0 
// because there's no movement today.
// Solution: Calculate change from day.o (today's open) to day.c (today's close)
// Or from prevDay.c to day.c for overnight change
// ============================================================

async function polygonBulkSnapshot(apiKey, forceSession = null) {
  const marketStatus = isUSMarketOpen();
  const session = forceSession || marketStatus.session;
  const cacheKey = `bulk_snapshot_stocks_${session}`;
  
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Bulk stocks snapshot (${session})`);
    return cached;
  }

  try {
    console.log(`[Polygon API] Fetching bulk stocks snapshot for ${session}...`);
    const response = await fetch(
      `https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers?apiKey=${apiKey}`
    );

    if (!response.ok) {
      throw new Error(`Polygon API error: ${response.status}`);
    }

    const data = await response.json();
    const tickers = data.tickers || [];
    
    // Debug: log sample ticker to see what Polygon returns during this session
    if (tickers.length > 0) {
      const sampleTicker = tickers.find(t => t.ticker === 'AAPL') || tickers[0];
      console.log(`[Polygon Debug] Sample ticker (${sampleTicker.ticker}) for ${session}:`, JSON.stringify({
        'min': sampleTicker.min,
        'day': sampleTicker.day,
        'prevDay': sampleTicker.prevDay,
        'todaysChange': sampleTicker.todaysChange,
        'todaysChangePerc': sampleTicker.todaysChangePerc,
        'updated': sampleTicker.updated
      }, null, 2));
    }
    
    const result = new Map();
    let calculatedCount = 0;
    
    for (const ticker of tickers) {
      const symbol = ticker.ticker;
      const prevClose = ticker.prevDay?.c || 0;
      const dayOpen = ticker.day?.o || 0;
      const dayClose = ticker.day?.c || 0;
      const minClose = ticker.min?.c || 0;
      
      let price, change, changePercent;
      
      // Get the most current price available
      const currentPrice = minClose || dayClose || prevClose;
      
      // =====================================================
      // KEY FIX: Calculate change based on available data
      // Priority:
      // 1. Use Polygon's todaysChangePerc if non-zero
      // 2. Calculate from day's open to close (intraday change)
      // 3. Calculate from previous close to current price (overnight change)
      // =====================================================
      
      if (ticker.todaysChangePerc && ticker.todaysChangePerc !== 0) {
        // Use Polygon's pre-calculated values
        price = currentPrice;
        change = ticker.todaysChange || 0;
        changePercent = ticker.todaysChangePerc;
      } else if (session === 'premarket' || session === 'afterhours') {
        // Extended hours: Calculate from previous close to current price
        price = currentPrice;
        if (prevClose > 0 && currentPrice > 0 && currentPrice !== prevClose) {
          const calculated = calculateChange(currentPrice, prevClose);
          change = calculated.change;
          changePercent = calculated.changePercent;
          calculatedCount++;
        } else {
          change = 0;
          changePercent = 0;
        }
      } else if (session === 'closed') {
        // Market closed: Use last day's data (day.c vs day.o for daily change)
        // Or prevDay.c to day.c for last trading day's change
        price = dayClose || prevClose;
        
        if (dayOpen > 0 && dayClose > 0 && dayClose !== dayOpen) {
          // Calculate from day's open to close
          const calculated = calculateChange(dayClose, dayOpen);
          change = calculated.change;
          changePercent = calculated.changePercent;
          calculatedCount++;
        } else if (prevClose > 0 && dayClose > 0 && dayClose !== prevClose) {
          // Fallback: calculate from previous close
          const calculated = calculateChange(dayClose, prevClose);
          change = calculated.change;
          changePercent = calculated.changePercent;
          calculatedCount++;
        } else {
          change = 0;
          changePercent = 0;
        }
      } else {
        // Regular session with 0 change - try to calculate
        price = currentPrice;
        if (prevClose > 0 && currentPrice > 0 && currentPrice !== prevClose) {
          const calculated = calculateChange(currentPrice, prevClose);
          change = calculated.change;
          changePercent = calculated.changePercent;
          calculatedCount++;
        } else {
          change = 0;
          changePercent = 0;
        }
      }
      
      result.set(symbol, {
        symbol,
        price,
        change,
        changePercent,
        // Regular session data
        open: ticker.day?.o,
        high: ticker.day?.h,
        low: ticker.day?.l,
        volume: ticker.day?.v || ticker.min?.v || 0,
        previousClose: prevClose,
        // Extended hours specific data
        extendedHoursPrice: (session === 'premarket' || session === 'afterhours') ? currentPrice : null,
        extendedHoursChange: (session === 'premarket' || session === 'afterhours') ? change : null,
        extendedHoursChangePercent: (session === 'premarket' || session === 'afterhours') ? changePercent : null,
        // Metadata
        session,
        lastUpdated: ticker.updated ? new Date(ticker.updated / 1000000).toISOString() : null,
        lastTradeTime: ticker.min?.t ? new Date(ticker.min.t).toISOString() : null
      });
    }

    dataCache.set(cacheKey, result, session);
    console.log(`[Polygon API] Loaded ${result.size} stock snapshots for ${session} (calculated ${calculatedCount} changes)`);
    return result;
  } catch (e) {
    console.error("Polygon bulk snapshot error:", e.message);
    return null;
  }
}

// Bulk Crypto Snapshot
async function polygonCryptoSnapshot(apiKey) {
  const cacheKey = 'bulk_snapshot_crypto';
  const cached = dataCache.get(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(
      `https://api.polygon.io/v2/snapshot/locale/global/markets/crypto/tickers?apiKey=${apiKey}`
    );

    if (!response.ok) {
      throw new Error(`Polygon Crypto API error: ${response.status}`);
    }

    const data = await response.json();
    const tickers = data.tickers || [];

    const symbolMap = {
      'X:BTCUSD': 'BTC', 'X:ETHUSD': 'ETH', 'X:BNBUSD': 'BNB',
      'X:SOLUSD': 'SOL', 'X:XRPUSD': 'XRP', 'X:ADAUSD': 'ADA',
      'X:DOGEUSD': 'DOGE', 'X:AVAXUSD': 'AVAX', 'X:DOTUSD': 'DOT',
      'X:LINKUSD': 'LINK', 'X:MATICUSD': 'MATIC', 'X:UNIUSD': 'UNI'
    };

    const result = new Map();
    for (const ticker of tickers) {
      const symbol = symbolMap[ticker.ticker];
      if (symbol) {
        const prevClose = ticker.prevDay?.c || 0;
        const currentPrice = ticker.day?.c || ticker.min?.c || prevClose;
        
        let changePercent = ticker.todaysChangePerc || 0;
        // Calculate if needed
        if (changePercent === 0 && prevClose > 0 && currentPrice > 0 && currentPrice !== prevClose) {
          const calculated = calculateChange(currentPrice, prevClose);
          changePercent = calculated.changePercent;
        }
        
        result.set(symbol, {
          symbol,
          price: currentPrice,
          change: ticker.todaysChange || (currentPrice - prevClose),
          changePercent: changePercent,
          previousClose: prevClose
        });
      }
    }

    dataCache.set(cacheKey, result, 'regular'); // Crypto is 24/7
    return result;
  } catch (e) {
    console.error("Polygon crypto snapshot error:", e.message);
    return null;
  }
}

// ============ MAIN ENDPOINT ============
router.get("/fetch-market-data", async (req, res) => {
  try {
    const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
    const FRED_KEY = process.env.FRED_API_KEY;
    const POLYGON_KEY = process.env.POLYGON_API_KEY;

    if (!POLYGON_KEY) {
      return res.status(500).json({ error: "POLYGON_API_KEY not set" });
    }

    const marketStatus = isUSMarketOpen();
    console.log(`[Market Status] ${marketStatus.session}: ${marketStatus.message}`);

    // Check if client requested specific session
    const requestedSession = req.query.session || marketStatus.session;

    // ========================================
    // 1️⃣ INDICES (Polygon Snapshot)
    // ========================================
    const indexSymbols = ["SPY", "QQQ", "DIA", "IWM"];
    const indexQuotes = await Promise.all(
      indexSymbols.map(s => polygonSnapshot(s, POLYGON_KEY))
    );

    const indices = {};
    indexSymbols.forEach((s, i) => {
      const q = indexQuotes[i];
      if (q) {
        const changePercent = q.extendedHoursChangePercent || q.changePercent || 0;
        const direction = changePercent > 0.1 ? "UP" :
                         changePercent < -0.1 ? "DOWN" : "FLAT";
        indices[s.toLowerCase()] = { ...q, overnightDirection: direction };
      } else {
        indices[s.toLowerCase()] = null;
      }
    });

    // VIX from Finnhub (Polygon doesn't have it)
    if (FINNHUB_KEY) {
      const vixQuote = await finnhubQuote("VIX", FINNHUB_KEY);
      indices.vix = vixQuote;
    }

    // ========================================
    // 2️⃣ RATES (FRED)
    // ========================================
    let rates = {};
    if (FRED_KEY) {
      const ratesSeries = [
        { id: "us02y", series: "DGS2", name: "2-Year Treasury" },
        { id: "us10y", series: "DGS10", name: "10-Year Treasury" },
        { id: "us30y", series: "DGS30", name: "30-Year Treasury" },
        { id: "fedfunds", series: "FEDFUNDS", name: "Fed Funds Rate" }
      ];

      const ratesData = await Promise.all(
        ratesSeries.map(r => fredSeries(r.series, FRED_KEY))
      );

      ratesSeries.forEach((r, i) => {
        const d = ratesData[i];
        rates[r.id] = d ? {
          name: r.name,
          yield: d.value,
          change: d.change,
          previous: d.previous,
          date: d.date
        } : null;
      });

      if (rates.us02y && rates.us10y) {
        const spread = +(rates.us10y.yield - rates.us02y.yield).toFixed(2);
        rates.curve = {
          spread_10y_2y: spread,
          direction: spread > 0 ? "NORMAL" : "INVERTED"
        };
      }
    }

    // ========================================
    // 3️⃣ FX (Polygon Currencies)
    // ========================================
    const fxPairs = [
      { id: "eurusd", pair: "EURUSD", name: "EUR/USD" },
      { id: "usdjpy", pair: "USDJPY", name: "USD/JPY" },
      { id: "gbpusd", pair: "GBPUSD", name: "GBP/USD" },
      { id: "usdchf", pair: "USDCHF", name: "USD/CHF" },
      { id: "audusd", pair: "AUDUSD", name: "AUD/USD" }
    ];

    const fxQuotes = await Promise.all(
      fxPairs.map(f => polygonFX(f.pair, POLYGON_KEY))
    );

    const fx = {};
    fxPairs.forEach((f, i) => {
      const q = fxQuotes[i];
      fx[f.id] = q ? { name: f.name, ...q } : null;
    });

    // DXY - Dollar Index (ETF proxy: UUP)
    const dxyQuote = await polygonSnapshot("UUP", POLYGON_KEY);
    fx.dxy = dxyQuote ? { name: "US Dollar Index (UUP)", ...dxyQuote } : null;

    // ========================================
    // 4️⃣ COMMODITIES (Polygon / ETF Proxies)
    // ========================================
    const commoditySymbols = [
      { id: "gold", symbol: "GLD", name: "Gold (GLD)" },
      { id: "oil", symbol: "USO", name: "Crude Oil (USO)" },
      { id: "silver", symbol: "SLV", name: "Silver (SLV)" },
      { id: "natgas", symbol: "UNG", name: "Natural Gas (UNG)" },
      { id: "copper", symbol: "CPER", name: "Copper (CPER)" }
    ];

    const commodityQuotes = await Promise.all(
      commoditySymbols.map(c => polygonSnapshot(c.symbol, POLYGON_KEY))
    );

    const commodities = {};
    commoditySymbols.forEach((c, i) => {
      const q = commodityQuotes[i];
      commodities[c.id] = q ? { name: c.name, ...q } : null;
    });

    // ========================================
    // 5️⃣ ECONOMIC CALENDAR
    // ========================================
    let calendar = [];
    
    // Try Forex Factory CDN first
    try {
      const ffResponse = await fetch("https://cdn-nfs.faireconomy.media/ff_calendar_thisweek.json", {
        headers: { "User-Agent": "Mozilla/5.0" }
      });
      if (ffResponse.ok) {
        const ffData = await ffResponse.json();
        calendar = ffData
          .filter(evt => evt.country === "USD" || evt.impact === "High")
          .slice(0, 30)
          .map(evt => ({
            event: evt.title,
            country: evt.country,
            date: evt.date,
            impact: evt.impact?.toLowerCase() || "low",
            forecast: evt.forecast,
            previous: evt.previous,
            actual: evt.actual || null
          }));
      }
    } catch (e) {
      console.error("Forex Factory error:", e.message);
    }

    // Fallback to Finnhub
    if (calendar.length === 0 && FINNHUB_KEY) {
      try {
        const calData = await finnhubGet("calendar/economic", FINNHUB_KEY);
        if (calData?.economicCalendar?.length > 0) {
          calendar = calData.economicCalendar.slice(0, 25).map(evt => ({
            event: evt.event,
            country: evt.country,
            time: evt.time,
            date: evt.date,
            actual: evt.actual,
            forecast: evt.estimate,
            previous: evt.prev,
            impact: evt.impact === 3 ? "high" : evt.impact === 2 ? "medium" : "low",
            unit: evt.unit
          }));
        }
      } catch (e) {
        console.error("Finnhub calendar error:", e.message);
      }
    }

    // ========================================
    // 6️⃣ SECTOR PERFORMANCE (Polygon Snapshots)
    // ========================================
    const sectorSymbols = [
      { id: "XLK", name: "Technology" },
      { id: "XLF", name: "Financials" },
      { id: "XLE", name: "Energy" },
      { id: "XLV", name: "Healthcare" },
      { id: "XLY", name: "Consumer Discretionary" },
      { id: "XLP", name: "Consumer Staples" },
      { id: "XLI", name: "Industrials" },
      { id: "XLB", name: "Materials" },
      { id: "XLRE", name: "Real Estate" },
      { id: "XLC", name: "Communications" },
      { id: "XLU", name: "Utilities" }
    ];

    const sectorQuotes = await Promise.all(
      sectorSymbols.map(s => polygonSnapshot(s.id, POLYGON_KEY))
    );

    const sectors = {};
    sectorSymbols.forEach((s, i) => {
      const q = sectorQuotes[i];
      if (q) {
        sectors[s.id] = {
          name: s.name,
          price: q.price,
          change: q.extendedHoursChange || q.change,
          changePercent: q.extendedHoursChangePercent || q.changePercent,
          previousClose: q.previousClose,
          session: q.session
        };
      } else {
        sectors[s.id] = null;
      }
    });

    const sectorRanking = Object.entries(sectors)
      .filter(([_, v]) => v !== null)
      .sort((a, b) => (b[1].changePercent || 0) - (a[1].changePercent || 0))
      .map(([symbol, data]) => ({ symbol, ...data }));

    // ========================================
    // 7️⃣ ANALYST ACTIONS (Finnhub)
    // ========================================
    let analyst_actions = [];
    let recommendations = [];
    let priceTargets = [];
    let highPotentialStocks = [];

    if (FINNHUB_KEY) {
      const today = new Date().toISOString().split("T")[0];
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

      const upgradesRaw = await finnhubGet(`stock/upgrade-downgrade?from=${thirtyDaysAgo}&to=${today}`, FINNHUB_KEY) || [];
      analyst_actions = upgradesRaw.slice(0, 50).map(u => ({
        symbol: u.symbol,
        action: u.action?.toLowerCase() || "update",
        from: u.fromGrade,
        to: u.toGrade,
        firm: u.company,
        date: u.gradeTime?.split("T")[0]
      }));

      const recSymbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "TSLA", "META", "SPY", "QQQ"];
      const recommendationsRaw = await Promise.all(
        recSymbols.map(async (sym) => {
          const recs = await finnhubGet(`stock/recommendation?symbol=${sym}`, FINNHUB_KEY);
          if (!recs || !recs.length) return null;
          const latest = recs[0];
          return {
            symbol: sym,
            period: latest.period,
            strongBuy: latest.strongBuy,
            buy: latest.buy,
            hold: latest.hold,
            sell: latest.sell,
            strongSell: latest.strongSell
          };
        })
      );
      recommendations = recommendationsRaw.filter(Boolean);

      const priceTargetsRaw = await Promise.all(
        recSymbols.slice(0, 7).map(async (sym) => {
          const [pt, quote] = await Promise.all([
            finnhubGet(`stock/price-target?symbol=${sym}`, FINNHUB_KEY),
            polygonSnapshot(sym, POLYGON_KEY)
          ]);
          if (!pt || !pt.targetHigh || !quote?.price) return null;

          const currentPrice = quote.price;
          const upsideToHigh = +((pt.targetHigh - currentPrice) / currentPrice * 100).toFixed(1);
          const downsideToLow = +((currentPrice - pt.targetLow) / currentPrice * 100).toFixed(1);
          const upsideToMean = +((pt.targetMean - currentPrice) / currentPrice * 100).toFixed(1);

          return {
            symbol: sym,
            currentPrice,
            targetHigh: pt.targetHigh,
            targetLow: pt.targetLow,
            targetMean: pt.targetMean,
            targetMedian: pt.targetMedian,
            upsideToHigh,
            downsideToLow,
            upsideToMean,
            lastUpdated: pt.lastUpdated
          };
        })
      );

      priceTargets = priceTargetsRaw.filter(Boolean);
      highPotentialStocks = priceTargets.filter(pt =>
        Math.abs(pt.upsideToHigh) >= 20 ||
        Math.abs(pt.downsideToLow) >= 20 ||
        Math.abs(pt.upsideToMean) >= 20
      );
    }

    // ========================================
    // 8️⃣ UOA - Unusual Options Activity (Polygon)
    // ========================================
    let uoa = [];
    try {
      const uoaSymbols = ["AAPL", "TSLA", "NVDA", "AMD", "SPY", "QQQ", "AMZN", "META", "GOOGL", "MSFT"];

      const optionsData = await Promise.all(
        uoaSymbols.map(async (symbol) => {
          const data = await polygonGet(`/v3/snapshot/options/${symbol}?limit=50`, POLYGON_KEY);
          if (!data?.results) return [];

          return data.results
            .filter(opt => {
              const volume = opt.day?.volume || 0;
              const oi = opt.open_interest || 1;
              const volOiRatio = volume / oi;
              return volume > 1000 && volOiRatio > 0.5;
            })
            .map(opt => {
              const isCall = opt.details?.contract_type === "call";
              const delta = opt.greeks?.delta || 0;
              const changePercent = opt.day?.change_percent || 0;

              let direction = "neutral";
              if (isCall && delta > 0.2) direction = "bullish";
              else if (!isCall && delta < -0.2) direction = "bearish";
              else if (isCall && changePercent > 0) direction = "bullish";
              else if (!isCall && changePercent > 0) direction = "bearish";

              return {
                symbol,
                contract: opt.details?.ticker,
                type: opt.details?.contract_type,
                strike: opt.details?.strike_price,
                expiration: opt.details?.expiration_date,
                volume: opt.day?.volume,
                openInterest: opt.open_interest,
                volOiRatio: +((opt.day?.volume || 0) / (opt.open_interest || 1)).toFixed(2),
                lastPrice: opt.day?.close,
                change: opt.day?.change,
                changePercent: opt.day?.change_percent,
                impliedVolatility: opt.greeks?.iv,
                delta: opt.greeks?.delta,
                gamma: opt.greeks?.gamma,
                theta: opt.greeks?.theta,
                vega: opt.greeks?.vega,
                underlyingPrice: opt.underlying_asset?.price,
                direction,
                flowType: opt.day?.volume > 10000 ? "sweep" : "standard"
              };
            });
        })
      );

      uoa = optionsData
        .flat()
        .sort((a, b) => (b.volume || 0) - (a.volume || 0))
        .slice(0, 30);
    } catch (e) {
      console.error("UOA error:", e.message);
    }

    // ========================================
    // 9️⃣ EARNINGS CALENDAR (Finnhub)
    // ========================================
    let earnings = [];
    if (FINNHUB_KEY) {
      const today = new Date().toISOString().split("T")[0];
      const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      const earnData = await finnhubGet(`calendar/earnings?from=${today}&to=${nextWeek}`, FINNHUB_KEY);

      earnings = (earnData?.earningsCalendar || []).slice(0, 40).map(e => ({
        symbol: e.symbol,
        date: e.date,
        time: e.hour === 0 ? "before open" : e.hour === 1 ? "after close" : "during market",
        epsEstimate: e.epsEstimate,
        epsActual: e.epsActual,
        revenueEstimate: e.revenueEstimate,
        revenueActual: e.revenueActual,
        surprise: e.epsActual && e.epsEstimate ?
          +((e.epsActual - e.epsEstimate) / Math.abs(e.epsEstimate) * 100).toFixed(1) : null,
        quarter: `Q${e.quarter} ${e.year}`
      }));
    }

    // ========================================
    // ?? CORPORATE NEWS (Finnhub)
    // ========================================
    let corporate_news = [];
    if (FINNHUB_KEY) {
      const newsRaw = await finnhubGet("news?category=general", FINNHUB_KEY) || [];
      corporate_news = newsRaw.slice(0, 20).map(n => ({
        headline: n.headline,
        source: n.source,
        url: n.url,
        timestamp: new Date(n.datetime * 1000).toISOString(),
        category: n.category,
        related: n.related?.split(",").filter(Boolean) || [],
        image: n.image,
        impact: n.headline?.toLowerCase().includes("upgrade") || n.headline?.toLowerCase().includes("downgrade") ? "high" :
                n.headline?.toLowerCase().includes("earnings") || n.headline?.toLowerCase().includes("revenue") ? "medium" : "low"
      }));
    }

    // ========================================
    // 1️⃣1️⃣ TECHNICAL LEVELS (Calculated)
    // ========================================
    const technicalSymbols = ["SPY", "QQQ", "AAPL", "TSLA", "NVDA"];
    const techQuotes = await Promise.all(
      technicalSymbols.map(s => polygonSnapshot(s, POLYGON_KEY))
    );

    const technical_levels = {};
    technicalSymbols.forEach((sym, i) => {
      const q = techQuotes[i];
      if (q && q.high && q.low) {
        const range = q.high - q.low;
        const pivot = (q.high + q.low + q.price) / 3;
        technical_levels[sym] = {
          price: q.price,
          pivot: +pivot.toFixed(2),
          support: [
            +(pivot - range * 0.382).toFixed(2),
            +(pivot - range * 0.618).toFixed(2)
          ],
          resistance: [
            +(pivot + range * 0.382).toFixed(2),
            +(pivot + range * 0.618).toFixed(2)
          ],
          dailyRange: {
            high: q.high,
            low: q.low,
            range: +range.toFixed(2)
          }
        };
      }
    });

    // ========================================
    // STOCK QUOTES (Top holdings via Polygon)
    // ========================================
    const stockSymbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "TSLA", "META"];
    const stockQuotes = await Promise.all(
      stockSymbols.map(s => polygonSnapshot(s, POLYGON_KEY))
    );
    const stocks = Object.fromEntries(
      stockSymbols.map((s, i) => [s.toLowerCase(), stockQuotes[i]])
    );

    // ========================================
    // HEATMAP DATA (Bulk snapshot for all stocks)
    // ========================================
    let heatmapData = null;
    try {
      const bulkSnapshot = await polygonBulkSnapshot(POLYGON_KEY);
      if (bulkSnapshot) {
        heatmapData = {
          count: bulkSnapshot.size,
          session: marketStatus.session,
          lastUpdated: new Date().toISOString(),
          tickers: Object.fromEntries(bulkSnapshot)
        };
      }
    } catch (e) {
      console.error("Heatmap data error:", e.message);
    }

    // ========================================
    // RESPONSE
    // ========================================
    res.json({
      timestamp: new Date().toISOString(),
      marketStatus: marketStatus,
      cacheInfo: {
        cacheDurationMs: CACHE_DURATION_MS,
        cacheDurationMin: CACHE_DURATION_MS / 60000
      },
      dataStatus: {
        indices: Object.values(indices).some(v => v !== null) ? "OK" : "UNAVAILABLE",
        rates: Object.values(rates).some(v => v !== null) ? "OK" : "UNAVAILABLE",
        fx: Object.values(fx).some(v => v !== null) ? "OK" : "UNAVAILABLE",
        commodities: Object.values(commodities).some(v => v !== null) ? "OK" : "UNAVAILABLE",
        calendar: calendar.length > 0 ? "OK" : "EMPTY",
        sectors: Object.values(sectors).some(v => v !== null) ? "OK" : "UNAVAILABLE",
        analyst_actions: analyst_actions.length > 0 || recommendations.length > 0 ? "OK" : "EMPTY",
        uoa: uoa.length > 0 ? "OK" : "EMPTY",
        earnings: earnings.length > 0 ? "OK" : "EMPTY",
        news: corporate_news.length > 0 ? "OK" : "EMPTY",
        technical: Object.keys(technical_levels).length > 0 ? "OK" : "EMPTY",
        heatmap: heatmapData ? "OK" : "UNAVAILABLE"
      },

      indices,
      rates,
      fx,
      commodities,
      calendar,
      sectors,
      sectorRanking,
      analyst_actions,
      recommendations,
      priceTargets,
      highPotentialStocks,
      uoa,
      earnings,
      corporate_news,
      technical_levels,
      stocks,
      heatmapData
    });

  } catch (e) {
    console.error("❌ fetch-market-data error:", e.message);
    res.status(500).json({ 
      error: "market_data_error", 
      message: e.message,
      marketStatus: isUSMarketOpen()
    });
  }
});

// ============ HEATMAP ENDPOINT (WITH PREMARKET SUPPORT) ============
router.get("/heatmap", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  try {
    const marketStatus = isUSMarketOpen();
    
    // Allow client to request specific session data
    const requestedSession = req.query.session || marketStatus.session;
    
    console.log(`[Heatmap] Fetching data for session: ${requestedSession}`);
    
    const bulkSnapshot = await polygonBulkSnapshot(POLYGON_KEY, requestedSession);

    if (!bulkSnapshot) {
      return res.status(500).json({ 
        error: "Failed to fetch heatmap data",
        marketStatus 
      });
    }

    res.json({
      timestamp: new Date().toISOString(),
      marketStatus,
      session: requestedSession,
      count: bulkSnapshot.size,
      tickers: Object.fromEntries(bulkSnapshot)
    });
  } catch (e) {
    res.status(500).json({ 
      error: "heatmap_error", 
      message: e.message 
    });
  }
});

// ============ INDIVIDUAL ENDPOINTS ============

// Single stock quote
router.get("/quote/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;

  const symbol = req.params.symbol.toUpperCase();

  let quote = await polygonSnapshot(symbol, POLYGON_KEY);
  if (!quote && FINNHUB_KEY) {
    quote = await finnhubQuote(symbol, FINNHUB_KEY);
  }

  if (!quote) return res.status(404).json({ error: "symbol_not_found" });
  res.json(quote);
});

// Multiple quotes
router.get("/quotes", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;

  const symbols = (req.query.symbols || "").split(",").filter(Boolean);
  if (!symbols.length) return res.status(400).json({ error: "symbols_required" });

  const quotes = await Promise.all(
    symbols.map(s => polygonSnapshot(s.trim().toUpperCase(), POLYGON_KEY))
  );
  res.json(quotes.filter(Boolean));
});

// Economic data
router.get("/economic/:series", async (req, res) => {
  const FRED_KEY = process.env.FRED_API_KEY;
  if (!FRED_KEY) return res.status(500).json({ error: "fred_key_missing" });

  const data = await fredSeries(req.params.series.toUpperCase(), FRED_KEY);
  if (!data) return res.status(404).json({ error: "series_not_found" });
  res.json(data);
});

// Analyst recommendations
// Analyst recommendations + upgrades/downgrades + price targets
router.get("/analyst/:symbol", async (req, res) => {
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
  const POLYGON_KEY = process.env.POLYGON_API_KEY;

  const symbol = req.params.symbol.toUpperCase();
  
  try {
    // Get date range for upgrades (last 90 days)
    const today = new Date().toISOString().split("T")[0];
    const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

    const [recommendations, priceTarget, quote, upgradesRaw] = await Promise.all([
      finnhubGet(`stock/recommendation?symbol=${symbol}`, FINNHUB_KEY),
      finnhubGet(`stock/price-target?symbol=${symbol}`, FINNHUB_KEY),
      polygonSnapshot(symbol, POLYGON_KEY),
      // 🆕 Add individual analyst actions
      finnhubGet(`stock/upgrade-downgrade?symbol=${symbol}&from=${ninetyDaysAgo}&to=${today}`, FINNHUB_KEY)
    ]);

    // 🆕 Transform upgrades/downgrades to clean format
    const analystActions = (upgradesRaw || [])
      .slice(0, 15) // Last 15 actions
      .map(u => ({
        date: u.gradeTime?.split("T")[0] || null,
        firm: u.company || "Unknown",
        action: u.action?.toLowerCase() || "update",
        fromGrade: u.fromGrade || null,
        toGrade: u.toGrade || null
      }));

    // Get latest recommendation summary
    const latestRec = recommendations?.[0] || null;
    
    // 🆕 Calculate rating summary
    let rating = null;
    if (latestRec) {
      const total = (latestRec.strongBuy || 0) + (latestRec.buy || 0) + 
                    (latestRec.hold || 0) + (latestRec.sell || 0) + (latestRec.strongSell || 0);
      
      // Determine consensus
      const buyTotal = (latestRec.strongBuy || 0) + (latestRec.buy || 0);
      const sellTotal = (latestRec.sell || 0) + (latestRec.strongSell || 0);
      let consensus = "Hold";
      if (buyTotal > total * 0.6) consensus = "Buy";
      if (buyTotal > total * 0.8) consensus = "Strong Buy";
      if (sellTotal > total * 0.4) consensus = "Sell";
      if (sellTotal > total * 0.6) consensus = "Strong Sell";

      rating = {
        strongBuy: latestRec.strongBuy || 0,
        buy: latestRec.buy || 0,
        hold: latestRec.hold || 0,
        sell: latestRec.sell || 0,
        strongSell: latestRec.strongSell || 0,
        total,
        consensus,
        period: latestRec.period
      };
    }

    // 🆕 Format price target with upside calculation
    let formattedPriceTarget = null;
    if (priceTarget && priceTarget.targetHigh) {
      const currentPrice = quote?.price || 0;
      formattedPriceTarget = {
        targetHigh: priceTarget.targetHigh,
        targetLow: priceTarget.targetLow,
        targetMean: priceTarget.targetMean,
        targetMedian: priceTarget.targetMedian,
        currentPrice,
        upsidePercent: currentPrice > 0 
          ? +((priceTarget.targetMean - currentPrice) / currentPrice * 100).toFixed(1)
          : 0,
        numberOfAnalysts: priceTarget.numberOfAnalysts || null,
        lastUpdated: priceTarget.lastUpdated || null
      };
    }

    res.json({ 
      symbol, 
      quote,
      rating,                    // 🆕 Formatted rating with consensus
      priceTarget: formattedPriceTarget,  // 🆕 Formatted with upside %
      analystActions,            // 🆕 Individual analyst upgrades/downgrades
      recommendations            // Keep full history for charts
    });

  } catch (e) {
    console.error("Analyst endpoint error:", e.message);
    res.status(500).json({ error: "analyst_error", message: e.message });
  }
});

// Sector performance
router.get("/sectors", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;

  const sectorSymbols = ["XLK", "XLF", "XLE", "XLV", "XLY", "XLP", "XLI", "XLB", "XLRE", "XLC", "XLU"];
  const sectorNames = {
    XLK: "Technology", XLF: "Financials", XLE: "Energy", XLV: "Healthcare",
    XLY: "Consumer Discretionary", XLP: "Consumer Staples", XLI: "Industrials",
    XLB: "Materials", XLRE: "Real Estate", XLC: "Communications", XLU: "Utilities"
  };

  const quotes = await Promise.all(
    sectorSymbols.map(s => polygonSnapshot(s, POLYGON_KEY))
  );

  const sectors = sectorSymbols
    .map((s, i) => quotes[i] ? { symbol: s, name: sectorNames[s], ...quotes[i] } : null)
    .filter(Boolean)
    .sort((a, b) => (b.changePercent || 0) - (a.changePercent || 0));

  res.json({ timestamp: new Date().toISOString(), sectors });
});

// FX rates
router.get("/fx", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;

  const pairs = [
    { id: "eurusd", pair: "EURUSD", name: "EUR/USD" },
    { id: "usdjpy", pair: "USDJPY", name: "USD/JPY" },
    { id: "gbpusd", pair: "GBPUSD", name: "GBP/USD" },
    { id: "usdchf", pair: "USDCHF", name: "USD/CHF" }
  ];

  const quotes = await Promise.all(
    pairs.map(p => polygonFX(p.pair, POLYGON_KEY))
  );

  const fx = {};
  pairs.forEach((p, i) => {
    fx[p.id] = quotes[i] ? { name: p.name, ...quotes[i] } : null;
  });

  res.json({ timestamp: new Date().toISOString(), fx });
});

// Options contracts (Polygon)
router.get("/options/contracts/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) return res.status(500).json({ error: "polygon_key_missing" });

  const symbol = req.params.symbol.toUpperCase();
  const limit = req.query.limit || 50;
  const type = req.query.type || "";
  const expiration = req.query.expiration || "";

  let url = `/v3/reference/options/contracts?underlying_ticker=${symbol}&limit=${limit}`;
  if (type) url += `&contract_type=${type}`;
  if (expiration) url += `&expiration_date=${expiration}`;

  const data = await polygonGet(url, POLYGON_KEY);
  if (!data) return res.status(500).json({ error: "polygon_error" });

  res.json({
    symbol,
    count: data.results?.length || 0,
    contracts: data.results || []
  });
});

// Options chain with greeks
router.get("/options/chain/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) return res.status(500).json({ error: "polygon_key_missing" });

  const symbol = req.params.symbol.toUpperCase();
  const expiration = req.query.expiration || "";
  const strikeFrom = req.query.strike_from || "";
  const strikeTo = req.query.strike_to || "";

  let url = `/v3/snapshot/options/${symbol}?limit=100`;
  if (expiration) url += `&expiration_date=${expiration}`;
  if (strikeFrom) url += `&strike_price.gte=${strikeFrom}`;
  if (strikeTo) url += `&strike_price.lte=${strikeTo}`;

  const data = await polygonGet(url, POLYGON_KEY);
  if (!data) return res.status(500).json({ error: "polygon_error" });

  const chain = (data.results || []).map(opt => ({
    contract: opt.details?.ticker,
    type: opt.details?.contract_type,
    strike: opt.details?.strike_price,
    expiration: opt.details?.expiration_date,
    lastPrice: opt.day?.close,
    bid: opt.last_quote?.bid,
    ask: opt.last_quote?.ask,
    volume: opt.day?.volume,
    openInterest: opt.open_interest,
    impliedVolatility: opt.greeks?.iv,
    delta: opt.greeks?.delta,
    gamma: opt.greeks?.gamma,
    theta: opt.greeks?.theta,
    vega: opt.greeks?.vega,
    underlyingPrice: opt.underlying_asset?.price
  }));

  res.json({ symbol, count: chain.length, chain });
});

// Options expirations
router.get("/options/expirations/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) return res.status(500).json({ error: "polygon_key_missing" });

  const symbol = req.params.symbol.toUpperCase();
  const data = await polygonGet(`/v3/reference/options/contracts?underlying_ticker=${symbol}&limit=250`, POLYGON_KEY);

  if (!data) return res.status(500).json({ error: "polygon_error" });

  const expirations = [...new Set(
    (data.results || []).map(c => c.expiration_date)
  )].sort();

  res.json({ symbol, expirations });
});

// Unusual Options Activity
router.get("/options/unusual", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) return res.status(500).json({ error: "polygon_key_missing" });

  const symbols = (req.query.symbols || "SPY,QQQ,AAPL,TSLA,NVDA,AMD").split(",");
  const minVolume = parseInt(req.query.min_volume) || 1000;
  const minVolOi = parseFloat(req.query.min_vol_oi) || 0.5;

  try {
    const allOptions = await Promise.all(
      symbols.map(async (symbol) => {
        const sym = symbol.trim().toUpperCase();
        const data = await polygonGet(`/v3/snapshot/options/${sym}?limit=100`, POLYGON_KEY);
        if (!data?.results) return [];

        return data.results
          .filter(opt => {
            const volume = opt.day?.volume || 0;
            const oi = opt.open_interest || 1;
            return volume >= minVolume && (volume / oi) >= minVolOi;
          })
          .map(opt => ({
            underlying: sym,
            contract: opt.details?.ticker,
            type: opt.details?.contract_type,
            strike: opt.details?.strike_price,
            expiration: opt.details?.expiration_date,
            volume: opt.day?.volume,
            openInterest: opt.open_interest,
            volOiRatio: +((opt.day?.volume || 0) / (opt.open_interest || 1)).toFixed(2),
            lastPrice: opt.day?.close,
            change: opt.day?.change,
            changePercent: opt.day?.change_percent,
            impliedVolatility: opt.greeks?.iv,
            delta: opt.greeks?.delta,
            underlyingPrice: opt.underlying_asset?.price
          }));
      })
    );

    const uoa = allOptions
      .flat()
      .sort((a, b) => b.volOiRatio - a.volOiRatio)
      .slice(0, 50);

    res.json({
      timestamp: new Date().toISOString(),
      count: uoa.length,
      uoa
    });
  } catch (e) {
    res.status(500).json({ error: "uoa_error", message: e.message });
  }
});

// UOA for specific symbol
router.get("/options/unusual/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) return res.status(500).json({ error: "polygon_key_missing" });

  const symbol = req.params.symbol.toUpperCase();
  const minVolume = parseInt(req.query.min_volume) || 500;
  const minVolOi = parseFloat(req.query.min_vol_oi) || 0.3;

  try {
    const data = await polygonGet(`/v3/snapshot/options/${symbol}?limit=250`, POLYGON_KEY);
    if (!data?.results) {
      return res.json({ symbol, count: 0, uoa: [] });
    }

    const uoa = data.results
      .filter(opt => {
        const volume = opt.day?.volume || 0;
        const oi = opt.open_interest || 1;
        return volume >= minVolume && (volume / oi) >= minVolOi;
      })
      .map(opt => ({
        contract: opt.details?.ticker,
        type: opt.details?.contract_type,
        strike: opt.details?.strike_price,
        expiration: opt.details?.expiration_date,
        volume: opt.day?.volume,
        openInterest: opt.open_interest,
        volOiRatio: +((opt.day?.volume || 0) / (opt.open_interest || 1)).toFixed(2),
        lastPrice: opt.day?.close,
        bid: opt.last_quote?.bid,
        ask: opt.last_quote?.ask,
        change: opt.day?.change,
        changePercent: opt.day?.change_percent,
        impliedVolatility: opt.greeks?.iv,
        delta: opt.greeks?.delta,
        gamma: opt.greeks?.gamma,
        theta: opt.greeks?.theta,
        vega: opt.greeks?.vega,
        underlyingPrice: opt.underlying_asset?.price
      }))
      .sort((a, b) => b.volOiRatio - a.volOiRatio);

    res.json({
      symbol,
      underlyingPrice: data.results[0]?.underlying_asset?.price,
      count: uoa.length,
      uoa
    });
  } catch (e) {
    res.status(500).json({ error: "uoa_error", message: e.message });
  }
});

// Market status endpoint
router.get("/status", (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    ...isUSMarketOpen()
  });
});

// Clear cache endpoint (admin)
router.post("/cache/clear", (req, res) => {
  dataCache.clear();
  res.json({ message: "Cache cleared", timestamp: new Date().toISOString() });
});

// ============ CHART DATA ENDPOINT ============
router.get("/chart/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const symbol = req.params.symbol.toUpperCase();
  const { from, to, multiplier = 1, timespan = 'day' } = req.query;

  if (!from || !to) {
    return res.status(400).json({ error: "from and to dates required" });
  }

  const cacheKey = `chart_${symbol}_${from}_${to}_${multiplier}_${timespan}`;
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Chart ${symbol} ${timespan}`);
    return res.json(cached);
  }

  try {
    const url = `https://api.polygon.io/v2/aggs/ticker/${symbol}/range/${multiplier}/${timespan}/${from}/${to}?adjusted=true&sort=asc&apiKey=${POLYGON_KEY}`;
    
    console.log(`[Polygon API] Fetching chart for ${symbol} (${timespan})`);
    const response = await fetch(url);
    
    if (!response.ok) {
      console.error(`Polygon chart error ${response.status} for ${symbol}`);
      return res.status(response.status).json({ 
        error: "polygon_error", 
        status: response.status 
      });
    }

    const data = await response.json();
    dataCache.set(cacheKey, data, 'closed');
    
    res.json(data);
  } catch (e) {
    console.error("Chart endpoint error:", e.message);
    res.status(500).json({ error: "chart_error", message: e.message });
  }
});

// ============ CRYPTO ENDPOINT ============
router.get("/crypto", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const cacheKey = 'crypto_snapshot';
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log('[Cache HIT] Crypto snapshot');
    return res.json(cached);
  }

  try {
    console.log('[Polygon API] Fetching crypto snapshot...');
    const response = await fetch(
      `https://api.polygon.io/v2/snapshot/locale/global/markets/crypto/tickers?apiKey=${POLYGON_KEY}`
    );

    if (!response.ok) {
      throw new Error(`Polygon Crypto API error: ${response.status}`);
    }

    const data = await response.json();
    const tickers = data.tickers || [];

    const symbolMap = {
      'X:BTCUSD': 'BTC',
      'X:ETHUSD': 'ETH',
      'X:BNBUSD': 'BNB',
      'X:SOLUSD': 'SOL',
      'X:XRPUSD': 'XRP',
      'X:ADAUSD': 'ADA',
      'X:DOGEUSD': 'DOGE',
      'X:AVAXUSD': 'AVAX',
      'X:DOTUSD': 'DOT',
      'X:LINKUSD': 'LINK',
      'X:MATICUSD': 'MATIC',
      'X:UNIUSD': 'UNI',
      'X:LTCUSD': 'LTC',
      'X:SHIBUSD': 'SHIB',
      'X:ATOMUSD': 'ATOM',
      'X:XLMUSD': 'XLM',
      'X:NEARUSD': 'NEAR',
      'X:ALGOUSD': 'ALGO',
      'X:ICPUSD': 'ICP',
      'X:FILUSD': 'FIL'
    };

    const result = {};
    for (const ticker of tickers) {
      const symbol = symbolMap[ticker.ticker];
      if (symbol) {
        const prevClose = ticker.prevDay?.c || 0;
        const currentPrice = ticker.day?.c || ticker.min?.c || prevClose;
        
        let changePercent = ticker.todaysChangePerc || 0;
        if (changePercent === 0 && prevClose > 0 && currentPrice > 0 && currentPrice !== prevClose) {
          const calculated = calculateChange(currentPrice, prevClose);
          changePercent = calculated.changePercent;
        }

        result[symbol] = {
          symbol,
          price: currentPrice,
          change: ticker.todaysChange || (currentPrice - prevClose),
          changePercent: +changePercent.toFixed(2),
          volume: ticker.day?.v || 0,
          high: ticker.day?.h,
          low: ticker.day?.l,
          previousClose: prevClose
        };
      }
    }

    const response_data = {
      timestamp: new Date().toISOString(),
      count: Object.keys(result).length,
      tickers: result
    };

    dataCache.set(cacheKey, response_data, 'regular');
    console.log(`[Crypto] Loaded ${Object.keys(result).length} crypto tickers`);
    
    res.json(response_data);
  } catch (e) {
    console.error("Crypto endpoint error:", e.message);
    res.status(500).json({ error: "crypto_error", message: e.message });
  }
});

// ============ COMMODITIES ENDPOINT (ETF-based) ============
router.get("/commodities", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const marketStatus = isUSMarketOpen();
  const cacheKey = `commodities_${marketStatus.session}`;
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log('[Cache HIT] Commodities');
    return res.json(cached);
  }

  try {
    const commodityETFs = [
      { symbol: 'GLD', name: 'Gold ETF', commodity: 'Gold' },
      { symbol: 'SLV', name: 'Silver ETF', commodity: 'Silver' },
      { symbol: 'USO', name: 'Oil ETF', commodity: 'Crude Oil' },
      { symbol: 'UNG', name: 'Natural Gas ETF', commodity: 'Natural Gas' },
      { symbol: 'CPER', name: 'Copper ETF', commodity: 'Copper' },
      { symbol: 'WEAT', name: 'Wheat ETF', commodity: 'Wheat' },
      { symbol: 'CORN', name: 'Corn ETF', commodity: 'Corn' },
      { symbol: 'DBA', name: 'Agriculture ETF', commodity: 'Agriculture' },
      { symbol: 'PDBC', name: 'Commodities ETF', commodity: 'Broad Commodities' },
      { symbol: 'DBC', name: 'Commodity Index', commodity: 'Commodity Index' }
    ];

    const quotes = await Promise.all(
      commodityETFs.map(c => polygonSnapshot(c.symbol, POLYGON_KEY))
    );

    const result = {};
    commodityETFs.forEach((c, i) => {
      const q = quotes[i];
      if (q) {
        result[c.symbol] = {
          symbol: c.symbol,
          name: c.name,
          commodity: c.commodity,
          price: q.price,
          change: q.extendedHoursChange || q.change || 0,
          changePercent: q.extendedHoursChangePercent || q.changePercent || 0,
          volume: q.volume || 0,
          previousClose: q.previousClose || 0,
          session: marketStatus.session
        };
      }
    });

    const response_data = {
      timestamp: new Date().toISOString(),
      session: marketStatus.session,
      count: Object.keys(result).length,
      tickers: result
    };

    dataCache.set(cacheKey, response_data, marketStatus.session);
    res.json(response_data);
  } catch (e) {
    console.error("Commodities endpoint error:", e.message);
    res.status(500).json({ error: "commodities_error", message: e.message });
  }
});

// ============ FUTURES ENDPOINT (ETF Proxies) ============
router.get("/futures", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const marketStatus = isUSMarketOpen();
  const cacheKey = `futures_${marketStatus.session}`;
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log('[Cache HIT] Futures');
    return res.json(cached);
  }

  try {
    const futuresMap = [
      { future: 'ES', etf: 'SPY', name: 'E-mini S&P 500' },
      { future: 'NQ', etf: 'QQQ', name: 'E-mini Nasdaq' },
      { future: 'YM', etf: 'DIA', name: 'E-mini Dow' },
      { future: 'RTY', etf: 'IWM', name: 'E-mini Russell' },
      { future: 'CL', etf: 'USO', name: 'Crude Oil WTI' },
      { future: 'GC', etf: 'GLD', name: 'Gold' },
      { future: 'SI', etf: 'SLV', name: 'Silver' },
      { future: 'NG', etf: 'UNG', name: 'Natural Gas' },
      { future: 'ZB', etf: 'TLT', name: '30Y T-Bond' },
      { future: 'HG', etf: 'CPER', name: 'Copper' },
      { future: 'ZC', etf: 'CORN', name: 'Corn' },
      { future: 'ZW', etf: 'WEAT', name: 'Wheat' }
    ];

    const etfSymbols = [...new Set(futuresMap.map(f => f.etf))];
    const quotes = await Promise.all(
      etfSymbols.map(s => polygonSnapshot(s, POLYGON_KEY))
    );

    const etfQuotes = {};
    etfSymbols.forEach((s, i) => {
      if (quotes[i]) etfQuotes[s] = quotes[i];
    });

    const result = {};
    futuresMap.forEach(f => {
      const q = etfQuotes[f.etf];
      if (q) {
        result[f.future] = {
          symbol: f.future,
          name: f.name,
          etfProxy: f.etf,
          price: q.price,
          change: q.extendedHoursChange || q.change || 0,
          changePercent: q.extendedHoursChangePercent || q.changePercent || 0,
          volume: q.volume || 0,
          previousClose: q.previousClose || 0,
          session: marketStatus.session
        };
      }
    });

    const response_data = {
      timestamp: new Date().toISOString(),
      session: marketStatus.session,
      count: Object.keys(result).length,
      tickers: result
    };

    dataCache.set(cacheKey, response_data, marketStatus.session);
    res.json(response_data);
  } catch (e) {
    console.error("Futures endpoint error:", e.message);
    res.status(500).json({ error: "futures_error", message: e.message });
  }
});

export default router;