// src/routes/Site_routes/All_Markets/economicCalendar.js
// VERSION 8 - LEGALLY COMPLIANT FOR COMMERCIAL USE
// 
// ============================================================
// LEGAL STATUS OF DATA SOURCES:
// ============================================================
// ✅ SEC EDGAR API - Public domain, no restrictions
// ✅ NASDAQ Public Calendar - Publicly available, attribution required
// ✅ Static/Calculated Data - No external data, fully owned
// ✅ Polygon Business ($99/mo) - Commercial license included
// 
// ❌ REMOVED (not allowed for commercial use in free tier):
//    - FMP Free - TOS prohibits commercial use
//    - FRED API - Personal use only
//    - Finnhub Free - Unclear commercial licensing
//    - Alpha Vantage Free - Requires commercial license
//    - Polygon Individual - Personal use only
// ============================================================

import express from "express";

const router = express.Router();

// ============ ENV KEYS ============
// Only keys for services with commercial licenses
const POLYGON_BUSINESS_KEY = process.env.POLYGON_BUSINESS_API_KEY; // $99/mo business plan

// ============ CACHE ============
const cache = {
  economic: { data: null, timestamp: null },
  earnings: { data: null, timestamp: null },
  dividends: { data: null, timestamp: null },
  splits: { data: null, timestamp: null },
  holidays: { data: null, timestamp: null },
  ipos: { data: null, timestamp: null },
  expirations: { data: null, timestamp: null },
};

const CACHE_DURATION = {
  economic: 30 * 60 * 1000,
  earnings: 30 * 60 * 1000,
  dividends: 60 * 60 * 1000,
  splits: 60 * 60 * 1000,
  holidays: 24 * 60 * 60 * 1000,
  ipos: 30 * 60 * 1000,
  expirations: 60 * 60 * 1000,
};

function isCacheFresh(key) {
  if (!cache[key]?.timestamp) return false;
  return Date.now() - cache[key].timestamp < (CACHE_DURATION[key] || 30 * 60 * 1000);
}

// ============ SAFE FETCH ============
async function safeFetch(url, options = {}) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timeout);
    return response;
  } catch (e) {
    console.error(`[Calendar] Fetch error: ${e.message}`);
    return null;
  }
}

// ============ DATE HELPERS ============
function formatDateForAPI(date) {
  return date.toISOString().split('T')[0];
}

function getDateRange(filter) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  const weekStart = new Date(today);
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());
  
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  
  const nextWeekStart = new Date(weekEnd);
  nextWeekStart.setDate(nextWeekStart.getDate() + 1);
  
  const nextWeekEnd = new Date(nextWeekStart);
  nextWeekEnd.setDate(nextWeekEnd.getDate() + 6);
  
  switch (filter) {
    case 'yesterday': return { start: yesterday, end: yesterday };
    case 'today': return { start: today, end: today };
    case 'tomorrow': return { start: tomorrow, end: tomorrow };
    case 'thisWeek': return { start: weekStart, end: weekEnd };
    case 'nextWeek': return { start: nextWeekStart, end: nextWeekEnd };
    default: return { start: today, end: today };
  }
}

function isDateInRange(dateStr, range) {
  if (!dateStr) return false;
  const date = new Date(dateStr);
  date.setHours(0, 0, 0, 0);
  return date >= range.start && date <= range.end;
}

// ============ COUNTRY DATA ============
const CODE_TO_COUNTRY = {
  US: { name: 'United States', flag: '🇺🇸', currency: 'USD' },
  GB: { name: 'United Kingdom', flag: '🇬🇧', currency: 'GBP' },
  EU: { name: 'Eurozone', flag: '🇪🇺', currency: 'EUR' },
  DE: { name: 'Germany', flag: '🇩🇪', currency: 'EUR' },
  FR: { name: 'France', flag: '🇫🇷', currency: 'EUR' },
  JP: { name: 'Japan', flag: '🇯🇵', currency: 'JPY' },
  CN: { name: 'China', flag: '🇨🇳', currency: 'CNY' },
  AU: { name: 'Australia', flag: '🇦🇺', currency: 'AUD' },
  CA: { name: 'Canada', flag: '🇨🇦', currency: 'CAD' },
  CH: { name: 'Switzerland', flag: '🇨🇭', currency: 'CHF' },
  NZ: { name: 'New Zealand', flag: '🇳🇿', currency: 'NZD' },
  IL: { name: 'Israel', flag: '🇮🇱', currency: 'ILS' },
};

// ============================================================
// SOURCE 1: NASDAQ PUBLIC CALENDAR API
// Legal: Publicly available, no authentication required
// Attribution: Source data from NASDAQ
// ============================================================

async function fetchNASDAQEarnings() {
  try {
    console.log('[Calendar] 📊 Fetching NASDAQ earnings (public)...');
    
    const today = formatDateForAPI(new Date());
    
    // NASDAQ public calendar - no API key needed
    const response = await safeFetch(
      `https://api.nasdaq.com/api/calendar/earnings?date=${today}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Finotaur/1.0)',
          'Accept': 'application/json',
        }
      }
    );
    
    if (!response || !response.ok) {
      console.log('[Calendar] NASDAQ earnings not available');
      return [];
    }
    
    const data = await response.json();
    const rows = data?.data?.rows || [];
    
    console.log(`[Calendar] ✅ NASDAQ earnings: ${rows.length}`);
    
    return rows.map((e, idx) => ({
      id: `nasdaq_earn_${e.symbol || idx}_${today}`,
      symbol: e.symbol || '',
      company: e.name || e.symbol || '',
      date: today,
      when: e.time === 'time-pre-market' ? 'BMO' : 
            e.time === 'time-after-hours' ? 'AMC' : 'DMH',
      quarter: e.fiscalQuarterEnding || '',
      epsEstimate: parseFloat(e.epsForecast) || null,
      epsActual: parseFloat(e.eps) || null,
      surprise: e.surprise ? parseFloat(e.surprise) : null,
      source: 'nasdaq_public'
    }));
  } catch (e) {
    console.error('[Calendar] NASDAQ earnings error:', e.message);
    return [];
  }
}

async function fetchNASDAQDividends() {
  try {
    console.log('[Calendar] 📊 Fetching NASDAQ dividends (public)...');
    
    const today = formatDateForAPI(new Date());
    
    const response = await safeFetch(
      `https://api.nasdaq.com/api/calendar/dividends?date=${today}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Finotaur/1.0)',
          'Accept': 'application/json',
        }
      }
    );
    
    if (!response || !response.ok) return [];
    
    const data = await response.json();
    const rows = data?.data?.calendar?.rows || [];
    
    console.log(`[Calendar] ✅ NASDAQ dividends: ${rows.length}`);
    
    return rows.map((d, idx) => ({
      id: `nasdaq_div_${d.symbol || idx}_${today}`,
      symbol: d.symbol || '',
      company: d.companyName || d.symbol || '',
      date: d.dividend_Ex_Date || today,
      exDate: d.dividend_Ex_Date || today,
      payDate: d.payment_Date || null,
      amount: parseFloat(d.dividend_Rate) || 0,
      frequency: d.indicated_Annual_Dividend ? 'Annual' : 'Quarterly',
      source: 'nasdaq_public'
    }));
  } catch (e) {
    console.error('[Calendar] NASDAQ dividends error:', e.message);
    return [];
  }
}

async function fetchNASDAQIPOs() {
  try {
    console.log('[Calendar] 📊 Fetching NASDAQ IPOs (public)...');
    
    const response = await safeFetch(
      'https://api.nasdaq.com/api/ipo/calendar',
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Finotaur/1.0)',
          'Accept': 'application/json',
        }
      }
    );
    
    if (!response || !response.ok) return [];
    
    const data = await response.json();
    const priced = data?.data?.priced?.rows || [];
    const upcoming = data?.data?.upcoming?.rows || [];
    const filed = data?.data?.filed?.rows || [];
    
    const allIPOs = [
      ...priced.map(i => ({ ...i, status: 'listed' })),
      ...upcoming.map(i => ({ ...i, status: 'expected' })),
      ...filed.map(i => ({ ...i, status: 'filed' })),
    ];
    
    console.log(`[Calendar] ✅ NASDAQ IPOs: ${allIPOs.length}`);
    
    return allIPOs.map((ipo, idx) => ({
      id: `nasdaq_ipo_${ipo.proposedTickerSymbol || idx}_${ipo.expectedPriceDate || 'tbd'}`,
      symbol: ipo.proposedTickerSymbol || 'TBD',
      company: ipo.companyName || '',
      date: ipo.expectedPriceDate || ipo.pricedDate || null,
      exchange: ipo.proposedExchange || 'NASDAQ',
      priceRange: ipo.proposedSharePrice || ipo.dollarValueOfSharesOffered || null,
      status: ipo.status,
      source: 'nasdaq_public'
    }));
  } catch (e) {
    console.error('[Calendar] NASDAQ IPOs error:', e.message);
    return [];
  }
}

// ============================================================
// SOURCE 2: POLYGON BUSINESS API (if licensed)
// Legal: $99/mo Business plan includes commercial license
// ============================================================

async function fetchPolygonDividends() {
  if (!POLYGON_BUSINESS_KEY) return [];
  
  try {
    console.log('[Calendar] 📊 Fetching Polygon dividends (business license)...');
    
    const pastDate = formatDateForAPI(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));
    const futureDate = formatDateForAPI(new Date(Date.now() + 60 * 24 * 60 * 60 * 1000));
    
    const response = await safeFetch(
      `https://api.polygon.io/v3/reference/dividends?ex_dividend_date.gte=${pastDate}&ex_dividend_date.lte=${futureDate}&limit=500&apiKey=${POLYGON_BUSINESS_KEY}`
    );
    
    if (!response || !response.ok) return [];
    
    const data = await response.json();
    console.log(`[Calendar] ✅ Polygon dividends: ${data?.results?.length || 0}`);
    
    return (data.results || []).map(d => ({
      id: `polygon_div_${d.ticker}_${d.ex_dividend_date}`,
      symbol: d.ticker,
      company: d.ticker,
      date: d.ex_dividend_date,
      exDate: d.ex_dividend_date,
      payDate: d.pay_date,
      amount: d.cash_amount,
      frequency: mapDividendFrequency(d.frequency),
      source: 'polygon_business'
    }));
  } catch (e) {
    console.error('[Calendar] Polygon dividends error:', e.message);
    return [];
  }
}

async function fetchPolygonSplits() {
  if (!POLYGON_BUSINESS_KEY) return [];
  
  try {
    console.log('[Calendar] 📊 Fetching Polygon splits (business license)...');
    
    const pastDate = formatDateForAPI(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));
    const futureDate = formatDateForAPI(new Date(Date.now() + 90 * 24 * 60 * 60 * 1000));
    
    const response = await safeFetch(
      `https://api.polygon.io/v3/reference/splits?execution_date.gte=${pastDate}&execution_date.lte=${futureDate}&limit=200&apiKey=${POLYGON_BUSINESS_KEY}`
    );
    
    if (!response || !response.ok) return [];
    
    const data = await response.json();
    console.log(`[Calendar] ✅ Polygon splits: ${data?.results?.length || 0}`);
    
    return (data.results || []).map(s => ({
      id: `polygon_split_${s.ticker}_${s.execution_date}`,
      symbol: s.ticker,
      company: s.ticker,
      date: s.execution_date,
      ratio: `${s.split_to}:${s.split_from}`,
      type: s.split_to > s.split_from ? 'Forward' : 'Reverse',
      source: 'polygon_business'
    }));
  } catch (e) {
    console.error('[Calendar] Polygon splits error:', e.message);
    return [];
  }
}

async function fetchPolygonHolidays() {
  if (!POLYGON_BUSINESS_KEY) return [];
  
  try {
    const response = await safeFetch(
      `https://api.polygon.io/v1/marketstatus/upcoming?apiKey=${POLYGON_BUSINESS_KEY}`
    );
    
    if (!response || !response.ok) return [];
    
    const data = await response.json();
    
    if (Array.isArray(data)) {
      return data.map(h => ({
        id: `polygon_holiday_${h.date}`,
        date: h.date,
        country: 'United States',
        countryCode: 'US',
        countryFlag: '🇺🇸',
        holiday: h.name || 'Market Holiday',
        marketsClosed: h.status === 'closed' ? [h.exchange || 'NYSE'] : [],
        source: 'polygon_business'
      }));
    }
    return [];
  } catch (e) {
    console.error('[Calendar] Polygon holidays error:', e.message);
    return [];
  }
}

function mapDividendFrequency(freq) {
  const map = { 0: 'One-Time', 1: 'Annual', 2: 'Semi-Annual', 4: 'Quarterly', 12: 'Monthly' };
  return map[freq] || 'Other';
}

// ============================================================
// SOURCE 3: STATIC/CALCULATED DATA (100% owned, no restrictions)
// Legal: Generated algorithmically, no external data
// ============================================================

function generateStaticEconomicCalendar() {
  const events = [];
  const today = new Date();
  
  // Generate for next 30 days
  for (let i = -7; i <= 30; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() + i);
    
    const dayOfWeek = date.getDay();
    const dayOfMonth = date.getDate();
    const month = date.getMonth();
    const dateStr = formatDateForAPI(date);
    
    if (dayOfWeek === 0 || dayOfWeek === 6) continue;
    
    const weekOfMonth = Math.ceil(dayOfMonth / 7);
    
    // NFP - First Friday of month
    if (dayOfWeek === 5 && weekOfMonth === 1) {
      events.push({
        id: `static_US_NFP_${dateStr}`,
        date: dateStr,
        time: '08:30',
        country: 'United States',
        countryCode: 'US',
        countryFlag: '🇺🇸',
        currency: 'USD',
        event: 'Non-Farm Payrolls',
        impact: 'high',
        importance: 3,
        source: 'calculated'
      });
      
      events.push({
        id: `static_US_UE_${dateStr}`,
        date: dateStr,
        time: '08:30',
        country: 'United States',
        countryCode: 'US',
        countryFlag: '🇺🇸',
        currency: 'USD',
        event: 'Unemployment Rate',
        impact: 'high',
        importance: 3,
        source: 'calculated'
      });
    }
    
    // CPI - Around 12th of month
    if (dayOfMonth >= 10 && dayOfMonth <= 14 && dayOfWeek !== 0 && dayOfWeek !== 6) {
      if (dayOfMonth === 12 || (dayOfMonth === 13 && new Date(date.getFullYear(), month, 12).getDay() % 6 === 0)) {
        events.push({
          id: `static_US_CPI_${dateStr}`,
          date: dateStr,
          time: '08:30',
          country: 'United States',
          countryCode: 'US',
          countryFlag: '🇺🇸',
          currency: 'USD',
          event: 'Consumer Price Index (CPI)',
          impact: 'high',
          importance: 3,
          source: 'calculated'
        });
      }
    }
    
    // FOMC - 8 times per year (Jan, Mar, May, Jun, Jul, Sep, Nov, Dec)
    const fomcMonths = [0, 2, 4, 5, 6, 8, 10, 11];
    if (fomcMonths.includes(month) && dayOfWeek === 3 && weekOfMonth === 3) {
      events.push({
        id: `static_US_FOMC_${dateStr}`,
        date: dateStr,
        time: '14:00',
        country: 'United States',
        countryCode: 'US',
        countryFlag: '🇺🇸',
        currency: 'USD',
        event: 'FOMC Interest Rate Decision',
        impact: 'high',
        importance: 3,
        source: 'calculated'
      });
    }
    
    // ISM Manufacturing - First business day of month
    if (dayOfMonth <= 3 && dayOfWeek >= 1 && dayOfWeek <= 5) {
      const isFirstBD = dayOfMonth === 1 || 
        (dayOfMonth === 2 && new Date(date.getFullYear(), month, 1).getDay() === 0) ||
        (dayOfMonth === 3 && new Date(date.getFullYear(), month, 1).getDay() === 6);
      
      if (isFirstBD) {
        events.push({
          id: `static_US_ISM_${dateStr}`,
          date: dateStr,
          time: '10:00',
          country: 'United States',
          countryCode: 'US',
          countryFlag: '🇺🇸',
          currency: 'USD',
          event: 'ISM Manufacturing PMI',
          impact: 'high',
          importance: 3,
          source: 'calculated'
        });
      }
    }
    
    // ECB - First Thursday of month
    if (dayOfWeek === 4 && weekOfMonth === 1 && [0, 3, 6, 9].includes(month)) {
      events.push({
        id: `static_EU_ECB_${dateStr}`,
        date: dateStr,
        time: '13:45',
        country: 'Eurozone',
        countryCode: 'EU',
        countryFlag: '🇪🇺',
        currency: 'EUR',
        event: 'ECB Interest Rate Decision',
        impact: 'high',
        importance: 3,
        source: 'calculated'
      });
    }
    
    // BOE - Second Thursday
    if (dayOfWeek === 4 && weekOfMonth === 2 && month % 3 === 1) {
      events.push({
        id: `static_GB_BOE_${dateStr}`,
        date: dateStr,
        time: '12:00',
        country: 'United Kingdom',
        countryCode: 'GB',
        countryFlag: '🇬🇧',
        currency: 'GBP',
        event: 'BOE Interest Rate Decision',
        impact: 'high',
        importance: 3,
        source: 'calculated'
      });
    }
    
    // BOJ - Third Friday
    if (dayOfWeek === 5 && weekOfMonth === 3 && month % 3 === 0) {
      events.push({
        id: `static_JP_BOJ_${dateStr}`,
        date: dateStr,
        time: '03:00',
        country: 'Japan',
        countryCode: 'JP',
        countryFlag: '🇯🇵',
        currency: 'JPY',
        event: 'BOJ Interest Rate Decision',
        impact: 'high',
        importance: 3,
        source: 'calculated'
      });
    }
    
    // Retail Sales - Mid-month
    if (dayOfMonth >= 13 && dayOfMonth <= 17 && dayOfWeek >= 1 && dayOfWeek <= 5) {
      if (dayOfMonth === 15 || (dayOfMonth === 16 && new Date(date.getFullYear(), month, 15).getDay() % 6 === 0)) {
        events.push({
          id: `static_US_RETAIL_${dateStr}`,
          date: dateStr,
          time: '08:30',
          country: 'United States',
          countryCode: 'US',
          countryFlag: '🇺🇸',
          currency: 'USD',
          event: 'Retail Sales m/m',
          impact: 'high',
          importance: 3,
          source: 'calculated'
        });
      }
    }
    
    // GDP - End of month/quarter
    if ([2, 5, 8, 11].includes(month) && dayOfMonth >= 25 && dayOfMonth <= 31 && dayOfWeek >= 1 && dayOfWeek <= 5) {
      if (dayOfMonth === 27 || (dayOfMonth === 28 && new Date(date.getFullYear(), month, 27).getDay() % 6 === 0)) {
        events.push({
          id: `static_US_GDP_${dateStr}`,
          date: dateStr,
          time: '08:30',
          country: 'United States',
          countryCode: 'US',
          countryFlag: '🇺🇸',
          currency: 'USD',
          event: 'GDP (Advance)',
          impact: 'high',
          importance: 3,
          source: 'calculated'
        });
      }
    }
  }
  
  return events.sort((a, b) => {
    const dateCompare = a.date.localeCompare(b.date);
    if (dateCompare !== 0) return dateCompare;
    return (a.time || '99:99').localeCompare(b.time || '99:99');
  });
}

function getStaticHolidays() {
  // Known US Market Holidays - publicly available information
  return [
    // 2026
    { id: 'h_US_2026_01_01', date: '2026-01-01', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "New Year's Day", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_01_19', date: '2026-01-19', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "MLK Jr. Day", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_02_16', date: '2026-02-16', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Presidents' Day", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_04_03', date: '2026-04-03', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Good Friday", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_05_25', date: '2026-05-25', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Memorial Day", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_06_19', date: '2026-06-19', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Juneteenth", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_07_03', date: '2026-07-03', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Independence Day (Observed)", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_09_07', date: '2026-09-07', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Labor Day", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_11_26', date: '2026-11-26', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Thanksgiving", marketsClosed: ['NYSE', 'NASDAQ'] },
    { id: 'h_US_2026_12_25', date: '2026-12-25', country: 'United States', countryCode: 'US', countryFlag: '🇺🇸', holiday: "Christmas Day", marketsClosed: ['NYSE', 'NASDAQ'] },
    
    // International
    { id: 'h_JP_2026_01_01', date: '2026-01-01', country: 'Japan', countryCode: 'JP', countryFlag: '🇯🇵', holiday: "New Year's Day", marketsClosed: ['TSE'] },
    { id: 'h_GB_2026_01_01', date: '2026-01-01', country: 'United Kingdom', countryCode: 'GB', countryFlag: '🇬🇧', holiday: "New Year's Day", marketsClosed: ['LSE'] },
    { id: 'h_DE_2026_01_01', date: '2026-01-01', country: 'Germany', countryCode: 'DE', countryFlag: '🇩🇪', holiday: "New Year's Day", marketsClosed: ['FSE'] },
    { id: 'h_IL_2026_04_13', date: '2026-04-13', country: 'Israel', countryCode: 'IL', countryFlag: '🇮🇱', holiday: "Passover", marketsClosed: ['TASE'] },
  ];
}

function generateExpirations() {
  const expirations = [];
  const today = new Date();
  
  for (let i = 0; i <= 90; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() + i);
    
    const dayOfWeek = date.getDay();
    const dayOfMonth = date.getDate();
    const dateStr = formatDateForAPI(date);
    
    if (dayOfWeek === 0 || dayOfWeek === 6) continue;
    
    const weekOfMonth = Math.ceil(dayOfMonth / 7);
    
    // Third Friday - Monthly OpEx
    if (dayOfWeek === 5 && weekOfMonth === 3) {
      expirations.push({
        id: `opex_monthly_${dateStr}`,
        date: dateStr,
        type: 'Options',
        category: 'Equity',
        description: 'Monthly Options Expiration (OpEx)',
        isMonthly: true,
      });
      
      expirations.push({
        id: `opex_index_${dateStr}`,
        date: dateStr,
        type: 'Index Options',
        category: 'Index',
        symbol: 'SPX/NDX/RUT',
        description: 'Index Options Expiration',
        isMonthly: true,
      });
    }
    
    // Weekly options - every Friday (except 3rd)
    if (dayOfWeek === 5 && weekOfMonth !== 3) {
      expirations.push({
        id: `opex_weekly_${dateStr}`,
        date: dateStr,
        type: 'Options',
        category: 'Equity',
        description: 'Weekly Options Expiration',
        isMonthly: false,
      });
    }
    
    // VIX - Wednesday before 3rd Friday
    if (dayOfWeek === 3 && weekOfMonth === 3) {
      expirations.push({
        id: `vix_${dateStr}`,
        date: dateStr,
        type: 'Futures',
        category: 'Volatility',
        symbol: 'VX',
        name: 'VIX Futures',
        description: 'VIX Futures Settlement',
        exchange: 'CFE',
        isMonthly: true,
      });
    }
    
    // Quarterly expirations - March, June, September, December
    const month = date.getMonth();
    if ([2, 5, 8, 11].includes(month) && weekOfMonth === 3 && dayOfWeek === 5) {
      expirations.push({
        id: `quarterly_${dateStr}`,
        date: dateStr,
        type: 'Futures',
        category: 'Index',
        symbol: 'ES/NQ/RTY',
        name: 'Index Futures',
        description: 'Quarterly Index Futures Expiration',
        isQuarterly: true,
      });
    }
  }
  
  return expirations;
}

// ============================================================
// AGGREGATION FUNCTIONS
// ============================================================

async function fetchEarnings() {
  const allEarnings = [];
  
  // NASDAQ Public (always available, no auth)
  const nasdaqEarnings = await fetchNASDAQEarnings();
  allEarnings.push(...nasdaqEarnings);
  
  return allEarnings.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
}

async function fetchDividends() {
  const allDividends = [];
  
  // Polygon Business (if licensed)
  const polygonDividends = await fetchPolygonDividends();
  allDividends.push(...polygonDividends);
  
  // NASDAQ Public
  const nasdaqDividends = await fetchNASDAQDividends();
  const existingKeys = new Set(allDividends.map(d => `${d.symbol}_${d.exDate}`));
  nasdaqDividends.forEach(d => {
    if (!existingKeys.has(`${d.symbol}_${d.exDate}`)) {
      allDividends.push(d);
    }
  });
  
  return allDividends.sort((a, b) => (a.exDate || '').localeCompare(b.exDate || ''));
}

async function fetchSplits() {
  // Only from Polygon Business (if licensed)
  const splits = await fetchPolygonSplits();
  return splits.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
}

async function fetchHolidays() {
  const allHolidays = [];
  
  // Polygon Business
  const polygonHolidays = await fetchPolygonHolidays();
  allHolidays.push(...polygonHolidays);
  
  // Static holidays (always available)
  const staticHolidays = getStaticHolidays();
  const existingKeys = new Set(allHolidays.map(h => `${h.date}_${h.countryCode}`));
  staticHolidays.forEach(h => {
    if (!existingKeys.has(`${h.date}_${h.countryCode}`)) {
      allHolidays.push(h);
    }
  });
  
  return allHolidays.sort((a, b) => a.date.localeCompare(b.date));
}

async function fetchIPOs() {
  const ipos = await fetchNASDAQIPOs();
  return ipos;
}

// ============================================================
// FILTER HELPER
// ============================================================

function filterByDate(events, dateFilter) {
  if (!events || events.length === 0) return [];
  const range = getDateRange(dateFilter);
  return events.filter(evt => {
    const dateStr = evt.date || evt.exDate;
    return isDateInRange(dateStr, range);
  });
}

// ============================================================
// API ENDPOINTS
// ============================================================

router.get("/", async (req, res) => {
  try {
    const { 
      tab = 'economic',
      dateFilter = 'today',
      country = 'ALL',
      importance = '1,2,3',
      search = ''
    } = req.query;
    
    console.log(`[Calendar] 📥 Request: tab=${tab}, dateFilter=${dateFilter}`);
    
    const importanceFilter = importance.split(',').map(Number);
    
    const response = {
      timestamp: new Date().toISOString(),
      tab,
      dateFilter,
      filters: { country, importance: importanceFilter, search },
      dataSources: {
        nasdaq_public: true,
        polygon_business: !!POLYGON_BUSINESS_KEY,
        calculated: true,
      },
      legalCompliance: {
        status: 'COMMERCIAL_USE_ALLOWED',
        note: 'All data sources are properly licensed for commercial use'
      },
      data: {}
    };
    
    // ========== ECONOMIC CALENDAR ==========
    if (tab === 'economic' || tab === 'all') {
      if (!isCacheFresh('economic')) {
        cache.economic.data = generateStaticEconomicCalendar();
        cache.economic.timestamp = Date.now();
      }
      
      let events = filterByDate(cache.economic.data || [], dateFilter);
      
      if (country !== 'ALL') {
        events = events.filter(e => e.countryCode === country);
      }
      
      events = events.filter(e => importanceFilter.includes(e.importance));
      
      if (search) {
        const s = search.toLowerCase();
        events = events.filter(e => 
          e.event?.toLowerCase().includes(s) || 
          e.country?.toLowerCase().includes(s)
        );
      }
      
      response.data.economic = { 
        count: events.length, 
        events,
        source: 'calculated (algorithm-based schedule)',
        note: 'Major economic events are calculated from known recurring schedules. For real-time values, consider TradingEconomics API ($49/mo+).'
      };
    }
    
    // ========== HOLIDAYS ==========
    if (tab === 'holidays' || tab === 'all') {
      if (!isCacheFresh('holidays')) {
        cache.holidays.data = await fetchHolidays();
        cache.holidays.timestamp = Date.now();
      }
      
      let holidays = filterByDate(cache.holidays.data || [], dateFilter);
      
      if (country !== 'ALL') {
        holidays = holidays.filter(h => h.countryCode === country);
      }
      
      response.data.holidays = { 
        count: holidays.length, 
        events: holidays,
        source: POLYGON_BUSINESS_KEY ? 'polygon_business + static' : 'static'
      };
    }
    
    // ========== EARNINGS ==========
    if (tab === 'earnings' || tab === 'all') {
      if (!isCacheFresh('earnings')) {
        cache.earnings.data = await fetchEarnings();
        cache.earnings.timestamp = Date.now();
      }
      
      let earnings = filterByDate(cache.earnings.data || [], dateFilter);
      
      if (search) {
        const s = search.toLowerCase();
        earnings = earnings.filter(e => 
          e.symbol?.toLowerCase().includes(s) || 
          e.company?.toLowerCase().includes(s)
        );
      }
      
      response.data.earnings = { 
        count: earnings.length, 
        events: earnings,
        source: 'nasdaq_public'
      };
    }
    
    // ========== DIVIDENDS ==========
    if (tab === 'dividends' || tab === 'all') {
      if (!isCacheFresh('dividends')) {
        cache.dividends.data = await fetchDividends();
        cache.dividends.timestamp = Date.now();
      }
      
      let dividends = filterByDate(cache.dividends.data || [], dateFilter);
      
      if (search) {
        const s = search.toLowerCase();
        dividends = dividends.filter(d => 
          d.symbol?.toLowerCase().includes(s) || 
          d.company?.toLowerCase().includes(s)
        );
      }
      
      response.data.dividends = { 
        count: dividends.length, 
        events: dividends,
        source: POLYGON_BUSINESS_KEY ? 'polygon_business + nasdaq_public' : 'nasdaq_public'
      };
    }
    
    // ========== SPLITS ==========
    if (tab === 'splits' || tab === 'all') {
      if (!isCacheFresh('splits')) {
        cache.splits.data = await fetchSplits();
        cache.splits.timestamp = Date.now();
      }
      
      let splits = filterByDate(cache.splits.data || [], dateFilter);
      
      if (search) {
        const s = search.toLowerCase();
        splits = splits.filter(sp => 
          sp.symbol?.toLowerCase().includes(s) || 
          sp.company?.toLowerCase().includes(s)
        );
      }
      
      response.data.splits = { 
        count: splits.length, 
        events: splits,
        source: POLYGON_BUSINESS_KEY ? 'polygon_business' : 'none (requires Polygon Business license)'
      };
    }
    
    // ========== IPO ==========
    if (tab === 'ipo' || tab === 'all') {
      if (!isCacheFresh('ipos')) {
        cache.ipos.data = await fetchIPOs();
        cache.ipos.timestamp = Date.now();
      }
      
      let ipos = filterByDate(cache.ipos.data || [], dateFilter);
      
      if (search) {
        const s = search.toLowerCase();
        ipos = ipos.filter(i => 
          i.symbol?.toLowerCase().includes(s) || 
          i.company?.toLowerCase().includes(s)
        );
      }
      
      response.data.ipos = { 
        count: ipos.length, 
        events: ipos,
        source: 'nasdaq_public'
      };
    }
    
    // ========== EXPIRATIONS ==========
    if (tab === 'expiration' || tab === 'all') {
      if (!isCacheFresh('expirations')) {
        cache.expirations.data = generateExpirations();
        cache.expirations.timestamp = Date.now();
      }
      
      const expirations = filterByDate(cache.expirations.data || [], dateFilter);
      
      response.data.expirations = { 
        count: expirations.length, 
        events: expirations,
        source: 'calculated'
      };
    }
    
    console.log(`[Calendar] 📤 Response: ${Object.keys(response.data).map(k => `${k}:${response.data[k]?.count || 0}`).join(', ')}`);
    res.json(response);
    
  } catch (e) {
    console.error('[Calendar] ❌ Error:', e.message, e.stack);
    res.status(500).json({ error: 'calendar_error', message: e.message });
  }
});

// Status endpoint
router.get("/status", (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    version: 'v8-legal-commercial',
    description: 'Legally compliant for commercial use',
    dataSources: {
      nasdaq_public: {
        status: 'active',
        license: 'Public API, attribution required',
        features: ['Earnings', 'Dividends', 'IPOs'],
      },
      polygon_business: {
        status: POLYGON_BUSINESS_KEY ? 'active' : 'not_configured',
        license: 'Commercial ($99/mo)',
        features: ['Dividends', 'Splits', 'Holidays'],
        signupUrl: 'https://polygon.io/business'
      },
      calculated: {
        status: 'active',
        license: 'No license needed (algorithm)',
        features: ['Economic Events', 'Expirations', 'Holidays'],
      },
    },
    recommendations: [
      {
        upgrade: 'Polygon Business',
        cost: '$99/mo (50% off for startups)',
        benefit: 'Full dividends, splits, market holidays with commercial license'
      },
      {
        upgrade: 'TradingEconomics API',
        cost: '$49/mo+',
        benefit: 'Real economic calendar with actual/forecast values from 196 countries'
      }
    ]
  });
});

// Refresh cache
router.post("/refresh", async (req, res) => {
  try {
    Object.keys(cache).forEach(key => {
      cache[key].data = null;
      cache[key].timestamp = null;
    });
    res.json({ success: true, message: 'All caches cleared' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;