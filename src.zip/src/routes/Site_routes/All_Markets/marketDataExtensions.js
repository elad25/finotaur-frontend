// src/routes/Site_routes/All_Markets/marketDataExtensions.js
// =====================================================
// STOCK SUMMARY DATA ENDPOINTS - v2.1
// =====================================================
// - 15-minute caching
// - Market hours detection (NYSE: 9:30-16:00 ET)
// - Show previous day data when market closed
// - Logo URL fix
// - Financial metrics endpoint
// =====================================================

import express from "express";

const router = express.Router();

// ============ CACHE CONFIGURATION ============
const CACHE_DURATION_MS = 15 * 60 * 1000; // 15 minutes

class DataCache {
  constructor() {
    this.store = new Map();
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() - entry.timestamp < CACHE_DURATION_MS) {
      return entry.data;
    }
    this.store.delete(key);
    return null;
  }

  set(key, data) {
    this.store.set(key, { data, timestamp: Date.now() });
  }

  clear() {
    this.store.clear();
  }
}

const dataCache = new DataCache();

// ============ HELPER: Safe fetch ============
async function safeFetch(url) {
  try {
    const response = await fetch(url, {
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) return null;
    return await response.json();
  } catch (e) {
    console.error(`[Fetch Error] ${url}:`, e.message);
    return null;
  }
}

// ============ HELPER: Market Hours Detection ============
function getMarketStatus() {
  const now = new Date();
  
  // Convert to New York time
  const nyTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const hour = nyTime.getHours();
  const minute = nyTime.getMinutes();
  const day = nyTime.getDay(); // 0 = Sunday, 6 = Saturday
  
  // Weekend
  if (day === 0 || day === 6) {
    return { isOpen: false, status: 'closed', reason: 'weekend' };
  }
  
  // Convert to minutes since midnight
  const timeInMinutes = hour * 60 + minute;
  const marketOpen = 9 * 60 + 30;  // 9:30 AM
  const marketClose = 16 * 60;      // 4:00 PM
  
  // Pre-market: 4:00 AM - 9:30 AM
  if (timeInMinutes >= 4 * 60 && timeInMinutes < marketOpen) {
    return { isOpen: false, status: 'pre-market', reason: 'pre-market' };
  }
  
  // Market hours: 9:30 AM - 4:00 PM
  if (timeInMinutes >= marketOpen && timeInMinutes < marketClose) {
    return { isOpen: true, status: 'open', reason: 'market-hours' };
  }
  
  // After-hours: 4:00 PM - 8:00 PM
  if (timeInMinutes >= marketClose && timeInMinutes < 20 * 60) {
    return { isOpen: false, status: 'after-hours', reason: 'after-hours' };
  }
  
  // Closed
  return { isOpen: false, status: 'closed', reason: 'outside-hours' };
}

// ============ HELPER: Fix Logo URL ============
function fixLogoUrl(logoUrl, apiKey) {
  if (!logoUrl) return null;
  
  // Polygon branding URLs need API key
  if (logoUrl.includes('api.polygon.io')) {
    const separator = logoUrl.includes('?') ? '&' : '?';
    return `${logoUrl}${separator}apiKey=${apiKey}`;
  }
  
  return logoUrl;
}

// ============ QUOTE EXTENDED ENDPOINT ============
// GET /api/market-data/quote-extended/:symbol
router.get("/quote-extended/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
  
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const symbol = req.params.symbol.toUpperCase();
  const cacheKey = `quote_ext_${symbol}`;
  
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Quote ${symbol}`);
    return res.json(cached);
  }

  try {
    console.log(`[API] Fetching extended quote for ${symbol}`);

    // Get market status
    const marketStatus = getMarketStatus();

    // Fetch snapshot and ticker details in parallel
    const [snapshotData, detailsData, basicFinancialsData] = await Promise.all([
      safeFetch(`https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${POLYGON_KEY}`),
      safeFetch(`https://api.polygon.io/v3/reference/tickers/${symbol}?apiKey=${POLYGON_KEY}`),
      FINNHUB_KEY 
        ? safeFetch(`https://finnhub.io/api/v1/stock/metric?symbol=${symbol}&metric=all&token=${FINNHUB_KEY}`)
        : null
    ]);

    if (!snapshotData?.ticker) {
      return res.status(404).json({ error: "Symbol not found" });
    }

    const t = snapshotData.ticker;
    const details = detailsData?.results || {};
    const metrics = basicFinancialsData?.metric || {};

    // Determine which data to use based on market status
    const dayData = t.day || {};
    const prevData = t.prevDay || {};
    
    // If market is closed and no current day data, use previous day
    const useDay = marketStatus.isOpen || (dayData.c && dayData.c > 0);
    const priceSource = useDay ? dayData : prevData;

    // Build quote object
    const quote = {
      symbol: t.ticker,
      price: priceSource.c || prevData.c || 0,
      change: t.todaysChange || 0,
      changePercent: t.todaysChangePerc || 0,
      
      // Use current day if available, otherwise previous day
      open: dayData.o || prevData.o || 0,
      high: dayData.h || prevData.h || 0,
      low: dayData.l || prevData.l || 0,
      volume: dayData.v || 0,
      previousClose: prevData.c || 0,
      
      // Market status
      marketStatus: marketStatus.status,
      isMarketOpen: marketStatus.isOpen,
      
      timestamp: new Date().toISOString(),
      
      // From Polygon details
      marketCap: details.market_cap || null,
      
      // 52-week range
      high52w: metrics['52WeekHigh'] || null,
      low52w: metrics['52WeekLow'] || null,
      
      // Fundamental metrics from Finnhub
      pe: metrics.peBasicExclExtraTTM || metrics.peTTM || null,
      eps: metrics.epsBasicExclExtraItemsTTM || metrics.epsTTM || null,
      beta: metrics.beta || null,
      dividendYield: metrics.dividendYieldIndicatedAnnual || null,
      avgVolume: metrics['10DayAverageTradingVolume'] 
        ? metrics['10DayAverageTradingVolume'] * 1e6 
        : (prevData.v || null),
      
      // Additional metrics
      priceToBook: metrics.pbAnnual || null,
      priceToSales: metrics.psAnnual || null,
      revenueGrowth: metrics.revenueGrowthTTMYoy || null,
      epsGrowth: metrics.epsGrowthTTMYoy || null,
      roe: metrics.roeTTM || null,
      roa: metrics.roaTTM || null,
      grossMargin: metrics.grossMarginTTM || null,
      operatingMargin: metrics.operatingMarginTTM || null,
      netMargin: metrics.netMarginTTM || null,
      debtToEquity: metrics.totalDebtToEquityAnnual || null,
      currentRatio: metrics.currentRatioAnnual || null,
    };

    // Cache result
    dataCache.set(cacheKey, quote);
    console.log(`[Cache SAVE] Quote ${symbol} (market: ${marketStatus.status})`);
    
    res.json(quote);
  } catch (e) {
    console.error("Extended quote error:", e.message);
    res.status(500).json({ error: "quote_error", message: e.message });
  }
});

// ============ COMPANY PROFILE ENDPOINT ============
// GET /api/market-data/company/:symbol
router.get("/company/:symbol", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
  
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const symbol = req.params.symbol.toUpperCase();
  const cacheKey = `company_${symbol}`;
  
  // Check cache
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Company ${symbol}`);
    return res.json(cached);
  }

  try {
    console.log(`[API] Fetching company profile for ${symbol}`);
    
    // Fetch from Polygon Ticker Details v3
    const polygonData = await safeFetch(
      `https://api.polygon.io/v3/reference/tickers/${symbol}?apiKey=${POLYGON_KEY}`
    );

    let profile = null;

    if (polygonData?.results) {
      const r = polygonData.results;
      
      // Fix logo URL - add API key if needed
      let logoUrl = r.branding?.icon_url || r.branding?.logo_url || null;
      logoUrl = fixLogoUrl(logoUrl, POLYGON_KEY);
      
      profile = {
        symbol: r.ticker,
        name: r.name,
        description: r.description,
        sector: r.sic_description || null,
        industry: r.sic_description || null,
        sicCode: r.sic_code,
        country: r.locale?.toUpperCase() || "US",
        exchange: r.primary_exchange,
        currency: r.currency_name || "USD",
        website: r.homepage_url,
        logo: logoUrl,
        employees: r.total_employees,
        listDate: r.list_date,
        marketCap: r.market_cap,
        shareClassSharesOutstanding: r.share_class_shares_outstanding,
        weightedSharesOutstanding: r.weighted_shares_outstanding,
        headquarters: r.address ? 
          `${r.address.city || ''}${r.address.state ? ', ' + r.address.state : ''}` : null,
        phone: r.phone_number,
        source: "polygon"
      };
    }

    // Fallback/Merge with Finnhub for additional data (including better logo)
    if (FINNHUB_KEY) {
      const finnhubData = await safeFetch(
        `https://finnhub.io/api/v1/stock/profile2?symbol=${symbol}&token=${FINNHUB_KEY}`
      );

      if (finnhubData?.name) {
        // Finnhub logo is usually better (no API key needed)
        const finnhubLogo = finnhubData.logo || null;
        
        profile = {
          ...profile,
          symbol: finnhubData.ticker || symbol,
          name: profile?.name || finnhubData.name,
          description: profile?.description || null,
          sector: profile?.sector || finnhubData.finnhubIndustry,
          industry: finnhubData.finnhubIndustry || profile?.industry,
          country: profile?.country || finnhubData.country,
          exchange: profile?.exchange || finnhubData.exchange,
          currency: profile?.currency || finnhubData.currency,
          website: profile?.website || finnhubData.weburl,
          // Prefer Finnhub logo (doesn't need API key)
          logo: finnhubLogo || profile?.logo,
          employees: profile?.employees || null,
          ipo: finnhubData.ipo,
          marketCap: profile?.marketCap || (finnhubData.marketCapitalization ? finnhubData.marketCapitalization * 1e6 : null),
          shareOutstanding: finnhubData.shareOutstanding ? finnhubData.shareOutstanding * 1e6 : null,
          source: profile?.source ? `${profile.source}+finnhub` : "finnhub"
        };
      }
    }

    if (!profile) {
      return res.status(404).json({ error: "Company not found" });
    }

    // Cache result
    dataCache.set(cacheKey, profile);
    console.log(`[Cache SAVE] Company ${symbol}`);

    res.json(profile);
  } catch (e) {
    console.error("Company profile error:", e.message);
    res.status(500).json({ error: "company_error", message: e.message });
  }
});

// ============ FINNHUB PROFILE ENDPOINT (FALLBACK) ============
// GET /api/market-data/profile/:symbol
router.get("/profile/:symbol", async (req, res) => {
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
  
  if (!FINNHUB_KEY) {
    return res.status(500).json({ error: "FINNHUB_API_KEY not set" });
  }

  const symbol = req.params.symbol.toUpperCase();
  const cacheKey = `finnhub_profile_${symbol}`;
  
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Profile ${symbol}`);
    return res.json(cached);
  }

  try {
    const data = await safeFetch(
      `https://finnhub.io/api/v1/stock/profile2?symbol=${symbol}&token=${FINNHUB_KEY}`
    );
    
    if (!data?.name) {
      return res.status(404).json({ error: "Company not found" });
    }

    const profile = {
      symbol: data.ticker,
      name: data.name,
      description: null,
      sector: data.finnhubIndustry,
      industry: data.finnhubIndustry,
      country: data.country,
      exchange: data.exchange,
      currency: data.currency,
      website: data.weburl,
      logo: data.logo,
      ipo: data.ipo,
      marketCap: data.marketCapitalization ? data.marketCapitalization * 1e6 : null,
      shareOutstanding: data.shareOutstanding ? data.shareOutstanding * 1e6 : null,
      source: "finnhub"
    };

    dataCache.set(cacheKey, profile);
    res.json(profile);
  } catch (e) {
    console.error("Finnhub profile error:", e.message);
    res.status(500).json({ error: "profile_error", message: e.message });
  }
});

// ============ ANALYST DATA ENDPOINT ============
// GET /api/market-data/analyst/:symbol
router.get("/analyst/:symbol", async (req, res) => {
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  
  if (!FINNHUB_KEY) {
    return res.status(500).json({ error: "FINNHUB_API_KEY not set" });
  }

  const symbol = req.params.symbol.toUpperCase();
  const cacheKey = `analyst_${symbol}`;
  
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Analyst ${symbol}`);
    return res.json(cached);
  }

  try {
    console.log(`[API] Fetching analyst data for ${symbol}`);

    // Fetch recommendations, price target, and current quote in parallel
    const [recsData, ptData, snapshotData] = await Promise.all([
      safeFetch(`https://finnhub.io/api/v1/stock/recommendation?symbol=${symbol}&token=${FINNHUB_KEY}`),
      safeFetch(`https://finnhub.io/api/v1/stock/price-target?symbol=${symbol}&token=${FINNHUB_KEY}`),
      POLYGON_KEY
        ? safeFetch(`https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${POLYGON_KEY}`)
        : null
    ]);

    // Get latest recommendation
    const latestRec = Array.isArray(recsData) && recsData.length > 0 ? recsData[0] : null;
    const currentPrice = snapshotData?.ticker?.day?.c || snapshotData?.ticker?.prevDay?.c || 0;

    // Build rating object
    let rating = null;
    if (latestRec) {
      const total = (latestRec.strongBuy || 0) + (latestRec.buy || 0) + 
                    (latestRec.hold || 0) + (latestRec.sell || 0) + (latestRec.strongSell || 0);
      
      // Determine consensus
      let consensus = 'Hold';
      const buyCount = (latestRec.strongBuy || 0) + (latestRec.buy || 0);
      const sellCount = (latestRec.sell || 0) + (latestRec.strongSell || 0);
      
      if (total > 0) {
        const buyPercent = buyCount / total;
        const sellPercent = sellCount / total;
        
        if (latestRec.strongBuy > total * 0.3) consensus = 'Strong Buy';
        else if (buyPercent > 0.6) consensus = 'Buy';
        else if (sellPercent > 0.6) consensus = 'Sell';
        else if (latestRec.strongSell > total * 0.3) consensus = 'Strong Sell';
      }
      
      rating = {
        strongBuy: latestRec.strongBuy || 0,
        buy: latestRec.buy || 0,
        hold: latestRec.hold || 0,
        sell: latestRec.sell || 0,
        strongSell: latestRec.strongSell || 0,
        total,
        consensus,
        period: latestRec.period
      };
    }

    // Build price target object
    let priceTarget = null;
    if (ptData && ptData.targetMean) {
      const upsidePercent = currentPrice > 0 
        ? ((ptData.targetMean - currentPrice) / currentPrice) * 100 
        : 0;
        
      priceTarget = {
        targetHigh: ptData.targetHigh || 0,
        targetLow: ptData.targetLow || 0,
        targetMean: ptData.targetMean || 0,
        targetMedian: ptData.targetMedian || ptData.targetMean || 0,
        currentPrice,
        upsidePercent: Math.round(upsidePercent * 10) / 10,
        numberOfAnalysts: ptData.numberOfAnalysts || (rating?.total || 0)
      };
    }

    const result = {
      symbol,
      rating,
      priceTarget,
      recommendations: recsData || [],
      lastUpdated: new Date().toISOString()
    };

    // Cache result
    dataCache.set(cacheKey, result);
    console.log(`[Cache SAVE] Analyst ${symbol}`);

    res.json(result);
  } catch (e) {
    console.error("Analyst data error:", e.message);
    res.status(500).json({ error: "analyst_error", message: e.message });
  }
});

// ============ FINANCIALS ENDPOINT ============
// GET /api/market-data/financials/:symbol
router.get("/financials/:symbol", async (req, res) => {
  const FINNHUB_KEY = process.env.FINNHUB_API_KEY;
  
  if (!FINNHUB_KEY) {
    return res.status(500).json({ error: "FINNHUB_API_KEY not set" });
  }

  const symbol = req.params.symbol.toUpperCase();
  const cacheKey = `financials_${symbol}`;
  
  const cached = dataCache.get(cacheKey);
  if (cached) {
    console.log(`[Cache HIT] Financials ${symbol}`);
    return res.json(cached);
  }

  try {
    console.log(`[API] Fetching financials for ${symbol}`);

    // Fetch basic financials from Finnhub
    const metricsData = await safeFetch(
      `https://finnhub.io/api/v1/stock/metric?symbol=${symbol}&metric=all&token=${FINNHUB_KEY}`
    );

    const metrics = metricsData?.metric || {};

    const financials = {
      symbol,
      
      // Growth metrics
      revenueGrowth: metrics.revenueGrowthTTMYoy || metrics.revenueGrowth3Y || null,
      netIncomeGrowth: metrics.netIncomeGrowthTTMYoy || metrics.epsGrowthTTMYoy || null,
      epsGrowth: metrics.epsGrowthTTMYoy || metrics.epsGrowth3Y || null,
      
      // Profitability margins
      grossMargin: metrics.grossMarginTTM || metrics.grossMarginAnnual || null,
      operatingMargin: metrics.operatingMarginTTM || metrics.operatingMarginAnnual || null,
      netMargin: metrics.netProfitMarginTTM || metrics.netMarginTTM || null,
      
      // Return metrics
      roe: metrics.roeTTM || metrics.roeAnnual || null,
      roa: metrics.roaTTM || metrics.roaAnnual || null,
      roic: metrics.roicTTM || metrics.roicAnnual || null,
      
      // Liquidity & Leverage
      currentRatio: metrics.currentRatioAnnual || metrics.currentRatioQuarterly || null,
      quickRatio: metrics.quickRatioAnnual || metrics.quickRatioQuarterly || null,
      debtToEquity: metrics.totalDebtToEquityAnnual || metrics.totalDebtToEquityQuarterly || null,
      debtToAssets: metrics.totalDebtToTotalAssetsAnnual || null,
      
      // Per share metrics
      revenuePerShare: metrics.revenuePerShareTTM || metrics.revenuePerShareAnnual || null,
      bookValuePerShare: metrics.bookValuePerShareAnnual || metrics.bookValuePerShareQuarterly || null,
      tangibleBookValuePerShare: metrics.tangibleBookValuePerShareAnnual || null,
      cashPerShare: metrics.cashPerSharePerShareAnnual || null,
      
      // Cash flow
      freeCashFlowPerShare: metrics.freeCashFlowPerShareTTM || null,
      operatingCashFlowPerShare: metrics.cashFlowPerShareTTM || null,
      
      // Valuation
      peRatio: metrics.peBasicExclExtraTTM || metrics.peTTM || null,
      pegRatio: metrics.pegAnnual || null,
      priceToBook: metrics.pbAnnual || metrics.pbQuarterly || null,
      priceToSales: metrics.psAnnual || metrics.psTTM || null,
      evToEbitda: metrics.enterpriseValueOverEBITDAAnnual || null,
      evToRevenue: metrics.enterpriseValueOverRevenueTTM || null,
      
      // Dividend
      dividendYield: metrics.dividendYieldIndicatedAnnual || null,
      dividendPerShare: metrics.dividendsPerShareAnnual || null,
      payoutRatio: metrics.payoutRatioAnnual || null,
      
      // Other
      beta: metrics.beta || null,
      
      lastUpdated: new Date().toISOString(),
      source: "finnhub"
    };

    // Cache result
    dataCache.set(cacheKey, financials);
    console.log(`[Cache SAVE] Financials ${symbol}`);

    res.json(financials);
  } catch (e) {
    console.error("Financials error:", e.message);
    res.status(500).json({ error: "financials_error", message: e.message });
  }
});

// ============ MARKET STATUS ENDPOINT ============
// GET /api/market-data/market-status
router.get("/market-status", (req, res) => {
  const status = getMarketStatus();
  
  // Add next open/close times
  const now = new Date();
  const nyTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  
  res.json({
    ...status,
    currentTime: nyTime.toISOString(),
    timezone: "America/New_York"
  });
});

// ============ BULK QUOTES ENDPOINT ============
// GET /api/market-data/quotes?symbols=AAPL,MSFT,GOOGL
router.get("/quotes", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  
  if (!POLYGON_KEY) {
    return res.status(500).json({ error: "POLYGON_API_KEY not set" });
  }

  const symbolsParam = req.query.symbols;
  if (!symbolsParam) {
    return res.status(400).json({ error: "symbols parameter required" });
  }

  const symbols = symbolsParam.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
  if (symbols.length === 0) {
    return res.status(400).json({ error: "No valid symbols provided" });
  }

  const marketStatus = getMarketStatus();

  try {
    // Fetch snapshots for all symbols in parallel
    const snapshots = await Promise.all(
      symbols.map(async (symbol) => {
        const cacheKey = `quote_simple_${symbol}`;
        const cached = dataCache.get(cacheKey);
        if (cached) return cached;

        const data = await safeFetch(
          `https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${POLYGON_KEY}`
        );

        if (!data?.ticker) return null;

        const t = data.ticker;
        const dayData = t.day || {};
        const prevData = t.prevDay || {};
        
        const quote = {
          symbol: t.ticker,
          price: dayData.c || prevData.c || 0,
          change: t.todaysChange || 0,
          changePercent: t.todaysChangePerc || 0,
          open: dayData.o || prevData.o,
          high: dayData.h || prevData.h,
          low: dayData.l || prevData.l,
          volume: dayData.v || 0,
          previousClose: prevData.c
        };

        dataCache.set(cacheKey, quote);
        return quote;
      })
    );

    res.json({
      timestamp: new Date().toISOString(),
      marketStatus: marketStatus.status,
      count: snapshots.filter(Boolean).length,
      quotes: snapshots.filter(Boolean)
    });
  } catch (e) {
    console.error("Bulk quotes error:", e.message);
    res.status(500).json({ error: "bulk_quotes_error", message: e.message });
  }
});

// ============ CLEAR CACHE ENDPOINT (Admin) ============
// POST /api/market-data/cache/clear
router.post("/cache/clear", (req, res) => {
  dataCache.clear();
  console.log("[Cache] Server cache cleared");
  res.json({ success: true, message: "Cache cleared" });
});

export default router;