// routes/Site_routes/All_Markets/top-movers.js
// Top Movers API - Multi-source with Market Status

import express from "express";

const router = express.Router();

// ============ CACHE - 15 minutes ============
const CACHE_DURATION_MS = 15 * 60 * 1000;
const cache = new Map();

function getCached(key) {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.ts > CACHE_DURATION_MS) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function setCache(key, data) {
  cache.set(key, { data, ts: Date.now() });
}

// ============ MARKET STATUS ============
function getStockMarketStatus() {
  const now = new Date();
  const nyTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = nyTime.getDay();
  const hours = nyTime.getHours();
  const minutes = nyTime.getMinutes();
  const currentMinutes = hours * 60 + minutes;

  const preMarketOpen = 4 * 60; // 4:00 AM
  const marketOpen = 9 * 60 + 30; // 9:30 AM
  const marketClose = 16 * 60; // 4:00 PM
  const afterHoursClose = 20 * 60; // 8:00 PM

  // Weekend
  if (day === 0 || day === 6) {
    return { isOpen: false, status: 'closed', message: 'Weekend - Opens Monday 9:30 AM ET' };
  }

  // Pre-market: 4:00 AM - 9:30 AM
  if (currentMinutes >= preMarketOpen && currentMinutes < marketOpen) {
    return { isOpen: false, status: 'pre-market', message: 'Pre-Market' };
  }

  // Regular hours: 9:30 AM - 4:00 PM
  if (currentMinutes >= marketOpen && currentMinutes < marketClose) {
    return { isOpen: true, status: 'open', message: 'Market Open' };
  }

  // After hours: 4:00 PM - 8:00 PM
  if (currentMinutes >= marketClose && currentMinutes < afterHoursClose) {
    return { isOpen: false, status: 'after-hours', message: 'After Hours' };
  }

  // Closed
  return { isOpen: false, status: 'closed', message: 'Market Closed' };
}

function getForexMarketStatus() {
  const now = new Date();
  const day = now.getUTCDay();
  
  // Forex closed from Friday 22:00 UTC to Sunday 22:00 UTC
  if (day === 6) return { isOpen: false, status: 'closed', message: 'Weekend - Opens Sunday 10 PM UTC' };
  if (day === 0 && now.getUTCHours() < 22) return { isOpen: false, status: 'closed', message: 'Opens Sunday 10 PM UTC' };
  
  return { isOpen: true, status: 'open', message: '24/5 Open' };
}

function getCryptoMarketStatus() {
  return { isOpen: true, status: 'open', message: '24/7 Open' };
}

function getCommoditiesMarketStatus() {
  const now = new Date();
  const day = now.getUTCDay();
  
  if (day === 6) return { isOpen: false, status: 'closed', message: 'Weekend - Opens Sunday' };
  if (day === 0 && now.getUTCHours() < 18) return { isOpen: false, status: 'closed', message: 'Opens Sunday 6 PM ET' };
  
  return { isOpen: true, status: 'open', message: 'Futures 24/5' };
}

// ============ MAJOR CRYPTO LIST ============
const MAJOR_CRYPTOS = [
  'BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT',
  'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'DOTUSDT', 'LINKUSDT',
  'MATICUSDT', 'UNIUSDT', 'LTCUSDT', 'ATOMUSDT', 'XLMUSDT',
  'NEARUSDT', 'FILUSDT', 'APTUSDT', 'ARBUSDT', 'OPUSDT',
  'SUIUSDT', 'SEIUSDT', 'INJUSDT', 'RENDERUSDT', 'FETUSDT',
  'TAOUSDT', 'JUPUSDT', 'PYTHUSDT', 'TIAUSDT', 'WIFUSDT',
  'PEPEUSDT', 'SHIBUSDT', 'BONKUSDT', 'FLOKIUSDT',
  'TRXUSDT', 'ETCUSDT', 'BCHUSDT', 'ICPUSDT', 'HBARUSDT',
  'VETUSDT', 'ALGOUSDT', 'FTMUSDT', 'SANDUSDT', 'MANAUSDT',
  'AAVEUSDT', 'MKRUSDT', 'COMPUSDT', 'SNXUSDT', 'CRVUSDT'
];

const CRYPTO_NAMES = {
  'BTC': 'Bitcoin', 'ETH': 'Ethereum', 'BNB': 'BNB', 'SOL': 'Solana',
  'XRP': 'XRP', 'ADA': 'Cardano', 'DOGE': 'Dogecoin', 'AVAX': 'Avalanche',
  'DOT': 'Polkadot', 'LINK': 'Chainlink', 'MATIC': 'Polygon', 'UNI': 'Uniswap',
  'LTC': 'Litecoin', 'ATOM': 'Cosmos', 'XLM': 'Stellar', 'NEAR': 'NEAR Protocol',
  'FIL': 'Filecoin', 'APT': 'Aptos', 'ARB': 'Arbitrum', 'OP': 'Optimism',
  'SUI': 'Sui', 'SEI': 'Sei', 'INJ': 'Injective', 'RENDER': 'Render',
  'FET': 'Fetch.ai', 'TAO': 'Bittensor', 'JUP': 'Jupiter', 'PYTH': 'Pyth Network',
  'TIA': 'Celestia', 'WIF': 'dogwifhat', 'PEPE': 'Pepe', 'SHIB': 'Shiba Inu',
  'BONK': 'Bonk', 'FLOKI': 'Floki', 'TRX': 'Tron', 'ETC': 'Ethereum Classic',
  'BCH': 'Bitcoin Cash', 'ICP': 'Internet Computer', 'HBAR': 'Hedera',
  'VET': 'VeChain', 'ALGO': 'Algorand', 'FTM': 'Fantom', 'SAND': 'The Sandbox',
  'MANA': 'Decentraland', 'AAVE': 'Aave', 'MKR': 'Maker', 'COMP': 'Compound',
  'SNX': 'Synthetix', 'CRV': 'Curve'
};

// ============ BINANCE API (Crypto) - 24/7 ============
async function getBinanceCryptoMovers(limit = 10) {
  const cacheKey = `crypto_movers_${limit}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch("https://api.binance.com/api/v3/ticker/24hr");
    if (!response.ok) throw new Error(`Binance API error: ${response.status}`);
    
    const data = await response.json();
    
    const majorCoins = data
      .filter(t => MAJOR_CRYPTOS.includes(t.symbol))
      .map(t => {
        const symbol = t.symbol.replace("USDT", "");
        return {
          symbol,
          name: CRYPTO_NAMES[symbol] || symbol,
          price: parseFloat(t.lastPrice),
          chp: parseFloat(t.priceChangePercent),
          change: parseFloat(t.priceChange),
          volume: parseFloat(t.quoteVolume),
          high: parseFloat(t.highPrice),
          low: parseFloat(t.lowPrice)
        };
      });

    const gainers = [...majorCoins].filter(t => t.chp > 0).sort((a, b) => b.chp - a.chp).slice(0, limit);
    const losers = [...majorCoins].filter(t => t.chp < 0).sort((a, b) => a.chp - b.chp).slice(0, limit);

    const result = { 
      gainers, 
      losers, 
      source: "binance", 
      marketStatus: getCryptoMarketStatus(),
      ts: Date.now() 
    };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.error("[Crypto] Error:", e.message);
    return { gainers: [], losers: [], source: "binance", marketStatus: getCryptoMarketStatus(), error: e.message };
  }
}

// ============ YAHOO FINANCE ============
async function getYahooQuotes(symbols) {
  try {
    const symbolsStr = symbols.join(",");
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbolsStr}`;
    
    const response = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
    });
    
    if (!response.ok) throw new Error(`Yahoo API error: ${response.status}`);
    
    const data = await response.json();
    return data.quoteResponse?.result || [];
  } catch (e) {
    console.error("[Yahoo] Error:", e.message);
    return [];
  }
}

// Stocks with Pre/Post market support
async function getStockMovers(limit = 10) {
  const cacheKey = `stocks_movers_${limit}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const stockSymbols = [
    "AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA", "BRK-B",
    "JPM", "V", "JNJ", "WMT", "PG", "MA", "UNH", "HD", "DIS", "PYPL",
    "NFLX", "ADBE", "CRM", "INTC", "AMD", "QCOM", "TXN", "AVGO",
    "COST", "PEP", "KO", "MRK", "PFE", "ABBV", "TMO", "ACN",
    "MCD", "NKE", "LLY", "ORCL", "CSCO", "VZ", "T", "BA",
    "CAT", "GE", "MMM", "IBM", "GS", "MS", "C", "BAC"
  ];

  try {
    const quotes = await getYahooQuotes(stockSymbols);
    const marketStatus = getStockMarketStatus();
    
    const tickers = quotes
      .filter(q => q.regularMarketChangePercent !== undefined)
      .map(q => {
        // Use pre/post market data if available and market is closed
        let price = q.regularMarketPrice;
        let change = q.regularMarketChange;
        let chp = q.regularMarketChangePercent;
        let dataSource = 'regular';

        if (marketStatus.status === 'pre-market' && q.preMarketPrice) {
          price = q.preMarketPrice;
          change = q.preMarketChange || 0;
          chp = q.preMarketChangePercent || 0;
          dataSource = 'pre-market';
        } else if (marketStatus.status === 'after-hours' && q.postMarketPrice) {
          price = q.postMarketPrice;
          change = q.postMarketChange || 0;
          chp = q.postMarketChangePercent || 0;
          dataSource = 'after-hours';
        }

        return {
          symbol: q.symbol,
          name: q.shortName || q.longName || q.symbol,
          price,
          chp,
          change,
          volume: q.regularMarketVolume,
          high: q.regularMarketDayHigh,
          low: q.regularMarketDayLow,
          dataSource
        };
      });

    const gainers = [...tickers].filter(t => t.chp > 0).sort((a, b) => b.chp - a.chp).slice(0, limit);
    const losers = [...tickers].filter(t => t.chp < 0).sort((a, b) => a.chp - b.chp).slice(0, limit);

    const result = { 
      gainers, 
      losers, 
      source: "yahoo", 
      marketStatus,
      ts: Date.now() 
    };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.error("[Stocks] Error:", e.message);
    return { gainers: [], losers: [], source: "yahoo", marketStatus: getStockMarketStatus(), error: e.message };
  }
}

// Commodities (Futures ETFs)
async function getCommodityMovers(limit = 10) {
  const cacheKey = `commodities_movers_${limit}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const commoditySymbols = [
    "GLD", "SLV", "USO", "UNG", "CPER", "WEAT", "CORN", "SOYB",
    "DBA", "PALL", "PPLT", "URA", "WOOD", "JO"
  ];

  const commodityNames = {
    GLD: "Gold", SLV: "Silver", USO: "Crude Oil", UNG: "Natural Gas",
    CPER: "Copper", WEAT: "Wheat", CORN: "Corn", SOYB: "Soybeans",
    DBA: "Agriculture", PALL: "Palladium", PPLT: "Platinum",
    URA: "Uranium", WOOD: "Timber", JO: "Coffee"
  };

  try {
    const quotes = await getYahooQuotes(commoditySymbols);
    
    const tickers = quotes
      .filter(q => q.regularMarketChangePercent !== undefined)
      .map(q => ({
        symbol: q.symbol,
        name: commodityNames[q.symbol] || q.shortName || q.symbol,
        price: q.regularMarketPrice,
        chp: q.regularMarketChangePercent,
        change: q.regularMarketChange,
        high: q.regularMarketDayHigh,
        low: q.regularMarketDayLow
      }));

    const gainers = [...tickers].filter(t => t.chp > 0).sort((a, b) => b.chp - a.chp).slice(0, limit);
    const losers = [...tickers].filter(t => t.chp < 0).sort((a, b) => a.chp - b.chp).slice(0, limit);

    const result = { 
      gainers, 
      losers, 
      source: "yahoo", 
      marketStatus: getCommoditiesMarketStatus(),
      ts: Date.now() 
    };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.error("[Commodities] Error:", e.message);
    return { gainers: [], losers: [], source: "yahoo", marketStatus: getCommoditiesMarketStatus(), error: e.message };
  }
}

// Forex
async function getForexMovers(apiKey, limit = 10) {
  const cacheKey = `forex_movers_${limit}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const pairs = [
    { pair: "EURUSD", name: "EUR/USD" },
    { pair: "USDJPY", name: "USD/JPY" },
    { pair: "GBPUSD", name: "GBP/USD" },
    { pair: "USDCHF", name: "USD/CHF" },
    { pair: "AUDUSD", name: "AUD/USD" },
    { pair: "USDCAD", name: "USD/CAD" },
    { pair: "NZDUSD", name: "NZD/USD" },
    { pair: "EURGBP", name: "EUR/GBP" },
    { pair: "EURJPY", name: "EUR/JPY" },
    { pair: "GBPJPY", name: "GBP/JPY" }
  ];

  try {
    const quotes = await Promise.all(
      pairs.map(async (p) => {
        try {
          const url = `https://api.polygon.io/v2/aggs/ticker/C:${p.pair}/prev?apiKey=${apiKey}`;
          const response = await fetch(url);
          if (!response.ok) return null;
          
          const data = await response.json();
          if (!data?.results?.[0]) return null;
          
          const r = data.results[0];
          const change = r.o ? ((r.c - r.o) / r.o) * 100 : 0;
          
          return {
            symbol: p.pair,
            name: p.name,
            price: r.c,
            chp: +change.toFixed(3),
            change: +(r.c - r.o).toFixed(5),
            high: r.h,
            low: r.l
          };
        } catch {
          return null;
        }
      })
    );

    const valid = quotes.filter(q => q && q.chp !== undefined && q.chp !== null);

    const gainers = [...valid].filter(t => t.chp > 0).sort((a, b) => b.chp - a.chp).slice(0, limit);
    const losers = [...valid].filter(t => t.chp < 0).sort((a, b) => a.chp - b.chp).slice(0, limit);

    const result = { 
      gainers, 
      losers, 
      source: "polygon", 
      marketStatus: getForexMarketStatus(),
      ts: Date.now() 
    };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.error("[Forex] Error:", e.message);
    return { gainers: [], losers: [], source: "polygon", marketStatus: getForexMarketStatus(), error: e.message };
  }
}

// ============ ROUTES ============

router.get("/", async (req, res) => {
  const POLYGON_KEY = process.env.POLYGON_API_KEY;
  
  const type = req.query.type || "all";
  const limit = Math.min(parseInt(req.query.limit) || 10, 50);

  try {
    let result = {};

    if (type === "all") {
      const [stocks, crypto, commodities, forex] = await Promise.all([
        getStockMovers(limit),
        getBinanceCryptoMovers(limit),
        getCommodityMovers(limit),
        POLYGON_KEY ? getForexMovers(POLYGON_KEY, limit) : { gainers: [], losers: [], marketStatus: getForexMarketStatus() }
      ]);
      
      result = { stocks, crypto, commodities, forex };
    } else {
      if (type === "stocks") result.stocks = await getStockMovers(limit);
      if (type === "crypto") result.crypto = await getBinanceCryptoMovers(limit);
      if (type === "commodities") result.commodities = await getCommodityMovers(limit);
      if (type === "forex") {
        result.forex = POLYGON_KEY 
          ? await getForexMovers(POLYGON_KEY, limit)
          : { gainers: [], losers: [], marketStatus: getForexMarketStatus(), error: "POLYGON_API_KEY not configured" };
      }
    }

    if (type !== "all" && result[type]) {
      return res.json(result[type]);
    }

    res.json({
      timestamp: new Date().toISOString(),
      ...result
    });

  } catch (e) {
    console.error("[Top Movers] Error:", e.message);
    res.status(500).json({ error: "top_movers_error", message: e.message });
  }
});

router.post("/cache/clear", (req, res) => {
  cache.clear();
  res.json({ message: "Cache cleared", timestamp: new Date().toISOString() });
});

export default router;