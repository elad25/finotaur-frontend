// finotaur-server/src/routes/Site_routes/All_Markets/news.js
// Multi-source news aggregator with image support
// Yahoo Finance style premium news experience

import express from "express";

const router = express.Router();

// ============ CACHE ============
const NEWS_CACHE_MS = 5 * 60 * 1000; // 5 minutes
const newsCache = new Map();

function getCached(key) {
  const entry = newsCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > NEWS_CACHE_MS) {
    newsCache.delete(key);
    return null;
  }
  return entry.data;
}

function setCache(key, data) {
  newsCache.set(key, { data, timestamp: Date.now() });
}

// ============ COMPANY TO TICKER MAPPING (400+) ============
const COMPANY_TO_TICKER = {
  // MEGA CAP TECH
  "apple": "AAPL", "microsoft": "MSFT", "google": "GOOGL", "alphabet": "GOOGL",
  "amazon": "AMZN", "tesla": "TSLA", "nvidia": "NVDA", "meta": "META",
  "facebook": "META", "netflix": "NFLX", "broadcom": "AVGO",
  
  // SEMICONDUCTORS
  "amd": "AMD", "intel": "INTC", "qualcomm": "QCOM", "micron": "MU",
  "texas instruments": "TXN", "applied materials": "AMAT", "lam research": "LRCX",
  "asml": "ASML", "tsmc": "TSM", "taiwan semiconductor": "TSM",
  "arm": "ARM", "arm holdings": "ARM", "marvell": "MRVL", "on semiconductor": "ON",
  
  // SOFTWARE & CLOUD
  "salesforce": "CRM", "oracle": "ORCL", "ibm": "IBM", "cisco": "CSCO",
  "adobe": "ADBE", "servicenow": "NOW", "workday": "WDAY",
  "datadog": "DDOG", "crowdstrike": "CRWD", "zscaler": "ZS", "okta": "OKTA",
  "palo alto": "PANW", "fortinet": "FTNT", "cloudflare": "NET",
  "snowflake": "SNOW", "palantir": "PLTR", "mongodb": "MDB",
  "atlassian": "TEAM", "twilio": "TWLO", "unity": "U", "roblox": "RBLX",
  
  // SOCIAL MEDIA & INTERNET
  "snap": "SNAP", "snapchat": "SNAP", "pinterest": "PINS", "reddit": "RDDT",
  "twitter": "X", "spotify": "SPOT", "bumble": "BMBL", "match": "MTCH",
  
  // E-COMMERCE
  "shopify": "SHOP", "etsy": "ETSY", "ebay": "EBAY", "mercadolibre": "MELI",
  "alibaba": "BABA", "jd.com": "JD", "jd": "JD", "pinduoduo": "PDD",
  "wayfair": "W", "chewy": "CHWY",
  
  // STREAMING & ENTERTAINMENT
  "disney": "DIS", "warner bros": "WBD", "paramount": "PARA", "comcast": "CMCSA",
  "roku": "ROKU", "draftkings": "DKNG", "caesars": "CZR", "mgm": "MGM",
  "wynn": "WYNN", "las vegas sands": "LVS",
  
  // FINTECH & PAYMENTS
  "paypal": "PYPL", "square": "SQ", "block": "SQ",
  "visa": "V", "mastercard": "MA", "american express": "AXP", "amex": "AXP",
  "discover": "DFS", "capital one": "COF",
  "affirm": "AFRM", "sofi": "SOFI", "upstart": "UPST",
  "toast": "TOST", "bill.com": "BILL", "bill": "BILL",
  
  // CRYPTO & BLOCKCHAIN
  "coinbase": "COIN", "robinhood": "HOOD", "microstrategy": "MSTR",
  "marathon digital": "MARA", "riot": "RIOT",
  
  // BANKS - US
  "jpmorgan": "JPM", "jp morgan": "JPM", "chase": "JPM",
  "bank of america": "BAC", "bofa": "BAC", "wells fargo": "WFC",
  "citigroup": "C", "citi": "C", "citibank": "C",
  "goldman sachs": "GS", "goldman": "GS", "morgan stanley": "MS",
  "charles schwab": "SCHW", "schwab": "SCHW",
  "svb": "SIVB", "silicon valley bank": "SIVB",
  
  // BANKS - INTERNATIONAL
  "hsbc": "HSBC", "barclays": "BCS", "deutsche bank": "DB",
  "ubs": "UBS", "credit suisse": "CS",
  
  // ASSET MANAGERS
  "blackrock": "BLK", "blackstone": "BX",
  
  // INSURANCE
  "berkshire": "BRK.B", "berkshire hathaway": "BRK.B",
  "progressive": "PGR", "allstate": "ALL",
  "unitedhealth": "UNH", "united health": "UNH", "anthem": "ELV",
  "cvs health": "CVS", "cvs": "CVS",
  
  // HEALTHCARE & PHARMA
  "johnson & johnson": "JNJ", "j&j": "JNJ", "pfizer": "PFE",
  "moderna": "MRNA", "merck": "MRK", "abbvie": "ABBV", 
  "eli lilly": "LLY", "lilly": "LLY",
  "bristol myers": "BMY", "amgen": "AMGN", "gilead": "GILD",
  "regeneron": "REGN", "vertex": "VRTX", "biogen": "BIIB",
  "thermo fisher": "TMO", "danaher": "DHR", "abbott": "ABT",
  "medtronic": "MDT", "intuitive surgical": "ISRG",
  "novartis": "NVS", "astrazeneca": "AZN", "novo nordisk": "NVO",
  
  // RETAIL
  "walmart": "WMT", "target": "TGT", "costco": "COST", "kroger": "KR",
  "walgreens": "WBA", "dollar general": "DG", "dollar tree": "DLTR",
  "tjx": "TJX", "ross": "ROST", "nordstrom": "JWN",
  "macy's": "M", "macys": "M", "gap": "GPS",
  "lululemon": "LULU", "nike": "NKE", "adidas": "ADDYY", "under armour": "UAA",
  "best buy": "BBY", "gamestop": "GME",
  "home depot": "HD", "lowe's": "LOW", "lowes": "LOW",
  "autozone": "AZO", "carmax": "KMX",
  "ulta": "ULTA", "estee lauder": "EL",
  
  // RESTAURANTS & FOOD
  "starbucks": "SBUX", "mcdonald's": "MCD", "mcdonalds": "MCD",
  "chipotle": "CMG", "domino's": "DPZ", "dominos": "DPZ",
  "wendy's": "WEN", "wendys": "WEN", "shake shack": "SHAK",
  
  // FOOD & BEVERAGE
  "coca-cola": "KO", "coca cola": "KO", "coke": "KO",
  "pepsi": "PEP", "pepsico": "PEP",
  "monster": "MNST", "celsius": "CELH",
  "anheuser": "BUD", "budweiser": "BUD",
  "kraft heinz": "KHC", "kraft": "KHC",
  "general mills": "GIS", "kellogg": "K",
  "beyond meat": "BYND",
  
  // CONSUMER GOODS
  "procter & gamble": "PG", "p&g": "PG", "procter": "PG",
  "unilever": "UL", "colgate": "CL",
  
  // AUTO & EV
  "ford": "F", "gm": "GM", "general motors": "GM",
  "toyota": "TM", "honda": "HMC",
  "rivian": "RIVN", "lucid": "LCID", "nio": "NIO", "xpeng": "XPEV",
  "li auto": "LI", "fisker": "FSR", "polestar": "PSNY", "vinfast": "VFS",
  "ferrari": "RACE",
  
  // TRANSPORT & LOGISTICS
  "uber": "UBER", "lyft": "LYFT", "doordash": "DASH",
  "instacart": "CART",
  "fedex": "FDX", "ups": "UPS",
  "union pacific": "UNP", "csx": "CSX",
  "delta": "DAL", "united airlines": "UAL", "american airlines": "AAL",
  "southwest": "LUV", "jetblue": "JBLU", "spirit": "SAVE",
  "boeing": "BA", "airbus": "EADSY",
  "lockheed": "LMT", "lockheed martin": "LMT", "northrop": "NOC",
  "raytheon": "RTX", "general dynamics": "GD",
  "carnival": "CCL", "royal caribbean": "RCL",
  
  // ENERGY - OIL & GAS
  "exxon": "XOM", "exxonmobil": "XOM", "chevron": "CVX",
  "conocophillips": "COP", "conoco": "COP", "occidental": "OXY", "oxy": "OXY",
  "pioneer": "PXD", "devon": "DVN", "diamondback": "FANG", "eog": "EOG",
  "schlumberger": "SLB", "halliburton": "HAL", "baker hughes": "BKR",
  "shell": "SHEL", "bp": "BP", "total": "TTE", "totalenergies": "TTE",
  "kinder morgan": "KMI",
  
  // ENERGY - RENEWABLES
  "nextera": "NEE", "first solar": "FSLR", "sunrun": "RUN",
  "enphase": "ENPH", "solaredge": "SEDG",
  "plug power": "PLUG", "bloom energy": "BE", "fuelcell": "FCEL",
  "chargepoint": "CHPT",
  
  // UTILITIES
  "duke energy": "DUK", "southern company": "SO", "dominion": "D",
  
  // REITS
  "american tower": "AMT", "crown castle": "CCI",
  "equinix": "EQIX", "digital realty": "DLR", "prologis": "PLD",
  "realty income": "O", "simon property": "SPG",
  
  // INDUSTRIALS
  "caterpillar": "CAT", "deere": "DE", "john deere": "DE",
  "honeywell": "HON", "3m": "MMM", "emerson": "EMR",
  "ge": "GE", "general electric": "GE",
  "waste management": "WM",
  
  // MATERIALS
  "linde": "LIN", "sherwin williams": "SHW",
  "dupont": "DD", "dow": "DOW", "dow chemical": "DOW",
  "newmont": "NEM", "barrick": "GOLD", "freeport": "FCX",
  "nucor": "NUE",
  
  // TELECOM
  "at&t": "T", "att": "T", "verizon": "VZ", "t-mobile": "TMUS", "tmobile": "TMUS",
  "charter": "CHTR",
  
  // CHINESE TECH
  "baidu": "BIDU", "tencent": "TCEHY", "netease": "NTES",
  "bilibili": "BILI", "byd": "BYDDY",
  
  // INDEXES & ETFS
  "sp500": "SPY", "s&p 500": "SPY", "s&p": "SPY", "s&p500": "SPY",
  "nasdaq": "QQQ", "nasdaq 100": "QQQ",
  "dow jones": "DIA", "dow": "DIA", "djia": "DIA",
  "russell": "IWM", "russell 2000": "IWM",
  "vix": "VIX", "volatility": "VIX",
  
  // CRYPTO
  "bitcoin": "BTC", "btc": "BTC", "ethereum": "ETH", "eth": "ETH",
  "solana": "SOL", "xrp": "XRP", "ripple": "XRP",
  "cardano": "ADA", "dogecoin": "DOGE", "doge": "DOGE",
  "shiba": "SHIB", "polkadot": "DOT",
  "avalanche": "AVAX", "polygon": "MATIC", "chainlink": "LINK",
  "litecoin": "LTC", "bnb": "BNB", "binance coin": "BNB",
  
  // COMMODITIES
  "gold": "GLD", "silver": "SLV",
  "oil": "USO", "crude": "USO", "crude oil": "USO", "wti": "USO", "brent": "BNO",
  "natural gas": "UNG", "copper": "CPER",
  
  // MISC
  "airbnb": "ABNB", "booking": "BKNG", "expedia": "EXPE",
  "zillow": "Z", "redfin": "RDFN", "opendoor": "OPEN",
  "docusign": "DOCU", "dropbox": "DBX", "zoom": "ZM",
  "peloton": "PTON",
  "amc": "AMC", "amc entertainment": "AMC", "blackberry": "BB",
  "oklo": "OKLO", "versant": "VSNTV"
};

// Category detection keywords
const CATEGORY_KEYWORDS = {
  stocks: ["stock", "shares", "nasdaq", "nyse", "s&p", "dow", "earnings", "ipo", "quarterly", "revenue"],
  crypto: ["bitcoin", "btc", "ethereum", "eth", "crypto", "blockchain", "defi", "token", "altcoin"],
  forex: ["forex", "currency", "dollar", "euro", "yen", "pound", "fx", "exchange rate", "usd", "eur"],
  commodities: ["oil", "gold", "silver", "crude", "commodity", "natural gas", "copper", "wheat", "corn"],
  global: ["fed", "federal reserve", "gdp", "inflation", "economy", "recession", "treasury", "interest rate", 
           "central bank", "monetary policy", "fiscal", "unemployment", "jobs report", "nonfarm", "cpi", 
           "ppi", "fomc", "rate hike", "rate cut", "quantitative", "bond yield", "yield curve", "debt ceiling",
           "trade war", "tariff", "imf", "world bank", "ecb", "boj", "economic growth", "stimulus"]
};

// Macro-only keywords for Global category (stricter filter)
const MACRO_KEYWORDS = [
  "fed", "federal reserve", "gdp", "inflation", "economy", "recession", "treasury", "interest rate",
  "central bank", "monetary policy", "fiscal", "unemployment", "jobs report", "nonfarm", "cpi", "ppi",
  "fomc", "rate hike", "rate cut", "quantitative", "bond yield", "yield curve", "debt ceiling",
  "trade war", "tariff", "imf", "world bank", "ecb", "boj", "economic growth", "stimulus",
  "consumer spending", "retail sales", "housing", "manufacturing", "pmi", "ism", "durable goods",
  "trade deficit", "budget", "government spending", "fed chair", "powell", "yellen", "lagarde"
];

function isMacroNews(headline, summary = "") {
  const text = `${headline} ${summary}`.toLowerCase();
  return MACRO_KEYWORDS.some(keyword => text.includes(keyword));
}

// ============ HELPER FUNCTIONS ============

function extractTickers(headline, summary = "") {
  const text = `${headline} ${summary}`.toLowerCase();
  const tickers = [];

  // 1. Look for $TICKER pattern
  const dollarMatches = headline.match(/\$([A-Z]{1,5})\b/g);
  if (dollarMatches) {
    dollarMatches.forEach(match => {
      tickers.push(match.replace("$", ""));
    });
  }

  // 2. Look for known company names
  for (const [company, ticker] of Object.entries(COMPANY_TO_TICKER)) {
    if (text.includes(company.toLowerCase())) {
      if (!tickers.includes(ticker)) {
        tickers.push(ticker);
      }
    }
  }

  return tickers.slice(0, 3);
}

function detectCategory(title, summary = "") {
  const text = `${title} ${summary}`.toLowerCase();
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    if (keywords.some(kw => text.includes(kw))) {
      return category;
    }
  }
  return "global";
}

function detectImportance(title) {
  const lower = title.toLowerCase();
  const high = ["breaking", "surge", "crash", "plunge", "soar", "record", "crisis"];
  const medium = ["rise", "fall", "gain", "loss", "beat", "miss", "upgrade"];
  if (high.some(kw => lower.includes(kw))) return "high";
  if (medium.some(kw => lower.includes(kw))) return "medium";
  return "low";
}

// ============ FALLBACK IMAGES BY CATEGORY ============
const CATEGORY_FALLBACK_IMAGES = {
  global: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=300&fit=crop", // World economy
  stocks: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=400&h=300&fit=crop", // Stock chart
  crypto: "https://images.unsplash.com/photo-1518546305927-5a555bb7020d?w=400&h=300&fit=crop", // Bitcoin
  forex: "https://images.unsplash.com/photo-1580519542036-c47de6196ba5?w=400&h=300&fit=crop", // Currency
  commodities: "https://images.unsplash.com/photo-1610375461246-83df859d849d?w=400&h=300&fit=crop", // Gold bars
};

// Source logo mapping for better branding
const SOURCE_LOGOS = {
  "Reuters": "https://logo.clearbit.com/reuters.com",
  "Bloomberg": "https://logo.clearbit.com/bloomberg.com",
  "CNBC": "https://logo.clearbit.com/cnbc.com",
  "MarketWatch": "https://logo.clearbit.com/marketwatch.com",
  "Yahoo Finance": "https://logo.clearbit.com/finance.yahoo.com",
  "The Wall Street Journal": "https://logo.clearbit.com/wsj.com",
  "Financial Times": "https://logo.clearbit.com/ft.com",
  "Benzinga": "https://logo.clearbit.com/benzinga.com",
  "Seeking Alpha": "https://logo.clearbit.com/seekingalpha.com",
  "Investopedia": "https://logo.clearbit.com/investopedia.com",
};

function getSourceLogo(sourceName) {
  // Check exact match first
  if (SOURCE_LOGOS[sourceName]) {
    return SOURCE_LOGOS[sourceName];
  }
  // Check partial match
  for (const [name, logo] of Object.entries(SOURCE_LOGOS)) {
    if (sourceName.toLowerCase().includes(name.toLowerCase())) {
      return logo;
    }
  }
  return null;
}

// ============ DATA FETCHERS ============

// Finnhub News (primary - most reliable)
async function fetchFinnhubNews(category = "general", limit = 20) {
  const key = process.env.FINNHUB_API_KEY;
  if (!key) {
    console.warn("FINNHUB_API_KEY not set");
    return [];
  }

  const cacheKey = `finnhub_${category}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://finnhub.io/api/v1/news?category=${category}&token=${key}`;
    const response = await fetch(url);
    if (!response.ok) {
      console.error("Finnhub error:", response.status);
      return [];
    }

    const data = await response.json();
    const detectedCat = category === "crypto" ? "crypto" : category === "forex" ? "forex" : detectCategory;
    
    const items = (data || []).slice(0, limit).map((n, index) => {
      const itemCategory = typeof detectedCat === "function" 
        ? detectedCat(n.headline || "", n.summary || "") 
        : detectedCat;
      
      return {
        id: String(n.id || `finnhub-${Date.now()}-${index}`),
        headline: n.headline || "",
        summary: (n.summary || "").slice(0, 300),
        source: n.source || "Finnhub",
        sourceLogo: getSourceLogo(n.source || ""),
        url: n.url || "",
        // IMPORTANT: Finnhub provides image URLs!
        imageUrl: n.image || CATEGORY_FALLBACK_IMAGES[itemCategory] || CATEGORY_FALLBACK_IMAGES.global,
        publishedAt: n.datetime ? new Date(n.datetime * 1000).toISOString() : new Date().toISOString(),
        importance: detectImportance(n.headline || ""),
        categories: [itemCategory],
        tickers: n.related ? n.related.split(",").slice(0, 3) : extractTickers(n.headline || "", n.summary || ""),
      };
    });

    setCache(cacheKey, items);
    return items;
  } catch (err) {
    console.error("Finnhub news error:", err.message);
    return [];
  }
}

// Polygon News (for specific symbols)
async function fetchPolygonNews(symbol, limit = 10) {
  const key = process.env.POLYGON_API_KEY;
  if (!key) return [];

  const cacheKey = `polygon_${symbol}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://api.polygon.io/v2/reference/news?ticker=${symbol}&limit=${limit}&order=desc&sort=published_utc&apiKey=${key}`;
    const response = await fetch(url);
    if (!response.ok) return [];

    const data = await response.json();
    const items = (data.results || []).map((n, index) => ({
      id: n.id || n.article_url || `polygon-${Date.now()}-${index}`,
      headline: n.title || "",
      summary: (n.description || "").slice(0, 300),
      source: n.publisher?.name || "Polygon",
      sourceLogo: n.publisher?.logo_url || getSourceLogo(n.publisher?.name || ""),
      url: n.article_url || "",
      // Polygon provides image_url
      imageUrl: n.image_url || CATEGORY_FALLBACK_IMAGES.stocks,
      publishedAt: n.published_utc || new Date().toISOString(),
      importance: detectImportance(n.title || ""),
      categories: ["stocks"],
      tickers: n.tickers || [symbol],
    }));

    setCache(cacheKey, items);
    return items;
  } catch (err) {
    console.error("Polygon news error:", err.message);
    return [];
  }
}

// ============ ROUTES ============

// GET / - Main endpoint
router.get("/", async (req, res) => {
  try {
    const { category, symbol, limit = 30 } = req.query;
    const maxLimit = Math.min(parseInt(limit) || 30, 100);

    // If specific symbol requested
    if (symbol) {
      const news = await fetchPolygonNews(symbol.toUpperCase(), maxLimit);
      return res.json({
        status: "OK",
        count: news.length,
        symbol: symbol.toUpperCase(),
        news
      });
    }

    // If specific category requested
    if (category && category !== "all") {
      const finnhubCat = category === "crypto" ? "crypto" : category === "forex" ? "forex" : "general";
      const news = await fetchFinnhubNews(finnhubCat, 50);
      const filtered = news.filter(n => 
        n.categories.includes(category) || detectCategory(n.headline) === category
      ).slice(0, maxLimit);

      return res.json({
        status: "OK",
        count: filtered.length,
        category,
        news: filtered
      });
    }

    // All news
    const news = await fetchFinnhubNews("general", maxLimit);
    res.json({
      status: "OK",
      count: news.length,
      news
    });

  } catch (err) {
    console.error("News API error:", err);
    res.status(500).json({ 
      status: "ERROR", 
      error: err.message 
    });
  }
});

// GET /categories - News grouped by category (QUALITY OVER QUANTITY)
router.get("/categories", async (req, res) => {
  try {
    const { limit = 5 } = req.query;
    const maxLimit = Math.min(parseInt(limit) || 5, 10); // Max 5-6 per category

    // Fetch all news from Finnhub
    const [generalNews, cryptoNews, forexNews] = await Promise.all([
      fetchFinnhubNews("general", 60),
      fetchFinnhubNews("crypto", 25),
      fetchFinnhubNews("forex", 25)
    ]);

    // Combine and categorize
    const allNews = [...generalNews, ...cryptoNews, ...forexNews];
    
    const results = {
      global: [],
      stocks: [],
      crypto: [],
      forex: [],
      commodities: []
    };

    // Quality filter - prioritize high/medium importance
    const sortByImportance = (arr) => {
      return arr.sort((a, b) => {
        const order = { high: 0, medium: 1, low: 2 };
        const impDiff = (order[a.importance] || 2) - (order[b.importance] || 2);
        if (impDiff !== 0) return impDiff;
        // Then by recency
        return new Date(b.publishedAt) - new Date(a.publishedAt);
      });
    };

    // Distribute news by category
    allNews.forEach(item => {
      const cat = item.categories[0] || detectCategory(item.headline);
      
      // Ensure fallback image based on category
      if (!item.imageUrl || item.imageUrl === CATEGORY_FALLBACK_IMAGES.global) {
        item.imageUrl = CATEGORY_FALLBACK_IMAGES[cat] || CATEGORY_FALLBACK_IMAGES.global;
      }
      
      // For global category, only include macro economic news
      if (cat === "global") {
        if (isMacroNews(item.headline, item.summary) && results.global.length < maxLimit * 2) {
          if (!results.global.some(n => n.headline === item.headline)) {
            results.global.push(item);
          }
        }
        return;
      }
      
      if (results[cat] && results[cat].length < maxLimit * 2) {
        if (!results[cat].some(n => n.headline === item.headline)) {
          results[cat].push(item);
        }
      }
    });

    // Also scan general news for macro content
    generalNews.forEach(item => {
      if (isMacroNews(item.headline, item.summary) && results.global.length < maxLimit * 2) {
        if (!results.global.some(n => n.headline === item.headline)) {
          results.global.push(item);
        }
      }
    });

    // Sort by importance and limit
    Object.keys(results).forEach(cat => {
      results[cat] = sortByImportance(results[cat]).slice(0, maxLimit);
    });

    // If some categories are empty, fill with appropriate news
    Object.keys(results).forEach(cat => {
      if (results[cat].length === 0) {
        if (cat === "global") {
          const macroNews = generalNews.filter(n => isMacroNews(n.headline, n.summary));
          results[cat] = sortByImportance(macroNews).slice(0, maxLimit);
        } else {
          const filtered = generalNews.filter(n => detectCategory(n.headline) === cat);
          results[cat] = sortByImportance(filtered).slice(0, maxLimit);
        }
      }
    });

    res.json({
      status: "OK",
      lastUpdated: new Date().toISOString(),
      categories: {
        global: { count: results.global.length, news: results.global },
        stocks: { count: results.stocks.length, news: results.stocks },
        crypto: { count: results.crypto.length, news: results.crypto },
        forex: { count: results.forex.length, news: results.forex },
        commodities: { count: results.commodities.length, news: results.commodities }
      }
    });

  } catch (err) {
    console.error("News categories error:", err);
    res.status(500).json({ 
      status: "ERROR", 
      error: err.message 
    });
  }
});

// GET /top - Top/breaking news
router.get("/top", async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const news = await fetchFinnhubNews("general", 30);
    
    const sorted = news
      .sort((a, b) => {
        const order = { high: 0, medium: 1, low: 2 };
        return order[a.importance] - order[b.importance];
      })
      .slice(0, parseInt(limit) || 10);

    res.json({
      status: "OK",
      count: sorted.length,
      news: sorted
    });

  } catch (err) {
    res.status(500).json({ status: "ERROR", error: err.message });
  }
});

// Clear cache
router.post("/cache/clear", (req, res) => {
  newsCache.clear();
  res.json({ status: "OK", message: "News cache cleared" });
});

export default router;