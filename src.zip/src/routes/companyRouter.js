// =====================================================
// COMPANY ANALYSIS ROUTER - v3.1 (ISM Toggle Fix)
// =====================================================
// Location: src/routes/companyRouter.js
//
// v3.1 FIXES:
// - /generate endpoint now reads includeIsm from request body
// - Passes includeIsm through to generateAutoReportAsync
// - Admin can toggle ISM on/off for any report
//
// v3.0 FEATURES:
// - Auto reports (S&P 500) include ISM sector context
// - Admin custom reports: any ticker, no ISM
// - Send reports to users functionality
// - PDF generation for both types
// =====================================================

import express from 'express';
import { createRequire } from 'module';
import { createClient } from '@supabase/supabase-js';

const require = createRequire(import.meta.url);

let CompanyAnalysis;
try {
  CompanyAnalysis = require('../TopSecret/CompanyAnalysis/index.js');
} catch (e) {
  console.error('[CompanyRouter] Failed to load CompanyAnalysis:', e.message);
  CompanyAnalysis = null;
}

const router = express.Router();

// ============================================
// SUPABASE CLIENT
// ============================================
const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = SUPABASE_URL && SUPABASE_KEY ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

// ============================================
// SERVICE INITIALIZATION
// ============================================
let companyService = null;

function getService() {
  if (!companyService && CompanyAnalysis && supabase) {
    try {
      companyService = CompanyAnalysis.initCompanyAnalysisService(supabase, {
        openaiApiKey: process.env.OPENAI_API_KEY,
        openaiModel: process.env.OPENAI_MODEL || 'gpt-4-turbo',
        polygonApiKey: process.env.POLYGON_API_KEY,
        fredApiKey: process.env.FRED_API_KEY,
        eodhApiKey: process.env.EODH_API_KEY,
        newsApiKey: process.env.NEWS_API_KEY,
      });
      console.log('[CompanyRouter] Service initialized');
    } catch (e) {
      console.error('[CompanyRouter] Service init failed:', e.message);
    }
  }
  return companyService;
}

// ============================================
// IN-MEMORY TRACKING
// ============================================
const activeGenerations = new Map();

// ============================================
// AUTH MIDDLEWARE
// ============================================
const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (authHeader?.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const { data: { user }, error } = await supabase.auth.getUser(token);
      if (!error && user) {
        req.user = user;
        
        // Check if admin
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();
        
        req.isAdmin = profile?.role === 'admin' || profile?.role === 'super_admin';
      }
    } catch (e) {
      // Continue without user
    }
  }
  
  next();
};

const adminOnly = (req, res, next) => {
  if (!req.isAdmin) {
    return res.status(403).json({ success: false, error: 'Admin access required' });
  }
  next();
};

// ============================================
// HELPER: Get ISM Context for Sector
// ============================================
async function getIsmContextForSector(sector) {
  if (!supabase || !sector) return null;
  
  try {
    const { data, error } = await supabase.rpc('get_ism_sector_context', {
      p_sector: sector
    });
    
    if (error) {
      console.error('[CompanyRouter] ISM context error:', error.message);
      return null;
    }
    
    return data;
  } catch (e) {
    console.error('[CompanyRouter] ISM context exception:', e.message);
    return null;
  }
}

// ============================================
// ROUTES - HEALTH & INFO
// ============================================

router.get('/health', (req, res) => {
  const service = getService();
  res.json({
    status: 'ok',
    service: service ? 'initialized' : 'not_initialized',
    version: '3.1.0',
    features: ['ism_toggle', 'ism_integration', 'admin_custom_reports', 'send_to_users'],
  });
});

router.get('/sp500', (req, res) => {
  const service = getService();
  if (!service) {
    return res.status(503).json({ success: false, error: 'Service not initialized' });
  }
  
  const list = service.getSP500List();
  res.json({ success: true, count: list.length, tickers: list });
});

router.get('/random-ticker', (req, res) => {
  const service = getService();
  if (!service) {
    return res.status(503).json({ success: false, error: 'Service not initialized' });
  }
  
  res.json({ success: true, ticker: service.getRandomTicker(), isInSP500: true });
});

// ============================================
// ROUTE: Generate Report (S&P 500 + Optional ISM)
// ============================================
// v3.1 FIX: Now reads includeIsm from request body
// ============================================

router.post('/generate', authMiddleware, async (req, res) => {
  const service = getService();
  if (!service) {
    return res.status(503).json({ success: false, error: 'Service not initialized' });
  }
  
  // v3.1 FIX: Extract includeIsm from request body (default: true for backward compatibility)
  let { ticker, includeIsm = true, isAdminOverride = false } = req.body;
  
  // Log the ISM toggle state
  console.log(`[CompanyRouter] /generate called - ticker: ${ticker || 'random'}, includeIsm: ${includeIsm}, isAdminOverride: ${isAdminOverride}`);
  
  if (!ticker) {
    ticker = service.getRandomTicker();
    console.log(`[CompanyRouter] Random ticker selected: ${ticker}`);
  }
  
  ticker = ticker.toUpperCase();
  
  // S&P 500 check for auto reports (skip if admin override)
  const isInSP500 = service.isInSP500(ticker);
  if (!isInSP500 && !isAdminOverride) {
    return res.status(400).json({
      success: false,
      error: `${ticker} is not in S&P 500. Use /admin/generate for custom analysis.`,
      ticker,
      isInSP500: false,
      suggestion: 'Use the admin custom analysis endpoint for non-S&P 500 tickers',
    });
  }
  
  // Check if already generating
  if (activeGenerations.has(ticker)) {
    const existing = activeGenerations.get(ticker);
    if (existing.status === 'running') {
      return res.json({
        success: true,
        status: 'already_generating',
        reportId: existing.reportId,
        ticker,
        includeIsm: existing.includeIsm,
      });
    }
  }
  
  const reportId = `company_${ticker}_${Date.now()}`;
  
  // v3.1 FIX: Store the actual includeIsm value from request
  activeGenerations.set(ticker, {
    reportId,
    ticker,
    reportType: 'auto',
    includeIsm: includeIsm,  // v3.1: Use value from request
    startedAt: new Date().toISOString(),
    status: 'running',
    progress: 0,
  });
  
  // v3.1 FIX: Pass includeIsm to the generation function
  generateAutoReportAsync(service, reportId, ticker, req.user?.id, includeIsm);
  
  res.json({
    success: true,
    reportId,
    ticker,
    reportType: 'auto',
    includeIsm: includeIsm,  // v3.1: Return actual value
    status: 'generating',
    message: `Generating report for ${ticker}${includeIsm ? ' with ISM integration' : ' (no ISM)'}`,
  });
});

// ============================================
// ROUTE: Admin Custom Report (Any ticker, optional ISM)
// ============================================

router.post('/admin/generate', authMiddleware, adminOnly, async (req, res) => {
  const service = getService();
  if (!service) {
    return res.status(503).json({ success: false, error: 'Service not initialized' });
  }
  
  let { ticker, includeIsm = false, publishNote } = req.body;
  
  if (!ticker) {
    return res.status(400).json({ success: false, error: 'Ticker is required' });
  }
  
  ticker = ticker.toUpperCase();
  
  console.log(`[CompanyRouter] /admin/generate called - ticker: ${ticker}, includeIsm: ${includeIsm}`);
  
  // Validate ticker exists (basic check)
  try {
    const validation = await service.validateTicker(ticker);
    if (!validation?.valid) {
      return res.status(400).json({
        success: false,
        error: `Invalid ticker: ${ticker}`,
        ticker,
      });
    }
  } catch (e) {
    // Continue anyway - might be valid
  }
  
  const reportId = `custom_${ticker}_${Date.now()}`;
  
  activeGenerations.set(`custom_${ticker}`, {
    reportId,
    ticker,
    reportType: 'custom',
    includeIsm: includeIsm,
    startedAt: new Date().toISOString(),
    status: 'running',
    progress: 0,
    adminId: req.user?.id,
  });
  
  // Generate custom report
  generateCustomReportAsync(service, reportId, ticker, {
    includeIsm,
    publishNote,
    adminId: req.user?.id,
  });
  
  res.json({
    success: true,
    reportId,
    ticker,
    reportType: 'custom',
    includeIsm,
    status: 'generating',
    message: `Generating custom admin report for ${ticker}${includeIsm ? ' with ISM' : ' (no ISM)'}`,
  });
});

// ============================================
// BACKGROUND: Auto Report Generation
// ============================================
// v3.1 FIX: Added includeIsm parameter
// ============================================

async function generateAutoReportAsync(service, reportId, ticker, userId, includeIsm = true) {
  const startTime = Date.now();
  
  try {
    console.log(`[CompanyRouter] Starting AUTO report: ${ticker}, includeIsm: ${includeIsm}`);
    
    // Get company info first to determine sector
    const companyInfo = await service.getCompanyInfo?.(ticker) || {};
    const sector = companyInfo.sector || 'Technology';
    
    let ismContext = null;
    
    // v3.1 FIX: Only fetch ISM context if includeIsm is true
    if (includeIsm) {
      console.log(`[CompanyRouter] Fetching ISM context for sector: ${sector}`);
      ismContext = await getIsmContextForSector(sector);
      
      if (ismContext) {
        console.log(`[CompanyRouter] ISM context found:`, {
          month: ismContext.report_month,
          hasRanking: !!ismContext.sector_ranking,
          quotesCount: ismContext.relevant_quotes?.length || 0,
        });
      }
    } else {
      console.log(`[CompanyRouter] Skipping ISM context (includeIsm: false)`);
    }
    
    // Update progress
    const gen = activeGenerations.get(ticker);
    if (gen) {
      gen.progress = 10;
      gen.currentPhase = includeIsm ? 'ISM_CONTEXT' : 'DATA_FETCH';
    }
    
    // Generate report with or without ISM context
    const result = await service.generateReport(ticker, {
      reportType: 'auto',
      includeIsm: includeIsm,  // v3.1: Pass actual value
      ismContext: ismContext,
      skipIsmSection: !includeIsm,  // v3.1: Tell agents to skip ISM if disabled
    });
    
    const actualReport = result.report || result;
    
    // Only add ISM section if includeIsm is true and we have context
    if (includeIsm && ismContext && actualReport) {
      actualReport.ism_context = ismContext;
      actualReport.ism_integration = buildIsmSection(ticker, sector, ismContext);
    }
    
    // Save to database
    if (supabase && actualReport) {
      await supabase.from('company_reports').upsert({
        id: reportId,
        ticker,
        company_name: actualReport.company_name,
        sector: actualReport.sector,
        report_type: 'auto',
        include_ism: includeIsm,  // v3.1: Store actual value
        ism_context: includeIsm ? ismContext : null,
        ...actualReport,
        created_at: new Date().toISOString(),
      }, { onConflict: 'id' });
    }
    
    // Update status
    if (gen) {
      gen.status = 'completed';
      gen.progress = 100;
      gen.report = actualReport;
      gen.completedAt = new Date().toISOString();
      gen.elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
    }
    
    console.log(`[CompanyRouter] AUTO report completed: ${ticker}, includeIsm: ${includeIsm}`);
    
    // Cleanup after 1 hour
    setTimeout(() => activeGenerations.delete(ticker), 60 * 60 * 1000);
    
  } catch (error) {
    console.error(`[CompanyRouter] AUTO report failed: ${ticker}`, error.message);
    
    const gen = activeGenerations.get(ticker);
    if (gen) {
      gen.status = 'error';
      gen.error = error.message;
      gen.completedAt = new Date().toISOString();
    }
    
    setTimeout(() => activeGenerations.delete(ticker), 10 * 60 * 1000);
  }
}

// ============================================
// BACKGROUND: Custom Report Generation (optional ISM)
// ============================================

async function generateCustomReportAsync(service, reportId, ticker, options) {
  const startTime = Date.now();
  const key = `custom_${ticker}`;
  
  try {
    console.log(`[CompanyRouter] Starting CUSTOM report: ${ticker}, includeIsm: ${options.includeIsm}`);
    
    let ismContext = null;
    
    // Only fetch ISM if explicitly requested
    if (options.includeIsm) {
      const companyInfo = await service.getCompanyInfo?.(ticker) || {};
      const sector = companyInfo.sector || 'Technology';
      ismContext = await getIsmContextForSector(sector);
    }
    
    // Generate report
    const result = await service.generateReport(ticker, {
      reportType: 'custom',
      includeIsm: options.includeIsm,
      ismContext: ismContext,
      skipIsmSection: !options.includeIsm, // Tell agents to skip ISM
    });
    
    const actualReport = result.report || result;
    
    // Only add ISM if requested
    if (options.includeIsm && ismContext && actualReport) {
      actualReport.ism_context = ismContext;
      actualReport.ism_integration = buildIsmSection(ticker, actualReport.sector, ismContext);
    }
    
    // Save to database
    if (supabase && actualReport) {
      await supabase.from('company_reports').upsert({
        id: reportId,
        ticker,
        company_name: actualReport.company_name,
        sector: actualReport.sector,
        report_type: 'custom',
        include_ism: options.includeIsm,
        ism_context: options.includeIsm ? ismContext : null,
        created_by_admin: options.adminId,
        publish_note: options.publishNote,
        is_published: false,
        ...actualReport,
        created_at: new Date().toISOString(),
      }, { onConflict: 'id' });
    }
    
    // Update status
    const gen = activeGenerations.get(key);
    if (gen) {
      gen.status = 'completed';
      gen.progress = 100;
      gen.report = actualReport;
      gen.completedAt = new Date().toISOString();
      gen.elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
    }
    
    console.log(`[CompanyRouter] CUSTOM report completed: ${ticker}`);
    
    setTimeout(() => activeGenerations.delete(key), 60 * 60 * 1000);
    
  } catch (error) {
    console.error(`[CompanyRouter] CUSTOM report failed: ${ticker}`, error.message);
    
    const gen = activeGenerations.get(key);
    if (gen) {
      gen.status = 'error';
      gen.error = error.message;
      gen.completedAt = new Date().toISOString();
    }
    
    setTimeout(() => activeGenerations.delete(key), 10 * 60 * 1000);
  }
}

// ============================================
// HELPER: Build ISM Integration Section
// ============================================

function buildIsmSection(ticker, sector, ismContext) {
  if (!ismContext) return null;
  
  const { sector_ranking, relevant_quotes, trade_ideas, report_month } = ismContext;
  
  let section = {
    title: `ISM Manufacturing Impact on ${ticker}`,
    reportMonth: report_month,
    sectorContext: null,
    relevantQuotes: [],
    tradeImplications: [],
    summary: '',
  };
  
  // Sector ranking context
  if (sector_ranking) {
    section.sectorContext = {
      rank: sector_ranking.rank,
      direction: sector_ranking.direction,
      impactScore: sector_ranking.impact_score,
      reasoning: sector_ranking.reasoning,
      quoteSupport: sector_ranking.quote_support,
    };
    
    const directionText = sector_ranking.direction === 'positive' 
      ? 'positive tailwinds' 
      : sector_ranking.direction === 'negative' 
        ? 'headwinds' 
        : 'neutral conditions';
    
    section.summary = `The ${sector} sector ranks #${sector_ranking.rank} in ISM impact with ${directionText}. `;
  }
  
  // Relevant quotes
  if (relevant_quotes?.length > 0) {
    section.relevantQuotes = relevant_quotes.map(q => ({
      industry: q.industry,
      quote: q.comment,
      sentiment: q.sentiment,
    }));
    
    section.summary += `${relevant_quotes.length} executive comments relate to this sector. `;
  }
  
  // Trade implications
  if (trade_ideas?.length > 0) {
    section.tradeImplications = trade_ideas.map(t => ({
      title: t.title,
      direction: t.direction,
      thesis: t.thesis,
      conviction: t.conviction,
    }));
    
    const longIdeas = trade_ideas.filter(t => t.direction === 'long').length;
    const shortIdeas = trade_ideas.filter(t => t.direction === 'short').length;
    
    if (longIdeas > 0) section.summary += `${longIdeas} bullish trade ideas identified. `;
    if (shortIdeas > 0) section.summary += `${shortIdeas} bearish signals present. `;
  }
  
  return section;
}

// ============================================
// ROUTE: Get Report Progress
// ============================================

router.get('/progress/:reportId', (req, res) => {
  const { reportId } = req.params;
  
  let generation = null;
  
  for (const [key, gen] of activeGenerations) {
    if (gen.reportId === reportId) {
      generation = gen;
      break;
    }
  }
  
  if (!generation) {
    return res.status(404).json({ success: false, error: 'Generation not found' });
  }
  
  res.json({
    success: true,
    data: {
      reportId: generation.reportId,
      ticker: generation.ticker,
      reportType: generation.reportType,
      includeIsm: generation.includeIsm,
      status: generation.status,
      progress: generation.progress,
      elapsedSeconds: generation.elapsedSeconds,
      error: generation.error,
    },
  });
});

// ============================================
// ROUTE: Get Report
// ============================================

router.get('/report/:reportId', authMiddleware, async (req, res) => {
  const { reportId } = req.params;
  
  // Check in-memory
  for (const [key, gen] of activeGenerations) {
    if (gen.reportId === reportId && gen.status === 'completed') {
      return res.json({ success: true, data: gen.report });
    }
  }
  
  // Check database
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('company_reports')
        .select('*')
        .eq('id', reportId)
        .single();
      
      if (data && !error) {
        return res.json({ success: true, data });
      }
    } catch (e) {
      // Continue
    }
  }
  
  res.status(404).json({ success: false, error: 'Report not found' });
});

// ============================================
// ROUTE: Admin - List Custom Reports
// ============================================

router.get('/admin/reports', authMiddleware, adminOnly, async (req, res) => {
  if (!supabase) {
    return res.status(503).json({ success: false, error: 'Database not configured' });
  }
  
  const { type, limit = 50 } = req.query;
  
  try {
    let query = supabase
      .from('company_reports')
      .select('id, ticker, company_name, sector, report_type, include_ism, qa_score, is_published, sent_to_users, sent_count, created_at')
      .order('created_at', { ascending: false })
      .limit(parseInt(limit));
    
    if (type === 'custom') {
      query = query.eq('report_type', 'custom');
    } else if (type === 'auto') {
      query = query.eq('report_type', 'auto');
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    
    res.json({ success: true, reports: data || [], count: data?.length || 0 });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================
// ROUTE: Admin - Send Report to Users
// ============================================

router.post('/admin/send', authMiddleware, adminOnly, async (req, res) => {
  const { 
    reportId, 
    recipientType = 'all_premium', // 'all_premium', 'all_basic', 'newsletter', 'custom'
    recipientIds = [],
    subject,
    customMessage,
    includePdf = true,
  } = req.body;
  
  if (!reportId) {
    return res.status(400).json({ success: false, error: 'reportId is required' });
  }
  
  if (!supabase) {
    return res.status(503).json({ success: false, error: 'Database not configured' });
  }
  
  try {
    // Get report
    const { data: report, error: reportError } = await supabase
      .from('company_reports')
      .select('*')
      .eq('id', reportId)
      .single();
    
    if (reportError || !report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    
    // Get recipients based on type
    let recipients = [];
    
    if (recipientType === 'custom' && recipientIds.length > 0) {
      const { data: users } = await supabase
        .from('profiles')
        .select('id, email, display_name')
        .in('id', recipientIds);
      recipients = users || [];
    } else if (recipientType === 'all_premium') {
      const { data: users } = await supabase
        .from('profiles')
        .select('id, email, display_name')
        .eq('account_type', 'premium');
      recipients = users || [];
    } else if (recipientType === 'all_basic') {
      const { data: users } = await supabase
        .from('profiles')
        .select('id, email, display_name')
        .in('account_type', ['basic', 'premium']);
      recipients = users || [];
    } else if (recipientType === 'newsletter') {
      const { data: users } = await supabase
        .from('profiles')
        .select('id, email, display_name')
        .in('newsletter_status', ['active', 'trial']);
      recipients = users || [];
    }
    
    if (recipients.length === 0) {
      return res.status(400).json({ success: false, error: 'No recipients found' });
    }
    
    // Log the send
    const emailSubject = subject || `Company Analysis: ${report.ticker} - ${report.company_name}`;
    
    const { data: sendLog, error: sendError } = await supabase.rpc('log_company_report_send', {
      p_report_id: reportId,
      p_ticker: report.ticker,
      p_sent_by: req.user.id,
      p_recipient_type: recipientType,
      p_recipient_ids: recipients.map(r => r.id),
      p_recipient_count: recipients.length,
      p_subject: emailSubject,
      p_custom_message: customMessage || null,
    });
    
    // TODO: Actually send emails via Resend
    // This is a placeholder - implement actual email sending
    console.log(`[CompanyRouter] Would send to ${recipients.length} recipients:`, {
      reportId,
      ticker: report.ticker,
      subject: emailSubject,
      recipientType,
      includePdf,
    });
    
    res.json({
      success: true,
      message: `Report queued for sending to ${recipients.length} recipients`,
      data: {
        reportId,
        ticker: report.ticker,
        recipientCount: recipients.length,
        recipientType,
        subject: emailSubject,
      },
    });
    
  } catch (e) {
    console.error('[CompanyRouter] Send error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================
// ROUTE: Admin - Publish/Unpublish Report
// ============================================

router.post('/admin/publish/:reportId', authMiddleware, adminOnly, async (req, res) => {
  const { reportId } = req.params;
  const { isPublished, publishNote } = req.body;
  
  if (!supabase) {
    return res.status(503).json({ success: false, error: 'Database not configured' });
  }
  
  try {
    const { data, error } = await supabase
      .from('company_reports')
      .update({
        is_published: isPublished,
        publish_note: publishNote,
        updated_at: new Date().toISOString(),
      })
      .eq('id', reportId)
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({
      success: true,
      message: isPublished ? 'Report published' : 'Report unpublished',
      data,
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================
// ROUTE: Download PDF
// ============================================

router.get('/report/:reportId/pdf', authMiddleware, async (req, res) => {
  const service = getService();
  const { reportId } = req.params;
  
  // Find report
  let report = null;
  
  for (const [key, gen] of activeGenerations) {
    if (gen.reportId === reportId && gen.status === 'completed') {
      report = gen.report;
      break;
    }
  }
  
  if (!report && supabase) {
    try {
      const { data } = await supabase
        .from('company_reports')
        .select('*')
        .eq('id', reportId)
        .single();
      
      if (data) report = data;
    } catch (e) {
      // Continue
    }
  }
  
  if (!report) {
    return res.status(404).json({ success: false, error: 'Report not found' });
  }
  
  try {
    const pdfBuffer = await service.generatePDF(report);
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="Company_Analysis_${report.ticker}.pdf"`);
    res.send(pdfBuffer);
  } catch (e) {
    console.error('[CompanyRouter] PDF generation failed:', e.message);
    res.status(500).json({ success: false, error: `PDF generation failed: ${e.message}` });
  }
});

// ============================================
// ROUTE: Active Generations
// ============================================

router.get('/active-generations', (req, res) => {
  const generations = [];
  
  for (const [key, gen] of activeGenerations) {
    generations.push({
      key,
      ticker: gen.ticker,
      reportId: gen.reportId,
      reportType: gen.reportType,
      includeIsm: gen.includeIsm,
      status: gen.status,
      progress: gen.progress,
      startedAt: gen.startedAt,
    });
  }
  
  res.json({ success: true, count: generations.length, generations });
});

export default router;