// src/routes/market.ts
import { Router } from "express";
import fetch from "node-fetch";
import { parseStringPromise } from "xml2js";

export const marketRouter = Router();

/* -------------------------- helpers -------------------------- */

const FMP = process.env.FMP_API_KEY || "demo";
const FH  = process.env.FINNHUB_API_KEY || "";

type Quote = { price:number|null, ch:number|null, chp:number|null, chOpen:number|null, chPrev:number|null, isPremarket:boolean };

function num(v: any): number | null {
  const n = typeof v === "string" ? parseFloat(v) : (typeof v === "number" ? v : NaN);
  return Number.isFinite(n) ? n : null;
}

/* -------------------------- caching -------------------------- */
const cache = new Map<string, { t:number, q:Quote }>();
const inflight = new Map<string, Promise<Quote>>();
const TTL_MS = 5000;

async function getQuoteCached(sym: string, fetcher: (s:string)=>Promise<Quote>): Promise<Quote> {
  const now = Date.now();
  const hit = cache.get(sym);
  if (hit && (now - hit.t) < TTL_MS) return hit.q;
  if (inflight.has(sym)) return inflight.get(sym)!;
  const p = (async () => {
    try {
      const q = await fetcher(sym);
      cache.set(sym, { t: Date.now(), q });
      return q;
    } finally {
      inflight.delete(sym);
    }
  })();
  inflight.set(sym, p);
  return p;
}

/* ------------------- symbol normalization -------------------- */

// Map short UI symbols to canonical form (VENUE:SYMBOL) when known
function knownMap(sym: string): string | null {
  const map: Record<string, string> = {
    // Crypto (Binance spot)
    "BTC": "BINANCE:BTCUSDT",
    "BTCUSD": "BINANCE:BTCUSDT",
    "ETH": "BINANCE:ETHUSDT",
    "ETHUSD": "BINANCE:ETHUSDT",
    "ETHUSDT": "BINANCE:ETHUSDT",

    // Indices via TVC
    "DXY": "TVC:DXY",
    "VIX": "TVC:VIX",

    // US ETFs / Stocks
    "SPY": "AMEX:SPY",
    "QQQ": "NASDAQ:QQQ",
    "TSLA": "NASDAQ:TSLA",
    "AAPL": "NASDAQ:AAPL",

    // Forex & Metals
    "XAUUSD": "FOREXCOM:XAUUSD",
    "EURUSD": "FX:EURUSD",
  };
  return map[sym] || null;
}

// Best-effort resolver for arbitrary symbols
function resolveSymbol(input: string): string {
  const s = (input || "").trim().toUpperCase();
  if (!s) return s;
  if (s.includes(":")) return s; // already canonical
  const known = knownMap(s);
  if (known) return known;

  // Heuristic 1: Binance crypto like SOLUSDT, XRPUSDT, etc.
  if (/^[A-Z]{2,12}USDT$/.test(s)) return "BINANCE:" + s;

  // Heuristic 2: FX pair like GBPUSD, USDJPY, USDCHF, etc. (also metals XAUUSD/XAGUSD handled above)
  if (/^[A-Z]{6}$/.test(s)) return s; // will route later to OANDA via mapToFinnhubFxMetal

  // Default: assume US equity/ETF -> Finnhub
  return s; // handled by Finnhub equities path
}

// Normalize for FMP quote endpoint
function normalizeForFmp(sym: string): string {
  const i = sym.indexOf(":");
  const raw = i >= 0 ? sym.slice(i + 1) : sym;
  if (/^VIX$/i.test(raw)) return "^VIX";
  if (/^DXY$/i.test(raw)) return "DX-Y.NYB";
  return raw;
}

// Normalize for Finnhub equities (strip venue)
function normalizeForEquity(sym: string): string {
  const i = sym.indexOf(":");
  return (i >= 0 ? sym.slice(i + 1) : sym).toUpperCase();
}

// Finnhub mapping for FX/Metals via OANDA
function mapToFinnhubFxMetal(raw: string): string | null {
  const m = raw.match(/^(?:FX:|FOREXCOM:)?([A-Z]{3})([A-Z]{3})$/i);
  if (!m) return null;
  const base = m[1].toUpperCase();
  const quote = m[2].toUpperCase();
  return `OANDA:${base}_${quote}`;
}

/* ---- Free public fallbacks (Stooq) for FX/Metals/DXY ---- */
async function stooqQuote(sym: string): Promise<{ price: number|null, open: number|null } | null> {
  const s = sym.toLowerCase();
  const url = `https://stooq.com/q/l/?s=${encodeURIComponent(s)}&f=sd2t2ohlcv&h&e=csv`;
  const r = await fetch(url);
  const csv = await r.text();
  const lines = csv.trim().split(/\r?\n/);
  if (lines.length < 2) return null;
  const row = lines[1].split(",");
  const open = num(row[3]);
  const close = num(row[6]);
  return { price: close, open };
}

/* ---- Yahoo fallback for DXY (no key) ---- */
async function yahooQuote(symbol: string): Promise<{ price: number|null } | null> {
  const url = "https://query1.finance.yahoo.com/v7/finance/quote?symbols=" + encodeURIComponent(symbol);
  const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 (compatible; FinotaurBot/1.0)" } });
  const j: any = await r.json();
  const r0 = j?.quoteResponse?.result?.[0];
  if (!r0) return null;
  const last = r0.regularMarketPrice ?? r0.postMarketPrice ?? r0.preMarketPrice;
  return { price: (typeof last === "number" ? last : null) };
}

/* ---- Finnhub fetch helper ---- */
async function finnhubQuote(symbol: string): Promise<{ c:number|null, o:number|null, pc:number|null } | null> {
  if (!FH) return null;
  const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${FH}`;
  const r = await fetch(url);
  const j: any = await r.json();
  if (!j || typeof j.c === "undefined") return null;
  return { c: num(j.c), o: num(j.o), pc: num(j.pc) };
}

/* ---- Compute DXY from FX legs (Finnhub OANDA) ---- */
async function computeDxyFromFx(): Promise<number | null> {
  const legs: Array<[string, number]> = [
    ["OANDA:EUR_USD", -0.576],
    ["OANDA:USD_JPY",  0.136],
    ["OANDA:GBP_USD", -0.119],
    ["OANDA:USD_CAD",  0.091],
    ["OANDA:USD_SEK",  0.042],
    ["OANDA:USD_CHF",  0.036],
  ];

  let value = 50.14348112;
  for (const [sym, exp] of legs) {
    const q = await finnhubQuote(sym);
    const px = q?.c;
    if (px == null || px <= 0) return null;
    value *= Math.pow(px, exp);
  }
  return value;
}

/* ------------------------ sentiment -------------------------- */
marketRouter.get("/sentiment/fear-greed", async (_req, res) => {
  try {
    const r = await fetch("https://api.alternative.me/fng/?limit=1");
    const j: any = await r.json();
    res.json({ value: j?.data?.[0]?.value ?? null });
  } catch (e) {
    res.status(500).json({ value: null });
  }
});

/* --------------------------- news ---------------------------- */
marketRouter.get("/news", async (_req, res) => {
  try {
    const feeds = [
      "https://feeds.reuters.com/reuters/businessNews",
      "https://www.cnbc.com/id/100003114/device/rss/rss.html",
      "https://www.investing.com/rss/news_25.rss",
    ];
    const items: any[] = [];
    for (const url of feeds) {
      const xml = await (await fetch(url)).text();
      const obj: any = await parseStringPromise(xml);
      const ch = obj?.rss?.channel?.[0];
      (ch?.item || []).slice(0, 10).forEach((it: any) => {
        items.push({
          title: it.title?.[0],
          link: it.link?.[0],
          source: ch?.title?.[0] || "News",
          pubDate: it.pubDate?.[0],
        });
      });
    }
    const uniq = Array.from(new Map(items.map((i) => [i.link, i])).values()).slice(0, 30);
    res.json(uniq);
  } catch (e) {
    res.status(500).json([]);
  }
});

/* -------------------- core single-symbol fetch -------------------- */
async function fetchOneSymbol(symInput: string): Promise<Quote> {
  const raw = resolveSymbol(symInput).toUpperCase();
  const empty: Quote = { price: null, ch: null, chp: null, chOpen: null, chPrev: null, isPremarket: false };

  try {
    // --- Crypto via Binance (free realtime) ---
    if (raw.startsWith("BINANCE:")) {
      const symbol = raw.replace("BINANCE:", "");
      const r = await fetch("https://api.binance.com/api/v3/ticker/24hr?symbol=" + encodeURIComponent(symbol));
      const j: any = await r.json();
      const last = num(j?.lastPrice);
      const open = num(j?.openPrice);
      const prev = num(j?.prevClosePrice);
      const priceChange = num(j?.priceChange);
      const priceChangePercent = num(j?.priceChangePercent);
      return {
        price: last,
        ch: priceChange,
        chp: priceChangePercent,
        chOpen: (last!=null && open!=null && open!==0) ? ((last - open) / open) * 100 : null,
        chPrev: (last!=null && prev!=null && prev!==0) ? ((last - prev) / prev) * 100 : null,
        isPremarket: false,
      };
    }

    // --- Special handling for DXY first (more robust) ---
    if (/^(TVC:DXY|DXY)$/i.test(raw)) {
      const dxyComputed = await computeDxyFromFx();
      if (dxyComputed != null) return { ...empty, price: dxyComputed };
      const st = await stooqQuote("dxy");
      if (st && st.price != null) {
        return { ...empty, price: st.price, chOpen: (st.price!=null && st.open!=null && st.open!==0) ? ((st.price - st.open) / st.open) * 100 : null };
      }
      const yCandidates = ["DX-Y.NYB", "DX=F"];
      for (const s of yCandidates) {
        const yq = await yahooQuote(s);
        if (yq?.price != null) return { ...empty, price: yq.price };
      }
      // fallthrough to FMP below
    }

    // --- Equities/ETFs via Finnhub if key exists ---
    if (FH && /^(NYSE|NASDAQ|AMEX):|^[A-Z.]{1,12}$/.test(raw)) {
      const eq = normalizeForEquity(raw);
      const r = await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(eq)}&token=${FH}`);
      const j: any = await r.json();
      if (j && typeof j.c !== "undefined") {
        const last = num(j.c);
        const open = num(j.o);
        const prev = num(j.pc);
        return {
          price: last,
          ch: (last!=null && prev!=null) ? (last - prev) : null,
          chp: (last!=null && prev!=null && prev!==0) ? ((last - prev) / prev) * 100 : null,
          chOpen: (last!=null && open!=null && open!==0) ? ((last - open) / open) * 100 : null,
          chPrev: (last!=null && prev!=null && prev!==0) ? ((last - prev) / prev) * 100 : null,
          isPremarket: false,
        };
      }
    }

    // --- FX & Metals via Finnhub (OANDA) if key exists ---
    if (FH) {
      const oandaSym = mapToFinnhubFxMetal(raw);
      if (oandaSym) {
        const q = await finnhubQuote(oandaSym);
        if (q && q.c != null) {
          const last = q.c, open = q.o, prev = q.pc;
          return {
            price: last,
            ch: (last!=null && prev!=null) ? (last - prev) : null,
            chp: (last!=null && prev!=null && prev!==0) ? ((last - prev) / prev) * 100 : null,
            chOpen: (last!=null && open!=null && open!==0) ? ((last - open) / open) * 100 : null,
            chPrev: (last!=null && prev!=null && prev!==0) ? ((last - prev) / prev) * 100 : null,
            isPremarket: false,
          };
        }
      }
    }

    // --- Free public fallback via Stooq (no key) for FX/Metals/DXY ---
    const stooqMap: Record<string,string> = {
      "FX:EURUSD": "eurusd",
      "FOREXCOM:EURUSD": "eurusd",
      "EURUSD": "eurusd",
      "FOREXCOM:XAUUSD": "xauusd",
      "XAUUSD": "xauusd",
      "TVC:DXY": "dxy",
      "DXY": "dxy"
    };
    const st = stooqMap[raw] || null;
    if (st) {
      const q = await stooqQuote(st);
      if (q && q.price != null) {
        return {
          price: q.price,
          ch: null,
          chp: null,
          chOpen: (q.price!=null && q.open!=null && q.open!==0) ? ((q.price - q.open) / q.open) * 100 : null,
          chPrev: null,
          isPremarket: false,
        };
      }
    }

    // --- Everything else via FMP (fallback) ---
    const candidates: string[] = (() => {
      const s = normalizeForFmp(raw);
      if (s === "DX-Y.NYB") return ["DX-Y.NYB", "DXY", "^DXY"];
      if (s === "^VIX") return ["^VIX", "VIX"];
      return [s];
    })();

    for (const sym of candidates) {
      const url = "https://financialmodelingprep.com/api/v3/quote/" + encodeURIComponent(sym) + "?apikey=" + FMP;
      const r = await fetch(url);
      const arr: any[] = await r.json();
      const q = Array.isArray(arr) ? arr[0] : null;
      if (q) {
        const price = num(q.price);
        const change = num(q.change);
        const chp = num(q.changesPercentage);
        const prevClose = num(q.previousClose);
        const open = num(q.open);
        return {
          price,
          ch: change,
          chp,
          chOpen: (price!=null && open!=null && open!==0) ? ((price - open) / open) * 100 : null,
          chPrev: (price!=null && prevClose!=null && prevClose!==0) ? ((price - prevClose) / prevClose) * 100 : null,
          isPremarket: false,
        };
      }
    }

    return empty;
  } catch {
    return empty;
  }
}

/* --------------------------- endpoints --------------------------- */

// Single symbol (backward compatible)
marketRouter.get("/quote", async (req, res) => {
  const raw = (req.query.symbol as string || "").trim();
  const canon = resolveSymbol(raw).toUpperCase();
  const q = await getQuoteCached(canon, (s) => fetchOneSymbol(s));
  res.json(q);
});

// NEW: batch endpoint with cache fan-out
// GET /api/quotes?symbols=BTC,SPY,EURUSD,...
marketRouter.get("/quotes", async (req, res) => {
  const raw = String(req.query.symbols || "").trim();
  if (!raw) return res.json({});
  const list = raw.split(/[,\s]+/).filter(Boolean);
  const out: Record<string, Quote> = {};
  await Promise.all(list.map(async (s) => {
    const canon = resolveSymbol(s).toUpperCase();
    const q = await getQuoteCached(canon, (ss) => fetchOneSymbol(ss));
    out[s.toUpperCase()] = q;
  }));
  res.json(out);
});

/* --------------------------- extras ---------------------------- */
marketRouter.get("/sentiment/fear-greed", async (_req, res) => {
  try {
    const r = await fetch("https://api.alternative.me/fng/?limit=1");
    const j: any = await r.json();
    res.json({ value: j?.data?.[0]?.value ?? null });
  } catch {
    res.status(500).json({ value: null });
  }
});

marketRouter.get("/news", async (_req, res) => {
  try {
    const feeds = [
      "https://feeds.reuters.com/reuters/businessNews",
      "https://www.cnbc.com/id/100003114/device/rss/rss.html",
      "https://www.investing.com/rss/news_25.rss",
    ];
    const items: any[] = [];
    for (const url of feeds) {
      const xml = await (await fetch(url)).text();
      const obj: any = await parseStringPromise(xml);
      const ch = obj?.rss?.channel?.[0];
      (ch?.item || []).slice(0, 10).forEach((it: any) => {
        items.push({
          title: it.title?.[0],
          link: it.link?.[0],
          source: ch?.title?.[0] || "News",
          pubDate: it.pubDate?.[0],
        });
      });
    }
    const uniq = Array.from(new Map(items.map((i) => [i.link, i])).values()).slice(0, 30);
    res.json(uniq);
  } catch {
    res.status(500).json([]);
  }
});

export default marketRouter;
