// src/routes/macro.js — Market Overview with REAL data + CACHE for weekends
// Uses Yahoo Finance for indices/commodities + Polygon for crypto
// Caches data in Supabase for when markets are closed

import { Router } from 'express';
import { createClient } from '@supabase/supabase-js';

const router = Router();
const POLY_KEY = process.env.POLYGON_API_KEY || '';

// Supabase client for caching
const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;
let supabase = null;

function getSupabase() {
  if (!supabase && SUPABASE_URL && SUPABASE_KEY) {
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
  }
  return supabase;
}

// Yahoo Finance API helper
async function fetchYahoo(symbol) {
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1d&range=5d`;
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    
    const result = data?.chart?.result?.[0];
    if (!result) return null;
    
    const meta = result.meta;
    const quotes = result.indicators?.quote?.[0];
    const closes = quotes?.close?.filter(c => c !== null) || [];
    
    const currentPrice = meta.regularMarketPrice;
    const previousClose = meta.previousClose || closes[closes.length - 2];
    const weekAgoClose = closes[0];
    
    if (!currentPrice || currentPrice === 0) return null;
    
    const dailyChange = currentPrice - previousClose;
    const dailyChangePercent = previousClose ? (dailyChange / previousClose) * 100 : 0;
    
    const weeklyChange = weekAgoClose ? currentPrice - weekAgoClose : null;
    const weeklyChangePercent = weekAgoClose ? (weeklyChange / weekAgoClose) * 100 : null;
    
    return {
      price: currentPrice,
      dailyChange,
      dailyChangePercent,
      weeklyChange,
      weeklyChangePercent,
      volume: meta.regularMarketVolume || 0,
    };
  } catch (e) {
    console.error(`[macro] Yahoo fetch error for ${symbol}:`, e.message);
    return null;
  }
}

// Polygon API for crypto
async function fetchPolygonCrypto(symbol) {
  if (!POLY_KEY) return null;
  try {
    const url = `https://api.polygon.io/v2/aggs/ticker/${encodeURIComponent(symbol)}/prev?adjusted=true&apiKey=${POLY_KEY}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const result = data?.results?.[0];
    if (!result) return null;
    
    // Get weekly data
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 7);
    const fromStr = from.toISOString().split('T')[0];
    const toStr = to.toISOString().split('T')[0];
    
    const weekUrl = `https://api.polygon.io/v2/aggs/ticker/${encodeURIComponent(symbol)}/range/1/day/${fromStr}/${toStr}?adjusted=true&sort=asc&apiKey=${POLY_KEY}`;
    const weekRes = await fetch(weekUrl);
    const weekData = await weekRes.json();
    const weekResults = weekData?.results || [];
    
    const currentPrice = result.c;
    const dailyChange = result.c - result.o;
    const dailyChangePercent = result.o ? (dailyChange / result.o) * 100 : 0;
    
    let weeklyChange = null;
    let weeklyChangePercent = null;
    if (weekResults.length >= 2) {
      const weekAgoPrice = weekResults[0].c;
      weeklyChange = currentPrice - weekAgoPrice;
      weeklyChangePercent = (weeklyChange / weekAgoPrice) * 100;
    }
    
    return {
      price: currentPrice,
      dailyChange,
      dailyChangePercent,
      weeklyChange,
      weeklyChangePercent,
      volume: result.v || 0,
    };
  } catch (e) {
    console.error(`[macro] Polygon crypto error for ${symbol}:`, e.message);
    return null;
  }
}

// Asset configurations with REAL symbols
const ASSETS = [
  { symbol: '^GSPC', displaySymbol: 'SPX', name: 'S&P 500', category: 'index', riskDirection: 'positive', source: 'yahoo' },
  { symbol: '^NDX', displaySymbol: 'NDX', name: 'Nasdaq 100', category: 'index', riskDirection: 'positive', source: 'yahoo' },
  { symbol: '^DJI', displaySymbol: 'DJI', name: 'Dow Jones', category: 'index', riskDirection: 'positive', source: 'yahoo' },
  { symbol: '^RUT', displaySymbol: 'RUT', name: 'Russell 2000', category: 'index', riskDirection: 'positive', source: 'yahoo' },
  { symbol: '^VIX', displaySymbol: 'VIX', name: 'Volatility Index', category: 'volatility', riskDirection: 'negative', source: 'yahoo' },
  { symbol: '^TNX', displaySymbol: 'TNX', name: 'US 10Y Yield', category: 'bond', riskDirection: 'neutral', source: 'yahoo' },
  { symbol: 'DX-Y.NYB', displaySymbol: 'DXY', name: 'US Dollar Index', category: 'currency', riskDirection: 'negative', source: 'yahoo' },
  { symbol: 'CL=F', displaySymbol: 'CL', name: 'Crude Oil (WTI)', category: 'commodity', riskDirection: 'positive', source: 'yahoo' },
  { symbol: 'GC=F', displaySymbol: 'GC', name: 'Gold', category: 'commodity', riskDirection: 'negative', source: 'yahoo' },
  { symbol: 'X:BTCUSD', displaySymbol: 'BTC', name: 'Bitcoin', category: 'crypto', riskDirection: 'positive', source: 'polygon' },
];

// Format volume
function formatVolume(vol) {
  if (!vol || vol === 0) return '—';
  if (vol >= 1e9) return (vol / 1e9).toFixed(1) + 'B';
  if (vol >= 1e6) return (vol / 1e6).toFixed(1) + 'M';
  if (vol >= 1e3) return (vol / 1e3).toFixed(1) + 'K';
  return vol.toString();
}

// Determine risk sentiment
function getRiskSentiment(asset, dailyChangePercent) {
  if (dailyChangePercent == null) return 'Neutral';
  
  const threshold = 0.5;
  
  if (asset.riskDirection === 'positive') {
    if (dailyChangePercent > threshold) return 'Risk-On';
    if (dailyChangePercent < -threshold) return 'Risk-Off';
  } else if (asset.riskDirection === 'negative') {
    if (dailyChangePercent > threshold) return 'Risk-Off';
    if (dailyChangePercent < -threshold) return 'Risk-On';
  }
  
  return 'Neutral';
}

// Save to cache
async function saveToCache(assets) {
  const sb = getSupabase();
  if (!sb) return;
  
  try {
    for (const asset of assets) {
      if (asset.price === null || asset.error) continue;
      
      await sb.from('macro_cache').upsert({
        symbol: asset.symbol,
        name: asset.name,
        category: asset.category,
        price: asset.price,
        daily_change: asset.dailyChange,
        daily_change_percent: asset.dailyChangePercent,
        weekly_change: asset.weeklyChange,
        weekly_change_percent: asset.weeklyChangePercent,
        volume: asset.volume,
        risk_sentiment: asset.riskSentiment,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'symbol' });
    }
    console.log('[macro] Cache updated successfully');
  } catch (e) {
    console.error('[macro] Cache save error:', e.message);
  }
}

// Load from cache
async function loadFromCache() {
  const sb = getSupabase();
  if (!sb) return null;
  
  try {
    const { data, error } = await sb
      .from('macro_cache')
      .select('*')
      .order('symbol');
    
    if (error) throw error;
    if (!data || data.length === 0) return null;
    
    return data.map(row => ({
      symbol: row.symbol,
      name: row.name,
      category: row.category,
      price: row.price,
      dailyChange: row.daily_change,
      dailyChangePercent: row.daily_change_percent,
      weeklyChange: row.weekly_change,
      weeklyChangePercent: row.weekly_change_percent,
      volume: row.volume || '—',
      riskSentiment: row.risk_sentiment || 'Neutral',
      cached: true,
      cachedAt: row.updated_at,
    }));
  } catch (e) {
    console.error('[macro] Cache load error:', e.message);
    return null;
  }
}

// Main endpoint - GET /api/macro/snapshot
router.get('/macro/snapshot', async (req, res) => {
  try {
    const results = await Promise.all(
      ASSETS.map(async (asset) => {
        let data = null;
        
        if (asset.source === 'yahoo') {
          data = await fetchYahoo(asset.symbol);
        } else if (asset.source === 'polygon') {
          data = await fetchPolygonCrypto(asset.symbol);
        }
        
        if (!data) {
          return {
            symbol: asset.displaySymbol,
            name: asset.name,
            category: asset.category,
            price: null,
            dailyChange: null,
            dailyChangePercent: null,
            weeklyChange: null,
            weeklyChangePercent: null,
            volume: '—',
            riskSentiment: 'Neutral',
            error: true,
          };
        }
        
        const riskSentiment = getRiskSentiment(asset, data.dailyChangePercent);
        
        return {
          symbol: asset.displaySymbol,
          name: asset.name,
          category: asset.category,
          price: data.price,
          dailyChange: data.dailyChange,
          dailyChangePercent: data.dailyChangePercent,
          weeklyChange: data.weeklyChange,
          weeklyChangePercent: data.weeklyChangePercent,
          volume: formatVolume(data.volume),
          riskSentiment,
        };
      })
    );
    
    // Check if we got valid data (at least 3 assets with prices)
    const validCount = results.filter(r => r.price !== null && !r.error).length;
    
    if (validCount >= 3) {
      // Good data - save to cache and return
      await saveToCache(results);
      
      res.json({
        timestamp: new Date().toISOString(),
        source: 'live',
        assets: results,
      });
    } else {
      // Market likely closed - try to load from cache
      console.log('[macro] Low valid data count, loading from cache...');
      const cached = await loadFromCache();
      
      if (cached && cached.length > 0) {
        // Merge: use live data where available, cached for the rest
        const merged = ASSETS.map(asset => {
          const live = results.find(r => r.symbol === asset.displaySymbol);
          const cache = cached.find(c => c.symbol === asset.displaySymbol);
          
          if (live && live.price !== null && !live.error) {
            return live;
          } else if (cache) {
            return cache;
          } else {
            return {
              symbol: asset.displaySymbol,
              name: asset.name,
              category: asset.category,
              price: null,
              dailyChange: null,
              dailyChangePercent: null,
              weeklyChange: null,
              weeklyChangePercent: null,
              volume: '—',
              riskSentiment: 'Neutral',
              error: true,
            };
          }
        });
        
        const cacheTime = cached[0]?.cachedAt;
        
        res.json({
          timestamp: new Date().toISOString(),
          source: 'cache',
          cachedAt: cacheTime,
          marketStatus: 'closed',
          assets: merged,
        });
      } else {
        // No cache available
        res.json({
          timestamp: new Date().toISOString(),
          source: 'live',
          marketStatus: 'closed',
          assets: results,
        });
      }
    }
  } catch (e) {
    console.error('[macro] snapshot error:', e);
    res.status(500).json({ error: 'macro_snapshot_error', message: e.message });
  }
});

// Force cache refresh endpoint
router.post('/macro/refresh-cache', async (req, res) => {
  try {
    const results = await Promise.all(
      ASSETS.map(async (asset) => {
        let data = null;
        
        if (asset.source === 'yahoo') {
          data = await fetchYahoo(asset.symbol);
        } else if (asset.source === 'polygon') {
          data = await fetchPolygonCrypto(asset.symbol);
        }
        
        if (!data) return null;
        
        return {
          symbol: asset.displaySymbol,
          name: asset.name,
          category: asset.category,
          price: data.price,
          dailyChange: data.dailyChange,
          dailyChangePercent: data.dailyChangePercent,
          weeklyChange: data.weeklyChange,
          weeklyChangePercent: data.weeklyChangePercent,
          volume: formatVolume(data.volume),
          riskSentiment: getRiskSentiment(asset, data.dailyChangePercent),
        };
      })
    );
    
    const valid = results.filter(r => r !== null);
    await saveToCache(valid);
    
    res.json({
      success: true,
      cached: valid.length,
      total: ASSETS.length,
    });
  } catch (e) {
    res.status(500).json({ error: 'cache_refresh_error', message: e.message });
  }
});

// Individual asset endpoint
router.get('/macro/asset/:symbol', async (req, res) => {
  const symbol = req.params.symbol?.toUpperCase();
  const asset = ASSETS.find(a => a.displaySymbol === symbol);
  
  if (!asset) {
    return res.status(404).json({ error: 'asset_not_found', symbol });
  }
  
  try {
    let data = null;
    
    if (asset.source === 'yahoo') {
      data = await fetchYahoo(asset.symbol);
    } else if (asset.source === 'polygon') {
      data = await fetchPolygonCrypto(asset.symbol);
    }
    
    if (!data) {
      // Try cache
      const cached = await loadFromCache();
      const cachedAsset = cached?.find(c => c.symbol === symbol);
      
      if (cachedAsset) {
        return res.json({ ...cachedAsset, source: 'cache' });
      }
      
      return res.status(404).json({ error: 'no_data', symbol });
    }
    
    res.json({
      symbol: asset.displaySymbol,
      name: asset.name,
      category: asset.category,
      price: data.price,
      dailyChange: data.dailyChange,
      dailyChangePercent: data.dailyChangePercent,
      weeklyChange: data.weeklyChange,
      weeklyChangePercent: data.weeklyChangePercent,
      volume: formatVolume(data.volume),
      riskSentiment: getRiskSentiment(asset, data.dailyChangePercent),
      source: 'live',
    });
  } catch (e) {
    res.status(500).json({ error: 'macro_asset_error', message: e.message });
  }
});

export default router;