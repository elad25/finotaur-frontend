// =====================================================
// NEWSLETTER CRON API ROUTES - v3.2.0 JS
// =====================================================
// Location: src/routes/newsletterCron.js
// =====================================================

import { Router } from 'express';
import { supabase, getUserFromToken, isUserAdmin } from '../lib/supabaseServer.js';
import {
  startNewsletterCron,
  stopNewsletterCron,
  getCronStatus,
  triggerNewsletterManually,
  getEligibleRecipients,
} from '../services/newsletterCron.js';

const router = Router();

// ============================================
// MIDDLEWARE: Require Admin
// ============================================

async function requireAdmin(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid authorization header' });
    }
    
    const token = authHeader.replace('Bearer ', '');
    const user = await getUserFromToken(token);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    
    const admin = await isUserAdmin(user.id);
    
    if (!admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    req.user = {
      id: user.id,
      email: user.email || '',
      role: 'admin',
    };
    
    next();
  } catch (error) {
    console.error('[AUTH] Error:', error);
    res.status(500).json({ error: 'Authentication error' });
  }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function maskEmail(email) {
  const [local, domain] = email.split('@');
  if (!domain) return email;
  const maskedLocal = local.substring(0, 2) + '***';
  return `${maskedLocal}@${domain}`;
}

// ============================================
// ROUTES
// ============================================

/**
 * GET /api/newsletter/cron/status
 */
router.get('/status', requireAdmin, async (req, res) => {
  try {
    const status = getCronStatus();
    res.json({ success: true, ...status });
  } catch (error) {
    console.error('[CRON] Status error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * POST /api/newsletter/cron/start
 */
router.post('/start', requireAdmin, async (req, res) => {
  try {
    startNewsletterCron();
    const status = getCronStatus();
    res.json({ success: true, message: 'Newsletter cron job started', ...status });
  } catch (error) {
    console.error('[CRON] Start error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * POST /api/newsletter/cron/stop
 */
router.post('/stop', requireAdmin, async (req, res) => {
  try {
    stopNewsletterCron();
    const status = getCronStatus();
    res.json({ success: true, message: 'Newsletter cron job stopped', ...status });
  } catch (error) {
    console.error('[CRON] Stop error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * POST /api/newsletter/cron/trigger
 */
router.post('/trigger', requireAdmin, async (req, res) => {
  try {
    console.log(`[CRON] Manual trigger by admin: ${req.user?.email}`);
    const result = await triggerNewsletterManually();
    res.json(result);
  } catch (error) {
    console.error('[CRON] Trigger error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * GET /api/newsletter/cron/recipients
 */
router.get('/recipients', requireAdmin, async (req, res) => {
  try {
    const recipients = await getEligibleRecipients();
    
    const maskedRecipients = recipients.slice(0, 50).map(r => ({
      id: r.id,
      email: maskEmail(r.email),
      display_name: r.display_name,
      source: r.source,
    }));
    
    const breakdown = {
      newsletter_subscriber: recipients.filter(r => r.source === 'newsletter_subscriber').length,
      premium_perk: recipients.filter(r => r.source === 'premium_perk').length,
      basic_perk: recipients.filter(r => r.source === 'basic_perk').length,
    };
    
    res.json({
      success: true,
      total: recipients.length,
      breakdown,
      preview: maskedRecipients,
      showing: Math.min(50, recipients.length),
    });
  } catch (error) {
    console.error('[CRON] Recipients error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * GET /api/newsletter/cron/logs
 */
router.get('/logs', requireAdmin, async (req, res) => {
  try {
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
    
    const { data: logs, error } = await supabase
      .from('newsletter_cron_logs')
      .select('*')
      .order('triggered_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    
    res.json({ success: true, logs: logs || [], count: logs?.length || 0 });
  } catch (error) {
    console.error('[CRON] Logs error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * POST /api/newsletter/generate-and-send
 */
router.post('/generate-and-send', requireAdmin, async (req, res) => {
  try {
    const { adminNote } = req.body;
    
    console.log(`[CRON] Generate-and-send by admin: ${req.user?.email}`);
    
    const edgeFunctionUrl = `${process.env.SUPABASE_URL}/functions/v1/newsletter-cron`;
    const cronSecret = process.env.CRON_SECRET;
    
    if (!cronSecret) {
      throw new Error('CRON_SECRET not configured');
    }
    
    const response = await fetch(`${edgeFunctionUrl}?secret=${cronSecret}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
      },
      body: JSON.stringify({
        trigger: 'admin_manual',
        adminId: req.user?.id,
        adminNote,
        timestamp: new Date().toISOString(),
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Edge Function failed: ${response.status} - ${errorText}`);
    }
    
    const result = await response.json();
    res.json(result);
  } catch (error) {
    console.error('[CRON] Generate-and-send error:', error);
    res.status(500).json({ success: false, error: error.message || 'Unknown error' });
  }
});

/**
 * GET /api/newsletter/cron/health (no auth)
 */
router.get('/health', (req, res) => {
  const status = getCronStatus();
  res.json({
    success: true,
    healthy: true,
    cronEnabled: status.enabled,
    timestamp: new Date().toISOString(),
  });
});

export default router;