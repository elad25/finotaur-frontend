// finotaur-server/src/routes/fundamentalsAll.ts
import { Router } from "express";
import type { Request, Response } from "express";
import { handleFundamentalsAll } from "./_fundamentals-normalized-shared";

export const fundamentalsAllRouter = Router();
fundamentalsAllRouter.get("/api/fundamentals/all", (req: Request, res: Response) => handleFundamentalsAll(req, res));
export default fundamentalsAllRouter;