// =====================================================
// ISM ROUTER - DYNAMIC FIRST v5.0
// =====================================================
// Location: src/routes/ismRouter.js
//
// 🚀 DYNAMIC FIRST - Uses ISMDataService as primary source
// With fallback to FALLBACK_ISM_DATA for reliability
//
// Data Flow Priority:
// 1. ISMDataService.fetchISMData() → Perplexity → ISM/TradingEconomics
// 2. FALLBACK_ISM_DATA (verified static data)
// 3. OpenAI (unverified)
// 4. FRED API (partial)
//
// v5.0 CHANGES:
// - ISMDataService is now PRIMARY source (not fallback)
// - FALLBACK_ISM_DATA kept as reliable backup
// - Quotes ALWAYS from ISMDataService TIER system
// - Better error handling and logging
// - Kept all v4.6 frontend compatibility
// =====================================================

import express from 'express';
import { generateISMReportPDFBuffer } from '../TopSecret/ISM/pdf-generator.js';
import OpenAI from 'openai';
import { ISMDataService } from '../TopSecret/ISM/data-service.js';

const router = express.Router();

// ============================================
// IN-MEMORY STORAGE & CACHE
// ============================================
const memoryStore = {
  reports: new Map(),
  progress: new Map(),
  ismDataCache: new Map(),  // Cache ISM data for 24 hours
  quotesCache: new Map(),   // Cache quotes for 6 hours
};

// Cache durations
const CACHE_DURATION_MS = 24 * 60 * 60 * 1000;        // 24 hours for PMI data
const QUOTES_CACHE_DURATION_MS = 6 * 60 * 60 * 1000;  // 6 hours for quotes

// ============================================
// OPENAI CLIENT
// ============================================
let openai = null;

function getOpenAIClient() {
  if (!openai) {
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (apiKey) {
      try {
        openai = new OpenAI({ apiKey });
        console.log('[ISM Router] ✅ OpenAI client initialized');
      } catch (error) {
        console.error('[ISM Router] ❌ Failed to initialize OpenAI:', error.message);
      }
    } else {
      console.log('[ISM Router] ⚠️ OPENAI_API_KEY not found in environment');
    }
  }
  return openai;
}

// Initialize on load
getOpenAIClient();

// ============================================
// ISM DATA SERVICE INSTANCE
// ============================================
let ismDataService = null;

function getISMDataService() {
  if (!ismDataService) {
    const perplexityKey = process.env.PERPLEXITY_API_KEY;
    const openaiKey = process.env.OPENAI_API_KEY;
    
    if (!perplexityKey) {
      console.warn('[ISM Router] ⚠️ PERPLEXITY_API_KEY not configured - dynamic quotes disabled');
      return null;
    }
    
    try {
      ismDataService = new ISMDataService(null, {
        perplexityApiKey: perplexityKey,
        openaiApiKey: openaiKey,
      });
      console.log('[ISM Router] ✅ ISMDataService initialized');
    } catch (error) {
      console.error('[ISM Router] ❌ Failed to initialize ISMDataService:', error.message);
      return null;
    }
  }
  return ismDataService;
}

// Initialize on load
getISMDataService();

// ============================================
// CONFIGURATION
// ============================================
const PHASES = {
  DATA_ACQUISITION: { order: 1, name: 'Data Acquisition', color: '#3B82F6' },
  MACRO_ANALYSIS: { order: 2, name: 'Macro Analysis', color: '#8B5CF6' },
  TREND_ANALYSIS: { order: 3, name: 'Trend Analysis', color: '#06B6D4' },
  SECTOR_ANALYSIS: { order: 4, name: 'Sector Analysis', color: '#C9A646' },
  EQUITY_ANALYSIS: { order: 5, name: 'Equity Analysis', color: '#F97316' },
  TRADE_SYNTHESIS: { order: 6, name: 'Trade Synthesis', color: '#EC4899' },
  QUALITY_ASSURANCE: { order: 7, name: 'Quality Assurance', color: '#10B981' },
};

const AGENTS = [
  { id: 'ism_data_fetcher', name: 'ISM Data Fetcher', phase: 'DATA_ACQUISITION', order: 1 },
  { id: 'quote_fetcher', name: 'Perplexity Quote Fetcher', phase: 'DATA_ACQUISITION', order: 2 },
  { id: 'historical_context_builder', name: 'Historical Context Builder', phase: 'DATA_ACQUISITION', order: 3 },
  { id: 'macro_regime_detector', name: 'Macro Regime Detector', phase: 'MACRO_ANALYSIS', order: 4 },
  { id: 'critical_gap_analyzer', name: 'Critical Gap Analyzer', phase: 'MACRO_ANALYSIS', order: 5 },
  { id: 'narrative_architect', name: 'Narrative Architect', phase: 'MACRO_ANALYSIS', order: 6 },
  { id: 'persistent_trend_scanner', name: 'Persistent Trend Scanner', phase: 'TREND_ANALYSIS', order: 7 },
  { id: 'structural_pressure_mapper', name: 'Structural Pressure Mapper', phase: 'TREND_ANALYSIS', order: 8 },
  { id: 'sector_impact_scorer', name: 'Sector Impact Scorer', phase: 'SECTOR_ANALYSIS', order: 9 },
  { id: 'respondent_quote_extractor', name: 'Respondent Quote Extractor', phase: 'SECTOR_ANALYSIS', order: 10 },
  { id: 'equity_criteria_builder', name: 'Equity Criteria Builder', phase: 'EQUITY_ANALYSIS', order: 11 },
  { id: 'trade_idea_generator', name: 'Trade Idea Generator', phase: 'TRADE_SYNTHESIS', order: 12 },
  { id: 'coherence_checker', name: 'Coherence Checker', phase: 'QUALITY_ASSURANCE', order: 13 },
  { id: 'executive_summary_writer', name: 'Executive Summary Writer', phase: 'QUALITY_ASSURANCE', order: 14 },
];

// ============================================
// HELPER FUNCTIONS
// ============================================

function getCurrentDataMonth() {
  const now = new Date();
  const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${prevMonth.getFullYear()}-${String(prevMonth.getMonth() + 1).padStart(2, '0')}`;
}

function formatMonthDisplay(monthStr) {
  const [year, month] = monthStr.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

function generateId() {
  return `ism_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function getMonthName(monthStr) {
  const [year, month] = monthStr.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

function getISMReportURL(month) {
  const [year, monthNum] = month.split('-');
  const monthNames = ['', 'january', 'february', 'march', 'april', 'may', 'june', 
                      'july', 'august', 'september', 'october', 'november', 'december'];
  const monthName = monthNames[parseInt(monthNum)];
  return `https://www.ismworld.org/supply-management-news-and-reports/reports/ism-report-on-business/pmi/${monthName}/`;
}

function getExpectedReleaseDate(month) {
  const [year, mon] = month.split('-');
  const releaseMonth = parseInt(mon);
  const releaseYear = releaseMonth === 12 ? parseInt(year) + 1 : parseInt(year);
  const nextMonth = releaseMonth === 12 ? 1 : releaseMonth + 1;
  return `${releaseYear}-${String(nextMonth).padStart(2, '0')}-01`;
}

// JSON extraction helper
function extractJSON(content) {
  if (!content) return null;
  
  try {
    return JSON.parse(content);
  } catch (e) {
    // Try to extract from markdown code block
    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1].trim());
      } catch (e2) {}
    }
    
    // Try to find array in content
    const arrayMatch = content.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      try {
        return JSON.parse(arrayMatch[0]);
      } catch (e3) {}
    }
    
    return null;
  }
}

// ============================================
// FALLBACK ISM DATA - Verified Static Data
// Used when ISMDataService fails
// ============================================

const FALLBACK_ISM_DATA = {
  // ═══════════════════════════════════════════════════════════════
  // November 2025 - Released December 1, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-11': {
    pmi: 48.2,
    previousPmi: 48.7,
    newOrders: 47.4,
    production: 51.4,
    employment: 44.0,
    supplierDeliveries: 49.3,
    inventories: 48.9,
    prices: 58.5,
    backlog: 44.0,
    newExportOrders: 47.0,
    imports: 46.6,
    customersInventories: 'too_low',
    releaseDate: '2025-12-01',
    contractionMonths: 9,
    employmentContractionMonths: 10,
    backlogContractionMonths: 38,
    pricesElevatedMonths: 14,
    newOrdersContractionMonths: 8,
    keyHighlights: [
      '9th consecutive month of manufacturing contraction',
      'Employment at lowest level since July 2020',
      'Prices elevated despite weak demand - stagflation signal',
      'Production/Orders divergence indicates inventory drawdown',
    ],
    notes: '9th consecutive month of contraction. Employment at lowest since July 2020. STAGFLATION WARNING: Prices 58.5 while PMI 48.2.',
  },
  
  // ═══════════════════════════════════════════════════════════════
  // October 2025 - Released November 1, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-10': {
    pmi: 48.7, 
    previousPmi: 49.1, 
    newOrders: 49.4, 
    production: 48.2, 
    employment: 46.0,
    supplierDeliveries: 54.2, 
    inventories: 45.8, 
    prices: 58.0, 
    backlog: 47.9,
    newExportOrders: 47.3, 
    imports: 48.0, 
    customersInventories: 'too_low',
    releaseDate: '2025-11-01',
    contractionMonths: 8,
    employmentContractionMonths: 9,
    backlogContractionMonths: 37,
    pricesElevatedMonths: 13,
    keyHighlights: ['8th month of contraction', 'Employment weak but improving from September'],
  },
  
  // ═══════════════════════════════════════════════════════════════
  // September 2025 - Released October 1, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-09': {
    pmi: 49.1, 
    previousPmi: 48.7, 
    newOrders: 48.9, 
    production: 51.0, 
    employment: 45.3,
    supplierDeliveries: 52.6, 
    inventories: 47.7, 
    prices: 61.9, 
    backlog: 46.2,
    newExportOrders: 48.0, 
    imports: 48.4, 
    customersInventories: 'too_low',
    releaseDate: '2025-10-01',
    contractionMonths: 7,
    employmentContractionMonths: 8,
    backlogContractionMonths: 36,
    pricesElevatedMonths: 12,
    keyHighlights: ['Prices spiking to 61.9 - highest in 6 months', 'Production recovering but orders still weak'],
  },
  
  // ═══════════════════════════════════════════════════════════════
  // August 2025 - Released September 2, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-08': {
    pmi: 48.7, 
    previousPmi: 48.0, 
    newOrders: 51.4, 
    production: 47.8, 
    employment: 43.8,
    supplierDeliveries: 50.5, 
    inventories: 47.0, 
    prices: 63.7, 
    backlog: 44.7,
    newExportOrders: 48.3, 
    imports: 47.5, 
    customersInventories: 'too_low',
    releaseDate: '2025-09-02',
    contractionMonths: 6,
    employmentContractionMonths: 7,
    backlogContractionMonths: 35,
    pricesElevatedMonths: 11,
    keyHighlights: ['New Orders finally above 50!', 'But Prices at 63.7 crushing margins'],
  },
  
  // ═══════════════════════════════════════════════════════════════
  // July 2025 - Released August 1, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-07': {
    pmi: 48.0, 
    previousPmi: 48.8, 
    newOrders: 49.3, 
    production: 49.5, 
    employment: 43.9,
    supplierDeliveries: 48.6, 
    inventories: 44.0, 
    prices: 57.0, 
    backlog: 42.8,
    newExportOrders: 46.4, 
    imports: 46.8, 
    customersInventories: 'too_low',
    releaseDate: '2025-08-01',
    contractionMonths: 5,
    employmentContractionMonths: 6,
    backlogContractionMonths: 34,
    pricesElevatedMonths: 10,
    keyHighlights: ['Backlog hits 42.8 - very weak visibility', 'Employment cuts accelerating'],
  },
  
  // ═══════════════════════════════════════════════════════════════
  // June 2025 - Released July 1, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-06': {
    pmi: 48.8, 
    previousPmi: 49.2, 
    newOrders: 47.8, 
    production: 50.2, 
    employment: 44.5,
    supplierDeliveries: 49.8, 
    inventories: 46.5, 
    prices: 56.2, 
    backlog: 43.5,
    newExportOrders: 47.8, 
    imports: 47.2, 
    customersInventories: 'too_low',
    releaseDate: '2025-07-01',
    contractionMonths: 4,
    employmentContractionMonths: 5,
    backlogContractionMonths: 33,
    pricesElevatedMonths: 9,
  },
  
  // ═══════════════════════════════════════════════════════════════
  // May 2025 - Released June 2, 2025
  // ═══════════════════════════════════════════════════════════════
  '2025-05': {
    pmi: 49.2, 
    previousPmi: 49.5, 
    newOrders: 48.5, 
    production: 51.5, 
    employment: 45.8,
    supplierDeliveries: 50.2, 
    inventories: 47.8, 
    prices: 55.8, 
    backlog: 44.2,
    newExportOrders: 48.5, 
    imports: 48.0, 
    customersInventories: 'about_right',
    releaseDate: '2025-06-02',
    contractionMonths: 3,
    employmentContractionMonths: 4,
    backlogContractionMonths: 32,
    pricesElevatedMonths: 8,
  },
};

// ============================================
// 🔥 QUOTES FETCHER - Using ISMDataService TIER System
// ============================================
async function fetchQuotesFromPerplexity(month) {
  console.log(`\n[ISM Router Quotes] ========================================`);
  console.log(`[ISM Router Quotes] 🔍 Fetching REAL quotes for ${getMonthName(month)}`);
  console.log(`[ISM Router Quotes] Using ISMDataService TIER system`);
  console.log(`[ISM Router Quotes] ========================================\n`);
  
  // Check quotes cache first
  const cached = memoryStore.quotesCache.get(month);
  if (cached && (Date.now() - cached.timestamp < QUOTES_CACHE_DURATION_MS)) {
    console.log(`[ISM Router Quotes] ✅ Using cached quotes (${cached.quotes.length} quotes)`);
    return cached.quotes;
  }
  
  try {
    const service = getISMDataService();
    if (!service) {
      console.warn('[ISM Router Quotes] ⚠️ ISMDataService not available');
      return [];
    }
    
    // Use the TIER system from data-service.js
    const quotes = await service.fetchIndustryQuotes(month);
    
    if (quotes && quotes.length > 0) {
      // Cache successful quotes
      memoryStore.quotesCache.set(month, {
        quotes,
        timestamp: Date.now(),
      });
      
      console.log(`[ISM Router Quotes] ✅ Got ${quotes.length} REAL quotes via TIER system`);
      
      // Convert to expected format
      return quotes.map(q => ({
        industry: q.industry,
        comment: q.comment || q.quote,
        sentiment: q.sentiment || 'neutral',
        keyTheme: q.keyTheme || 'general',
        source: q.source,
        isVerified: q.isVerified !== false,
      }));
    }
    
    console.warn(`[ISM Router Quotes] ⚠️ No quotes returned from TIER system`);
    return [];
    
  } catch (error) {
    console.error(`[ISM Router Quotes] ❌ Error: ${error.message}`);
    return [];
  }
}

// ============================================
// 🚀 ISMDataService FETCHER (PRIMARY)
// ============================================

async function fetchISMDataFromService(month) {
  const service = getISMDataService();
  
  if (!service) {
    console.log('[ISM Router] ⚠️ ISMDataService not available');
    return null;
  }
  
  console.log(`[ISM Router] 🔍 Fetching ISM data via ISMDataService for ${month}...`);
  
  try {
    const rawData = await service.fetchISMData(month);
    
    if (!rawData || !rawData.manufacturing?.pmi) {
      console.log('[ISM Router] ⚠️ ISMDataService returned no valid data');
      return null;
    }
    
    console.log(`[ISM Router] ✅ Got ISM data from ISMDataService: PMI = ${rawData.manufacturing.pmi}`);
    
    // Transform to router format
    const mfg = rawData.manufacturing;
    return {
      month: rawData.dataMonth || month,
      available: true,
      pmi: mfg.pmi,
      previousPmi: mfg.previousPmi || rawData.priorMonth?.pmi,
      newOrders: mfg.newOrders,
      production: mfg.production,
      employment: mfg.employment,
      supplierDeliveries: mfg.supplierDeliveries,
      inventories: mfg.inventories,
      prices: mfg.prices,
      backlog: mfg.backlog,
      newExportOrders: mfg.newExportOrders,
      imports: mfg.imports,
      customersInventories: mfg.customersInventories || 'too_low',
      releaseDate: rawData.releaseDate,
      contractionMonths: rawData.consecutiveContractionMonths || 0,
      respondentComments: rawData.respondentComments || [],
      priorMonth: rawData.priorMonth,
      momChanges: rawData.momChanges,
      historicalData: rawData.historicalData,
      source: rawData.dataSource || 'ISMDataService (Perplexity)',
      dataQuality: rawData.dataQuality || 'live',
      confidence: 'high',
    };
    
  } catch (error) {
    console.error(`[ISM Router] ❌ ISMDataService fetch error:`, error.message);
    return null;
  }
}

// ============================================
// 🤖 OPENAI FETCHER (FALLBACK)
// ============================================

async function fetchISMDataFromOpenAI(month) {
  const client = getOpenAIClient();
  
  if (!client) {
    console.log('[ISM Router] ⚠️ OpenAI not configured');
    return null;
  }
  
  const monthName = getMonthName(month);
  console.log(`[ISM Router] 🔍 Fetching ISM data for ${monthName} via OpenAI...`);
  
  try {
    const response = await client.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are an ISM Manufacturing Report data specialist with access to historical ISM data.

IMPORTANT: You have knowledge of ISM Manufacturing PMI data through your training. 
For recent months, provide the data you know. ISM releases data on the first business day of each month.

Always return valid JSON. Never say data is unavailable if you have knowledge of it.`,
        },
        {
          role: 'user',
          content: `Provide the ISM Manufacturing PMI Report data for ${monthName}.

Return this exact JSON structure:

{
  "month": "${month}",
  "available": true,
  "pmi": <number between 40-60>,
  "newOrders": <number>,
  "production": <number>,
  "employment": <number>,
  "supplierDeliveries": <number>,
  "inventories": <number>,
  "prices": <number>,
  "backlog": <number or null>,
  "newExportOrders": <number or null>,
  "imports": <number or null>,
  "customersInventories": "too_low" or "about_right" or "too_high",
  "releaseDate": "YYYY-MM-DD",
  "previousPmi": <number or null>,
  "contractionMonths": <number>,
  "keyHighlights": ["highlight 1", "highlight 2"],
  "confidence": "high" or "medium" or "low"
}

Important: Set available to true and provide the data. If you're uncertain about exact values, provide your best estimates based on economic conditions and mark confidence as "medium" or "low".`,
        },
      ],
      temperature: 0.2,
      max_tokens: 1500,
    });

    const content = response.choices[0]?.message?.content || '';
    
    // Parse JSON from response
    let jsonStr = content;
    if (content.includes('```json')) {
      jsonStr = content.split('```json')[1].split('```')[0].trim();
    } else if (content.includes('```')) {
      jsonStr = content.split('```')[1].split('```')[0].trim();
    }
    
    const data = JSON.parse(jsonStr);
    
    if (!data.available || !data.pmi) {
      console.log(`[ISM Router] ⚠️ OpenAI couldn't provide data`);
      return null;
    }
    
    console.log(`[ISM Router] ✅ Got ISM data from OpenAI: PMI = ${data.pmi}`);
    return data;
    
  } catch (error) {
    console.error(`[ISM Router] ❌ OpenAI fetch error:`, error.message);
    return null;
  }
}

// ============================================
// 📊 FRED API FETCHER (FALLBACK)
// ============================================

async function fetchISMDataFromFRED(month) {
  const fredApiKey = process.env.FRED_API_KEY;
  
  if (!fredApiKey) {
    console.log('[ISM Router] ⚠️ FRED API not configured');
    return null;
  }
  
  const [year, monthNum] = month.split('-').map(Number);
  const startDate = `${year}-${String(monthNum).padStart(2, '0')}-01`;
  const endDate = new Date(year, monthNum, 0).toISOString().split('T')[0];
  
  try {
    const url = `https://api.stlouisfed.org/fred/series/observations?series_id=NAPM&api_key=${fredApiKey}&file_type=json&observation_start=${startDate}&observation_end=${endDate}`;
    
    const response = await fetch(url, { timeout: 10000 });
    
    if (!response.ok) {
      console.error('[ISM Router] FRED API error:', response.status);
      return null;
    }
    
    const data = await response.json();
    
    if (!data.observations?.length) {
      console.log('[ISM Router] No FRED data for this period');
      return null;
    }
    
    const latestObs = data.observations[data.observations.length - 1];
    const pmi = parseFloat(latestObs.value);
    
    if (isNaN(pmi)) {
      return null;
    }
    
    console.log(`[ISM Router] ✅ Got FRED data: PMI = ${pmi}`);
    
    return {
      month,
      available: true,
      pmi,
      source: 'FRED API',
      partial: true,
      releaseDate: latestObs.date,
    };
    
  } catch (error) {
    console.error('[ISM Router] FRED fetch error:', error.message);
    return null;
  }
}

// ============================================
// 🎯 MAIN DATA FETCHER - DYNAMIC FIRST!
// ============================================
// Priority:
// 1. ISMDataService (dynamic, includes quotes)
// 2. FALLBACK_ISM_DATA (verified static)
// 3. OpenAI (unverified)
// 4. FRED (partial)
// ============================================

async function getISMData(month) {
  console.log(`\n[ISM Router] ========================================`);
  console.log(`[ISM Router] 🔍 Getting ISM data for ${month}`);
  console.log(`[ISM Router] Priority: ISMDataService → Fallback → OpenAI → FRED`);
  console.log(`[ISM Router] ========================================\n`);
  
  // Check cache first
  const cached = memoryStore.ismDataCache.get(month);
  if (cached && (Date.now() - cached.timestamp < CACHE_DURATION_MS)) {
    const quotesAge = Date.now() - (cached.quotesTimestamp || 0);
    if (quotesAge < QUOTES_CACHE_DURATION_MS && cached.data.respondentComments?.length > 0) {
      console.log(`[ISM Router] ✅ Using cached data with ${cached.data.respondentComments.length} quotes`);
      return cached.data;
    }
    console.log(`[ISM Router] ℹ️ PMI cached, refreshing quotes...`);
  }
  
  let ismData = null;
  let dataSource = 'unknown';
  let quotesFromService = [];
  
  // ⭐ PRIORITY 1: Try ISMDataService (DYNAMIC!)
  console.log(`[ISM Router] 🔍 Trying ISMDataService (dynamic)...`);
  try {
    const serviceData = await fetchISMDataFromService(month);
    if (serviceData && serviceData.pmi) {
      ismData = serviceData;
      dataSource = 'ISMDataService (Perplexity)';
      quotesFromService = serviceData.respondentComments || [];
      console.log(`[ISM Router] ✅ Got DYNAMIC data: PMI = ${ismData.pmi}, Quotes = ${quotesFromService.length}`);
    }
  } catch (error) {
    console.warn(`[ISM Router] ⚠️ ISMDataService failed: ${error.message}`);
  }
  
  // ⭐ PRIORITY 2: Try FALLBACK_ISM_DATA (verified static)
  if (!ismData && FALLBACK_ISM_DATA[month]) {
    console.log(`[ISM Router] 📋 Using verified FALLBACK_ISM_DATA for ${month}`);
    ismData = { ...FALLBACK_ISM_DATA[month] };
    ismData.month = month;
    ismData.available = true;
    dataSource = 'ISM Official Data (Verified)';
  }
  
  // ⭐ PRIORITY 3: Try OpenAI (unverified)
  if (!ismData) {
    console.log(`[ISM Router] 🤖 Trying OpenAI...`);
    try {
      ismData = await fetchISMDataFromOpenAI(month);
      if (ismData) {
        dataSource = 'OpenAI (Unverified)';
        console.log(`[ISM Router] ⚠️ Using OpenAI data - may not be accurate!`);
      }
    } catch (error) {
      console.warn(`[ISM Router] OpenAI failed: ${error.message}`);
    }
  }
  
  // ⭐ PRIORITY 4: Try FRED (partial)
  if (!ismData) {
    console.log(`[ISM Router] 📊 Trying FRED API...`);
    try {
      ismData = await fetchISMDataFromFRED(month);
      if (ismData) {
        dataSource = 'FRED API (Partial)';
      }
    } catch (error) {
      console.warn(`[ISM Router] FRED failed: ${error.message}`);
    }
  }
  
  // ⭐ PRIORITY 5: Use latest available as last resort
  if (!ismData) {
    const fallbackMonths = Object.keys(FALLBACK_ISM_DATA).sort().reverse();
    if (fallbackMonths.length > 0) {
      const latestMonth = fallbackMonths[0];
      console.warn(`[ISM Router] ⚠️ No data for ${month}, using latest: ${latestMonth}`);
      ismData = { ...FALLBACK_ISM_DATA[latestMonth] };
      ismData.month = latestMonth;
      ismData.available = true;
      ismData.requestedMonth = month;
      ismData.warning = `Data for ${month} not available. Showing ${latestMonth} data.`;
      dataSource = `ISM Official Data (${latestMonth})`;
    }
  }
  
  if (!ismData) {
    throw new Error(`Unable to fetch ISM data for ${month}. No data sources available.`);
  }
  
  // ⭐ QUOTES: Use quotes from ISMDataService, or fetch separately
  let quotes = quotesFromService;
  if (quotes.length === 0 && dataSource !== 'ISMDataService (Perplexity)') {
    console.log(`[ISM Router] 🔍 Fetching quotes separately via ISMDataService...`);
    quotes = await fetchQuotesFromPerplexity(month);
  }
  
  // Enrich with computed fields
  const isContraction = ismData.pmi < 50;
  
  const enrichedData = {
    month: ismData.month || month,
    pmi: ismData.pmi,
    previousPmi: ismData.previousPmi || null,
    newOrders: ismData.newOrders || null,
    production: ismData.production || null,
    employment: ismData.employment || null,
    supplierDeliveries: ismData.supplierDeliveries || null,
    inventories: ismData.inventories || null,
    prices: ismData.prices || null,
    backlog: ismData.backlog || null,
    newExportOrders: ismData.newExportOrders || null,
    imports: ismData.imports || null,
    customersInventories: ismData.customersInventories || 'too_low',
    releaseDate: ismData.releaseDate,
    direction: isContraction ? 'contraction' : 'expansion',
    isContraction,
    contractionMonths: ismData.contractionMonths || 0,
    employmentContractionMonths: ismData.employmentContractionMonths || 0,
    backlogContractionMonths: ismData.backlogContractionMonths || 0,
    pricesElevatedMonths: ismData.pricesElevatedMonths || 0,
    dataSource,
    dataQuality: dataSource.includes('Verified') || dataSource.includes('ISMDataService') ? 'official' : 'estimated',
    notes: ismData.keyHighlights?.join('. ') || ismData.notes || ismData.warning || null,
    respondentComments: quotes || [],
    priorMonth: ismData.priorMonth || null,
    momChanges: ismData.momChanges || null,
    confidence: dataSource.includes('Verified') || dataSource.includes('ISMDataService') ? 'high' : 'medium',
    generatedAt: new Date().toISOString(),
    warning: ismData.warning,
  };
  
  // Cache with separate quotes timestamp
  memoryStore.ismDataCache.set(month, {
    data: enrichedData,
    timestamp: Date.now(),
    quotesTimestamp: quotes?.length > 0 ? Date.now() : 0,
  });
  
  console.log(`\n[ISM Router] ========================================`);
  console.log(`[ISM Router] ✅ Data ready from ${dataSource}`);
  console.log(`[ISM Router] 📊 PMI: ${enrichedData.pmi}, Direction: ${enrichedData.direction}`);
  console.log(`[ISM Router] 💬 Quotes: ${enrichedData.respondentComments?.length || 0}`);
  console.log(`[ISM Router] ========================================\n`);
  
  return enrichedData;
}

// ============================================
// REGIME DETECTION
// ============================================

function detectRegime(ismData) {
  const { pmi, prices, newOrders, employment, production } = ismData;
  const isContraction = pmi < 50;
  const isPricesElevated = (prices || 50) > 55;
  const isEmploymentWeak = (employment || 50) < 48;
  const isOrdersWeak = (newOrders || 50) < 48;
  
  if (isContraction && isPricesElevated) {
    return {
      name: 'Stagflation Risk',
      description: 'Costs rising while activity contracts - worst environment for margins',
      riskLevel: 'elevated',
      direction: 'deteriorating',
    };
  } else if (isContraction && isOrdersWeak && (newOrders || 50) < pmi) {
    return {
      name: 'Contraction Deepening',
      description: 'New orders falling faster than production - more pain ahead',
      riskLevel: 'high',
      direction: 'deteriorating',
    };
  } else if (isContraction && (newOrders || 50) > pmi) {
    return {
      name: 'Contraction Recovering',
      description: 'Orders stabilizing - watch for PMI inflection',
      riskLevel: 'moderate',
      direction: 'stabilizing',
    };
  } else if (!isContraction && pmi > 52 && (newOrders || 50) > 52) {
    return {
      name: 'Expansion Accelerating',
      description: 'Broad strength across components - risk-on environment',
      riskLevel: 'low',
      direction: 'improving',
    };
  } else if (!isContraction && ((newOrders || 50) < pmi || isEmploymentWeak)) {
    return {
      name: 'Late Cycle Weakness',
      description: 'Expansion intact but momentum fading - be selective',
      riskLevel: 'moderate',
      direction: 'mixed',
    };
  } else {
    return {
      name: 'Expansion Decelerating',
      description: 'Growth continues but pace moderating',
      riskLevel: 'moderate',
      direction: 'mixed',
    };
  }
}

// ============================================
// CRITICAL GAPS ANALYSIS
// ============================================

function analyzeCriticalGaps(ismData) {
  const gaps = [];
  const { pmi, newOrders, production, employment, prices, backlog, customersInventories } = ismData;
  
  // Production vs New Orders divergence
  if (production && newOrders) {
    const gap = production - newOrders;
    if (gap > 2) {
      gaps.push({
        type: 'Production Outpacing Orders',
        icon: '🚨',
        severity: gap > 4 ? 'high' : 'moderate',
        description: `Production at ${production} while New Orders at ${newOrders}. Companies are producing more than they're selling - inventory buildup risk.`,
        whyItMatters: 'Inventory builds lead to future production cuts and margin pressure',
        investorAction: 'Underweight inventory-heavy industrials, favor lean operators',
        tradingSignal: 'Potential SHORT setup in high-inventory industrial names',
      });
    } else if (gap < -2) {
      gaps.push({
        type: 'Orders Outpacing Production',
        icon: '📈',
        severity: Math.abs(gap) > 4 ? 'high' : 'moderate',
        description: `New Orders at ${newOrders} exceeding Production at ${production}. Demand exceeds supply capacity - pricing power opportunity.`,
        whyItMatters: 'Supply constraints support pricing power and select industrial stocks',
        investorAction: 'Favor companies with pricing power and capacity constraints',
        tradingSignal: 'LONG opportunity in capacity-constrained industrials',
      });
    }
  }
  
  // Stagflation warning
  if (pmi < 50 && (prices || 50) > 55) {
    gaps.push({
      type: 'Stagflation Warning',
      icon: '🚨',
      severity: 'high',
      description: `Prices elevated at ${prices} while PMI contracts at ${pmi}. This is the worst combination: falling demand with rising costs.`,
      whyItMatters: 'Stagflation crushes margins - companies cannot pass costs to shrinking demand',
      investorAction: 'Defensive positioning. Favor pricing power + inelastic demand',
      tradingSignal: 'SHORT high-cost, low-pricing-power manufacturers',
    });
  }
  
  // Employment weakness
  if (employment && employment < 47) {
    gaps.push({
      type: 'Employment Contraction Signal',
      icon: '🚨',
      severity: employment < 45 ? 'high' : 'moderate',
      description: `Employment at ${employment} signals companies are cutting workforce to protect margins. This is a late-cycle defensive move.`,
      whyItMatters: 'Employment cuts lag economic weakness by 3-6 months. More pain ahead.',
      investorAction: 'Reduce cyclical exposure, increase defensive allocation',
      tradingSignal: 'Favor companies with lean operations already',
    });
  }
  
  // Backlog depletion
  if (backlog && backlog < 46) {
    gaps.push({
      type: 'Backlog Depletion',
      icon: '🚨',
      severity: backlog < 44 ? 'high' : 'moderate',
      description: `Backlog at ${backlog} indicates order pipeline is drying up. Poor forward visibility for 2-3 quarters.`,
      whyItMatters: 'Low backlog = weak earnings visibility = multiple compression risk',
      investorAction: 'Avoid companies with short order-to-delivery cycles',
      tradingSignal: 'Be cautious on industrials without strong backlog metrics',
    });
  }
  
  // Restocking potential
  if (customersInventories === 'too_low') {
    gaps.push({
      type: 'Restocking Potential',
      icon: '📈',
      severity: 'moderate',
      description: `Customer inventories reported as "too low" - potential restocking cycle ahead.`,
      whyItMatters: 'Restocking cycles can drive 1-2 quarters of demand even in weak economy',
      investorAction: 'Watch for restocking-sensitive materials and industrials',
      tradingSignal: 'LONG materials (XLB) on inventory normalization thesis',
    });
  }
  
  return gaps;
}

// ============================================
// TIME HORIZONS
// ============================================

function generateTimeHorizons(ismData, regime) {
  const { pmi, prices } = ismData;
  const isContraction = pmi < 50;
  const isPricesElevated = (prices || 50) > 55;
  
  return {
    shortTerm: {
      period: '1-4 weeks',
      outlook: isContraction 
        ? 'Expect continued volatility. PMI below 50 creates headline risk. Trade defensively.'
        : 'Expansion supports risk-on but monitor momentum indicators.',
    },
    mediumTerm: {
      period: '1-3 months',
      outlook: isPricesElevated
        ? 'Margin pressure from elevated costs. Extreme selectivity required - favor pricing power.'
        : 'Cost environment manageable. Focus on revenue growth and market share.',
    },
    longTerm: {
      period: '3-12 months',
      outlook: isContraction
        ? 'Cycle late-stage. Clear winners vs losers will emerge. Avoid leverage, favor free cash flow.'
        : 'Expansion supports cyclical exposure but be prepared for rotation.',
    },
  };
}

// ============================================
// PERSISTENT TRENDS
// ============================================

function analyzeTrends(ismData) {
  const { 
    pmi, prices, employment, backlog, 
    contractionMonths, employmentContractionMonths, 
    backlogContractionMonths, pricesElevatedMonths 
  } = ismData;
  
  const trends = [];
  
  if (pmi < 50) {
    trends.push({
      indicator: 'PMI',
      direction: 'contracting',
      duration: `${contractionMonths || 1} consecutive months`,
      months: contractionMonths || 1,
      strength: (contractionMonths || 0) > 6 ? 'Persistent' : 'Moderate',
      currentValue: pmi,
      threshold: 50,
      implication: `Manufacturing recession ${contractionMonths > 6 ? 'entrenched' : 'continuing'} - underweight cyclicals`,
      severityScore: Math.min(10, (contractionMonths || 1) + (50 - pmi)),
    });
  } else {
    trends.push({
      indicator: 'PMI',
      direction: 'expanding',
      duration: 'ongoing',
      months: 0,
      strength: pmi > 52 ? 'Strong' : 'Moderate',
      currentValue: pmi,
      threshold: 50,
      implication: 'Expansion supports cyclical exposure',
      severityScore: 0,
    });
  }
  
  if ((employment || 50) < 48) {
    const empMonths = employmentContractionMonths || Math.round((50 - (employment || 50)) * 2);
    trends.push({
      indicator: 'Employment',
      direction: 'contracting',
      duration: `${empMonths} consecutive months`,
      months: empMonths,
      strength: empMonths > 8 ? 'Severe' : empMonths > 4 ? 'Persistent' : 'Moderate',
      currentValue: employment,
      threshold: 48,
      implication: `Labor cuts ${empMonths > 6 ? 'accelerating' : 'underway'} - margin protection mode, avoid labor-intensive`,
      severityScore: Math.min(10, empMonths + (48 - (employment || 50))),
    });
  }
  
  if (backlog && backlog < 47) {
    const backlogMonths = backlogContractionMonths || 12;
    trends.push({
      indicator: 'Backlog',
      direction: 'depleting',
      duration: `${backlogMonths} consecutive months`,
      months: backlogMonths,
      strength: backlogMonths > 24 ? 'Structural' : backlogMonths > 12 ? 'Severe' : 'Persistent',
      currentValue: backlog,
      threshold: 47,
      implication: `Order visibility ${backlogMonths > 24 ? 'structurally impaired' : 'very weak'} - earnings risk elevated for industrials`,
      severityScore: Math.min(10, Math.round(backlogMonths / 4) + (47 - backlog)),
    });
  }
  
  if ((prices || 50) > 55) {
    const priceMonths = pricesElevatedMonths || 6;
    trends.push({
      indicator: 'Prices',
      direction: 'elevated',
      duration: `${priceMonths} consecutive months above 55`,
      months: priceMonths,
      strength: priceMonths > 12 ? 'Sticky' : priceMonths > 6 ? 'Persistent' : 'Elevated',
      currentValue: prices,
      threshold: 55,
      implication: `Input cost inflation ${priceMonths > 12 ? 'entrenched' : 'persistent'} - pricing power critical for survival`,
      severityScore: Math.min(10, Math.round(priceMonths / 2) + ((prices || 50) - 55) / 2),
    });
  }
  
  return trends;
}

// ============================================
// STRUCTURAL PRESSURES
// ============================================

function analyzeStructuralPressures(ismData) {
  const { prices, employment } = ismData;
  
  return [
    {
      type: 'Tariff Uncertainty',
      level: 'Elevated',
      source: 'Trade policy changes affecting supply chain decisions',
      impact: 'Companies delaying CapEx, shortening supply chains',
      duration: 'Multi-year structural shift',
    },
    {
      type: 'Labor Market',
      level: (employment || 50) < 48 ? 'Contracting' : 'Stable',
      source: (employment || 50) < 48 ? 'Companies cutting to protect margins' : 'Balanced labor conditions',
      impact: (employment || 50) < 48 ? 'Operational efficiency focus' : 'Wage growth moderating',
      duration: '6-12 months',
    },
    {
      type: 'Input Costs',
      level: (prices || 50) > 55 ? 'Elevated' : 'Normalizing',
      source: 'Energy, materials, logistics',
      impact: (prices || 50) > 55 ? 'Margin compression unless passed through' : 'Margin relief ahead',
      duration: '3-6 months',
    },
  ];
}

// ============================================
// SECTOR RANKINGS
// ============================================

function generateSectorRankings(ismData) {
  const { pmi, production, prices, backlog, employment, customersInventories } = ismData;
  const isContraction = pmi < 50;
  const isPricesElevated = (prices || 50) > 55;
  const isEmploymentWeak = (employment || 50) < 48;
  const isBacklogWeak = backlog && backlog < 47;
  
  const sectors = [
    {
      rank: 1,
      sector: 'Computer & Electronic Products',
      shortName: 'Technology',
      impactScore: (production || 50) > 50 ? 6.5 : 5.5,
      direction: 'positive',
      reasoning: `Production at ${production || 'N/A'}. Data center and AI demand provides secular support regardless of cycle.`,
      keyDriver: 'Production',
      keyDriverValue: production || 'N/A',
      ismConnection: `ISM Production at ${production || 'N/A'} - sector shows relative strength`,
      tradingImplication: 'LONG semiconductor equipment, data center infrastructure',
      watchFor: 'New Orders crossing 50 would confirm demand acceleration',
      etf: 'XLK',
      stocks: ['NVDA', 'AMD', 'AMAT'],
    },
    {
      rank: 2,
      sector: 'Food, Beverage & Tobacco',
      shortName: 'Consumer Staples',
      impactScore: isContraction ? 7.8 : 6.0,
      direction: 'positive',
      reasoning: `Defensive demand profile. Customer inventories "${customersInventories}" supports restocking. Pricing power evident.`,
      keyDriver: 'Prices',
      keyDriverValue: prices || 'N/A',
      ismConnection: `Prices at ${prices || 'N/A'} - able to pass through costs`,
      tradingImplication: isContraction ? 'LONG defensive staples with pricing power' : 'Market weight',
      watchFor: 'Customer inventory normalization',
      etf: 'XLP',
      stocks: ['PG', 'KO', 'PEP'],
    },
    {
      rank: 3,
      sector: 'Machinery',
      shortName: 'Industrials/Machinery',
      impactScore: isBacklogWeak ? 4.5 : 7.0,
      direction: isBacklogWeak ? 'negative' : 'positive',
      reasoning: `Backlog at ${backlog || 'N/A'} signals ${isBacklogWeak ? 'weak' : 'adequate'} forward visibility.`,
      keyDriver: 'Backlog',
      keyDriverValue: backlog || 'N/A',
      ismConnection: `Backlog at ${backlog || 'N/A'} - ${isBacklogWeak ? 'poor order visibility' : 'solid order book'}`,
      tradingImplication: isBacklogWeak ? 'Underweight - avoid CapEx sensitivity' : 'Selective LONG with strong backlog',
      watchFor: 'Backlog stabilization above 47',
      etf: 'XLI',
      stocks: ['CAT', 'DE', 'HON'],
    },
    {
      rank: 4,
      sector: 'Transportation Equipment',
      shortName: 'Transportation',
      impactScore: isEmploymentWeak ? 3.8 : 6.5,
      direction: isEmploymentWeak ? 'negative' : 'neutral',
      reasoning: `Employment at ${employment || 'N/A'} signals ${isEmploymentWeak ? 'workforce cuts underway' : 'stable staffing'}.`,
      keyDriver: 'Employment',
      keyDriverValue: employment || 'N/A',
      ismConnection: `Employment at ${employment || 'N/A'} - ${isEmploymentWeak ? 'significant workforce reduction' : 'stable labor conditions'}`,
      tradingImplication: isEmploymentWeak ? 'SHORT or avoid - labor cost pressure' : 'Market weight',
      watchFor: 'Employment stabilization above 48',
      etf: 'IYT',
      stocks: ['UNP', 'FDX', 'DAL'],
    },
  ];
  
  return sectors.sort((a, b) => b.impactScore - a.impactScore);
}

// ============================================
// INDUSTRY QUOTES - From ISMDataService!
// ============================================

function generateQuotes(ismData, sectors) {
  // Use quotes from ISMDataService
  if (ismData.respondentComments && ismData.respondentComments.length > 0) {
    console.log(`[ISM Router] 💬 Using ${ismData.respondentComments.length} REAL quotes`);
    return ismData.respondentComments.map(rc => ({
      industry: rc.industry,
      quote: rc.comment || rc.quote,
      sentiment: rc.sentiment === 'positive' ? 'optimistic' : rc.sentiment === 'negative' ? 'concerned' : 'cautious',
      keyTheme: rc.keyTheme || 'general',
      isReal: rc.isVerified !== false,
      source: rc.source || 'ISMDataService',
    }));
  }
  
  // No quotes available - return empty (no fake generation!)
  console.warn(`[ISM Router] ⚠️ No quotes available - section will be empty`);
  return [];
}

// ============================================
// EQUITY SELECTION LOGIC
// ============================================

function generateEquityLogic(ismData, regime) {
  const { prices, inventories, employment, backlog, newExportOrders, production } = ismData;
  
  const favorable = [
    {
      characteristic: 'Pricing Power',
      ismConnection: `Prices at ${prices || 'N/A'} - companies must pass through costs`,
      rationale: 'In elevated price environment, only companies with pricing power maintain margins',
      examples: 'Consumer staples leaders, essential industrial suppliers',
    },
    {
      characteristic: 'Lean Inventory Management',
      ismConnection: `Inventories at ${inventories || 'N/A'} - efficient operators outperform`,
      rationale: 'Low inventory companies avoid markdown risk if demand weakens further',
      examples: 'JIT manufacturers, service-oriented industrials',
    },
    {
      characteristic: 'Strong Free Cash Flow',
      ismConnection: `Employment at ${employment || 'N/A'} signals margin protection focus`,
      rationale: 'FCF funds buybacks, dividends, and strategic M&A without debt',
      examples: 'Mature industrials with low CapEx needs',
    },
    {
      characteristic: 'Domestic Revenue Focus',
      ismConnection: 'Export Orders vulnerable to trade policy',
      rationale: 'Domestic-focused companies avoid tariff and currency headwinds',
      examples: 'Regional industrials, US-focused contractors',
    },
  ];
  
  const unfavorable = [
    {
      characteristic: 'High Operating Leverage',
      ismConnection: `Production at ${production || 'N/A'} with weak demand = utilization risk`,
      rationale: 'Fixed cost structures amplify earnings decline in downturn',
      examples: 'Heavy industrials, commodity producers',
    },
    {
      characteristic: 'CapEx Dependency',
      ismConnection: `Backlog at ${backlog || 'N/A'} signals customer CapEx hesitation`,
      rationale: 'Equipment sellers suffer when customers defer spending',
      examples: 'Machine tool makers, construction equipment',
    },
    {
      characteristic: 'China/Export Exposure',
      ismConnection: `New Export Orders at ${newExportOrders || 'N/A'} - trade uncertainty`,
      rationale: 'Tariff risk and demand weakness in key markets',
      examples: 'Agricultural equipment, commodity exporters',
    },
    {
      characteristic: 'Labor Intensive Operations',
      ismConnection: `Employment at ${employment || 'N/A'} - workforce adjustments costly`,
      rationale: 'High labor content = wage pressure + severance costs in downturn',
      examples: 'Assembly-heavy manufacturers, logistics',
    },
  ];
  
  let guidance;
  if (regime.name.includes('Stagflation')) {
    guidance = 'Extreme selectivity required. Favor quality, pricing power, and free cash flow over growth. Avoid leverage.';
  } else if (regime.name.includes('Contraction')) {
    guidance = 'Defensive positioning. Prioritize balance sheet strength and dividend sustainability.';
  } else if (regime.name.includes('Late Cycle')) {
    guidance = 'Quality bias but can take cyclical exposure. Focus on companies gaining market share.';
  } else {
    guidance = 'Broader exposure acceptable. Favor companies with operating leverage to improving demand.';
  }
  
  return { favorable, unfavorable, guidance };
}

// ============================================
// TRADE IDEAS GENERATOR
// ============================================

function generateTradeIdeas(ismData, regime, sectors) {
  const { pmi, prices, employment, backlog, customersInventories, newOrders, production } = ismData;
  const isContraction = pmi < 50;
  const isPricesElevated = (prices || 50) > 55;
  const isEmploymentWeak = (employment || 50) < 48;
  const isBacklogWeak = backlog && backlog < 47;
  
  const ideas = [];
  
  // Idea 1: Based on regime
  if (isContraction) {
    ideas.push({
      title: '📈 LONG XLP (Consumer Staples) - Defensive Rotation',
      ticker: 'XLP',
      alternativeStocks: ['PG', 'KO', 'PEP'],
      direction: 'long',
      sector: 'Consumer Staples',
      type: 'positional',
      thesis: {
        ismConnection: `PMI at ${pmi} in contraction, Employment at ${employment || 'N/A'} signals weakness`,
        ismLogic: `In contraction regime, defensive sectors with stable demand outperform.`,
        catalyst: 'Rotation from cyclicals to defensives as PMI weakness persists',
        timing: 'Contraction typically lasts 8-12 months. Position for defensive outperformance.',
      },
      execution: {
        entry: 'XLP at current levels or on pullback to 20-day MA',
        target: '+8-12% as defensive premium expands',
        stopLoss: '-5% below entry',
        timeframe: '2-4 months',
      },
      confidence: 'high',
      confidenceRationale: 'Historical correlation: Consumer Staples outperform by 8-15% during ISM contraction periods',
      invalidation: ['PMI crosses above 50 sustainably (2+ months)', 'New Orders accelerate above 52'],
      risks: ['Risk-on rally on Fed pivot', 'Valuation premium already priced'],
    });
  } else {
    ideas.push({
      title: '📈 LONG XLI (Industrials) - Expansion Play',
      ticker: 'XLI',
      alternativeStocks: ['CAT', 'DE', 'HON'],
      direction: 'long',
      sector: 'Industrials/Machinery',
      type: 'positional',
      thesis: {
        ismConnection: `PMI at ${pmi} expanding, Production at ${production || 'N/A'}`,
        ismLogic: `Expansion regime favors cyclical industrials.`,
        catalyst: 'Earnings beats from industrial companies',
        timing: 'Early/mid expansion typically sees industrials lead',
      },
      execution: {
        entry: 'XLI at current levels',
        target: '+10-15%',
        stopLoss: '-6%',
        timeframe: '2-3 months',
      },
      confidence: 'medium',
      confidenceRationale: 'PMI > 50 historically supports industrial outperformance',
      invalidation: ['PMI drops below 48', 'New Orders collapse below 46'],
      risks: ['Trade policy escalation', 'Fed overtightening'],
    });
  }
  
  // Idea 2: Based on specific signals
  if (isPricesElevated && isContraction) {
    ideas.push({
      title: '📉 SHORT XLY (Consumer Discretionary) - Stagflation Victim',
      ticker: 'XLY',
      alternativeStocks: ['AMZN', 'HD', 'LOW'],
      direction: 'short',
      sector: 'Consumer Discretionary',
      type: 'tactical',
      thesis: {
        ismConnection: `Prices at ${prices} elevated while PMI at ${pmi} contracts`,
        ismLogic: `Stagflation environment crushes discretionary spending.`,
        catalyst: 'Earnings misses from retailers, reduced guidance',
        timing: 'Consumer weakness typically follows manufacturing weakness by 1-2 quarters',
      },
      execution: {
        entry: 'XLY on any bounce to 50-day MA resistance',
        target: '-8-12%',
        stopLoss: '+5% above entry',
        timeframe: '1-2 months',
      },
      confidence: 'high',
      confidenceRationale: 'Stagflation = worst environment for discretionary',
      invalidation: ['Prices index drops below 52', 'Employment stabilizes above 50'],
      risks: ['Holiday spending resilience', 'Fed dovish pivot'],
    });
  } else {
    ideas.push({
      title: '📈 LONG XLK (Technology) - Secular Growth',
      ticker: 'XLK',
      alternativeStocks: ['NVDA', 'MSFT', 'AAPL'],
      direction: 'long',
      sector: 'Technology',
      type: 'swing',
      thesis: {
        ismConnection: `Production at ${production || 'N/A'} - tech resilient`,
        ismLogic: 'Technology shows relative strength. AI demand provides secular support.',
        catalyst: 'AI capex announcements, cloud earnings beats',
        timing: 'Tech typically leads in late cycle before defensive rotation',
      },
      execution: {
        entry: 'XLK at current levels',
        target: '+10-15%',
        stopLoss: '-7%',
        timeframe: '2-3 months',
      },
      confidence: 'medium',
      confidenceRationale: 'Secular AI theme + relative ISM strength',
      invalidation: ['Production drops below 46', 'Tech earnings disappoint'],
      risks: ['Valuation compression', 'Rates spike'],
    });
  }
  
  // Idea 3: Restocking or Backlog play
  if (customersInventories === 'too_low') {
    ideas.push({
      title: '📈 LONG XLB (Materials) - Restocking Cycle',
      ticker: 'XLB',
      alternativeStocks: ['LIN', 'APD', 'FCX', 'NEM'],
      direction: 'long',
      sector: 'Materials',
      type: 'swing',
      thesis: {
        ismConnection: `Customer Inventories "too low"`,
        ismLogic: 'Low customer inventories signal potential restocking cycle.',
        catalyst: 'Inventory normalization, purchasing manager comments on restocking',
        timing: 'Restocking typically occurs 1-2 months after inventory trough signal',
      },
      execution: {
        entry: 'XLB at current levels',
        target: '+10-15%',
        stopLoss: '-6%',
        timeframe: '2-4 months',
      },
      confidence: 'medium',
      confidenceRationale: '"Too Low" customer inventories is reliable restocking signal',
      invalidation: ['Inventories rise to "about right" without restocking', 'New Orders collapse below 42'],
      risks: ['Demand deteriorates preventing restocking', 'Commodity price spike'],
    });
  } else if (isBacklogWeak) {
    ideas.push({
      title: '📉 UNDERWEIGHT XLI (Industrials) - Backlog Depletion',
      ticker: 'XLI',
      alternativeStocks: ['GE', 'HON', 'MMM'],
      direction: 'short',
      sector: 'Industrials',
      type: 'tactical',
      thesis: {
        ismConnection: `Backlog at ${backlog} depleting`,
        ismLogic: 'Order backlog depletion signals weak forward visibility.',
        catalyst: 'Q4 guidance cuts, backlog depletion mentioned in earnings',
        timing: 'Backlog impact shows up in earnings 1-2 quarters later',
      },
      execution: {
        entry: 'Reduce XLI exposure on strength',
        target: '-8-10% underperformance vs SPY',
        stopLoss: 'Cover if Backlog crosses 50',
        timeframe: '2-3 months',
      },
      confidence: 'medium',
      confidenceRationale: 'Backlog < 46 historically leads industrial underperformance',
      invalidation: ['Backlog crosses above 50', 'New Orders accelerate sharply'],
      risks: ['Infrastructure stimulus', 'Defense spending boost'],
    });
  }
  
  // Idea 4: Quality flight
  if (isEmploymentWeak) {
    ideas.push({
      title: '📈 LONG QUAL (Quality Factor) - Flight to Quality',
      ticker: 'QUAL',
      alternativeStocks: ['JNJ', 'UNH', 'V', 'MA'],
      direction: 'long',
      sector: 'Quality/Multi-sector',
      type: 'positional',
      thesis: {
        ismConnection: `Employment at ${employment} signals late-cycle margin protection`,
        ismLogic: 'When companies cut employment, only quality companies survive intact.',
        catalyst: 'Earnings season quality divergence',
        timing: 'Quality outperformance accelerates as cycle matures',
      },
      execution: {
        entry: 'QUAL or quality stocks at current levels',
        target: '+8-12% relative outperformance',
        stopLoss: '-5%',
        timeframe: '3-6 months',
      },
      confidence: 'high',
      confidenceRationale: 'Quality factor has highest Sharpe in late-cycle/early recession',
      invalidation: ['Employment rebounds above 50', 'Aggressive Fed easing'],
      risks: ['Risk-on rally leaves quality behind temporarily'],
    });
  }
  
  return ideas;
}

// ============================================
// INVALIDATION SCENARIOS
// ============================================

function generateInvalidationScenarios(ismData) {
  const { pmi, newOrders, prices, employment } = ismData;
  const isContraction = pmi < 50;
  
  if (isContraction) {
    return [
      'PMI crosses above 50 for 2+ consecutive months',
      'New Orders rebounds above 52 signaling demand recovery',
      'Federal Reserve major policy pivot (unexpected rate cuts/hikes)',
      'Geopolitical shock affecting supply chains or energy prices',
      'Prices index normalizes below 52 - changes margin narrative',
      'Employment stabilizes above 50 - changes labor narrative',
    ];
  } else {
    return [
      'PMI crosses below 50 for 2+ consecutive months',
      'New Orders collapses below 46 signaling demand destruction',
      'Federal Reserve major policy pivot (unexpected rate cuts/hikes)',
      'Geopolitical shock affecting supply chains or energy prices',
      'Prices spike above 65 - stagflation concerns',
      'Employment drops below 46 - recession signal',
    ];
  }
}

// ============================================
// NEXT MONTH INDICATORS
// ============================================

function generateNextMonthIndicators(ismData) {
  const { newOrders, employment, prices, backlog, customersInventories } = ismData;
  
  return [
    `New Orders direction (currently ${newOrders || 'N/A'}) - leading indicator of PMI`,
    `Employment trajectory (currently ${employment || 'N/A'}) - confirms or denies weakness`,
    `Prices trend (currently ${prices || 'N/A'}) - inflation persistence check`,
    `Backlog stabilization (currently ${backlog || 'N/A'}) - visibility metric`,
    `Customer inventory normalization (currently "${customersInventories || 'N/A'}")`,
    'Regional Fed manufacturing surveys (Empire State, Philly Fed) - early signals',
    'ISM Services PMI - broader economy health check',
  ];
}

// ============================================
// EXECUTIVE SUMMARY GENERATOR
// ============================================

function generateExecutiveSummary(ismData, regime, sectors, trends) {
  const { pmi, prices, employment, newOrders } = ismData;
  const isContraction = pmi < 50;
  const topSector = sectors[0];
  const bottomSector = sectors[sectors.length - 1];
  
  const situation = `ISM PMI at ${pmi}, ${isContraction ? 'contraction' : 'expansion'} territory. ${regime.name}.`;
  
  const pmiTrend = trends.find(t => t.indicator === 'PMI');
  const trendLine = pmiTrend 
    ? `${pmiTrend.direction === 'contracting' ? 'Contracting' : 'Expanding'} for ${pmiTrend.duration}. ${pmiTrend.implication}`
    : `${isContraction ? 'Contraction' : 'Expansion'} trend continues.`;
  
  const sectorLine = `${topSector.shortName} favored (${topSector.impactScore}/10), ${bottomSector.shortName} challenged (${bottomSector.impactScore}/10).`;
  
  let riskLine;
  if (regime.name.includes('Stagflation')) {
    riskLine = `Stagflation Warning. Prices at ${prices || 'N/A'} while activity contracts - worst margin environment.`;
  } else if (isContraction && (newOrders || 50) < pmi) {
    riskLine = `Orders Weakening. New Orders at ${newOrders || 'N/A'} lead PMI lower. More downside likely.`;
  } else {
    riskLine = `${regime.name}. ${regime.description}`;
  }
  
  let actionLine;
  if (regime.name.includes('Stagflation')) {
    actionLine = 'Extreme selectivity required. Favor quality, pricing power, and free cash flow over growth. Avoid leverage.';
  } else if (isContraction) {
    actionLine = 'Defensive positioning recommended. Prioritize balance sheet strength and dividend sustainability.';
  } else {
    actionLine = 'Quality bias but can take cyclical exposure. Focus on companies gaining market share.';
  }
  
  return { situation, trend: trendLine, sectors: sectorLine, risk: riskLine, action: actionLine };
}

// ============================================
// MARKDOWN BUILDER
// ============================================

function buildInstitutionalMarkdown(ismData, regime, criticalGaps, timeHorizons, trends, structuralPressures, sectors, quotes, equityLogic, tradeIdeas, invalidation, nextMonth, summary) {
  const monthDisplay = formatMonthDisplay(ismData.month);
  let md = '';

  // Header
  md += `# 🔒 TOP SECRET: ISM Manufacturing Report\n`;
  md += `## ${monthDisplay}\n\n`;
  md += `> **Institutional Grade Analysis** | Data Source: ${ismData.dataSource} | Generated: ${new Date().toISOString()}\n\n`;
  
  if (ismData.dataQuality === 'partial') {
    md += `> ⚠️ **Note:** Some data points unavailable. Analysis based on available PMI data.\n\n`;
  }
  
  if (ismData.notes) {
    md += `> 📋 **Key Note:** ${ismData.notes}\n\n`;
  }
  
  if (ismData.warning) {
    md += `> ⚠️ **Warning:** ${ismData.warning}\n\n`;
  }
  
  md += `---\n\n`;

  // Executive Summary
  md += `## 📋 Executive Summary\n\n`;
  md += `*5 lines for busy investment managers*\n\n`;
  md += `📊 **Situation:** ${summary.situation}\n\n`;
  md += `📈 **Trend:** ${summary.trend}\n\n`;
  md += `🏭 **Sectors:** ${summary.sectors}\n\n`;
  md += `⚠️ **Risk:** ${summary.risk}\n\n`;
  md += `🎯 **Action:** ${summary.action}\n\n`;
  md += `---\n\n`;

  // Section 1: Macro Regime
  md += `## 1. 🎯 Macro Regime Snapshot\n\n`;
  md += `*Clear picture of where we are in the cycle*\n\n`;
  
  md += `### Current Regime\n\n`;
  md += `**🏛️ ${regime.name}**\n\n`;
  md += `| Attribute | Assessment |\n`;
  md += `|-----------|------------|\n`;
  md += `| **PMI Level** | ${ismData.pmi} (${ismData.isContraction ? 'contraction' : 'expansion'}) |\n`;
  md += `| **Direction** | ${regime.direction === 'improving' ? '📈' : regime.direction === 'deteriorating' ? '📉' : '➡️'} ${regime.direction.charAt(0).toUpperCase() + regime.direction.slice(1)} |\n`;
  md += `| **Risk Level** | ${regime.riskLevel === 'high' ? '🚨' : regime.riskLevel === 'elevated' ? '⚠️' : '📊'} ${regime.riskLevel.charAt(0).toUpperCase() + regime.riskLevel.slice(1)} |\n\n`;

  // Key Data Points
  md += `### 📊 Key ISM Data Points\n\n`;
  md += `| Component | Value | Signal | Implication |\n`;
  md += `|-----------|-------|--------|-------------|\n`;
  md += `| **PMI Headline** | ${ismData.pmi} | ${ismData.pmi >= 50 ? '✅ Expansion' : '❌ Contraction'} | ${ismData.pmi >= 50 ? '📈 Expansion' : ismData.pmi >= 48 ? '⚠️ Mild contraction' : '🚨 Deep contraction'} |\n`;
  md += `| **New Orders** | ${ismData.newOrders || 'N/A'} | ${(ismData.newOrders || 50) >= 50 ? '📈 Growing' : '📉 Falling'} | ${(ismData.newOrders || 50) > ismData.pmi ? '🔥 Leading positive' : 'Aligned with PMI'} |\n`;
  md += `| **Production** | ${ismData.production || 'N/A'} | ${(ismData.production || 50) >= 50 ? '🏭 Active' : '⬇️ Slowing'} | ${Math.abs((ismData.production || 50) - (ismData.newOrders || 50)) > 2 ? '⚠️ Gap with orders' : 'Balanced'} |\n`;
  md += `| **Employment** | ${ismData.employment || 'N/A'} | ${(ismData.employment || 50) >= 50 ? '👥 Hiring' : '⬇️ Cutting'} | ${(ismData.employment || 50) < 45 ? '🚨 Severe cuts' : (ismData.employment || 50) < 48 ? '⚠️ Layoffs' : '📊 Stable'} |\n`;
  md += `| **Prices** | ${ismData.prices || 'N/A'} | ${(ismData.prices || 50) > 55 ? '🔥 Elevated' : '📊 Moderate'} | ${(ismData.prices || 50) > 55 && ismData.pmi < 50 ? '⚠️ Stagflation risk' : 'Manageable'} |\n`;
  md += `| **Backlog** | ${ismData.backlog || 'N/A'} | ${(ismData.backlog || 50) >= 47 ? '📋 Healthy' : '📉 Depleting'} | ${(ismData.backlog || 50) < 45 ? '🚨 Poor visibility' : '📊 Adequate'} |\n\n`;

  // MoM Changes if available
  if (ismData.momChanges) {
    md += `### 📈 Month-over-Month Changes\n\n`;
    md += `| Component | Prior | Current | Change |\n`;
    md += `|-----------|-------|---------|--------|\n`;
    const changes = ismData.momChanges;
    if (changes.pmi) md += `| PMI | ${changes.pmi.prior} | ${changes.pmi.current} | ${changes.pmi.delta > 0 ? '+' : ''}${changes.pmi.delta} |\n`;
    if (changes.newOrders) md += `| New Orders | ${changes.newOrders.prior || '-'} | ${changes.newOrders.current || '-'} | ${changes.newOrders.delta ? (changes.newOrders.delta > 0 ? '+' : '') + changes.newOrders.delta : '-'} |\n`;
    if (changes.employment) md += `| Employment | ${changes.employment.prior || '-'} | ${changes.employment.current || '-'} | ${changes.employment.delta ? (changes.employment.delta > 0 ? '+' : '') + changes.employment.delta : '-'} |\n`;
    if (changes.prices) md += `| Prices | ${changes.prices.prior || '-'} | ${changes.prices.current || '-'} | ${changes.prices.delta ? (changes.prices.delta > 0 ? '+' : '') + changes.prices.delta : '-'} |\n`;
    md += `\n`;
  }

  // Critical divergences
  if (criticalGaps.length > 0) {
    md += `### 🔍 Critical Divergences\n\n`;
    md += `*These gaps reveal what the headline PMI doesn't tell you*\n\n`;
    
    for (const gap of criticalGaps) {
      md += `#### ${gap.severity === 'high' ? '🚨' : '⚠️'} ${gap.type}\n\n`;
      md += `${gap.description}\n\n`;
      md += `**Why It Matters:** ${gap.whyItMatters}\n\n`;
      md += `**Investor Action:** ${gap.investorAction}\n\n`;
      md += `> 💡 **Trading Signal:** ${gap.tradingSignal}\n\n`;
    }
  }

  // Time horizons
  md += `### ⏰ Time Horizon Analysis\n\n`;
  md += `| Timeframe | Outlook |\n`;
  md += `|-----------|--------|\n`;
  md += `| **Short-term (${timeHorizons.shortTerm.period})** | ${timeHorizons.shortTerm.outlook} |\n`;
  md += `| **Medium-term (${timeHorizons.mediumTerm.period})** | ${timeHorizons.mediumTerm.outlook} |\n`;
  md += `| **Long-term (${timeHorizons.longTerm.period})** | ${timeHorizons.longTerm.outlook} |\n\n`;
  md += `---\n\n`;

  // Section 2: Trend Engine
  md += `## 2. 📈 Trend Engine\n\n`;
  md += `*Multi-month trends that are NOT monthly noise*\n\n`;
  
  md += `### Persistent Trends\n\n`;
  md += `| Indicator | Direction | Duration | Current | Threshold | Severity |\n`;
  md += `|-----------|-----------|----------|---------|-----------|----------|\n`;
  for (const trend of trends) {
    const icon = trend.direction === 'contracting' || trend.direction === 'depleting' || trend.direction === 'elevated' ? '🔴' : '🟢';
    const severity = trend.severityScore > 7 ? '🚨 Critical' : trend.severityScore > 4 ? '⚠️ Elevated' : '📊 Moderate';
    md += `| **${trend.indicator}** | ${icon} ${trend.direction} | ${trend.duration} | ${trend.currentValue} | ${trend.threshold} | ${severity} |\n`;
  }
  md += `\n`;
  
  md += `#### 📊 Trend Implications\n\n`;
  for (const trend of trends) {
    const icon = trend.direction === 'contracting' || trend.direction === 'depleting' || trend.direction === 'elevated' ? '📉' : '📈';
    md += `**${trend.indicator}** (${trend.strength})\n`;
    md += `- ${icon} ${trend.implication}\n\n`;
  }

  md += `### Structural Pressures\n\n`;
  for (const pressure of structuralPressures) {
    md += `- **${pressure.type}**: ${pressure.level}\n`;
    md += `  - *Source:* ${pressure.source}\n`;
    md += `  - *Impact:* ${pressure.impact}\n`;
    md += `  - *Duration:* ${pressure.duration}\n\n`;
  }
  md += `---\n\n`;

  // Section 3: Sector Impact
  md += `## 3. 🏭 Sector Impact Map\n\n`;
  md += `*4 key sectors ranked by ISM impact*\n\n`;

  for (const sector of sectors) {
    const dirIcon = sector.direction === 'positive' ? '📈' : sector.direction === 'negative' ? '📉' : '➡️';
    md += `### ${sector.rank}. ${sector.sector} (${sector.shortName})\n\n`;
    md += `**Impact Score:** ${sector.impactScore}/10 ${dirIcon} ${sector.direction}\n\n`;
    md += `${sector.reasoning}\n\n`;
    md += `| Attribute | Value |\n`;
    md += `|-----------|-------|\n`;
    md += `| **Key Driver** | ${sector.keyDriver} at ${sector.keyDriverValue} |\n`;
    md += `| **ISM Connection** | ${sector.ismConnection} |\n`;
    md += `| **Trading Implication** | ${sector.tradingImplication} |\n`;
    md += `| **Watch For** | ${sector.watchFor} |\n`;
    md += `| **ETF** | ${sector.etf} |\n`;
    md += `| **Key Stocks** | ${sector.stocks.join(', ')} |\n\n`;
  }

  // Industry quotes
  md += `### 💬 Industry Voices\n\n`;
  if (quotes.length > 0) {
    md += `*Real quotes from ISM Manufacturing Report - via ISMDataService*\n\n`;
    for (const quote of quotes) {
      const emoji = quote.sentiment === 'optimistic' ? '😊' : quote.sentiment === 'concerned' ? '😟' : '😐';
      const verified = quote.isReal ? '✓' : '';
      md += `> "${quote.quote}"\n>\n> — *${quote.industry}* ${emoji} ${verified}\n\n`;
    }
  } else {
    md += `*No quotes available for this month.*\n\n`;
  }
  md += `---\n\n`;

  // Section 4: Equity Selection
  md += `## 4. 📋 Equity Selection Logic\n\n`;
  md += `*How to select stocks in this ISM environment*\n\n`;
  md += `> 📊 **Overall Guidance:** ${equityLogic.guidance}\n\n`;

  md += `### ✅ Favorable Characteristics\n\n`;
  for (const fav of equityLogic.favorable) {
    md += `#### ${fav.characteristic}\n`;
    md += `- **ISM Connection:** ${fav.ismConnection}\n`;
    md += `- **Rationale:** ${fav.rationale}\n`;
    md += `- **Examples:** ${fav.examples}\n\n`;
  }

  md += `### ❌ Characteristics to Avoid\n\n`;
  for (const unfav of equityLogic.unfavorable) {
    md += `#### ${unfav.characteristic}\n`;
    md += `- **ISM Connection:** ${unfav.ismConnection}\n`;
    md += `- **Rationale:** ${unfav.rationale}\n`;
    md += `- **Examples:** ${unfav.examples}\n\n`;
  }
  md += `---\n\n`;

  // Section 5: Trade Ideas
  md += `## 5. 💡 Actionable Trade Ideas\n\n`;
  md += `*${tradeIdeas.length} ideas directly derived from ISM data*\n\n`;

  tradeIdeas.forEach((idea, index) => {
    const dirIcon = idea.direction === 'long' ? '📈' : '📉';
    md += `### ${dirIcon} Trade ${index + 1}: ${idea.title}\n\n`;
    
    md += `| Ticker | Direction | Sector | Type | Confidence |\n`;
    md += `|--------|-----------|--------|------|------------|\n`;
    md += `| **${idea.ticker}** | ${idea.direction.toUpperCase()} | ${idea.sector} | ${idea.type} | ${idea.confidence} |\n\n`;
    
    if (idea.alternativeStocks?.length > 0) {
      md += `**📌 Alternative Stocks:** ${idea.alternativeStocks.join(', ')}\n\n`;
    }
    
    md += `#### 📖 Thesis\n\n`;
    md += `**🔗 ISM Connection:** ${idea.thesis.ismConnection}\n\n`;
    md += `${idea.thesis.ismLogic}\n\n`;
    md += `**Catalyst:** ${idea.thesis.catalyst}\n\n`;
    md += `**Why Now:** ${idea.thesis.timing}\n\n`;
    
    md += `#### 📊 Execution\n\n`;
    md += `| Parameter | Value |\n`;
    md += `|-----------|-------|\n`;
    md += `| **Entry** | ${idea.execution.entry} |\n`;
    md += `| **Target** | ${idea.execution.target} |\n`;
    md += `| **Stop Loss** | ${idea.execution.stopLoss} |\n`;
    md += `| **Timeframe** | ${idea.execution.timeframe} |\n\n`;
    
    md += `*Confidence Rationale:* ${idea.confidenceRationale}\n\n`;
    
    md += `#### ❌ What Would Invalidate This Trade\n\n`;
    for (const inv of idea.invalidation) {
      md += `- ${inv}\n`;
    }
    md += `\n`;
    
    md += `**Risks:** ${idea.risks.join(' | ')}\n\n`;
    md += `---\n\n`;
  });

  md += `> ⚠️ **Disclaimer:** These are trade ideas for educational purposes only. Not investment advice.\n\n`;
  md += `---\n\n`;

  // Invalidation
  md += `## ❌ What Would Invalidate This Analysis\n\n`;
  for (const item of invalidation) {
    md += `- ${item}\n`;
  }
  md += `\n---\n\n`;

  // Next Month
  md += `## 👁️ Indicators to Watch Next Month\n\n`;
  for (const indicator of nextMonth) {
    md += `- 👁️ ${indicator}\n`;
  }
  md += `\n---\n\n`;

  // Footer
  md += `*Report generated by Finotaur ISM Analysis System v5.0 (Dynamic First)*\n`;
  md += `*PMI Data: ${ismData.dataSource} | Quotes: ${quotes.length > 0 ? `${quotes.length} via ISMDataService` : 'None available'}*\n`;
  md += `*${new Date().toISOString()}*\n\n`;
  md += `🔒 **TOP SECRET - INSTITUTIONAL USE ONLY**\n`;

  return md;
}

// ============================================
// MAIN REPORT GENERATOR
// ============================================

async function generateInstitutionalReport(month, reportId, onProgress) {
  const startTime = Date.now();
  
  // Step 1: Fetch ISM Data (DYNAMIC FIRST!)
  onProgress?.(AGENTS[0], 'running', 'Fetching ISM PMI data (dynamic first)...');
  let ismData;
  try {
    ismData = await getISMData(month);
    onProgress?.(AGENTS[0], 'completed', `Got PMI ${ismData.pmi} from ${ismData.dataSource}`);
  } catch (error) {
    onProgress?.(AGENTS[0], 'error', error.message);
    throw error;
  }
  
  // Step 2: Quotes already fetched in getISMData
  onProgress?.(AGENTS[1], 'completed', `${ismData.respondentComments?.length || 0} quotes from ISMDataService`);
  
  // Simulate agent execution
  const simulateAgent = async (agent, task, result) => {
    onProgress?.(agent, 'running', task);
    await new Promise(r => setTimeout(r, 200 + Math.random() * 300));
    onProgress?.(agent, 'completed', result);
  };
  
  // Step 3-14: Process data
  await simulateAgent(AGENTS[2], 'Building historical context...', 'Context built');
  
  await simulateAgent(AGENTS[3], 'Detecting macro regime...', 'Regime identified');
  const regime = detectRegime(ismData);
  
  await simulateAgent(AGENTS[4], 'Analyzing critical gaps...', 'Divergences mapped');
  const criticalGaps = analyzeCriticalGaps(ismData);
  
  await simulateAgent(AGENTS[5], 'Building narrative...', 'Time horizons set');
  const timeHorizons = generateTimeHorizons(ismData, regime);
  
  await simulateAgent(AGENTS[6], 'Scanning persistent trends...', 'Trends identified');
  const trends = analyzeTrends(ismData);
  
  await simulateAgent(AGENTS[7], 'Mapping structural pressures...', 'Pressures analyzed');
  const structuralPressures = analyzeStructuralPressures(ismData);
  
  await simulateAgent(AGENTS[8], 'Scoring sector impacts...', '4 sectors ranked');
  const sectors = generateSectorRankings(ismData);
  
  await simulateAgent(AGENTS[9], 'Processing quotes...', `${ismData.respondentComments?.length || 0} quotes ready`);
  const quotes = generateQuotes(ismData, sectors);
  
  await simulateAgent(AGENTS[10], 'Building equity criteria...', 'Selection logic ready');
  const equityLogic = generateEquityLogic(ismData, regime);
  
  await simulateAgent(AGENTS[11], 'Generating trade ideas...', 'Ideas synthesized');
  const tradeIdeas = generateTradeIdeas(ismData, regime, sectors);
  
  await simulateAgent(AGENTS[12], 'Checking coherence...', 'Report validated');
  const invalidation = generateInvalidationScenarios(ismData);
  const nextMonth = generateNextMonthIndicators(ismData);
  
  await simulateAgent(AGENTS[13], 'Writing executive summary...', 'Summary complete');
  const summary = generateExecutiveSummary(ismData, regime, sectors, trends);
  
  // Build markdown
  const markdown = buildInstitutionalMarkdown(
    ismData, regime, criticalGaps, timeHorizons, trends,
    structuralPressures, sectors, quotes, equityLogic,
    tradeIdeas, invalidation, nextMonth, summary
  );
  
  const processingTime = Date.now() - startTime;
  
  return {
    id: reportId,
    month: ismData.month,
    status: 'completed',
    dataSource: ismData.dataSource,
    quotesSource: 'ISMDataService',
    quotesCount: quotes.length,
    dataQuality: ismData.dataQuality,
    format: 'markdown',
    content: markdown,
    metadata: {
      regime: regime.name,
      pmi: ismData.pmi,
      direction: ismData.direction,
      tradeIdeasCount: tradeIdeas.length,
      sectorsAnalyzed: sectors.length,
      criticalGaps: criticalGaps.length,
      generatedAt: new Date().toISOString(),
      processingTimeMs: processingTime,
      confidence: ismData.confidence,
    },
    rawData: {
      ismData, regime, criticalGaps, timeHorizons, trends,
      structuralPressures, sectors, quotes, equityLogic,
      tradeIdeas, invalidation, nextMonth, summary,
    },
  };
}

// ============================================
// API ROUTES
// ============================================

// GET /status
router.get('/status', (req, res) => {
  const currentMonth = getCurrentDataMonth();
  const client = getOpenAIClient();
  const service = getISMDataService();
  const fallbackMonths = Object.keys(FALLBACK_ISM_DATA).sort().reverse();
  const perplexityConfigured = !!process.env.PERPLEXITY_API_KEY;
  
  // Check if we have a report for current month
  let reportExists = false;
  let reportId = null;
  let reportGeneratedAt = null;
  
  for (const [id, report] of memoryStore.reports.entries()) {
    if (report.month === currentMonth) {
      reportExists = true;
      reportId = id;
      reportGeneratedAt = report.metadata?.generatedAt || report.created_at;
      break;
    }
  }
  
  // ISM available if we have verified data OR ISMDataService is configured
  const hasVerifiedData = !!FALLBACK_ISM_DATA[currentMonth];
  const hasDynamicService = !!service;
  const ismAvailable = hasVerifiedData || hasDynamicService;
  
  res.json({
    success: true,
    data: {
      month: currentMonth,
      ismAvailable: ismAvailable,
      willUseMockData: !hasVerifiedData && !hasDynamicService,
      expectedReleaseDate: getExpectedReleaseDate(currentMonth),
      status: reportExists ? 'report_generated' : (ismAvailable ? 'ism_available' : 'pending_ism'),
      reportExists: reportExists,
      reportId: reportId,
      reportGeneratedAt: reportGeneratedAt,
    },
    service: 'ISM Analysis Service v5.0 (Dynamic First)',
    dataSources: {
      primary: service ? 'ISMDataService (Perplexity) ✅' : '❌ ISMDataService not configured',
      fallback: `FALLBACK_ISM_DATA (${fallbackMonths.length} months verified)`,
      quotes: perplexityConfigured ? 'ISMDataService TIER system ✅' : '❌ NOT CONFIGURED',
      openai: client ? 'configured ✅' : 'not configured',
    },
    cache: {
      dataEntries: memoryStore.ismDataCache.size,
      quotesEntries: memoryStore.quotesCache.size,
      reportsCount: memoryStore.reports.size,
    },
    timestamp: new Date().toISOString(),
  });
});

// GET /status/:month
router.get('/status/:month', (req, res) => {
  const { month } = req.params;
  const service = getISMDataService();
  
  let reportExists = false;
  let reportId = null;
  let reportGeneratedAt = null;
  
  for (const [id, report] of memoryStore.reports.entries()) {
    if (report.month === month) {
      reportExists = true;
      reportId = id;
      reportGeneratedAt = report.metadata?.generatedAt || report.created_at;
      break;
    }
  }
  
  const hasVerifiedData = !!FALLBACK_ISM_DATA[month];
  const hasDynamicService = !!service;
  const ismAvailable = hasVerifiedData || hasDynamicService;
  
  res.json({
    success: true,
    data: {
      month: month,
      ismAvailable: ismAvailable,
      willUseMockData: !hasVerifiedData && !hasDynamicService,
      expectedReleaseDate: getExpectedReleaseDate(month),
      status: reportExists ? 'report_generated' : (ismAvailable ? 'ism_available' : 'pending_ism'),
      reportExists: reportExists,
      reportId: reportId,
      reportGeneratedAt: reportGeneratedAt,
    },
    service: 'ISM Analysis Service v5.0 (Dynamic First)',
    timestamp: new Date().toISOString(),
  });
});

// POST /generate
router.post('/generate', async (req, res) => {
  try {
    const { month } = req.body;
    const targetMonth = month || getCurrentDataMonth();
    const reportId = generateId();
    
    console.log(`[ISM Router] 🚀 Starting DYNAMIC FIRST report generation for ${targetMonth}`);
    
    // Initialize progress
    memoryStore.progress.set(reportId, {
      id: reportId,
      month: targetMonth,
      status: 'running',
      startedAt: new Date().toISOString(),
      agents: AGENTS.map(a => ({ ...a, status: 'pending', message: '' })),
      currentAgent: 0,
    });
    
    // Progress callback
    const onProgress = (agent, status, message) => {
      const progress = memoryStore.progress.get(reportId);
      if (progress) {
        const agentIndex = progress.agents.findIndex(a => a.id === agent.id);
        if (agentIndex >= 0) {
          progress.agents[agentIndex].status = status;
          progress.agents[agentIndex].message = message;
          progress.currentAgent = agentIndex;
        }
        memoryStore.progress.set(reportId, progress);
      }
    };
    
    // Start generation
    generateInstitutionalReport(targetMonth, reportId, onProgress)
      .then(report => {
        memoryStore.reports.set(reportId, report);
        const progress = memoryStore.progress.get(reportId);
        if (progress) {
          progress.status = 'completed';
          progress.completedAt = new Date().toISOString();
          memoryStore.progress.set(reportId, progress);
        }
        console.log(`[ISM Router] ✅ Report ${reportId} completed with ${report.quotesCount} quotes from ${report.dataSource}`);
      })
      .catch(error => {
        console.error(`[ISM Router] ❌ Report ${reportId} failed:`, error);
        const progress = memoryStore.progress.get(reportId);
        if (progress) {
          progress.status = 'error';
          progress.error = error.message;
          memoryStore.progress.set(reportId, progress);
        }
      });
    
    res.json({
      success: true,
      message: 'Dynamic First report generation started',
      reportId,
      month: targetMonth,
      mode: 'ISMDataService → Fallback → OpenAI → FRED',
      progressUrl: `/api/ism/progress/${reportId}`,
      reportUrl: `/api/ism/report/${reportId}`,
    });
    
  } catch (error) {
    console.error('[ISM Router] Generate error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET /progress/:id
router.get('/progress/:id', (req, res) => {
  const { id } = req.params;
  const progress = memoryStore.progress.get(id);
  
  if (!progress) {
    return res.status(404).json({
      success: false,
      error: 'Report not found',
    });
  }
  
  const completedAgentIds = progress.agents
    .filter(a => a.status === 'completed')
    .map(a => a.id);
  
  const completedCount = completedAgentIds.length;
  const totalAgents = progress.agents.length;
  const currentAgent = progress.agents.find(a => a.status === 'running');
  
  const startTime = new Date(progress.startedAt).getTime();
  const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
  
  res.json({
    success: true,
    data: {
      reportId: progress.id,
      status: progress.status,
      progress: Math.round((completedCount / totalAgents) * 100),
      currentPhase: currentAgent?.phase || null,
      currentAgentId: currentAgent?.id || null,
      completedAgents: completedAgentIds,
      elapsedSeconds: elapsedSeconds,
      error: progress.error,
      month: progress.month,
      startedAt: progress.startedAt,
      completedAt: progress.completedAt,
      completedCount,
      totalAgents,
      currentAgent: currentAgent ? {
        id: currentAgent.id,
        name: currentAgent.name,
        phase: currentAgent.phase,
        message: currentAgent.message,
      } : null,
      agents: progress.agents,
    },
  });
});

// GET /report/:id
router.get('/report/:id', (req, res) => {
  const { id } = req.params;
  const report = memoryStore.reports.get(id);
  
  if (!report) {
    const progress = memoryStore.progress.get(id);
    if (progress?.status === 'running') {
      return res.status(202).json({
        success: true,
        status: 'generating',
        message: 'Report is still being generated',
        progressUrl: `/api/ism/progress/${id}`,
      });
    }
    if (progress?.status === 'error') {
      return res.status(500).json({
        success: false,
        error: progress.error,
      });
    }
    return res.status(404).json({
      success: false,
      error: 'Report not found',
    });
  }
  
  res.json({
    success: true,
    data: {
      ...report,
      markdown_content: report.content,
      html_content: report.htmlContent || '',
      created_at: report.metadata?.generatedAt || new Date().toISOString(),
      qa_score: report.metadata?.qaScore || 85,
      qa_passed: true,
    },
  });
});

// GET /report/:id/pdf
router.get('/report/:id/pdf', async (req, res) => {
  try {
    const { id } = req.params;
    const report = memoryStore.reports.get(id);
    
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    
    if (!report.rawData) {
      return res.status(400).json({ success: false, error: 'Report has no data for PDF' });
    }
    
    const ismData = report.rawData.ismData;
    
    // GET PRIOR MONTH DATA FOR MOM CALCULATION
    const [year, monthNum] = report.month.split('-').map(Number);
    let priorYear = year;
    let priorMonthNum = monthNum - 1;
    if (priorMonthNum < 1) {
      priorMonthNum = 12;
      priorYear--;
    }
    const priorMonthKey = `${priorYear}-${String(priorMonthNum).padStart(2, '0')}`;
    
    // Try ISMDataService priorMonth first, then fallback
    const priorData = ismData.priorMonth || FALLBACK_ISM_DATA[priorMonthKey] || {};
    
    console.log(`[ISM Router] Prior month: ${priorMonthKey}, has data: ${!!priorData.pmi}`);
    
    // CALCULATE MOM CHANGES
    const calcDelta = (curr, prev) => {
      if (curr == null || prev == null) return null;
      return parseFloat((curr - prev).toFixed(1));
    };
    
    const momChanges = ismData.momChanges || {
      pmi: { prior: priorData.pmi, current: ismData.pmi, delta: calcDelta(ismData.pmi, priorData.pmi) },
      newOrders: { prior: priorData.newOrders, current: ismData.newOrders, delta: calcDelta(ismData.newOrders, priorData.newOrders) },
      production: { prior: priorData.production, current: ismData.production, delta: calcDelta(ismData.production, priorData.production) },
      employment: { prior: priorData.employment, current: ismData.employment, delta: calcDelta(ismData.employment, priorData.employment) },
      prices: { prior: priorData.prices, current: ismData.prices, delta: calcDelta(ismData.prices, priorData.prices) },
      backlog: { prior: priorData.backlog, current: ismData.backlog, delta: calcDelta(ismData.backlog, priorData.backlog) },
      inventories: { prior: priorData.inventories, current: ismData.inventories, delta: calcDelta(ismData.inventories, priorData.inventories) },
    };
    
    // Build structured report object for PDF generator
    const pdfReportData = {
      report_month: report.month,
      executive_summary: report.rawData.summary,
      
      macro_snapshot: {
        regime: report.rawData.regime.name,
        regimeLabel: report.rawData.regime.name,
        confidence: ismData.confidence === 'high' ? 85 : 65,
        narrative: report.rawData.regime.description,
        riskLevel: report.rawData.regime.riskLevel,
        direction: report.rawData.regime.direction,
        keyDrivers: ismData.notes ? [ismData.notes] : [],
        criticalGaps: report.rawData.criticalGaps,
        timeHorizon: {
          shortTerm: report.rawData.timeHorizons.shortTerm.outlook,
          mediumTerm: report.rawData.timeHorizons.mediumTerm.outlook,
          longTerm: report.rawData.timeHorizons.longTerm.outlook,
        },
        
        // ISM VALUES
        pmi: ismData.pmi,
        pmiValue: ismData.pmi,
        newOrders: ismData.newOrders,
        production: ismData.production,
        employment: ismData.employment,
        prices: ismData.prices,
        backlog: ismData.backlog,
        inventories: ismData.inventories,
        supplierDeliveries: ismData.supplierDeliveries,
        newExportOrders: ismData.newExportOrders,
        imports: ismData.imports,
        customersInventories: ismData.customersInventories,
        
        // PRIOR MONTH VALUES
        previousPmi: priorData.pmi || ismData.previousPmi,
        previousNewOrders: priorData.newOrders,
        previousProduction: priorData.production,
        previousEmployment: priorData.employment,
        previousPrices: priorData.prices,
        previousBacklog: priorData.backlog,
        previousInventories: priorData.inventories,
        
        isContraction: ismData.isContraction,
        consecutiveMonths: ismData.contractionMonths,
      },
      
      ism_data: {
        dataMonth: report.month,
        manufacturing: {
          pmi: ismData.pmi,
          newOrders: ismData.newOrders,
          production: ismData.production,
          employment: ismData.employment,
          prices: ismData.prices,
          backlog: ismData.backlog,
          inventories: ismData.inventories,
          supplierDeliveries: ismData.supplierDeliveries,
          newExportOrders: ismData.newExportOrders,
          imports: ismData.imports,
          customersInventories: ismData.customersInventories,
        },
        priorMonth: {
          pmi: priorData.pmi,
          newOrders: priorData.newOrders,
          production: priorData.production,
          employment: priorData.employment,
          prices: priorData.prices,
          backlog: priorData.backlog,
          inventories: priorData.inventories,
        },
        momChanges: momChanges,
        dataSource: ismData.dataSource,
        dataQuality: ismData.dataQuality,
      },
      
      mom_changes: momChanges,
      
      what_changed: {
        changes: [
          { component: 'PMI', current: ismData.pmi, prior: priorData.pmi, delta: momChanges.pmi?.delta },
          { component: 'New Orders', current: ismData.newOrders, prior: priorData.newOrders, delta: momChanges.newOrders?.delta },
          { component: 'Employment', current: ismData.employment, prior: priorData.employment, delta: momChanges.employment?.delta },
          { component: 'Prices', current: ismData.prices, prior: priorData.prices, delta: momChanges.prices?.delta },
          { component: 'Backlog', current: ismData.backlog, prior: priorData.backlog, delta: momChanges.backlog?.delta },
          { component: 'Production', current: ismData.production, prior: priorData.production, delta: momChanges.production?.delta },
        ],
      },
      
      trend_analysis: { 
        trends: report.rawData.trends.map(t => ({
          indicator: t.indicator,
          direction: t.direction,
          monthsConsecutive: t.months,
          implication: t.implication,
        })),
        redFlags: [],
      },
      
      sector_impacts: { 
        sectors: report.rawData.sectors.map(s => ({
          rank: s.rank,
          sector: s.sector,
          impactScore: s.impactScore,
          impact: s.direction,
          reasoning: s.reasoning,
          keyQuote: report.rawData.quotes.find(q => q.industry.includes(s.shortName))?.quote || '',
        })),
      },
      
      equity_logic: {
        favorable: report.rawData.equityLogic.favorable.map(f => ({
          trait: f.characteristic,
          importance: 'important',
          ismConnection: f.ismConnection,
        })),
        risky: report.rawData.equityLogic.unfavorable.map(u => ({
          trait: u.characteristic,
          riskLevel: 'high',
          ismConnection: u.ismConnection,
        })),
      },
      
      trade_ideas: { 
        ideas: report.rawData.tradeIdeas.map(t => ({
          direction: t.direction,
          sector: t.sector,
          conviction: t.confidence,
          timeframe: t.execution.timeframe,
          thesis: {
            ismConnection: t.thesis.ismConnection,
            catalysts: [t.thesis.catalyst],
          },
          invalidation: t.invalidation,
        })),
        disclaimer: 'For educational purposes only. Not investment advice.',
      },
      
      quotes_analysis: {
        quotes: report.rawData.quotes,
      },
      industry_quotes: {
        quotes: report.rawData.quotes,
      },
      
      key_divergences: report.rawData.criticalGaps,
      invalidation_scenarios: report.rawData.invalidation,
      next_month_indicators: report.rawData.nextMonth,
      
      rawData: {
        ismData: ismData,
        manufacturing: {
          pmi: ismData.pmi,
          newOrders: ismData.newOrders,
          production: ismData.production,
          employment: ismData.employment,
          prices: ismData.prices,
          backlog: ismData.backlog,
          inventories: ismData.inventories,
        },
        priorMonth: {
          pmi: priorData.pmi,
          newOrders: priorData.newOrders,
          production: priorData.production,
          employment: priorData.employment,
          prices: priorData.prices,
          backlog: priorData.backlog,
        },
        momChanges: momChanges,
      },
    };
    
    console.log('[ISM Router] Building PDF with ISM values:', {
      pmi: ismData.pmi,
      newOrders: ismData.newOrders,
      employment: ismData.employment,
      prices: ismData.prices,
      previousPmi: priorData.pmi || ismData.previousPmi,
      hasPriorData: !!priorData.pmi,
      quotesCount: report.rawData.quotes?.length || 0,
      dataSource: ismData.dataSource,
    });
    
    // Generate PDF
    const pdfBuffer = await generateISMReportPDFBuffer(pdfReportData, null);
    
    // Send PDF
    const filename = `ISM_Manufacturing_Report_${report.month}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.send(pdfBuffer);
    
console.log(`[ISM Router] PDF sent: ${filename} (${(pdfBuffer.length / 1024).toFixed(1)} KB)`);
    
  } catch (error) {
    console.error('[ISM Router] PDF generation error:', error);
    res.status(500).json({ success: false, error: 'Failed to generate PDF: ' + error.message });
  }
});

// DELETE /report/:id - Delete a report
router.delete('/report/:id', (req, res) => {
  try {
    const { id } = req.params;
    
    const report = memoryStore.reports.get(id);
    
    if (!report) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }
    
    const month = report.month;
    
    memoryStore.reports.delete(id);
    memoryStore.progress.delete(id);
    
    console.log(`[ISM Router] 🗑️ Deleted report ${id} for ${month}`);
    
    res.json({
      success: true,
      message: `Report ${id} deleted successfully`,
      deletedMonth: month,
    });
    
  } catch (error) {
    console.error('[ISM Router] Delete error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET /agents
router.get('/agents', (req, res) => {
  res.json({
    success: true,
    data: {
      agents: AGENTS,
      phases: PHASES,
      totalAgents: AGENTS.length,
    },
  });
});

// GET /cache
router.get('/cache', (req, res) => {
  const dataEntries = [];
  const quotesEntries = [];
  
  memoryStore.ismDataCache.forEach((value, key) => {
    const ageMinutes = Math.round((Date.now() - value.timestamp) / 60000);
    dataEntries.push({
      month: key,
      pmi: value.data.pmi,
      dataSource: value.data.dataSource,
      quotesCount: value.data.respondentComments?.length || 0,
      cachedAt: new Date(value.timestamp).toISOString(),
      ageMinutes,
      expiresInMinutes: Math.max(0, 24 * 60 - ageMinutes),
    });
  });
  
  memoryStore.quotesCache.forEach((value, key) => {
    const ageMinutes = Math.round((Date.now() - value.timestamp) / 60000);
    quotesEntries.push({
      month: key,
      quotesCount: value.quotes?.length || 0,
      cachedAt: new Date(value.timestamp).toISOString(),
      ageMinutes,
      expiresInMinutes: Math.max(0, 6 * 60 - ageMinutes),
    });
  });
  
  res.json({
    success: true,
    dataCache: dataEntries,
    quotesCache: quotesEntries,
    totalDataEntries: dataEntries.length,
    totalQuotesEntries: quotesEntries.length,
    dataCacheMaxAgeHours: 24,
    quotesCacheMaxAgeHours: 6,
    mode: 'Dynamic First (ISMDataService → Fallback)',
  });
});

// DELETE /cache
router.delete('/cache', (req, res) => {
  const dataCount = memoryStore.ismDataCache.size;
  const quotesCount = memoryStore.quotesCache.size;
  
  memoryStore.ismDataCache.clear();
  memoryStore.quotesCache.clear();
  
  res.json({
    success: true,
    message: `Cleared ${dataCount} data entries and ${quotesCount} quotes entries`,
  });
});

// POST /refresh - Force refresh data for a month
router.post('/refresh', async (req, res) => {
  try {
    const { month } = req.body;
    const targetMonth = month || getCurrentDataMonth();
    
    // Clear cache for this month
    memoryStore.ismDataCache.delete(targetMonth);
    memoryStore.quotesCache.delete(targetMonth);
    
    console.log(`[ISM Router] 🔄 Force refreshing data for ${targetMonth}`);
    
    // Fetch fresh data
    const ismData = await getISMData(targetMonth);
    
    res.json({
      success: true,
      message: `Refreshed data for ${targetMonth}`,
      data: {
        month: targetMonth,
        pmi: ismData.pmi,
        dataSource: ismData.dataSource,
        quotesCount: ismData.respondentComments?.length || 0,
      },
    });
    
  } catch (error) {
    console.error('[ISM Router] Refresh error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});
// Helper: Get next ISM company report run date
function getNextIsmCompanyRun() {
  const now = new Date();
  const day = now.getDate();
  
  let nextRun;
  if (day < 10) {
    nextRun = new Date(now.getFullYear(), now.getMonth(), 10, 10, 0, 0);
  } else if (day < 20) {
    nextRun = new Date(now.getFullYear(), now.getMonth(), 20, 10, 0, 0);
  } else {
    nextRun = new Date(now.getFullYear(), now.getMonth() + 1, 10, 10, 0, 0);
  }
  
  return nextRun.toISOString();
}

// GET /recommended-tickers - Get ISM-recommended tickers for company reports
router.get('/recommended-tickers', async (req, res) => {
  try {
    const { month } = req.query;
    const targetMonth = month || getCurrentDataMonth();
    
    // Get latest ISM report from memory
    let report = null;
    for (const [id, r] of memoryStore.reports.entries()) {
      if (r.month === targetMonth) {
        report = r;
        break;
      }
    }
    
    if (!report || !report.rawData) {
      return res.json({
        success: true,
        data: {
          month: targetMonth,
          tickers: [],
          message: 'No ISM report available for this month. Generate ISM report first.',
        },
      });
    }
    
    // Extract tickers from trade ideas and sectors
    const tickers = [];
    
    // From trade ideas (long direction only)
    if (report.rawData.tradeIdeas) {
      for (const idea of report.rawData.tradeIdeas) {
        if (idea.direction === 'long' && idea.alternativeStocks) {
          for (const stock of idea.alternativeStocks) {
            tickers.push({
              ticker: stock,
              sector: idea.sector,
              conviction: idea.confidence || 'medium',
              source: 'trade_ideas',
              reasoning: idea.thesis?.ismConnection || '',
            });
          }
        }
      }
    }
    
    // From sector rankings (positive direction only)
    if (report.rawData.sectors) {
      for (const sector of report.rawData.sectors) {
        if (sector.direction === 'positive' && sector.stocks) {
          for (const stock of sector.stocks) {
            // Avoid duplicates
            if (!tickers.find(t => t.ticker === stock)) {
              tickers.push({
                ticker: stock,
                sector: sector.sector || sector.shortName,
                conviction: sector.impactScore > 6 ? 'high' : 'medium',
                source: 'sector_rankings',
                reasoning: `Sector impact score: ${sector.impactScore}/10`,
              });
            }
          }
        }
      }
    }
    
    res.json({
      success: true,
      data: {
        month: targetMonth,
        regime: report.rawData.regime?.name || 'Unknown',
        pmi: report.rawData.ismData?.pmi,
        tickers: tickers.slice(0, 10), // Top 10
        totalAvailable: tickers.length,
      },
    });
    
  } catch (error) {
    console.error('[ISM Router] Recommended tickers error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /company-reports/status - Get status of ISM-triggered company reports
router.get('/company-reports/status', async (req, res) => {
  try {
    const { month, supabase } = req.query;
    const targetMonth = month || getCurrentDataMonth();
    
    // If supabase client is available via req.app, use it
    const db = req.app?.locals?.supabase;
    
    let scheduled = [];
    let completed = [];
    let pending = [];
    
    if (db) {
      // Query from database
      const { data: reports } = await db
        .from('company_reports')
        .select('id, ticker, created_at, status, ism_report_month')
        .eq('is_ism_triggered', true)
        .eq('ism_report_month', targetMonth)
        .order('created_at', { ascending: false });
      
      if (reports) {
        completed = reports.filter(r => r.status === 'completed');
        pending = reports.filter(r => r.status === 'pending' || r.status === 'generating');
      }
    }
    
    res.json({
      success: true,
      data: {
        month: targetMonth,
        scheduled: scheduled.length,
        completed: completed.length,
        pending: pending.length,
        reports: [...completed, ...pending],
        nextScheduledRun: getNextIsmCompanyRun(),
        cronSchedule: '10th and 20th of each month at 10:00 AM Israel time',
      },
    });
    
  } catch (error) {
    console.error('[ISM Router] Company reports status error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /company-reports/trigger - Manually trigger ISM company reports
router.post('/company-reports/trigger', async (req, res) => {
  try {
    const { month, count = 1, ticker } = req.body;
    const targetMonth = month || getCurrentDataMonth();
    
    console.log(`[ISM Router] 🏭 Manual trigger: ${count} company report(s) for ${targetMonth}`);
    
    // Get ISM report
    let report = null;
    for (const [id, r] of memoryStore.reports.entries()) {
      if (r.month === targetMonth) {
        report = r;
        break;
      }
    }
    
    if (!report && !ticker) {
      return res.status(400).json({
        success: false,
        error: 'No ISM report available for this month. Generate ISM report first, or specify a ticker.',
      });
    }
    
    let selectedTickers = [];
    
    // If specific ticker requested
    if (ticker) {
      selectedTickers = [ticker];
    } else {
      // Extract top tickers from ISM report
      if (report.rawData.tradeIdeas) {
        for (const idea of report.rawData.tradeIdeas) {
          if (idea.direction === 'long' && idea.alternativeStocks) {
            selectedTickers.push(...idea.alternativeStocks.slice(0, 2));
          }
        }
      }
      selectedTickers = [...new Set(selectedTickers)].slice(0, count);
    }
    
    if (selectedTickers.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No tickers found in ISM report trade ideas',
      });
    }
    
    // Try to add to Company Scheduler queue if available
    const companyScheduler = req.app?.locals?.companyScheduler;
    let queued = [];
    
    if (companyScheduler) {
      for (const t of selectedTickers) {
        try {
          const result = await companyScheduler.addToQueue(t, {
            priority: 'high',
            requestedBy: 'ism_manual_trigger',
            includeIsm: true,
          });
          if (result.success) {
            queued.push({ ticker: t, queueId: result.queueId });
          }
        } catch (err) {
          console.warn(`[ISM Router] Failed to queue ${t}:`, err.message);
        }
      }
    }
    
    res.json({
      success: true,
      message: `${queued.length > 0 ? 'Queued' : 'Selected'} ${selectedTickers.length} company report(s)`,
      data: {
        month: targetMonth,
        regime: report?.rawData?.regime?.name,
        pmi: report?.rawData?.ismData?.pmi,
        tickers: selectedTickers,
        queued: queued,
        nextScheduledRun: getNextIsmCompanyRun(),
        note: queued.length > 0 
          ? 'Reports added to queue and will be processed shortly'
          : 'Company Scheduler not available. Reports will be generated on next scheduled run (10th or 20th)',
      },
    });
    
  } catch (error) {
    console.error('[ISM Router] Trigger company reports error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;