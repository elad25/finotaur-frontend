// src/types/routes.d.ts
// Type declarations for JavaScript route files

declare module "*/routes/overview/filings.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}

declare module "*/routes/overview/reference.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}

declare module "*/routes/polygon.aggs.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}

declare module "*/routes/newsletter.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}

declare module "*/routes/secProxy.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}

declare module "*/routes/crypto.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}

declare module "*/routes/stocks.js" {
  import { Router } from "express";
  const router: Router;
  export default router;
}