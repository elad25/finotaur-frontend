import { Router } from "express";
import fetch from "node-fetch";

const router = Router();

// Helper to fetch JSON safely
async function j(url: string) {
  const r = await fetch(url, { timeout: 20000 as any });
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return r.json();
}

// Expect process.env.SEC_PROXY_URL to expose standardized SEC JSON:
// /financials?symbol=TSLA&statement=income|balance|cashflow&tf=Quarterly|Annual&limit=8
router.get("/all", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "").toUpperCase();
    const tf = (String(req.query.tf || "Quarterly") as "Quarterly" | "Annual");
    const periods = Math.min(parseInt(String(req.query.periods || "8"), 10) || 8, 12);
    if (!symbol) return res.status(400).json({ error: "symbol required" });

    const base = process.env.SEC_PROXY_URL || "http://localhost:8787";
    const qs = (stmt: string) => `${base}/financials?symbol=${encodeURIComponent(symbol)}&statement=${stmt}&tf=${tf}&limit=${periods}`;
    // Fetch in parallel
    const [income, balance, cashflow] = await Promise.all([
      j(qs("income")), j(qs("balance")), j(qs("cashflow"))
    ]);

    // Normalize into blocks: [{name, unit, series:[{date,value}...]}]
    const norm = (obj: any) => {
      // Expect obj like { statement:"income", unit:"USD", series: [{date: '2024-Q4', Revenue:123, NetIncome:..}, ...] }
      // We'll transform columns into per-metric arrays.
      if (!obj || !Array.isArray(obj.series)) return [];
      const rows = obj.series;
      const metricNames = Object.keys(rows[0] || {}).filter(k => k !== "date");
      return metricNames.map(name => ({
        name,
        unit: obj.unit || "USD",
        series: rows.map((row: any) => ({ date: row.date, value: row[name] ?? null })),
      }));
    };

    const payload = {
      symbol,
      tf,
      periods,
      income: norm(income),
      balance: norm(balance),
      cashflow: norm(cashflow),
      ai: { summary: income?.aiSummary || "" }
    };
    res.json(payload);
  } catch (e:any) {
    res.status(500).json({ error: e.message || "server error" });
  }
});

export default router;
