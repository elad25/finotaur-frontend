// finotaur-server/src/routes/_fundamentals-normalized-shared.ts
import type { Request, Response } from "express";
import { getTickerDetails, getAggs, getFinancials } from "../services/providers/polygon";

export async function handleFundamentalsAll(req: Request, res: Response) {
  try {
    const symbol = String(req.query.symbol || "").toUpperCase();
    const tf = (String(req.query.tf || "TTM") as "TTM" | "Annual" | "Quarterly");
    const periods = Number(req.query.periods || 10);
    if (!symbol) return res.status(400).json({ error: "symbol is required" });

    // Context from Polygon reference
    const tick = await getTickerDetails(symbol).catch(() => null);
    const name = tick?.results?.name || symbol;
    const logoUrl = tick?.results?.branding?.logo_url || null;
    const sectorName = tick?.results?.sic_description || tick?.results?.sector || null;
    const industry = tick?.results?.industry || null;

    // Price via Aggs (prev close within last week)
    let price: number | null = null;
    try {
      const today = new Date();
      const to = today.toISOString().slice(0, 10);
      const y = new Date(today.getTime() - 86400000 * 7);
      const from = y.toISOString().slice(0, 10);
      const aggs = await getAggs(symbol, "day", from, to);
      const last = Array.isArray(aggs?.results) ? aggs.results[aggs.results.length - 1] : null;
      price = typeof last?.c === "number" ? last.c : null;
    } catch { price = null; }

    // Financials (fallback when SEC not wired)
    const fin = await getFinancials(symbol, periods).catch(() => ({ results: [] }));
    const rows: any[] = fin?.results || [];

    const mapSeries = (key: string) =>
      rows.map((r: any) => ({
        date: r.end_date || r.fiscal_period || r.fiscal_year,
        value: Number(r?.financials?.income_statement?.[key]?.value ?? null) || null
      })).filter((p) => p.value !== null);

    const rev = mapSeries("revenues");
    const ni  = mapSeries("net_income_loss");

    const grossMargin =
      Number(rows?.[0]?.financials?.income_statement?.gross_profit_ratio?.value ?? null) || null;
    const operatingMargin =
      Number(rows?.[0]?.financials?.income_statement?.operating_income_ratio?.value ?? null) || null;
    const netMargin =
      Number(rows?.[0]?.financials?.income_statement?.net_income_ratio?.value ?? null) || null;

    const shares =
      Number(rows?.[0]?.financials?.income_statement?.weighted_average_diluted_shares_outstanding?.value ?? null) ||
      Number(rows?.[0]?.financials?.income_statement?.weighted_average_shares_outstanding_basic?.value ?? null) ||
      null;

    const marketCap = (price != null && shares != null) ? price * shares : null;

    const kpis = {
      price,
      marketCap,
      revenueTTM: rev?.[0]?.value ?? null,
      netIncomeTTM: ni?.[0]?.value ?? null,
      grossMargin,
      operatingMargin,
      netMargin,
      roe: null, roa: null, debtToEquity: null, currentRatio: null, quickRatio: null
    };

    const trends = {
      revenue: rev,
      netIncome: ni,
      margins: [],
      debt: [], equity: [], cashflows: []
    };

    const payload = {
      symbol, tf, periods,
      ai: { summary: null },
      fairValue: null,
      kpis,
      trends,
      valuation: {},
      health: null,
      peers: [],
      context: { name, ticker: symbol, logoUrl, sector: sectorName, industry }
    };

    return res.json(payload);
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || "server error" });
  }
}