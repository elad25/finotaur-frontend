// src/routes/overview-subroutes.js (ESM) — v3
// Exposes: /api/overview/price, /events, /analyst, /about, /header

import express from 'express';

const router = express.Router();

const cache = new Map();
const TTL_MS = 60 * 1000;
const ckey = (name, params) => name + ":" + JSON.stringify(params || {});

const normalizeTs = (t) => {
  let ts = Number(t ?? 0);
  if (!Number.isFinite(ts)) return NaN;
  if (ts < 1e11) ts = ts * 1000; // seconds -> ms
  return ts;
};

const probe = async (urls) => {
  for (const u of urls) {
    try {
      const r = await fetch(u);
      if (r.ok) return await r.json();
    } catch {}
  }
  return null;
};

router.get('/price', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || '').toUpperCase();
    const tf = String(req.query.tf || '6M');
    if (!symbol) return res.status(400).json({ error: 'symbol_required' });

    const k = ckey('price', { symbol, tf });
    const hit = cache.get(k);
    if (hit && Date.now() - hit.ts < TTL_MS) return res.json(hit.data);

    const base = `${req.protocol}://${req.get('host')}`;
    const raw = await probe([
      `${base}/api/chart/series?symbol=${encodeURIComponent(symbol)}&range=${encodeURIComponent(tf)}`,
      `${base}/api/polygon/aggs?symbol=${encodeURIComponent(symbol)}&range=${encodeURIComponent(tf)}`,
      `${base}/api/price/history?symbol=${encodeURIComponent(symbol)}&range=${encodeURIComponent(tf)}`,
    ]);

    let rows = [];
    if (Array.isArray(raw)) rows = raw;
    else if (raw?.series) rows = raw.series;
    else if (raw?.results) rows = raw.results;

    const series = rows
      .map(d => ({ t: normalizeTs(d.t ?? d.time ?? d.timestamp ?? d[0]), c: Number(d.c ?? d.close ?? d[1]) }))
      .filter(p => Number.isFinite(p.t) && Number.isFinite(p.c))
      .sort((a,b)=>a.t-b.t);

    const payload = { series };
    cache.set(k, { ts: Date.now(), data: payload });
    res.json(payload);
  } catch (e) {
    res.status(500).json({ error: 'price_failed', message: e?.message });
  }
});

router.get('/events', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || '').toUpperCase();
    if (!symbol) return res.status(400).json({ error: 'symbol_required' });

    const k = ckey('events', { symbol });
    const hit = cache.get(k);
    if (hit && Date.now() - hit.ts < TTL_MS) return res.json(hit.data);

    const base = `${req.protocol}://${req.get('host')}`;
    const r = await fetch(`${base}/api/sec/filings?symbol=${encodeURIComponent(symbol)}&forms=annual,quarterly&limit=30`);
    const j = r.ok ? await r.json() : { filings: [] };

    const events = (j.filings || []).map(f => ({
      form: f.form,
      filingDate: f.filingDate,
      reportDate: f.reportDate,
    }));

    const payload = { events };
    cache.set(k, { ts: Date.now(), data: payload });
    res.json(payload);
  } catch (e) {
    res.status(500).json({ error: 'events_failed', message: e?.message });
  }
});

router.get('/analyst', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || '').toUpperCase();
    if (!symbol) return res.status(400).json({ error: 'symbol_required' });

    const k = ckey('analyst', { symbol });
    const hit = cache.get(k);
    if (hit && Date.now() - hit.ts < TTL_MS) return res.json(hit.data);

    const base = `${req.protocol}://${req.get('host')}`;
    const r = await fetch(`${base}/api/fundamentals/all?symbol=${encodeURIComponent(symbol)}`);
    const j = r.ok ? await r.json() : {};
    const a = j?.analyst || {};

    const payload = {
      buy: a.buy ?? 0,
      hold: a.hold ?? 0,
      sell: a.sell ?? 0,
      targetAvg: a.targetAvg ?? null,
      targetHigh: a.targetHigh ?? null,
      targetLow: a.targetLow ?? null,
    };
    cache.set(k, { ts: Date.now(), data: payload });
    res.json(payload);
  } catch (e) {
    res.status(500).json({ error: 'analyst_failed', message: e?.message });
  }
});

router.get('/about', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || '').toUpperCase();
    if (!symbol) return res.status(400).json({ error: 'symbol_required' });

    const k = ckey('about', { symbol });
    const hit = cache.get(k);
    if (hit && Date.now() - hit.ts < TTL_MS) return res.json(hit.data);

    const base = `${req.protocol}://${req.get('host')}`;
    const r = await fetch(`${base}/api/fundamentals/all?symbol=${encodeURIComponent(symbol)}`);
    const j = r.ok ? await r.json() : {};
    const p = j?.profile || {};

    const payload = {
      name: p.name ?? null,
      description: p.description ?? null,
      exchange: p.exchange ?? null,
      industry: p.industry ?? null,
      source: "SEC EDGAR",
    };
    cache.set(k, { ts: Date.now(), data: payload });
    res.json(payload);
  } catch (e) {
    res.status(500).json({ error: 'about_failed', message: e?.message });
  }
});

router.get('/header', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || '').toUpperCase();
    if (!symbol) return res.status(400).json({ error: 'symbol_required' });

    const k = ckey('header', { symbol });
    const hit = cache.get(k);
    if (hit && Date.now() - hit.ts < TTL_MS) return res.json(hit.data);

    const base = `${req.protocol}://${req.get('host')}`;
    const r = await fetch(`${base}/api/fundamentals/all?symbol=${encodeURIComponent(symbol)}`);
    const j = r.ok ? await r.json() : {};
    const s = j?.snapshot || j || {};

    const payload = {
      price: s.price ?? null,
      changePct: s.changePct ?? null,
      marketCap: s.marketCap ?? null,
      peTTM: s.peTTM ?? null,
      peFwd: s.peFwd ?? null,
      beta: s.beta ?? null,
      dividendYield: s.dividendYield ?? null,
      avgVolume: s.avgVolume ?? null,
      fiftyTwoWkLow: s.fiftyTwoWkLow ?? null,
      fiftyTwoWkHigh: s.fiftyTwoWkHigh ?? null,
    };
    cache.set(k, { ts: Date.now(), data: payload });
    res.json(payload);
  } catch (e) {
    res.status(500).json({ error: 'header_failed', message: e?.message });
  }
});

export default router;
