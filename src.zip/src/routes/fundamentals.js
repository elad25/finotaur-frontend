/**
 * Finotaur Fundamentals Aggregator
 * Route: GET /api/fundamentals/all?symbol=TSLA
 * - Merges SEC (companyfacts + recent filings) with Polygon (market cap / price)
 * - Caches per-symbol in-memory for 30 minutes
 * - Does NOT modify or interfere with other routes
 */
const express = require('express');
const fetch = require('node-fetch');
const router = express.Router();

// Basic in-memory cache
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes
const cache = new Map(); // key: symbol, value: { t: timestamp, data }

function setCache(key, data) {
  cache.set(key.toUpperCase(), { t: Date.now(), data });
}
function getCache(key) {
  const hit = cache.get(key.toUpperCase());
  if (!hit) return null;
  if (Date.now() - hit.t > CACHE_TTL_MS) {
    cache.delete(key.toUpperCase());
    return null;
  }
  return hit.data;
}

// Helpers
const SEC_PROXY = process.env.SEC_PROXY_URL || '';
const POLY_KEY = process.env.POLYGON_API_KEY || '';

async function safeJson(res) {
  const txt = await res.text();
  try { return JSON.parse(txt); } catch(e) { return { _raw: txt }; }
}

async function resolveCIKFromSEC(symbol) {
  // Use SEC company_tickers JSON via proxy (already used elsewhere in the app)
  const urls = [
    `${SEC_PROXY}/api/sec/files/company_tickers.json`,
    `${SEC_PROXY}/api/sec/files/company_tickers_exchange.json`
  ];
  for (const u of urls) {
    try {
      const r = await fetch(u, { timeout: 15000 });
      if (!r.ok) continue;
      const j = await r.json();
      // company_tickers.json is an array with objects containing "cik_str" and "ticker"
      if (Array.isArray(j)) {
        const match = j.find(x => (x.ticker || '').toUpperCase() === symbol.toUpperCase());
        if (match) return String(match.cik_str).padStart(10, '0');
      } else if (j && j.data) { // exchange variant table-ish
        const rec = j.data.find(x => (x.ticker || '').toUpperCase() === symbol.toUpperCase());
        if (rec && rec.cik) return String(rec.cik).padStart(10, '0');
      }
    } catch(e) { /*ignore and try next*/ }
  }
  return null;
}

async function fetchSECCompanyFacts(cik) {
  const url = `${SEC_PROXY}/api/sec/companyfacts?cik=${cik}`;
  const res = await fetch(url, { timeout: 20000 });
  if (!res.ok) throw new Error(`SEC companyfacts ${res.status}`);
  return await safeJson(res);
}

async function fetchSECSubmissions(cik) {
  const url = `${SEC_PROXY}/api/sec/submissions?cik=${cik}`;
  const res = await fetch(url, { timeout: 20000 });
  if (!res.ok) throw new Error(`SEC submissions ${res.status}`);
  return await safeJson(res);
}

async function fetchPolygonReference(symbol) {
  // limit Polygon calls to once; use reference/tickers for market cap, branding, etc.
  if (!POLY_KEY) return null;
  const url = `https://api.polygon.io/v3/reference/tickers/${symbol.toUpperCase()}?apiKey=${POLY_KEY}`;
  const res = await fetch(url, { timeout: 15000 });
  if (!res.ok) return null;
  const j = await safeJson(res);
  return j && j.results ? j.results : null;
}

function latestValue(series = []) {
  // SEC series entries have {val, fy, fp, end, ...}; pick most recent by 'end'
  const sorted = [...series].filter(Boolean).sort((a,b) => new Date(b.end||0) - new Date(a.end||0));
  return sorted[0] || null;
}

function ttmFromQuarterly(series = [], labelIncludes = []) {
  // sum last 4 quarters; optionally filter by label string includes
  const q = [...series]
    .filter(x => x && (x.fp === 'Q1' || x.fp === 'Q2' || x.fp === 'Q3' || x.fp === 'Q4'))
    .filter(x => labelIncludes.length === 0 || labelIncludes.some(s => (x.form || '').includes(s)))
    .sort((a,b) => new Date(b.end||0) - new Date(a.end||0))
    .slice(0, 4);
  const sum = q.reduce((acc, x) => acc + (Number(x.val) || 0), 0);
  const end = q[0]?.end;
  return { value: sum, end, items: q };
}

function pct(a, b) {
  if (!Number.isFinite(a) || !Number.isFinite(b) || b === 0) return null;
  return ((a - b) / Math.abs(b)) * 100;
}

function miniTrend(series = [], n = 5) {
  const s = [...series].sort((a,b) => new Date(a.end||0) - new Date(b.end||0));
  const pts = s.slice(-n).map(x => ({ x: x.end, y: Number(x.val) || 0 }));
  return pts;
}

function pickFact(facts, usgaapKey) {
  const node = facts?.facts?.['us-gaap']?.[usgaapKey];
  if (!node || !Array.isArray(node.units)) return { series: [] };
  // find USD units first
  const units = node.units['USD'] || node.units[Object.keys(node.units)[0]] || [];
  return { series: units };
}

function deriveRatios(secFacts) {
  const revenue = pickFact(secFacts, 'RevenueFromContractWithCustomerExcludingAssessedTax').series;
  const ni = pickFact(secFacts, 'NetIncomeLoss').series;
  const equity = pickFact(secFacts, 'StockholdersEquity').series;
  const assets = pickFact(secFacts, 'Assets').series;
  const liabilities = pickFact(secFacts, 'Liabilities').series;
  const grossProfit = pickFact(secFacts, 'GrossProfit').series;
  const currentAssets = pickFact(secFacts, 'AssetsCurrent').series;
  const currentLiab = pickFact(secFacts, 'LiabilitiesCurrent').series;
  const debt = pickFact(secFacts, 'LongTermDebt').series;

  const revenueTTM = ttmFromQuarterly(revenue);
  const niTTM = ttmFromQuarterly(ni);
  const gpTTM = ttmFromQuarterly(grossProfit);

  const grossMargin = (gpTTM.value && revenueTTM.value) ? (gpTTM.value / revenueTTM.value) : null;
  // For ROE/ROA, use latest annual value
  const eqLatest = Number(latestValue(equity)?.val) || null;
  const assetsLatest = Number(latestValue(assets)?.val) || null;
  const niLatest = Number(latestValue(ni)?.val) || null;

  const roe = (niLatest && eqLatest) ? (niLatest / eqLatest) : null;
  const roa = (niLatest && assetsLatest) ? (niLatest / assetsLatest) : null;
  const currentRatio = (Number(latestValue(currentAssets)?.val) || 0) / ((Number(latestValue(currentLiab)?.val) || 0) || 1);
  const debtEquity = (Number(latestValue(debt)?.val) || 0) / ((eqLatest || 1));

  return {
    revenueTTM,
    netIncomeTTM: niTTM,
    grossMargin,
    roe,
    roa,
    currentRatio,
    debtEquity,
    trends: {
      revenue: miniTrend(revenue),
      netIncome: miniTrend(ni),
      debt: miniTrend(debt),
      equity: miniTrend(equity),
      grossProfit: miniTrend(grossProfit),
    }
  };
}

router.get('/all', async (req, res) => {
  try {
    const symbol = (req.query.symbol || '').toUpperCase().trim();
    if (!symbol) return res.status(400).json({ error: 'symbol is required' });

    const cached = getCache(symbol);
    if (cached) return res.json(cached);

    const cik = await resolveCIKFromSEC(symbol);
    if (!cik) return res.status(404).json({ error: 'CIK not found for symbol', symbol });

    const [facts, subs, poly] = await Promise.all([
      fetchSECCompanyFacts(cik).catch(() => null),
      fetchSECSubmissions(cik).catch(() => null),
      fetchPolygonReference(symbol).catch(() => null),
    ]);

    const ratios = deriveRatios(facts || {});

    // Market cap from Polygon (fallback to null)
    const marketCap = poly?.market_cap ?? null;
    const companyName = poly?.name ?? (subs?.name || symbol);

    // YoY deltas (TTM vs prior 4 quarters)
    const revSeries = pickFact(facts, 'RevenueFromContractWithCustomerExcludingAssessedTax').series
      .sort((a,b)=> new Date(b.end||0) - new Date(a.end||0));
    const last8 = revSeries.slice(0,8);
    const latest4 = last8.slice(0,4).reduce((a,x)=>a+(Number(x.val)||0),0);
    const prev4 = last8.slice(4,8).reduce((a,x)=>a+(Number(x.val)||0),0);
    const revenueYoY = pct(latest4, prev4);

    const niSeries = pickFact(facts, 'NetIncomeLoss').series
      .sort((a,b)=> new Date(b.end||0) - new Date(a.end||0));
    const niLatest4 = niSeries.slice(0,4).reduce((a,x)=>a+(Number(x.val)||0),0);
    const niPrev4 = niSeries.slice(4,8).reduce((a,x)=>a+(Number(x.val)||0),0);
    const netIncomeYoY = pct(niLatest4, niPrev4);

    const payload = {
      symbol,
      cik,
      companyName,
      marketCap,
      sources: {
        sec: !!facts,
        polygon: !!poly,
      },
      snapshot: {
        marketCap,
        revenueTTM: ratios.revenueTTM.value || null,
        netIncomeTTM: ratios.netIncomeTTM.value || null,
        grossMargin: ratios.grossMargin,
        roe: ratios.roe,
        roa: ratios.roa,
        debtEquity: ratios.debtEquity,
        currentRatio: ratios.currentRatio,
        yoy: { revenue: revenueYoY, netIncome: netIncomeYoY },
        sparks: {
          revenue: ratios.trends.revenue,
          netIncome: ratios.trends.netIncome,
          debt: ratios.trends.debt,
          equity: ratios.trends.equity,
        }
      },
      statements: {
        // Pass-through for frontend tables; keep compact (frontend can format)
        facts: facts?.facts || null,
        submissions: subs || null
      },
      lastUpdated: new Date().toISOString()
    };

    setCache(symbol, payload);
    return res.json(payload);
  } catch (e) {
    console.error('[fundamentals/all] error', e);
    return res.status(500).json({ error: 'internal', message: e.message });
  }
});

module.exports = router;
