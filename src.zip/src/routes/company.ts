
import express from "express";
import type { Request, Response } from "express";
import fetch from "node-fetch";

const router = express.Router();

const POLY = process.env.POLYGON_API_KEY || "";
const TTL_MS = 1000 * 60 * 30;
const cache = new Map<string, { at: number; data: any }>();

function ok(data: any) {
  return { ok: true, data };
}

router.get("/profile", async (req: Request, res: Response) => {
  try {
    const symbol = String(req.query.symbol || "").toUpperCase();
    if (!symbol) return res.status(400).json({ ok: false, error: "symbol required" });
    const key = `company:profile:${symbol}`;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.at < TTL_MS) return res.json(ok(hit.data));

    // Polygon reference ticker for name, branding (logo), market cap
    // We keep soft-fail guards so page continues to render without this data.
    let name = symbol;
    let ticker = symbol;
    let logoUrl: string | null = null;
    let marketCap: number | null = null;

    if (POLY) {
      const url = `https://api.polygon.io/v3/reference/tickers/${symbol}?apiKey=${POLY}`;
      const r = await fetch(url);
      if (r.ok) {
        const j = await r.json();
        const t = j?.results ?? {};
        name = t.name || symbol;
        ticker = t.ticker || symbol;
        marketCap = t.market_cap ?? null;
        if (t.branding?.logo_url) logoUrl = `${t.branding.logo_url}?apiKey=${POLY}`;
      }
    }

    const out = { name, ticker, logoUrl, marketCap };
    cache.set(key, { at: Date.now(), data: out });
    res.json(ok(out));
  } catch (err: any) {
    res.status(200).json(ok({ name: String(req.query.symbol || ""), ticker: String(req.query.symbol || ""), logoUrl: null, marketCap: null }));
  }
});

export default router;
