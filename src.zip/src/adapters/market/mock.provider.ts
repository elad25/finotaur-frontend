export function ping() { return { ok: true, ts: Date.now() }; }
