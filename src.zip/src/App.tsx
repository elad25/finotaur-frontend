import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/providers/AuthProvider";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { ProtectedAppLayout } from "@/layouts/ProtectedAppLayout";
import LandingPage from "@/pages/landing/LandingPage";
import Login from "@/pages/auth/Login";
import Register from "@/pages/auth/Register";
import Settings from "@/pages/Settings";
import NotFound from "./pages/NotFound";

// === Heatmap page (explicit routes use this) ===
import HeatmapPage from "@/pages/HeatmapPage";

// All Markets
import AllMarketsOverview from "@/pages/app/all-markets/Overview";
import AllMarketsChart from "@/pages/app/all-markets/Chart";
import AllMarketsSummary from "@/pages/app/all-markets/Summary";
import AllMarketsMovers from "@/pages/app/all-markets/Movers";
import AllMarketsSentiment from "@/pages/app/all-markets/Sentiment";
import AllMarketsCalendar from "@/pages/app/all-markets/Calendar";
import AllMarketsNews from "@/pages/app/all-markets/News";

// Stocks
import StocksOverview from "@/pages/app/stocks/Overview";
import StocksScreener from "@/pages/app/stocks/Screener";
import StocksEarnings from "@/pages/app/stocks/Earnings";
import StocksFundamentals from "@/pages/app/stocks/Fundamentals";
import StocksMovers from "@/pages/app/stocks/Movers";
import StocksNews from "@/pages/app/stocks/News";
import StocksSectors from "@/pages/app/stocks/Sectors";
import StocksCatalysts from "@/pages/app/stocks/Catalysts";
import StocksUpgrades from "@/pages/app/stocks/Upgrades";
import StocksValuation from "@/pages/app/stocks/Valuation";
import StocksReports from "@/pages/app/stocks/Reports";
import StocksWatchlists from "@/pages/app/stocks/Watchlists";

// Crypto
import CryptoOverview from "@/pages/app/crypto/Overview";
import CryptoTopCoins from "@/pages/app/crypto/TopCoins";
import CryptoOnChain from "@/pages/app/crypto/OnChain";
import CryptoHeatmap from "@/pages/app/crypto/Heatmap";
import CryptoNews from "@/pages/app/crypto/News";
import CryptoCatalysts from "@/pages/app/crypto/Catalysts";
import CryptoExchanges from "@/pages/app/crypto/Exchanges";
import CryptoMovers from "@/pages/app/crypto/Movers";
import CryptoReports from "@/pages/app/crypto/Reports";
import CryptoCalendar from "@/pages/app/crypto/Calendar";

// Futures
import FuturesOverview from "@/pages/app/futures/Overview";
import FuturesOpenInterests from "@/pages/app/futures/OpenInterests";
import FuturesCalendar from "@/pages/app/futures/Calendar";

// Forex
import ForexOverview from "@/pages/app/forex/Overview";
import ForexStrength from "@/pages/app/forex/Strength";
import ForexCorrelation from "@/pages/app/forex/Correlation";
import ForexCalendar from "@/pages/app/forex/Calendar";
import ForexPairs from "@/pages/app/forex/Pairs";
import ForexRates from "@/pages/app/forex/Rates";
import ForexDeepAnalysis from "@/pages/app/forex/DeepAnalysis";
import ForexAlerts from "@/pages/app/forex/Alerts";

// Commodities
import CommoditiesOverview from "@/pages/app/commodities/Overview";
import CommoditiesScreener from "@/pages/app/commodities/Screener";
import CommoditiesCatalysts from "@/pages/app/commodities/Catalysts";
import CommoditiesEnergy from "@/pages/app/commodities/Energy";
import CommoditiesMetals from "@/pages/app/commodities/Metals";
import CommoditiesAgriculture from "@/pages/app/commodities/Agriculture";
import CommoditiesSeasonality from "@/pages/app/commodities/Seasonality";
import CommoditiesReports from "@/pages/app/commodities/Reports";
import CommoditiesCalendar from "@/pages/app/commodities/Calendar";

import ForexNews from "@/pages/app/forex/News";

import CommoditiesNews from "@/pages/app/commodities/News";

import MacroNews from "@/pages/app/macro/News";

// Macro
import MacroOverview from "@/pages/app/macro/Overview";
import MacroCalendar from "@/pages/app/macro/Calendar";
import MacroRates from "@/pages/app/macro/Rates";
import MacroIndicators from "@/pages/app/macro/Indicators";
import MacroEvents from "@/pages/app/macro/Events";
import MacroReports from "@/pages/app/macro/Reports";
import MacroSentiment from "@/pages/app/macro/Sentiment";

import OptionsChain from "@/pages/app/options/Chain";
import OptionsFlow from "@/pages/app/options/Flow";
import OptionsVolatility from "@/pages/app/options/Volatility";
import OptionsStrategy from "@/pages/app/options/Strategy";
import OptionsSimulator from "@/pages/app/options/Simulator";
import OptionsGreeksMonitor from "@/pages/app/options/GreeksMonitor";
import OptionsIvRank from "@/pages/app/options/IVRank";
import OptionsOIVolume from "@/pages/app/options/OIVolume";
import OptionsUnusualActivity from "@/pages/app/options/UnusualActivity";
import OptionsEarningsIVCrush from "@/pages/app/options/EarningsIVCrush";
import OptionsShortcuts from "@/pages/app/options/Shortcuts";

// AI
import AIOverview from "@/pages/app/ai/Overview";
import AIDigest from "@/pages/app/ai/Digest";
import AISentiment from "@/pages/app/ai/Sentiment";
import AIForecasts from "@/pages/app/ai/Forecasts";
import AIRisk from "@/pages/app/ai/Risk";
import AIPatterns from "@/pages/app/ai/Patterns";
import AIReports from "@/pages/app/ai/Reports";
import AIAlerts from "@/pages/app/ai/Alerts";
import AIBacktesting from "@/pages/app/ai/Backtesting";

// Journal
import JournalOverview from "@/pages/app/journal/Overview";
import JournalMyTrades from "@/pages/app/journal/MyTrades";
import JournalNew from "@/pages/app/journal/New";
import JournalTradeDetail from "@/pages/app/journal/TradeDetail";
import JournalImport from "@/pages/app/journal/Import";
import JournalExport from "@/pages/app/journal/Export";
import JournalNotes from "@/pages/app/journal/Notes";
import JournalAnalytics from "@/pages/app/journal/Analytics";
import JournalAIReview from "@/pages/app/journal/AIReview";
import JournalCalendar from "@/pages/app/journal/Calendar";
import JournalPerformance from "@/pages/app/journal/Performance";

// Copy Trade
import CopyTradeOverview from "@/pages/app/copy-trade/Overview";
import CopyTradeTopTraders from "@/pages/app/copy-trade/TopTraders";
import CopyTradeStrategies from "@/pages/app/copy-trade/Strategies";
import CopyTradePortfolios from "@/pages/app/copy-trade/Portfolios";
import CopyTradeLeaderboard from "@/pages/app/copy-trade/Leaderboard";
import CopyTradeMyCopying from "@/pages/app/copy-trade/MyCopying";
import CopyTradeInsights from "@/pages/app/copy-trade/Insights";

// Funding
import FundingOverview from "@/pages/app/funding/Overview";
import FundingBrokers from "@/pages/app/funding/Brokers";
import FundingAdvance from "@/pages/app/funding/Advance";
import FundingTransactions from "@/pages/app/funding/Transactions";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/auth/login" element={<Login />} />
            <Route path="/auth/register" element={<Register />} />
            
            <Route path="/app" element={<ProtectedRoute><ProtectedAppLayout /></ProtectedRoute>}>
              <Route index element={<Navigate to="/app/all-markets/overview" replace />} />

              {/* ==== HEATMAP (explicit routes) ==== */}
              <Route path="stocks/heatmap" element={<HeatmapPage market="stocks" />} />
              <Route path="crypto/heatmap" element={<HeatmapPage market="crypto" />} />
              <Route path="futures/heatmap" element={<HeatmapPage market="futures" />} />
              <Route path="forex/heatmap" element={<HeatmapPage market="forex" />} />
              <Route path="commodities/heatmap" element={<HeatmapPage market="commodities" />} />
              <Route path="indices/heatmap" element={<HeatmapPage market="indices" />} />
              {/* legacy redirect */}
              <Route path="all-markets/heatmap" element={<HeatmapPage />} />

              {/* All Markets */}
              <Route path="all-markets/overview" element={<AllMarketsOverview />} />
              <Route path="all-markets/chart" element={<AllMarketsChart />} />
              <Route path="all-markets/summary" element={<AllMarketsSummary />} />
              <Route path="all-markets/movers" element={<AllMarketsMovers />} />
              <Route path="all-markets/sentiment" element={<AllMarketsSentiment />} />
              <Route path="all-markets/calendar" element={<AllMarketsCalendar />} />
              <Route path="all-markets/news" element={<AllMarketsNews />} />
              
              {/* Options */}
              <Route path="options" element={<Navigate to="/app/options/chain" replace />} />
              <Route path="options/chain" element={<OptionsChain />} />
              <Route path="options/flow" element={<OptionsFlow />} />
              <Route path="options/volatility" element={<OptionsVolatility />} />
              <Route path="options/strategy" element={<OptionsStrategy />} />
              <Route path="options/simulator" element={<OptionsSimulator />} />
              {/* Options sidebar pages */}
              <Route path="options/greeks-monitor" element={<OptionsGreeksMonitor />} />
              <Route path="options/iv-rank" element={<OptionsIvRank />} />
              <Route path="options/oi-volume" element={<OptionsOIVolume />} />
              <Route path="options/unusual-activity" element={<OptionsUnusualActivity />} />
              <Route path="options/earnings-iv-crush" element={<OptionsEarningsIVCrush />} />
              <Route path="options/shortcuts" element={<OptionsShortcuts />} />

              {/* Stocks */}
              <Route path="stocks/overview" element={<StocksOverview />} />
              <Route path="stocks/screener" element={<StocksScreener />} />
              <Route path="stocks/earnings" element={<StocksEarnings />} />
              <Route path="stocks/fundamentals" element={<StocksFundamentals />} />
              <Route path="stocks/movers" element={<StocksMovers />} />
              <Route path="stocks/news" element={<StocksNews />} />
              <Route path="stocks/sectors" element={<StocksSectors />} />
              <Route path="stocks/catalysts" element={<StocksCatalysts />} />
              <Route path="stocks/upgrades" element={<StocksUpgrades />} />
              <Route path="stocks/valuation" element={<StocksValuation />} />
              <Route path="stocks/reports" element={<StocksReports />} />
              <Route path="stocks/watchlists" element={<StocksWatchlists />} />
              
              {/* Crypto */}
              <Route path="crypto/overview" element={<CryptoOverview />} />
              <Route path="crypto/top-coins" element={<CryptoTopCoins />} />
              <Route path="crypto/on-chain" element={<CryptoOnChain />} />
              <Route path="crypto/heatmap" element={<CryptoHeatmap />} />
              <Route path="crypto/news" element={<CryptoNews />} />
              <Route path="crypto/catalysts" element={<CryptoCatalysts />} />
              <Route path="crypto/exchanges" element={<CryptoExchanges />} />
              <Route path="crypto/movers" element={<CryptoMovers />} />
              <Route path="crypto/reports" element={<CryptoReports />} />
              <Route path="crypto/calendar" element={<CryptoCalendar />} />
              
              {/* Futures */}
              <Route path="futures/overview" element={<FuturesOverview />} />
              <Route path="futures/open-interests" element={<FuturesOpenInterests />} />
              <Route path="futures/calendar" element={<FuturesCalendar />} />
              
              {/* Forex */}
              <Route path="forex/overview" element={<ForexOverview />} />
              <Route path="forex/strength" element={<ForexStrength />} />
              <Route path="forex/correlation" element={<ForexCorrelation />} />
              <Route path="forex/calendar" element={<ForexCalendar />} />
              <Route path="forex/pairs" element={<ForexPairs />} />
              <Route path="forex/rates" element={<ForexRates />} />
              <Route path="forex/deep-analysis" element={<ForexDeepAnalysis />} />
              <Route path="forex/alerts" element={<ForexAlerts />} />
              
              {/* Commodities */}
              <Route path="commodities/overview" element={<CommoditiesOverview />} />
              <Route path="commodities/screener" element={<CommoditiesScreener />} />
              <Route path="commodities/catalysts" element={<CommoditiesCatalysts />} />
              <Route path="commodities/energy" element={<CommoditiesEnergy />} />
              <Route path="commodities/metals" element={<CommoditiesMetals />} />
              <Route path="commodities/agriculture" element={<CommoditiesAgriculture />} />
              <Route path="commodities/seasonality" element={<CommoditiesSeasonality />} />
              <Route path="commodities/reports" element={<CommoditiesReports />} />
              <Route path="commodities/calendar" element={<CommoditiesCalendar />} />
              
                            <Route path="forex/news" element=<ForexNews /> />
              <Route path="commodities/news" element=<CommoditiesNews /> />
              <Route path="macro/news" element=<MacroNews /> />
{/* Macro */}
              <Route path="macro/overview" element={<MacroOverview />} />
              <Route path="macro/calendar" element={<MacroCalendar />} />
              <Route path="macro/rates" element={<MacroRates />} />
              <Route path="macro/indicators" element={<MacroIndicators />} />
              <Route path="macro/events" element={<MacroEvents />} />
              <Route path="macro/reports" element={<MacroReports />} />
              <Route path="macro/sentiment" element={<MacroSentiment />} />
              
              {/* AI */}
              <Route path="ai/overview" element={<AIOverview />} />
              <Route path="ai/digest" element={<AIDigest />} />
              <Route path="ai/sentiment" element={<AISentiment />} />
              <Route path="ai/forecasts" element={<AIForecasts />} />
              <Route path="ai/risk" element={<AIRisk />} />
              <Route path="ai/patterns" element={<AIPatterns />} />
              <Route path="ai/reports" element={<AIReports />} />
              <Route path="ai/alerts" element={<AIAlerts />} />
              <Route path="ai/backtesting" element={<AIBacktesting />} />
              
              {/* Journal */}
              <Route path="journal/overview" element={<JournalOverview />} />
              <Route path="journal/my-trades" element={<JournalMyTrades />} />
              <Route path="journal/new" element={<JournalNew />} />
              <Route path="journal/:id" element={<JournalTradeDetail />} />
              <Route path="journal/import" element={<JournalImport />} />
              <Route path="journal/export" element={<JournalExport />} />
              <Route path="journal/notes" element={<JournalNotes />} />
              <Route path="journal/analytics" element={<JournalAnalytics />} />
              <Route path="journal/ai-review" element={<JournalAIReview />} />
              <Route path="journal/calendar" element={<JournalCalendar />} />
              <Route path="journal/performance" element={<JournalPerformance />} />
              
              {/* Copy Trade */}
              <Route path="copy-trade/overview" element={<CopyTradeOverview />} />
              <Route path="copy-trade/top-traders" element={<CopyTradeTopTraders />} />
              <Route path="copy-trade/strategies" element={<CopyTradeStrategies />} />
              <Route path="copy-trade/portfolios" element={<CopyTradePortfolios />} />
              <Route path="copy-trade/leaderboard" element={<CopyTradeLeaderboard />} />
              <Route path="copy-trade/my-copying" element={<CopyTradeMyCopying />} />
              <Route path="copy-trade/insights" element={<CopyTradeInsights />} />
              
              {/* Funding */}
              <Route path="funding/overview" element={<FundingOverview />} />
              <Route path="funding/brokers" element={<FundingBrokers />} />
              <Route path="funding/advance" element={<FundingAdvance />} />
              <Route path="funding/transactions" element={<FundingTransactions />} />
            </Route>
            
            <Route path="/settings" element={<ProtectedRoute><ProtectedAppLayout /></ProtectedRoute>}>
              <Route index element={<Settings />} />
            </Route>
            
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
