// src/index.ts — FIXED for Railway deployment
import "dotenv/config";
import express from "express";
import cors from "cors";
import { rateLimit } from "./middleware/rateLimit.js";

// Route imports
import quotesRouter from "./routes/quotes.js";
import marketRouter from "./routes/market.js";
import newsRouter from "./routes/news.js";
import overviewRouter from "./routes/overview.js";
import polygonAggsRouter from "./routes/polygon.aggs.js";
import secProxyRouter from "./routes/secProxy.js";
import newsletterRouter from "./routes/newsletter.js";
import cryptoRouter from "./routes/crypto.js";
import stocksRouter from "./routes/stocks.js";

const app = express();

// -------- CORS (Production ready) --------
const ORIGIN = process.env.CORS_ORIGIN?.split(",") || [
  "http://localhost:5173",
  "https://finotaur.com",
  "https://www.finotaur.com",
];

app.use(cors({ origin: ORIGIN, credentials: true }));
app.use((req, res, next) => {
  res.setHeader("Vary", "Origin");
  next();
});
app.use(express.json());

// Rate limit: 60 req / 60s per IP
app.use(rateLimit({ windowMs: 60_000, max: 60 }));

// -------- Health --------
app.get("/api/_whoami", (_req, res) =>
  res.json({ version: "finotaur-server-ts", origin: ORIGIN })
);

// -------- Mount Routers --------
app.use("/api", marketRouter);
app.use("/api", quotesRouter);
app.use("/api", newsRouter);
app.use("/api", overviewRouter);
app.use("/api/polygon", polygonAggsRouter);
app.use("/api", cryptoRouter);
app.use("/api", stocksRouter);
app.use("/api", secProxyRouter);
app.use("/api/newsletter", newsletterRouter);

// -------- Dynamic route loading for overview subroutes --------
async function loadOptionalRoutes() {
  try {
    const { default: overviewFilings } = await import("./routes/overview/filings.js");
    app.use("/api", overviewFilings);
    console.log("✅ Overview filings mounted");
  } catch (e: any) {
    console.log("⚠️ Overview filings not available:", e.message);
  }

  try {
    const { default: overviewReference } = await import("./routes/overview/reference.js");
    app.use("/api", overviewReference);
    console.log("✅ Overview reference mounted");
  } catch (e: any) {
    console.log("⚠️ Overview reference not available:", e.message);
  }
}

// -------- 404 handler (must be last) --------
function setup404() {
  app.use((req, res) =>
    res.status(404).json({ error: "not_found", path: req.path })
  );
}

// -------- Start Server --------
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

loadOptionalRoutes()
  .then(() => {
    setup404();
    // ⚠️ CRITICAL: Bind to 0.0.0.0 for Railway/Docker
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`[finotaur] server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Failed to start server:", err);
    process.exit(1);
  });