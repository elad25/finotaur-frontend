// finotaur-server/src/types/bcryptjs.d.ts
declare module "bcryptjs";
