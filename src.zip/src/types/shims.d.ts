// finotaur-server/src/types/shims.d.ts
declare module 'morgan';
