// src/config/nav.ts (SERVER VERSION - No lucide-react!)
// =====================================================
// FINOTAUR SERVER NAVIGATION CONFIG
// =====================================================

export interface NavItem {
  label: string;
  path: string;
}

export interface Domain {
  id: string;
  label: string;
  subNav: NavItem[];
  sidebar: NavItem[];
}

export const domains: Record<string, Domain> = {
  'all-markets': {
    id: 'all-markets',
    label: 'All Markets',
    subNav: [
      { label: 'Overview', path: '/app/all-markets/overview' },
      { label: 'Chart', path: '/app/all-markets/chart' },
      { label: 'Summary', path: '/app/all-markets/summary' },
      { label: 'News', path: '/app/all-markets/news' },
    ],
    sidebar: [
      { label: 'Overview', path: '/app/all-markets/overview' },
      { label: 'Heatmap', path: '/app/all-markets/heatmap' },
      { label: 'Movers', path: '/app/all-markets/movers' },
      { label: 'Sentiment', path: '/app/all-markets/sentiment' },
      { label: 'Calendar', path: '/app/all-markets/calendar' },
    ],
  },
  
  stocks: {
    id: 'stocks',
    label: 'Stocks',
    subNav: [
      { label: 'Overview', path: '/app/stocks/overview' },
      { label: 'News', path: '/app/stocks/news' },
      { label: 'Screener', path: '/app/stocks/screener' },
    ],
    sidebar: [
      { label: 'Dashboard', path: '/app/stocks/overview' },
      { label: 'Screener', path: '/app/stocks/screener' },
      { label: 'Earnings Calendar', path: '/app/stocks/earnings' },
      { label: 'Fundamentals', path: '/app/stocks/fundamentals' },
      { label: 'Top Movers', path: '/app/stocks/movers' },
      { label: 'News', path: '/app/stocks/news' },
      { label: 'Sector Analysis', path: '/app/stocks/sectors' },
      { label: 'Catalysts', path: '/app/stocks/catalysts' },
      { label: 'Upgrades/Downgrades', path: '/app/stocks/upgrades' },
      { label: 'Valuation', path: '/app/stocks/valuation' },
      { label: 'Reports & PDFs', path: '/app/stocks/reports' },
      { label: 'Watchlists', path: '/app/stocks/watchlists' },
    ],
  },
  
  crypto: {
    id: 'crypto',
    label: 'Crypto',
    subNav: [
      { label: 'Overview', path: '/app/crypto/overview' },
      { label: 'News', path: '/app/crypto/news' },
    ],
    sidebar: [
      { label: 'Dashboard', path: '/app/crypto/overview' },
      { label: 'Top Coins', path: '/app/crypto/top-coins' },
      { label: 'On-chain Data', path: '/app/crypto/on-chain' },
      { label: 'Heatmap', path: '/app/crypto/heatmap' },
      { label: 'News & Sentiment', path: '/app/crypto/news' },
      { label: 'Catalysts', path: '/app/crypto/catalysts' },
      { label: 'Exchanges', path: '/app/crypto/exchanges' },
      { label: 'Top Movers', path: '/app/crypto/movers' },
      { label: 'Reports', path: '/app/crypto/reports' },
      { label: 'Calendar', path: '/app/crypto/calendar' },
    ],
  },
  
  futures: {
    id: 'futures',
    label: 'Futures',
    subNav: [
      { label: 'Overview', path: '/app/futures/overview' },
    ],
    sidebar: [
      { label: 'Overview', path: '/app/futures/overview' },
      { label: 'Open Interests', path: '/app/futures/open-interests' },
      { label: 'Calendar', path: '/app/futures/calendar' },
    ],
  },
  
  forex: {
    id: 'forex',
    label: 'Forex',
    subNav: [
      { label: 'Overview', path: '/app/forex/overview' },
      { label: 'News', path: '/app/forex/news' },
    ],
    sidebar: [
      { label: 'Dashboard', path: '/app/forex/overview' },
      { label: 'Currency Strength', path: '/app/forex/strength' },
      { label: 'Correlation Map', path: '/app/forex/correlation' },
      { label: 'Economic Calendar', path: '/app/forex/calendar' },
      { label: 'Major/Cross Pairs', path: '/app/forex/pairs' },
      { label: 'Interest Rates', path: '/app/forex/rates' },
      { label: 'Macro Reports', path: '/app/forex/deep-analysis' },
      { label: 'Alerts & Watchlists', path: '/app/forex/alerts' },
    ],
  },
  
  commodities: {
    id: 'commodities',
    label: 'Commodities',
    subNav: [
      { label: 'Overview', path: '/app/commodities/overview' },
      { label: 'News', path: '/app/commodities/news' },
    ],
    sidebar: [
      { label: 'Dashboard', path: '/app/commodities/overview' },
      { label: 'Screener', path: '/app/commodities/screener' },
      { label: 'Catalysts', path: '/app/commodities/catalysts' },
      { label: 'Energy', path: '/app/commodities/energy' },
      { label: 'Metals', path: '/app/commodities/metals' },
      { label: 'Agriculture', path: '/app/commodities/agriculture' },
      { label: 'Seasonality', path: '/app/commodities/seasonality' },
      { label: 'Reports', path: '/app/commodities/reports' },
      { label: 'Calendar', path: '/app/commodities/calendar' },
    ],
  },
  
  macro: {
    id: 'macro',
    label: 'Macro & News',
    subNav: [
      { label: 'Overview', path: '/app/macro/overview' },
      { label: 'News', path: '/app/macro/news' },
    ],
    sidebar: [
      { label: 'Market Overview', path: '/app/macro/overview' },
      { label: 'Global Calendar', path: '/app/macro/calendar' },
      { label: 'Interest Rates', path: '/app/macro/rates' },
      { label: 'Economic Indicators', path: '/app/macro/indicators' },
      { label: 'Major Events', path: '/app/macro/events' },
      { label: 'Reports & PDFs', path: '/app/macro/reports' },
      { label: 'Sentiment', path: '/app/macro/sentiment' },
    ],
  },
  
  // ✅ AI - Removed Forecasts from subNav
  ai: {
    id: 'ai',
    label: 'AI Insights',
    subNav: [
      { label: 'Overview', path: '/app/ai/overview' },
    ],
    sidebar: [
      { label: 'Overview', path: '/app/ai/overview' },
      { label: 'Morning Brief', path: '/app/ai/morning-brief' },
      { label: 'Market Pulse', path: '/app/ai/market-pulse' },
      { label: 'My Portfolio', path: '/app/ai/my-portfolio' },
      { label: 'Macro & Earnings', path: '/app/ai/macro-earnings' },
      { label: 'Trade Ideas', path: '/app/ai/trade-ideas' },
      { label: 'AI Assistant', path: '/app/ai/assistant' },
    ],
  },
  
  journal: {
    id: 'journal',
    label: 'Journal',
    subNav: [
      { label: 'Overview', path: '/app/journal/overview' },
      { label: 'My Trades', path: '/app/journal/my-trades' },
    ],
    sidebar: [
      { label: 'Overview', path: '/app/journal/overview' },
      { label: 'My Trades', path: '/app/journal/my-trades' },
      { label: 'Notes & Tags', path: '/app/journal/notes' },
      { label: 'Analytics & Win Rate', path: '/app/journal/analytics' },
      { label: 'AI Trade Review', path: '/app/journal/ai-review' },
      { label: 'Calendar View', path: '/app/journal/calendar' },
      { label: 'Performance Reports', path: '/app/journal/performance' },
    ],
  },
  
  'copy-trade': {
    id: 'copy-trade',
    label: 'Copy Trade',
    subNav: [
      { label: 'Overview', path: '/app/copy-trade/overview' },
      { label: 'Top Traders', path: '/app/copy-trade/top-traders' },
    ],
    sidebar: [
      { label: 'Overview', path: '/app/copy-trade/overview' },
      { label: 'Top Traders', path: '/app/copy-trade/top-traders' },
      { label: 'Strategies', path: '/app/copy-trade/strategies' },
      { label: 'Portfolios', path: '/app/copy-trade/portfolios' },
      { label: 'Leaderboard', path: '/app/copy-trade/leaderboard' },
      { label: 'My Copying', path: '/app/copy-trade/my-copying' },
      { label: 'Trader Insights', path: '/app/copy-trade/insights' },
    ],
  },
  
  funding: {
    id: 'funding',
    label: 'Funding',
    subNav: [
      { label: 'Overview', path: '/app/funding/overview' },
      { label: 'Brokers', path: '/app/funding/brokers' },
    ],
    sidebar: [
      { label: 'Overview', path: '/app/funding/overview' },
      { label: 'Brokers', path: '/app/funding/brokers' },
      { label: 'Cash Advance', path: '/app/funding/advance' },
      { label: 'Transactions', path: '/app/funding/transactions' },
    ],
  },
  
  options: {
    id: 'options',
    label: 'Options',
    subNav: [
      { label: 'Chain', path: '/app/options/chain' },
      { label: 'Flow', path: '/app/options/flow' },
      { label: 'Volatility', path: '/app/options/volatility' },
      { label: 'Strategy', path: '/app/options/strategy' },
      { label: 'Simulator', path: '/app/options/simulator' },
    ],
    sidebar: [
      { label: 'Greeks Monitor', path: '/app/options/greeks-monitor' },
      { label: 'IV Rank / Percentile', path: '/app/options/iv-rank' },
      { label: 'OI / Volume', path: '/app/options/oi-volume' },
      { label: 'Unusual Activity', path: '/app/options/unusual-activity' },
      { label: 'Earnings IV Crush', path: '/app/options/earnings-iv-crush' },
      { label: 'Shortcuts', path: '/app/options/shortcuts' },
    ],
  },
};

export const domainOrder = [
  'all-markets',
  'stocks',
  'crypto',
  'futures',
  'forex',
  'commodities',
  'options',
  'macro',
  'ai',
  'journal',
  'copy-trade',
  'funding',
];