// ============================================================================
// FINOTAUR INTELLIGENCE - UNIFIED ROUTES
// ============================================================================
// Version: 8.0 | All API endpoints in one place
// ============================================================================

import express from 'express';
import { VERSION } from './config.js';
import {
  runFullWorkflow,
  runQuickWorkflow,
  getWorkflowStatus,
  getWorkflowPhasesInfo,
} from './workflow.js';
import { generateIntelligenceReportPDFBuffer } from './pdf-generator.js';
import {
  fetchAllMarketData,
  fetchNewsAndEarnings,
  fetchAnalystActions,
  fetchOptionsFlow,
  fetchFedContext,
  fetchEconomicCalendar,
  buildLockedPrices,
} from './data-service.js';

const router = express.Router();

// In-memory report cache
const reportCache = new Map();

// ============================================================================
// HEALTH CHECK
// ============================================================================
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    version: VERSION,
    timestamp: new Date().toISOString(),
    endpoints: {
      reports: ['POST /generate-report', 'POST /generate-quick', 'POST /generate-pdf'],
      status: ['GET /workflow-progress', 'GET /phases'],
      debug: ['GET /debug/market-data', 'GET /debug/news', 'GET /debug/analyst-actions'],
    },
  });
});

// ============================================================================
// GENERATE FULL REPORT (JSON)
// ============================================================================
router.post('/generate-report', async (req, res) => {
  try {
    console.log('\n🚀 Starting report generation...');
    
    const result = await runFullWorkflow({
      openaiApiKey: process.env.OPENAI_API_KEY,
    });
    
    if (result.success) {
      // Cache the report
      const reportId = `report-${Date.now()}`;
      reportCache.set(reportId, result);
      
      res.json({
        success: true,
        reportId,
        report: result.report,
        metadata: result.metadata,
        summary: result.summary,
      });
    } else {
      res.status(500).json({ success: false, error: result.error });
    }
  } catch (e) {
    console.error('Report generation error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// GENERATE QUICK REPORT (JSON)
// ============================================================================
router.post('/generate-quick', async (req, res) => {
  try {
    console.log('\n⚡ Starting quick report generation...');
    
    const result = await runQuickWorkflow({});
    res.json(result);
  } catch (e) {
    console.error('Quick report error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// GENERATE PDF REPORT
// ============================================================================
router.post('/generate-pdf', async (req, res) => {
  try {
    console.log('\n📄 Starting PDF report generation...');
    
    // Step 1: Generate report
    const result = await runFullWorkflow({
      openaiApiKey: process.env.OPENAI_API_KEY,
    });
    
    if (!result.success) {
      return res.status(500).json({
        success: false,
        error: result.error || 'Report generation failed',
      });
    }
    
    // Step 2: Generate PDF
    console.log('   Generating PDF...');
    
    // v21.0: Log what we're passing to PDF generator
    console.log(`   [DEBUG] result.lockedPrices: ${result.lockedPrices ? 'EXISTS' : 'NULL'}`);
    console.log(`   [DEBUG] result.context: ${result.context ? 'EXISTS' : 'NULL'}`);
    if (result.lockedPrices) {
      console.log(`   [DEBUG] lockedPrices keys: ${Object.keys(result.lockedPrices).join(', ')}`);
    }
    if (result.context) {
      console.log(`   [DEBUG] context keys: ${Object.keys(result.context).join(', ')}`);
    }
    
    const pdfBuffer = await generateIntelligenceReportPDFBuffer(
      result.report,
      null,
      {
        lockedPrices: result.lockedPrices,
        context: result.context,  // v21.0: Pass full context for dynamic tables
        qaScore: result.qaScore || result.summary?.qaScore,
      }
    );
    
    if (!pdfBuffer || pdfBuffer.length < 1000) {
      return res.status(500).json({
        success: false,
        error: 'PDF generation failed - buffer too small',
      });
    }
    
    // Step 3: Send PDF
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `finotaur-intelligence-${dateStr}.pdf`;
    
    console.log(`   ✅ PDF generated: ${filename} (${(pdfBuffer.length / 1024).toFixed(1)} KB)`);
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.send(pdfBuffer);
    
  } catch (e) {
    console.error('PDF generation error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// CONVERT REPORT TO PDF
// ============================================================================
router.post('/convert-to-pdf', async (req, res) => {
  try {
    const { reportText, lockedPrices } = req.body;
    
    if (!reportText) {
      return res.status(400).json({
        success: false,
        error: 'reportText is required in request body',
      });
    }
    
    console.log('\n📄 Converting report to PDF...');
    
    const pdfBuffer = await generateIntelligenceReportPDFBuffer(
      reportText,
      null,
      { lockedPrices }
    );
    
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `finotaur-intelligence-${dateStr}.pdf`;
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.send(pdfBuffer);
    
  } catch (e) {
    console.error('PDF conversion error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// GENERATE FULL (JSON + PDF)
// ============================================================================
router.post('/generate-full', async (req, res) => {
  try {
    console.log('\n🚀 Starting full report generation (JSON + PDF)...');
    
    const { includePdf = true } = req.body || {};
    
    // Generate report
    const result = await runFullWorkflow({
      openaiApiKey: process.env.OPENAI_API_KEY,
    });
    
    if (!result.success) {
      return res.status(500).json({ success: false, error: result.error });
    }
    
    const response = {
      success: true,
      report: result.report,
      metadata: result.metadata,
      summary: result.summary,
    };
    
    // Generate PDF if requested
    if (includePdf) {
      console.log('   Generating PDF...');
      const pdfBuffer = await generateIntelligenceReportPDFBuffer(
        result.report,
        null,
        { lockedPrices: result.lockedPrices }
      );
      
      response.pdfBase64 = pdfBuffer.toString('base64');
      response.pdfSize = pdfBuffer.length;
      
      console.log(`   ✅ PDF included (${(pdfBuffer.length / 1024).toFixed(1)} KB)`);
    }
    
    res.json(response);
    
  } catch (e) {
    console.error('Full report generation error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// WORKFLOW STATUS
// ============================================================================
router.get('/workflow-progress', (req, res) => {
  res.json({
    success: true,
    ...getWorkflowStatus(),
  });
});

// ============================================================================
// WORKFLOW PHASES INFO
// ============================================================================
router.get('/phases', (req, res) => {
  res.json({
    success: true,
    data: getWorkflowPhasesInfo(),
  });
});

// ============================================================================
// GET CACHED REPORT
// ============================================================================
router.get('/report/:reportId', (req, res) => {
  const { reportId } = req.params;
  const cached = reportCache.get(reportId);
  
  if (!cached) {
    return res.status(404).json({
      success: false,
      error: 'Report not found',
    });
  }
  
  res.json({
    success: true,
    report: cached.report,
    metadata: cached.metadata,
    summary: cached.summary,
  });
});

// ============================================================================
// GET CACHED REPORT AS PDF
// ============================================================================
router.get('/report/:reportId/pdf', async (req, res) => {
  try {
    const { reportId } = req.params;
    const cached = reportCache.get(reportId);
    
    if (!cached) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }
    
    const pdfBuffer = await generateIntelligenceReportPDFBuffer(
      cached.report,
      null,
      { lockedPrices: cached.lockedPrices }
    );
    
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `finotaur-intelligence-${dateStr}.pdf`;
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.send(pdfBuffer);
    
  } catch (e) {
    console.error('PDF error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// DEBUG ENDPOINTS
// ============================================================================

router.get('/debug/market-data', async (req, res) => {
  try {
    const marketData = await fetchAllMarketData();
    const lockedPrices = buildLockedPrices(marketData);
    res.json({
      success: true,
      marketData,
      lockedPrices,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

router.get('/debug/news', async (req, res) => {
  try {
    const newsData = await fetchNewsAndEarnings();
    res.json({
      success: true,
      newsData,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

router.get('/debug/analyst-actions', async (req, res) => {
  try {
    const analystData = await fetchAnalystActions();
    res.json({
      success: true,
      analystData,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

router.get('/debug/options-flow', async (req, res) => {
  try {
    const optionsFlow = await fetchOptionsFlow();
    res.json({
      success: true,
      optionsFlow,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

router.get('/debug/fed', async (req, res) => {
  try {
    const fedContext = await fetchFedContext();
    res.json({
      success: true,
      fedContext,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

router.get('/debug/economic-calendar', async (req, res) => {
  try {
    const calendar = await fetchEconomicCalendar();
    res.json({
      success: true,
      calendar,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================================
// API DOCUMENTATION
// ============================================================================
router.get('/docs', (req, res) => {
  res.json({
    name: 'Finotaur Intelligence API',
    version: VERSION,
    description: 'Institutional-grade market intelligence reports (Meida Pnim Style)',
    endpoints: {
      reports: {
        'POST /generate-report': {
          description: 'Generate full intelligence report (JSON)',
          response: 'JSON with report text and metadata',
        },
        'POST /generate-quick': {
          description: 'Generate quick summary report (JSON)',
          response: 'JSON with abbreviated report',
        },
        'POST /generate-pdf': {
          description: 'Generate full report as PDF download',
          response: 'PDF file download',
        },
        'POST /convert-to-pdf': {
          description: 'Convert existing report text to PDF',
          body: { reportText: 'required', lockedPrices: 'optional' },
          response: 'PDF file download',
        },
        'POST /generate-full': {
          description: 'Generate report with both JSON and PDF (base64)',
          body: { includePdf: 'optional boolean, default true' },
          response: 'JSON with report, metadata, and PDF as base64',
        },
      },
      status: {
        'GET /workflow-progress': 'Current workflow status',
        'GET /phases': 'Workflow phases information',
        'GET /report/:reportId': 'Get cached report by ID',
        'GET /report/:reportId/pdf': 'Get cached report as PDF',
      },
      debug: {
        'GET /debug/market-data': 'Raw market data',
        'GET /debug/news': 'News and earnings data',
        'GET /debug/analyst-actions': 'Analyst actions data',
        'GET /debug/options-flow': 'Options flow data',
        'GET /debug/fed': 'Fed context data',
        'GET /debug/economic-calendar': 'Economic calendar',
      },
      utility: {
        'GET /health': 'Health check',
        'GET /docs': 'This documentation',
      },
    },
  });
});

// ============================================================================
// SETUP ROUTES FUNCTION
// ============================================================================
export function setupRoutes(app, basePath = '/api/intelligence') {
  app.use(basePath, router);
  
  console.log(`[Routes] Finotaur Intelligence API v${VERSION} mounted at ${basePath}`);
  console.log(`[Routes] Endpoints:`);
  console.log(`   POST ${basePath}/generate-report`);
  console.log(`   POST ${basePath}/generate-quick`);
  console.log(`   POST ${basePath}/generate-pdf`);
  console.log(`   POST ${basePath}/generate-full`);
  console.log(`   GET  ${basePath}/workflow-progress`);
  console.log(`   GET  ${basePath}/docs`);
}

// ============================================================================
// EXPORTS
// ============================================================================
export { router };

export default {
  router,
  setupRoutes,
};