// =====================================================
// WEEKLY TACTICAL REVIEW - REPORT GENERATOR v1.0
// =====================================================
// Location: src/TopSecret/Weekly/report-generator.js
// =====================================================

import { VERSION, REGIME_LABELS } from './config.js';

// =====================================================
// MARKDOWN REPORT GENERATOR
// =====================================================

export function generateMarkdownReport(data, reportWeek) {
  const sections = data.sections || data;
  const qa = data.qa || {};
  
  const lines = [];
  
  // Header
  lines.push('# Weekly Tactical Review');
  lines.push('');
  lines.push(`**Week of ${formatWeekDisplay(reportWeek)}**`);
  lines.push('');
  lines.push('---');
  lines.push('');
  
  // Executive Summary
  lines.push('## Executive Summary');
  lines.push('');
  const summary = sections.summary?.summary || sections.week_summary_writer?.data?.summary;
  if (summary) {
    lines.push(summary);
  } else {
    lines.push('Markets showed mixed performance this week with sector rotation evident across major indices.');
  }
  lines.push('');
  
  // Market Regime
  const regime = sections.summary?.regime || sections.market_data_processor?.data?.regime;
  if (regime) {
    lines.push(`**Market Regime:** ${REGIME_LABELS[regime] || regime}`);
    lines.push('');
  }
  
  lines.push('---');
  lines.push('');
  
  // Macro Analysis
  lines.push('## Macro Analysis');
  lines.push('');
  
  const macro = sections.macro?.tactical || sections.tactical_macro_analyst?.data;
  if (macro) {
    lines.push('### Tactical View');
    lines.push('');
    lines.push(`**Growth Outlook:** ${macro.growthOutlook || 'N/A'}`);
    lines.push('');
    lines.push(`**Inflation Trend:** ${macro.inflationTrend || 'N/A'}`);
    lines.push('');
    lines.push(`**Policy Stance:** ${macro.policyStance || 'N/A'}`);
    lines.push('');
    lines.push(`**Tactical View:** ${macro.tacticalView || 'N/A'}`);
    lines.push('');
    
    if (macro.keyRisks && macro.keyRisks.length > 0) {
      lines.push('**Key Risks:**');
      macro.keyRisks.forEach(risk => {
        lines.push(`- ${risk}`);
      });
      lines.push('');
    }
  }
  
  // Rate Environment
  const rates = sections.macro?.rates || sections.rate_environment_analyst?.data;
  if (rates) {
    lines.push('### Rate Environment');
    lines.push('');
    lines.push(`- Bond Performance: ${rates.bondPerformance > 0 ? '+' : ''}${rates.bondPerformance}%`);
    lines.push(`- Rate Direction: ${rates.rateDirection?.replace('_', ' ') || 'N/A'}`);
    lines.push(`- Duration View: ${rates.durationView || 'N/A'}`);
    lines.push('');
  }
  
  lines.push('---');
  lines.push('');
  
  // Technical Analysis
  lines.push('## Technical Analysis');
  lines.push('');
  
  // Key Levels
  const levels = sections.technical?.levels || sections.technical_levels_mapper?.data;
  if (levels?.SPY) {
    lines.push('### S&P 500 Key Levels');
    lines.push('');
    lines.push(`| Level | Price |`);
    lines.push(`|-------|-------|`);
    lines.push(`| Current | ${levels.SPY.current} |`);
    lines.push(`| Resistance 1 | ${levels.SPY.resistance1} |`);
    lines.push(`| Resistance 2 | ${levels.SPY.resistance2} |`);
    lines.push(`| Support 1 | ${levels.SPY.support1} |`);
    lines.push(`| Support 2 | ${levels.SPY.support2} |`);
    lines.push('');
    lines.push(`**Trend:** ${levels.SPY.trend || 'N/A'}`);
    lines.push('');
  }
  
  // Volatility
  const volatility = sections.technical?.volatility || sections.volatility_analyst?.data;
  if (volatility) {
    lines.push('### Volatility');
    lines.push('');
    lines.push(`- VIX Level: ${volatility.vixLevel}`);
    lines.push(`- Regime: ${volatility.volatilityRegime}`);
    lines.push(`- Recommendation: ${volatility.recommendation}`);
    lines.push('');
  }
  
  // Sector Analysis
  const sectorData = sections.technical?.sectors || sections.sector_analyzer?.data;
  if (sectorData) {
    lines.push('### Sector Rotation');
    lines.push('');
    
    if (sectorData.leaders && sectorData.leaders.length > 0) {
      lines.push('**Leaders:**');
      sectorData.leaders.forEach(s => {
        lines.push(`- ${s.symbol}: ${s.return > 0 ? '+' : ''}${s.return}%`);
      });
      lines.push('');
    }
    
    if (sectorData.laggards && sectorData.laggards.length > 0) {
      lines.push('**Laggards:**');
      sectorData.laggards.forEach(s => {
        lines.push(`- ${s.symbol}: ${s.return > 0 ? '+' : ''}${s.return}%`);
      });
      lines.push('');
    }
    
    if (sectorData.sectorView) {
      lines.push(`**View:** ${sectorData.sectorView}`);
      lines.push('');
    }
  }
  
  lines.push('---');
  lines.push('');
  
  // Sentiment
  lines.push('## Sentiment & Flows');
  lines.push('');
  
  const sentiment = sections.sentiment?.gauge || sections.sentiment_gauge?.data;
  if (sentiment) {
    lines.push(`- Overall Sentiment: **${sentiment.overallSentiment}**`);
    lines.push(`- Fear & Greed Index: ${sentiment.fearGreedIndex}`);
    lines.push(`- Retail Sentiment: ${sentiment.retailSentiment}`);
    lines.push(`- Institutional Positioning: ${sentiment.institutionalPositioning}`);
    lines.push('');
  }
  
  const flows = sections.sentiment?.flows || sections.fund_flow_tracker?.data;
  if (flows?.etfHighlights) {
    lines.push('### ETF Flows');
    lines.push('');
    flows.etfHighlights.forEach(f => {
      lines.push(`- ${f.ticker}: ${f.flow}`);
    });
    lines.push('');
  }
  
  lines.push('---');
  lines.push('');
  
  // Trade Ideas
  lines.push('## Trade Ideas');
  lines.push('');
  
  const ideas = sections.tradeIdeas?.tradeIdeas || sections.trade_idea_generator_weekly?.data?.tradeIdeas;
  if (ideas && ideas.length > 0) {
    ideas.forEach((idea, index) => {
      lines.push(`### Idea ${index + 1}: ${idea.ticker} (${idea.direction.toUpperCase()})`);
      lines.push('');
      lines.push(`- **Entry:** ${idea.entry}`);
      lines.push(`- **Stop:** ${idea.stop}`);
      lines.push(`- **Target:** ${idea.target}`);
      lines.push(`- **Timeframe:** ${idea.timeframe}`);
      lines.push(`- **Conviction:** ${idea.conviction}`);
      lines.push('');
      lines.push(`**Rationale:** ${idea.rationale}`);
      lines.push('');
    });
  } else {
    lines.push('*No specific trade ideas this week. Focus on risk management.*');
    lines.push('');
  }
  
  // Risk Management
  const risk = sections.risk || sections.risk_manager?.data;
  if (risk) {
    lines.push('### Risk Management');
    lines.push('');
    lines.push(`- Portfolio Risk: ${risk.portfolioRisk}`);
    lines.push(`- Max Position Size: ${risk.maxPositionSize}`);
    if (risk.volatilityAdjustment) {
      lines.push(`- Volatility Adjustment: ${risk.volatilityAdjustment}`);
    }
    lines.push('');
  }
  
  lines.push('---');
  lines.push('');
  
  // Upcoming Events
  lines.push('## Week Ahead');
  lines.push('');
  
  const macroCalendar = sections.calendar?.macro || sections.macro_calendar_builder?.data;
  if (macroCalendar?.upcomingEvents && macroCalendar.upcomingEvents.length > 0) {
    lines.push('### Key Events');
    lines.push('');
    macroCalendar.upcomingEvents.forEach(event => {
      const importance = event.importance === 'high' ? '🔴' : event.importance === 'medium' ? '🟡' : '⚪';
      lines.push(`- ${importance} ${event.event}`);
    });
    lines.push('');
  }
  
  // Footer
  lines.push('---');
  lines.push('');
  lines.push('*This report is for informational purposes only and does not constitute investment advice.*');
  lines.push('');
  lines.push(`*Generated by Finotaur Weekly Report System v${VERSION}*`);
  
  if (qa?.qaScore) {
    lines.push('');
    lines.push(`*QA Score: ${qa.qaScore}/100*`);
  }
  
  return lines.join('\n');
}

// =====================================================
// HTML REPORT GENERATOR
// =====================================================

export function generateHTMLReport(data, reportWeek) {
  const markdown = generateMarkdownReport(data, reportWeek);
  
  // Simple markdown to HTML conversion
  let html = markdown
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    .replace(/^\*\*(.*)\*\*$/gim, '<strong>$1</strong>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/^- (.*$)/gim, '<li>$1</li>')
    .replace(/^---$/gim, '<hr>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>');
  
  // Wrap in basic HTML structure
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Weekly Tactical Review - ${formatWeekDisplay(reportWeek)}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 20px; color: #333; }
    h1 { color: #1a1a2e; border-bottom: 2px solid #c9a646; padding-bottom: 10px; }
    h2 { color: #2d2d44; margin-top: 30px; }
    h3 { color: #4a4a6a; }
    hr { border: none; border-top: 1px solid #e0e0e0; margin: 30px 0; }
    table { border-collapse: collapse; width: 100%; margin: 15px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f5f5f5; }
    li { margin: 5px 0; }
    strong { color: #1a1a2e; }
    em { color: #666; }
  </style>
</head>
<body>
  ${html}
</body>
</html>`;
}

// =====================================================
// HELPER FUNCTIONS
// =====================================================

function formatWeekDisplay(reportWeek) {
  if (!reportWeek) {
    const now = new Date();
    return now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  }
  
  // If it's a date string, format it
  try {
    const date = new Date(reportWeek);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  } catch {
    return reportWeek;
  }
}

export default {
  generateMarkdownReport,
  generateHTMLReport,
};
