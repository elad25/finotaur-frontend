// =====================================================
// WEEKLY TACTICAL REVIEW - CONFIGURATION v4.0
// =====================================================
// Style: "Midapnim" (מידע פנים) Professional Format - EXACT MATCH
// Language: English output, institutional analyst tone
// v4.0: Complete restructure to match Meida Pnim 1:1
// =====================================================

export const VERSION = '4.0.0';
export const REPORT_TITLE = 'Daily Intelligence Report';
export const COMPANY_NAME = 'FINOTAUR';

// =====================================================
// TICKER TO COMPANY NAME MAPPING
// =====================================================
export const TICKER_MAP = {
  // Mega Cap Tech
  AAPL: 'Apple',
  MSFT: 'Microsoft',
  GOOGL: 'Alphabet',
  GOOG: 'Alphabet',
  AMZN: 'Amazon',
  META: 'Meta Platforms',
  NVDA: 'NVIDIA',
  TSLA: 'Tesla',
  
  // Other Major Tech
  NFLX: 'Netflix',
  AMD: 'AMD',
  INTC: 'Intel',
  CRM: 'Salesforce',
  ORCL: 'Oracle',
  ADBE: 'Adobe',
  CSCO: 'Cisco',
  AVGO: 'Broadcom',
  QCOM: 'Qualcomm',
  TXN: 'Texas Instruments',
  IBM: 'IBM',
  NOW: 'ServiceNow',
  SNOW: 'Snowflake',
  PLTR: 'Palantir',
  MU: 'Micron',
  AMAT: 'Applied Materials',
  LRCX: 'Lam Research',
  KLAC: 'KLA Corp',
  MRVL: 'Marvell',
  ARM: 'ARM Holdings',
  
  // Financials
  JPM: 'JPMorgan Chase',
  BAC: 'Bank of America',
  WFC: 'Wells Fargo',
  GS: 'Goldman Sachs',
  MS: 'Morgan Stanley',
  C: 'Citigroup',
  BLK: 'BlackRock',
  SCHW: 'Charles Schwab',
  AXP: 'American Express',
  V: 'Visa',
  MA: 'Mastercard',
  PYPL: 'PayPal',
  SQ: 'Block (Square)',
  
  // Healthcare
  UNH: 'UnitedHealth',
  JNJ: 'Johnson & Johnson',
  PFE: 'Pfizer',
  MRK: 'Merck',
  ABBV: 'AbbVie',
  LLY: 'Eli Lilly',
  TMO: 'Thermo Fisher',
  ABT: 'Abbott',
  BMY: 'Bristol-Myers Squibb',
  AMGN: 'Amgen',
  GILD: 'Gilead',
  MRNA: 'Moderna',
  REGN: 'Regeneron',
  VRTX: 'Vertex',
  ISRG: 'Intuitive Surgical',
  DHR: 'Danaher',
  CVS: 'CVS Health',
  
  // Consumer
  WMT: 'Walmart',
  COST: 'Costco',
  HD: 'Home Depot',
  LOW: 'Lowes',
  TGT: 'Target',
  NKE: 'Nike',
  SBUX: 'Starbucks',
  MCD: 'McDonalds',
  KO: 'Coca-Cola',
  PEP: 'PepsiCo',
  PG: 'Procter & Gamble',
  CL: 'Colgate-Palmolive',
  PM: 'Philip Morris',
  MO: 'Altria',
  
  // Industrials
  CAT: 'Caterpillar',
  DE: 'John Deere',
  HON: 'Honeywell',
  UPS: 'UPS',
  FDX: 'FedEx',
  BA: 'Boeing',
  LMT: 'Lockheed Martin',
  RTX: 'RTX (Raytheon)',
  GE: 'GE Aerospace',
  MMM: '3M',
  UNP: 'Union Pacific',
  
  // Energy
  XOM: 'Exxon Mobil',
  CVX: 'Chevron',
  COP: 'ConocoPhillips',
  SLB: 'Schlumberger',
  EOG: 'EOG Resources',
  OXY: 'Occidental',
  PSX: 'Phillips 66',
  VLO: 'Valero',
  MPC: 'Marathon Petroleum',
  
  // Communication
  DIS: 'Disney',
  CMCSA: 'Comcast',
  VZ: 'Verizon',
  T: 'AT&T',
  TMUS: 'T-Mobile',
  
  // Real Estate
  AMT: 'American Tower',
  PLD: 'Prologis',
  CCI: 'Crown Castle',
  EQIX: 'Equinix',
  SPG: 'Simon Property',
  
  // Utilities
  NEE: 'NextEra Energy',
  DUK: 'Duke Energy',
  SO: 'Southern Company',
  D: 'Dominion Energy',
  AEP: 'American Electric Power',
  
  // Materials
  LIN: 'Linde',
  APD: 'Air Products',
  FCX: 'Freeport-McMoRan',
  NEM: 'Newmont',
  
  // ETFs
  SPY: 'S&P 500 ETF',
  QQQ: 'Nasdaq 100 ETF',
  IWM: 'Russell 2000 ETF',
  DIA: 'Dow Jones ETF',
  TLT: '20+ Year Treasury ETF',
  IEF: '7-10 Year Treasury ETF',
  GLD: 'Gold ETF',
  USO: 'Oil ETF',
  UUP: 'US Dollar ETF',
  VIX: 'Volatility Index',
  XLK: 'Technology Select Sector',
  XLF: 'Financial Select Sector',
  XLE: 'Energy Select Sector',
  XLV: 'Health Care Select Sector',
  XLI: 'Industrial Select Sector',
  XLP: 'Consumer Staples Select',
  XLY: 'Consumer Discretionary Select',
  XLU: 'Utilities Select Sector',
  XLB: 'Materials Select Sector',
  XLRE: 'Real Estate Select Sector',
  XLC: 'Communication Services Select',
};

export function tickerToCompanyName(ticker) {
  if (!ticker) return '';
  const upperTicker = ticker.toUpperCase().trim();
  return TICKER_MAP[upperTicker] || ticker;
}

// =====================================================
// UTILITY FUNCTIONS
// =====================================================
export function formatPercent(num) {
  if (num === null || num === undefined) return '-';
  const n = Number(num);
  if (isNaN(n)) return '-';
  const prefix = n > 0 ? '+' : '';
  return prefix + n.toFixed(2) + '%';
}

export function formatNumber(num) {
  if (num === null || num === undefined) return '-';
  const n = Number(num);
  if (isNaN(n)) return '-';
  if (Math.abs(n) >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return n.toFixed(2);
}

export function formatPrice(num) {
  if (num === null || num === undefined) return '-';
  const n = Number(num);
  if (isNaN(n)) return '-';
  return '$' + n.toFixed(2);
}

export function formatDate(dateStr) {
  try {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'America/New_York'
    });
  } catch {
    return new Date().toLocaleDateString('en-US');
  }
}

export function formatDateShort(dateStr) {
  try {
    const date = new Date(dateStr);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return `${day}.${month}.${year}`;
  } catch {
    return new Date().toLocaleDateString('en-GB').replace(/\//g, '.');
  }
}

export function cleanText(text) {
  if (!text) return '';
  return String(text)
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/#{1,6}\s*/g, '')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// =====================================================
// WORKFLOW PHASES
// =====================================================
export const PHASES = {
  DATA_ACQUISITION: 'DATA_ACQUISITION',
  WEEK_SUMMARY: 'WEEK_SUMMARY',
  MACRO_CALENDAR: 'MACRO_CALENDAR',
  TACTICAL_PREPARATION: 'TACTICAL_PREPARATION',
  TRADE_IDEAS: 'TRADE_IDEAS',
  QUALITY_ASSURANCE: 'QUALITY_ASSURANCE',
};

export const PHASE_ORDER = [
  PHASES.DATA_ACQUISITION,
  PHASES.WEEK_SUMMARY,
  PHASES.MACRO_CALENDAR,
  PHASES.TACTICAL_PREPARATION,
  PHASES.TRADE_IDEAS,
  PHASES.QUALITY_ASSURANCE,
];

export const PHASE_LABELS = {
  [PHASES.DATA_ACQUISITION]: 'Data Acquisition',
  [PHASES.WEEK_SUMMARY]: 'Week Summary',
  [PHASES.MACRO_CALENDAR]: 'Macro Calendar',
  [PHASES.TACTICAL_PREPARATION]: 'Tactical Preparation',
  [PHASES.TRADE_IDEAS]: 'Trade Ideas',
  [PHASES.QUALITY_ASSURANCE]: 'Quality Assurance',
};

// =====================================================
// REPORT SECTIONS (Midapnim Style - Enhanced)
// =====================================================
export const REPORT_SECTIONS = {
  COVER: {
    id: 'cover',
    title: 'Weekly Tactical Review',
    order: 0,
  },
  DISCLAIMER_INTRO: {
    id: 'disclaimer_intro',
    title: 'Disclaimer',
    order: 1,
  },
  WEEK_SUMMARY: {
    id: 'week_summary',
    title: 'The Week That Was',
    subtitle: 'US Equities - Weekly Review, Sectors & Valuations',
    order: 2,
  },
  MACRO_AGENDA: {
    id: 'macro_agenda',
    title: 'The Week Ahead',
    subtitle: 'Key Events & Data Releases',
    order: 3,
  },
  TACTICAL_PREP: {
    id: 'tactical_prep',
    title: 'Tactical Preparation',
    subtitle: 'Markets & Macro - Global Macro Mix',
    order: 4,
  },
  FLOWS_SENTIMENT: {
    id: 'flows_sentiment',
    title: 'Flows & Sentiment',
    subtitle: 'Institutional Flows, CTA & Risk Appetite',
    order: 5,
  },
  KEY_RISKS: {
    id: 'key_risks',
    title: 'Key Risks to Monitor',
    subtitle: 'Risk Assessment & Triggers',
    order: 6,
  },
  TRADE_IDEAS: {
    id: 'trade_ideas',
    title: 'Trade Ideas',
    subtitle: 'Actionable Opportunities',
    order: 7,
  },
  DISCLAIMER_END: {
    id: 'disclaimer_end',
    title: 'Disclaimer',
    order: 8,
  },
};

// =====================================================
// SECTION CONFIG - For PDF Generation v4.0
// Maps section keys to display information
// MEIDA PNIM STYLE STRUCTURE
// =====================================================
export const SECTION_CONFIG = {
  globalArena: { 
    title: 'The Global Arena', 
    subtitle: 'Market Overview & Key Developments'
  },
  whatsHappening: { 
    title: "What's Happening Now", 
    subtitle: 'Current Market Status'
  },
  weekAhead: { 
    title: 'Week Ahead', 
    subtitle: "What's On The Radar"
  },
  macroArena: { 
    title: 'The Macro Arena', 
    subtitle: 'Economic Calendar & Data'
  },
  analystArena: { 
    title: 'Analyst Arena', 
    subtitle: 'Wall Street Actions'
  },
  tacticalCorner: { 
    title: 'The Tactical Corner', 
    subtitle: 'Flow of Funds & Market Structure'
  },
  focusCorner: { 
    title: 'Focus Corner', 
    subtitle: 'Trade Setups'
  },
  reports: { 
    title: 'Reports', 
    subtitle: 'Earnings & Company News'
  },
};

// =====================================================
// SECTION ORDER - For PDF Generation v4.0
// MEIDA PNIM STYLE ORDER
// =====================================================
export const SECTION_ORDER = [
  'globalArena',      // Page 1: Market overview
  'whatsHappening',   // Page 1: Current market status
  'weekAhead',        // Page 1: What to watch
  'macroArena',       // Page 2: Economic calendar
  'analystArena',     // Page 3: Analyst ratings
  'tacticalCorner',   // Page 4-5: Deep analysis
  'focusCorner',      // Page 6: Stock picks
  'reports',          // Page 7: Earnings
];

// =====================================================
// SECTION MAP - Maps various header names to section keys
// MEIDA PNIM STYLE v4.0
// =====================================================
export const SECTION_MAP = {
  // Global Arena variations (was Yesterday's Events)
  'THE GLOBAL ARENA': 'globalArena',
  'GLOBAL ARENA': 'globalArena',
  'YESTERDAY\'S EVENTS': 'globalArena',
  'YESTERDAYS EVENTS': 'globalArena',
  'MARKET OVERVIEW': 'globalArena',
  'MARKET STATUS': 'globalArena',
  'FROM YESTERDAY\'S EVENTS': 'globalArena',
  
  // What's Happening Now variations (was What's Hot)
  'WHAT\'S HAPPENING NOW': 'whatsHappening',
  'WHATS HAPPENING NOW': 'whatsHappening',
  'WHAT\'S HAPPENING': 'whatsHappening',
  'WHATS HAPPENING': 'whatsHappening',
  'WHAT\'S HOT TODAY': 'whatsHappening',
  'WHATS HOT TODAY': 'whatsHappening',
  'WHAT\'S HOT': 'whatsHappening',
  'WHATS HOT': 'whatsHappening',
  'CURRENT MARKET STATUS': 'whatsHappening',
  'WHAT\'S INTERESTING TODAY': 'whatsHappening',
  'WHATS INTERESTING TODAY': 'whatsHappening',
  
  // Week Ahead variations
  'WEEK AHEAD': 'weekAhead',
  'THE WEEK AHEAD': 'weekAhead',
  'WHAT\'S ON THE RADAR': 'weekAhead',
  'WHATS ON THE RADAR': 'weekAhead',
  'ON THE RADAR': 'weekAhead',
  'EVENTS THIS WEEK': 'weekAhead',
  'LOOKING AHEAD': 'weekAhead',
  
  // Macro Arena variations
  'THE MACRO ARENA': 'macroArena',
  'MACRO ARENA': 'macroArena',
  'ECONOMIC CALENDAR': 'macroArena',
  'MACRO ECONOMIC ARENA': 'macroArena',
  
  // Analyst Arena variations
  'ANALYST ARENA': 'analystArena',
  'THE ANALYST ARENA': 'analystArena',
  'WALL STREET ACTIONS': 'analystArena',
  
  // Tactical Corner variations
  'THE TACTICAL CORNER': 'tacticalCorner',
  'TACTICAL CORNER': 'tacticalCorner',
  'FLOW OF FUNDS': 'tacticalCorner',
  'MARKET STRUCTURE': 'tacticalCorner',
  
  // Focus Corner variations
  'FOCUS CORNER': 'focusCorner',
  'THE FOCUS CORNER': 'focusCorner',
  'TRADE SETUPS': 'focusCorner',
  'STOCK FOCUS': 'focusCorner',
  
  // Reports variations (was Earnings)
  'REPORTS': 'reports',
  'EARNINGS REPORTS': 'reports',
  'EARNINGS': 'reports',
  'COMPANY REPORTS': 'reports',
  'NOTABLE EARNINGS': 'reports',
  
  // Disclaimer (skip this)
  'IMPORTANT DISCLAIMER': 'disclaimer',
  'DISCLAIMER': 'disclaimer',
};

// =====================================================
// SECTIONS ALIAS (Backward Compatibility)
// =====================================================
export const SECTIONS = REPORT_SECTIONS;

// =====================================================
// LEGACY MAP - For backward compatibility with old section keys
// v4.0 - Maps old keys to new Meida Pnim structure
// =====================================================
export const LEGACY_MAP = {
  // Old daily report keys -> new keys
  'YESTERDAY_EVENTS': 'globalArena',
  'WHATS_INTERESTING': 'whatsHappening',
  'MACRO_ARENA': 'macroArena',
  'ANALYST_ARENA': 'analystArena',
  'EARNINGS': 'reports',
  'NEWS_CATALYSTS': 'whatsHappening',  // Merged into whatsHappening
  'TACTICAL_CORNER': 'tacticalCorner',
  'FOCUS_CORNER': 'focusCorner',
  'WEEK_AHEAD': 'weekAhead',
  'GLOBAL_ARENA': 'globalArena',
  'WHATS_HAPPENING': 'whatsHappening',
  'REPORTS': 'reports',
  // Snake_case variations
  'yesterday_events': 'globalArena',
  'whats_interesting': 'whatsHappening',
  'macro_arena': 'macroArena',
  'analyst_arena': 'analystArena',
  'news_catalysts': 'whatsHappening',
  'tactical_corner': 'tacticalCorner',
  'focus_corner': 'focusCorner',
  'week_ahead': 'weekAhead',
  'global_arena': 'globalArena',
  'whats_happening': 'whatsHappening',
  'reports': 'reports',
  // Direct camelCase - old to new
  'yesterdayEvents': 'globalArena',
  'whatsInteresting': 'whatsHappening',
  'macroArena': 'macroArena',
  'analystArena': 'analystArena',
  'earnings': 'reports',
  'newsCatalysts': 'whatsHappening',
  'tacticalCorner': 'tacticalCorner',
  'focusCorner': 'focusCorner',
  'weekAhead': 'weekAhead',
  // New keys (identity)
  'globalArena': 'globalArena',
  'whatsHappening': 'whatsHappening',
  'reports': 'reports',
};

// =====================================================
// NORMALIZE SECTION KEY - Converts any key format to standard camelCase
// =====================================================
export function normalizeSectionKey(key) {
  if (!key) return null;
  
  const keyStr = String(key).trim();
  
  // Check LEGACY_MAP first
  if (LEGACY_MAP[keyStr]) {
    return LEGACY_MAP[keyStr];
  }
  
  // Check SECTION_MAP (for header text variations)
  const upperKey = keyStr.toUpperCase();
  if (SECTION_MAP[upperKey]) {
    return SECTION_MAP[upperKey];
  }
  
  // Check if it's already a valid section key
  if (SECTION_ORDER.includes(keyStr)) {
    return keyStr;
  }
  
  // Try to convert common formats
  // SNAKE_CASE -> camelCase
  if (keyStr.includes('_')) {
    const camelCase = keyStr.toLowerCase().replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    if (SECTION_ORDER.includes(camelCase)) {
      return camelCase;
    }
  }
  
  return null;
}

// =====================================================
// SLEEP UTILITY
// =====================================================
export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// =====================================================
// AGENT DEFINITIONS (14 Agents)
// =====================================================
export const AGENT_DEFINITIONS = [
  // Phase 1: Data Acquisition (3 agents)
  {
    id: 'market_data_fetcher',
    name: 'Market Data Fetcher',
    description: 'Fetches weekly market data from Polygon API',
    icon: '📊',
    phase: PHASES.DATA_ACQUISITION,
    order: 1,
    estimatedSeconds: 15,
    dependencies: [],
  },
  {
    id: 'news_aggregator',
    name: 'News Aggregator',
    description: 'Aggregates market news from Perplexity API',
    icon: '📰',
    phase: PHASES.DATA_ACQUISITION,
    order: 2,
    estimatedSeconds: 20,
    dependencies: [],
  },
  {
    id: 'economic_calendar_fetcher',
    name: 'Economic Calendar Fetcher',
    description: 'Fetches upcoming economic events',
    icon: '📅',
    phase: PHASES.DATA_ACQUISITION,
    order: 3,
    estimatedSeconds: 15,
    dependencies: [],
  },

  // Phase 2: Week Summary (2 agents)
  {
    id: 'week_narrative_writer',
    name: 'Week Narrative Writer',
    description: 'Writes the weekly market narrative in professional analyst style',
    icon: '✍️',
    phase: PHASES.WEEK_SUMMARY,
    order: 4,
    estimatedSeconds: 45,
    dependencies: ['market_data_fetcher', 'news_aggregator'],
  },
  {
    id: 'sector_rotation_analyzer',
    name: 'Sector Rotation Analyzer',
    description: 'Analyzes sector performance and rotation dynamics',
    icon: '🔄',
    phase: PHASES.WEEK_SUMMARY,
    order: 5,
    estimatedSeconds: 30,
    dependencies: ['market_data_fetcher'],
  },

  // Phase 3: Macro Calendar (2 agents)
  {
    id: 'macro_events_writer',
    name: 'Macro Events Writer',
    description: 'Writes detailed analysis of upcoming macro events',
    icon: '🌐',
    phase: PHASES.MACRO_CALENDAR,
    order: 6,
    estimatedSeconds: 35,
    dependencies: ['economic_calendar_fetcher', 'news_aggregator'],
  },
  {
    id: 'micro_events_writer',
    name: 'Micro Events Writer',
    description: 'Writes analysis of earnings and corporate events',
    icon: '🎯',
    phase: PHASES.MACRO_CALENDAR,
    order: 7,
    estimatedSeconds: 30,
    dependencies: ['economic_calendar_fetcher'],
  },

  // Phase 4: Tactical Preparation (3 agents)
  {
    id: 'tactical_macro_analyst',
    name: 'Tactical Macro Analyst',
    description: 'Deep macro analysis and regime assessment',
    icon: '🌍',
    phase: PHASES.TACTICAL_PREPARATION,
    order: 8,
    estimatedSeconds: 50,
    dependencies: ['week_narrative_writer', 'sector_rotation_analyzer'],
  },
  {
    id: 'flows_sentiment_analyst',
    name: 'Flows & Sentiment Analyst',
    description: 'Analyzes fund flows, positioning, and sentiment indicators',
    icon: '💰',
    phase: PHASES.TACTICAL_PREPARATION,
    order: 9,
    estimatedSeconds: 40,
    dependencies: ['market_data_fetcher', 'news_aggregator'],
  },
  {
    id: 'risk_assessment_builder',
    name: 'Risk Assessment Builder',
    description: 'Builds comprehensive risk assessment',
    icon: '⚠️',
    phase: PHASES.TACTICAL_PREPARATION,
    order: 10,
    estimatedSeconds: 35,
    dependencies: ['tactical_macro_analyst', 'flows_sentiment_analyst'],
  },

  // Phase 5: Trade Ideas (2 agents)
  {
    id: 'trade_idea_generator',
    name: 'Trade Idea Generator',
    description: 'Generates actionable trade ideas',
    icon: '💡',
    phase: PHASES.TRADE_IDEAS,
    order: 11,
    estimatedSeconds: 40,
    dependencies: ['tactical_macro_analyst', 'sector_rotation_analyzer', 'risk_assessment_builder'],
  },
  {
    id: 'risk_manager',
    name: 'Risk Manager',
    description: 'Validates and enhances trade ideas with risk parameters',
    icon: '🛡️',
    phase: PHASES.TRADE_IDEAS,
    order: 12,
    estimatedSeconds: 20,
    dependencies: ['trade_idea_generator'],
  },

  // Phase 6: Quality Assurance (2 agents)
  {
    id: 'coherence_checker',
    name: 'Coherence Checker',
    description: 'Validates report coherence and quality',
    icon: '✅',
    phase: PHASES.QUALITY_ASSURANCE,
    order: 13,
    estimatedSeconds: 15,
    dependencies: ['risk_manager'],
  },
  {
    id: 'final_compiler',
    name: 'Final Compiler',
    description: 'Compiles final report output',
    icon: '📦',
    phase: PHASES.QUALITY_ASSURANCE,
    order: 14,
    estimatedSeconds: 10,
    dependencies: ['coherence_checker'],
  },
];

// =====================================================
// MARKET INDICES TO TRACK
// =====================================================
export const MARKET_INDICES = {
  SPY: { name: 'S&P 500', symbol: 'SPY', category: 'equity' },
  QQQ: { name: 'Nasdaq 100', symbol: 'QQQ', category: 'equity' },
  IWM: { name: 'Russell 2000', symbol: 'IWM', category: 'equity' },
  DIA: { name: 'Dow Jones', symbol: 'DIA', category: 'equity' },
  TLT: { name: '20+ Year Treasury', symbol: 'TLT', category: 'bonds' },
  IEF: { name: '7-10 Year Treasury', symbol: 'IEF', category: 'bonds' },
  GLD: { name: 'Gold', symbol: 'GLD', category: 'commodities' },
  USO: { name: 'Oil', symbol: 'USO', category: 'commodities' },
  UUP: { name: 'US Dollar', symbol: 'UUP', category: 'forex' },
  VIX: { name: 'Volatility Index', symbol: 'VIX', category: 'volatility' },
};

// =====================================================
// SECTOR ETFS
// =====================================================
export const SECTOR_ETFS = {
  XLK: { name: 'Technology', sector: 'technology', keyStocks: ['AAPL', 'MSFT', 'NVDA'] },
  XLF: { name: 'Financials', sector: 'financials', keyStocks: ['JPM', 'BAC', 'GS'] },
  XLE: { name: 'Energy', sector: 'energy', keyStocks: ['XOM', 'CVX', 'COP'] },
  XLV: { name: 'Healthcare', sector: 'healthcare', keyStocks: ['UNH', 'JNJ', 'PFE'] },
  XLI: { name: 'Industrials', sector: 'industrials', keyStocks: ['CAT', 'DE', 'HON'] },
  XLP: { name: 'Consumer Staples', sector: 'staples', keyStocks: ['PG', 'KO', 'WMT'] },
  XLY: { name: 'Consumer Discretionary', sector: 'discretionary', keyStocks: ['AMZN', 'TSLA', 'HD'] },
  XLU: { name: 'Utilities', sector: 'utilities', keyStocks: ['NEE', 'DUK', 'SO'] },
  XLB: { name: 'Materials', sector: 'materials', keyStocks: ['LIN', 'APD', 'FCX'] },
  XLRE: { name: 'Real Estate', sector: 'realestate', keyStocks: ['AMT', 'PLD', 'CCI'] },
  XLC: { name: 'Communication Services', sector: 'communication', keyStocks: ['META', 'GOOGL', 'NFLX'] },
};

// =====================================================
// MARKET REGIMES
// =====================================================
export const MARKET_REGIMES = {
  RISK_ON: 'risk_on',
  RISK_OFF: 'risk_off',
  ROTATION: 'rotation',
  CONSOLIDATION: 'consolidation',
  BREAKOUT: 'breakout',
  BREAKDOWN: 'breakdown',
  RUN_IT_HOT: 'run_it_hot',
  STAGFLATION_RISK: 'stagflation_risk',
};

export const REGIME_LABELS = {
  [MARKET_REGIMES.RISK_ON]: 'Risk-On Environment',
  [MARKET_REGIMES.RISK_OFF]: 'Risk-Off Environment',
  [MARKET_REGIMES.ROTATION]: 'Sector Rotation',
  [MARKET_REGIMES.CONSOLIDATION]: 'Consolidation',
  [MARKET_REGIMES.BREAKOUT]: 'Breakout Mode',
  [MARKET_REGIMES.BREAKDOWN]: 'Breakdown Mode',
  [MARKET_REGIMES.RUN_IT_HOT]: 'Run-It-Hot (Growth + Controlled Inflation)',
  [MARKET_REGIMES.STAGFLATION_RISK]: 'Stagflation Risk',
};

// =====================================================
// CONVICTION LEVELS
// =====================================================
export const CONVICTION_LEVELS = {
  HIGH: 'HIGH',
  MEDIUM: 'MEDIUM',
  LOW: 'LOW',
};

// =====================================================
// TRADE TIMEFRAMES
// =====================================================
export const TRADE_TIMEFRAMES = {
  INTRADAY: 'Intraday',
  SWING_1W: '1 Week',
  SWING_2W: '2 Weeks',
  SWING_1M: '1 Month',
  POSITION: '1-3 Months',
};

// =====================================================
// WRITING STYLE MANDATE - MIDAPNIM STYLE v3.0 (Enhanced)
// =====================================================
export const WRITING_MANDATE = `
YOU ARE A SENIOR INSTITUTIONAL MARKET STRATEGIST writing for professional investors.

Your writing embodies the "Midapnim" analytical philosophy - direct, insightful, and actionable.
Write as a seasoned professional speaking candidly to a peer about what truly matters in markets.

═══════════════════════════════════════════════════════════════════════════════
CORE PHILOSOPHY
═══════════════════════════════════════════════════════════════════════════════

The Midapnim approach is about CUTTING THROUGH THE NOISE:
- Start with what happened (facts and data)
- Explain WHY it matters (the real implication, not the obvious one)
- Connect it to the bigger picture (macro context, regime, cycle)
- End with what to DO about it (positioning, risk management)

This is NOT about predicting the future - it is about helping investors 
UNDERSTAND where we are in the cycle and position accordingly.

═══════════════════════════════════════════════════════════════════════════════
ABSOLUTE PROHIBITIONS - VIOLATING ANY DESTROYS CREDIBILITY
═══════════════════════════════════════════════════════════════════════════════

1. NO EMOJIS - Professional research never uses emojis
2. NO BULLET POINTS in main analysis - Use flowing, connected prose
3. NO MARKDOWN with # symbols - Write naturally
4. NO FIRST PERSON - Never "I think", "I believe", "In my view"
5. NO META-COMMENTARY - Never "Let me analyze", "Looking at the data"
6. NO EXCESSIVE HEDGING - Avoid "might potentially", "could perhaps"
7. NO MARKETING LANGUAGE - No "exclusive", "insider tip", "secret"
8. NO EXCLAMATION MARKS in analytical content
9. NO GENERIC CONCLUSIONS - Never end with "time will tell"
10. NO REPETITIVE FILLER - Every sentence must add value

Write as if speaking to a sophisticated colleague who values your insight 
but has limited time. Every sentence should earn its place.
`;

// =====================================================
// DISCLAIMER TEXT
// =====================================================
export const DISCLAIMER_TEXT = `The information provided above, including the content contained therein, is for general informational purposes only.

This information does not constitute, and should not be construed as, investment advice, investment marketing, or a substitute for such services that takes into account the specific data and needs of each individual.

No guarantee of any return should be inferred from this content.

This review and the information and/or analysis contained herein should not be considered an offer or recommendation to purchase and/or sell and/or hold securities and/or financial assets, or a recommendation for investment in any specific avenue.

The analysis in this review was performed based on information that was published and/or was accessible to the general public, and other information, including information collected and compiled by the authors and information derived from other sources that appears to be reliable, without the authors and/or the company having conducted independent investigations to verify its reliability.

This review does not constitute any certification and/or confirmation of the reliability and accuracy of the said information.

The above does not purport to contain all the information required by any particular investor. The opinions and forecasts stated above are subject to change without any further notice.

Therefore, the above does not constitute in any way a substitute for investment advice that takes into account the specific data and needs of each individual.

The authors of this review shall not be liable in any way for any damage and/or loss that may result from reliance on the above, if any.

All rights in this review belong to ${COMPANY_NAME}.`;

// =====================================================
// PDF STYLING - Enhanced for AMD-style Design
// =====================================================
export const PDF_COLORS = {
  primary: '#1E3A8A',       // Deep blue (professional)
  secondary: '#C9A646',     // Gold accent
  accent: '#059669',        // Green for positive
  negative: '#DC2626',      // Red for negative
  text: {
    dark: '#1A1A1A',
    medium: '#374151',
    light: '#6B7280',
    veryLight: '#9CA3AF',
  },
  background: {
    white: '#FFFFFF',
    light: '#F9FAFB',
    accent: '#FEF3C7',      // Light gold for highlights
  },
  chart: {
    positive: '#059669',
    negative: '#DC2626',
    neutral: '#6B7280',
    line: '#2563EB',
    area: 'rgba(37, 99, 235, 0.1)',
  },
};

export const PDF_FONTS = {
  sizes: {
    coverTitle: 36,
    coverSubtitle: 14,
    coverDate: 20,
    sectionTitle: 16,
    subSection: 12,
    body: 10.5,
    small: 9,
    table: 9,
    footer: 8,
  },
};

// =====================================================
// EXPORTS
// =====================================================
export default {
  VERSION,
  REPORT_TITLE,
  COMPANY_NAME,
  // Ticker mapping
  TICKER_MAP,
  tickerToCompanyName,
  // Utility functions
  formatPercent,
  formatNumber,
  formatPrice,
  formatDate,
  formatDateShort,
  cleanText,
  normalizeSectionKey,
  sleep,
  // Phases
  PHASES,
  PHASE_ORDER,
  PHASE_LABELS,
  // Sections
  REPORT_SECTIONS,
  SECTIONS,
  SECTION_CONFIG,
  SECTION_ORDER,
  SECTION_MAP,
  LEGACY_MAP,
  // Agents
  AGENT_DEFINITIONS,
  // Market data
  MARKET_INDICES,
  SECTOR_ETFS,
  MARKET_REGIMES,
  REGIME_LABELS,
  CONVICTION_LEVELS,
  TRADE_TIMEFRAMES,
  // Content
  WRITING_MANDATE,
  DISCLAIMER_TEXT,
  // PDF styling
  PDF_COLORS,
  PDF_FONTS,
};