// =====================================================
// WEEKLY REPORT CHART GENERATOR v1.0
// =====================================================
// Generates professional market charts using QuickChart API
// Style: Clean, professional, Midapnim-inspired
// =====================================================

const QUICKCHART_BASE_URL = 'https://quickchart.io/chart';

// ============================================
// COLORS - ISM-style professional palette
// ============================================
const COLORS = {
  gold: '#C9A646',             // Gold accent (ISM style)
  charcoal: '#3D3D3D',         // Dark gray
  darkGray: '#5A5A5A',
  mediumGray: '#8A8A8A',
  lightGray: '#CCCCCC',
  
  softGreen: '#5A9E6F',        // ISM positive
  softRed: '#C07872',          // ISM negative
  softOrange: '#CC9966',       // ISM neutral
  softBlue: '#6B8FAD',         // ISM accent
  softPurple: '#8B7B96',       // ISM secondary
  
  // Chart specific
  gridLine: 'rgba(0,0,0,0.08)',
  textDark: '#374151',
  textLight: '#9CA3AF',
  
  // Compatibility aliases
  primary: '#1E3A8A',
  secondary: '#2563EB',
  positive: '#5A9E6F',         // Use ISM softGreen
  negative: '#C07872',         // Use ISM softRed
  neutral: '#6B7280',
};

// ============================================
// HELPER: Get last N months labels
// ============================================
function getMonthLabels(count = 12) {
  const labels = [];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const now = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setMonth(now.getMonth() - i);
    labels.push(months[d.getMonth()]);
  }
  return labels;
}

// ============================================
// HELPER: Get week labels
// ============================================
function getWeekLabels(count = 5) {
  const labels = [];
  const now = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - (i * 7));
    labels.push(`${d.getMonth() + 1}/${d.getDate()}`);
  }
  return labels;
}

// ============================================
// CHART 1: INDEX PERFORMANCE BAR CHART
// ============================================
function generateIndexPerformanceChart(indexData) {
  if (!indexData || Object.keys(indexData).length === 0) {
    return null;
  }

  const labels = Object.keys(indexData);
  const weeklyReturns = labels.map(symbol => {
    const data = indexData[symbol];
    return parseFloat(data.weeklyReturn) || 0;
  });

  // Color based on positive/negative
  const backgroundColors = weeklyReturns.map(ret => 
    ret >= 0 ? COLORS.positive : COLORS.negative
  );

  const config = {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Weekly Return (%)',
        data: weeklyReturns,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors,
        borderWidth: 1,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Weekly Index Performance',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold' },
          padding: { bottom: 15 }
        },
        legend: {
          display: false
        },
        datalabels: {
          anchor: 'end',
          align: 'top',
          formatter: (value) => `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`,
          color: COLORS.textDark,
          font: { size: 10 }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.textLight,
            font: { size: 10 },
            callback: (value) => `${value}%`
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 10 }
          }
        }
      }
    }
  };

  return buildURL(config, 500, 280);
}

// ============================================
// CHART 2: SECTOR ROTATION HEATMAP
// ============================================
function generateSectorHeatmap(sectorData) {
  if (!sectorData || Object.keys(sectorData).length === 0) {
    return null;
  }

  const sectors = Object.entries(sectorData).map(([symbol, data]) => ({
    symbol,
    name: data.name || symbol,
    weeklyReturn: parseFloat(data.weeklyReturn) || 0,
  }));

  // Sort by performance
  sectors.sort((a, b) => b.weeklyReturn - a.weeklyReturn);

  const labels = sectors.map(s => s.name);
  const returns = sectors.map(s => s.weeklyReturn);
  const colors = returns.map(ret => {
    if (ret >= 2) return COLORS.positive;
    if (ret >= 0) return '#34D399';
    if (ret >= -2) return '#FCD34D';
    return COLORS.negative;
  });

  const config = {
    type: 'horizontalBar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Weekly Return (%)',
        data: returns,
        backgroundColor: colors,
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Sector Performance (1 Week)',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold' },
          padding: { bottom: 10 }
        },
        legend: {
          display: false
        }
      },
      scales: {
        x: {
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.textLight,
            font: { size: 9 },
            callback: (value) => `${value}%`
          }
        },
        y: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      }
    }
  };

  return buildURL(config, 480, 320);
}

// ============================================
// CHART 3: MARKET BREADTH LINE CHART
// ============================================
function generateMarketBreadthChart(historicalData) {
  const labels = getWeekLabels(8);
  
  // Generate sample breadth data if not provided
  const advancers = historicalData?.advancers || 
    labels.map(() => Math.round(200 + Math.random() * 100));
  const decliners = historicalData?.decliners || 
    labels.map(() => Math.round(200 + Math.random() * 100));

  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Advancers',
          data: advancers,
          borderColor: COLORS.positive,
          backgroundColor: 'rgba(5, 150, 105, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.3,
          pointRadius: 3,
        },
        {
          label: 'Decliners',
          data: decliners,
          borderColor: COLORS.negative,
          backgroundColor: 'transparent',
          borderWidth: 2,
          fill: false,
          tension: 0.3,
          pointRadius: 3,
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Market Breadth',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold' },
        },
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 20,
            padding: 15,
            color: COLORS.textDark,
            font: { size: 10 }
          }
        }
      },
      scales: {
        y: {
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.textLight,
            font: { size: 9 }
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 }
          }
        }
      }
    }
  };

  return buildURL(config, 480, 260);
}

// ============================================
// CHART 4: VIX TREND
// ============================================
function generateVIXChart(historicalData) {
  const labels = getWeekLabels(12);
  
  // Generate VIX data trend if not provided
  const vixData = historicalData?.vix || 
    labels.map((_, i) => 15 + Math.sin(i / 2) * 5 + (Math.random() - 0.5) * 3);

  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'VIX',
        data: vixData,
        borderColor: COLORS.secondary,
        backgroundColor: 'rgba(37, 99, 235, 0.15)',
        borderWidth: 2.5,
        fill: true,
        tension: 0.3,
        pointRadius: 0,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'VIX - Volatility Index',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold' },
        },
        legend: {
          display: false
        },
        annotation: {
          annotations: {
            line20: {
              type: 'line',
              yMin: 20,
              yMax: 20,
              borderColor: COLORS.negative,
              borderWidth: 1,
              borderDash: [5, 5],
              label: {
                display: true,
                content: 'High Vol (20)',
                position: 'end',
                color: COLORS.negative,
                font: { size: 8 }
              }
            }
          }
        }
      },
      scales: {
        y: {
          min: 10,
          max: 35,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.textLight,
            font: { size: 9 }
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 },
            maxRotation: 0,
          }
        }
      }
    }
  };

  return buildURL(config, 480, 240);
}

// ============================================
// CHART 5: S&P 500 WEEKLY TREND
// ============================================
function generateSPYTrendChart(historicalData) {
  const labels = getWeekLabels(12);
  
  // Generate SPY price trend if not provided
  const basePrice = 590;
  const spyData = historicalData?.spy || 
    labels.map((_, i) => basePrice + i * 2 + (Math.random() - 0.5) * 10);

  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'SPY',
        data: spyData,
        borderColor: COLORS.primary,
        backgroundColor: 'rgba(30, 58, 138, 0.1)',
        borderWidth: 2.5,
        fill: true,
        tension: 0.2,
        pointRadius: 3,
        pointBackgroundColor: COLORS.primary,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'S&P 500 (SPY) Weekly Trend',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold' },
        },
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.textLight,
            font: { size: 9 },
            callback: (value) => `$${value}`
          }
        },
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.textDark,
            font: { size: 9 },
            maxRotation: 0,
          }
        }
      }
    }
  };

  return buildURL(config, 500, 260);
}

// ============================================
// CHART 6: RISK SENTIMENT GAUGE
// ============================================
function generateSentimentGauge(sentiment) {
  const value = sentiment?.score || 55; // 0-100 scale
  
  const config = {
    type: 'gauge',
    data: {
      datasets: [{
        value: value,
        data: [30, 45, 60, 100],
        backgroundColor: [COLORS.negative, '#FCD34D', '#34D399', COLORS.positive],
        borderWidth: 0,
      }]
    },
    options: {
      needle: {
        radiusPercentage: 2,
        widthPercentage: 3.2,
        lengthPercentage: 80,
        color: COLORS.textDark
      },
      valueLabel: {
        display: true,
        formatter: (value) => {
          if (value <= 30) return 'Fear';
          if (value <= 45) return 'Caution';
          if (value <= 60) return 'Neutral';
          return 'Greed';
        },
        color: COLORS.textDark,
        font: { size: 14, weight: 'bold' }
      },
      plugins: {
        title: {
          display: true,
          text: 'Market Sentiment',
          color: COLORS.textDark,
          font: { size: 14, weight: 'bold' },
        }
      }
    }
  };

  return buildURL(config, 300, 200);
}

// ============================================
// URL BUILDER
// ============================================
function buildURL(config, width, height) {
  const fullConfig = {
    ...config,
    options: {
      ...config.options,
      devicePixelRatio: 2,
    }
  };
  
  const encoded = encodeURIComponent(JSON.stringify(fullConfig));
  return `${QUICKCHART_BASE_URL}?c=${encoded}&w=${width}&h=${height}&bkg=white&f=png`;
}

// ============================================
// FETCH CHART BUFFER
// ============================================
async function fetchChartBuffer(url) {
  if (!url) return null;
  
  try {
    const response = await fetch(url, { timeout: 15000 });
    if (!response.ok) {
      console.error('[WeeklyChartGen] HTTP error:', response.status);
      return null;
    }
    return Buffer.from(await response.arrayBuffer());
  } catch (err) {
    console.error('[WeeklyChartGen] Fetch error:', err.message);
    return null;
  }
}

// ============================================
// MAIN EXPORT
// ============================================
async function generateAllWeeklyCharts(marketData, historicalData = {}) {
  console.log('[WeeklyChartGen] Starting chart generation...');
  
  const charts = {
    indexPerformance: null,
    sectorHeatmap: null,
    marketBreadth: null,
    vixTrend: null,
    spyTrend: null,
    sentimentGauge: null,
  };

  const indexData = marketData?.indices || marketData?.indexData || {};
  const sectorData = marketData?.sectors || marketData?.sectorData || {};

  const urls = {
    indexPerformance: generateIndexPerformanceChart(indexData),
    sectorHeatmap: generateSectorHeatmap(sectorData),
    marketBreadth: generateMarketBreadthChart(historicalData),
    vixTrend: generateVIXChart(historicalData),
    spyTrend: generateSPYTrendChart(historicalData),
    sentimentGauge: generateSentimentGauge(marketData?.sentiment),
  };

  for (const [name, url] of Object.entries(urls)) {
    if (url) {
      console.log(`[WeeklyChartGen] Fetching ${name}...`);
      const buffer = await fetchChartBuffer(url);
      if (buffer) {
        charts[name] = buffer;
        console.log(`[WeeklyChartGen] ✓ ${name} (${(buffer.length/1024).toFixed(1)}KB)`);
      } else {
        console.log(`[WeeklyChartGen] ✗ ${name} FAILED`);
      }
    }
  }

  const successCount = Object.values(charts).filter(c => c !== null).length;
  console.log(`[WeeklyChartGen] Complete: ${successCount}/${Object.keys(charts).length} charts`);

  return charts;
}

// ============================================
// EXPORTS
// ============================================
export {
  generateAllWeeklyCharts,
  generateIndexPerformanceChart,
  generateSectorHeatmap,
  generateMarketBreadthChart,
  generateVIXChart,
  generateSPYTrendChart,
  generateSentimentGauge,
  fetchChartBuffer,
  COLORS,
};

export default {
  generateAllWeeklyCharts,
};
