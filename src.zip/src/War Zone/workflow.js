// ============================================================================
// FINOTAUR INTELLIGENCE - WORKFLOW v11.0 WITH REAL DATA
// ============================================================================
// Uses data-service-v2 with verified Yahoo Finance data
// ============================================================================

import {
  fetchAllMarketData,
  fetchAnalystActions,
  fetchOptionsFlow,
  fetchFedContext,
  fetchEconomicCalendar,
  fetchNewsAndEarnings,
  buildLockedPrices,
  REAL_PRICES_JAN_2026,
  REAL_ANALYST_ACTIONS,
  REAL_EARNINGS_CALENDAR,
  REAL_ECONOMIC_CALENDAR,
  REAL_FED_CONTEXT,
  REAL_OPTIONS_FLOW,
} from './data-service.js';

import agents, { AGENT_PHASES, runAgent, runQAEditor, runPhase } from './agents.js';
import { SECTION_ORDER, SECTION_CONFIG } from './config.js';

// ============================================================================
// MAIN WORKFLOW
// ============================================================================
export async function runFullWorkflow(options = {}) {
  console.log('\n' + '='.repeat(60));
  console.log('🦎 FINOTAUR INTELLIGENCE - Daily Report Generation');
  console.log('='.repeat(60));
  console.log(`📅 Date: ${new Date().toISOString().split('T')[0]}`);
  console.log(`🎯 Mode: ${options.useLiveAPI ? 'Live API' : 'Real Data Fallback'}`);
  console.log('='.repeat(60) + '\n');

  // ========================================
  // PHASE 1: DATA COLLECTION
  // ========================================
  console.log('\n📊 PHASE 1: Data Collection');
  console.log('-'.repeat(40));

  // Fetch market data (uses real fallback if no API)
  const marketData = await fetchAllMarketData();
  const lockedPrices = buildLockedPrices(marketData);
  
  // Fetch analyst data
  const analystData = await fetchAnalystActions();
  
  // Fetch options flow
  const optionsFlow = await fetchOptionsFlow();
  
  // Fetch Fed context
  const fedContext = await fetchFedContext();
  
  // Fetch economic calendar
  const economicCalendar = await fetchEconomicCalendar();
  
  // Fetch news and earnings
  const newsAndEarnings = await fetchNewsAndEarnings();
  
  // Build context object
  const context = {
    lockedPrices,
    marketData,
    analystData: {
      actions: analystData,
    },
    optionsFlow: {
      unusualActivity: optionsFlow,
    },
    fedContext: {
      currentRate: fedContext.currentRate,
      lastAction: fedContext.lastAction.type + ' ' + fedContext.lastAction.amount,
      lastActionDate: fedContext.lastAction.date,
      nextMeeting: fedContext.nextMeeting,
      marketExpectations: {
        probability: fedContext.marketPricing.hold,
        nextMeeting: 'Hold',
        yearEndRate: fedContext.yearEndExpectation,
        cutsExpected: fedContext.impliedCuts,
      },
      inflationWatch: {
        cpi: { latest: fedContext.inflation.cpiYoY.toString() },
        pce: { latest: fedContext.inflation.corePceYoY.toString() },
      },
    },
    economicCalendar: {
      highImportance: economicCalendar.filter(e => e.importance === 'high'),
      thisWeek: economicCalendar,
    },
    newsData: newsAndEarnings,
    earningsData: newsAndEarnings.earnings,
  };

  console.log('\n✅ Data collection complete');
  console.log(`   • Market data: ${Object.keys(lockedPrices.indices).length} indices`);
  console.log(`   • Analyst actions: ${analystData.length}`);
  console.log(`   • Options flow: ${optionsFlow.length}`);
  console.log(`   • Economic events: ${economicCalendar.length}`);

  // ========================================
  // PHASE 2: REPORT GENERATION
  // ========================================
  console.log('\n📝 PHASE 2: Report Generation');
  console.log('-'.repeat(40));

  const sections = {};
  const openaiKey = process.env.OPENAI_API_KEY;

  for (const sectionKey of SECTION_ORDER) {
    console.log(`\n   Generating: ${sectionKey}...`);
    
    const content = await runAgent(sectionKey, context, openaiKey);
    sections[sectionKey] = content;
    
    console.log(`   ✓ ${sectionKey}: ${content.length} chars`);
  }

  // ========================================
  // PHASE 3: QA & ASSEMBLY
  // ========================================
  console.log('\n🔍 PHASE 3: Quality Assurance');
  console.log('-'.repeat(40));

  // Build full report
  const fullReport = Object.entries(sections)
    .map(([key, content]) => {
      const config = SECTION_CONFIG[key];
      return `## ${config?.title || key}\n\n${content}`;
    })
    .join('\n\n---\n\n');

  // Run QA editor
  const editedReport = await runQAEditor(fullReport, openaiKey);
  
  // Calculate QA score based on report quality checks
  const qaScore = calculateQAScore(editedReport || fullReport);
  
  console.log('\n✅ Report generation complete');
  console.log(`   • Total sections: ${Object.keys(sections).length}`);
  console.log(`   • Total characters: ${fullReport.length}`);
  console.log(`   • QA Score: ${qaScore}/100`);

  return {
    success: true,
    sections,
    report: editedReport || fullReport,
    fullReport: editedReport || fullReport,
    qaScore,
    lockedPrices,
    context,
    generatedAt: new Date().toISOString(),
  };
}

// QA Score Calculator
function calculateQAScore(report) {
  let score = 100;
  
  // Penalize AI artifacts
  const aiPatterns = [
    'Based on analysis', 'Based on the analysis', 'It\'s worth noting',
    'Additionally,', 'Furthermore,', 'Moreover,', 'In conclusion', 'Moving forward'
  ];
  for (const pattern of aiPatterns) {
    if (report.includes(pattern)) score -= 5;
  }
  
  // Check for specific data points
  const hasTickerFormat = (report.match(/\*\*[A-Z]{1,5}\*\*/g) || []).length;
  if (hasTickerFormat < 5) score -= 10;
  
  // Check for price levels
  const hasPriceLevels = (report.match(/\$\d+/g) || []).length;
  if (hasPriceLevels < 3) score -= 10;
  
  // Check for proper sections
  const sectionCount = (report.match(/^## /gm) || []).length;
  if (sectionCount < 5) score -= 10;
  
  return Math.max(0, Math.min(100, score));
}

// ============================================================================
// QUICK DATA SUMMARY (for testing)
// ============================================================================
export function getDataSummary() {
  console.log('\n📊 FINOTAUR DATA SUMMARY');
  console.log('='.repeat(50));
  
  console.log('\n🏛️ MARKET DATA (Jan 3, 2026):');
  ['SPY', 'QQQ', 'IWM', 'NVDA', 'AAPL', 'TSLA'].forEach(sym => {
    const d = REAL_PRICES_JAN_2026[sym];
    if (d) {
      console.log(`   ${sym}: $${d.price.toFixed(2)} (${d.changePercent >= 0 ? '+' : ''}${d.changePercent.toFixed(2)}%)`);
    }
  });
  
  console.log('\n📈 ANALYST ACTIONS:');
  REAL_ANALYST_ACTIONS.slice(0, 5).forEach(a => {
    console.log(`   ${a.ticker}: ${a.firm} - ${a.action}`);
    if (a.priceTarget) console.log(`      PT: $${a.priceTarget}`);
  });
  
  console.log('\n📅 EARNINGS CALENDAR (Upcoming):');
  REAL_EARNINGS_CALENDAR
    .filter(e => new Date(e.date) >= new Date())
    .slice(0, 5)
    .forEach(e => {
      console.log(`   ${e.ticker}: ${e.date} ${e.time}`);
    });
  
  console.log('\n🗓️ ECONOMIC CALENDAR:');
  REAL_ECONOMIC_CALENDAR.slice(0, 5).forEach(e => {
    console.log(`   ${e.date} ${e.time}: ${e.event}`);
    console.log(`      Previous: ${e.previous} | Forecast: ${e.forecast}`);
  });
  
  console.log('\n🏦 FED CONTEXT:');
  console.log(`   Rate: ${REAL_FED_CONTEXT.currentRate}`);
  console.log(`   Next Meeting: ${REAL_FED_CONTEXT.nextMeeting}`);
  console.log(`   Market Pricing: Hold ${REAL_FED_CONTEXT.marketPricing.hold}%`);
  
  return { success: true };
}

// ============================================================================
// QUICK WORKFLOW (for faster generation)
// ============================================================================
export async function runQuickWorkflow(options = {}) {
  console.log('\n⚡ Running Quick Workflow...');
  return await runFullWorkflow({ ...options, quick: true });
}

// ============================================================================
// WORKFLOW STATUS (for progress tracking)
// ============================================================================
let workflowStatus = {
  running: false,
  progress: 0,
  currentPhase: null,
  startedAt: null,
};

export function getWorkflowStatus() {
  return workflowStatus;
}

export function resetStatus() {
  workflowStatus = {
    running: false,
    progress: 0,
    currentPhase: null,
    startedAt: null,
  };
  return workflowStatus;
}

export function getWorkflowPhasesInfo() {
  return {
    phases: ['DATA_COLLECTION', 'REPORT_GENERATION', 'QA_ASSEMBLY'],
    sections: SECTION_ORDER,
  };
}

// ============================================================================
// CLI ENTRY
// ============================================================================
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  
  if (args.includes('--summary')) {
    getDataSummary();
  } else {
    runFullWorkflow()
      .then(result => {
        console.log('\n✅ Workflow complete!');
        console.log(`   Generated at: ${result.generatedAt}`);
        console.log(`   QA Score: ${result.qaScore}/100`);
      })
      .catch(err => {
        console.error('❌ Workflow failed:', err);
        process.exit(1);
      });
  }
}

export default {
  runFullWorkflow,
  runQuickWorkflow,
  getWorkflowStatus,
  getWorkflowPhasesInfo,
  getDataSummary,
  resetStatus,
};