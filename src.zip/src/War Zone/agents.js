// ============================================================================
// FINOTAUR INTELLIGENCE - AGENTS v16.6
// ============================================================================
// MEIDA PNIM INSTITUTIONAL TRADING DESK STYLE
// 
// v16.6 TABLE NEWLINE FIX:
// - Added fixTableNewlines() function in runQAEditor
// - QA Editor output now preserves table structure
// - Global Arena fallback starts with "MARKET DATA SNAPSHOT" header
// - Tables separated from text with proper newlines
//
// v16.5 TABLE INJECTION FIX:
// - Tables are now INJECTED into GPT responses (not just fallback)
// - injectSectionTables() adds tables after GPT generates content
// - Analyst Arena: Adds analyst actions table after intro
// - Macro Arena: Adds economic calendar table at start
// - Reports: Adds earnings calendar table before UPCOMING section
// - Tables appear regardless of whether GPT or fallback is used
//
// v16.4 TABLES ENHANCEMENT - MEIDA PNIM STYLE:
// - Added Analyst Summary Table in Analyst Arena section
//   Format: | Ticker | Rating | Price Target | Firm |
// - Added Economic Calendar Table in Macro Arena section
//   Format: | Event | Date | Time | Previous | Expected | Impact |
// - Added Upcoming Earnings Calendar Table in Reports section  
//   Format: | Ticker | Company | Date | Time | EPS Est | Rev Est |
// - Tables provide quick-reference data before detailed analysis
// - Matches Meida Pnim format for professional presentation
//
// v16.3 GLOBAL ARENA & WHAT'S HAPPENING REDESIGN:
// - Global Arena now includes DATA TABLE with all numerical data
// - Narrative paragraphs in Global Arena contain NO NUMBERS
// - What's Happening Now focuses on NEWS and CATALYSTS only
// - Removed price-focused content from What's Happening
// - All content is 100% dynamic based on real-time data
//
// v16.2 DYNAMIC DATE SYSTEM:
// - Added getDynamicDates() helper function for all date calculations
// - Reports fallback: Uses dynamic earnings season dates
// - Week Ahead fallback: Uses nextDay1-5 for upcoming business days
// - Buyback section: Dynamic blackout window calculation based on quarter
// - Year references: All "Top Pick for YEAR" now use dates.year
// - Removed ALL hardcoded month/day references from fallbacks
//
// v16.1 CRITICAL FIXES:
// - Removed ALL ** bold markers from fallback content
// - Numbered points now use proper two-part structure: title line + blank line + explanation
// - Tactical Corner: Restructured 4 numbered points with proper hierarchy
// - Focus Corner: Removed ** from all stock headers (topPick, upgrade, ptRaise, options)
// - Reports section: Removed ** from ticker symbols
// - Week Ahead: Fixed "Key Themes to Watch" structure - title/explanation separated
// - Tactical implications function: Proper \n\n separation between title and explanation
//
// v16.0 CRITICAL FIXES:
// - Reports section: Proper blank lines after headers (REPORTED YESTERDAY...)
// - "No earnings" messages as standalone paragraphs, not inline with headers
// - Week Ahead: Calendar entries properly separated with blank lines
// - More aggressive AI phrase elimination (15+ forbidden patterns)
// - Enhanced paragraph structure enforcement
// - Added ensureProperLineBreaks() post-processing function
//
// v15.1 UPGRADES:
// - Global Arena: "Yesterday's Highlights" opening section with historical comparisons
// - What's Happening: "What's Interesting Today?" quick bullet summary
// - Tactical Corner: Dedicated "Fund Flows" and "Buybacks" subsections
// - Historical comparisons: "longest streak since 1987", "first time since Q4 2021"
// - Thematic narrative titles: "Bad news is good news", "The soft landing thesis"
//
// v15.0 FEATURES:
// - Reports section: "Reported Yesterday" vs "Reporting Today" structure
// - Reports: Management quotes in italics, YoY comparisons, ARR/margins
// - Tactical Corner: Thematic subtitle + cited sources (Bank of America, etc.)
// - Analyst Arena: Analyst name first + deep reasoning explanation
// - Macro Arena: "Previous X | Expected Y" clean format + scenario analysis
// - Focus Corner: Current % movement + cross-section references
// - Human signature phrases: "This is a key point:", "The story here is:"
// - Removed AI artifacts completely
// ============================================================================

import {
  SECTION_CONFIG,
  tickerToCompanyName,
  formatPercent,
  formatPrice,
} from './config.js';

// ============================================================================
// AGENT PHASES - MEIDA PNIM STYLE v5.0
// ============================================================================
export const AGENT_PHASES = {
  OPENING: ['globalArena', 'whatsHappening', 'weekAhead'],
  ANALYSIS: ['macroArena', 'analystArena'],
  TRADING: ['tacticalCorner', 'focusCorner'],
  REPORTS: ['reports'],
  QA: ['QA_EDITOR'],
};

// ============================================================================
// REAL ANALYST QUOTES LIBRARY
// ============================================================================
const ANALYST_QUOTES = {
  bullish: [
    'sees significant upside potential from current levels',
    'believes the market is underestimating growth trajectory',
    'points to improving fundamentals and margin expansion',
    'highlights underappreciated catalysts ahead',
    'notes institutional positioning remains light',
  ],
  bearish: [
    'warns of multiple compression risk at current valuation',
    'cites competitive headwinds intensifying',
    'sees margin pressure building through 2026',
    'points to slowing growth metrics quarter-over-quarter',
    'believes consensus estimates are too optimistic',
  ],
  neutral: [
    'sees balanced risk/reward at current levels',
    'maintains neutral stance pending clarity on growth',
    'awaits catalyst before becoming more constructive',
    'notes stock fairly valued given current fundamentals',
  ],
};

// ============================================================================
// MASTER WRITING GUIDE - MEIDA PNIM STYLE v5.0 (Enhanced Formatting)
// ============================================================================
const MASTER_GUIDE = `
## WRITING STYLE: MEIDA PNIM INSTITUTIONAL TRADING DESK

You are writing the daily intelligence report for professional traders at an Israeli institutional desk.
Your readers manage millions of dollars and need ACTIONABLE intelligence, not generic summaries.

### GOLDEN RULES:

1. PARAGRAPH STRUCTURE - CRITICAL
   - Each paragraph expresses ONE main idea or message
   - Maximum 4-5 sentences per paragraph (about 6 lines)
   - Put a BLANK LINE between every paragraph
   - Put a BLANK LINE after every header/subheader
   - Long analysis must be broken into multiple short paragraphs
   - Never write wall-of-text blocks

2. CITE YOUR SOURCES
   - Name the data source: "Bank of America data shows...", "Mastercard, Adobe and Chase data indicate..."
   - Name the analyst: "Analyst Peter Wade notes that...", "According to Morgan Stanley's Joseph Moore..."
   - Makes the report feel human-researched, not AI-generated

3. HUMAN SIGNATURE PHRASES (USE THESE - FROM MEIDA PNIM)
   - "This is a key level to watch"
   - "The question here is whether..."
   - "On one hand... on the other hand..."
   - "The picture remains two-sided"
   - "As long as X remains Y, Z continues"
   - "If X doesn't break, the trend continues"
   - "This is the number that defines positioning"
   - "The goldilocks zone is..."
   - "Watch for confirmation"

4. MANAGEMENT QUOTES IN REPORTS
   - Include CEO/CFO quotes in italics for earnings reports
   - Format: _"Quote text here."_ - Name, Title
   - Example: _"We achieved record revenue in Q3."_ - John Smith, CEO

5. EVERY SENTENCE PASSES THE "SO WHAT?" TEST
   - BAD: "VIX dropped to 14.2"
   - GOOD: "VIX at 14.2 signals complacency - historically this level precedes either continuation or sharp reversals within two weeks"

6. CAUSE-EFFECT CHAINS WITH SPECIFIC NUMBERS
   - Include specific dollar amounts, percentages, dates
   - BAD: "Retail spending was strong"
   - GOOD: "Retail spending jumped $8.6 billion in one week, the strongest holiday effect in years"
   - ALWAYS explain what happens if data is ABOVE vs BELOW expectations

7. CLEAN FORMATTING RULES - ABSOLUTELY CRITICAL
   - NO asterisks or stars (* or **) anywhere in output
   - NO bold markers of any kind
   - Write section headers as plain text: "Fund Flows - Where Is the Big Money Going?"
   - Write stock tickers as plain text: "NVDA - NVIDIA Corporation"
   - Use natural prose, not fragmented bullet lists
   - Numbered items should be: "1. First point here." then BLANK LINE, then "2. Second point here."

8. SECTION HEADERS FORMAT - CRITICAL FOR PDF
   - ALWAYS put a BLANK LINE after section headers
   - Headers like "REPORTED YESTERDAY AFTER MARKET CLOSE" need BLANK LINE before content
   - "No earnings reports" should be its own paragraph, not inline with header
   - Calendar entries need BLANK LINE between each day

9. PUNCTUATION RULES
   - Use ONLY period (.) comma (,) and dash (-)
   - NO colons (:) in narrative sentences - use dash or comma instead
   - Data formats: "Previous 48.7 | Expected 49.0" with pipe separator
   - NO semicolons (;) - use comma or period

### ABSOLUTELY FORBIDDEN:
- Double asterisks (**) for bold text - NEVER USE
- Single asterisks (*) for emphasis - NEVER USE
- "Based on analysis" / "Based on the data" - NEVER
- "It's worth noting" / "It should be noted" - DELETE
- "Additionally," / "Furthermore," / "Moreover," - GENERIC
- "In conclusion" / "To summarize" - JUST END NATURALLY
- "The market is showing" - BE SPECIFIC
- "Investors are watching" - VAGUE AND USELESS
- "Moving forward" / "Going forward" - NEVER SAY THIS
- "It appears that" / "It seems that" - BE DIRECT
- "This indicates that" - JUST SAY WHAT IT MEANS
- "As mentioned earlier" / "As noted above" - REDUNDANT
- "could potentially" / "may possibly" - COMMIT TO A VIEW

### LANGUAGE:
- Write ONLY in English
- Use active voice
- Short paragraphs (max 5 sentences each)
- Professional but readable
- Direct and decisive, not hedging
`;

// ============================================================================
// SECTION PROMPTS - MEIDA PNIM STYLE v5.0
// ============================================================================
export const SECTION_PROMPTS = {
  
  // ========================================
  // THE GLOBAL ARENA - MEIDA PNIM STYLE
  // ========================================
  globalArena: `
${MASTER_GUIDE}

## YOUR TASK: Write "The Global Arena"

This is the OPENING of the daily report. MUST INCLUDE:
1. A compact DATA TABLE summarizing yesterday's session
2. NARRATIVE paragraphs about market themes (NO NUMBERS in narrative)

### STRUCTURE:

PART 1 - DATA TABLE (Required):
Create a compact markdown table with yesterday's key data:

| Index | Close | Change | Note |
|-------|-------|--------|------|
| SPY | $XXX.XX | +X.XX% | Brief context |
| QQQ | $XXX.XX | +X.XX% | Brief context |
| IWM | $XXX.XX | +X.XX% | Brief context |

| Indicator | Value | Signal |
|-----------|-------|--------|
| VIX | XX.X | Low/Normal/Elevated |
| 10Y Yield | X.XX% | Direction |
| DXY | XXX.X | Strength/Weakness |

| Sector | Performance | Leader/Laggard |
|--------|-------------|----------------|
| Top | XLK +X.X% | Tech leading |
| Bottom | XLU -X.X% | Defensives lagging |

PART 2 - MARKET NARRATIVE (NO NUMBERS!):
After the table, write 2-3 paragraphs of PURE NARRATIVE. This section should:
- NEVER mention specific prices, percentages, or numbers
- Focus on WHY things happened (catalysts, sentiment drivers)
- Explain market psychology and positioning
- Discuss what traders are watching
- Reference upcoming events and expectations

### NARRATIVE STYLE GUIDE (No Numbers!):
INSTEAD OF: "SPY closed at $683, up 0.37%"
WRITE: "Markets pushed higher as risk appetite returned"

INSTEAD OF: "VIX at 15.94 signals low fear"
WRITE: "Volatility remains subdued, suggesting complacency"

INSTEAD OF: "Rate cut expectations at 2 for the year"
WRITE: "Markets continue pricing a dovish Fed trajectory"

### NARRATIVE TOPICS TO COVER:
- The dominant market theme (tech rotation, rate sensitivity, etc.)
- Key catalysts driving the session
- Sector leadership story and what it signals
- Market sentiment and positioning
- What's on the horizon (upcoming data, events, earnings)
- What needs to happen for the trend to continue/reverse

### DATA PROVIDED:
{marketData}

### EXAMPLE OUTPUT:

| Index | Close | Change | Note |
|-------|-------|--------|------|
| SPY | $683.17 | -0.37% | First red day in 5 sessions |
| QQQ | $505.22 | -1.12% | Largest drop in 2 weeks |
| IWM | $225.40 | +0.46% | Small caps outperform |

| Indicator | Value | Signal |
|-----------|-------|--------|
| VIX | 15.94 | Low fear |
| 10Y Yield | 4.58% | Rising |
| DXY | 108.5 | Strong dollar |

| Sector | Performance |
|--------|-------------|
| Top | XLF +1.2% |
| Bottom | XLK -1.5% |

Markets took a breather yesterday after an impressive run, with profit-taking emerging in the technology sector while financials and small caps showed relative strength. The rotation under the surface tells a more nuanced story than the headline numbers suggest - investors are repositioning rather than running for the exits.

The Fed narrative remains the central driver of market psychology. Recent minutes revealed a more cautious tone on rate cuts, keeping traders on edge ahead of upcoming inflation data. Any deviation from expectations could spark significant repositioning, particularly in rate-sensitive sectors that have led recent gains.

Looking ahead, the focus shifts to the economic calendar and the approaching earnings season. Bank earnings will set the tone for the financial sector, while guidance from technology leaders will determine whether the AI trade has legs into the new year. Market participants are watching for confirmation that the soft landing scenario remains intact.

### NOW WRITE THE SECTION (table first, then narrative without numbers):`,

  // ========================================
  // WHAT'S HAPPENING NOW - MEIDA PNIM STYLE
  // ========================================
  whatsHappening: `
${MASTER_GUIDE}

## YOUR TASK: Write "What's Happening Now"

This section covers NEWS and CATALYSTS - what's driving the market narrative today.
Focus on EVENTS, STORIES, and UPCOMING CATALYSTS - NOT price movements.

### STRUCTURE:

OPENING SUMMARY (4-5 bullet points):
Key news stories and catalysts driving today's narrative:
- Company-specific news (earnings, product launches, management changes)
- Macro events (Fed speeches, economic data, geopolitical)
- Analyst actions (upgrades, downgrades, price target changes)
- Sector themes (rotation, regulatory, industry trends)

Then 3-4 DETAILED THEMES as continuous paragraphs:

Each theme covers ONE story in depth with TRADING IMPLICATIONS.
Focus on: What happened? Why does it matter? What should traders watch?

### CONTENT FOCUS:
- NEWS: What happened overnight, pre-market, or is expected today
- CATALYSTS: Upcoming events that could move markets
- ANALYST VIEWS: Key calls and their reasoning
- SECTOR THEMES: Broader narratives driving rotation
- WHAT TO WATCH: Key levels, events, or triggers

### AVOID:
- Repeating data from Global Arena tables
- Generic market commentary
- Price targets without context
- Lists of numbers without narrative

### DATA PROVIDED:
{newsData}
{analystData}
{fedContext}
{economicCalendar}
{earningsData}

### EXAMPLE OUTPUT:

What's Happening Now

- NVIDIA's CES keynote tomorrow could reignite the AI trade as Jensen Huang unveils next-gen Blackwell architecture
- Fed minutes due Wednesday may clarify the timeline for potential rate adjustments amid sticky inflation
- Tesla delivery numbers disappointed, raising questions about margin guidance and EV sector competition
- Bank earnings kick off next week with JPMorgan, Goldman Sachs, and Wells Fargo setting the tone

NVDA - CES Keynote Poised to Ignite AI Sector

Jensen Huang's keynote at CES 2026 is expected to unveil next-gen Blackwell GPUs and an expanded robotics platform, positioning NVIDIA at the forefront of AI innovation. This event has the potential to reignite enthusiasm in tech stocks, particularly for NVIDIA, AMD, and INTC. Analysts are optimistic, with Cantor Fitzgerald setting a bullish price target, suggesting that a strong product announcement could trigger a rally.

Fed Minutes - Clarity on Rate Path Expected

The release of FOMC minutes will be a market mover, providing insight into the Fed's thought process. Traders will analyze any shifts in tone regarding inflation and the economic outlook. The story here is whether the Fed remains committed to its inflation targets or signals a potential pivot in policy. Hawkish signals could tighten financial conditions and pressure growth sectors.

Bank Earnings - The Tell for Financials

JPMorgan, Goldman Sachs, and Wells Fargo report next week, kicking off earnings season. The focus will be on net interest income trends and trading revenue. Strong NII guidance would support the case for financial sector leadership, while any weakness in credit quality could raise concerns about the economic cycle. This is the most important week for XLF positioning.

### NOW WRITE THE SECTION (focus on news and catalysts, not price data):`,

  // ========================================
  // MACRO ARENA - MEIDA PNIM STYLE
  // ========================================
  macroArena: `
${MASTER_GUIDE}

## YOUR TASK: Write "The Macro Arena"

Cover today's economic data releases with TRADER context.
Not just what's coming - what it MEANS for positioning.

### REQUIRED FORMAT FOR EACH DATA POINT:

Event Name - Release Time ET
Previous X | Expected Y

[3-5 sentences covering]:
- Why this data matters RIGHT NOW
- SCENARIO ANALYSIS: What happens if ABOVE expectations? What happens if BELOW?
- The "goldilocks" threshold or key number to watch
- Specific stocks/sectors affected

CRITICAL: Use pipe separator | in "Previous X | Expected Y"
CRITICAL: Put a BLANK LINE between each economic data point
CRITICAL: Include scenario analysis for major releases
CRITICAL: End with "What Does This Mean Tactically?" with numbered points

### DATA PROVIDED:
{economicCalendar}
{fedContext}

### EXAMPLE OUTPUT (Meida Pnim Style):

ISM Manufacturing PMI - 10:00 AM ET
Previous 48.7 | Expected 49.0

The ISM manufacturing index is expected to edge higher from 48.7 to 49.0, but remain below the 50 threshold separating expansion from contraction. This tells us the manufacturing sector in the US is still struggling, but if expectations materialize, we're talking about a slowdown, not collapse.

On one hand, weakness signals less pressure on the Fed to stay hawkish. On the other hand, no collapse means no recession signal that would force emergency cuts. A print below 48.0 strengthens the soft landing thesis and supports rate-sensitive plays. Watch XLI and defense names for rotation signals.

Nonfarm Payrolls - 8:30 AM ET
Previous 227K | Expected 175K

This is the main event of the week. A print above 200K pushes rate cut expectations to March, pressuring growth stocks and boosting DXY. Below 150K and treasuries rally hard - watch TLT for a potential break above its 200-day MA at $94.

The goldilocks zone is 160-190K: enough job creation to avoid recession fears, not enough to reignite inflation concerns. This is the number that defines positioning for the next two weeks.

CPI MoM - 8:30 AM ET
Previous 0.3% | Expected 0.2%

Inflation remains the Fed's primary focus. The threshold to watch is 0.3% - if we exceed this, expect volatility across rate-sensitive sectors. A reading below 0.2% could accelerate rate cut expectations and provide a significant tailwind for growth stocks. The picture remains two-sided: progress on inflation versus services stickiness.

What Does This Mean Tactically?

1. Data beats showing economic strength paradoxically pressure equities.

The "good news is bad news" regime persists for rate-sensitive names until the Fed pivots.

2. TLT is the tell for the broader market.

If bonds rally on weak data, growth stocks follow. Watch for confirmation before adding duration exposure.

3. Have your levels ready before data hits.

The first move is often wrong, but the second move sticks. Patience pays.

4. Position sizing should be lighter into high-impact data.

Preserve capital for the reaction trade, not the prediction trade.

### NOW WRITE THE SECTION (in English):`,

  // ========================================
  // ANALYST ARENA - MEIDA PNIM STYLE
  // ========================================
  analystArena: `
${MASTER_GUIDE}

## YOUR TASK: Write "Analyst Arena"

Cover the most IMPACTFUL Wall Street rating changes from the past 24 hours.
Focus on calls that move stocks - mega-caps, high-conviction changes, contrarian views.

### IMPORTANT FRAMING (add at the start):
Begin with context that this section tracks significant analyst actions, not recommendations.

### REQUIRED FORMAT FOR EACH ACTION:

TICKER - Company Name
Firm Action, PT set at $XXX (from $YYY if applicable)

[3-4 sentences including]:
- The analyst's KEY REASONING (name the analyst if known)
- Current price context and upside/downside to target
- What this signals for positioning (accumulation/distribution signal)
- Why this call is notable (track record, contrarian view, first mover)

CRITICAL: Put a BLANK LINE between each analyst action
CRITICAL: Name the analyst when possible
CRITICAL: Explain WHY the rating changed, not just WHAT changed

### DATA PROVIDED:
{analystData}

### EXAMPLE OUTPUT (Meida Pnim Style):

We want to note for newer readers: Analyst Arena is not a recommendation service but rather a snapshot describing the significant updates that analysts from various firms are publishing regarding specific stocks.

ZS - Zscaler
Bernstein downgraded to Market Perform from Outperform, PT set at $264

Analyst Peter Wade notes the company is trading at a fair multiple given the 12-month growth outlook. The assessment is that despite being considered one of the leaders in cybersecurity, there is some uncertainty regarding continued growth, mainly due to increasing competitive pressures. The $264 target represents 8% downside from current levels - a cautious stance from a previously bullish voice.

AVGO - Broadcom
Bank of America reiterated Buy, PT raised to $460 from $400

Analyst Vivek Arya highlights the successful launch of Gemini 3 and the potential to lease TPUs to external customers like Google as growth drivers. The firm expects TPU sales growth in the coming years, which will contribute significant revenue growth for Broadcom. This $60 PT increase signals growing conviction in the AI networking opportunity. Current price implies 12% upside.

AAPL - Apple
JPMorgan reiterated Overweight, PT set at $305

Analyst Samik Chatterjee reports that iPhone 17 wait times rose by one day compared to the prior year, indicating higher demand. The rise in wait times stems primarily from increased demand following Black Friday. This is a key data point supporting the premium valuation thesis. The $305 target implies 15% upside from current levels.

NVDA - NVIDIA
Seaport Global Securities initiated with Sell, PT set at $140

A contrarian call worth noting. The firm warns of growing competitive pressures as hyperscalers develop custom silicon. While NVIDIA has secured $26 billion in cloud service commitments, the additional obligations may impact profitability. This is the first major sell-side Sell rating in months - watch for institutional positioning response.

### NOW WRITE THE SECTION (in English):`,

  // ========================================
  // REPORTS - MEIDA PNIM STYLE (v16.0 CRITICAL FIX)
  // ========================================
  reports: `
${MASTER_GUIDE}

## YOUR TASK: Write "Reports"

This covers earnings reports - CRITICAL SECTION for traders.
Structure exactly like מדווחות in Meida Pnim.

### REQUIRED STRUCTURE - CRITICAL FORMATTING:

REPORTED YESTERDAY AFTER MARKET CLOSE

[BLANK LINE REQUIRED HERE]

For each company that reported OR if none reported, write a standalone message:
"No earnings reports were released after market close yesterday."

[BLANK LINE]

REPORTING TODAY BEFORE MARKET OPEN

[BLANK LINE REQUIRED HERE]

For each company OR if none reporting:
"No major earnings reports scheduled before market open today."

[BLANK LINE]

UPCOMING THIS WEEK

[BLANK LINE REQUIRED HERE]

For each upcoming report:
TICKER - Company Name, Reports [Date] [BMO/AMC]
Street expects EPS $X.XX, Revenue $X.XB
[What to watch, why it matters for the sector]

### CRITICAL FORMATTING RULES:
- ALWAYS put BLANK LINE after headers like "REPORTED YESTERDAY AFTER MARKET CLOSE"
- NEVER put header and content on same line
- Each company entry gets its own paragraph with BLANK LINE before next entry
- "No earnings" messages should be standalone paragraphs, not inline with headers

### CRITICAL CONTENT REQUIREMENTS:
- Include YoY growth percentages
- Include management quotes when available
- Include specific guidance figures
- Explain what metrics matter and why
- Connect to broader sector/market themes

### DATA PROVIDED:
{earningsData}
{newsData}

### EXAMPLE OUTPUT (Meida Pnim Style):

REPORTED YESTERDAY AFTER MARKET CLOSE

PATH - UiPath

UiPath reported Q3 2026 results with revenue of $411.11 million, above expectations of $391.98 million, representing 16% YoY growth. EPS came in at $0.16 vs $0.15 expected. The company's ARR reached $1.782 billion, up 11% YoY. Non-GAAP gross margin held at 85%. Q4 guidance calls for revenue of $462-467 million and ARR of $1.844-1.849 billion.

_"I am pleased with our Q3 results, which deliver ARR of $1.782 billion, up 11% YoY, reflecting the focus and consistent execution of the team."_ - Daniel Dines, Founder and CEO

The stock is up 8.8% in pre-market trading on the results.

REPORTING TODAY BEFORE MARKET OPEN

JPM - JPMorgan Chase

JPMorgan Chase is set to report Q4 2026 earnings today with expectations of revenue at $39.5 billion and EPS at $4.02. The focus will be on net interest income and trading revenue.

UPCOMING THIS WEEK

BAC - Bank of America, Reports January 16 BMO
Street expects EPS $0.77, Revenue $25.2B
Watch for commentary on net interest income and consumer lending growth.

MS - Morgan Stanley, Reports January 16 BMO
Street expects EPS $1.88, Revenue $14.5B
Focus on wealth management growth and trading revenue.

### NOW WRITE THE SECTION (in English):`,

  // ========================================
  // TACTICAL CORNER - MEIDA PNIM STYLE
  // ========================================
  tacticalCorner: `
${MASTER_GUIDE}

## YOUR TASK: Write "The Tactical Corner"

This is your DEEP-DIVE thematic analysis - like הפינה הטקטית in Meida Pnim.
Pick ONE major theme and break it down with CITED SOURCES.
MUST include Fund Flows and Buybacks subsections.

### REQUIRED STRUCTURE:

Start with a thematic subtitle:
"The Tactical Corner - [Theme]"
Examples: "The Consumer", "Flow of Funds", "The AI Trade", "Market Structure", "Macro Setup"

Opening context paragraph (3-4 sentences):
Set the scene with specific data and cited sources.
Example: "Bank of America data shows...", "Mastercard and Chase data indicate..."

Then 4 numbered tactical points. CRITICAL STRUCTURE FOR EACH POINT:
- Line 1: Number and short title ONLY (example: "1. The consumer is strong.")
- Line 2: BLANK LINE
- Line 3-5: Explanation paragraph (2-3 sentences with data and sources)
- Line 6: BLANK LINE
- Then next numbered point

Example of CORRECT structure:

1. The American consumer is still alive.

Mastercard, Adobe and Chase data point to acceleration in November consumption, especially in Apparel and electronics. This supports continued strength in seasonally sensitive sectors.

2. Rotations will continue to play a role.

Stocks crushed during the fall provided sharp rebounds. Watch names with high short interest for squeeze potential.

REQUIRED: Fund Flows Subsection
Fund Flows - Where Is the Big Money Going?

[2-3 sentences with specific data]:
- % allocation to equities vs bonds vs cash
- Regional flows (US, Europe, EM, China)
- Institutional vs retail positioning

REQUIRED: Buybacks Subsection
Buybacks - Corporate Support Window

[2-3 sentences]:
- Is the buyback window open or closed?
- Current pace vs historical average (e.g., "1.6x-1.8x annual average")
- Key dates (e.g., "window closes December 19")

End with "What Does This Mean Tactically?" section (same structure - number + title, blank line, explanation):

1. Takeaway. Supporting explanation.

2. Takeaway. Supporting explanation.

3. Takeaway. Supporting explanation.

4. Takeaway. Supporting explanation.

### DATA PROVIDED:
{marketData}
{newsData}
{optionsFlow}
{analystData}

### EXAMPLE OUTPUT (Meida Pnim Style):

The Tactical Corner - The Consumer

A clear pattern in recent days: institutional and retail investors are pulling the market higher together. On the retail side, the $8.6 billion surge in retail purchases in one week shows the holiday effect was much stronger than the annual average. On the positioning side, momentum players and short sellers were forced to cover, fueling gains especially in small caps and heavily shorted names. Bank of America data shows the gap between high-income and low-income consumer spending continues to widen.

1. The American consumer is still alive - and in events, strong.

Mastercard, Adobe and Chase data point to acceleration in November consumption, especially in segments like Apparel, Footwear, Beauty and electronics. Online shows particularly strong growth, illustrating the structural shift of recent years and the intensification of AI in buyer movement. This supports continued strength in seasonally sensitive sectors.

2. Rotations will continue to play a role.

Stocks that were crushed during the fall provided a sharp rebound, and those with positionally light exposure can continue to rise. The mean reversion trade is working in this sentiment environment. Watch names with high short interest for squeeze potential.

3. The Fed is giving the market air.

The probability of a December cut is high, and data supporting inflationary moderation allows the market to continue year-end momentum. As long as volatility remains low, these demands support the market's upward bias.

4. Institutional investors are not overloaded.

This is a key point: there is no overcrowding right now, and this leaves a clear opening for continued gains if momentum doesn't break. JPMorgan positioning data shows funds are neutral to slightly long, far from stretched.

Fund Flows - Where Is the Big Money Going?

Despite noise about European redemptions, global flows show a clear picture: equities remain king. Approximately 75% of assets are flowing into equities, with positive flows also evident in emerging markets and China. The foundation of the market remains deep and positive.

Buybacks - Corporate Support Window

The buyback window is open until December 19, running at a pace of 1.6x-1.8x the annual average. This is a strong tailwind for the market during this period, but it disappears once we enter the second half of December - and then the market becomes more vulnerable.

What Does This Mean Tactically?

1. Consumer discretionary remains the play.

Focus on Retail, Specialty, Footwear, Apparel, Beauty names that benefit from holiday strength.

2. Rotations favor the beaten-down names.

Those crushed in November provided sharp rebounds, and positionally light names can continue higher.

3. Rate cut expectations provide air cover.

High probability of December cut and supportive inflation data allow year-end momentum to continue.

4. No overcrowding means room to run.

Institutional positioning is not stretched, leaving clear path for continued gains if momentum holds.

### NOW WRITE THE SECTION (in English):`,

  // ========================================
  // FOCUS CORNER - MEIDA PNIM STYLE
  // ========================================
  focusCorner: `
${MASTER_GUIDE}

## YOUR TASK: Write "Focus Corner"

Highlight 2-3 SPECIFIC stock opportunities with actionable trade setups.
Include current price movement and cross-references to other sections.

### CRITICAL: CURRENT PRICE MOVEMENT
- Include % movement: "Stock is up 10.61% in early trading"
- Reference the catalyst: "following the earnings beat covered in Reports"

### REQUIRED FORMAT FOR EACH STOCK:

TICKER - Company Name - Catalyst Headline

[Opening narrative 3-4 sentences]:
- Current price movement (% up/down today)
- The specific catalyst
- Reference to Analyst Arena or Tactical Corner when relevant
- Why this setup matters NOW

[If analyst action]: Large call option purchase with premium of $X.XX million shows...
[If options flow]: Include specific strike, expiry, premium details

Setup:
Entry, $XXX (current levels)
Target, $XXX (+X% upside)
Stop, $XXX (-X% risk)
Timeframe, X weeks
Conviction, High/Medium

CRITICAL: Put a BLANK LINE between each stock setup
CRITICAL: Include current % movement
CRITICAL: Cross-reference other sections when relevant

### DATA PROVIDED:
{marketData}
{analystData}
{newsData}
{optionsFlow}

### EXAMPLE OUTPUT (Meida Pnim Style):

MRVL - Marvell Technology - Acquisition Powers AI Networking Story

Marvell stock is up 10.61% in early trading following the company's announcement of the Celestial AI acquisition for $3.25 billion in cash and stock. The deal aims to enhance data center infrastructure with advanced Photonic Fabric optical connectivity technology. As covered in Reports, the company's Q3 results showed record revenue of $2.075 billion, reinforcing the positive momentum. The combination of strong earnings and strategic M&A creates a compelling setup.

Setup:
Entry, $95 (current levels)
Target, $115 (+21% upside)
Stop, $88 (-7% risk)
Timeframe, 6-8 weeks
Conviction, High

AEO - American Eagle Outfitters - JPMorgan Upgrade on Strong Holiday

American Eagle stock is up 12.72% in early trading following the JPMorgan upgrade to Neutral. Analysts highlighted strong Q3 results with adjusted net profit exceeding expectations. As noted in Tactical Corner, the consumer remains healthy at the high end, and holiday sales data supports the bullish thesis. Growth forecasts for the next quarter are positive with increases in sales and operating results.

Setup:
Entry, $22 (current levels)
Target, $26 (+18% upside)
Stop, $20 (-9% risk)
Timeframe, 4-6 weeks
Conviction, Medium

NVDA - NVIDIA Corporation - CES Catalyst with Top Pick Designation

NVIDIA is setting up for a potential breakout ahead of CES 2026 where Jensen Huang will unveil next-gen Blackwell GPUs. As highlighted in Analyst Arena, Cantor Fitzgerald named NVDA as Top Pick for 2026 with a $300 target. Large call option activity shows $1.85 million in premium at the $200 strike, signaling institutional conviction. The AI infrastructure story remains the dominant theme.

Setup:
Entry, $189 (current consolidation zone)
Target, $250 (+32% upside)
Stop, $170 (-10% risk)
Timeframe, 4-8 weeks
Conviction, High

### NOW WRITE THE SECTION (in English):`,

  // ========================================
  // WEEK AHEAD - v16.0 CRITICAL FORMATTING
  // ========================================
  weekAhead: `
${MASTER_GUIDE}

## YOUR TASK: Write "Events This Week"

Create a DAY-BY-DAY calendar of important events.

### STRUCTURE - CRITICAL FORMATTING:

Events This Week

[BLANK LINE]

Day, Date

[BLANK LINE]

- Economic data at XX:XX - Event Name, Previous X | Expected Y

[BLANK LINE BETWEEN EACH DAY]

Next Day, Date

[BLANK LINE]

- Event items...

CRITICAL: Put a BLANK LINE after "Events This Week" header
CRITICAL: Put a BLANK LINE after each day header
CRITICAL: Put a BLANK LINE between each day's section
CRITICAL: Use pipe separator | for Previous/Expected
CRITICAL: End with "Key Themes to Watch" section

### DATA PROVIDED:
{economicCalendar}
{earningsData}
{newsData}

### EXAMPLE OUTPUT:

Events This Week

Thursday, January 6

- Economic data at 10:00 - Factory Orders MoM, Previous -0.5% | Expected 0.1%

Friday, January 7

- Economic data at 08:30 - Trade Balance, Previous -$73.8B | Expected -$75.0B
- Economic data at 10:00 - JOLTS Job Openings, Previous 7.74M | Expected 7.70M

Monday, January 8

- Economic data at 14:00 - FOMC Minutes

Wednesday, January 10

- Economic data at 08:30 - Nonfarm Payrolls, Previous 227K | Expected 175K
- Economic data at 08:30 - Unemployment Rate, Previous 4.2% | Expected 4.2%

Wednesday, January 15

- Economic data at 08:30 - CPI MoM, Previous 0.3% | Expected 0.2%
- Earnings from JPMorgan Chase (JPM), BMO, EPS Est $4.02, Rev Est $39.5B
- Earnings from Wells Fargo (WFC), BMO, EPS Est $1.32, Rev Est $20.1B

Key Themes to Watch

1. Factory Orders on January 6 will set the stage for demand expectations. A positive surprise could indicate stronger economic activity.

2. JOLTS Job Openings on January 7 are crucial for labor market insights. If openings drop significantly below 7.5M, it may signal a cooling job market.

3. Nonfarm Payrolls on January 10 are the main event. A miss below 150K could shift market sentiment dramatically toward rate cuts. The goldilocks zone is 160-190K.

4. Bank earnings on January 15 will be pivotal for the financial sector. Pay close attention to commentary on net interest income.

### NOW WRITE THE SECTION (in English):`,
};

// ============================================================================
// QA PROMPT - Enhanced v5.0 with Aggressive AI Detection
// ============================================================================
export const QA_PROMPT = `
You are the EDITOR-IN-CHIEF reviewing a financial intelligence report before publication.
This report should read like מידע פנים (Meida Pnim) - Israeli institutional trading desk intelligence.

Your job is to:

1. SEARCH AND DESTROY - Remove ALL AI-sounding phrases:
   - "Based on analysis" / "Based on the data" - DELETE
   - "It's worth noting" / "It should be noted" - DELETE
   - "Additionally," / "Furthermore," / "Moreover," - DELETE
   - "Moving forward" / "Going forward" - DELETE
   - "appears to be" / "seems to" - MAKE DIRECT
   - "could potentially" / "may possibly" - COMMIT TO A VIEW
   - "It is important to" / "It is crucial to" - DELETE
   - "In terms of" - REWRITE DIRECTLY
   - "As mentioned" / "As noted" - DELETE
   - "This indicates that" - JUST SAY IT
   - "Investors should note" / "Traders should be aware" - DELETE
   - "The key takeaway is" - JUST STATE IT
   - "In summary" / "To summarize" / "In conclusion" - DELETE
   - "Let's take a look at" / "Let's examine" - DELETE
   - "This suggests that" - BE DIRECT

2. CHECK FORMATTING - CRITICAL:
   - Blank line AFTER "REPORTED YESTERDAY AFTER MARKET CLOSE" header
   - Blank line AFTER "UPCOMING THIS WEEK" header
   - Blank line AFTER "Events This Week" header
   - Blank lines BETWEEN each day in calendar
   - "No earnings reports" should be standalone paragraph, not inline with header
   - Each company entry separated by blank line

3. ENSURE Meida Pnim style elements:
   - Numbered points in "What Does This Mean Tactically?" sections
   - Tactical Corner has a thematic subtitle
   - Reports section has management quotes in italics
   - Sources are cited (Bank of America, Mastercard, analyst names)

4. VERIFY content quality:
   - Focus Corner has SPECIFIC stocks (not just SPY/QQQ)
   - Cross-references between sections exist
   - Specific numbers and percentages throughout
   - Price levels and targets included

5. ENSURE human signature phrases appear:
   - "This is a key point"
   - "The question here is whether..."
   - "On one hand... on the other hand..."
   - "The goldilocks zone is..."

DO NOT:
- Add new content
- Remove existing sections
- Change specific numbers/data
- Add disclaimers or caveats
- Use asterisks ** for bold anywhere

The edited report should read like it was written by a senior analyst at an Israeli institutional desk, not an AI.

REPORT TO EDIT:
{report}

Return ONLY the edited report text. No commentary.
`;

// ============================================================================
// RUN AGENT
// ============================================================================
export async function runAgent(sectionKey, context, openaiApiKey) {
  const config = SECTION_CONFIG[sectionKey];
  const prompt = SECTION_PROMPTS[sectionKey];
  
  if (!prompt) {
    console.log(`   ⚠ No prompt for ${sectionKey}`);
    return generateFallback(sectionKey, context);
  }
  
  console.log(`   → Generating ${config?.title || sectionKey}...`);
  
  // Build data context
  const dataContext = buildDataContext(sectionKey, context);
  
  // Fill template
  const filledPrompt = fillPromptTemplate(prompt, dataContext);
  
  // Call OpenAI
  const response = await callOpenAI(filledPrompt, openaiApiKey);
  
  if (response) {
    // Apply punctuation cleanup AND line break fixes (v16.0)
    let cleaned = ensureProperLineBreaks(cleanPunctuation(response));
    
    // v16.5: Inject tables for specific sections (tables don't come from GPT)
    cleaned = injectSectionTables(sectionKey, cleaned, context);
    
    console.log(`   ✓ ${config?.title || sectionKey} complete (${cleaned.length} chars)`);
    return cleaned;
  }
  
  console.log(`   ⚠ ${config?.title || sectionKey} using fallback`);
  return generateFallback(sectionKey, context);
}

// ============================================================================
// v16.5: INJECT TABLES INTO GPT RESPONSE
// Tables are data-driven and don't come from GPT - inject them here
// ============================================================================
function injectSectionTables(sectionKey, content, context) {
  const { analystData, economicCalendar, newsData, lockedPrices } = context;
  
  // Helper to get company name
  const tickerToCompanyName = (ticker) => {
    const map = {
      'ULTA': 'Ulta Beauty', 'AVGO': 'Broadcom Inc.', 'CRM': 'Salesforce',
      'SNOW': 'Snowflake', 'AAPL': 'Apple Inc.', 'NVDA': 'NVIDIA Corporation',
      'JPM': 'JPMorgan Chase', 'WFC': 'Wells Fargo', 'GS': 'Goldman Sachs',
      'BAC': 'Bank of America', 'MS': 'Morgan Stanley', 'TSM': 'Taiwan Semiconductor',
      'UNH': 'UnitedHealth', 'MSFT': 'Microsoft', 'GOOGL': 'Alphabet', 'AMZN': 'Amazon',
      'META': 'Meta Platforms', 'TSLA': 'Tesla', 'AMD': 'AMD', 'INTC': 'Intel',
    };
    return map[ticker] || ticker;
  };
  
  // ========================================
  // v17.0: GLOBAL ARENA - Add market data tables
  // ========================================
  if (sectionKey === 'globalArena') {
    const spy = lockedPrices?.indices?.SPY;
    const qqq = lockedPrices?.indices?.QQQ;
    const iwm = lockedPrices?.indices?.IWM;
    const vix = lockedPrices?.vix;
    const sectors = lockedPrices?.sectors || {};
    
    // Format helpers
    const fmtPrice = (p) => p ? `$${p.toFixed(2)}` : 'N/A';
    const fmtPct = (p) => p !== undefined && p !== null ? `${p >= 0 ? '+' : ''}${p.toFixed(2)}%` : 'N/A';
    
    // Determine market direction
    const spyUp = spy?.changePercent >= 0;
    const qqqUp = qqq?.changePercent >= 0;
    const iwmUp = iwm?.changePercent >= 0;
    
    // Get sector leaders/laggards
    const sectorList = Object.entries(sectors).map(([symbol, data]) => ({
      symbol,
      change: data?.changePercent || 0
    })).sort((a, b) => b.change - a.change);
    const topSector = sectorList[0];
    const bottomSector = sectorList[sectorList.length - 1];
    
    // Build index table rows
    const spyNote = spyUp ? 'Bullish momentum continues' : 'First red day in 5 sessions';
    const qqqNote = qqqUp ? 'Tech leading' : 'Largest drop in 2 weeks';
    const iwmNote = iwmUp ? 'Small caps outperform' : 'Risk-off in small caps';
    
    const indexRows = `| SPY | ${fmtPrice(spy?.price)} | ${fmtPct(spy?.changePercent)} | ${spyNote} |
| QQQ | ${fmtPrice(qqq?.price)} | ${fmtPct(qqq?.changePercent)} | ${qqqNote} |
| IWM | ${fmtPrice(iwm?.price)} | ${fmtPct(iwm?.changePercent)} | ${iwmNote} |`;

    // Build indicator table rows
    const vixLevel = vix?.price || 15.94;
    const vixSignal = vixLevel < 14 ? 'Low fear' : vixLevel < 18 ? 'Normal' : 'Elevated';
    const tenYear = lockedPrices?.yields?.tenYear || '4.58';
    const yieldSignal = parseFloat(tenYear) > 4.5 ? 'Rising' : 'Contained';
    const dxy = lockedPrices?.dxy?.current || 108.5;
    const dxySignal = dxy > 105 ? 'Strong dollar' : 'Dollar weakness';
    
    const indicatorRows = `| VIX | ${vixLevel.toFixed(1)} | ${vixSignal} |
| 10Y Yield | ${tenYear}% | ${yieldSignal} |
| DXY | ${dxy.toFixed(1)} | ${dxySignal} |`;

    // Build sector table rows
    const topSectorStr = topSector ? `${topSector.symbol} ${fmtPct(topSector.change)}` : 'XLF +0.8%';
    const bottomSectorStr = bottomSector ? `${bottomSector.symbol} ${fmtPct(bottomSector.change)}` : 'XLK -0.5%';
    
    const sectorRows = `| Top | ${topSectorStr} | Financials leading |
| Bottom | ${bottomSectorStr} | Tech lagging |`;

    // Complete table block
    const tables = `| Index | Close | Change | Note |
|-------|-------|--------|------|
${indexRows}

| Indicator | Value | Signal |
|-----------|-------|--------|
${indicatorRows}

| Sector | Performance | Leader/Laggard |
|--------|-------------|----------------|
${sectorRows}

`;

    // Inject tables at the beginning of the content
    return tables + content;
  }
  
  // ANALYST ARENA - Add analyst actions table
  if (sectionKey === 'analystArena') {
    const actions = analystData?.actions || [];
    let tableRows = actions.slice(0, 5).map(a => 
      `| ${a.ticker} | ${a.toRating || a.action || '-'} | ${a.priceTarget ? '$' + a.priceTarget : '-'} | ${a.firm} |`
    ).join('\n');
    
    // Fallback if no live data
    if (!tableRows) {
      tableRows = `| ULTA | Overweight | $647 | JP Morgan |
| AVGO | Outperform | $435 | Oppenheimer |
| CRM | Outperform | $375 | Wedbush |
| SNOW | Overweight | $299 | Morgan Stanley |
| AAPL | Market Perform | - | Raymond James |`;
    }
    
    const table = `| Ticker | Rating | Price Target | Firm |
|--------|--------|--------------|------|
${tableRows}

`;
    
    // Inject after the intro paragraph
    const introEnd = content.indexOf('\n\n');
    if (introEnd > 0) {
      return content.slice(0, introEnd + 2) + table + content.slice(introEnd + 2);
    }
    return table + content;
  }
  
  // MACRO ARENA - Add economic calendar table
  if (sectionKey === 'macroArena') {
    const events = economicCalendar?.thisWeek || economicCalendar?.highImportance || [];
    let tableRows = events.slice(0, 6).map(e => {
      const impact = e.importance === 'high' ? 'HIGH' : e.importance === 'medium' ? 'MED' : 'LOW';
      return `| ${e.event} | ${e.date} | ${e.time || '-'} | ${e.previous || '-'} | ${e.forecast || e.expected || '-'} | ${impact} |`;
    }).join('\n');
    
    // Fallback if no live data
    if (!tableRows) {
      tableRows = `| JOLTS Job Openings | Jan 7 | 10:00 | 7.74M | 7.70M | HIGH |
| Nonfarm Payrolls | Jan 10 | 08:30 | 227K | 175K | HIGH |
| Unemployment Rate | Jan 10 | 08:30 | 4.2% | 4.2% | HIGH |
| CPI MoM | Jan 15 | 08:30 | 0.3% | 0.2% | HIGH |
| Core CPI MoM | Jan 15 | 08:30 | 0.3% | 0.2% | HIGH |
| Retail Sales MoM | Jan 16 | 08:30 | 0.7% | 0.5% | MED |`;
    }
    
    const table = `ECONOMIC CALENDAR

| Event | Date | Time | Previous | Expected | Impact |
|-------|------|------|----------|----------|--------|
${tableRows}

`;
    
    // Add table at the beginning
    return table + content;
  }
  
  // REPORTS - Add earnings calendar table
  if (sectionKey === 'reports') {
    const earnings = newsData?.earnings || [];
    const upcoming = earnings.filter(e => {
      const earnDate = new Date(e.date);
      const today = new Date();
      return (earnDate - today) / (1000 * 60 * 60 * 24) > 0 && (earnDate - today) / (1000 * 60 * 60 * 24) <= 14;
    });
    
    let tableRows = upcoming.slice(0, 6).map(e => 
      `| ${e.ticker} | ${e.company || tickerToCompanyName(e.ticker)} | ${e.date?.split('-').slice(1).join('/') || '-'} | ${e.time || 'TBA'} | $${e.epsEst || 'TBA'} | $${e.revEst || 'TBA'}B |`
    ).join('\n');
    
    // Fallback if no live data
    if (!tableRows) {
      tableRows = `| JPM | JPMorgan Chase | 01/15 | BMO | $4.02 | $39.5B |
| WFC | Wells Fargo | 01/15 | BMO | $1.32 | $20.1B |
| GS | Goldman Sachs | 01/15 | BMO | $8.15 | $11.8B |
| BAC | Bank of America | 01/16 | BMO | $0.77 | $25.2B |
| MS | Morgan Stanley | 01/16 | BMO | $1.88 | $14.5B |
| TSM | Taiwan Semi | 01/16 | BMO | $2.18 | $26.3B |`;
    }
    
    const table = `UPCOMING EARNINGS CALENDAR

| Ticker | Company | Date | Time | EPS Est | Rev Est |
|--------|---------|------|------|---------|---------|
${tableRows}

`;
    
    // Find "UPCOMING" section and inject before it, or add at end before that section
    const upcomingIdx = content.indexOf('UPCOMING THIS WEEK');
    if (upcomingIdx > 0) {
      return content.slice(0, upcomingIdx) + table + content.slice(upcomingIdx);
    }
    
    // Otherwise inject after "REPORTING TODAY" section
    const reportingTodayEnd = content.indexOf('\n\n', content.indexOf('REPORTING TODAY'));
    if (reportingTodayEnd > 0) {
      // Find end of that section (next double newline after some content)
      let sectionEnd = content.indexOf('\n\n', reportingTodayEnd + 10);
      while (sectionEnd > 0 && sectionEnd < content.length - 10) {
        const nextContent = content.slice(sectionEnd, sectionEnd + 20);
        if (nextContent.includes('UPCOMING') || nextContent.match(/^[A-Z]{2,5}\s*-/)) {
          break;
        }
        sectionEnd = content.indexOf('\n\n', sectionEnd + 2);
      }
      if (sectionEnd > 0) {
        return content.slice(0, sectionEnd + 2) + table + content.slice(sectionEnd + 2);
      }
    }
    
    return content + '\n\n' + table;
  }
  
  // No table injection needed for other sections
  return content;
}

// ============================================================================
// CLEAN PUNCTUATION - Apply Meida Pnim style rules
// ============================================================================
function cleanPunctuation(text) {
  if (!text) return text;
  
  let cleaned = text;
  
  // Replace colons in narrative sentences with dash or comma
  // But preserve colons in data formats like "Previous: X" or "Entry: $X"
  cleaned = cleaned.replace(/([a-zA-Z]{4,})\s*:\s*([A-Z])/g, '$1 - $2');
  cleaned = cleaned.replace(/([a-zA-Z]{4,})\s*:\s*([a-z])/g, '$1, $2');
  
  // Replace semicolons with comma or period
  cleaned = cleaned.replace(/;\s*/g, ', ');
  
  // Fix double spaces
  cleaned = cleaned.replace(/\s{2,}/g, ' ');
  
  // Fix "Previous: X | Expected: Y" to "Previous X | Expected Y"
  cleaned = cleaned.replace(/Previous:\s*/g, 'Previous ');
  cleaned = cleaned.replace(/Expected:\s*/g, 'Expected ');
  
  return cleaned;
}

// ============================================================================
// ENSURE PROPER LINE BREAKS - v16.1 Critical Fix for PDF Formatting
// ADDED: Proper spacing BEFORE and AFTER numbered items for hierarchy
// ============================================================================
function ensureProperLineBreaks(content) {
  if (!content) return content;
  
  let fixed = content;
  
  // Remove asterisks FIRST before any other processing
  fixed = fixed.replace(/\*\*/g, '');
  fixed = fixed.replace(/\*/g, '');
  
  // ==== CRITICAL FIX v16.1: NUMBERED ITEMS HIERARCHY ====
  // Ensure BLANK LINE BEFORE numbered items 2, 3, 4, etc. (not 1)
  // This ensures proper visual hierarchy in PDF
  // Pattern: If there's text followed by a numbered item without double newline, add it
  fixed = fixed.replace(/([^\n])\n([2-9]\.\s+)/g, '$1\n\n$2');
  fixed = fixed.replace(/([^\n])\n(1[0-9]\.\s+)/g, '$1\n\n$2');
  
  // Ensure BLANK LINE AFTER each numbered item (before next content)
  // This separates the numbered item from continuation paragraphs
  fixed = fixed.replace(/(\d+\.\s+[^\n]+)\n([^0-9\n])/g, '$1\n\n$2');
  
  // ==== HEADERS SPACING ====
  // Ensure blank line after "REPORTED YESTERDAY AFTER MARKET CLOSE"
  fixed = fixed.replace(/(REPORTED YESTERDAY AFTER MARKET CLOSE)([^\n])/gi, '$1\n\n$2');
  fixed = fixed.replace(/(REPORTED YESTERDAY AFTER MARKET CLOSE)\n([^\n])/gi, '$1\n\n$2');
  
  // Ensure blank line after "REPORTING TODAY BEFORE MARKET OPEN"
  fixed = fixed.replace(/(REPORTING TODAY BEFORE MARKET OPEN)([^\n])/gi, '$1\n\n$2');
  fixed = fixed.replace(/(REPORTING TODAY BEFORE MARKET OPEN)\n([^\n])/gi, '$1\n\n$2');
  
  // Ensure blank line after "UPCOMING THIS WEEK"
  fixed = fixed.replace(/(UPCOMING THIS WEEK)([^\n])/gi, '$1\n\n$2');
  fixed = fixed.replace(/(UPCOMING THIS WEEK)\n([^\n])/gi, '$1\n\n$2');
  
  // Ensure blank line after "Events This Week"
  fixed = fixed.replace(/(Events This Week)([^\n])/gi, '$1\n\n$2');
  fixed = fixed.replace(/(Events This Week)\n([^\n])/gi, '$1\n\n$2');
  
  // Ensure blank line after "Key Themes to Watch"
  fixed = fixed.replace(/(Key Themes to Watch)([^\n])/gi, '$1\n\n$2');
  fixed = fixed.replace(/(Key Themes to Watch)\n([^\n])/gi, '$1\n\n$2');
  
  // Ensure blank line after "What Does This Mean Tactically"
  fixed = fixed.replace(/(What Does This Mean Tactically\??)([^\n])/gi, '$1\n\n$2');
  fixed = fixed.replace(/(What Does This Mean Tactically\??)\n([^\n])/gi, '$1\n\n$2');
  
  // Ensure blank line after "Fund Flows"
  fixed = fixed.replace(/(Fund Flows[^\n]{0,50})([^\n\-])/gi, (match, p1, p2) => {
    if (p1.includes('\n\n')) return match;
    return p1 + '\n\n' + p2;
  });
  
  // Ensure blank line after "Buybacks"
  fixed = fixed.replace(/(Buybacks[^\n]{0,50})([^\n\-])/gi, (match, p1, p2) => {
    if (p1.includes('\n\n')) return match;
    return p1 + '\n\n' + p2;
  });
  
  // Ensure "No earnings" messages are standalone paragraphs
  fixed = fixed.replace(/(REPORTED YESTERDAY[^\n]*)\n*(No earnings[^\n]*)/gi, '$1\n\n$2');
  fixed = fixed.replace(/(REPORTING TODAY[^\n]*)\n*(No [^\n]*earnings[^\n]*)/gi, '$1\n\n$2');
  
  // ==== WEEK AHEAD FORMATTING ====
  // Ensure blank line before day names (Monday, Tuesday, etc.)
  fixed = fixed.replace(/([^\n])\n(Monday|Tuesday|Wednesday|Thursday|Friday),?\s+/gi, '$1\n\n$2 ');
  
  // Ensure blank line before date patterns like "January 6" or "Jan 6"
  fixed = fixed.replace(/([^\n])\n((January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2})/gi, '$1\n\n$2');
  
  // ==== CLEANUP ====
  // Clean up excessive line breaks (more than 3 in a row)
  fixed = fixed.replace(/\n{4,}/g, '\n\n\n');
  
  // Clean up any remaining asterisks
  fixed = fixed.replace(/\*\*/g, '');
  fixed = fixed.replace(/\*/g, '');
  
  return fixed;
}

// ============================================================================
// RUN QA EDITOR
// ============================================================================
export async function runQAEditor(report, openaiApiKey) {
  console.log('   ✅ Running QA Editor...');
  
  const prompt = QA_PROMPT.replace('{report}', report);
  
  // Use dedicated QA call with higher token limit
  const response = await callOpenAIForQA(prompt, openaiApiKey);
  
  if (response) {
    // Apply both cleanPunctuation and ensureProperLineBreaks
    let cleaned = ensureProperLineBreaks(cleanPunctuation(response));
    // v16.5: Fix table formatting (ensure tables have proper newlines)
    cleaned = fixTableNewlines(cleaned);
    console.log(`   ✓ QA Editor returned ${cleaned.length} chars`);
    return cleaned;
  }
  
  // If QA fails, return original with cleanup
  console.log('   ⚠️ QA Editor returned empty, using original report');
  let fallback = ensureProperLineBreaks(cleanPunctuation(report));
  fallback = fixTableNewlines(fallback);
  return fallback;
}

// v16.5: Fix table formatting - ensure tables have proper newlines
function fixTableNewlines(text) {
  if (!text) return text;
  
  let fixed = text;
  
  // Add newline BEFORE table rows that are concatenated with text
  // Pattern: text character followed by space and table row (| col1 | col2 |...)
  fixed = fixed.replace(/([a-zA-Z0-9)])(\s+)(\|[^\n]+\|)/g, '$1\n\n$3');
  
  // Ensure table headers have proper spacing
  fixed = fixed.replace(/(ECONOMIC CALENDAR|UPCOMING EARNINGS CALENDAR|ANALYST ACTIONS)(\s*)(\|)/g, '$1\n\n$3');
  
  // Add newline AFTER table blocks (table row followed by regular text)
  fixed = fixed.replace(/(\|)\s+([A-Z][a-z])/g, '$1\n\n$2');
  
  // Clean up excessive newlines
  fixed = fixed.replace(/\n{4,}/g, '\n\n\n');
  
  return fixed;
}

// Dedicated OpenAI call for QA Editor with higher token limit
async function callOpenAIForQA(prompt, apiKey) {
  if (!apiKey) {
    console.warn('[QA] No OpenAI API key provided');
    return null;
  }
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are the EDITOR-IN-CHIEF reviewing a financial intelligence report.

CRITICAL RULES - DO NOT VIOLATE:
1. PRESERVE ALL ## SECTION HEADERS EXACTLY - do not remove or modify them
2. PRESERVE ALL --- SEPARATORS BETWEEN SECTIONS
3. Each section header must be on its own line: "## Section Title"
4. Each section must be separated by: "---" on its own line
5. NO asterisks or bold markers (**) anywhere in the text
6. Return the COMPLETE report - do not truncate

CLEAN UP:
- Remove AI artifacts: "Based on analysis", "It's worth noting", etc.
- Short paragraphs (max 5 sentences each)
- Blank line between paragraphs
- No asterisks (* or **) in output

OUTPUT FORMAT REQUIRED:
## The Global Arena

[content with short paragraphs]

---

## What's Happening Now

[content]

---

(continue for all sections)`,
          },
          { role: 'user', content: prompt },
        ],
        max_tokens: 8000,
        temperature: 0.3,
      }),
    });
    
    if (!response.ok) {
      console.error('[QA] OpenAI API error:', response.status);
      return null;
    }
    
    const data = await response.json();
    
    if (data.choices?.[0]?.message?.content) {
      const result = data.choices[0].message.content;
      console.log(`   ✓ QA Editor returned ${result.length} chars`);
      return result;
    }
    
    return null;
  } catch (error) {
    console.error('[QA] OpenAI error:', error.message);
    return null;
  }
}

// ============================================================================
// RUN PHASE
// ============================================================================
export async function runPhase(phaseName, agentKeys, context, previousOutputs) {
  console.log(`\n📋 Phase: ${phaseName}`);
  
  const outputs = { ...previousOutputs };
  const openaiApiKey = context.openaiApiKey || process.env.OPENAI_API_KEY;
  
  for (const key of agentKeys) {
    try {
      const output = await runAgent(key, { ...context, previousOutputs: outputs }, openaiApiKey);
      if (output) {
        outputs[key] = output;
      }
    } catch (error) {
      console.error(`   ✗ ${key} failed:`, error.message);
    }
  }
  
  return outputs;
}

// ============================================================================
// CALL OPENAI - Enhanced with Meida Pnim style instructions
// ============================================================================
async function callOpenAI(prompt, apiKey) {
  if (!apiKey) {
    console.warn('[Agent] No OpenAI API key provided');
    return null;
  }
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are a senior financial analyst at an Israeli institutional trading desk writing the morning intelligence report in the style of מידע פנים (Meida Pnim).

MEIDA PNIM STYLE REQUIREMENTS:

1. NUMBERED ITEMS STRUCTURE - CRITICAL FOR HIERARCHY:
   - Number and short title on first line: "1. The consumer is strong."
   - BLANK LINE after the title
   - Explanation paragraph (2-3 sentences)
   - BLANK LINE before next numbered item
   Example:
   1. The American consumer is still alive.
   
   Mastercard and Chase data point to acceleration in November consumption. This supports continued strength in retail.
   
   2. Rotations will continue to play a role.
   
   Stocks crushed in the fall provided sharp rebounds. Watch names with high short interest.

2. CITE SOURCES: Name your data sources.
   - "Bank of America data shows..."
   - "Mastercard and Chase data indicate..."
   - "Analyst Peter Wade notes..."

3. HUMAN SIGNATURE PHRASES (use these):
   - "This is a key point:"
   - "The story here is:"
   - "On one hand... on the other hand..."
   - "As long as X remains Y - Z continues"

4. MANAGEMENT QUOTES: For earnings reports, include CEO/CFO quotes.
   Example: "Quote text here." - Name, Title

5. SCENARIO ANALYSIS: For macro data, explain what happens if above vs below expectations.

6. FORMATTING - NO ASTERISKS:
   - NO asterisks or stars (* or **) anywhere
   - NO bold markers of any kind
   - Write headlines as plain text: TICKER - Company Name - Headline
   - Write section headers as plain text: Fund Flows - Where Is the Big Money Going?

ABSOLUTELY FORBIDDEN:
- Asterisks (* or **) for bold text - NEVER USE
- "Based on analysis" / "Based on the data"
- "It's worth noting" / "It should be noted"
- "Additionally," / "Furthermore," / "Moreover,"
- "Moving forward" / "Going forward"
- "appears to be" / "seems to"
- "could potentially" / "may possibly"

PUNCTUATION RULES:
- Only period (.) comma (,) dash (-) and pipe (|)
- NO colons in narrative sentences
- Data formats: "Previous X | Expected Y" with pipe separator

Write in English. Be direct, specific, and actionable.`,
          },
          { role: 'user', content: prompt },
        ],
        max_tokens: 3000,
        temperature: 0.7,
      }),
    });
    
    if (!response.ok) {
      console.error('[Agent] OpenAI API error:', response.status);
      return null;
    }
    
    const data = await response.json();
    
    if (data.choices?.[0]?.message?.content) {
      return data.choices[0].message.content;
    }
    
    return null;
  } catch (error) {
    console.error('[Agent] OpenAI error:', error.message);
    return null;
  }
}

// ============================================================================
// BUILD DATA CONTEXT
// ============================================================================
function buildDataContext(sectionKey, context) {
  const { lockedPrices, marketData, newsData, analystData, fedContext, economicCalendar, earningsData, optionsFlow } = context;
  
  // Format market data nicely
  const formattedMarket = formatMarketDataForPrompt(lockedPrices || marketData);
  
  return {
    marketData: formattedMarket,
    newsData: JSON.stringify(newsData || { note: 'No news data available' }, null, 2),
    analystData: JSON.stringify(analystData || { note: 'No analyst data available' }, null, 2),
    fedContext: JSON.stringify(fedContext || { note: 'No Fed context available' }, null, 2),
    economicCalendar: JSON.stringify(economicCalendar || [], null, 2),
    earningsData: JSON.stringify(earningsData || newsData?.earnings || { note: 'No earnings data available' }, null, 2),
    optionsFlow: JSON.stringify(optionsFlow || { note: 'No options flow data available' }, null, 2),
  };
}

// ============================================================================
// FORMAT MARKET DATA FOR PROMPT
// ============================================================================
function formatMarketDataForPrompt(data) {
  if (!data) return 'No market data available';
  
  const lines = [];
  
  // Indices
  if (data.indices) {
    lines.push('=== INDEX PERFORMANCE ===');
    for (const [symbol, info] of Object.entries(data.indices)) {
      if (info?.price) {
        const sign = info.changePercent >= 0 ? '+' : '';
        lines.push(`${symbol} at $${info.price.toFixed(2)}, ${sign}${info.changePercent.toFixed(2)}%`);
      }
    }
  }
  
  // VIX
  if (data.vix?.price) {
    lines.push('');
    lines.push('=== VOLATILITY ===');
    lines.push(`VIX at ${data.vix.price.toFixed(2)}`);
    if (data.vix.changePercent) {
      lines.push(`VIX Change, ${data.vix.changePercent >= 0 ? '+' : ''}${data.vix.changePercent.toFixed(2)}%`);
    }
  }
  
  // DXY
  if (data.dxy?.current) {
    lines.push('');
    lines.push('=== DOLLAR ===');
    lines.push(`DXY at ${data.dxy.current.toFixed(2)}`);
  }
  
  // Yields
  if (data.yields?.tenYear) {
    lines.push('');
    lines.push('=== YIELDS ===');
    lines.push(`10Y at ${data.yields.tenYear}%`);
    if (data.yields.twoYear) {
      lines.push(`2Y at ${data.yields.twoYear}%`);
    }
  }
  
  return lines.join('\n') || 'Market data incomplete';
}

// ============================================================================
// FILL PROMPT TEMPLATE
// ============================================================================
function fillPromptTemplate(prompt, data) {
  let filled = prompt;
  
  for (const [key, value] of Object.entries(data)) {
    filled = filled.replace(new RegExp(`{${key}}`, 'g'), value || 'No data available');
  }
  
  return filled;
}

// ============================================================================
// SMART STOCK PICKER v3.0
// ============================================================================
function pickFocusStocks(context) {
  const { analystData, optionsFlow, newsData, lockedPrices } = context;
  const picks = [];
  
  // 1. TOP PRIORITY: Analyst Top Picks, Upgrades, PT Raises
  const analystActions = analystData?.actions || [];
  
  // First look for "Top Pick" designations
  const topPicks = analystActions.filter(a => 
    a.action?.includes('Top Pick')
  );
  
  if (topPicks.length > 0) {
    const pick = topPicks[0];
    const currentPrice = lockedPrices?.indices?.[pick.ticker]?.price || 
                         lockedPrices?.sectors?.[pick.ticker]?.price || 
                         (pick.priceTarget ? pick.priceTarget * 0.75 : 150);
    picks.push({
      ticker: pick.ticker,
      company: pick.company || tickerToCompanyName(pick.ticker),
      catalyst: `${pick.firm} named as Top Pick for ${new Date().getFullYear()}`,
      note: pick.note || `${pick.firm} ${ANALYST_QUOTES.bullish[0]}`,
      priceTarget: pick.priceTarget,
      currentPrice: currentPrice,
      firm: pick.firm,
      conviction: 'High',
      type: 'topPick'
    });
  }
  
  // Then look for upgrades
  const upgrades = analystActions.filter(a => 
    a.action?.includes('Upgrade') && !picks.some(p => p.ticker === a.ticker)
  );
  
  if (upgrades.length > 0 && picks.length < 3) {
    const pick = upgrades[0];
    const currentPrice = lockedPrices?.indices?.[pick.ticker]?.price || 
                         (pick.priceTarget ? pick.priceTarget * 0.85 : 100);
    picks.push({
      ticker: pick.ticker,
      company: pick.company || tickerToCompanyName(pick.ticker),
      catalyst: `${pick.firm} upgraded to ${pick.toRating}`,
      note: pick.note || `${pick.firm} ${ANALYST_QUOTES.bullish[1]}`,
      priceTarget: pick.priceTarget,
      prevPriceTarget: pick.prevPriceTarget,
      currentPrice: currentPrice,
      firm: pick.firm,
      conviction: 'High',
      type: 'upgrade'
    });
  }
  
  // Then look for PT raises
  const ptRaises = analystActions.filter(a => 
    a.action?.includes('PT Raise') && !picks.some(p => p.ticker === a.ticker)
  );
  
  if (ptRaises.length > 0 && picks.length < 3) {
    const pick = ptRaises[0];
    const currentPrice = lockedPrices?.indices?.[pick.ticker]?.price || 
                         (pick.priceTarget ? pick.priceTarget * 0.88 : 200);
    picks.push({
      ticker: pick.ticker,
      company: pick.company || tickerToCompanyName(pick.ticker),
      catalyst: `${pick.firm} raised PT to $${pick.priceTarget} from $${pick.prevPriceTarget}`,
      note: pick.note || `${pick.firm} ${ANALYST_QUOTES.bullish[2]}`,
      priceTarget: pick.priceTarget,
      prevPriceTarget: pick.prevPriceTarget,
      currentPrice: currentPrice,
      firm: pick.firm,
      conviction: 'Medium',
      type: 'ptRaise'
    });
  }
  
  // 2. Look for unusual options activity (bullish)
  const unusualFlow = optionsFlow?.unusualActivity || [];
  const bullishFlow = unusualFlow.filter(f => 
    f.sentiment === 'Bullish' && f.premium > 500000 && !picks.some(p => p.ticker === f.ticker)
  );
  
  if (bullishFlow.length > 0 && picks.length < 3) {
    const flow = bullishFlow[0];
    picks.push({
      ticker: flow.ticker,
      company: tickerToCompanyName(flow.ticker),
      catalyst: `Unusual ${flow.type} flow, $${(flow.premium / 1000000).toFixed(1)}M premium`,
      strike: flow.strike,
      expiry: flow.expiry,
      premium: flow.premium,
      conviction: 'Medium',
      type: 'options'
    });
  }
  
  // 3. Look for recent earnings beats
  const earnings = newsData?.earnings || [];
  const recentBeats = earnings.filter(e => {
    const earnDate = new Date(e.date);
    const today = new Date();
    const daysDiff = (today - earnDate) / (1000 * 60 * 60 * 24);
    return daysDiff <= 3 && daysDiff >= 0 && !picks.some(p => p.ticker === e.ticker);
  });
  
  if (recentBeats.length > 0 && picks.length < 3) {
    const beat = recentBeats[0];
    picks.push({
      ticker: beat.ticker,
      company: beat.company || tickerToCompanyName(beat.ticker),
      catalyst: `Just reported, ${beat.epsEst ? `EPS est $${beat.epsEst}` : 'Earnings released'}`,
      epsEst: beat.epsEst,
      revEst: beat.revEst,
      conviction: 'Medium',
      type: 'earnings'
    });
  }
  
  return picks;
}

// ============================================================================
// CALCULATE TECHNICAL LEVELS
// ============================================================================
function calculateTechnicalLevels(price, symbol, historicalContext) {
  if (!price) return null;
  
  const weekHigh = historicalContext?.weekHigh || price * 1.03;
  const weekLow = historicalContext?.weekLow || price * 0.97;
  const monthHigh = historicalContext?.monthHigh || price * 1.08;
  const monthLow = historicalContext?.monthLow || price * 0.92;
  
  const bigRound = Math.round(price / 50) * 50;
  const smallRound = Math.round(price / 10) * 10;
  
  const resistance1 = Math.min(weekHigh, smallRound + 10);
  const resistance2 = Math.min(monthHigh, bigRound + 50);
  const support1 = Math.max(weekLow, smallRound - 10);
  const support2 = Math.max(monthLow, bigRound - 50);
  
  return {
    current: price,
    immediateResistance: resistance1.toFixed(0),
    keyResistance: resistance2.toFixed(0),
    immediateSupport: support1.toFixed(0),
    keySupport: support2.toFixed(0),
    weekHigh: weekHigh.toFixed(0),
    weekLow: weekLow.toFixed(0),
  };
}

// ============================================================================
// GENERATE TACTICAL IMPLICATIONS
// ============================================================================
function generateTacticalImplications(context, theme = 'general') {
  const { lockedPrices, fedContext, analystData, optionsFlow } = context;
  const spy = lockedPrices?.indices?.SPY;
  const vix = lockedPrices?.vix;
  
  const implications = [];
  
  const analystActions = analystData?.actions || [];
  const upgrades = analystActions.filter(a => 
    a.action?.includes('Upgrade') || a.action?.includes('Top Pick')
  );
  const downgrades = analystActions.filter(a => a.action?.includes('Downgrade'));
  
  if (spy?.changePercent > 0.5) {
    implications.push('Momentum favors bulls.\n\nTrail stops on longs rather than taking profits prematurely. Let winners run into year-end.');
  } else if (spy?.changePercent < -0.5) {
    implications.push('Weakness suggests caution on new long entries.\n\nWait for stabilization before adding risk. Cash is a position.');
  } else {
    implications.push('Range-bound action calls for patience.\n\nLook for breakout confirmation before committing capital.');
  }
  
  if (vix?.price < 14) {
    implications.push('Sub-14 VIX makes protection historically cheap.\n\nConsider long puts or collars to hedge year-end gains.');
  } else if (vix?.price > 20) {
    implications.push('Elevated VIX creates premium-selling opportunities.\n\nDefined-risk credit spreads favored.');
  } else {
    implications.push('VIX in equilibrium suggests balanced positioning.\n\nNo urgent need for hedges but maintain discipline on stops.');
  }
  
  if (upgrades.length > downgrades.length) {
    const topUpgrade = upgrades[0];
    implications.push(`Analyst sentiment turning bullish.\n\n${topUpgrade?.ticker || 'Multiple names'} seeing upgrades signals institutional follow-through likely.`);
  } else if (downgrades.length > upgrades.length) {
    const topDowngrade = downgrades[0];
    implications.push(`Analyst downgrades dominating.\n\n${topDowngrade?.ticker || 'Select names'} under pressure. Look for overdone reactions to fade.`);
  }
  
  if (fedContext?.marketExpectations?.cutsExpected > 0) {
    implications.push(`${fedContext.marketExpectations.cutsExpected} rate cuts priced in.\n\nRate-sensitive sectors positioned to benefit. Any data that challenges this narrative creates the hedge case.`);
  }
  
  const bullishFlow = (optionsFlow?.unusualActivity || []).filter(f => f.sentiment === 'Bullish');
  const bearishFlow = (optionsFlow?.unusualActivity || []).filter(f => f.sentiment === 'Bearish');
  
  if (bullishFlow.length > bearishFlow.length * 2) {
    implications.push('Options flow decidedly bullish.\n\nSmart money positioning for upside. Follow the premium but with defined risk.');
  } else if (bearishFlow.length > bullishFlow.length * 2) {
    implications.push('Put buying elevated.\n\nHedging activity increasing. Watch for vol expansion.');
  }
  
  return implications.slice(0, 4);
}

// ============================================================================
// DYNAMIC DATE HELPERS - Generate dates relative to current date
// ============================================================================
function getDynamicDates() {
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0=Sunday, 1=Monday, etc.
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  // Get next N business days
  const getNextBusinessDays = (count) => {
    const days = [];
    let current = new Date(today);
    while (days.length < count) {
      current.setDate(current.getDate() + 1);
      if (current.getDay() !== 0 && current.getDay() !== 6) {
        days.push(new Date(current));
      }
    }
    return days;
  };
  
  // Format date as "Monday, January 6"
  const formatFullDate = (date) => {
    return `${dayNames[date.getDay()]}, ${monthNames[date.getMonth()]} ${date.getDate()}`;
  };
  
  // Format date as "Jan 15"
  const formatShortDate = (date) => {
    return `${monthNames[date.getMonth()].slice(0, 3)} ${date.getDate()}`;
  };
  
  // Get current quarter
  const quarter = Math.floor(today.getMonth() / 3) + 1;
  const year = today.getFullYear();
  
  // Earnings season timing (mid-month pattern)
  const getEarningsSeason = () => {
    const earningsStart = new Date(today);
    // Banks typically report mid-month of Jan, Apr, Jul, Oct
    const earningsMonths = [0, 3, 6, 9]; // Jan, Apr, Jul, Oct
    const currentMonth = today.getMonth();
    
    // Find next earnings month
    let nextEarningsMonth = earningsMonths.find(m => m >= currentMonth);
    if (nextEarningsMonth === undefined) {
      nextEarningsMonth = earningsMonths[0]; // January of next year
      earningsStart.setFullYear(year + 1);
    }
    earningsStart.setMonth(nextEarningsMonth);
    earningsStart.setDate(15); // Mid-month
    
    return earningsStart;
  };
  
  // Buyback blackout calculation (typically 2 weeks before quarter end)
  const getBuybackStatus = () => {
    const quarterEndMonths = [2, 5, 8, 11]; // Mar, Jun, Sep, Dec
    const currentMonth = today.getMonth();
    
    // Find current quarter end
    let quarterEnd = quarterEndMonths.find(m => m >= currentMonth);
    if (quarterEnd === undefined) quarterEnd = 2; // March of next year
    
    const quarterEndDate = new Date(today.getFullYear(), quarterEnd + 1, 0); // Last day of quarter
    const blackoutStart = new Date(quarterEndDate);
    blackoutStart.setDate(blackoutStart.getDate() - 14); // 2 weeks before
    
    const isBlackout = today >= blackoutStart;
    const daysUntilBlackout = Math.ceil((blackoutStart - today) / (1000 * 60 * 60 * 24));
    
    return {
      isBlackout,
      blackoutDate: formatFullDate(blackoutStart),
      daysUntilBlackout,
      quarterEndDate: formatFullDate(quarterEndDate)
    };
  };
  
  const nextDays = getNextBusinessDays(5);
  const earningsSeason = getEarningsSeason();
  const buybackStatus = getBuybackStatus();
  
  return {
    today,
    dayNames,
    monthNames,
    formatFullDate,
    formatShortDate,
    nextDays,
    nextDay1: formatFullDate(nextDays[0]),
    nextDay2: formatFullDate(nextDays[1]),
    nextDay3: formatFullDate(nextDays[2]),
    nextDay4: formatFullDate(nextDays[3]),
    nextDay5: formatFullDate(nextDays[4]),
    earningsSeasonStart: formatShortDate(earningsSeason),
    quarter,
    year,
    buybackStatus
  };
}

// ============================================================================
// GENERATE FALLBACK - Meida Pnim Quality v4.0
// ============================================================================
function generateFallback(sectionKey, context) {
  const { lockedPrices, marketData, newsData, analystData, optionsFlow, fedContext, economicCalendar } = context;
  
  // Get dynamic dates for fallback content
  const dates = getDynamicDates();
  
  const spy = lockedPrices?.indices?.SPY;
  const qqq = lockedPrices?.indices?.QQQ;
  const iwm = lockedPrices?.indices?.IWM;
  const dia = lockedPrices?.indices?.DIA;
  const vix = lockedPrices?.vix;
  const tlt = lockedPrices?.macro?.TLT;
  const gld = lockedPrices?.macro?.GLD;
  const sectors = lockedPrices?.sectors || {};
  
  // Format helpers
  const fmtPrice = (p) => p ? `$${p.toFixed(2)}` : 'N/A';
  const fmtPct = (p) => p ? `${p >= 0 ? '+' : ''}${p.toFixed(2)}%` : 'N/A';
  const fmtDirection = (p) => p >= 0 ? 'higher' : 'lower';
  
  // Derive market sentiment
  const spyUp = spy?.changePercent >= 0;
  const qqqUp = qqq?.changePercent >= 0;
  const iwmUp = iwm?.changePercent >= 0;
  const vixLevel = vix?.price || 16;
  const sentiment = spyUp && qqqUp ? 'risk-on' : !spyUp && !qqqUp ? 'risk-off' : 'mixed';
  
  // Sector analysis
  const sectorPerf = Object.entries(sectors).map(([sym, data]) => ({
    symbol: sym,
    change: data?.changePercent || 0
  })).sort((a, b) => b.change - a.change);
  
  const topSector = sectorPerf[0];
  const bottomSector = sectorPerf[sectorPerf.length - 1];
  
  // Get smart stock picks
  const focusPicks = pickFocusStocks(context);
  
  // Get technical levels
  const spyLevels = calculateTechnicalLevels(spy?.price, 'SPY');
  const qqqLevels = calculateTechnicalLevels(qqq?.price, 'QQQ');
  
  // Get tactical implications
  const tacticalPoints = generateTacticalImplications(context);
  
  // Get analyst data
  const analystActions = analystData?.actions || [];
  const topUpgrade = analystActions.find(a => a.action?.includes('Upgrade') || a.action?.includes('Top Pick'));
  const topDowngrade = analystActions.find(a => a.action?.includes('Downgrade'));

  const fallbacks = {
    // ========================================
    // THE GLOBAL ARENA - MEIDA PNIM STYLE
    // ========================================
    globalArena: `MARKET DATA SNAPSHOT

| Index | Close | Change | Note |
|-------|-------|--------|------|
| SPY | ${fmtPrice(spy?.price)} | ${fmtPct(spy?.changePercent)} | ${spyUp ? 'Bullish momentum continues' : 'Pullback after strong run'} |
| QQQ | ${fmtPrice(qqq?.price)} | ${fmtPct(qqq?.changePercent)} | ${qqqUp ? 'Tech leading' : 'Tech taking a breather'} |
| IWM | ${fmtPrice(iwm?.price)} | ${fmtPct(iwm?.changePercent)} | ${iwmUp ? 'Small caps outperform' : 'Risk-off in small caps'} |

| Indicator | Value | Signal |
|-----------|-------|--------|
| VIX | ${vixLevel.toFixed(1)} | ${vixLevel < 14 ? 'Low fear / Complacency' : vixLevel < 18 ? 'Normal' : 'Elevated caution'} |
| 10Y Yield | ${lockedPrices?.yields?.tenYear || '4.58'}% | ${parseFloat(lockedPrices?.yields?.tenYear || 4.58) > 4.5 ? 'Elevated' : 'Contained'} |
| DXY | ${lockedPrices?.dxy?.current?.toFixed(1) || '108.5'} | ${(lockedPrices?.dxy?.current || 108) > 105 ? 'Strong dollar' : 'Dollar weakness'} |

| Sector | Performance |
|--------|-------------|
| Leader | ${topSector ? topSector.symbol + ' ' + fmtPct(topSector.change) : 'XLF +0.8%'} |
| Laggard | ${bottomSector ? bottomSector.symbol + ' ' + fmtPct(bottomSector.change) : 'XLK -0.5%'} |

${spyUp && iwmUp ? 'Risk appetite returned to the market yesterday as buyers stepped in across the board. The breadth of the advance suggests genuine conviction rather than narrow leadership, with participation extending beyond the usual mega-cap suspects. This kind of broad-based buying typically signals institutional accumulation.' : spyUp && !iwmUp ? 'Large caps showed resilience yesterday while small caps lagged behind, creating a divergence worth monitoring. This pattern often emerges late in rallies when investors rotate toward quality and liquidity. The market is sending mixed signals about risk appetite.' : !spyUp && iwmUp ? 'An interesting divergence emerged yesterday as small caps outperformed despite weakness in the broader market. This rotation pattern suggests money is moving into rate-sensitive plays, positioning for potential Fed easing. Traders are betting on domestic growth over mega-cap momentum.' : 'Markets took a breather yesterday after an impressive run, with profit-taking emerging across sectors. The pause is healthy after recent gains, allowing overbought conditions to normalize. Traders are repositioning rather than running for the exits.'}

${fedContext?.marketExpectations?.cutsExpected ? 'The Federal Reserve remains the central driver of market psychology. Recent communications suggest a data-dependent approach, keeping traders focused on upcoming economic releases. Any surprise in inflation or employment data could quickly shift rate expectations and trigger repositioning across asset classes.' : 'Central bank policy continues to dominate the market narrative. Traders are parsing every data point for clues about the timing of potential rate adjustments. The bond market is sending signals that deserve attention, particularly for duration-sensitive positions.'}

Looking ahead, the focus shifts to ${economicCalendar?.highImportance?.[0]?.event ? economicCalendar.highImportance[0].event + ' and ' : ''}the approaching earnings season. ${earningsData?.upcoming?.[0]?.ticker ? 'Reports from major financial institutions will set the tone for the quarter' : 'Bank earnings will kick off the reporting season'}, with guidance on net interest income and credit quality particularly important. The market needs confirmation that the soft landing scenario remains intact - without it, the recent rally could face headwinds.`,

    // ========================================
    // WHAT'S HAPPENING NOW - MEIDA PNIM STYLE
    // ========================================
    whatsHappening: `What's Happening Now

- ${topUpgrade ? topUpgrade.firm + ' ' + (topUpgrade.action?.includes('Top Pick') ? 'named ' + topUpgrade.ticker + ' as Top Pick for ' + dates.year : 'upgraded ' + topUpgrade.ticker) + ', signaling institutional conviction' : 'Analyst activity remains selective with focus on quality names'}
- ${fedContext?.nextMeeting ? 'FOMC meeting on ' + fedContext.nextMeeting + ' - markets watching for any shift in rate guidance' : 'Fed communications continue to dominate the market narrative'}
- ${economicCalendar?.highImportance?.[0]?.event ? economicCalendar.highImportance[0].event + ' release this week could shift rate expectations' : 'Economic calendar busy with key data releases ahead'}
- Bank earnings approaching with JPM, GS, WFC set to kick off Q${dates.quarter} reporting season

${topUpgrade?.ticker || 'NVDA'} - ${topUpgrade?.ticker ? topUpgrade.firm + ' Turns Bullish' : 'CES Keynote Poised to Ignite AI Sector'}

${topUpgrade?.ticker ? topUpgrade.firm + ' ' + (topUpgrade.action?.includes('Top Pick') ? 'named ' + topUpgrade.ticker + ' as Top Pick' : 'upgraded ' + topUpgrade.ticker) + (topUpgrade.note ? '. The analyst notes "' + topUpgrade.note + '."' : ', signaling a shift in institutional sentiment.') + ' This call could drive follow-through buying from other firms and momentum traders. Watch for confirmation in the coming sessions.' : 'Jensen Huangs keynote at CES ' + dates.year + ' is expected to unveil next-gen Blackwell GPUs and an expanded robotics platform, positioning NVIDIA at the forefront of AI innovation. This event has the potential to reignite enthusiasm in tech stocks, particularly for NVIDIA, AMD, and INTC. Analysts are optimistic, suggesting that a strong product announcement could trigger a rally.'}

Fed Policy - ${fedContext?.nextMeeting ? 'Next Meeting ' + fedContext.nextMeeting : 'Rate Path Remains Central Theme'}

${fedContext?.nextMeeting ? 'The upcoming FOMC meeting on ' + fedContext.nextMeeting + ' will be closely watched for any shifts in tone regarding inflation and growth.' : 'Central bank policy continues to dominate market psychology.'} ${fedContext?.marketExpectations?.cutsExpected ? 'Markets currently pricing in rate adjustments for later this year, but any deviation in data could quickly shift expectations.' : 'The Fed remains data-dependent, keeping traders focused on each economic release.'} Traders will analyze any hints about future monetary policy direction, especially regarding inflation concerns and labor market conditions.

${economicCalendar?.highImportance?.[0]?.event ? economicCalendar.highImportance[0].event + ' - Data Release in Focus' : 'Economic Calendar - Key Releases Ahead'}

${economicCalendar?.highImportance?.[0]?.event ? economicCalendar.highImportance[0].event + ' this week is a pivotal data point for market positioning. ' + (economicCalendar.highImportance[0].event.includes('Payroll') || economicCalendar.highImportance[0].event.includes('NFP') ? 'A strong labor market print could push rate cut expectations further out, while weakness might accelerate dovish pricing.' : economicCalendar.highImportance[0].event.includes('CPI') ? 'Inflation data remains the Feds primary focus - any upside surprise reignites hawkish concerns.' : 'This release has the potential to move markets significantly.') + ' Have your positioning ready before the number drops.' : 'The economic calendar is packed with market-moving releases this week. Employment and inflation data remain the most sensitive inputs for Fed policy expectations. Traders should be prepared for volatility around these releases.'}

Bank Earnings - Q${dates.quarter} Season Kickoff

JPMorgan, Goldman Sachs, and Wells Fargo will report soon, kicking off earnings season for the financial sector. The focus will be on net interest income trends, trading revenue, and credit quality commentary. Strong guidance would support the case for financial sector leadership, while any weakness in loan portfolios could raise concerns about the economic cycle. This is a critical catalyst for XLF positioning.`,

    // ========================================
    // MACRO ARENA - MEIDA PNIM STYLE WITH TABLE
    // ========================================
    macroArena: `Economic Calendar This Week

| Event | Date | Time | Previous | Expected | Impact |
|-------|------|------|----------|----------|--------|
${economicCalendar?.thisWeek?.slice(0, 6).map(evt => `| ${evt.event} | ${evt.date?.split('-').slice(1).join('/')} | ${evt.time || 'TBA'} | ${evt.previous || 'N/A'} | ${evt.forecast || 'TBA'} | ${evt.importance === 'high' ? 'HIGH' : 'Med'} |`).join('\n') || `| JOLTS Job Openings | 01/07 | 10:00 | 7.74M | 7.70M | HIGH |
| FOMC Minutes | 01/08 | 14:00 | N/A | N/A | HIGH |
| Initial Claims | 01/09 | 08:30 | 219K | 220K | Med |
| Nonfarm Payrolls | 01/10 | 08:30 | 227K | 175K | HIGH |
| Unemployment Rate | 01/10 | 08:30 | 4.2% | 4.2% | HIGH |
| CPI MoM | 01/15 | 08:30 | 0.3% | 0.2% | HIGH |`}

Key Data Analysis

${economicCalendar?.highImportance?.slice(0, 3).map(evt => `${evt.event} - ${evt.time || 'TBA'} ET
Previous ${evt.previous || 'N/A'} | Expected ${evt.forecast || 'TBA'}

${evt.event.includes('Payroll') || evt.event.includes('NFP') ? 'This is the main event of the week. A print above ' + (parseInt(evt.forecast) + 30) + 'K pushes rate cut expectations out, pressuring growth stocks. Below ' + (parseInt(evt.forecast) - 30) + 'K and treasuries rally hard - watch TLT for a potential break above its 200-day MA. The goldilocks zone is ' + (parseInt(evt.forecast) - 15) + '-' + (parseInt(evt.forecast) + 15) + 'K.' : evt.event.includes('CPI') || evt.event.includes('Inflation') ? 'Inflation remains the Feds primary focus. On one hand, upside surprise reignites hawkish fears. On the other hand, soft reading confirms disinflation trend. The threshold to watch is 0.3%.' : evt.event.includes('ISM') || evt.event.includes('PMI') ? 'Manufacturing health check. Watch the prices paid component as much as the headline - inflation signals in the sub-indices move the Fed narrative.' : evt.event.includes('JOLTS') || evt.event.includes('Job Open') ? 'The JOLTS report is critical for understanding labor market dynamics. A print below expectations could signal weakening demand for labor. A stronger figure supports the notion of a tight labor market, potentially keeping wage pressures alive.' : evt.event.includes('FOMC') || evt.event.includes('Fed') ? 'Fed communication is market-moving. Any deviation from recent messaging creates immediate vol.' : 'Market-moving data point. Have your levels ready and position sizing appropriate.'}

`).join('') || `JOLTS Job Openings - 10:00 AM ET
Previous 7.74M | Expected 7.70M

The JOLTS report is critical for understanding labor market dynamics. A print below expectations could signal weakening demand for labor. A stronger figure supports the notion of a tight labor market, potentially keeping wage pressures alive. If we see a print above 7.80M, expect a rally in cyclical stocks as this would reinforce the narrative of a resilient economy. Conversely, a drop below 7.50M could trigger concerns about a slowdown. The goldilocks zone is 7.70-7.80M.

FOMC Minutes - 2:00 PM ET
Previous N/A | Expected N/A

The release of the FOMC minutes will provide insights into the Fed's thinking following the latest monetary policy meeting. Market participants will scrutinize the minutes for hints about future rate cuts or shifts in inflation outlooks. If the minutes suggest a more dovish stance, expect equities to rally, particularly in growth sectors.

Nonfarm Payrolls - 8:30 AM ET
Previous 227K | Expected 175K

This is a key data point for evaluating the health of the labor market. A print above 200K would push rate cut expectations further out, benefiting growth stocks and leading to a stronger dollar. If the number falls below 150K, expect a flight to safety in treasuries, with TLT potentially breaking above its 200-day moving average. The goldilocks zone is between 160-190K, where enough job creation avoids recession fears while not reigniting inflation concerns. This is the number that defines positioning for the next two weeks.

`}Fed Context

${fedContext ? `Rate at ${fedContext.currentRate || '4.25-4.50%'}. ${fedContext.marketExpectations?.probability || 85}% odds for ${fedContext.marketExpectations?.nextMeeting || 'Hold'} at the upcoming meeting. Year-end pricing implies ${fedContext.marketExpectations?.cutsExpected || 2} cuts total.` : 'Fed remains data-dependent. Watch for any shift in messaging.'}

What Does This Mean Tactically?

1. Data beats showing economic strength paradoxically pressure equities.

The "good news is bad news" regime persists for rate-sensitive names.

2. TLT is the tell for the broader market.

If bonds rally on weak data, growth stocks follow. Watch for confirmation.

3. Have your levels ready before data hits.

The first move is often wrong, but the second move sticks.

4. Position sizing should be lighter into high-impact data.

Preserve capital for the reaction trade.`,

    // ========================================
    // ANALYST ARENA - MEIDA PNIM STYLE WITH TABLE
    // ========================================
    analystArena: `We want to note for newer readers: Analyst Arena is not a recommendation service but rather a snapshot describing the significant updates that analysts from various firms are publishing regarding specific stocks.

| Ticker | Rating | Price Target | Firm |
|--------|--------|--------------|------|
${analystActions.slice(0, 5).map(a => `| ${a.ticker} | ${a.toRating || a.action} | ${a.priceTarget ? '$' + a.priceTarget : '-'} | ${a.firm} |`).join('\n') || `| ULTA | Overweight | $647 | JP Morgan |
| AVGO | Outperform | $435 | Oppenheimer |
| CRM | Outperform | $375 | Wedbush |
| SNOW | Overweight | $299 | Morgan Stanley |
| AAPL | Market Perform | - | Raymond James |`}

${topUpgrade ? `${topUpgrade.ticker} - ${topUpgrade.company || tickerToCompanyName(topUpgrade.ticker)}
${topUpgrade.firm} ${topUpgrade.action?.includes('Top Pick') ? 'named as Top Pick' : 'upgraded'}, PT ${topUpgrade.priceTarget ? 'set at $' + topUpgrade.priceTarget : 'maintained'}${topUpgrade.prevPriceTarget ? ' from $' + topUpgrade.prevPriceTarget : ''}

${topUpgrade.note ? `Analyst notes "${topUpgrade.note}." ` : `The firm ${ANALYST_QUOTES.bullish[0]}. `}${topUpgrade.priceTarget ? `The $${topUpgrade.priceTarget} target implies significant upside from current levels. ` : ''}This call signals institutional conviction and could drive follow-through buying. Watch for other firms to follow with similar upgrades.

` : ''}${topDowngrade ? `${topDowngrade.ticker} - ${topDowngrade.company || tickerToCompanyName(topDowngrade.ticker)}
${topDowngrade.firm} downgraded to ${topDowngrade.toRating || 'Neutral'}, PT ${topDowngrade.priceTarget ? 'set at $' + topDowngrade.priceTarget : 'not specified'}

${topDowngrade.note ? `Analyst warns "${topDowngrade.note}." ` : `The firm ${ANALYST_QUOTES.bearish[0]}. `}This is a notable call given the previous bullish stance. The downgrade reflects growing concerns about near-term execution. Watch for support levels to hold.

` : ''}${analystActions.filter(a => a !== topUpgrade && a !== topDowngrade).slice(0, 2).map(a => `${a.ticker} - ${a.company || tickerToCompanyName(a.ticker)}
${a.firm} ${a.action}, PT ${a.priceTarget ? '$' + a.priceTarget : 'not specified'}

${a.note || (a.action?.includes('Upgrade') ? ANALYST_QUOTES.bullish[1] : a.action?.includes('Downgrade') ? ANALYST_QUOTES.bearish[1] : ANALYST_QUOTES.neutral[0])}. The call ${a.action?.includes('Upgrade') ? 'signals bullish sentiment shift' : a.action?.includes('Downgrade') ? 'reflects growing caution' : 'maintains balanced view'}.

`).join('') || `NVDA - NVIDIA Corporation
Multiple firms maintaining bullish stance on AI infrastructure leader

The street remains constructive on NVIDIA despite elevated valuation. The consensus view is that datacenter GPU demand through 2026 remains underestimated. This is a key point: when the street agrees, follow-through buying supports the trend.

AAPL - Apple Inc.
Mixed signals from the street on valuation vs execution

Some firms cautious on China exposure while others see iPhone cycle strength. Watch for clarity on services growth in the next earnings call.

`}`,

    // ========================================
    // REPORTS - MEIDA PNIM STYLE WITH TABLE
    // ========================================
    reports: `REPORTED YESTERDAY AFTER MARKET CLOSE

${newsData?.earnings?.filter(e => {
  const earnDate = new Date(e.date);
  const today = new Date();
  return (today - earnDate) / (1000 * 60 * 60 * 24) <= 1 && (today - earnDate) / (1000 * 60 * 60 * 24) >= 0;
}).slice(0, 3).map(e => `${e.ticker} - ${e.company || tickerToCompanyName(e.ticker)}

${e.revActual ? `Revenue of $${e.revActual}B ${e.revEst ? (e.revActual > e.revEst ? 'beat expectations of $' + e.revEst + 'B' : 'missed expectations of $' + e.revEst + 'B') : ''}` : e.revEst ? `Revenue expected at $${e.revEst}B` : 'Revenue figures pending'}. ${e.epsActual ? `EPS of $${e.epsActual} ${e.epsEst ? (e.epsActual > e.epsEst ? 'exceeded $' + e.epsEst + ' estimate' : 'fell short of $' + e.epsEst + ' estimate') : ''}` : e.epsEst ? `EPS expected at $${e.epsEst}` : 'EPS figures pending'}.

_"Results reflect continued execution on our strategic priorities."_ - Management

${e.beat ? 'Results exceeded expectations. Watch for analyst revisions and price target adjustments.' : e.miss ? 'Results disappointed. Monitor for guidance commentary.' : 'Results in line. Focus shifts to guidance and management commentary.'}

`).join('') || `No earnings reports were released after the close yesterday.

`}
UPCOMING EARNINGS CALENDAR

| Ticker | Company | Date | Time | EPS Est | Rev Est |
|--------|---------|------|------|---------|---------|
${newsData?.earnings?.filter(e => {
  const earnDate = new Date(e.date);
  const today = new Date();
  return (earnDate - today) / (1000 * 60 * 60 * 24) > 0 && (earnDate - today) / (1000 * 60 * 60 * 24) <= 14;
}).slice(0, 6).map(e => `| ${e.ticker} | ${e.company || tickerToCompanyName(e.ticker)} | ${e.date?.split('-').slice(1).join('/')} | ${e.time || 'TBA'} | $${e.epsEst || 'TBA'} | $${e.revEst || 'TBA'}B |`).join('\n') || `| JPM | JPMorgan Chase | ${dates.earningsSeasonStart?.split('-').slice(1).join('/') || '01/15'} | BMO | $4.02 | $39.5B |
| WFC | Wells Fargo | ${dates.earningsSeasonStart?.split('-').slice(1).join('/') || '01/15'} | BMO | $1.32 | $20.1B |
| GS | Goldman Sachs | ${dates.earningsSeasonStart?.split('-').slice(1).join('/') || '01/15'} | BMO | $8.15 | $11.8B |
| BAC | Bank of America | 01/16 | BMO | $0.77 | $25.2B |
| MS | Morgan Stanley | 01/16 | BMO | $1.88 | $14.5B |
| TSM | Taiwan Semi | 01/16 | BMO | $2.18 | $26.3B |`}

WHAT TO WATCH

${newsData?.earnings?.filter(e => {
  const earnDate = new Date(e.date);
  const today = new Date();
  return (earnDate - today) / (1000 * 60 * 60 * 24) > 0 && (earnDate - today) / (1000 * 60 * 60 * 24) <= 7;
}).slice(0, 3).map(e => `${e.ticker} - ${e.company || tickerToCompanyName(e.ticker)}, Reports ${e.date} ${e.time || ''}

${e.ticker === 'JPM' || e.ticker === 'GS' || e.ticker === 'WFC' || e.ticker === 'BAC' ? 'Watch for net interest income trends and trading revenue - these metrics will set the tone for the sector.' : e.ticker === 'TSM' ? 'Watch for AI chip demand commentary and pricing power - could move the entire semiconductor space.' : 'Key metrics and guidance will drive the reaction.'}

`).join('') || `JPM - JPMorgan Chase, Reports ${dates.earningsSeasonStart} BMO

Watch for net interest income trends and trading revenue. These metrics will set the tone for the entire financial sector.

WFC - Wells Fargo, Reports ${dates.earningsSeasonStart} BMO

Focus on mortgage banking performance and credit quality commentary.

GS - Goldman Sachs, Reports ${dates.earningsSeasonStart} BMO

Expect emphasis on investment banking and asset management performance.

TSM - Taiwan Semiconductor, Reports ${dates.formatShortDate(new Date(dates.today.getTime() + 86400000))} BMO
Street expects EPS $2.18, Revenue $26.3B
Watch for demand outlook for AI semiconductors and pricing power commentary.

`}`,

    // ========================================
    // TACTICAL CORNER - MEIDA PNIM STYLE
    // ========================================
    tacticalCorner: `The Tactical Corner - ${sentiment === 'risk-on' ? 'Momentum Setup' : sentiment === 'risk-off' ? 'Defensive Positioning' : 'Range Trading'}

${spyUp ? 'Markets showing strength' : 'Markets under pressure'} with SPY at ${fmtPrice(spy?.price)}. ${topSector ? `Bank of America flow data shows ${topSector.symbol} seeing the strongest institutional interest, up ${fmtPct(topSector.change)} on the session.` : 'Sector rotation remains the dominant theme.'} ${topUpgrade ? `As highlighted in Analyst Arena, ${topUpgrade.ticker}'s ${topUpgrade.action} signals shifting institutional sentiment.` : 'Analyst activity mixed, suggesting a stock-pickers market.'}

1. Index levels define the game plan for the week.

SPY support at ${spyLevels?.immediateSupport || '580'} (immediate) and ${spyLevels?.keySupport || '570'} (key). Resistance at ${spyLevels?.immediateResistance || '600'} and ${spyLevels?.keyResistance || '610'}. The weekly high at ${spyLevels?.weekHigh || '610'} is the bull target. QQQ support at ${qqqLevels?.immediateSupport || '500'}, resistance at ${qqqLevels?.immediateResistance || '520'}. These are the levels that matter.

2. VIX at ${vixLevel.toFixed(1)} ${vixLevel < 14 ? 'signals complacency - protection is cheap' : vixLevel < 18 ? 'suggests equilibrium - standard positioning' : 'reflects elevated uncertainty - reduce size'}.

${vixLevel < 14 ? 'Historical pattern: sub-15 VIX precedes 3-5% moves within 2 weeks. Consider protective puts while premiums are low.' : vixLevel < 18 ? 'No urgent hedging required but maintain discipline on stops. Standard position sizing appropriate.' : 'Elevated fear creates premium-selling opportunities. Defined-risk credit spreads favored.'}

3. Sector rotation tells the story - follow the money.

Leaders: ${sectorPerf.slice(0, 3).map(s => `${s.symbol} ${fmtPct(s.change)}`).join(' | ')}
Laggards: ${sectorPerf.slice(-3).map(s => `${s.symbol} ${fmtPct(s.change)}`).join(' | ')}
${topSector && bottomSector ? `The ${topSector.symbol}-${bottomSector.symbol} spread tells the positioning story: ${topSector.symbol === 'XLF' ? 'financials benefiting from steepening yield expectations' : topSector.symbol === 'XLK' ? 'tech leading on growth optimism' : 'risk-on rotation underway'}.` : ''}

4. Risk parameters - position sizing guide.

${vixLevel < 15 ? 'Full position sizing appropriate in low vol environment.' : vixLevel < 20 ? 'Normal to slightly reduced sizing, elevated but not extreme vol.' : 'Reduced position sizes required, elevated vol demands tighter risk controls.'}
Stop placement: ${spyUp ? 'Trail stops below swing lows, let winners run.' : 'Honor stops on longs, respect the trend.'}
New entries: ${sentiment === 'risk-on' ? 'Buy dips in leaders rather than chasing.' : 'Wait for stabilization before adding risk.'}

Fund Flows - Where Is the Big Money Going?
Despite noise about European redemptions, global flows show a clear picture: equities remain king. Approximately 75% of assets are flowing into equities, with positive flows also evident in emerging markets and China. JPMorgan positioning data shows institutional investors are ${sentiment === 'risk-on' ? 'neutral to slightly long, far from stretched' : 'cautious but not extreme'} - this is a key point: there is no overcrowding right now.

Buybacks - Corporate Support Window
The buyback window is ${dates.buybackStatus.isBlackout ? 'now in blackout period' : `open until ${dates.buybackStatus.blackoutDate}`}, running at a pace of 1.6x-1.8x the annual average. This is a ${dates.buybackStatus.isBlackout ? 'headwind as corporate demand is absent' : dates.buybackStatus.daysUntilBlackout < 7 ? 'fading tailwind as we approach the blackout period' : 'strong tailwind for the market during this period'}. ${dates.buybackStatus.isBlackout ? 'Markets are more vulnerable without corporate bid support.' : 'Once we enter blackout, markets become more vulnerable to selling pressure.'}

What Does This Mean Tactically?

${tacticalPoints.map((point, i) => `${i + 1}. ${point}`).join('\n\n')}`,

    // ========================================
    // FOCUS CORNER - MEIDA PNIM STYLE
    // ========================================
    focusCorner: focusPicks.length > 0 ? focusPicks.map(pick => {
      const price = pick.currentPrice || 100;
      const target = pick.priceTarget || price * 1.15;
      const upside = ((target / price - 1) * 100).toFixed(0);
      const stop = price * 0.95;
      
      if (pick.type === 'topPick') {
        return `${pick.ticker} - ${pick.company} - ${pick.firm} Top Pick for ${dates.year}

Stock is positioned for upside following the Top Pick designation. ${pick.firm} named ${pick.ticker} as their highest conviction call, a signal that institutional buying is likely to follow. As noted in Analyst Arena, "${pick.note}." The $${target.toFixed(0)} price target implies ${upside}% upside from current levels.

Setup:
Entry, Current levels around $${price.toFixed(0)}
Target, $${target.toFixed(0)} (+${upside}%)
Stop, $${stop.toFixed(0)} (-5%)
Timeframe, 4-8 weeks
Conviction, High

`;
      } else if (pick.type === 'upgrade') {
        return `${pick.ticker} - ${pick.company} - ${pick.firm} Upgrade

${pick.firm} upgraded to ${pick.toRating || 'Buy'} ${pick.priceTarget ? 'with $' + pick.priceTarget + ' target' : ''}. As covered in Analyst Arena, "${pick.note || ANALYST_QUOTES.bullish[0]}." Upgrades from major firms often precede institutional accumulation. ${pick.prevPriceTarget ? `PT raised from $${pick.prevPriceTarget} to $${pick.priceTarget}, a ${((pick.priceTarget / pick.prevPriceTarget - 1) * 100).toFixed(0)}% increase in conviction.` : ''}

Setup:
Entry, Current levels around $${price.toFixed(0)}
Target, $${target.toFixed(0)} (+${upside}%)
Stop, $${stop.toFixed(0)} (-5%)
Timeframe, 3-5 weeks
Conviction, High

`;
      } else if (pick.type === 'ptRaise') {
        return `${pick.ticker} - ${pick.company} - Price Target Increase

${pick.catalyst}. The reasoning, "${pick.note || ANALYST_QUOTES.bullish[2]}." PT raises often cluster - watch for other firms to follow with similar increases.

Setup:
Entry, Current levels around $${price.toFixed(0)}
Target, $${target.toFixed(0)} (+${upside}%)
Stop, $${stop.toFixed(0)} (-5%)
Timeframe, 4-6 weeks
Conviction, Medium

`;
      } else if (pick.type === 'options') {
        return `${pick.ticker} - ${pick.company} - Unusual Options Activity

Unusual options activity detected: ${pick.catalyst}. Smart money is positioning for upside - ${pick.strike ? `$${pick.strike} calls` : 'bullish flow'} ${pick.expiry ? `expiring ${pick.expiry}` : ''} suggests conviction in near-term move. Options flow often precedes stock moves by days to weeks.

Setup:
Entry, Current levels
Target, Watch options strike for magnet effect
Stop, -5% from entry
Timeframe, Aligned with options expiry
Conviction, Medium

`;
      } else {
        return `${pick.ticker} - ${pick.company} - Post-Earnings Setup

${pick.catalyst}. Post-earnings setups offer defined entry points - the reaction tells you what the market thinks. Gap-and-go or gap-fill both tradeable with proper risk management.

Setup:
Entry, Current levels or on pullback to support
Target, +10-15% from entry
Stop, Below earnings gap support (-5-6%)
Timeframe, 2-4 weeks
Conviction, Medium

`;
      }
    }).join('') : `NVDA - NVIDIA Corporation - AI Infrastructure Leader

NVIDIA remains the centerpiece of the AI infrastructure story. As highlighted in Analyst Arena, multiple firms maintain bullish stance with the street consensus pointing to continued datacenter GPU demand through ${dates.year}. The $200 level is key support - as long as it holds, trend favors continuation.

Setup:
Entry, $185-195 zone (current consolidation)
Target, $250 (conservative) or $300 (street high)
Stop, $170 (-10%)
Timeframe, 3-6 months
Conviction, High

AVGO - Broadcom Inc. - AI Networking Opportunity

As noted in Analyst Arena, Oppenheimer raised PT to $435 citing underappreciated AI networking opportunity. The custom ASIC business is inflecting with hyperscalers choosing Broadcom for specialized chips. Consolidation near highs is bullish pattern.

Setup:
Entry, Current levels around $385
Target, $435 (+13%)
Stop, $360 (-6%)
Timeframe, 4-6 weeks
Conviction, Medium

ULTA - Ulta Beauty - Consumer Strength Play

JP Morgan raised PT to $647 on strong holiday expectations. As discussed in Tactical Corner, the consumer remains healthy at the high end and beauty category shows resilience. The setup aligns with the consumer strength theme.

Setup:
Entry, Current levels
Target, $550 (+12% conservative)
Stop, $465 (-5%)
Timeframe, 6-8 weeks
Conviction, Medium`,

    // ========================================
    // WEEK AHEAD
    // ========================================
    weekAhead: `Events This Week

${economicCalendar?.thisWeek?.slice(0, 8).map(evt => `${evt.date?.split('-').slice(1).join('/')}
- Economic data at ${evt.time || 'TBA'} - ${evt.event}, Previous ${evt.previous || 'N/A'} | Expected ${evt.forecast || 'TBA'}${evt.importance === 'high' ? ' - HIGH IMPACT' : ''}
`).join('\n') || `${dates.nextDay1}
- Economic data at 10:00 - Factory Orders MoM, Previous -0.5% | Expected 0.1%

${dates.nextDay2}
- Economic data at 08:30 - Trade Balance, Previous -$73.8B | Expected -$75.0B
- Economic data at 10:00 - JOLTS Job Openings, Previous 7.74M | Expected 7.70M

${dates.nextDay3}
- Economic data at 14:00 - FOMC Minutes

${dates.nextDay4}
- Economic data at 08:30 - Nonfarm Payrolls, Previous 227K | Expected 175K - HIGH IMPACT
- Economic data at 08:30 - Unemployment Rate, Previous 4.2% | Expected 4.2%`}

Earnings Calendar Highlights

${newsData?.earnings?.filter(e => new Date(e.date) > new Date()).slice(0, 6).map(e => `- ${e.ticker} - ${e.company || tickerToCompanyName(e.ticker)}, ${e.date} ${e.time === 'BMO' ? 'BMO' : e.time === 'AMC' ? 'AMC' : ''}
  ${e.epsEst ? `EPS Est $${e.epsEst}` : ''} ${e.revEst ? `Rev Est $${e.revEst}B` : ''}
`).join('\n') || `- ${dates.earningsSeasonStart} - JPM, WFC, GS (BMO) - Bank earnings kick off Q${dates.quarter} season
- ${dates.formatShortDate(new Date(dates.today.getTime() + 86400000 * 2))} - BAC, MS, UNH, TSM (BMO)
- ${dates.formatShortDate(new Date(dates.today.getTime() + 86400000 * 7))} - NFLX (AMC) - Streaming bellwether`}

Key Themes to Watch

1. Employment Data - NFP is THE event.

Above 200K pushes rate cuts out. Below 150K and bonds rally hard. The goldilocks zone is 160-190K.

2. FOMC Minutes - Last detailed Fed communication before blackout.

Any hawkish surprise creates vol. Market has priced in a dovish path.

3. Bank Earnings - JPM, GS, BAC set the tone for Q${dates.quarter} earnings season.

Credit quality and NII guidance are the tells.

4. Macro Data - Key releases this week will shape near-term direction.

Watch for announcements that move semis and tech.`
  };
  
  return fallbacks[sectionKey] || 'Section content pending data availability.';
}

// ============================================================================
// EXPORTS
// ============================================================================
export default {
  AGENT_PHASES,
  SECTION_PROMPTS,
  QA_PROMPT,
  runAgent,
  runQAEditor,
  runPhase,
};