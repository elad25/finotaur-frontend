// ==========================================
// Newsletter API Routes - v9.0 (Unified System)
// ==========================================
// 🎨 v9.0 CHANGES:
// - REMOVED: agentWorkflow.js dependency
// - UPDATED: Uses unified system (workflow.js, data-service.js)
// - UPDATED: Section structure to match Meida Pnim format
// - CLEANED: Removed all legacy imports
// ==========================================

import { Router } from 'express';
import { createClient } from '@supabase/supabase-js';
import { Resend } from 'resend';

// ============================================================================
// IMPORT FROM UNIFIED SYSTEM (replaces agentWorkflow)
// ============================================================================
import {
  runFullWorkflow,
  runQuickWorkflow,
  getWorkflowStatus,
  resetStatus,
} from './workflow.js';

import {
  fetchAllMarketData,
  fetchNewsAndEarnings,
  fetchAnalystActions,
  fetchOptionsFlow,
  fetchFedContext,
  fetchEconomicCalendar,
  fetchAllLiquidityData,
  buildLockedPrices,
} from './data-service.js';

import { generateIntelligenceReportPDFBuffer } from './pdf-generator.js';

import { VERSION, SECTIONS } from './config.js';

const router = Router();

// ============================================================================
// WORKFLOW STATUS EXPORT (for backward compatibility)
// ============================================================================
export { getWorkflowStatus };
export const workflowStatus = { isRunning: false }; // Legacy compatibility

// ============================================================================
// IN-MEMORY STATE FOR GENERATION TRACKING
// ============================================================================
const generationState = {
  status: 'idle',
  startedAt: null,
  completedAt: null,
  error: null,
  report: null,
  qaScore: null,
  qaPassed: null,
  duration: null,
  dataStats: null,
  progress: 0,
  currentPhase: '',
  currentStep: '',
  currentAgent: null,
  mode: 'DAILY',
  regimeStatus: null,
  story: null,
  charts: null,
  sectionCharts: null,
  pdfBuffer: null,
  pdfPath: null,
};

const REPORT_EXPIRY_MS = 4 * 60 * 60 * 1000;

// ============================================================================
// CLIENTS
// ============================================================================
function getSupabase() {
  return createClient(
    process.env.SUPABASE_URL || '',
    process.env.SUPABASE_SERVICE_ROLE_KEY || ''
  );
}

function getResend() {
  return new Resend(process.env.RESEND_API_KEY || '');
}

// ============================================================================
// PROCESSOR INFO (v9.0 Unified)
// ============================================================================
const PROCESSOR_INFO = {
  version: 'v9.0',
  type: 'unified-system',
  agentCount: 25,
  phases: 6,
  standard: 'Meida Pnim Professional Design',
  targetScore: '98+/100',
  pdfEngine: 'PDFKit v4',
  designFeatures: [
    'Meida Pnim Layout',
    'Black + Gold Theme',
    'Story-First Narrative',
    'Professional Typography',
  ],
  features: [
    '6-Phase Architecture',
    '25 Specialized AI Agents',
    'Unified Data Pipeline',
    'Professional PDF Design',
    'Clean Email Template',
    'Subscription Management',
  ],
};

// ============================================================================
// SECTION ICONS (v9.0 - Meida Pnim Structure)
// ============================================================================
const SECTION_ICONS = {
  'market-overview': '',
  'whats-hot': '',
  'whats-hot-today': '',
  'macro-arena': '',
  'the-macro-arena': '',
  'analyst-arena': '',
  'news-catalysts': '',
  'news-and-catalysts': '',
  'tactical-corner': '',
  'the-tactical-corner': '',
  'focus-stocks': '',
  'trading-plan': '',
  'default': '',
};

// ============================================================================
// FETCH ALL MARKET DATA (Unified version)
// ============================================================================
export async function fetchMarketData() {
  console.log('\n📊 Fetching all market data for report...');
  
  try {
    // Fetch core market data
    const { marketData, priceMap } = await fetchAllMarketData();
    
    // Build locked prices
    const lockedPrices = buildLockedPrices(marketData);
    
    // Fetch extended data in parallel
    const [newsAndEarnings, analystData, optionsFlow, fedContext, economicCalendar] = await Promise.all([
      fetchNewsAndEarnings().catch(e => { console.warn('News fetch error:', e.message); return {}; }),
      fetchAnalystActions().catch(e => { console.warn('Analyst fetch error:', e.message); return []; }),
      fetchOptionsFlow().catch(e => { console.warn('Options fetch error:', e.message); return { layer1: [], summary: {} }; }),
      fetchFedContext().catch(e => { console.warn('Fed fetch error:', e.message); return {}; }),
      fetchEconomicCalendar().catch(e => { console.warn('Calendar fetch error:', e.message); return []; }),
    ]);
    
    // Fetch liquidity data for key symbols
    const keySymbols = ['SPY', 'QQQ', 'IWM', 'NVDA', 'TSLA', 'AAPL', 'MSFT'];
    const liquidityData = await fetchAllLiquidityData(keySymbols, priceMap).catch(e => {
      console.warn('Liquidity fetch error:', e.message);
      return {};
    });
    
    return {
      marketData,
      priceMap,
      lockedPrices,
      optionsFlow,
      analystData,
      newsData: newsAndEarnings,
      liquidityData,
      fedContext,
      events: economicCalendar,
      fetchedAt: new Date().toISOString(),
    };
  } catch (error) {
    console.error('❌ Market data fetch error:', error);
    throw error;
  }
}

// ============================================================================
// RUN AGENT WORKFLOW (Unified version - replaces agentWorkflow.js)
// ============================================================================
export async function runAgentWorkflow(marketData, mode = 'DAILY') {
  console.log('\n🚀 Starting Unified Workflow v9.0...');
  console.log(`   Mode: ${mode}`);
  
  const startTime = Date.now();
  
  try {
    // Run the full unified workflow
    const result = await runFullWorkflow({
      marketData: marketData.marketData,
      optionsFlow: marketData.optionsFlow,
      analystData: marketData.analystData,
      newsData: marketData.newsData,
      liquidityData: marketData.liquidityData,
      fedContext: marketData.fedContext,
      events: marketData.events,
    });
    
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    
    if (result.success) {
      console.log(`\n✅ Workflow complete in ${elapsed}s`);
      console.log(`   QA Score: ${result.qaScore}/100`);
      
      return {
        success: true,
        report: result.report,
        qaScore: result.qaScore,
        qaPassed: result.qaScore >= 85,
        duration: `${elapsed}s`,
        story: result.story,
        metadata: result.metadata,
        validation: result.validation,
        regimeStatus: result.story?.marketRegime || null,
        // v21.0: Pass lockedPrices and context for PDF table generation
        lockedPrices: marketData.lockedPrices,
        context: {
          lockedPrices: marketData.lockedPrices,
          analystData: { actions: marketData.analystData || [] },
          economicCalendar: { thisWeek: marketData.events || [] },
          earningsData: marketData.newsData?.earnings || [],
          fedContext: marketData.fedContext,
        },
        signals: {
          bullishFlow: marketData.optionsFlow?.layer1?.filter(f => f.sentiment === 'BULLISH') || [],
          bearishFlow: marketData.optionsFlow?.layer1?.filter(f => f.sentiment === 'BEARISH') || [],
          smartMoney: marketData.optionsFlow?.layer1?.slice(0, 5) || [],
        },
      };
    } else {
      console.error('❌ Workflow failed:', result.error);
      return {
        success: false,
        error: result.error,
        duration: `${elapsed}s`,
      };
    }
  } catch (error) {
    console.error('❌ Workflow error:', error);
    return {
      success: false,
      error: error.message,
      stack: error.stack,
    };
  }
}

// ============================================================================
// EXTRACT SECTIONS FROM REPORT
// ============================================================================
function extractSections(report) {
  if (!report) return [];

  const sections = [];
  const lines = report.split('\n');
  let currentSection = null;
  let currentContent = [];

  const knownSections = [
    'MARKET OVERVIEW',
    'WHAT\'S HOT', 'WHATS HOT', 'WHAT\'S HOT TODAY', 'WHATS HOT TODAY',
    'MACRO ARENA', 'THE MACRO ARENA',
    'ANALYST ARENA',
    'NEWS & CATALYSTS', 'NEWS AND CATALYSTS', 'NEWS CATALYSTS',
    'TACTICAL CORNER', 'THE TACTICAL CORNER',
    'FOCUS STOCKS',
    'TRADING PLAN',
    'IMPORTANT DISCLAIMER',
  ];

  const isSeparator = (line) => {
    const trimmed = line.trim();
    return trimmed.length > 10 && /^[═─\-]+$/.test(trimmed);
  };

  const cleanLine = (line) => {
    return line.replace(/[📊📖💰🌍🌏📚🎯🏛️⬆️⬇️📅📈🔗⚡📉📌⚠️🎰💼✅❌🔥💹🏗️📡📰🔄📐🔍🔧🎨📦🏆⭐\*]/g, '').trim();
  };

  const isKnownSection = (line) => {
    const cleaned = cleanLine(line).toUpperCase();
    return knownSections.some(s => cleaned === s || cleaned.startsWith(s));
  };

  for (const line of lines) {
    const trimmedLine = line.trim();
    if (!trimmedLine || isSeparator(line)) continue;

    const cleaned = cleanLine(trimmedLine);

    const isHeader = isKnownSection(trimmedLine) ||
      (cleaned.length > 3 && cleaned.length < 40 &&
       cleaned === cleaned.toUpperCase() &&
       /^[A-Z][A-Z\s&\-']+$/.test(cleaned));

    if (isHeader) {
      if (currentSection && currentContent.length > 0) {
        const content = currentContent.join('\n').trim();
        if (content.length > 10) {
          const sectionId = currentSection.toLowerCase().replace(/[^a-z0-9]+/g, '-');
          sections.push({
            id: sectionId,
            title: currentSection,
            content: content,
            icon: SECTION_ICONS[sectionId] || SECTION_ICONS.default,
          });
        }
      }
      currentSection = cleaned;
      currentContent = [];
    } else if (currentSection) {
      if (!trimmedLine.includes('FINOTAUR INTELLIGENCE REPORT') &&
          !trimmedLine.includes('INSTITUTIONAL EDITION') &&
          !trimmedLine.match(/^v\d+/)) {
        currentContent.push(line);
      }
    }
  }

  if (currentSection && currentContent.length > 0) {
    const content = currentContent.join('\n').trim();
    if (content.length > 10) {
      const sectionId = currentSection.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      sections.push({
        id: sectionId,
        title: currentSection,
        content: content,
        icon: SECTION_ICONS[sectionId] || SECTION_ICONS.default,
      });
    }
  }

  console.log(`Extracted ${sections.length} sections from report`);
  return sections;
}

// ============================================================================
// GENERATE SUBJECT LINE
// ============================================================================
function generateSubject(report, mode = 'DAILY', story = null) {
  const date = new Date().toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    timeZone: 'America/New_York',
  });

  const dayType = mode === 'WEEKLY' ? 'Weekly' : 'Daily';
  return `Finotaur ${dayType} Report | ${date}`;
}

// ============================================================================
// GENERATE PREHEADER
// ============================================================================
function generatePreheader(report, story = null) {
  return 'Your market intelligence report is ready';
}

// ============================================================================
// MINIMALIST EMAIL HTML
// ============================================================================
function generateNewsletterHtml(report, subject, preheader, adminNote = null, unsubscribeUrl = null, story = null, hasPdfAttachment = false, mode = 'DAILY') {
  const date = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: 'America/New_York',
  });

  const dayType = mode === 'WEEKLY' ? 'WEEKLY' : 'DAILY';

  const adminNoteHtml = adminNote
    ? `
    <tr>
      <td style="padding: 24px 32px 0;">
        <div style="background: linear-gradient(135deg, #C9A646 0%, #a08030 100%); border-radius: 8px; padding: 20px;">
          <p style="color: #000; font-weight: 600; font-size: 13px; margin: 0 0 8px 0; text-transform: uppercase; letter-spacing: 1px;">Message from Finotaur</p>
          <p style="color: #000; margin: 0; font-size: 14px; line-height: 1.6;">${adminNote}</p>
        </div>
      </td>
    </tr>
  `
    : '';

  const unsubscribeHtml = unsubscribeUrl
    ? `<p style="margin: 16px 0 0 0;">
        <a href="${unsubscribeUrl}" style="color: #666; text-decoration: underline; font-size: 11px;">Unsubscribe</a>
       </p>`
    : '';

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>${subject}</title>
  <meta name="description" content="${preheader}">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    body { margin: 0; padding: 0; background-color: #080812; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    table { border-collapse: collapse; width: 100%; }
    @media only screen and (max-width: 600px) {
      .container { width: 100% !important; padding: 12px !important; }
      .content { padding: 20px !important; }
      .header-title { font-size: 32px !important; }
    }
  </style>
</head>
<body style="margin: 0; padding: 0; background-color: #080812;">
  <div style="display: none; max-height: 0; overflow: hidden;">${preheader}</div>
  
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #080812;">
    <tr>
      <td align="center" style="padding: 40px 16px;">
        <table role="presentation" class="container" width="600" cellpadding="0" cellspacing="0" style="background-color: #0d0d18; border-radius: 12px; overflow: hidden; border: 1px solid #1a1a2e;">
          
          <tr>
            <td style="background-color: #080812; padding: 60px 32px; text-align: center; border-bottom: 1px solid #1a1a2e;">
              <div style="display: inline-block; background: linear-gradient(135deg, #C9A646 0%, #a08030 100%); padding: 14px 32px; border-radius: 6px; margin-bottom: 32px;">
                <span style="color: #000; font-size: 28px; font-weight: 800; letter-spacing: 3px;">FINOTAUR</span>
              </div>
              <h1 class="header-title" style="color: #ffffff; font-size: 36px; font-weight: 300; margin: 0 0 16px 0; letter-spacing: 4px;">
                ${dayType} REPORT
              </h1>
              <p style="color: #C9A646; font-size: 15px; margin: 0; font-weight: 500; letter-spacing: 1px;">${date}</p>
            </td>
          </tr>
          
          ${adminNoteHtml}
          
          <tr>
            <td style="padding: 40px 32px; text-align: center;">
              <p style="color: #C9A646; font-size: 11px; margin: 0; line-height: 1.8; text-align: justify;">
                <strong>DISCLAIMER:</strong> This report is provided for educational and informational purposes only and does not constitute investment advice, financial advice, trading advice, or any other type of advice. Finotaur is not a registered investment advisor, broker-dealer, or financial planner. The information contained herein should not be construed as a recommendation to buy, sell, or hold any security or investment. All investments involve risk, including the potential loss of principal. Past performance is not indicative of future results. Any investment decisions made based on this report are solely at your own risk and responsibility. Finotaur, its affiliates, and their respective officers, directors, employees, and agents shall not be held liable for any losses, damages, or costs arising from reliance on this information. You should consult with a qualified financial professional before making any investment decisions. By reading this report, you acknowledge and accept these terms.
              </p>
            </td>
          </tr>
          
          <tr>
            <td style="background-color: #080812; padding: 24px 32px; text-align: center; border-top: 1px solid #1a1a2e;">
              <p style="color: #444; font-size: 10px; margin: 0;">
                © ${new Date().getFullYear()} Finotaur. All rights reserved.
              </p>
              <p style="margin: 12px 0 0 0;">
                <a href="https://finotaur.com" style="color: #C9A646; text-decoration: none; font-size: 12px; font-weight: 500;">finotaur.com</a>
              </p>
              ${unsubscribeHtml}
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
function isReportExpired() {
  if (!generationState.completedAt) return true;
  const elapsed = Date.now() - new Date(generationState.completedAt).getTime();
  return elapsed > REPORT_EXPIRY_MS;
}

function resetGenerationState() {
  generationState.status = 'idle';
  generationState.startedAt = null;
  generationState.completedAt = null;
  generationState.error = null;
  generationState.report = null;
  generationState.qaScore = null;
  generationState.qaPassed = null;
  generationState.duration = null;
  generationState.dataStats = null;
  generationState.progress = 0;
  generationState.currentPhase = '';
  generationState.currentStep = '';
  generationState.currentAgent = null;
  generationState.regimeStatus = null;
  generationState.story = null;
  generationState.charts = null;
  generationState.sectionCharts = null;
  generationState.pdfBuffer = null;
  generationState.pdfPath = null;
}

// ============================================================================
// GENERATE REPORT WITH PDF
// ============================================================================
async function generateAgentReportWithCharts(mode = 'DAILY') {
  console.log('Starting unified workflow v9.0...');
  const startTime = Date.now();

  try {
    console.log('Phase 1: Fetching market data...');
    generationState.progress = 5;
    generationState.currentPhase = 'DATA_FETCH';
    generationState.currentStep = 'Fetching market data';
    
    const marketData = await fetchMarketData();

    console.log('Phase 2: Running agents...');
    generationState.progress = 15;
    generationState.currentPhase = 'PHASE_2';
    generationState.currentStep = 'Running AI Agents';

    const agentResult = await runAgentWorkflow(marketData, mode);

    if (!agentResult.success || !agentResult.report) {
      throw new Error('Agent workflow failed to generate report');
    }

    console.log('Phase 3: Generating PDF...');
    generationState.progress = 92;
    generationState.currentPhase = 'PDF';
    generationState.currentStep = 'Creating PDF';

    let pdfBuffer = null;
    try {
      // v21.0: Pass lockedPrices and context for dynamic table generation
      pdfBuffer = await generateIntelligenceReportPDFBuffer(
        agentResult.report,
        null,
        {
          qaScore: agentResult.qaScore,
          story: agentResult.story,
          lockedPrices: agentResult.lockedPrices,
          context: agentResult.context,
        }
      );
    } catch (pdfError) {
      console.warn('PDF generation failed:', pdfError.message);
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(1);

    return {
      report: agentResult.report,
      qaScore: agentResult.qaScore,
      qaPassed: agentResult.qaPassed,
      duration,
      story: agentResult.story,
      charts: {},
      sectionCharts: {},
      themes: [],
      pdfBuffer: pdfBuffer,
      dataStats: {
        uoaFlows: agentResult.signals?.bullishFlow?.length + agentResult.signals?.bearishFlow?.length || 0,
        smartMoneyFlows: agentResult.signals?.smartMoney?.length || 0,
        chartCount: 0,
        hasPdf: !!pdfBuffer,
      },
      regimeStatus: agentResult.regimeStatus,
    };
  } catch (error) {
    console.error('Workflow error:', error);
    throw error;
  }
}

async function generateAgentReportBackground(mode = 'DAILY') {
  console.log('Starting background workflow v9.0...');
  const startTime = Date.now();

  generationState.status = 'generating';
  generationState.startedAt = new Date().toISOString();
  generationState.mode = mode;
  generationState.progress = 0;
  generationState.currentPhase = 'INIT';
  generationState.currentStep = 'Starting workflow';
  generationState.error = null;

  try {
    const result = await generateAgentReportWithCharts(mode);
    const duration = ((Date.now() - startTime) / 1000).toFixed(1);

    generationState.status = 'completed';
    generationState.completedAt = new Date().toISOString();
    generationState.report = result.report;
    generationState.qaScore = result.qaScore;
    generationState.qaPassed = result.qaPassed;
    generationState.duration = `${duration}s`;
    generationState.story = result.story;
    generationState.charts = result.charts;
    generationState.sectionCharts = result.sectionCharts;
    generationState.pdfBuffer = result.pdfBuffer;
    generationState.dataStats = result.dataStats;
    generationState.progress = 100;
    generationState.currentPhase = 'COMPLETE';
    generationState.currentStep = 'Report finished';
    generationState.regimeStatus = result.regimeStatus;

    try {
      const supabase = getSupabase();
      const subject = generateSubject(result.report, mode, result.story);
      const preheader = generatePreheader(result.report, result.story);
      const sections = extractSections(result.report);
      const html = generateNewsletterHtml(result.report, subject, preheader, null, null, result.story, !!result.pdfBuffer, mode);

      await supabase.from('newsletters').insert({
        subject,
        preheader,
        content: sections,
        html_content: html,
        raw_markdown: result.report,
        status: 'draft',
        audience_type: 'preview',
        qa_score: result.qaScore,
        processor_version: 'v9.0-unified',
        metadata: {
          hasPdf: !!result.pdfBuffer,
          sectionCount: sections.length,
        },
      });
    } catch (dbError) {
      console.warn('Failed to save to database:', dbError.message);
    }

    return result;
  } catch (error) {
    console.error('Agent workflow error:', error);
    generationState.status = 'error';
    generationState.error = error.message;
    generationState.progress = 0;
    generationState.currentPhase = 'ERROR';
    generationState.currentStep = 'Workflow failed';
    throw error;
  }
}

// ==========================================
// API ROUTES
// ==========================================

router.get('/workflow-progress', async (req, res) => {
  try {
    const workflowData = getWorkflowStatus();
    
    const elapsed = generationState.startedAt 
      ? Math.floor((Date.now() - new Date(generationState.startedAt).getTime()) / 1000)
      : 0;
    
    res.json({
      success: true,
      isRunning: generationState.status === 'generating',
      currentPhase: workflowData.phase || generationState.currentPhase,
      currentStep: workflowData.message || generationState.currentStep,
      currentAgent: generationState.currentAgent,
      progress: workflowData.progress || generationState.progress,
      elapsedSeconds: elapsed,
      elapsedFormatted: `${Math.floor(elapsed / 60)}:${(elapsed % 60).toString().padStart(2, '0')}`,
      estimatedRemaining: Math.max(0, 180 - elapsed),
      error: generationState.error,
      hasPdf: !!generationState.pdfBuffer,
      ts: Date.now(),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e?.message });
  }
});

router.get('/status', async (req, res) => {
  try {
    const isExpired = isReportExpired();
    
    res.json({
      success: true,
      data: {
        status: generationState.status,
        startedAt: generationState.startedAt,
        completedAt: generationState.completedAt,
        error: generationState.error,
        qaScore: generationState.qaScore,
        qaPassed: generationState.qaPassed,
        duration: generationState.duration,
        progress: generationState.progress,
        currentPhase: generationState.currentPhase,
        currentStep: generationState.currentStep,
        mode: generationState.mode,
        hasReport: !!generationState.report,
        hasStory: !!generationState.story,
        hasPdf: !!generationState.pdfBuffer,
        isExpired,
        regimeStatus: generationState.regimeStatus,
        processorInfo: PROCESSOR_INFO,
      },
      ts: Date.now(),
    });
  } catch (e) {
    res.status(500).json({ error: e?.message });
  }
});

router.post('/generate', async (req, res) => {
  try {
    const { force = false, mode = 'DAILY' } = req.body;

    if (generationState.status === 'generating') {
      return res.json({
        success: true,
        data: {
          status: 'generating',
          startedAt: generationState.startedAt,
          progress: generationState.progress,
          currentPhase: generationState.currentPhase,
          currentStep: generationState.currentStep,
          message: 'Generation already in progress',
        },
        ts: Date.now(),
      });
    }

    if (!force && generationState.status === 'completed' && !isReportExpired()) {
      return res.json({
        success: true,
        data: {
          status: 'completed',
          completedAt: generationState.completedAt,
          qaScore: generationState.qaScore,
          hasReport: true,
          hasPdf: !!generationState.pdfBuffer,
          message: 'Report already available',
        },
        ts: Date.now(),
      });
    }

    resetGenerationState();
    generateAgentReportBackground(mode).catch((err) => {
      console.error('Background generation failed:', err);
    });

    res.json({
      success: true,
      data: {
        status: 'generating',
        startedAt: generationState.startedAt,
        message: 'Generation started',
        estimatedTime: '~3-5 minutes',
        version: 'v9.0',
      },
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Generate start failed:', e);
    res.status(500).json({ error: e?.message || 'generate_start_failed' });
  }
});

router.get('/preview', async (req, res) => {
  try {
    const { force } = req.query;

    if (force === 'true' && generationState.status !== 'generating') {
      resetGenerationState();
      generateAgentReportBackground('DAILY').catch((err) => {
        console.error('Background generation failed:', err);
      });

      return res.json({
        success: true,
        data: {
          status: 'generating',
          startedAt: generationState.startedAt,
          message: 'Generation started',
        },
        ts: Date.now(),
      });
    }

    if (generationState.status === 'generating') {
      return res.json({
        success: true,
        data: {
          status: 'generating',
          startedAt: generationState.startedAt,
          progress: generationState.progress,
          currentPhase: generationState.currentPhase,
          currentStep: generationState.currentStep,
        },
        ts: Date.now(),
      });
    }

    if (generationState.status === 'completed' && generationState.report && !isReportExpired()) {
      const report = generationState.report;
      const story = generationState.story;
      const mode = generationState.mode;
      const subject = generateSubject(report, mode, story);
      const preheader = generatePreheader(report, story);
      const sections = extractSections(report);
      const hasPdf = !!generationState.pdfBuffer;
      const html = generateNewsletterHtml(report, subject, preheader, null, null, story, hasPdf, mode);

      return res.json({
        success: true,
        data: {
          subject,
          preheader,
          sections,
          html,
          markdown: report,
          generatedAt: generationState.completedAt,
          cached: false,
          story,
          hasPdf: hasPdf,
          processorInfo: {
            ...PROCESSOR_INFO,
            qaScore: generationState.qaScore,
            qaPassed: generationState.qaPassed,
            duration: generationState.duration,
            regimeStatus: generationState.regimeStatus,
          },
        },
        ts: Date.now(),
      });
    }

    const supabase = getSupabase();
    const fourHoursAgo = new Date(Date.now() - REPORT_EXPIRY_MS);

    const { data: recent } = await supabase
      .from('newsletters')
      .select('*')
      .gte('created_at', fourHoursAgo.toISOString())
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (recent) {
      return res.json({
        success: true,
        data: {
          subject: recent.subject,
          preheader: recent.preheader,
          sections: recent.content,
          html: recent.html_content,
          markdown: recent.raw_markdown,
          generatedAt: recent.created_at,
          cached: true,
          hasPdf: recent.metadata?.hasPdf || false,
          processorInfo: {
            ...PROCESSOR_INFO,
            qaScore: recent.qa_score,
          },
        },
        ts: Date.now(),
      });
    }

    res.json({
      success: true,
      data: null,
      message: 'No report available. Use POST /generate to create one.',
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Preview failed:', e);
    res.status(500).json({ error: e?.message || 'preview_failed' });
  }
});

router.get('/pdf', async (req, res) => {
  try {
    if (!generationState.pdfBuffer) {
      return res.status(404).json({ 
        success: false, 
        error: 'No PDF available. Generate a report first.' 
      });
    }

    const date = new Date().toISOString().split('T')[0];
    const filename = `finotaur-report-${date}.pdf`;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', generationState.pdfBuffer.length);
    
    res.send(generationState.pdfBuffer);
  } catch (e) {
    console.error('PDF download failed:', e);
    res.status(500).json({ error: e?.message || 'pdf_download_failed' });
  }
});

router.post('/test', async (req, res) => {
  try {
    const { email, adminNote = null, mode = 'DAILY', includePdf = true } = req.body;

    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: 'valid_email_required' });
    }

    let report, qaScore, dataStats, story, pdfBuffer;

    if (generationState.status === 'completed' && generationState.report && !isReportExpired()) {
      report = generationState.report;
      qaScore = generationState.qaScore;
      dataStats = generationState.dataStats;
      story = generationState.story;
      pdfBuffer = generationState.pdfBuffer;
    } else {
      const result = await generateAgentReportWithCharts(mode);
      report = result.report;
      qaScore = result.qaScore;
      dataStats = result.dataStats;
      story = result.story;
      pdfBuffer = result.pdfBuffer;
    }

    const subject = `[TEST] ${generateSubject(report, mode, story)}`;
    const preheader = generatePreheader(report, story);
    const hasPdf = includePdf && pdfBuffer;
    const html = generateNewsletterHtml(report, subject, preheader, adminNote, null, story, hasPdf, mode);

    const resend = getResend();
    
    const emailOptions = {
      from: `${process.env.NEWSLETTER_FROM_NAME || 'Finotaur'} <${process.env.NEWSLETTER_FROM_EMAIL || 'newsletter@finotaur.com'}>`,
      to: email,
      subject,
      html,
    };

    if (hasPdf) {
      const date = new Date().toISOString().split('T')[0];
      emailOptions.attachments = [{
        filename: `finotaur-report-${date}.pdf`,
        content: pdfBuffer,
      }];
    }

    const { error: sendError } = await resend.emails.send(emailOptions);
    if (sendError) throw sendError;

    res.json({
      success: true,
      message: `Test sent to ${email}${hasPdf ? ' with PDF' : ''}`,
      qaScore,
      dataStats,
      hasPdf: !!hasPdf,
      processorInfo: PROCESSOR_INFO,
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Test failed:', e);
    res.status(500).json({ error: e?.message || 'test_failed' });
  }
});

router.post('/send', async (req, res) => {
  try {
    const {
      audienceType = 'custom',
      recipientIds = [],
      newsletterId = null,
      segments = [],
      adminNote = null,
      mode = 'DAILY',
      includePdf = true,
    } = req.body;

    const supabase = getSupabase();
    const resend = getResend();

    let recipients = [];

    if (audienceType === 'custom' && recipientIds.length > 0) {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, display_name, newsletter_unsubscribe_token')
        .in('id', recipientIds)
        .not('email', 'is', null);
      if (error) throw error;
      recipients = data || [];
    } else if (audienceType === 'premium') {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, display_name, newsletter_unsubscribe_token')
        .eq('account_type', 'premium')
        .eq('newsletter_enabled', true)
        .not('email', 'is', null);
      if (error) throw error;
      recipients = data || [];
    } else if (audienceType === 'enabled') {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, display_name, newsletter_unsubscribe_token')
        .eq('newsletter_enabled', true)
        .not('email', 'is', null);
      if (error) throw error;
      recipients = data || [];
    }

    if (recipients.length === 0) {
      return res.status(400).json({ success: false, error: 'no_recipients' });
    }

    let report, subject, preheader, qaScore, story, pdfBuffer;

    if (newsletterId) {
      const { data: existing, error: fetchError } = await supabase
        .from('newsletters')
        .select('*')
        .eq('id', newsletterId)
        .single();
      if (fetchError || !existing) throw new Error('Newsletter not found');
      report = existing.raw_markdown;
      subject = existing.subject;
      preheader = existing.preheader;
      qaScore = existing.qa_score;
      
      if (includePdf) {
        try {
          pdfBuffer = await generateIntelligenceReportPDFBuffer(report, null, {
            qaScore: qaScore,
            story: null,
          });
        } catch (pdfErr) {
          console.warn('PDF generation failed for existing newsletter:', pdfErr.message);
        }
      }
    } else if (generationState.status === 'completed' && generationState.report && !isReportExpired()) {
      report = generationState.report;
      story = generationState.story;
      subject = generateSubject(report, mode, story);
      preheader = generatePreheader(report, story);
      qaScore = generationState.qaScore;
      pdfBuffer = generationState.pdfBuffer;
    } else {
      const result = await generateAgentReportWithCharts(mode);
      report = result.report;
      story = result.story;
      subject = generateSubject(report, mode, story);
      preheader = generatePreheader(report, story);
      qaScore = result.qaScore;
      pdfBuffer = result.pdfBuffer;
    }

    const hasPdf = includePdf && pdfBuffer;
    const sections = extractSections(report);
    const baseHtml = generateNewsletterHtml(report, subject, preheader, adminNote, null, story, hasPdf, mode);

    const { data: record, error: saveError } = await supabase
      .from('newsletters')
      .insert({
        subject,
        preheader,
        content: sections,
        html_content: baseHtml,
        raw_markdown: report,
        status: 'sending',
        audience_type: audienceType,
        qa_score: qaScore,
        processor_version: 'v9.0-unified',
        metadata: {
          hasPdf: hasPdf,
          sectionCount: sections.length,
        },
      })
      .select()
      .single();
    if (saveError) throw saveError;

    const date = new Date().toISOString().split('T')[0];
    const pdfAttachment = hasPdf ? [{
      filename: `finotaur-report-${date}.pdf`,
      content: pdfBuffer,
    }] : undefined;

    let sentCount = 0;
    let failedCount = 0;
    const baseUrl = process.env.BASE_URL || 'https://finotaur.com';

    for (const recipient of recipients) {
      try {
        const unsubscribeUrl = recipient.newsletter_unsubscribe_token
          ? `${baseUrl}/api/newsletter/unsubscribe/${recipient.newsletter_unsubscribe_token}`
          : null;

        const personalizedHtml = generateNewsletterHtml(report, subject, preheader, adminNote, unsubscribeUrl, story, hasPdf, mode);

        const emailOptions = {
          from: `${process.env.NEWSLETTER_FROM_NAME || 'Finotaur'} <${process.env.NEWSLETTER_FROM_EMAIL || 'newsletter@finotaur.com'}>`,
          to: recipient.email,
          subject,
          html: personalizedHtml,
        };

        if (pdfAttachment) {
          emailOptions.attachments = pdfAttachment;
        }

        await resend.emails.send(emailOptions);
        sentCount++;

        if (sentCount % 10 === 0) {
          await new Promise((r) => setTimeout(r, 1000));
        }
      } catch (emailError) {
        console.error(`Failed to send to ${recipient.email}:`, emailError.message);
        failedCount++;
      }
    }

    await supabase
      .from('newsletters')
      .update({
        status: 'sent',
        sent_at: new Date().toISOString(),
        recipient_count: recipients.length,
        sent_count: sentCount,
        failed_count: failedCount,
      })
      .eq('id', record.id);

    await supabase.from('newsletter_send_logs').insert({
      sent_at: new Date().toISOString(),
      recipient_count: sentCount,
      subject,
      segments: segments,
      admin_note: adminNote,
    });

    res.json({
      success: true,
      data: {
        newsletterId: record.id,
        subject,
        audienceType,
        recipientCount: recipients.length,
        sentCount,
        failedCount,
        sentAt: new Date().toISOString(),
        qaScore,
        hasPdf: hasPdf,
        processorInfo: PROCESSOR_INFO,
      },
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Send failed:', e);
    res.status(500).json({ error: e?.message || 'send_failed' });
  }
});

router.get('/latest', async (req, res) => {
  try {
    const supabase = getSupabase();

    const now = new Date();
    const nyDate = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const todayStart = new Date(nyDate);
    todayStart.setHours(0, 0, 0, 0);

    let { data: todayNewsletter } = await supabase
      .from('newsletters')
      .select('*')
      .gte('created_at', todayStart.toISOString())
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (!todayNewsletter) {
      const { data: latestNewsletter } = await supabase
        .from('newsletters')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      todayNewsletter = latestNewsletter;
    }

    if (!todayNewsletter) {
      return res.json({
        success: true,
        data: null,
        message: 'No newsletters found',
        ts: Date.now(),
      });
    }

    res.json({
      success: true,
      data: {
        id: todayNewsletter.id,
        subject: todayNewsletter.subject,
        preheader: todayNewsletter.preheader,
        sections: todayNewsletter.content,
        html: todayNewsletter.html_content,
        markdown: todayNewsletter.raw_markdown,
        status: todayNewsletter.status,
        sentAt: todayNewsletter.sent_at,
        recipientCount: todayNewsletter.recipient_count,
        sentCount: todayNewsletter.sent_count,
        generatedAt: todayNewsletter.created_at,
        isToday: new Date(todayNewsletter.created_at) >= todayStart,
        hasPdf: todayNewsletter.metadata?.hasPdf || false,
        processorInfo: {
          ...PROCESSOR_INFO,
          qaScore: todayNewsletter.qa_score,
        },
      },
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Latest fetch failed:', e);
    res.status(500).json({ error: e?.message || 'latest_fetch_failed' });
  }
});

router.get('/history', async (req, res) => {
  try {
    const { limit = 20, offset = 0 } = req.query;
    const supabase = getSupabase();

    const { data, error, count } = await supabase
      .from('newsletters')
      .select('id, subject, status, sent_at, recipient_count, sent_count, failed_count, audience_type, qa_score, processor_version, metadata, created_at', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1);

    if (error) throw error;

    res.json({ success: true, data, total: count, ts: Date.now() });
  } catch (e) {
    console.error('History fetch failed:', e);
    res.status(500).json({ error: e?.message || 'history_fetch_failed' });
  }
});

// ==========================================
// SUBSCRIPTION MANAGEMENT ROUTES
// ==========================================

router.post('/cancel', async (req, res) => {
  try {
    const { userId, membershipId } = req.body;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'userId required' });
    }

    console.log(`Cancelling newsletter subscription for user ${userId}`);

    const supabase = getSupabase();

    if (membershipId) {
      const whopApiKey = process.env.WHOP_API_KEY;
      
      if (whopApiKey) {
        try {
          const whopResponse = await fetch(`https://api.whop.com/api/v2/memberships/${membershipId}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${whopApiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              cancel_at_period_end: true,
            }),
          });

          if (!whopResponse.ok) {
            const errorText = await whopResponse.text();
            console.warn('Whop API cancel failed:', errorText);
          } else {
            console.log('Whop membership set to cancel at period end');
          }
        } catch (whopError) {
          console.warn('Whop API error:', whopError);
        }
      }
    }

    const { data, error } = await supabase.rpc('cancel_newsletter_subscription', {
      p_user_id: userId,
    });

    if (error) {
      console.error('Cancel RPC error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }

    console.log('Newsletter subscription cancelled:', data);

    res.json({
      success: true,
      data,
      message: 'Subscription will be cancelled at the end of the billing period',
      accessUntil: data?.access_until || null,
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Cancel failed:', e);
    res.status(500).json({ success: false, error: e?.message || 'cancel_failed' });
  }
});

router.post('/reactivate', async (req, res) => {
  try {
    const { userId, membershipId } = req.body;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'userId required' });
    }

    console.log(`Reactivating newsletter subscription for user ${userId}`);

    const supabase = getSupabase();

    if (membershipId) {
      const whopApiKey = process.env.WHOP_API_KEY;
      
      if (whopApiKey) {
        try {
          const whopResponse = await fetch(`https://api.whop.com/api/v2/memberships/${membershipId}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${whopApiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              cancel_at_period_end: false,
            }),
          });

          if (!whopResponse.ok) {
            const errorText = await whopResponse.text();
            console.warn('Whop API reactivate failed:', errorText);
          } else {
            console.log('Whop membership reactivated');
          }
        } catch (whopError) {
          console.warn('Whop API error:', whopError);
        }
      }
    }

    const { data, error } = await supabase.rpc('reactivate_newsletter_subscription', {
      p_user_id: userId,
    });

    if (error) {
      console.error('Reactivate RPC error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }

    console.log('Newsletter subscription reactivated:', data);

    res.json({
      success: true,
      data,
      message: 'Subscription reactivated successfully',
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Reactivate failed:', e);
    res.status(500).json({ success: false, error: e?.message || 'reactivate_failed' });
  }
});

router.get('/subscription-status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'userId required' });
    }

    const supabase = getSupabase();

    const { data, error } = await supabase.rpc('get_newsletter_status', {
      p_user_id: userId,
    });

    if (error) {
      console.error('Get status RPC error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }

    const status = data?.[0] || null;

    res.json({
      success: true,
      data: status,
      ts: Date.now(),
    });
  } catch (e) {
    console.error('Get status failed:', e);
    res.status(500).json({ success: false, error: e?.message || 'get_status_failed' });
  }
});

router.get('/unsubscribe/:token', async (req, res) => {
  try {
    const { token } = req.params;

    if (!token) {
      return res.status(400).send('Invalid unsubscribe link');
    }

    const supabase = getSupabase();

    const { data: user, error: findError } = await supabase
      .from('profiles')
      .select('id, email, newsletter_status')
      .eq('newsletter_unsubscribe_token', token)
      .single();

    if (findError || !user) {
      return res.status(404).send('Invalid or expired unsubscribe link');
    }

    const { error: cancelError } = await supabase.rpc('cancel_newsletter_subscription', {
      p_user_id: user.id,
    });

    if (cancelError) {
      console.error('Unsubscribe error:', cancelError);
      return res.status(500).send('Failed to unsubscribe. Please contact support.');
    }

    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Unsubscribed - Finotaur</title>
        <style>
          body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #080812; 
            color: #fff; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh;
            margin: 0;
          }
          .container { 
            text-align: center; 
            padding: 40px;
            max-width: 500px;
          }
          .logo {
            background: linear-gradient(135deg, #C9A646 0%, #a08030 100%);
            padding: 12px 28px;
            border-radius: 6px;
            display: inline-block;
            margin-bottom: 30px;
          }
          .logo span {
            color: #000;
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 3px;
          }
          h1 { color: #C9A646; margin-bottom: 16px; }
          p { color: #888; line-height: 1.6; }
          a { color: #C9A646; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="logo"><span>FINOTAUR</span></div>
          <h1>You've Been Unsubscribed</h1>
          <p>You will no longer receive the War Zone Intelligence newsletter.</p>
          <p>Your subscription will remain active until the end of your current billing period.</p>
          <p style="margin-top: 30px;">
            Changed your mind? <a href="https://finotaur.com/app/all-markets/warzone">Resubscribe here</a>
          </p>
        </div>
      </body>
      </html>
    `);
  } catch (e) {
    console.error('Unsubscribe failed:', e);
    res.status(500).send('An error occurred. Please contact support@finotaur.com');
  }
});

router.get('/debug/env', async (req, res) => {
  res.json({
    OPENAI_API_KEY: process.env.OPENAI_API_KEY ? `${process.env.OPENAI_API_KEY.slice(0, 10)}...` : 'NOT SET',
    SUPABASE_URL: process.env.SUPABASE_URL ? 'SET' : 'NOT SET',
    SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY ? 'SET' : 'NOT SET',
    RESEND_API_KEY: process.env.RESEND_API_KEY ? 'SET' : 'NOT SET',
    VERSION: VERSION,
  });
});

export default router;