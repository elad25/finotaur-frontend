// ==========================================
// FINOTAUR INTELLIGENCE PDF GENERATOR v22.0
// ==========================================
// v22.0: AGGRESSIVE TABLE CONTENT REMOVAL
//   - Tables rendered ONLY from lockedPrices data
//   - All pipe-delimited text removed from narrative content
//   - Orphaned table headers/cells stripped
//   - No duplicate table rendering
// v19.0: DIRECT DATA TABLE RENDERING
//   - Tables rendered from lockedPrices, not from content
//   - Completely bypasses text processing pipeline
//   - Clean, professional table rendering
// FIXES: 
// - v11.1: Meida Pnim Style Content Rendering
// - v11.2: CRITICAL FIX - parseContentBlocks crash on numberedList
// - v11.3: Smart quote normalization for section parsing
// - v11.6: Updated section keys to match Meida Pnim structure
// - v11.7: Inline section detection
// - v11.8: CRITICAL FIX - Smart formatting for line breaks
// - v12.0: CHARTS INTEGRATION - Added market charts to PDF
//   - Index performance chart after Global Arena
//   - Sector heatmap in Tactical Corner
//   - VIX gauge chart
// - v13.0: CRITICAL FIX - Aggressive line break insertion
//   - Force breaks before headers even without punctuation
//   - Better day header detection for Week Ahead
//   - Proper "No earnings" standalone paragraph handling
//   - Focus Corner setup block separation
// - v13.1: Text overlapping bug - heightOfString before font set
// - v13.2: CRITICAL FIX - Text overlapping SOLVED
//   - ALL render functions now use doc.y for actual position tracking
//   - Removed calculated height estimates in favor of PDFKit's cursor
//   - renderParagraph, renderNumberedList, renderStockHeader all fixed
//   - renderBoldHeader, renderDayHeader, renderThematicSubtitle fixed
//   - renderEconomicData, renderSetup fixed
// - v13.3: MARKDOWN TABLE SUPPORT
//   - Added table detection in parseContentBlocks
//   - Added renderTable function for compact PDF tables
//   - Tables used in Global Arena for market data summary
// - v13.4: TABLE PRESERVATION FIX
//   - Fixed smartSplitIntoParagraphs to preserve table formatting
//   - Tables no longer get merged into single lines
//   - Added table header line break handling in applySmartFormatting
//   - ECONOMIC CALENDAR and EARNINGS CALENDAR tables now render correctly
// - v13.5: TABLE NEWLINE FIX
//   - Added fixTableFormatting() function in cleanSectionContent
//   - Handles tables concatenated with section headers
//   - MARKET DATA SNAPSHOT header detection added
//   - Better regex for table row separation
// - v17.0: CRITICAL TABLE FIX
//   - COMPLETELY REWROTE fixTableFormatting() - previous version broke tables!
//   - Old regex was splitting table rows by inserting newlines mid-row
//   - New version processes line-by-line to preserve table integrity
//   - Removed broken regex from applySmartFormatting that also split tables
//   - Tables now render correctly with all columns intact
// ==========================================

import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';

// ============ CHART GENERATION ============
const QUICKCHART_BASE_URL = 'https://quickchart.io/chart';

// Chart colors matching PDF theme
const CHART_COLORS = {
  gold: '#C9A646',
  positive: '#16A34A',
  negative: '#DC2626',
  neutral: '#6B7280',
  primary: '#1E3A8A',
  secondary: '#2563EB',
  gridLine: 'rgba(0,0,0,0.08)',
  textDark: '#374151',
  textLight: '#9CA3AF',
};

// ============ COLORS (identical to ISM) ============
const COLORS = {
  gold: '#C9A646',
  goldDark: '#A68A3A',
  goldLight: '#E5D5A0',
  black: '#000000',
  darkText: '#1A1A1A',
  mediumGray: '#555555',
  lightGray: '#888888',
  veryLightGray: '#CCCCCC',
  ultraLightGray: '#F5F5F5',
  white: '#FFFFFF',
  green: '#16A34A',
  greenLight: '#DCFCE7',
  red: '#DC2626',
  redLight: '#FEE2E2',
  orange: '#EA580C',
  blue: '#2563EB',
};

// ============ TYPOGRAPHY ============
const FONT_DIR = path.join(process.cwd(), 'static', 'fonts');
const INTER_REGULAR = path.join(FONT_DIR, 'Inter_18pt-Regular.ttf');
const INTER_BOLD = path.join(FONT_DIR, 'Inter_18pt-Bold.ttf');

const hasInterFont = fs.existsSync(INTER_REGULAR) && fs.existsSync(INTER_BOLD);

const FONTS = {
  title: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  heading: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
  body: hasInterFont ? 'Inter-Regular' : 'Helvetica',
  bold: hasInterFont ? 'Inter-Bold' : 'Helvetica-Bold',
};

function registerFonts(doc) {
  if (hasInterFont) {
    doc.registerFont('Inter-Regular', INTER_REGULAR);
    doc.registerFont('Inter-Bold', INTER_BOLD);
    console.log('[PDF] Using Inter font');
  }
}

const SIZES = {
  coverTitle: 32,
  coverSubtitle: 16,
  coverDate: 14,
  coverTagline: 11,
  sectionTitle: 16,
  subSection: 13,
  thematicSubtitle: 11,
  stockTicker: 12,
  body: 10.5,
  small: 9.5,
  tableHeader: 9,
  tableCell: 9,
  footer: 8,
  logo: 42,
};

// ============ PAGE LAYOUT (identical to ISM) ============
const PAGE = {
  width: 612,
  height: 792,
  marginLeft: 50,
  marginRight: 50,
  marginTop: 60,
  marginBottom: 50,
  
  get contentWidth() { return this.width - this.marginLeft - this.marginRight; },
  get contentTop() { return this.marginTop + 25; },
  get footerY() { return this.height - 30; },
  get contentBottom() { return this.footerY - 25; },
  get safeBottom() { return this.footerY - 40; },
  get contentHeight() { return this.contentBottom - this.contentTop; },
  get threshold60() { return this.contentTop + (this.contentHeight * 0.60); },
  get minSectionSpace() { return 80; },
};

const COPYRIGHT = '© 2026 FINOTAUR';

// ============ CHART GENERATION FUNCTIONS ============

// Generate Index Performance Bar Chart URL
function generateIndexPerformanceChartURL(lockedPrices) {
  if (!lockedPrices?.indices) return null;
  
  const indices = lockedPrices.indices;
  const labels = [];
  const data = [];
  const colors = [];
  
  for (const [symbol, info] of Object.entries(indices)) {
    if (info?.changePercent !== undefined) {
      labels.push(symbol);
      data.push(parseFloat(info.changePercent.toFixed(2)));
      colors.push(info.changePercent >= 0 ? CHART_COLORS.positive : CHART_COLORS.negative);
    }
  }
  
  if (labels.length === 0) return null;
  
  const config = {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Daily Change (%)',
        data: data,
        backgroundColor: colors,
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Index Performance',
          color: CHART_COLORS.textDark,
          font: { size: 14, weight: 'bold' },
        },
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          formatter: (value) => `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`,
          color: CHART_COLORS.textDark,
          font: { size: 10 }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: CHART_COLORS.gridLine },
          ticks: { callback: (value) => `${value}%` }
        },
        x: { grid: { display: false } }
      }
    }
  };
  
  return `${QUICKCHART_BASE_URL}?c=${encodeURIComponent(JSON.stringify(config))}&w=450&h=220&bkg=white&f=png`;
}

// Generate Sector Heatmap URL
function generateSectorHeatmapURL(lockedPrices) {
  if (!lockedPrices?.sectors) return null;
  
  const sectors = [];
  for (const [symbol, info] of Object.entries(lockedPrices.sectors)) {
    if (info?.changePercent !== undefined) {
      sectors.push({
        symbol,
        change: parseFloat(info.changePercent.toFixed(2))
      });
    }
  }
  
  if (sectors.length === 0) return null;
  
  // Sort by performance
  sectors.sort((a, b) => b.change - a.change);
  
  const labels = sectors.map(s => s.symbol);
  const data = sectors.map(s => s.change);
  const colors = data.map(val => {
    if (val >= 1) return CHART_COLORS.positive;
    if (val >= 0) return '#34D399';
    if (val >= -1) return '#FCD34D';
    return CHART_COLORS.negative;
  });
  
  const config = {
    type: 'horizontalBar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Daily Change (%)',
        data: data,
        backgroundColor: colors,
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Sector Performance',
          color: CHART_COLORS.textDark,
          font: { size: 14, weight: 'bold' },
        },
        legend: { display: false }
      },
      scales: {
        x: {
          grid: { color: CHART_COLORS.gridLine },
          ticks: { callback: (value) => `${value}%` }
        },
        y: { grid: { display: false } }
      }
    }
  };
  
  return `${QUICKCHART_BASE_URL}?c=${encodeURIComponent(JSON.stringify(config))}&w=420&h=280&bkg=white&f=png`;
}

// Generate VIX Gauge Chart URL
function generateVIXGaugeURL(lockedPrices) {
  const vixValue = lockedPrices?.vix?.price || 16;
  
  const config = {
    type: 'gauge',
    data: {
      datasets: [{
        value: vixValue,
        data: [12, 16, 20, 30, 40],
        backgroundColor: [
          CHART_COLORS.positive,  // 0-12: Very Low
          '#34D399',              // 12-16: Low
          '#FCD34D',              // 16-20: Moderate
          '#F97316',              // 20-30: High
          CHART_COLORS.negative   // 30+: Very High
        ],
        borderWidth: 0,
      }]
    },
    options: {
      needle: {
        radiusPercentage: 2,
        widthPercentage: 3.2,
        lengthPercentage: 80,
        color: CHART_COLORS.textDark
      },
      valueLabel: {
        display: true,
        formatter: () => `VIX: ${vixValue.toFixed(1)}`,
        color: CHART_COLORS.textDark,
        font: { size: 14, weight: 'bold' }
      },
      plugins: {
        title: {
          display: true,
          text: 'Volatility Index',
          color: CHART_COLORS.textDark,
          font: { size: 12, weight: 'bold' },
        }
      }
    }
  };
  
  return `${QUICKCHART_BASE_URL}?c=${encodeURIComponent(JSON.stringify(config))}&w=280&h=180&bkg=white&f=png`;
}

// Fetch chart image buffer from URL
async function fetchChartBuffer(url) {
  if (!url) return null;
  
  try {
    const response = await fetch(url, { timeout: 10000 });
    if (!response.ok) {
      console.log(`[PDF Charts] Failed to fetch chart: ${response.status}`);
      return null;
    }
    const buffer = Buffer.from(await response.arrayBuffer());
    console.log(`[PDF Charts] Fetched chart: ${(buffer.length / 1024).toFixed(1)}KB`);
    return buffer;
  } catch (err) {
    console.log(`[PDF Charts] Error fetching chart: ${err.message}`);
    return null;
  }
}

// Generate all charts for the report
async function generateReportCharts(lockedPrices) {
  console.log('[PDF Charts] Generating charts...');
  
  const charts = {
    indexPerformance: null,
    sectorHeatmap: null,
    vixGauge: null,
  };
  
  // Generate URLs
  const urls = {
    indexPerformance: generateIndexPerformanceChartURL(lockedPrices),
    sectorHeatmap: generateSectorHeatmapURL(lockedPrices),
    vixGauge: generateVIXGaugeURL(lockedPrices),
  };
  
  // Fetch chart buffers in parallel
  const results = await Promise.all([
    fetchChartBuffer(urls.indexPerformance),
    fetchChartBuffer(urls.sectorHeatmap),
    fetchChartBuffer(urls.vixGauge),
  ]);
  
  charts.indexPerformance = results[0];
  charts.sectorHeatmap = results[1];
  charts.vixGauge = results[2];
  
  const successCount = Object.values(charts).filter(c => c !== null).length;
  console.log(`[PDF Charts] Generated ${successCount}/3 charts`);
  
  return charts;
}

// Draw chart on PDF page
function drawChart(doc, chartBuffer, x, y, width, height = null) {
  if (!chartBuffer) return y;
  
  try {
    const options = { width };
    if (height) options.height = height;
    
    doc.image(chartBuffer, x, y, options);
    
    // Return new Y position (estimate based on aspect ratio)
    const estimatedHeight = height || (width * 0.6);
    return y + estimatedHeight + 15;
  } catch (err) {
    console.log(`[PDF Charts] Error drawing chart: ${err.message}`);
    return y;
  }
}

// ============ DEFAULT LOGO PATH ============
const DEFAULT_LOGO_PATHS = [
  path.join(process.cwd(), '..', 'finotaur-frontend', 'public', 'logo.png'),
  path.join(process.cwd(), '..', 'frontend', 'public', 'logo.png'),
  path.join(process.cwd(), '..', 'client', 'public', 'logo.png'),
  '/app/finotaur-frontend/public/logo.png',
  '/app/frontend/public/logo.png',
  '/opt/render/project/src/finotaur-frontend/public/logo.png',
  path.join(process.cwd(), 'packages', 'frontend', 'public', 'logo.png'),
  path.join(process.cwd(), 'apps', 'frontend', 'public', 'logo.png'),
  path.join(process.cwd(), 'public', 'logo.png'),
  path.join(process.cwd(), 'public', 'logo-text.png'),
  path.join(process.cwd(), 'static', 'logo.png'),
  path.join(process.cwd(), 'static', 'logo-text.png'),
  path.join(process.cwd(), 'assets', 'logo.png'),
  '/app/public/logo.png',
  '/app/public/logo-text.png',
  './public/logo.png',
  './public/logo-text.png',
];

// ============ HELPER FUNCTIONS ============
function needsPageBreak(currentY, requiredSpace) {
  return currentY + requiredSpace > PAGE.safeBottom;
}

function pastThresholdForNewSection(currentY) {
  return currentY > PAGE.threshold60;
}

function formatDateDisplay() {
  const now = new Date();
  return now.toLocaleDateString('en-US', { 
    weekday: 'long',
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    timeZone: 'America/New_York'
  });
}

// ============ IMPROVED TEXT CLEANING ============
function cleanText(text) {
  if (!text) return '';
  
  return text
    .replace(/[\u{1F300}-\u{1F9FF}]/gu, '')
    .replace(/[\u{2600}-\u{26FF}]/gu, '')
    .replace(/[\u{2700}-\u{27BF}]/gu, '')
    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
    .replace(/[\u{1F1E0}-\u{1F1FF}]/gu, '')
    .replace(/[📊📖💰🌍🌏📚🎯🏛️⬆️⬇️📅📈🔗⚡📉📌⚠️🎰💼✅❌🔥💹🏗️📡📰🔄📐🔍🔧🎨📦🏆⭐🗺️📝💡🎲📆🤖📄🟨🟦🟩🟪🔹🔴🟢🔵🟡🔒]/g, '')
    // v12.0: Remove ** asterisks (no longer needed for bold)
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/\#\#\#/g, '')
    .replace(/\#\#/g, '')
    .replace(/\#/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function findLogo(providedPath) {
  console.log('[PDF] Looking for logo...');
  
  const envLogoPath = process.env.LOGO_PATH || process.env.FINOTAUR_LOGO_PATH;
  if (envLogoPath && fs.existsSync(envLogoPath)) {
    console.log(`[PDF] Found logo via environment variable: ${envLogoPath}`);
    return envLogoPath;
  }
  
  if (providedPath) {
    if (Buffer.isBuffer(providedPath)) {
      console.log('[PDF] Logo provided as Buffer');
      return providedPath;
    }
    if (typeof providedPath === 'string') {
      if (providedPath.startsWith('data:image')) {
        console.log('[PDF] Logo provided as base64 data URL');
        const base64Data = providedPath.split(',')[1];
        return Buffer.from(base64Data, 'base64');
      }
      if (fs.existsSync(providedPath)) {
        console.log(`[PDF] Logo found at provided path: ${providedPath}`);
        return providedPath;
      }
    }
  }
  
  for (const p of DEFAULT_LOGO_PATHS) {
    if (fs.existsSync(p)) {
      console.log(`[PDF] Found logo at: ${p}`);
      return p;
    }
  }
  
  console.log('[PDF] No logo found');
  return null;
}

// ============ COVER PAGE (identical design to ISM) ============
function drawCoverPage(doc, dateDisplay, logoData) {
  const centerX = PAGE.width / 2;

  // Black background
  doc.rect(0, 0, PAGE.width, PAGE.height).fill(COLORS.black);
  
  // Top gold accent bar
  doc.rect(0, 0, PAGE.width, 5).fill(COLORS.gold);

  // === FINOTAUR TEXT LOGO ===
  const textLogoY = 100;
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(48)
     .text('FINOTAUR', 0, textLogoY, { align: 'center', width: PAGE.width });
  
  // Thicker underline
  const textWidth = 220;
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .moveTo(centerX - textWidth/2, textLogoY + 52)
     .lineTo(centerX + textWidth/2, textLogoY + 52)
     .stroke();
  
  // Tagline under logo
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(10)
     .text('Institutional-Grade Market Intelligence', 0, textLogoY + 68, { 
       align: 'center', width: PAGE.width 
     });

  // === COMPANY LOGO IMAGE ===
  let logoImageY = 210;
  let logoLoaded = false;
  const logoWidth = 200;
  const logoHeight = 160;
  
  if (logoData) {
    try {
      const logoX = centerX - logoWidth/2;
      const logoY = logoImageY;
      
      if (Buffer.isBuffer(logoData)) {
        doc.image(logoData, logoX, logoY, { width: logoWidth, height: logoHeight });
        logoLoaded = true;
      } else if (typeof logoData === 'string' && fs.existsSync(logoData)) {
        doc.image(logoData, logoX, logoY, { width: logoWidth, height: logoHeight });
        logoLoaded = true;
      }
    } catch (e) {
      console.log('[PDF] Logo image load failed:', e.message);
    }
  }
  
  const titleY = logoLoaded ? logoImageY + logoHeight + 40 : textLogoY + 180;
  
  // Decorative line above title
  doc.strokeColor(COLORS.gold)
     .lineWidth(1)
     .moveTo(centerX - 150, titleY - 35)
     .lineTo(centerX + 150, titleY - 35)
     .stroke();
  
  // Gold diamond decoration
  const diamondY = titleY - 25;
  const diamondSize = 6;
  doc.fillColor(COLORS.gold)
     .moveTo(centerX, diamondY - diamondSize)
     .lineTo(centerX + diamondSize, diamondY)
     .lineTo(centerX, diamondY + diamondSize)
     .lineTo(centerX - diamondSize, diamondY)
     .closePath()
     .fill();
  
  // Report type label
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(11)
     .text('INSTITUTIONAL RESEARCH', 0, titleY - 8, { align: 'center', width: PAGE.width });
  
  // Main title
  doc.fillColor(COLORS.white)
     .font(FONTS.title)
     .fontSize(36)
     .text('Daily Intelligence Report', 0, titleY + 20, { 
       align: 'center', width: PAGE.width 
     });

  // Gold separator line
  doc.strokeColor(COLORS.gold)
     .lineWidth(2)
     .moveTo(centerX - 180, titleY + 68)
     .lineTo(centerX + 180, titleY + 68)
     .stroke();

  // Date display
  doc.fillColor(COLORS.white)
     .font(FONTS.body)
     .fontSize(20)
     .text(dateDisplay, 0, titleY + 88, { align: 'center', width: PAGE.width });

  // Tagline
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.coverTagline)
     .text('Market Analysis • Trading Opportunities • Institutional Flow', 0, titleY + 120, { 
       align: 'center', width: PAGE.width 
     });

  // Bottom gold accent bar
  doc.rect(0, PAGE.height - 5, PAGE.width, 5).fill(COLORS.gold);

  // Copyright at bottom
  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.footer)
     .text(COPYRIGHT, 0, PAGE.height - 25, { align: 'center', width: PAGE.width });
}

// ============ PAGE HEADER ============
function drawPageHeader(doc, dateDisplay) {
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(12)
     .text('FINOTAUR', PAGE.marginLeft, 28, { lineBreak: false });

  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.small)
     .text(dateDisplay, PAGE.width - PAGE.marginRight - 150, 30, { 
       width: 150, align: 'right', lineBreak: false 
     });

  doc.strokeColor(COLORS.gold)
     .lineWidth(0.75)
     .moveTo(PAGE.marginLeft, 45)
     .lineTo(PAGE.width - PAGE.marginRight, 45)
     .stroke();
}

// ============ SECTION HEADER ============
function drawSectionHeader(doc, title, subtitle, startY) {
  let y = startY;

  doc.fillColor(COLORS.black)
     .font(FONTS.bold)
     .fontSize(SIZES.sectionTitle)
     .text(title, PAGE.marginLeft, y, { lineBreak: false });

  const titleWidth = doc.widthOfString(title);
  y += 18;

  // Gold underline
  doc.strokeColor(COLORS.gold)
     .lineWidth(2.5)
     .moveTo(PAGE.marginLeft, y)
     .lineTo(PAGE.marginLeft + Math.min(titleWidth + 20, PAGE.contentWidth * 0.4), y)
     .stroke();

  y += 8;

  // Optional subtitle
  if (subtitle) {
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.small)
       .text(subtitle, PAGE.marginLeft, y, { width: PAGE.contentWidth });
    y += 16;
  }

  return y + 8;
}

// ============ PAGE FOOTER ============
function drawPageFooter(doc, pageNumber) {
  const footerY = PAGE.footerY;

  doc.strokeColor(COLORS.veryLightGray)
     .lineWidth(0.5)
     .moveTo(PAGE.marginLeft, footerY - 10)
     .lineTo(PAGE.width - PAGE.marginRight, footerY - 10)
     .stroke();

  doc.fillColor(COLORS.lightGray)
     .font(FONTS.body)
     .fontSize(SIZES.footer);

  doc.text(COPYRIGHT, PAGE.marginLeft, footerY, { lineBreak: false });
  doc.text('For educational purposes only. Not investment advice.', PAGE.marginLeft + 130, footerY, { lineBreak: false });
  doc.text(String(pageNumber), PAGE.width - PAGE.marginRight - 20, footerY, { align: 'right', lineBreak: false });
}

// =====================================================
// CRITICAL FIX: COMPREHENSIVE SECTION MAP
// =====================================================
// =====================================================
// SECTION MAP - Maps various header names to section keys
// MEIDA PNIM STYLE v11.5
// IMPORTANT: Also includes OLD section names for backward compatibility
// =====================================================
const SECTION_MAP = {
  // ===============================================
  // NEW SECTION NAMES (v4.0 Meida Pnim style)
  // ===============================================
  
  // Global Arena (new name for Yesterday's Events)
  'THE GLOBAL ARENA': 'globalArena',
  'GLOBAL ARENA': 'globalArena',
  'GLOBALARENA': 'globalArena',
  
  // What's Happening Now (new name for What's Interesting)
  'WHAT\'S HAPPENING NOW': 'whatsHappening',
  'WHATS HAPPENING NOW': 'whatsHappening',
  'WHAT\'S HAPPENING': 'whatsHappening',
  'WHATS HAPPENING': 'whatsHappening',
  'WHATSHAPPENING': 'whatsHappening',
  
  // Week Ahead (same as before)
  'WEEK AHEAD': 'weekAhead',
  'THE WEEK AHEAD': 'weekAhead',
  'WEEKAHEAD': 'weekAhead',
  'WHAT\'S ON THE RADAR': 'weekAhead',
  'WHATS ON THE RADAR': 'weekAhead',
  'ON THE RADAR': 'weekAhead',
  'EVENTS THIS WEEK': 'weekAhead',
  'LOOKING AHEAD': 'weekAhead',
  
  // Macro Arena (same as before)
  'THE MACRO ARENA': 'macroArena',
  'MACRO ARENA': 'macroArena',
  'MACROARENA': 'macroArena',
  'ECONOMIC CALENDAR': 'macroArena',
  'MACRO ECONOMIC ARENA': 'macroArena',
  
  // Analyst Arena (same as before)
  'ANALYST ARENA': 'analystArena',
  'THE ANALYST ARENA': 'analystArena',
  'ANALYSTARENA': 'analystArena',
  'WALL STREET ACTIONS': 'analystArena',
  
  // Tactical Corner (same as before)
  'THE TACTICAL CORNER': 'tacticalCorner',
  'TACTICAL CORNER': 'tacticalCorner',
  'TACTICALCORNER': 'tacticalCorner',
  'FLOW OF FUNDS': 'tacticalCorner',
  'MARKET STRUCTURE': 'tacticalCorner',
  
  // Focus Corner (same as before)
  'FOCUS CORNER': 'focusCorner',
  'THE FOCUS CORNER': 'focusCorner',
  'FOCUSCORNER': 'focusCorner',
  'TRADE SETUPS': 'focusCorner',
  'STOCK FOCUS': 'focusCorner',
  
  // Reports (new name for Earnings)
  'REPORTS': 'reports',
  'EARNINGS REPORTS': 'reports',
  'EARNINGS': 'reports',
  'COMPANY REPORTS': 'reports',
  'NOTABLE EARNINGS': 'reports',
  'NOTABLE EARNINGS REPORTS': 'reports',
  
  // ===============================================
  // OLD SECTION NAMES (v3.x backward compatibility)
  // ===============================================
  
  // Yesterday's Events -> maps to globalArena
  'YESTERDAY\'S EVENTS': 'globalArena',
  'YESTERDAYS EVENTS': 'globalArena',
  'YESTERDAYEVENTS': 'globalArena',
  'MARKET STATUS': 'globalArena',
  'MARKET STATUS & KEY MOVES': 'globalArena',
  'FROM YESTERDAY\'S EVENTS': 'globalArena',
  'MARKET OVERVIEW': 'globalArena',
  
  // What's Interesting/Hot -> maps to whatsHappening
  'WHAT\'S INTERESTING TODAY': 'whatsHappening',
  'WHATS INTERESTING TODAY': 'whatsHappening',
  'WHAT\'S INTERESTING': 'whatsHappening',
  'WHATS INTERESTING': 'whatsHappening',
  'WHATSINTERESTING': 'whatsHappening',
  'WHAT\'S HOT TODAY': 'whatsHappening',
  'WHATS HOT TODAY': 'whatsHappening',
  'WHAT\'S HOT': 'whatsHappening',
  'WHATS HOT': 'whatsHappening',
  'WHATSHOT': 'whatsHappening',
  'KEY THEMES': 'whatsHappening',
  'KEY THEMES & CATALYSTS': 'whatsHappening',
  'CURRENT MARKET STATUS': 'whatsHappening',
  
  // News & Catalysts -> maps to whatsHappening
  'NEWS & CATALYSTS': 'whatsHappening',
  'NEWS AND CATALYSTS': 'whatsHappening',
  'NEWS, CATALYSTS': 'whatsHappening',
  'NEWSCATALYSTS': 'whatsHappening',
  'MARKET-MOVING DEVELOPMENTS': 'whatsHappening',
  
  // ===============================================
  // SKIP SECTIONS
  // ===============================================
  'IMPORTANT DISCLAIMER': 'disclaimer',
  'DISCLAIMER': 'disclaimer',
};

// Section display info - MEIDA PNIM STYLE
const SECTION_INFO = {
  globalArena: { 
    title: 'The Global Arena', 
    subtitle: 'Market Overview & Key Developments'
  },
  whatsHappening: { 
    title: "What's Happening Now", 
    subtitle: 'Current Market Status'
  },
  weekAhead: { 
    title: 'Week Ahead', 
    subtitle: "What's On The Radar"
  },
  macroArena: { 
    title: 'The Macro Arena', 
    subtitle: 'Economic Calendar & Data'
  },
  analystArena: { 
    title: 'Analyst Arena', 
    subtitle: 'Wall Street Actions'
  },
  tacticalCorner: { 
    title: 'The Tactical Corner', 
    subtitle: 'Flow of Funds & Market Structure'
  },
  focusCorner: { 
    title: 'Focus Corner', 
    subtitle: 'Trade Setups'
  },
  reports: { 
    title: 'Reports', 
    subtitle: 'Earnings & Company News'
  },
};

// =====================================================
// v19.0: DIRECT DATA TABLE RENDERING
// Tables are rendered directly from lockedPrices data
// This completely bypasses the text processing pipeline
// =====================================================

function renderDataTable(doc, headers, rows, y, options = {}) {
  if (!headers || headers.length === 0) return y;
  
  const tableStartX = PAGE.marginLeft;
  const tableWidth = PAGE.contentWidth;
  const rowHeight = options.rowHeight || 22;
  const cellPadding = 6;
  const numCols = headers.length;
  
  // Calculate column widths (can be customized via options)
  const colWidths = options.colWidths || headers.map(() => tableWidth / numCols);
  
  y += 5;
  
  // Draw header row
  doc.fillColor('#2d2d44')
     .rect(tableStartX, y, tableWidth, rowHeight)
     .fill();
  
  let cellX = tableStartX;
  for (let i = 0; i < headers.length; i++) {
    doc.fillColor('#ffffff')
       .font(FONTS.bold)
       .fontSize(9)
       .text(headers[i], cellX + cellPadding, y + 6, {
         width: colWidths[i] - (cellPadding * 2),
         height: rowHeight - 8,
         ellipsis: true
       });
    cellX += colWidths[i];
  }
  
  // Draw header bottom border
  doc.strokeColor('#c9a227')
     .lineWidth(1)
     .moveTo(tableStartX, y + rowHeight)
     .lineTo(tableStartX + tableWidth, y + rowHeight)
     .stroke();
  
  y += rowHeight;
  
  // Draw data rows
  for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
    const row = rows[rowIdx];
    if (!row) continue;
    
    // Alternating row background
    if (rowIdx % 2 === 0) {
      doc.fillColor('#f8f9fa')
         .rect(tableStartX, y, tableWidth, rowHeight)
         .fill();
    }
    
    // Draw cells
    cellX = tableStartX;
    for (let colIdx = 0; colIdx < row.length && colIdx < numCols; colIdx++) {
      const cellText = String(row[colIdx] || '');
      
      doc.fillColor('#2d3748')
         .font(FONTS.body)
         .fontSize(9)
         .text(cellText, cellX + cellPadding, y + 6, {
           width: colWidths[colIdx] - (cellPadding * 2),
           height: rowHeight - 8,
           ellipsis: true
         });
      cellX += colWidths[colIdx];
    }
    
    // Draw row border
    doc.strokeColor('#e2e8f0')
       .lineWidth(0.5)
       .moveTo(tableStartX, y + rowHeight)
       .lineTo(tableStartX + tableWidth, y + rowHeight)
       .stroke();
    
    y += rowHeight;
  }
  
  doc.fillColor(COLORS.darkText);
  return y + 8;
}

// ============================================================================
// DYNAMIC TABLE DATA - v21.0
// 100% dynamic - NO hardcoded values, all from context/lockedPrices
// ============================================================================
function getSectionTables(sectionKey, lockedPrices, context) {
  console.log(`[PDF] getSectionTables(${sectionKey})`);
  console.log(`[PDF]   lockedPrices: ${lockedPrices ? 'EXISTS' : 'NULL'}`);
  console.log(`[PDF]   context: ${context ? 'EXISTS' : 'NULL'}`);
  
  if (lockedPrices?.indices) {
    console.log(`[PDF]   indices: ${JSON.stringify(Object.keys(lockedPrices.indices))}`);
  }
  
  const tables = [];
  
  // Helper functions
  const fmtPrice = (p) => p ? `$${p.toFixed(2)}` : '-';
  const fmtPct = (p) => p !== undefined && p !== null ? `${p >= 0 ? '+' : ''}${p.toFixed(2)}%` : '-';
  const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[d.getMonth()]} ${d.getDate()}`;
  };
  
  // Helper to generate intelligent notes based on price action
  const getIndexNote = (symbol, data) => {
    if (!data) return '-';
    const pct = data.changePercent || 0;
    if (symbol === 'SPY') {
      if (pct > 0.5) return 'Strong rally';
      if (pct > 0) return 'Bullish momentum';
      if (pct > -0.5) return 'Minor pullback';
      return 'Risk-off session';
    }
    if (symbol === 'QQQ') {
      if (pct > 0.5) return 'Tech leading';
      if (pct > 0) return 'Tech holding';
      if (pct > -0.5) return 'Tech underperforming';
      return 'Tech weakness';
    }
    if (symbol === 'IWM') {
      if (pct > 0.5) return 'Small caps outperform';
      if (pct > 0) return 'Small caps bid';
      if (pct > -0.5) return 'Small caps lag';
      return 'Risk-off in small caps';
    }
    return pct >= 0 ? 'Positive' : 'Negative';
  };
  
  // ========== GLOBAL ARENA ==========
  if (sectionKey === 'globalArena' && lockedPrices) {
    // Index table from lockedPrices.indices
    const indices = lockedPrices.indices || {};
    const indexRows = [];
    
    if (indices.SPY) indexRows.push(['SPY', fmtPrice(indices.SPY.price), fmtPct(indices.SPY.changePercent), getIndexNote('SPY', indices.SPY)]);
    if (indices.QQQ) indexRows.push(['QQQ', fmtPrice(indices.QQQ.price), fmtPct(indices.QQQ.changePercent), getIndexNote('QQQ', indices.QQQ)]);
    if (indices.IWM) indexRows.push(['IWM', fmtPrice(indices.IWM.price), fmtPct(indices.IWM.changePercent), getIndexNote('IWM', indices.IWM)]);
    if (indices.DIA) indexRows.push(['DIA', fmtPrice(indices.DIA.price), fmtPct(indices.DIA.changePercent), getIndexNote('DIA', indices.DIA)]);
    
    console.log(`[PDF] globalArena indexRows: ${indexRows.length}`);
    
    if (indexRows.length > 0) {
      tables.push({
        title: 'INDEX PERFORMANCE',
        headers: ['Index', 'Close', 'Change', 'Note'],
        rows: indexRows,
        colWidths: [70, 90, 80, PAGE.contentWidth - 240]
      });
    }
    
    // Market indicators from lockedPrices
    const indicatorRows = [];
    const vix = lockedPrices.vix;
    const yields = lockedPrices.yields;
    const dxy = lockedPrices.dxy;
    
    if (vix?.price) {
      const vixVal = vix.price;
      const signal = vixVal < 14 ? 'Low fear' : vixVal < 18 ? 'Normal' : vixVal < 25 ? 'Elevated' : 'High fear';
      indicatorRows.push(['VIX', vixVal.toFixed(2), signal]);
    }
    if (yields?.tenYear) {
      const yieldVal = parseFloat(yields.tenYear);
      const signal = yieldVal > 4.5 ? 'Rising' : yieldVal > 4.0 ? 'Contained' : 'Falling';
      indicatorRows.push(['10Y Yield', `${yields.tenYear}%`, signal]);
    }
    if (dxy?.current) {
      const dxyVal = dxy.current;
      const signal = dxyVal > 107 ? 'Strong dollar' : dxyVal > 103 ? 'Neutral' : 'Dollar weakness';
      indicatorRows.push(['DXY', dxyVal.toFixed(2), signal]);
    }
    
    if (indicatorRows.length > 0) {
      tables.push({
        title: 'MARKET INDICATORS',
        headers: ['Indicator', 'Value', 'Signal'],
        rows: indicatorRows,
        colWidths: [100, 100, PAGE.contentWidth - 200]
      });
    }
    
    // Sector performance from lockedPrices.sectors
    const sectors = lockedPrices.sectors;
    if (sectors && Object.keys(sectors).length > 0) {
      const sectorPerf = Object.entries(sectors)
        .filter(([_, data]) => data?.changePercent !== undefined)
        .map(([sym, data]) => ({ symbol: sym, change: data.changePercent }))
        .sort((a, b) => b.change - a.change);
      
      if (sectorPerf.length >= 4) {
        const topSectors = sectorPerf.slice(0, 2);
        const bottomSectors = sectorPerf.slice(-2).reverse();
        
        tables.push({
          title: 'SECTOR PERFORMANCE',
          headers: ['Sector', 'Change', 'Status'],
          rows: [
            ...topSectors.map((s, i) => [s.symbol, fmtPct(s.change), i === 0 ? 'Leading' : 'Strong']),
            ...bottomSectors.map((s, i) => [s.symbol, fmtPct(s.change), i === bottomSectors.length - 1 ? 'Lagging' : 'Weak'])
          ],
          colWidths: [100, 100, PAGE.contentWidth - 200]
        });
      }
    }
  }
  
  // ========== WEEK AHEAD ==========
  if (sectionKey === 'weekAhead' && context) {
    // Economic events from context.economicCalendar.thisWeek
    const events = context.economicCalendar?.thisWeek || [];
    if (events.length > 0) {
      const eventRows = events.slice(0, 8).map(e => [
        formatDate(e.date),
        e.event || '-',
        e.time || '-',
        e.previous || '-',
        e.forecast || '-'
      ]);
      
      tables.push({
        title: 'ECONOMIC EVENTS',
        headers: ['Date', 'Event', 'Time', 'Previous', 'Expected'],
        rows: eventRows,
        colWidths: [70, 160, 50, 70, 70]
      });
    }
    
    // Earnings calendar from context.earningsData
    const earnings = context.earningsData || [];
    if (earnings.length > 0) {
      const earningsRows = earnings.slice(0, 6).map(e => [
        e.ticker || '-',
        e.company || '-',
        formatDate(e.date),
        e.time || '-'
      ]);
      
      tables.push({
        title: 'EARNINGS CALENDAR',
        headers: ['Ticker', 'Company', 'Date', 'Time'],
        rows: earningsRows,
        colWidths: [60, 180, 70, 50]
      });
    }
  }
  
  // ========== MACRO ARENA ==========
  if (sectionKey === 'macroArena' && context) {
    const events = context.economicCalendar?.thisWeek || [];
    if (events.length > 0) {
      const eventRows = events.slice(0, 10).map(e => [
        e.event || '-',
        formatDate(e.date),
        e.time || '-',
        e.previous || '-',
        e.forecast || '-',
        (e.importance || 'med').toUpperCase().slice(0, 3)
      ]);
      
      tables.push({
        title: 'ECONOMIC CALENDAR',
        headers: ['Event', 'Date', 'Time', 'Previous', 'Expected', 'Impact'],
        rows: eventRows,
        colWidths: [145, 55, 45, 65, 70, 45]
      });
    }
  }
  
  // ========== ANALYST ARENA ==========
  if (sectionKey === 'analystArena' && context) {
    const actions = context.analystData?.actions || [];
    if (actions.length > 0) {
      const analystRows = actions.slice(0, 8).map(a => [
        a.ticker || '-',
        a.toRating || a.action || '-',
        a.priceTarget ? `$${a.priceTarget}` : '-',
        a.firm || '-'
      ]);
      
      tables.push({
        title: 'ANALYST ACTIONS',
        headers: ['Ticker', 'Rating', 'Price Target', 'Firm'],
        rows: analystRows,
        colWidths: [70, 120, 90, PAGE.contentWidth - 280]
      });
    }
  }
  
  // ========== REPORTS (EARNINGS) ==========
  if (sectionKey === 'reports' && context) {
    const earnings = context.earningsData || [];
    if (earnings.length > 0) {
      const earningsRows = earnings.slice(0, 8).map(e => [
        e.ticker || '-',
        e.company || '-',
        formatDate(e.date),
        e.time || '-',
        e.epsEst ? `$${e.epsEst.toFixed(2)}` : '-',
        e.revEst ? `$${e.revEst}` : '-'
      ]);
      
      tables.push({
        title: 'UPCOMING EARNINGS',
        headers: ['Ticker', 'Company', 'Date', 'Time', 'EPS Est', 'Rev Est'],
        rows: earningsRows,
        colWidths: [55, 130, 55, 40, 65, 70]
      });
    }
  }
  
  console.log(`[PDF] getSectionTables(${sectionKey}): ${tables.length} tables generated`);
  return tables;
}

// Render all tables for a section
function renderSectionTables(doc, sectionKey, lockedPrices, context, y, onPageBreak) {
  console.log(`[PDF] renderSectionTables called for: ${sectionKey}`);
  
  const tables = getSectionTables(sectionKey, lockedPrices, context);
  
  if (tables.length === 0) {
    console.log(`[PDF]   WARNING: No tables generated for ${sectionKey}!`);
    return y;
  }
  
  for (const table of tables) {
    console.log(`[PDF]   Drawing table: ${table.title || 'unnamed'} with ${table.rows?.length || 0} rows`);
    
    // Check page break
    const estimatedHeight = (table.rows.length + 1) * 22 + 30;
    if (y + estimatedHeight > PAGE.safeBottom) {
      y = onPageBreak();
    }
    
    // Optional title
    if (table.title) {
      doc.fillColor(COLORS.darkText)
         .font(FONTS.bold)
         .fontSize(11)
         .text(table.title, PAGE.marginLeft, y);
      y = doc.y + 8;
    }
    
    y = renderDataTable(doc, table.headers, table.rows, y, { colWidths: table.colWidths });
    y += 10;
  }
  
  return y;
}

// Section rendering order - MEIDA PNIM STYLE
const SECTION_ORDER = [
  'globalArena',      // Page 1: Market overview
  'whatsHappening',   // Page 1: Current market status
  'weekAhead',        // Page 1: What to watch
  'macroArena',       // Page 2: Economic calendar
  'analystArena',     // Page 3: Analyst ratings
  'tacticalCorner',   // Page 4-5: Deep analysis
  'focusCorner',      // Page 6: Stock picks
  'reports',          // Page 7: Earnings
];

// =====================================================
// CRITICAL FIX v12.0: IMPROVED SECTION PARSING
// Now detects section headers even without ## or ---
// =====================================================
function parseReportSections(reportText) {
  if (!reportText) {
    console.log('[PDF] parseReportSections: No report text provided');
    return {};
  }
  
  console.log(`[PDF] ========== PARSING REPORT ==========`);
  console.log(`[PDF] Report length: ${reportText.length} chars`);
  console.log('[PDF] Report preview (first 800 chars):');
  console.log(reportText.substring(0, 800));
  console.log('[PDF] =====================================');
  
  const sections = {};
  const lines = reportText.split('\n');
  let currentSection = null;
  let currentContent = [];

  const cleanLineForMatching = (line) => {
    // Remove markdown headers (##), ---, emojis, asterisks, and special chars
    let cleaned = line
      .replace(/^#+\s*/g, '')  // Remove markdown headers at start
      .replace(/^-{2,}\s*/g, '') // Remove --- at start
      .replace(/\*\*/g, '') // Remove bold markers
      .replace(/\*/g, '') // Remove single asterisks
      .replace(/[📊📖💰🌍🌏📚🎯🏛️⬆️⬇️📅📈🔗⚡📉📌⚠️🎰💼✅❌🔥💹🏗️📡📰🔄📐🔍🔧🎨📦🏆⭐═─\-#]+/g, '')
      .replace(/[—–]/g, '')
      .replace(/[''`´]/g, "'")
      .replace(/[""„]/g, '"')
      .trim()
      .toUpperCase();
    return cleaned;
  };

  // Check if line is a section header
  const isSectionHeader = (line) => {
    const trimmed = line.trim();
    const cleaned = cleanLineForMatching(trimmed);
    
    // Must be short enough to be a header (not a sentence)
    if (cleaned.length < 5 || cleaned.length > 60) return null;
    
    // Check exact matches first
    if (SECTION_MAP[cleaned]) {
      return SECTION_MAP[cleaned];
    }
    
    // Check partial matches
    for (const [key, value] of Object.entries(SECTION_MAP)) {
      if (cleaned === key || 
          cleaned.startsWith(key + ' ') || 
          cleaned.endsWith(' ' + key) ||
          key.startsWith(cleaned + ' ') ||
          cleaned.replace(/\s+/g, '') === key.replace(/\s+/g, '')) {
        return value;
      }
    }
    
    return null;
  };

  // Debug counters
  let linesProcessed = 0;
  let linesSkipped = 0;
  let linesContent = 0;
  let sectionsFound = 0;

  for (const line of lines) {
    linesProcessed++;
    const trimmed = line.trim();
    
    // Skip completely empty lines but preserve them as content separators
    if (!trimmed) {
      if (currentSection && currentContent.length > 0) {
        currentContent.push('');
        linesContent++;
      } else {
        linesSkipped++;
      }
      continue;
    }
    
    // Check if this line is a section header
    const matchedSection = isSectionHeader(trimmed);
    
    if (matchedSection && matchedSection !== 'disclaimer') {
      sectionsFound++;
      console.log(`[PDF] Found section #${sectionsFound}: "${trimmed.substring(0, 50)}" → ${matchedSection}`);
      
      // Save previous section
      if (currentSection && currentContent.length > 0) {
        const cleanedContent = cleanSectionContent(currentContent.join('\n'));
        if (cleanedContent.length > 50) {
          sections[currentSection] = cleanedContent;
          console.log(`[PDF] Saved section: ${currentSection} (${cleanedContent.length} chars)`);
        }
      }
      currentSection = matchedSection;
      currentContent = [];
    } else if (currentSection && matchedSection !== 'disclaimer') {
      // Add content to current section
      currentContent.push(line);
      linesContent++;
    } else if (!currentSection) {
      // Before first section - try to detect section from content
      const cleaned = cleanLineForMatching(trimmed);
      
      // Check if this might be a section header inline
      for (const [key, value] of Object.entries(SECTION_MAP)) {
        if (cleaned.includes(key) && value !== 'disclaimer') {
          sectionsFound++;
          console.log(`[PDF] Detected inline section: "${key}" → ${value}`);
          currentSection = value;
          break;
        }
      }
    }
  }
  
  // Save last section
  if (currentSection && currentSection !== 'disclaimer' && currentContent.length > 0) {
    const cleanedContent = cleanSectionContent(currentContent.join('\n'));
    if (cleanedContent.length > 50) {
      sections[currentSection] = cleanedContent;
      console.log(`[PDF] Saved final section: ${currentSection} (${cleanedContent.length} chars)`);
    }
  }
  
  console.log(`[PDF] Lines: ${linesProcessed} total, ${linesSkipped} skipped, ${linesContent} content`);
  console.log(`[PDF] Parsed ${Object.keys(sections).length} sections:`, Object.keys(sections));
  
  // FALLBACK: If few sections found, try alternative parsing
  if (Object.keys(sections).length < 3) {
    console.log('[PDF] WARNING: Few sections found, trying alternative parsing...');
    const altSections = parseReportSectionsAlternative(reportText);
    // Merge if alternative found more
    if (Object.keys(altSections).length > Object.keys(sections).length) {
      return altSections;
    }
  }
  
  return sections;
}

// =====================================================
// ALTERNATIVE SECTION PARSING v11.7 - INLINE DETECTION
// Handles cases where sections are inline like:
// "...content --- What's Happening Now more content..."
// =====================================================
function parseReportSectionsAlternative(reportText) {
  console.log('[PDF ALT] Using alternative section parser (inline detection)...');
  
  const sections = {};
  
  // Section patterns with inline markers (---, ##, or just section name)
  const sectionMarkers = [
    { pattern: /(?:---\s*|##\s*)?(?:The\s*)?Global\s*Arena\b/gi, key: 'globalArena' },
    { pattern: /(?:---\s*|##\s*)?Yesterday'?s?\s*Events?\b/gi, key: 'globalArena' },
    { pattern: /(?:---\s*|##\s*)?What'?s?\s*Happening\s*(?:Now)?\b/gi, key: 'whatsHappening' },
    { pattern: /(?:---\s*|##\s*)?What'?s?\s*(?:Hot|Interesting)\s*(?:Today)?\b/gi, key: 'whatsHappening' },
    { pattern: /(?:---\s*|##\s*)?Week\s*Ahead\b/gi, key: 'weekAhead' },
    { pattern: /(?:---\s*|##\s*)?Events?\s*This\s*Week\b/gi, key: 'weekAhead' },
    { pattern: /(?:---\s*|##\s*)?(?:The\s*)?Macro\s*Arena\b/gi, key: 'macroArena' },
    { pattern: /(?:---\s*|##\s*)?(?:The\s*)?Analyst\s*Arena\b/gi, key: 'analystArena' },
    { pattern: /(?:---\s*|##\s*)?(?:The\s*)?Tactical\s*Corner\b/gi, key: 'tacticalCorner' },
    { pattern: /(?:---\s*|##\s*)?Focus\s*(?:Corner|Stocks?)\b/gi, key: 'focusCorner' },
    // FIXED v11.8: Reports pattern must start with ## or --- to avoid matching "report" mid-sentence
    { pattern: /(?:---\s*|##\s*)Reports?\b/gi, key: 'reports' },
    { pattern: /(?:---\s*|##\s*)(?:Notable\s*)?Earnings?\s*(?:Reports?)?\b/gi, key: 'reports' },
  ];
  
  // Find all section positions
  const positions = [];
  const foundKeys = new Set();
  
  for (const { pattern, key } of sectionMarkers) {
    // Reset regex
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(reportText)) !== null) {
      // Only keep first occurrence of each section
      if (!foundKeys.has(key)) {
        positions.push({
          key,
          index: match.index,
          matchLength: match[0].length,
          matchText: match[0]
        });
        foundKeys.add(key);
        console.log(`[PDF ALT] Found ${key} at position ${match.index}: "${match[0].substring(0, 30)}"`);
      }
    }
  }
  
  // Sort by position
  positions.sort((a, b) => a.index - b.index);
  
  console.log(`[PDF ALT] Found ${positions.length} section positions:`, positions.map(p => p.key).join(', '));
  
  // Extract content between sections
  for (let i = 0; i < positions.length; i++) {
    const current = positions[i];
    const next = positions[i + 1];
    
    const startIndex = current.index + current.matchLength;
    const endIndex = next ? next.index : reportText.length;
    
    let content = reportText.substring(startIndex, endIndex);
    
    // Clean up content
    content = content
      .replace(/^[\s\-=]+/, '')
      .replace(/[\s\-=]+$/, '')
      .replace(/^---+\s*/gm, '')
      .trim();
    
    // Skip if too short
    if (content.length > 50) {
      sections[current.key] = content;
      console.log(`[PDF ALT] Extracted ${current.key}: ${content.length} chars`);
    }
  }
  
  console.log(`[PDF ALT] Parsed ${Object.keys(sections).length} sections:`, Object.keys(sections).join(', '));
  return sections;
}

// =====================================================
// CRITICAL FIX: CONTENT CLEANING - UPDATED v13.4
// =====================================================
function cleanSectionContent(content) {
  if (!content) return '';
  
  let cleaned = content
    // CRITICAL: Remove ALL asterisks (bold markers)
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    // Remove duplicate section headers that may appear in content (OLD and NEW names)
    .replace(/^(The Global Arena|Global Arena|Yesterday's Events|What's Happening Now|What's Happening|What's Hot|What's Interesting|The Macro Arena|Macro Arena|Analyst Arena|The Analyst Arena|Reports|Earnings|News & Catalysts|The Tactical Corner|Tactical Corner|Focus Corner|Week Ahead)[^\n]*\n/gim, '')
    // Remove --- separators
    .replace(/^-{3,}$/gm, '')
    // Clean up excessive whitespace but preserve paragraph structure
    .replace(/\n{4,}/g, '\n\n\n')
    .trim();
  
  // v13.4: Fix table formatting BEFORE other processing
  cleaned = fixTableFormatting(cleaned);
  
  // Apply smart formatting to add line breaks and separate paragraphs
  cleaned = applySmartFormatting(cleaned);
  
  // Split long paragraphs
  cleaned = splitLongParagraphs(cleaned);
  
  return cleaned;
}

// =====================================================
// v17.0: FIX TABLE FORMATTING - COMPLETELY REWRITTEN
// Previous version broke tables by splitting rows
// This version preserves table integrity
// =====================================================
function fixTableFormatting(text) {
  if (!text) return text;
  
  // Process line by line to preserve table structure
  const lines = text.split('\n');
  const result = [];
  let inTable = false;
  let prevWasTableRow = false;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    
    // Detect table row: starts with | and ends with | (or has multiple |)
    const isTableRow = trimmed.startsWith('|') && (trimmed.endsWith('|') || (trimmed.match(/\|/g) || []).length >= 2);
    // Detect table separator: |---|---|
    const isTableSeparator = /^\|[\s\-:|]+\|$/.test(trimmed);
    
    if (isTableRow || isTableSeparator) {
      // We're entering or continuing a table
      if (!inTable && result.length > 0) {
        // Add blank line before table if previous line wasn't blank
        const lastResult = result[result.length - 1];
        if (lastResult && lastResult.trim() !== '') {
          result.push('');
        }
      }
      inTable = true;
      prevWasTableRow = true;
      result.push(line);
    } else if (trimmed === '') {
      // Empty line
      if (inTable) {
        // End of table
        inTable = false;
      }
      result.push(line);
      prevWasTableRow = false;
    } else {
      // Regular text line
      if (prevWasTableRow && !inTable) {
        // Text right after table - ensure blank line between
        const lastResult = result[result.length - 1];
        if (lastResult && lastResult.trim() !== '') {
          result.push('');
        }
      }
      inTable = false;
      prevWasTableRow = false;
      result.push(line);
    }
  }
  
  let fixed = result.join('\n');
  
  // Ensure table headers like "ECONOMIC CALENDAR" have newlines after them
  fixed = fixed.replace(/(ECONOMIC CALENDAR|UPCOMING EARNINGS CALENDAR|ANALYST ACTIONS|MARKET DATA SNAPSHOT)[ \t]*\n(?!\n)/g, '$1\n\n');
  
  // Clean up excessive newlines
  fixed = fixed.replace(/\n{3,}/g, '\n\n');
  
  return fixed;
}

// =====================================================
// SPLIT LONG PARAGRAPHS v12.0 - Max 6 lines per paragraph
// =====================================================
function splitLongParagraphs(text) {
  if (!text) return text;
  
  const paragraphs = text.split(/\n\n+/);
  const result = [];
  
  for (const para of paragraphs) {
    const trimmed = para.trim();
    if (!trimmed) continue;
    
    // Count sentences (approximate)
    const sentences = trimmed.split(/(?<=[.!?])\s+/);
    
    // If more than 5 sentences, split into multiple paragraphs
    if (sentences.length > 5) {
      let currentPara = [];
      for (let i = 0; i < sentences.length; i++) {
        currentPara.push(sentences[i]);
        // Split every 4-5 sentences
        if (currentPara.length >= 4 && i < sentences.length - 1) {
          result.push(currentPara.join(' '));
          currentPara = [];
        }
      }
      if (currentPara.length > 0) {
        result.push(currentPara.join(' '));
      }
    } else {
      result.push(trimmed);
    }
  }
  
  return result.join('\n\n');
}

// =====================================================
// SMART FORMATTING v12.1 - Add line breaks where missing
// =====================================================
function applySmartFormatting(text) {
  if (!text) return text;
  
  let formatted = text;
  
  // CRITICAL: Remove all asterisks first
  formatted = formatted.replace(/\*\*/g, '');
  formatted = formatted.replace(/\*/g, '');
  
  // ========== v13.0 CRITICAL: FORCE LINE BREAKS BEFORE HEADERS ==========
  // These patterns add breaks REGARDLESS of punctuation before them
  
  // Force break before REPORTED YESTERDAY / REPORTING TODAY / UPCOMING THIS WEEK
  formatted = formatted.replace(/\s*(REPORTED YESTERDAY[^\n]*)/gi, '\n\n$1');
  formatted = formatted.replace(/\s*(REPORTING TODAY[^\n]*)/gi, '\n\n$1');
  formatted = formatted.replace(/\s*(UPCOMING THIS WEEK)/gi, '\n\n$1');
  
  // Force break before "Events This Week"
  formatted = formatted.replace(/\s*(Events This Week)/gi, '\n\n$1');
  
  // Force break before "Key Themes to Watch"
  formatted = formatted.replace(/\s*(Key Themes[^\n]*)/gi, '\n\n$1');
  
  // Force break before "No earnings" messages (make them standalone paragraphs)
  formatted = formatted.replace(/\s*(No earnings[^\n]*)/gi, '\n\n$1');
  formatted = formatted.replace(/\s*(No major earnings[^\n]*)/gi, '\n\n$1');
  
  // Force break before "What Does This Mean Tactically?"
  formatted = formatted.replace(/\s*(What Does This Mean Tactically\??)/gi, '\n\n$1');
  
  // Force break before Fund Flows and Buybacks headers
  formatted = formatted.replace(/\s*(Fund Flows[^\n]*)/gi, '\n\n$1');
  formatted = formatted.replace(/\s*(Buybacks[^\n]*)/gi, '\n\n$1');
  
  // v16.5: Force line breaks before and after table headers
  // ECONOMIC CALENDAR, UPCOMING EARNINGS CALENDAR, etc.
  formatted = formatted.replace(/\s*(ECONOMIC CALENDAR)\s*/gi, '\n\n$1\n\n');
  formatted = formatted.replace(/\s*(UPCOMING EARNINGS CALENDAR)\s*/gi, '\n\n$1\n\n');
  formatted = formatted.replace(/\s*(ANALYST ACTIONS SUMMARY)\s*/gi, '\n\n$1\n\n');
  formatted = formatted.replace(/\s*(MARKET DATA SNAPSHOT)\s*/gi, '\n\n$1\n\n');
  
  // v17.0: REMOVED broken regex that was splitting table rows
  // The old regex /([a-zA-Z0-9)])(\s+)(\|[^\n]+\|)/g was breaking tables
  // Table row separation is now handled by fixTableFormatting instead
  
  // ========== v13.0: FORCE LINE BREAKS BEFORE DAY HEADERS ==========
  // Match day names with or without punctuation before them
  formatted = formatted.replace(/\s*((?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),\s+\w+\s+\d+)/gi, '\n\n$1');
  
  // ========== ORIGINAL PATTERNS (enhanced) ==========
  
  // 1. Add line breaks before numbered items (1. 2. 3. etc)
  formatted = formatted.replace(/([.!?])\s+(\d+\.\s+)/g, '$1\n\n$2');
  // Also handle case where no punctuation before number
  formatted = formatted.replace(/([a-z])\s+(\d+\.\s+[A-Z])/g, '$1\n\n$2');
  
  // 2. Add line breaks before stock entries (TICKER - COMPANY pattern)
  formatted = formatted.replace(/([.!?])\s+([A-Z]{2,5})\s+-\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})\s+(?=[A-Z])/g, '$1\n\n$2 - $3 ');
  // Also force break before stock tickers even without punctuation
  formatted = formatted.replace(/\s+([A-Z]{2,5})\s+-\s+(NVIDIA|Apple|Microsoft|Amazon|Tesla|Meta|Alphabet|JPMorgan|Goldman|Wells Fargo|Bank of America|Morgan Stanley|Broadcom|Marvell|UiPath|Snowflake|Zscaler|Taiwan Semiconductor|UnitedHealth|Ulta Beauty)/gi, '\n\n$1 - $2');
  
  // 3. Add line breaks before economic data entries (DATANAME - TIME pattern)
  formatted = formatted.replace(/([.!?])\s+([A-Z][A-Za-z\s]+)\s+-\s+(\d+:\d+\s+[AP]M)/g, '$1\n\n$2 - $3');
  // Also handle "10:00 AM ET" format
  formatted = formatted.replace(/\s+([A-Z][A-Za-z\s]+)\s+-\s+(\d+:\d+\s+[AP]M\s+ET)/g, '\n\n$1 - $2');
  
  // 4. Add line breaks before "The" followed by specific patterns
  formatted = formatted.replace(/([.!?])\s+(The (?:question|key|story|picture|focus|goldilocks))/gi, '$1\n\n$2');
  
  // 5. Force break before Setup blocks
  formatted = formatted.replace(/\s*(Setup[\s:,-])/gi, '\n\n$1');
  formatted = formatted.replace(/(Setup\s+-\s+[^\n]+)/gi, '$1\n');
  
  // 6. Add line breaks before bank tickers (common earnings reports)
  formatted = formatted.replace(/([.!?])\s+(WFC|GS|BAC|MS|JPM|C)\s+-\s+/gi, '$1\n\n$2 - ');
  
  // ========== CLEANUP ==========
  
  // Clean up any triple+ line breaks
  formatted = formatted.replace(/\n{3,}/g, '\n\n');
  
  // Clean up line breaks at start of content
  formatted = formatted.replace(/^\n+/, '');
  
  return formatted;
}


// =====================================================
// CRITICAL FIX: RICH CONTENT RENDERING - v13.2
// =====================================================
function drawSectionContent(doc, title, subtitle, content, startY, onPageBreak) {
  let y = drawSectionHeader(doc, title, subtitle, startY);
  
  if (!content) return y + 10;
  
  // CRITICAL: Reset color to dark text before rendering content
  doc.fillColor(COLORS.darkText);
  
  // Split into logical blocks (paragraphs, numbered items, etc.)
  const blocks = parseContentBlocks(content);
  
  for (const block of blocks) {
    // Check if we need a page break
    const blockHeight = estimateBlockHeight(doc, block);
    if (needsPageBreak(y, blockHeight + 15)) {
      y = onPageBreak();
    }
    
    y = renderBlock(doc, block, y);
    
    // CRITICAL: Reset color after each block to ensure dark text
    doc.fillColor(COLORS.darkText);
    
    // v13.2: Reduced spacing since render functions now use doc.y
    y += 4;
  }
  
  return y + 5;
}

// =====================================================
// v22.0: CONTENT ONLY RENDERING - AGGRESSIVE TABLE REMOVAL
// Tables are rendered separately by renderSectionTables()
// This function must remove ALL table-related content
// =====================================================
function drawSectionContentOnly(doc, content, startY, onPageBreak) {
  let y = startY;
  
  if (!content) return y + 10;
  
  // v22.0: AGGRESSIVE table content removal
  // Since tables are rendered by renderSectionTables, we must strip ALL table syntax
  let cleanContent = removeAllTableContent(content);
  
  // Skip if nothing left after removing tables
  if (!cleanContent || cleanContent.trim().length < 20) {
    return y + 5;
  }
  
  // CRITICAL: Reset color to dark text before rendering content
  doc.fillColor(COLORS.darkText);
  
  // Clean the content
  cleanContent = cleanSectionContent(cleanContent);
  
  // Split into logical blocks (paragraphs, numbered items, etc.)
  const blocks = parseContentBlocks(cleanContent);
  
  for (const block of blocks) {
    // Check if we need a page break
    const blockHeight = estimateBlockHeight(doc, block);
    if (needsPageBreak(y, blockHeight + 15)) {
      y = onPageBreak();
    }
    
    y = renderBlock(doc, block, y);
    
    // CRITICAL: Reset color after each block to ensure dark text
    doc.fillColor(COLORS.darkText);
    
    // v13.2: Reduced spacing since render functions now use doc.y
    y += 4;
  }
  
  return y + 5;
}

// =====================================================
// v22.0: AGGRESSIVE TABLE CONTENT REMOVAL
// Remove ALL lines that look like table data or headers
// =====================================================
function removeAllTableContent(content) {
  if (!content) return '';
  
  const lines = content.split('\n');
  const cleanLines = [];
  
  // Table-related patterns to remove
  const tableHeaderPatterns = [
    /^(Index|Close|Change|Note|Ticker|Company|Date|Time|Previous|Expected|Impact|Rating|Price\s*Target|Firm|Sector|Performance|Leader|Laggard|Status|Signal|Value|Indicator|Rev\s*Est|EPS\s*Est)\s*\|?\s*$/i,
    /^\|\s*(Index|Close|Change|Note|Ticker|Company|Date|Time|Previous|Expected|Impact|Rating|Price\s*Target|Firm|Sector|Performance|Leader|Laggard|Status|Signal|Value|Indicator|Rev\s*Est|EPS\s*Est)/i,
  ];
  
  // Table section headers that appear alone
  const tableSectionHeaders = [
    /^(INDEX PERFORMANCE|MARKET INDICATORS|SECTOR PERFORMANCE|ECONOMIC CALENDAR|EARNINGS CALENDAR|ANALYST ACTIONS|UPCOMING EARNINGS|UPCOMING THIS WEEK|ECONOMIC EVENTS)\s*$/i,
  ];
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    // Skip empty lines (but allow one)
    if (!trimmed) {
      // Only add empty line if previous wasn't empty
      if (cleanLines.length > 0 && cleanLines[cleanLines.length - 1].trim() !== '') {
        cleanLines.push('');
      }
      continue;
    }
    
    // v22.0: Skip ANY line containing pipe characters (table delimiters)
    if (trimmed.includes('|')) {
      continue;
    }
    
    // Skip table separator lines (----, ====, etc.)
    if (/^[-=:]{3,}$/.test(trimmed)) {
      continue;
    }
    
    // Skip standalone table header keywords
    let isTableHeader = false;
    for (const pattern of tableHeaderPatterns) {
      if (pattern.test(trimmed)) {
        isTableHeader = true;
        break;
      }
    }
    if (isTableHeader) continue;
    
    // Skip table section headers (they're added by renderSectionTables)
    let isTableSectionHeader = false;
    for (const pattern of tableSectionHeaders) {
      if (pattern.test(trimmed)) {
        isTableSectionHeader = true;
        break;
      }
    }
    if (isTableSectionHeader) continue;
    
    // Skip very short lines that look like orphaned table cells
    // (e.g., just "SPY", "QQQ", "$100", "+0.5%", etc.)
    if (trimmed.length < 15) {
      // Check if it's just a ticker, price, percentage, or time
      if (/^[A-Z]{1,5}$/.test(trimmed) || // Just ticker
          /^\$?\d+\.?\d*[%]?$/.test(trimmed) || // Just a number/price/percent
          /^\d{1,2}:\d{2}$/.test(trimmed) || // Just a time
          /^(BMO|AMC|N\/A|-|Top|Bottom|Leading|Lagging|Strong|Weak|Normal|High|Low|Med|MED|HIG)$/i.test(trimmed)) {
        continue;
      }
    }
    
    // Keep this line
    cleanLines.push(line);
  }
  
  // Join and clean up multiple newlines
  let result = cleanLines.join('\n');
  result = result.replace(/\n{3,}/g, '\n\n');
  result = result.trim();
  
  return result;
}

// =====================================================
// CRITICAL FIX v12.0: parseContentBlocks with asterisk removal
// and paragraph splitting for max 6 lines
// =====================================================
function parseContentBlocks(content) {
  const blocks = [];
  
  // Safety check for undefined/null content
  if (!content || typeof content !== 'string') {
    console.warn('[PDF] parseContentBlocks: Invalid content received:', typeof content);
    return blocks;
  }
  
  // CRITICAL: Remove ALL asterisks from content first
  let cleanedContent = content
    .replace(/\*\*/g, '')
    .replace(/\*/g, '');
  
  // CRITICAL v12.1: Force split long text into paragraphs
  // Split on sentence endings followed by capital letters (new sentences)
  cleanedContent = smartSplitIntoParagraphs(cleanedContent);
  
  const lines = cleanedContent.split('\n');
  let currentBlock = { type: 'paragraph', lines: [] };
  
  // Helper function to check if current block has content
  const hasContent = (block) => {
    if (!block) return false;
    if (block.type === 'numberedList') {
      return block.items && block.items.length > 0;
    }
    return block.lines && block.lines.length > 0;
  };
  
  // Helper function to push current block if it has content
  const pushCurrentBlock = () => {
    if (hasContent(currentBlock)) {
      blocks.push(currentBlock);
    }
  };
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    
    // Empty line = end of current block
    if (!trimmed) {
      pushCurrentBlock();
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // v22.0: SKIP ALL lines with pipe characters (table content)
    // Tables are rendered separately by renderSectionTables()
    if (trimmed.includes('|')) {
      continue;
    }
    
    // v22.0: Skip separator rows (---|---|)
    if (/^[-:|=]+$/.test(trimmed)) {
      continue;
    }
    
    // Numbered item (1. 2. 3. etc)
    if (/^(\d+)\.\s+/.test(trimmed)) {
      // Push previous block if it's not already a numbered list
      if (currentBlock.type !== 'numberedList') {
        pushCurrentBlock();
        currentBlock = { type: 'numberedList', items: [] };
      }
      
      // Extract number and content
      const match = trimmed.match(/^(\d+)\.\s+(.*)$/);
      if (match) {
        currentBlock.items = currentBlock.items || [];
        currentBlock.items.push({
          number: match[1],
          content: match[2]
        });
      }
      continue;
    }
    
    // Stock ticker header: TICKER | Company or TICKER - Company Name (ONLY if short)
    if (trimmed.length < 80 && 
        (/^[A-Z]{1,5}\s*[\|]\s*.+/i.test(trimmed) || 
         /^[A-Z]{2,5}\s+-\s+[A-Z][a-z]+/.test(trimmed))) {
      pushCurrentBlock();
      blocks.push({ type: 'stockHeader', content: trimmed });
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // Setup block
    if (/^(Setup|Entry|Target|Stop|Timeframe|Conviction)[\s,-]/i.test(trimmed)) {
      pushCurrentBlock();
      // Collect all setup lines
      const setupLines = [trimmed];
      while (i + 1 < lines.length) {
        const nextLine = lines[i + 1].trim();
        if (/^-?\s*(Entry|Target|Stop|Timeframe|Conviction)[\s,:]/i.test(nextLine)) {
          setupLines.push(nextLine);
          i++;
        } else {
          break;
        }
      }
      blocks.push({ type: 'setup', lines: setupLines });
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // Economic data with Previous/Expected format
    if (/Previous:?\s*[\d.$\-]+.*[\|]?\s*Expected/i.test(trimmed) ||
        /Previous\s+[\d.$\-]+.*Expected/i.test(trimmed)) {
      pushCurrentBlock();
      blocks.push({ type: 'economicData', content: trimmed });
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // Section header - ONLY if short and looks like a header
    // v13.0: Enhanced detection for Reports and Week Ahead sections
    if (trimmed.length < 60 && 
        (/^[A-Z\s]{10,}$/.test(trimmed) ||
         /^(REPORTED|REPORTING|UPCOMING|Events This Week|Key Themes|Fund Flows|Buybacks|What Does This Mean)/i.test(trimmed) ||
         /^No earnings/i.test(trimmed) ||
         /^No major earnings/i.test(trimmed))) {
      pushCurrentBlock();
      blocks.push({ type: 'boldHeader', content: trimmed });
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // Day header - ONLY if short (for week ahead)
    if (trimmed.length < 40 && /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),?\s+/i.test(trimmed)) {
      pushCurrentBlock();
      blocks.push({ type: 'dayHeader', content: trimmed });
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // Thematic subtitle - ONLY if starts with — AND is SHORT (max 30 chars)
    if (trimmed.length < 35 && /^[—–]\s+/.test(trimmed)) {
      pushCurrentBlock();
      const subtitle = trimmed.replace(/^[—–]\s+/, '');
      blocks.push({ type: 'thematicSubtitle', content: subtitle });
      currentBlock = { type: 'paragraph', lines: [] };
      continue;
    }
    
    // Regular paragraph line
    if (currentBlock.type === 'numberedList') {
      // Continuation of last numbered item
      if (currentBlock.items && currentBlock.items.length > 0) {
        currentBlock.items[currentBlock.items.length - 1].content += ' ' + trimmed;
      }
    } else {
      // Ensure lines array exists
      currentBlock.lines = currentBlock.lines || [];
      currentBlock.lines.push(trimmed);
    }
  }
  
  // Don't forget the last block
  pushCurrentBlock();
  
  return blocks;
}

// =====================================================
// SMART SPLIT INTO PARAGRAPHS v12.1
// Split long text blocks into readable paragraphs
// =====================================================
function smartSplitIntoParagraphs(text) {
  if (!text) return text;
  
  // v16.5: Preserve table blocks - don't split them
  // Tables have lines starting with |
  const lines = text.split('\n');
  const sections = [];
  let currentSection = [];
  let inTable = false;
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    // Detect table row (starts with | and has multiple |)
    const isTableRow = trimmed.startsWith('|') && trimmed.includes('|', 1);
    // Detect table separator (|---|---|)
    const isTableSeparator = /^\|[\s\-:|]+\|$/.test(trimmed);
    
    if (isTableRow || isTableSeparator) {
      if (!inTable && currentSection.length > 0) {
        // Push previous non-table content
        sections.push({ type: 'text', content: currentSection.join('\n') });
        currentSection = [];
      }
      inTable = true;
      currentSection.push(line);
    } else if (trimmed === '') {
      if (inTable) {
        // End of table
        sections.push({ type: 'table', content: currentSection.join('\n') });
        currentSection = [];
        inTable = false;
      } else if (currentSection.length > 0) {
        // End of text paragraph
        sections.push({ type: 'text', content: currentSection.join('\n') });
        currentSection = [];
      }
    } else {
      if (inTable) {
        // Non-table line after table - end table first
        sections.push({ type: 'table', content: currentSection.join('\n') });
        currentSection = [];
        inTable = false;
      }
      currentSection.push(line);
    }
  }
  
  // Push remaining content
  if (currentSection.length > 0) {
    sections.push({ type: inTable ? 'table' : 'text', content: currentSection.join('\n') });
  }
  
  // Process each section
  const result = [];
  for (const section of sections) {
    if (section.type === 'table') {
      // Tables go through unchanged
      result.push(section.content);
    } else {
      // Text gets split into paragraphs
      const paragraphs = section.content.split(/\n\n+/);
      for (const para of paragraphs) {
        const trimmed = para.trim();
        if (!trimmed) continue;
        
        // Check if this paragraph is too long
        const sentences = trimmed.split(/(?<=[.!?])\s+/);
        
        if (sentences.length > 4 || trimmed.length > 500) {
          let currentPara = [];
          let charCount = 0;
          
          for (const sentence of sentences) {
            currentPara.push(sentence);
            charCount += sentence.length;
            
            if (currentPara.length >= 3 || charCount > 400) {
              result.push(currentPara.join(' '));
              currentPara = [];
              charCount = 0;
            }
          }
          
          if (currentPara.length > 0) {
            result.push(currentPara.join(' '));
          }
        } else {
          result.push(trimmed);
        }
      }
    }
  }
  
  return result.join('\n\n');
}

// =====================================================
// CRITICAL FIX v11.2: estimateBlockHeight with safety checks
// v13.1: Set font/size BEFORE heightOfString for accurate calculation
// =====================================================
function estimateBlockHeight(doc, block) {
  const lineHeight = SIZES.body * 1.4;
  
  if (!block) return 20;
  
  // CRITICAL: Set default font/size for accurate height calculations
  doc.font(FONTS.body).fontSize(SIZES.body);
  
  switch (block.type) {
    case 'table':
      // Each row is about 18px + 8px spacing
      return ((block.rows?.length || 1) * 18) + 15;
    case 'stockHeader':
      return 30; // Increased for safety
    case 'boldHeader':
      return 32; // Increased for safety
    case 'dayHeader':
      return 28; // Increased for safety
    case 'thematicSubtitle':
      return 25; // Increased for safety
    case 'economicData':
      return 20; // Increased for safety
    case 'setup':
      return ((block.lines && block.lines.length) || 1) * lineHeight + 20;
    case 'numberedList':
      if (!block.items || block.items.length === 0) return 20;
      return block.items.reduce((h, item) => {
        const text = cleanText(item.content || '');
        if (!text) return h + 20;
        return h + doc.heightOfString(text, { width: PAGE.contentWidth - 25, lineGap: 3 }) + 20;
      }, 0);
    case 'paragraph':
    default:
      const text = cleanText((block.lines || []).join(' '));
      if (!text) return 15;
      return doc.heightOfString(text, { width: PAGE.contentWidth, lineGap: 3 }) + 20;
  }
}

// =====================================================
// CRITICAL FIX v11.2: renderBlock with safety checks
// =====================================================
function renderBlock(doc, block, y) {
  if (!block) return y;
  
  switch (block.type) {
    case 'table':
      return renderTable(doc, block.rows || [], y);
    case 'stockHeader':
      return renderStockHeader(doc, block.content || '', y);
    case 'boldHeader':
      return renderBoldHeader(doc, block.content || '', y);
    case 'dayHeader':
      return renderDayHeader(doc, block.content || '', y);
    case 'thematicSubtitle':
      return renderThematicSubtitle(doc, block.content || '', y);
    case 'economicData':
      return renderEconomicData(doc, block.content || '', y);
    case 'setup':
      return renderSetup(doc, block.lines || [], y);
    case 'numberedList':
      return renderNumberedList(doc, block.items || [], y);
    case 'paragraph':
    default:
      return renderParagraph(doc, (block.lines || []).join(' '), y);
  }
}

// v16.3: Render markdown table as compact PDF table
function renderTable(doc, rows, y) {
  if (!rows || rows.length === 0) return y;
  
  // Table configuration
  const tableStartX = PAGE.marginLeft;
  const tableWidth = PAGE.contentWidth;
  const rowHeight = 18;
  const cellPadding = 5;
  
  // Calculate column widths based on number of columns
  const numCols = rows[0]?.cells?.length || 3;
  const colWidth = tableWidth / numCols;
  
  // Add some spacing before table
  y += 5;
  
  for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
    const row = rows[rowIdx];
    if (!row || !row.cells) continue;
    
    const isHeader = rowIdx === 0;
    
    // Draw row background for header
    if (isHeader) {
      doc.fillColor(COLORS.veryLightGray)
         .rect(tableStartX, y, tableWidth, rowHeight)
         .fill();
    }
    
    // Draw cells
    for (let colIdx = 0; colIdx < row.cells.length; colIdx++) {
      const cellX = tableStartX + (colIdx * colWidth);
      const cellText = cleanText(row.cells[colIdx] || '');
      
      // Set font and color based on header/data
      if (isHeader) {
        doc.fillColor(COLORS.darkText)
           .font(FONTS.bold)
           .fontSize(SIZES.tableHeader);
      } else {
        doc.fillColor(COLORS.darkText)
           .font(FONTS.body)
           .fontSize(SIZES.tableCell);
      }
      
      // Draw cell text
      doc.text(cellText, cellX + cellPadding, y + 4, {
        width: colWidth - (cellPadding * 2),
        height: rowHeight - 4,
        ellipsis: true
      });
    }
    
    // Draw bottom border
    doc.strokeColor(COLORS.veryLightGray)
       .lineWidth(0.5)
       .moveTo(tableStartX, y + rowHeight)
       .lineTo(tableStartX + tableWidth, y + rowHeight)
       .stroke();
    
    y += rowHeight;
  }
  
  // Reset colors
  doc.fillColor(COLORS.darkText);
  
  return y + 8;
}

// Render stock header: TICKER - Company Name
function renderStockHeader(doc, content, y) {
  if (!content) return y;
  
  // Remove any asterisks and clean
  const cleaned = content.replace(/\*\*/g, '').replace(/\*/g, '');
  
  // Handle both TICKER | Company and TICKER - Company Name patterns
  let ticker, companyName;
  if (cleaned.includes('|')) {
    const parts = cleaned.split('|').map(p => p.trim());
    ticker = parts[0];
    companyName = parts[1] || '';
  } else if (cleaned.includes(' - ')) {
    const parts = cleaned.split(' - ').map(p => p.trim());
    ticker = parts[0];
    companyName = parts.slice(1).join(' - ');
  } else {
    ticker = cleaned;
    companyName = '';
  }
  
  // Add spacing before stock header
  y += 8;
  
  // Ticker in bold gold
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.stockTicker)
     .text(ticker, PAGE.marginLeft, y, { continued: companyName ? true : false });
  
  // Company name in gray
  if (companyName) {
    doc.font(FONTS.body)
       .fillColor(COLORS.mediumGray)
       .text(' - ' + companyName, { continued: false });
  }
  
  // CRITICAL: Reset color to dark text for next content
  doc.fillColor(COLORS.darkText);
  
  // CRITICAL v13.2: Use doc.y for actual position
  return doc.y + 8;
}

// Render bold header with more spacing
function renderBoldHeader(doc, content, y) {
  if (!content) return y;
  
  // Add spacing before header for clear separation
  y += 10;
  
  // Draw a subtle separator line
  doc.strokeColor(COLORS.veryLightGray)
     .lineWidth(0.5)
     .moveTo(PAGE.marginLeft, y - 5)
     .lineTo(PAGE.marginLeft + 150, y - 5)
     .stroke();
  
  doc.fillColor(COLORS.darkText)
     .font(FONTS.bold)
     .fontSize(SIZES.subSection)
     .text(cleanText(content), PAGE.marginLeft, y, { width: PAGE.contentWidth });
  
  // CRITICAL v13.2: Use doc.y for actual position
  return doc.y + 8;
}

// Render day header (for week ahead) with spacing
function renderDayHeader(doc, content, y) {
  if (!content) return y;
  
  // Add spacing before day header
  y += 8;
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.subSection)
     .text(cleanText(content), PAGE.marginLeft, y, { width: PAGE.contentWidth });
  
  // CRITICAL: Reset color to dark text for next content
  doc.fillColor(COLORS.darkText);
  
  // CRITICAL v13.2: Use doc.y for actual position
  return doc.y + 6;
}

// Render thematic subtitle (— The Consumer) - ONLY for short subtitles
function renderThematicSubtitle(doc, content, y) {
  if (!content) return y;
  
  // Add spacing before
  y += 5;
  
  doc.fillColor(COLORS.gold)
     .font(FONTS.bold)
     .fontSize(SIZES.thematicSubtitle)
     .text('— ' + cleanText(content), PAGE.marginLeft, y, { width: PAGE.contentWidth });
  
  // CRITICAL: Reset color to dark text for next content
  doc.fillColor(COLORS.darkText);
  
  // CRITICAL v13.2: Use doc.y for actual position
  return doc.y + 6;
}

// Render economic data
function renderEconomicData(doc, content, y) {
  if (!content) return y;
  
  const cleaned = cleanText(content);
  
  doc.fillColor(COLORS.mediumGray)
     .font(FONTS.body)
     .fontSize(SIZES.small)
     .text(cleaned, PAGE.marginLeft + 10, y, { 
       width: PAGE.contentWidth - 20,
       lineGap: 2
     });
  
  // CRITICAL v13.2: Use doc.y for actual position
  return doc.y + 6;
}

// Render setup block
function renderSetup(doc, lines, y) {
  if (!lines || lines.length === 0) return y;
  
  // Setup header
  const firstLine = lines[0];
  if (firstLine && firstLine.toLowerCase().startsWith('setup')) {
    doc.fillColor(COLORS.darkText)
       .font(FONTS.bold)
       .fontSize(SIZES.small)
       .text('Setup:', PAGE.marginLeft + 10, y);
    y = doc.y + 4;
    lines = lines.slice(1);
  }
  
  // Setup items
  for (const line of lines) {
    if (!line) continue;
    const cleaned = cleanText(line).replace(/^-\s*/, '');
    doc.fillColor(COLORS.mediumGray)
       .font(FONTS.body)
       .fontSize(SIZES.small)
       .text('• ' + cleaned, PAGE.marginLeft + 20, y, { width: PAGE.contentWidth - 30 });
    y = doc.y + 4;
  }
  
  return y + 5;
}

// Render numbered list with proper spacing v13.2
function renderNumberedList(doc, items, y) {
  if (!items || items.length === 0) return y;
  
  for (const item of items) {
    if (!item) continue;
    
    const number = item.number || '•';
    const content = cleanText(item.content || '');
    
    if (!content) continue;
    
    // CRITICAL FIX v13.2: Track positions properly
    
    // Number in gold - render at explicit position
    doc.fillColor(COLORS.gold)
       .font(FONTS.bold)
       .fontSize(SIZES.body)
       .text(number + '.', PAGE.marginLeft, y, { continued: false });
    
    // Content in dark text - render at same Y but offset X
    doc.fillColor(COLORS.darkText)
       .font(FONTS.body)
       .fontSize(SIZES.body)
       .text(content, PAGE.marginLeft + 20, y, { 
         width: PAGE.contentWidth - 25,
         lineGap: 3 
       });
    
    // CRITICAL: Get actual Y position from PDFKit after rendering content
    // This accounts for text wrapping properly
    y = doc.y + 12; // Add spacing between items
  }
  
  // CRITICAL: Reset color to dark text for next content
  doc.fillColor(COLORS.darkText);
  
  return y;
}

// Render regular paragraph - v12.1 with explicit color reset
function renderParagraph(doc, text, y) {
  const cleaned = cleanText(text);
  if (!cleaned) return y;
  
  // Remove any remaining asterisks
  const finalText = cleaned.replace(/\*\*/g, '').replace(/\*/g, '');
  
  // CRITICAL FIX v13.2: Use doc.y to track actual position after rendering
  doc.font(FONTS.body)
     .fontSize(SIZES.body)
     .fillColor(COLORS.darkText);
  
  // Render text at explicit position
  doc.text(finalText, PAGE.marginLeft, y, { 
    width: PAGE.contentWidth, 
    lineGap: 3,
    align: 'justify'
  });
  
  // CRITICAL: Get actual Y position from PDFKit after rendering
  // This is more accurate than calculating height ourselves
  const actualY = doc.y;
  
  // Add spacing after paragraph
  return actualY + 10;
}

// ============ DISCLAIMER PAGE (identical to ISM) ============
function generateDisclaimerSection(doc, logoData) {
  doc.addPage();
  
  // BLACK BACKGROUND
  doc.rect(0, 0, PAGE.width, PAGE.height).fill('#000000');
  
  const frameMargin = 25;
  const frameWidth = PAGE.width - (frameMargin * 2);
  const frameHeight = PAGE.height - (frameMargin * 2);
  
  // OUTER GOLD BORDER
  doc.strokeColor(COLORS.gold)
     .lineWidth(3)
     .rect(frameMargin, frameMargin, frameWidth, frameHeight)
     .stroke();
  
  // INNER GOLD BORDER
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.5)
     .rect(frameMargin + 8, frameMargin + 8, frameWidth - 16, frameHeight - 16)
     .stroke();
  
  let y = frameMargin + 35;
  const centerX = PAGE.width / 2;
  const contentMargin = frameMargin + 35;
  const contentWidth = frameWidth - 70;
  
  // FINOTAUR TEXT
  doc.fillColor(COLORS.gold)
     .fontSize(28)
     .font(FONTS.bold)
     .text('FINOTAUR', 0, y, { align: 'center', width: PAGE.width });
  
  y += 40;
  
  // LOGO under FINOTAUR text
  if (logoData) {
    try {
      const logoWidth = 120;
      const logoX = (PAGE.width - logoWidth) / 2;
      doc.image(logoData, logoX, y, { width: logoWidth });
      y += 70;
    } catch (e) {
      y += 10;
    }
  } else {
    y += 10;
  }
  
  // Gold decorative line
  doc.strokeColor(COLORS.gold)
     .lineWidth(1.5)
     .moveTo(centerX - 80, y)
     .lineTo(centerX + 80, y)
     .stroke();
  
  y += 20;
  
  // IMPORTANT DISCLAIMER title
  doc.fillColor(COLORS.gold)
     .fontSize(22)
     .font(FONTS.bold)
     .text('IMPORTANT DISCLAIMER', 0, y, { align: 'center', width: PAGE.width });
  
  y += 35;
  
  // Thin gold separator
  doc.strokeColor(COLORS.gold)
     .lineWidth(0.75)
     .moveTo(centerX - 100, y)
     .lineTo(centerX + 100, y)
     .stroke();
  
  y += 20;
  
  // Disclaimer sections
  const disclaimerItems = [
    { title: 'GENERAL INFORMATION ONLY', text: 'This report is produced by Finotaur for EDUCATIONAL and INFORMATIONAL purposes ONLY. The content herein is general market commentary and analysis.' },
    { title: 'NOT INVESTMENT ADVICE', text: 'This report does NOT constitute investment advice, financial advice, tax advice, legal advice, or a recommendation to buy or sell any security. Finotaur is NOT a registered investment adviser or broker-dealer.' },
    { title: 'RISK DISCLOSURE', text: 'Trading and investing involves SUBSTANTIAL RISK OF LOSS. Past performance is NOT indicative of future results. You may lose some or ALL of your invested capital.' },
    { title: 'NO GUARANTEES', text: 'Finotaur makes NO guarantees regarding accuracy, completeness, or timeliness of information. All information is provided "AS IS" without warranty.' },
    { title: 'YOUR RESPONSIBILITY', text: 'You should conduct your own research, consult with a qualified financial advisor, and consider your own risk tolerance before making any investment decision.' },
    { title: 'LIMITATION OF LIABILITY', text: 'Finotaur shall NOT be liable for any damages arising from your use of or reliance on this report.' },
  ];
  
  for (const item of disclaimerItems) {
    doc.fillColor(COLORS.gold)
       .fontSize(10)
       .font(FONTS.bold)
       .text(item.title, contentMargin, y, { 
         width: contentWidth,
         underline: true
       });
    y += 14;
    
    doc.fillColor(COLORS.lightGray)
       .fontSize(9)
       .font(FONTS.body)
       .text(item.text, contentMargin, y, { 
         width: contentWidth,
         lineGap: 1.5
       });
    y += doc.heightOfString(item.text, { width: contentWidth, lineGap: 1.5 }) + 12;
  }
  
  // Copyright warning box
  y = Math.max(y + 15, PAGE.height - frameMargin - 120);
  
  doc.fillColor('#2a0a0a')
     .rect(contentMargin - 5, y, contentWidth + 10, 70)
     .fill();
  
  doc.strokeColor(COLORS.red)
     .lineWidth(1.5)
     .rect(contentMargin - 5, y, contentWidth + 10, 70)
     .stroke();
  
  y += 10;
  
  doc.fillColor(COLORS.red)
     .fontSize(11)
     .font(FONTS.bold)
     .text('COPYRIGHT WARNING', contentMargin, y, { 
       width: contentWidth, 
       align: 'center' 
     });
  
  y += 16;
  
  const copyrightText = 'This report is the exclusive intellectual property of FINOTAUR. Unauthorized reproduction, distribution, transmission, display, or publication of this report, in whole or in part, without the prior written consent of FINOTAUR is strictly prohibited and constitutes a violation of copyright law. Violators will be subject to legal action and may be liable for statutory damages.';
  
  doc.fillColor(COLORS.lightGray)
     .fontSize(8)
     .font(FONTS.body)
     .text(copyrightText, contentMargin + 5, y, { 
       width: contentWidth - 10,
       align: 'center',
       lineGap: 1
     });
  
  // Bottom copyright
  doc.fillColor(COLORS.gold)
     .fontSize(10)
     .font(FONTS.body)
     .text('© 2026 Finotaur. All Rights Reserved.', 0, PAGE.height - frameMargin - 35, { 
       align: 'center', 
       width: PAGE.width 
     });
  
  doc.fillColor(COLORS.lightGray)
     .fontSize(8)
     .text('By reading this report, you acknowledge and agree to the terms above.', 0, PAGE.height - frameMargin - 20, { 
       align: 'center', 
       width: PAGE.width 
     });
}

// ============ MAIN PDF GENERATION ============
export async function generateIntelligencePDF(reportText, options = {}) {
  console.log('[PDF] ============================================');
  console.log('[PDF] generateIntelligencePDF called');
  console.log(`[PDF] reportText type: ${typeof reportText}`);
  console.log(`[PDF] reportText length: ${reportText?.length || 0}`);
  console.log(`[PDF] reportText first 300 chars:`);
  console.log(reportText?.substring(0, 300) || 'EMPTY/NULL');
  console.log('[PDF] ============================================');
  
  // v21.0: Log all options for debugging
  console.log(`[PDF] options keys: ${JSON.stringify(Object.keys(options))}`);
  console.log(`[PDF] lockedPrices: ${options.lockedPrices ? 'EXISTS' : 'null'}`);
  console.log(`[PDF] context: ${options.context ? 'EXISTS' : 'null'}`);
  if (options.lockedPrices) {
    console.log(`[PDF] lockedPrices keys: ${JSON.stringify(Object.keys(options.lockedPrices))}`);
    if (options.lockedPrices.indices) {
      console.log(`[PDF] indices: ${JSON.stringify(Object.keys(options.lockedPrices.indices))}`);
    }
  }
  if (options.context) {
    console.log(`[PDF] context keys: ${JSON.stringify(Object.keys(options.context))}`);
  }
  
  // Generate charts if lockedPrices provided
  let charts = { indexPerformance: null, sectorHeatmap: null, vixGauge: null };
  const lockedPrices = options.lockedPrices || null;  // v19.0: Store for table rendering
  const context = options.context || null;  // v21.0: Full context for dynamic tables
  
  if (lockedPrices) {
    console.log('[PDF] Generating charts from lockedPrices...');
    try {
      charts = await generateReportCharts(lockedPrices);
    } catch (err) {
      console.log(`[PDF] Chart generation failed: ${err.message}`);
    }
  }
  
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'letter',
        margin: 0,
        autoFirstPage: false,
        bufferPages: true,
      });

      registerFonts(doc);

      const chunks = [];
      doc.on('data', chunks.push.bind(chunks));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(chunks);
        console.log(`[PDF] Generated ${pdfBuffer.length} bytes`);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      const dateDisplay = formatDateDisplay();
      const logoPath = findLogo(options.logoPath);
      let logoData = null;
      if (logoPath) {
        if (Buffer.isBuffer(logoPath)) {
          logoData = logoPath;
        } else if (typeof logoPath === 'string' && fs.existsSync(logoPath)) {
          logoData = logoPath;
        }
      }

      // ===== COVER PAGE =====
      doc.addPage();
      drawCoverPage(doc, dateDisplay, logoData);

      // ===== CONTENT PAGES =====
      const sections = parseReportSections(reportText);
      console.log(`[PDF] Sections parsed: ${Object.keys(sections).length} sections`);
      console.log(`[PDF] Section keys found: ${Object.keys(sections).join(', ') || 'NONE'}`);
      
      let pageNumber = 1;
      
      // Start first content page
      doc.addPage();
      drawPageHeader(doc, dateDisplay);
      let currentY = PAGE.contentTop;
      
      const onPageBreak = () => {
        drawPageFooter(doc, pageNumber++);
        doc.addPage();
        drawPageHeader(doc, dateDisplay);
        return PAGE.contentTop;
      };

      // Render sections in order
      // Sections that should start on a new page
      const newPageSections = ['macroArena', 'tacticalCorner', 'focusCorner', 'reports'];
      
      for (const sectionKey of SECTION_ORDER) {
        const content = sections[sectionKey];
        if (!content) {
          console.log(`[PDF] Skipping empty section: ${sectionKey}`);
          continue;
        }
        
        const info = SECTION_INFO[sectionKey];
        if (!info) continue;
        
        console.log(`[PDF] Rendering section: ${sectionKey} (${content.length} chars)`);
        
        // Force new page for major sections
        if (newPageSections.includes(sectionKey) || pastThresholdForNewSection(currentY)) {
          currentY = onPageBreak();
        }
        
        // Draw a visual separator before each section (except first)
        if (currentY > PAGE.contentTop + 20) {
          currentY += 15;
          doc.strokeColor(COLORS.gold)
             .lineWidth(1)
             .moveTo(PAGE.marginLeft, currentY)
             .lineTo(PAGE.marginLeft + PAGE.contentWidth, currentY)
             .stroke();
          currentY += 20;
        }
        
        // v19.0: First draw section header
        currentY = drawSectionHeader(doc, info.title, info.subtitle, currentY);
        
        // v21.0: Render dynamic tables from lockedPrices and context
        const sectionsWithTables = ['globalArena', 'weekAhead', 'macroArena', 'analystArena', 'reports'];
        if (sectionsWithTables.includes(sectionKey) && (lockedPrices || context)) {
          console.log(`[PDF] Rendering data tables for ${sectionKey}`);
          currentY = renderSectionTables(doc, sectionKey, lockedPrices, context, currentY, onPageBreak);
        }
        
        // v19.0: Finally render text content (without table markup)
        currentY = drawSectionContentOnly(
          doc, 
          content, 
          currentY, 
          onPageBreak
        );
        
        // Add charts after specific sections
        if (sectionKey === 'globalArena' && (charts.indexPerformance || charts.vixGauge)) {
          currentY += 10;
          
          // Check if we need a page break for charts
          if (currentY + 200 > PAGE.safeBottom) {
            currentY = onPageBreak();
          }
          
          // Draw Index Performance and VIX side by side
          const chartStartX = PAGE.marginLeft;
          const chartWidth = (PAGE.contentWidth - 20) / 2;
          
          if (charts.indexPerformance) {
            try {
              doc.image(charts.indexPerformance, chartStartX, currentY, { width: chartWidth });
              console.log('[PDF] Added index performance chart');
            } catch (e) {
              console.log(`[PDF] Failed to add index chart: ${e.message}`);
            }
          }
          
          if (charts.vixGauge) {
            try {
              doc.image(charts.vixGauge, chartStartX + chartWidth + 20, currentY, { width: chartWidth - 40 });
              console.log('[PDF] Added VIX gauge chart');
            } catch (e) {
              console.log(`[PDF] Failed to add VIX chart: ${e.message}`);
            }
          }
          
          currentY += 160; // Height of charts
        }
        
        // Add sector heatmap after tacticalCorner
        if (sectionKey === 'tacticalCorner' && charts.sectorHeatmap) {
          currentY += 10;
          
          // Check if we need a page break
          if (currentY + 250 > PAGE.safeBottom) {
            currentY = onPageBreak();
          }
          
          // Center the sector heatmap
          const heatmapWidth = PAGE.contentWidth * 0.8;
          const heatmapX = PAGE.marginLeft + (PAGE.contentWidth - heatmapWidth) / 2;
          
          try {
            doc.image(charts.sectorHeatmap, heatmapX, currentY, { width: heatmapWidth });
            console.log('[PDF] Added sector heatmap chart');
            currentY += 220;
          } catch (e) {
            console.log(`[PDF] Failed to add sector heatmap: ${e.message}`);
          }
        }
        
        currentY += 15; // Space between sections
      }

      // Final footer for last content page
      drawPageFooter(doc, pageNumber);

      // ===== DISCLAIMER PAGE =====
      generateDisclaimerSection(doc, logoData);

      // ===== FINALIZE =====
      doc.end();
      
    } catch (error) {
      console.error('[PDF] Generation error:', error);
      reject(error);
    }
  });
}

// =====================================================
// CRITICAL FIX: 3-PARAMETER EXPORT FOR NEWSLETTER.JS
// =====================================================
// newsletter.js calls: generateIntelligenceReportPDFBuffer(report, null, { qaScore, story })
// This wrapper handles the 3-parameter signature
export async function generateIntelligenceReportPDFBuffer(reportText, logoPath = null, options = {}) {
  console.log('[PDF] generateIntelligenceReportPDFBuffer called with 3 params');
  
  // Merge logoPath into options if provided
  const mergedOptions = {
    ...options,
    logoPath: logoPath || options.logoPath,
  };
  
  return generateIntelligencePDF(reportText, mergedOptions);
}

// Default export
export default { 
  generateIntelligencePDF,
  generateIntelligenceReportPDFBuffer
};