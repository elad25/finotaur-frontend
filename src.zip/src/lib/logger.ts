
export function log(...args: any[]) { console.log('[FINOTAUR]', ...args); }
